﻿namespace LKZ_MF_Widget.SetBunkersAtStart
{
    partial class SetBunkersAtStart
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SetBunkersAtStart));
            this.tableLayoutPanelMain = new System.Windows.Forms.TableLayoutPanel();
            this.groupBoxPlace = new System.Windows.Forms.GroupBox();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.radioButtonPd1 = new System.Windows.Forms.RadioButton();
            this.radioButtonOd1 = new System.Windows.Forms.RadioButton();
            this.radioButtonPd2 = new System.Windows.Forms.RadioButton();
            this.radioButtonOd2 = new System.Windows.Forms.RadioButton();
            this.flowLayoutPanelButtons = new System.Windows.Forms.FlowLayoutPanel();
            this.buttonCancel = new System.Windows.Forms.Button();
            this.buttonStart = new System.Windows.Forms.Button();
            this.flowLayoutPanelNotification = new System.Windows.Forms.FlowLayoutPanel();
            this.labelNotification = new System.Windows.Forms.Label();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.panelPriorButtons = new System.Windows.Forms.Panel();
            this.buttonDown = new System.Windows.Forms.Button();
            this.buttonUp = new System.Windows.Forms.Button();
            this.dataGridViewPriorities = new System.Windows.Forms.DataGridView();
            this.tableLayoutPanelMain.SuspendLayout();
            this.groupBoxPlace.SuspendLayout();
            this.flowLayoutPanel1.SuspendLayout();
            this.flowLayoutPanelButtons.SuspendLayout();
            this.flowLayoutPanelNotification.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.panelPriorButtons.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewPriorities)).BeginInit();
            this.SuspendLayout();
            // 
            // tableLayoutPanelMain
            // 
            this.tableLayoutPanelMain.ColumnCount = 1;
            this.tableLayoutPanelMain.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanelMain.Controls.Add(this.groupBoxPlace, 0, 0);
            this.tableLayoutPanelMain.Controls.Add(this.flowLayoutPanelButtons, 0, 2);
            this.tableLayoutPanelMain.Controls.Add(this.tableLayoutPanel1, 0, 1);
            this.tableLayoutPanelMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanelMain.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanelMain.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tableLayoutPanelMain.Name = "tableLayoutPanelMain";
            this.tableLayoutPanelMain.RowCount = 3;
            this.tableLayoutPanelMain.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 13.33333F));
            this.tableLayoutPanelMain.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 86.66666F));
            this.tableLayoutPanelMain.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 51F));
            this.tableLayoutPanelMain.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 31F));
            this.tableLayoutPanelMain.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 31F));
            this.tableLayoutPanelMain.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 31F));
            this.tableLayoutPanelMain.Size = new System.Drawing.Size(758, 570);
            this.tableLayoutPanelMain.TabIndex = 0;
            // 
            // groupBoxPlace
            // 
            this.groupBoxPlace.Controls.Add(this.flowLayoutPanel1);
            this.groupBoxPlace.Dock = System.Windows.Forms.DockStyle.Left;
            this.groupBoxPlace.Location = new System.Drawing.Point(4, 5);
            this.groupBoxPlace.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBoxPlace.Name = "groupBoxPlace";
            this.groupBoxPlace.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBoxPlace.Size = new System.Drawing.Size(676, 59);
            this.groupBoxPlace.TabIndex = 12;
            this.groupBoxPlace.TabStop = false;
            this.groupBoxPlace.Text = "Линия";
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Controls.Add(this.radioButtonPd1);
            this.flowLayoutPanel1.Controls.Add(this.radioButtonOd1);
            this.flowLayoutPanel1.Controls.Add(this.radioButtonPd2);
            this.flowLayoutPanel1.Controls.Add(this.radioButtonOd2);
            this.flowLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel1.Location = new System.Drawing.Point(4, 24);
            this.flowLayoutPanel1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(668, 30);
            this.flowLayoutPanel1.TabIndex = 4;
            // 
            // radioButtonPd1
            // 
            this.radioButtonPd1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.radioButtonPd1.AutoSize = true;
            this.radioButtonPd1.Location = new System.Drawing.Point(4, 5);
            this.radioButtonPd1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButtonPd1.Name = "radioButtonPd1";
            this.radioButtonPd1.Size = new System.Drawing.Size(116, 24);
            this.radioButtonPd1.TabIndex = 0;
            this.radioButtonPd1.TabStop = true;
            this.radioButtonPd1.Text = "1 Линия ПД";
            this.radioButtonPd1.UseVisualStyleBackColor = true;
            this.radioButtonPd1.CheckedChanged += new System.EventHandler(this.radioButtonPd1_CheckedChanged);
            // 
            // radioButtonOd1
            // 
            this.radioButtonOd1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.radioButtonOd1.AutoSize = true;
            this.radioButtonOd1.Location = new System.Drawing.Point(128, 5);
            this.radioButtonOd1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButtonOd1.Name = "radioButtonOd1";
            this.radioButtonOd1.Size = new System.Drawing.Size(116, 24);
            this.radioButtonOd1.TabIndex = 1;
            this.radioButtonOd1.TabStop = true;
            this.radioButtonOd1.Text = "1 Линия ОД";
            this.radioButtonOd1.UseVisualStyleBackColor = true;
            this.radioButtonOd1.CheckedChanged += new System.EventHandler(this.radioButtonOd1_CheckedChanged);
            // 
            // radioButtonPd2
            // 
            this.radioButtonPd2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.radioButtonPd2.AutoSize = true;
            this.radioButtonPd2.Location = new System.Drawing.Point(252, 5);
            this.radioButtonPd2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButtonPd2.Name = "radioButtonPd2";
            this.radioButtonPd2.Size = new System.Drawing.Size(116, 24);
            this.radioButtonPd2.TabIndex = 2;
            this.radioButtonPd2.TabStop = true;
            this.radioButtonPd2.Text = "2 Линия ПД";
            this.radioButtonPd2.UseVisualStyleBackColor = true;
            this.radioButtonPd2.CheckedChanged += new System.EventHandler(this.radioButtonPd2_CheckedChanged);
            // 
            // radioButtonOd2
            // 
            this.radioButtonOd2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.radioButtonOd2.AutoSize = true;
            this.radioButtonOd2.Location = new System.Drawing.Point(376, 5);
            this.radioButtonOd2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButtonOd2.Name = "radioButtonOd2";
            this.radioButtonOd2.Size = new System.Drawing.Size(116, 24);
            this.radioButtonOd2.TabIndex = 3;
            this.radioButtonOd2.TabStop = true;
            this.radioButtonOd2.Text = "2 Линия ОД";
            this.radioButtonOd2.UseVisualStyleBackColor = true;
            this.radioButtonOd2.CheckedChanged += new System.EventHandler(this.radioButtonOd2_CheckedChanged);
            // 
            // flowLayoutPanelButtons
            // 
            this.flowLayoutPanelButtons.Controls.Add(this.buttonCancel);
            this.flowLayoutPanelButtons.Controls.Add(this.buttonStart);
            this.flowLayoutPanelButtons.Controls.Add(this.flowLayoutPanelNotification);
            this.flowLayoutPanelButtons.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanelButtons.FlowDirection = System.Windows.Forms.FlowDirection.RightToLeft;
            this.flowLayoutPanelButtons.Location = new System.Drawing.Point(4, 523);
            this.flowLayoutPanelButtons.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.flowLayoutPanelButtons.Name = "flowLayoutPanelButtons";
            this.flowLayoutPanelButtons.Size = new System.Drawing.Size(750, 42);
            this.flowLayoutPanelButtons.TabIndex = 0;
            // 
            // buttonCancel
            // 
            this.buttonCancel.Location = new System.Drawing.Point(628, 5);
            this.buttonCancel.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.buttonCancel.Name = "buttonCancel";
            this.buttonCancel.Size = new System.Drawing.Size(118, 35);
            this.buttonCancel.TabIndex = 0;
            this.buttonCancel.Text = "Отмена";
            this.buttonCancel.UseVisualStyleBackColor = true;
            this.buttonCancel.Click += new System.EventHandler(this.buttonCancel_Click);
            // 
            // buttonStart
            // 
            this.buttonStart.Location = new System.Drawing.Point(508, 5);
            this.buttonStart.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.buttonStart.Name = "buttonStart";
            this.buttonStart.Size = new System.Drawing.Size(112, 35);
            this.buttonStart.TabIndex = 1;
            this.buttonStart.Text = "Запустить";
            this.buttonStart.UseVisualStyleBackColor = true;
            this.buttonStart.Click += new System.EventHandler(this.buttonStart_Click);
            // 
            // flowLayoutPanelNotification
            // 
            this.flowLayoutPanelNotification.Controls.Add(this.labelNotification);
            this.flowLayoutPanelNotification.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanelNotification.Location = new System.Drawing.Point(4, 3);
            this.flowLayoutPanelNotification.Name = "flowLayoutPanelNotification";
            this.flowLayoutPanelNotification.Size = new System.Drawing.Size(497, 39);
            this.flowLayoutPanelNotification.TabIndex = 3;
            // 
            // labelNotification
            // 
            this.labelNotification.AutoSize = true;
            this.labelNotification.BackColor = System.Drawing.Color.Yellow;
            this.labelNotification.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labelNotification.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelNotification.Location = new System.Drawing.Point(3, 0);
            this.labelNotification.Name = "labelNotification";
            this.labelNotification.Size = new System.Drawing.Size(2, 22);
            this.labelNotification.TabIndex = 0;
            this.labelNotification.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.labelNotification.Visible = false;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 75F));
            this.tableLayoutPanel1.Controls.Add(this.panelPriorButtons, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.dataGridViewPriorities, 0, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(4, 74);
            this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(750, 439);
            this.tableLayoutPanel1.TabIndex = 1;
            // 
            // panelPriorButtons
            // 
            this.panelPriorButtons.Controls.Add(this.buttonDown);
            this.panelPriorButtons.Controls.Add(this.buttonUp);
            this.panelPriorButtons.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelPriorButtons.Location = new System.Drawing.Point(679, 5);
            this.panelPriorButtons.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.panelPriorButtons.Name = "panelPriorButtons";
            this.panelPriorButtons.Size = new System.Drawing.Size(67, 429);
            this.panelPriorButtons.TabIndex = 0;
            // 
            // buttonDown
            // 
            this.buttonDown.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonDown.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonDown.Location = new System.Drawing.Point(4, 283);
            this.buttonDown.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.buttonDown.Name = "buttonDown";
            this.buttonDown.Size = new System.Drawing.Size(58, 146);
            this.buttonDown.TabIndex = 6;
            this.buttonDown.Text = "↓";
            this.buttonDown.UseVisualStyleBackColor = true;
            this.buttonDown.Click += new System.EventHandler(this.buttonDown_Click);
            // 
            // buttonUp
            // 
            this.buttonUp.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonUp.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonUp.Location = new System.Drawing.Point(4, 5);
            this.buttonUp.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.buttonUp.Name = "buttonUp";
            this.buttonUp.Size = new System.Drawing.Size(58, 146);
            this.buttonUp.TabIndex = 5;
            this.buttonUp.Text = "↑";
            this.buttonUp.UseVisualStyleBackColor = true;
            this.buttonUp.Click += new System.EventHandler(this.buttonUp_Click);
            // 
            // dataGridViewPriorities
            // 
            this.dataGridViewPriorities.AllowUserToAddRows = false;
            this.dataGridViewPriorities.AllowUserToResizeRows = false;
            this.dataGridViewPriorities.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewPriorities.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCellsExceptHeaders;
            this.dataGridViewPriorities.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewPriorities.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridViewPriorities.Location = new System.Drawing.Point(4, 5);
            this.dataGridViewPriorities.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.dataGridViewPriorities.MultiSelect = false;
            this.dataGridViewPriorities.Name = "dataGridViewPriorities";
            this.dataGridViewPriorities.RowHeadersVisible = false;
            this.dataGridViewPriorities.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewPriorities.Size = new System.Drawing.Size(667, 429);
            this.dataGridViewPriorities.TabIndex = 1;
            this.dataGridViewPriorities.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewPriorities_CellClick);
            this.dataGridViewPriorities.SelectionChanged += new System.EventHandler(this.dataGridViewPriorities_SelectionChanged);
            // 
            // SetBunkersAtStart
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(758, 570);
            this.Controls.Add(this.tableLayoutPanelMain);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "SetBunkersAtStart";
            this.Text = "Бункеры и порядок дозирования. ";
            this.TopMost = true;
            this.tableLayoutPanelMain.ResumeLayout(false);
            this.groupBoxPlace.ResumeLayout(false);
            this.flowLayoutPanel1.ResumeLayout(false);
            this.flowLayoutPanel1.PerformLayout();
            this.flowLayoutPanelButtons.ResumeLayout(false);
            this.flowLayoutPanelNotification.ResumeLayout(false);
            this.flowLayoutPanelNotification.PerformLayout();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.panelPriorButtons.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewPriorities)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelMain;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanelButtons;
        private System.Windows.Forms.Button buttonCancel;
        private System.Windows.Forms.Button buttonStart;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Panel panelPriorButtons;
        private System.Windows.Forms.Button buttonDown;
        private System.Windows.Forms.Button buttonUp;
        private System.Windows.Forms.DataGridView dataGridViewPriorities;
        private System.Windows.Forms.GroupBox groupBoxPlace;
        private System.Windows.Forms.RadioButton radioButtonOd2;
        private System.Windows.Forms.RadioButton radioButtonPd2;
        private System.Windows.Forms.RadioButton radioButtonOd1;
        private System.Windows.Forms.RadioButton radioButtonPd1;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanelNotification;
        private System.Windows.Forms.Label labelNotification;
    }
}