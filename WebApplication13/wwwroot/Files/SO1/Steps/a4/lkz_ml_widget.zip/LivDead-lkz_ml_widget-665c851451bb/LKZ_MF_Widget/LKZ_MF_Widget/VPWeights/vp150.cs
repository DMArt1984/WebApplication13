﻿using System.Runtime.InteropServices;
using System.Windows.Forms;
using LKZ_MF_Widget.DBClasses;

namespace LKZ_MF_Widget.VPWeights
{
    [ProgId("LKZ_MF_Widget.Vp150")]
    [ComVisible(true)]
    [ClassInterface(ClassInterfaceType.None)]
    //Класс добавления и чтения статистики весов ВП150        
    public class Vp150
    {
        public Vp150()
        {
            ;
        }

        [ComVisible(true)]
        //Метод для добавления информации на весы ВП150          
        public void AddInfo(string name, float taskLeft, float taskRight, int cyclesLeft, int cyclesRight,
            float productionLeft, float productionRight, string fromBunker, string toBunker)
        {
            var query =
                "INSERT INTO dbo.vp150_stats (name,taskLeft, taskRight,cyclesLeft, cyclesRight, productionLeft, productionRight, fromBunker, toBunker) values " +
                "(N'" + name + "'," + taskLeft.ToString().Replace(",", ".") + "," +
                taskRight.ToString().Replace(",", ".") + "," + cyclesLeft + "," + cyclesRight + "," +
                productionLeft.ToString().Replace(",", ".") + "," + productionRight.ToString().Replace(",", ".") + ",N'" +
                fromBunker + "',N'" + toBunker + "')";
            try
            {
                DbConnect.GetDbInstance().PerformNonQuery(query);
            }
            catch
            {
                MessageBox.Show("Не удалось записать данные о приеме сырья на весы ВП150", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1, (MessageBoxOptions)0x40000);
                return;
            }
            ExternalUpdater.ExternalUpdater.GetInstance().UpdateVp();
        }
    }
}