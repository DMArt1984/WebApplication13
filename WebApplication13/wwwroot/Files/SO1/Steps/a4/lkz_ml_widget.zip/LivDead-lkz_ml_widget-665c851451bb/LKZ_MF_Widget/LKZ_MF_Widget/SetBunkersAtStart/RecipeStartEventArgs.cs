﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LKZ_MF_Widget.SetBunkersAtStart
{
    public class RecipeStartEventArgs : EventArgs
    {
        private readonly int _id;

        public delegate void RecipeStartEventHandler(object sender, RecipeStartEventArgs args);

        public RecipeStartEventArgs(int id)
        {
            _id = id;
        }

        public int Id
        {
            get { return _id; }
        }
    }
}
