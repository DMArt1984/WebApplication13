﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Windows.Forms;
using iTextSharp.text;
using iTextSharp.text.pdf;

namespace LKZ_MF_Widget.Reports
{
    //Формирование отчетов для весов ВП
    class ReportVp
    {
        private DataGridView _dgv; //таблица, которую необходимо распечатать
        private string _vpName = ""; //имя весов для отчета
        private string _headerText = ""; //заголовок для отчета

       
        public ReportVp(DataGridView dgv)
        {
            _dgv = dgv;
        }

        public void PrintVp(string footer = "")
        {
            MakeVp(true, footer);
        }

        public void SaveVp(string footer = "")
        {
            MakeVp(false,footer);
        }

        private void MakeVp(bool print = false, string footer = "")
        {
            if (_dgv.Rows.Count == 0)
                return;
            if (_dgv.SelectedRows.Count == 0)
            {
                MessageBox.Show("В выбранной таблице нет ни одной выделенной строки", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1, (MessageBoxOptions)0x40000);
                return;
            }
            var fontsfolder = Environment.GetFolderPath(Environment.SpecialFolder.Fonts);
            var baseFont = BaseFont.CreateFont(fontsfolder + "\\times.ttf", BaseFont.IDENTITY_H, BaseFont.EMBEDDED);
            string folderPath = GetPath(print);
            if (folderPath.Equals(string.Empty))
                return;
            var pdfTable = new PdfPTable(_dgv.ColumnCount) { HorizontalAlignment = Element.ALIGN_CENTER };
            pdfTable.DefaultCell.Padding = 3;
            pdfTable.WidthPercentage = 100;
            pdfTable.HorizontalAlignment = Element.ALIGN_LEFT;
            var f = new Font(baseFont, 11);
            pdfTable.DefaultCell.Phrase = new Phrase { Font = f };
            pdfTable.DefaultCell.VerticalAlignment = Element.ALIGN_CENTER;
            if (File.Exists(folderPath + ".pdf"))
            {
                MessageBox.Show("Файл с таким именем уже существует", "Внимание", MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
                return;
            }
            using (var stream = new FileStream(folderPath + ".pdf", FileMode.Create))
            {
                var pdfDoc = new Document(PageSize.A4, 20f, 20f, 30f, 30f); //Для альбомной добавить к А4.Rotate()
                PdfWriter.GetInstance(pdfDoc, stream);
                pdfDoc.Open();
                var para = new Paragraph("Отчет по работе порционных весов "+_vpName, new Font(f) {Size = 18})
                {
                    Alignment = Element.ALIGN_CENTER,
                    SpacingAfter = 10f,
                    SpacingBefore = 0f
                };
                Paragraph head = new Paragraph();
                if (_headerText != string.Empty) //заголовок с отчетом по времени
                {
                    head = new Paragraph(_headerText, new Font(f) { Size = 14 })
                    {
                        Alignment = Element.ALIGN_CENTER,
                        SpacingAfter = 10f,
                        SpacingBefore = 0f
                    };
                }

                //Делаем заголовок для таблицы
                List<string> header = new List<string>();
                for (int i = 0; i < _dgv.ColumnCount; i++)
                {
                    header.Add(_dgv.Columns[i].HeaderText);
                }
                
                for (int i = 0; i < header.Count; i++)
                {
                    var num = new PdfPCell(new Phrase(header[i], f))
                    {
                        BackgroundColor = new BaseColor(240, 240, 240)
                    };
                    pdfTable.AddCell(num);
                }
                pdfDoc.Add(para);
                pdfDoc.Add(head);
                for (int i = 0; i < _dgv.Rows.Count; i++)
                {
                    if (!_dgv.Rows[i].Selected) //Добавляем только выбранные
                        continue;
                    for (int j = 0; j < _dgv.Columns.Count; j++)
                    {
                        int alignment = GetAlignment(_dgv.Columns[j].DefaultCellStyle.Alignment);
                        var el = _dgv.Rows[i].Cells[j].FormattedValue;
                        if (el != null)
                        {
                            string name = el.ToString();
                            pdfTable.AddCell(new PdfPCell(new Phrase(name, f)) { HorizontalAlignment =  alignment});
                        }
                        else
                        {
                            pdfTable.AddCell(new PdfPCell(new Phrase(" ", f))); 
                        }
                    }
                }
                pdfDoc.Add(pdfTable);
                //Добавляем "Итого"
                pdfDoc.Add(new Phrase("Итого: "+GetTotal().ToString("N3")+" кг.",new Font(f){Size = 11}));
                if (!footer.Equals(string.Empty))  //Добавляем подпись
                {
                    pdfDoc.Add(new Paragraph(" "));
                    pdfDoc.Add(new Phrase(footer, new Font(f) {Size = 11}));
                    pdfDoc.Add(new Paragraph(" "));
                }
                pdfDoc.Add(new Phrase("Сформировано " + DateTime.Now, new Font(f) { Size = 8 }));
                pdfDoc.Close();
                stream.Close();
            }
            if (print)
            {
                TryPrint(folderPath);
            }
            else
            {
                TryOpen(folderPath);
            }
        }

        //Возвращает аналог выравнивание в itextsharp для выравнивания в dgv, чтобы отчеты печатались с тем же выравниванием, что и в dgv
        private int GetAlignment(DataGridViewContentAlignment alignment)
        {
            switch (alignment)
            {
                case DataGridViewContentAlignment.MiddleCenter:
                {
                    return Element.ALIGN_CENTER;
                }
                case DataGridViewContentAlignment.MiddleRight:
                {
                    return Element.ALIGN_RIGHT;
                }
                case DataGridViewContentAlignment.MiddleLeft:
                {
                    return Element.ALIGN_LEFT;
                }
                default:
                {
                    return Element.ALIGN_LEFT;
                }
            }
        }

        //Возвращает "Итого" для порционных весов
        private float GetTotal()
        {
            float total = 0;
            float tmp = 0;
            foreach (DataGridViewRow r in _dgv.SelectedRows)
            {
                if(r.Cells["production"].Value == null)
                    continue;
                try
                {
                    tmp = Convert.ToSingle(r.Cells["production"].Value);
                    total += tmp;
                }
                catch (Exception)
                {
                    // ignored
                }
            }
            return total;
        }
        private string GetPath(bool print)
        {
            string folderPath = Path.GetPathRoot(Environment.SystemDirectory);
            folderPath += "Aseng\\ReportDose\\" + DateTime.Now.ToString("dd-mm-yyyy HH-MM");
            //Спрашиваем куда сохранять
            if (!print)
            {
                var dlg = new SaveFileDialog() { Filter = "PDF (*.pdf)|*.pdf" };
                dlg.FileName = DateTime.Now.ToString("dd-mm-yyyy HH-MM");

                if (dlg.ShowDialog() != DialogResult.OK) return "";
                folderPath = dlg.FileName;
            }
            if (folderPath != string.Empty)
                Directory.CreateDirectory(Path.GetDirectoryName(folderPath));
            else
            {
                MessageBox.Show("Неверно указан путь для записи");
                return "";
            }
            return folderPath;
        }

        //Для открытия файла pdf по пути до него
        private void TryOpen(string folderPath)
        {
            try
            {
                Process.Start(folderPath + ".pdf"); //открываем файл после сохранения
            }
            catch (Exception)
            {
                MessageBox.Show("Не удалось открыть файл отчета", "Ошибка", MessageBoxButtons.OK,
                    MessageBoxIcon.Error, MessageBoxDefaultButton.Button1, (MessageBoxOptions)0x40000);
            }
        }
        //Для печати файла pdf по пути до него
        private void TryPrint(string folderPath)
        {
            try
            {
                var sArgs = " /p \"" + folderPath + ".pdf" + "\"";
                var startInfo = new ProcessStartInfo
                {
                    FileName = @"C:\Program Files (x86)\Foxit Software\Foxit Reader\FoxitReader.exe",
                    Arguments = sArgs,
                    CreateNoWindow = true,
                    WindowStyle = ProcessWindowStyle.Hidden
                };
                var proc = Process.Start(startInfo);
                if (proc != null)
                {
                    proc.WaitForExit(10000); // Ждем 10 сек для закрытия
                    if (!proc.HasExited)
                    {
                        proc.Kill();
                        proc.Dispose();
                    }
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Не удалось распечатать файл отчета", "Ошибка", MessageBoxButtons.OK,
                    MessageBoxIcon.Error, MessageBoxDefaultButton.Button1, (MessageBoxOptions)0x40000);
            }
        }
        //Указать имя весов в заголовке отчета
        public void SetName(string name)
        {
            _vpName = name;
        }
        //Заголовок со временем для отчета
        public void SetHeader(string header = "")
        {
            _headerText = header;
        }
    }
}
