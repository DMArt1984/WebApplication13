﻿using System.Runtime.InteropServices;
using System.Windows.Forms;
using LKZ_MF_Widget.DBClasses;

namespace LKZ_MF_Widget.VPWeights
{
    [ProgId("LKZ_MF_Widget.Vp502")]
    [ComVisible(true)]
    [ClassInterface(ClassInterfaceType.None)]
    //Класс добавления и чтения статистики весов ВП50_2         
    public class Vp502 //: IWeightsVP50
    {
        
        public Vp502()
        {
            ;
        }
        [ComVisible(true)]
        //Метод для добавления информации на весы ВП50_2    
        public void AddInfo(string name, float task, int cycles, float production,string bunker = "-")
        {
            if (bunker.Trim() == string.Empty)
                bunker = "-";
            var query = "INSERT INTO dbo.vp502_stats (name,task,cycles,production,bunker) values (N'" + name + "'," +
                        task.ToString().Replace(",", ".") + "," + cycles + "," + production.ToString().Replace(",", ".") +
                        ",N'"+bunker.Trim().Replace(",",".")+"')";
            try
            {
                DbConnect.GetDbInstance().PerformNonQuery(query);
            }
            catch
            {
                MessageBox.Show("Не удалось записать данные о приеме сырья на весы ВП50-2", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1, (MessageBoxOptions)0x40000);
                return;
            }
            ExternalUpdater.ExternalUpdater.GetInstance().UpdateVp();
        }

        //Перегрузка, позволяющая записывать бункер для весов
       /* public void AddInfo(string name, float task, int cycles, float production, string bunker)
        {
            if (bunker.Trim() == string.Empty)
                bunker = "-";
            var query = "INSERT INTO dbo.vp502_stats (name,task,cycles,production,bunker) values (N'" + name + "'," +
                        task.ToString().Replace(",", ".") + "," + cycles + "," + production.ToString().Replace(",", ".") +
                        ",N'"+bunker.Trim()+"')";
            try
            {
                DbConnect.GetDbInstance().PerformNonQuery(query);
            }
            catch
            {
                MessageBox.Show("Не удалось записать данные о приеме сырья на весы ВП50-2", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1, (MessageBoxOptions)0x40000);
                return;
            }
            ExternalUpdater.ExternalUpdater.GetInstance().UpdateVp();
        }*/
    }
}