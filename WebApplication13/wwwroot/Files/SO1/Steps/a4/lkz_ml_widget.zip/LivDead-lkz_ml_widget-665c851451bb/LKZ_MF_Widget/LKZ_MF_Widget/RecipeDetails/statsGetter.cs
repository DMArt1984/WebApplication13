﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Windows.Forms;

namespace LKZ_MF_Widget.RecipeDetails
{
    //Класс для формирования статистики по рецепту
    class StatsGetter
    {
        private int _id;
        int _tolerance = 3;
        public StatsGetter(int id)
        {
            _id = id;
        }

        public Dictionary<string,string> GetBasicStats(List<string> statNames, int id)
        {
            
            Dictionary<string, string> result = new Dictionary<string, string>();
           /* string query = "select id, name, place, quality, weightKK, weight, Round(weightFact,"+tolerance+") as weightFact, Round(weightFact-weight,"+tolerance+") as devKg," + 
                " Round((weightFact-weight)/(weight/100),"+tolerance+") as devPerc, isFinished, isInProgress, isFinishedErr, comment, commentService," + 
                " timeCreate, timeInProgress, Datepart(minute,timeFinished-timeInProgress) as  duration, timeFinished from dbo.recipe where id="+id;*/
            string query = "select id, name, place, quality, weightKK, weight, Round(weightFact," + _tolerance + ") as weightFact, Round(weightFact-weight," + _tolerance + ") as devKg," +
                " Round((weightFact-weight)/(weight/100)," + _tolerance + ") as devPerc, isFinished, isInProgress, isFinishedErr, comment, commentService," +
                " timeCreate, timeInProgress, (CONVERT(varchar(3),Datediff(MINUTE,timeInProgress,timeFinished)/60) +N' ч. '+CONVERT(varchar(3),Datediff(minute,timeInProgress,timeFinished)%60)+ N' мин.') as duration, " +
                           "timeFinished from dbo.recipe where id=" + id;
            DataTable dt =  DBClasses.DbConnect.GetDbInstance().PerformQuery(query);
            if (dt.Rows.Count != 1)
            {
                MessageBox.Show("Ошибка при запросе данных о рецепте", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1, (MessageBoxOptions)0x40000);
                return result;
            }
            result["Номер"] = dt.Rows[0]["id"].ToString();
            result["Название"] = dt.Rows[0]["name"].ToString();
            result["Линия"] = GetPlacename(dt);
            result["Качество"] = dt.Rows[0]["quality"].ToString();
            result["Задание на к/к, кг."] = dt.Rows[0]["weightKK"].ToString();
            result["Требуемый вес, кг."] = dt.Rows[0]["weight"].ToString();
            result["Фактический вес, кг."] = dt.Rows[0]["weightFact"].ToString();
            result["Отклонение, кг."] = dt.Rows[0]["devKg"].ToString();
            result["Отклонение, %"] = dt.Rows[0]["devPerc"].ToString();
            result["Комментарий"] = dt.Rows[0]["comment"].ToString();
            result["Служебная информация"] = dt.Rows[0]["commentService"].ToString();
            result["Создан"] = dt.Rows[0]["timeCreate"].ToString();
            result["Запущен в работу"] = dt.Rows[0]["timeInProgress"].ToString();
            result["Завершен"] = dt.Rows[0]["timeFinished"].ToString();
            result["Продолжительность"] = dt.Rows[0]["duration"].ToString();
            result["Статус"] = GetStatusByBits(dt);
            if (result["Статус"] == "В работе")   //Формируем выработанную продукцию из отвесов, если рецепт еще не завершен 
            {
                query =
                    "select Round(SUM(weightFact),"+_tolerance+") as weightFact, Round((SUM(weightFact) - (select weight from dbo.recipe where id = "+id+")),"+_tolerance+") as devKg," +
                    "Round(((SUM(weightFact) - (select weight from dbo.recipe where id = " + id + "))/((select weight from dbo.recipe where id = " + id + ")/100))," + _tolerance + ") as devPerc " +
                    "from dbo.recipe_batch where id_ingredient in (select id from dbo.recipe_ingredient where id_recipe = " + id + ")";
                dt = DBClasses.DbConnect.GetDbInstance().PerformQuery(query);
                if (dt.Rows.Count == 1)
                {
                    result["Фактический вес, кг."] = dt.Rows[0]["weightFact"].ToString();
                    result["Отклонение, кг."] = dt.Rows[0]["devKg"].ToString();
                    result["Отклонение, %"] = dt.Rows[0]["devPerc"].ToString();
                }
            }
            return result;
        }

        //Получаем название линии
        private string GetPlacename(DataTable dt)
        {
            if (dt.Rows.Count != 1)
                return "";
            string place = dt.Rows[0]["place"].ToString().Trim();
            if (place.Equals("W6"))
                return "ПД 1 (весы 6)";
            if (place.Equals("W2"))
                return "ОД 1 (весы 2)";
            if (place.Equals("W5"))
                return "ПД 2 (весы 5)";
            if (place.Equals("W4"))
                return "ОД 2 (весы 4)";
            if (place.Equals("Na0"))
                return "Не задана";
            return place;
        }

        //Получаем строковое наименование статуса через биты
        private string GetStatusByBits(DataTable dt)
        {
            if (dt.Rows.Count != 1)
                return "";
            if (dt.Rows[0]["isFinished"].ToString().Equals("True"))
                return "Завершен";
            if (dt.Rows[0]["isInProgress"].ToString().Equals("True"))
                return "В работе";
            if (dt.Rows[0]["isFinishedErr"].ToString().Equals("True"))
                return "Завершен аварийно";
            return "Еще не выполнялся";
        }
        //Для записи рецепта в таблицу общих деталей
        public  DataTable GetRecipe(int ident)
        {
            string query = "select weight from dbo.recipe where id = " + ident;
            DataTable dt = DBClasses.DbConnect.GetDbInstance().PerformQuery(query);
            if (dt.Rows.Count != 1)
            {
                MessageBox.Show("Ошибка при запросе ингредиентов рецепта", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1, (MessageBoxOptions)0x40000);
                return new DataTable();
            }
            string weight = dt.Rows[0]["weight"].ToString().Trim();
             query = "select bunker, name, percentage, Round("+weight+"*percentage/100," + _tolerance + ") as weight, " +
                     "Round(weightFact," + _tolerance + ") as weightFact,"+
                     " Round(weightFact-"+weight+"*percentage/100,"+ _tolerance + ") as deviationKilos," +
                     "Round((weightFact-"+weight+"*percentage/100)/("+weight+"*percentage/10000)," + _tolerance + ") as deviationPercentage" +
                     " from dbo.recipe_ingredient where id_recipe=" + ident + " order by priority asc";
            return DBClasses.DbConnect.GetDbInstance().PerformQuery(query);
        }

        //Приоритеты
        public DataTable GetPriorities(int ident)
        {
            string query = "select name, bunker, priority from dbo.recipe_ingredient where id_recipe = "+ident+" order by priority asc";
            return DBClasses.DbConnect.GetDbInstance().PerformQuery(query);
        }

        //Список отвесов
        public DataTable GetBatches(int ident)
        {
            //Отвесы для рецепта
            string query =
                "select  dbo.recipe_batch.bunker, dbo.recipe_ingredient.name,dbo.recipe_ingredient.percentage, Round(weight,"+_tolerance+") as weight, " +
                "Round(dbo.recipe_batch.weightFact," + _tolerance + ") as weightFact,ROUND(dbo.recipe_batch.weightFact -weight," + _tolerance + ") as deviationKilos," +
                "ROUND((dbo.recipe_batch.weightFact - weight)/(NULLIF(weight,0)/100)," + _tolerance + ") as deviationPercents  ," + 
                " batchNum from dbo.recipe_batch " + 
                "INNER JOIN dbo.recipe_ingredient ON dbo.recipe_batch.id_ingredient = dbo.recipe_ingredient.id where id_ingredient in "+
                "(select id from dbo.recipe_ingredient where id_recipe = "+ident+")   order by batchNum asc";
            DataTable batches =  DBClasses.DbConnect.GetDbInstance().PerformQuery(query);
            //Таблица для формирования строки с "Итого"
            query = "select NULL as bunker, N'Итого' as name, NULL as percentage, " +
                    "ROUND(SUM(weight),"+_tolerance+") as weight, ROUND(SUM(dbo.recipe_batch.weightFact),"+_tolerance+") as weightFact, " +
                    "ROUND(SUM(dbo.recipe_batch.weightFact)-SUM(weight)," + _tolerance + ") as deviationKilos, " +
                    "Round((SUM(dbo.recipe_batch.weightFact) - SUM(weight))/(NULLIF(SUM(weight),0)/100)," + _tolerance + ") as deviationPercents,  " +
                    "batchNum from dbo.recipe_batch INNER JOIN dbo.recipe_ingredient ON dbo.recipe_batch.id_ingredient = dbo.recipe_ingredient.id " +
                    "where id_ingredient in (select id from dbo.recipe_ingredient where id_recipe = " + ident + ") group by batchNum   order by batchNum asc ";
            batches.Merge(DBClasses.DbConnect.GetDbInstance().PerformQuery(query),true, MissingSchemaAction.Ignore);
            return batches;
        }

        //Номер максимального отвеса в рецепте
        public int GetMaxBatchNum(int ident)
        {
            string query =
                "Select MAX(dbo.recipe_batch.batchNum) as maxNum from dbo.recipe_batch where id_ingredient in (select id from dbo.recipe_ingredient where id_recipe = " +
                ident + ")";
            DataTable dt = DBClasses.DbConnect.GetDbInstance().PerformQuery(query);
            if (dt.Rows.Count != 1)
            {
                MessageBox.Show("Ошибка при запросе количества отвесов", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1, (MessageBoxOptions)0x40000);
                return 0;
            }
            if (dt.Rows[0]["maxNum"].Equals(DBNull.Value))
            {
                return 0;
            }
            return Convert.ToInt32(dt.Rows[0]["maxNum"]);
        }
            //Номер минимального отвеса в рецепте
        public int GetMinBatchNum(int ident)
        {
            string query =
                "Select MIN(dbo.recipe_batch.batchNum) as minNum from dbo.recipe_batch where id_ingredient in (select id from dbo.recipe_ingredient where id_recipe = " +
                ident + ")";
            DataTable dt = DBClasses.DbConnect.GetDbInstance().PerformQuery(query);
            if (dt.Rows.Count != 1)
            {
                MessageBox.Show("Ошибка при запросе количества отвесов", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1, (MessageBoxOptions)0x40000);
                return 0;
            }
            if (dt.Rows[0]["minNum"].Equals(DBNull.Value))
            {
                return 0;
            }
            return Convert.ToInt32(dt.Rows[0]["minNum"]);
        }

        //Возвращает список доступных отвесов
        public List<int> GetBatchesList(int ident)
        {
            List<int> result = new List<int>();
            string query =
                "Select Distinct batchNum  from dbo.recipe_batch where id_ingredient in (select id from dbo.recipe_ingredient where id_recipe = " +
                ident + ")";
            DataTable dt = DBClasses.DbConnect.GetDbInstance().PerformQuery(query);
            foreach (DataRow r in dt.Rows)
            {
              result.Add(Convert.ToInt32(r["batchNum"]));  
            }
            result.Sort();
            return result;
        }
        //Отвесы + величина ошибки и высота столба
        public DataTable GetTechnologicalBatches(int ident)
        {
            //Отвесы для рецепта
            string query =
                "select  dbo.recipe_batch.bunker, dbo.recipe_ingredient.name,dbo.recipe_ingredient.percentage, Round(weight," + _tolerance + ") as weight, " +
                "Round(dbo.recipe_batch.weightFact," + _tolerance + ") as weightFact,ROUND(dbo.recipe_batch.weightFact -weight," + _tolerance + ") as deviationKilos," +
                "ROUND((dbo.recipe_batch.weightFact - weight)/(NULLIF(weight,0)/100)," + _tolerance + ") as deviationPercents  ," +
                " batchNum, ROUND(fallingColumnSize," + _tolerance + ") as fallingColumnSize, ROUND(doseErrorSize,"+_tolerance+") as doseErrorSize from dbo.recipe_batch " +
                "INNER JOIN dbo.recipe_ingredient ON dbo.recipe_batch.id_ingredient = dbo.recipe_ingredient.id where id_ingredient in " +
                "(select id from dbo.recipe_ingredient where id_recipe = " + ident + ")   order by batchNum asc";
            DataTable batches = DBClasses.DbConnect.GetDbInstance().PerformQuery(query);
            //Таблица для формирования строки с "Итого"
            query = "select NULL as bunker, N'Итого' as name, NULL as percentage, " +
                    "ROUND(SUM(weight)," + _tolerance + ") as weight, ROUND(SUM(dbo.recipe_batch.weightFact)," + _tolerance + ") as weightFact, " +
                    "ROUND(SUM(dbo.recipe_batch.weightFact)-SUM(weight)," + _tolerance + ") as deviationKilos, " +
                    "Round((SUM(dbo.recipe_batch.weightFact) - SUM(weight))/(NULLIF(SUM(weight),0)/100)," + _tolerance + ") as deviationPercents,  " +
                    "batchNum, Round(SUM(dbo.recipe_batch.fallingColumnSize),"+_tolerance+") as fallingColumnSize, " +
                    " Round(SUM(dbo.recipe_batch.doseErrorSize)," + _tolerance + ") as doseErrorSize from dbo.recipe_batch INNER JOIN dbo.recipe_ingredient ON dbo.recipe_batch.id_ingredient = dbo.recipe_ingredient.id " +
                    "where id_ingredient in (select id from dbo.recipe_ingredient where id_recipe = " + ident + ") group by batchNum   order by batchNum asc ";
            batches.Merge(DBClasses.DbConnect.GetDbInstance().PerformQuery(query), true, MissingSchemaAction.Ignore);
            return batches;
        }
    }
}
