﻿namespace LKZ_MF_Widget.BunkerSkip
{
    partial class BunkerSkip
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BunkerSkip));
            this.tableLayoutPanelMain = new System.Windows.Forms.TableLayoutPanel();
            this.labelRecipe = new System.Windows.Forms.Label();
            this.dataGridViewSkipList = new System.Windows.Forms.DataGridView();
            this.groupBoxPlace = new System.Windows.Forms.GroupBox();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.radioButtonPd1 = new System.Windows.Forms.RadioButton();
            this.radioButtonOd1 = new System.Windows.Forms.RadioButton();
            this.radioButtonOd2 = new System.Windows.Forms.RadioButton();
            this.radioButtonPd2 = new System.Windows.Forms.RadioButton();
            this.labelRecipeNum = new System.Windows.Forms.Label();
            this.flowLayoutPanelButtons = new System.Windows.Forms.FlowLayoutPanel();
            this.buttonCancel = new System.Windows.Forms.Button();
            this.buttonSkip = new System.Windows.Forms.Button();
            this.tableLayoutPanelMain.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewSkipList)).BeginInit();
            this.groupBoxPlace.SuspendLayout();
            this.flowLayoutPanel1.SuspendLayout();
            this.flowLayoutPanelButtons.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanelMain
            // 
            this.tableLayoutPanelMain.ColumnCount = 1;
            this.tableLayoutPanelMain.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanelMain.Controls.Add(this.labelRecipe, 0, 1);
            this.tableLayoutPanelMain.Controls.Add(this.dataGridViewSkipList, 0, 2);
            this.tableLayoutPanelMain.Controls.Add(this.groupBoxPlace, 0, 0);
            this.tableLayoutPanelMain.Controls.Add(this.flowLayoutPanelButtons, 0, 3);
            this.tableLayoutPanelMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanelMain.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanelMain.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tableLayoutPanelMain.Name = "tableLayoutPanelMain";
            this.tableLayoutPanelMain.RowCount = 4;
            this.tableLayoutPanelMain.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 73F));
            this.tableLayoutPanelMain.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 36F));
            this.tableLayoutPanelMain.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanelMain.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 54F));
            this.tableLayoutPanelMain.Size = new System.Drawing.Size(802, 501);
            this.tableLayoutPanelMain.TabIndex = 1;
            // 
            // labelRecipe
            // 
            this.labelRecipe.AutoSize = true;
            this.labelRecipe.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelRecipe.Location = new System.Drawing.Point(4, 84);
            this.labelRecipe.Margin = new System.Windows.Forms.Padding(4, 11, 4, 0);
            this.labelRecipe.Name = "labelRecipe";
            this.labelRecipe.Size = new System.Drawing.Size(64, 20);
            this.labelRecipe.TabIndex = 13;
            this.labelRecipe.Text = "Рецепт";
            // 
            // dataGridViewSkipList
            // 
            this.dataGridViewSkipList.AllowUserToAddRows = false;
            this.dataGridViewSkipList.AllowUserToResizeRows = false;
            this.dataGridViewSkipList.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewSkipList.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCellsExceptHeaders;
            this.dataGridViewSkipList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewSkipList.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridViewSkipList.Location = new System.Drawing.Point(4, 114);
            this.dataGridViewSkipList.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.dataGridViewSkipList.MultiSelect = false;
            this.dataGridViewSkipList.Name = "dataGridViewSkipList";
            this.dataGridViewSkipList.RowHeadersVisible = false;
            this.dataGridViewSkipList.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewSkipList.Size = new System.Drawing.Size(794, 328);
            this.dataGridViewSkipList.TabIndex = 1;
            // 
            // groupBoxPlace
            // 
            this.groupBoxPlace.Controls.Add(this.flowLayoutPanel1);
            this.groupBoxPlace.Dock = System.Windows.Forms.DockStyle.Left;
            this.groupBoxPlace.Location = new System.Drawing.Point(4, 5);
            this.groupBoxPlace.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBoxPlace.Name = "groupBoxPlace";
            this.groupBoxPlace.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBoxPlace.Size = new System.Drawing.Size(567, 63);
            this.groupBoxPlace.TabIndex = 12;
            this.groupBoxPlace.TabStop = false;
            this.groupBoxPlace.Text = "Линия";
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Controls.Add(this.radioButtonPd1);
            this.flowLayoutPanel1.Controls.Add(this.radioButtonOd1);
            this.flowLayoutPanel1.Controls.Add(this.radioButtonOd2);
            this.flowLayoutPanel1.Controls.Add(this.radioButtonPd2);
            this.flowLayoutPanel1.Controls.Add(this.labelRecipeNum);
            this.flowLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel1.Location = new System.Drawing.Point(4, 24);
            this.flowLayoutPanel1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(559, 34);
            this.flowLayoutPanel1.TabIndex = 4;
            // 
            // radioButtonPd1
            // 
            this.radioButtonPd1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.radioButtonPd1.AutoSize = true;
            this.radioButtonPd1.Location = new System.Drawing.Point(4, 5);
            this.radioButtonPd1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButtonPd1.Name = "radioButtonPd1";
            this.radioButtonPd1.Size = new System.Drawing.Size(116, 24);
            this.radioButtonPd1.TabIndex = 0;
            this.radioButtonPd1.TabStop = true;
            this.radioButtonPd1.Text = "1 Линия ПД";
            this.radioButtonPd1.UseVisualStyleBackColor = true;
            this.radioButtonPd1.CheckedChanged += new System.EventHandler(this.radioButtonPd1_CheckedChanged);
            // 
            // radioButtonOd1
            // 
            this.radioButtonOd1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.radioButtonOd1.AutoSize = true;
            this.radioButtonOd1.Location = new System.Drawing.Point(128, 5);
            this.radioButtonOd1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButtonOd1.Name = "radioButtonOd1";
            this.radioButtonOd1.Size = new System.Drawing.Size(116, 24);
            this.radioButtonOd1.TabIndex = 1;
            this.radioButtonOd1.TabStop = true;
            this.radioButtonOd1.Text = "1 Линия ОД";
            this.radioButtonOd1.UseVisualStyleBackColor = true;
            this.radioButtonOd1.CheckedChanged += new System.EventHandler(this.radioButtonPd1_CheckedChanged);
            // 
            // radioButtonOd2
            // 
            this.radioButtonOd2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.radioButtonOd2.AutoSize = true;
            this.radioButtonOd2.Location = new System.Drawing.Point(252, 5);
            this.radioButtonOd2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButtonOd2.Name = "radioButtonOd2";
            this.radioButtonOd2.Size = new System.Drawing.Size(116, 24);
            this.radioButtonOd2.TabIndex = 3;
            this.radioButtonOd2.TabStop = true;
            this.radioButtonOd2.Text = "2 Линия ОД";
            this.radioButtonOd2.UseVisualStyleBackColor = true;
            this.radioButtonOd2.CheckedChanged += new System.EventHandler(this.radioButtonPd1_CheckedChanged);
            // 
            // radioButtonPd2
            // 
            this.radioButtonPd2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.radioButtonPd2.AutoSize = true;
            this.radioButtonPd2.Location = new System.Drawing.Point(376, 5);
            this.radioButtonPd2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButtonPd2.Name = "radioButtonPd2";
            this.radioButtonPd2.Size = new System.Drawing.Size(116, 24);
            this.radioButtonPd2.TabIndex = 2;
            this.radioButtonPd2.TabStop = true;
            this.radioButtonPd2.Text = "2 Линия ПД";
            this.radioButtonPd2.UseVisualStyleBackColor = true;
            this.radioButtonPd2.CheckedChanged += new System.EventHandler(this.radioButtonPd1_CheckedChanged);
            // 
            // labelRecipeNum
            // 
            this.labelRecipeNum.AutoSize = true;
            this.labelRecipeNum.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelRecipeNum.Location = new System.Drawing.Point(500, 0);
            this.labelRecipeNum.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelRecipeNum.Name = "labelRecipeNum";
            this.labelRecipeNum.Size = new System.Drawing.Size(0, 13);
            this.labelRecipeNum.TabIndex = 4;
            // 
            // flowLayoutPanelButtons
            // 
            this.flowLayoutPanelButtons.Controls.Add(this.buttonCancel);
            this.flowLayoutPanelButtons.Controls.Add(this.buttonSkip);
            this.flowLayoutPanelButtons.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanelButtons.FlowDirection = System.Windows.Forms.FlowDirection.RightToLeft;
            this.flowLayoutPanelButtons.Location = new System.Drawing.Point(4, 452);
            this.flowLayoutPanelButtons.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.flowLayoutPanelButtons.Name = "flowLayoutPanelButtons";
            this.flowLayoutPanelButtons.Size = new System.Drawing.Size(794, 44);
            this.flowLayoutPanelButtons.TabIndex = 0;
            // 
            // buttonCancel
            // 
            this.buttonCancel.Location = new System.Drawing.Point(672, 5);
            this.buttonCancel.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.buttonCancel.Name = "buttonCancel";
            this.buttonCancel.Size = new System.Drawing.Size(118, 35);
            this.buttonCancel.TabIndex = 0;
            this.buttonCancel.Text = "Отмена";
            this.buttonCancel.UseVisualStyleBackColor = true;
            this.buttonCancel.Click += new System.EventHandler(this.buttonCancel_Click);
            // 
            // buttonSkip
            // 
            this.buttonSkip.Location = new System.Drawing.Point(552, 5);
            this.buttonSkip.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.buttonSkip.Name = "buttonSkip";
            this.buttonSkip.Size = new System.Drawing.Size(112, 35);
            this.buttonSkip.TabIndex = 1;
            this.buttonSkip.Text = "Пропустить";
            this.buttonSkip.UseVisualStyleBackColor = true;
            this.buttonSkip.Click += new System.EventHandler(this.buttonSkip_Click);
            // 
            // BunkerSkip
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(802, 501);
            this.Controls.Add(this.tableLayoutPanelMain);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "BunkerSkip";
            this.Text = "Пропуск бункера";
            this.tableLayoutPanelMain.ResumeLayout(false);
            this.tableLayoutPanelMain.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewSkipList)).EndInit();
            this.groupBoxPlace.ResumeLayout(false);
            this.flowLayoutPanel1.ResumeLayout(false);
            this.flowLayoutPanel1.PerformLayout();
            this.flowLayoutPanelButtons.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelMain;
        private System.Windows.Forms.GroupBox groupBoxPlace;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.RadioButton radioButtonPd1;
        private System.Windows.Forms.RadioButton radioButtonOd1;
        private System.Windows.Forms.RadioButton radioButtonOd2;
        private System.Windows.Forms.RadioButton radioButtonPd2;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanelButtons;
        private System.Windows.Forms.Button buttonCancel;
        private System.Windows.Forms.Button buttonSkip;
        private System.Windows.Forms.DataGridView dataGridViewSkipList;
        private System.Windows.Forms.Label labelRecipeNum;
        private System.Windows.Forms.Label labelRecipe;
    }
}