﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace LKZ_MF_Widget.MainView
{
    public partial class MainView
    {
        private void CurrentRecipeInit()
        {
            buttonAdd.Click += buttonAdd_Clicked;
            buttonAddByTemplate.Click += buttonAddByTemplate_Click;
            InitDgvCurrentRecipes();
            dataGridViewCurrentRecipes.CellFormatting += DataGridViewCurrentRecipesOnCellFormatting;
            InitDgvRecipe();
            radioButtonCurrentWeek.Checked = true;
            textBoxCurrentId.Enabled = false;
        }

      

        //Отображаем расчет необходимого материала
        private void InitDgvConsumption()
        {
            ClearDgv(dataGridViewRecipe);
          /*  if (dataGridViewRecipe.Columns.Count != 0)
            {
                dataGridViewRecipe.Columns.Clear();
            }*/
            var colNames = new List<KeyValuePair<string, string>>
            {   
                new KeyValuePair<string, string>("Наименование","name"),
                new KeyValuePair<string, string>("Требуемый вес, кг.","weight")
            };
            for (int i = 0; i < colNames.Count; i++)
            {
                var column = new DataGridViewTextBoxColumn();
                dataGridViewRecipe.Columns.Add(column);
                dataGridViewRecipe.Columns[i].DataPropertyName = colNames[i].Value;
                dataGridViewRecipe.Columns[i].Name = colNames[i].Value;
                dataGridViewRecipe.Columns[i].HeaderText = colNames[i].Key;
            }
            dataGridViewRecipe.Columns[1].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dataGridViewRecipe.Columns[1].DefaultCellStyle.Format = "N3";
        }

        //Инициализация таблицы с составом текущего рецепта
        private void InitDgvRecipe()
        {
            ClearDgv(dataGridViewRecipe);
           /* if (dataGridViewRecipe.Columns.Count != 0)
            {
                dataGridViewRecipe.Columns.Clear();
            }*/
            for (var i = 0; i < 6; i++)
            {
                var column = new DataGridViewTextBoxColumn();
                dataGridViewRecipe.Columns.Add(column);
            }
            dataGridViewRecipe.Columns[0].DataPropertyName = "cnt";
            dataGridViewRecipe.Columns[0].Name = "№";
            dataGridViewRecipe.Columns[0].HeaderText = "№";
            dataGridViewRecipe.Columns[0].Width = 40;

            dataGridViewRecipe.Columns[1].DataPropertyName = "name";
            dataGridViewRecipe.Columns[1].Name = "Наименование";
            dataGridViewRecipe.Columns[1].HeaderText = "Наименование";
            dataGridViewRecipe.Columns[1].Width = 200;
            dataGridViewRecipe.Columns[1].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;

            dataGridViewRecipe.Columns[2].DataPropertyName = "percentage";
            dataGridViewRecipe.Columns[2].Name = "Доля в смеси, %";
            dataGridViewRecipe.Columns[2].HeaderText = "Доля в смеси, %";
            dataGridViewRecipe.Columns[2].DefaultCellStyle.Format = "N3";
            dataGridViewRecipe.Columns[2].Width = 120;
            dataGridViewRecipe.Columns[2].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;

            dataGridViewRecipe.Columns[3].DataPropertyName = "mass";
            dataGridViewRecipe.Columns[3].Name = "Вес, кг.";
            dataGridViewRecipe.Columns[3].HeaderText = "Вес, кг.";
            dataGridViewRecipe.Columns[3].DefaultCellStyle.Format = "N3";
            dataGridViewRecipe.Columns[3].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;

            dataGridViewRecipe.Columns[4].DataPropertyName = "bunker";
            dataGridViewRecipe.Columns[4].Name = "Бункер";
            dataGridViewRecipe.Columns[4].HeaderText = "Бункер";
            dataGridViewRecipe.Columns[4].Width = 80;
            dataGridViewRecipe.Columns[4].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;

            dataGridViewRecipe.Columns[5].DataPropertyName = "priority";
            dataGridViewRecipe.Columns[5].Name = "Приоритет";
            dataGridViewRecipe.Columns[5].HeaderText = "Приоритет";
            dataGridViewRecipe.Columns[5].Width = 100;
            dataGridViewRecipe.Columns[5].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
        }

        //Инициализация таблицы с текущим рецептом
        private void InitDgvCurrentRecipes()
        {
            ClearDgv(dataGridViewCurrentRecipes);
            for (var i = 0; i < 8; i++)
            {
                var column = new DataGridViewTextBoxColumn();
                dataGridViewCurrentRecipes.Columns.Add(column);
            }

            dataGridViewCurrentRecipes.Columns[0].DataPropertyName = "id";
            dataGridViewCurrentRecipes.Columns[0].Name = "№";
            dataGridViewCurrentRecipes.Columns[0].HeaderText = "№";
            dataGridViewCurrentRecipes.Columns[0].Width = 40;

            dataGridViewCurrentRecipes.Columns[1].DataPropertyName = "name";
            dataGridViewCurrentRecipes.Columns[1].Name = "Наименование";
            dataGridViewCurrentRecipes.Columns[1].HeaderText = "Наименование";

            dataGridViewCurrentRecipes.Columns[2].DataPropertyName = "weight";
            dataGridViewCurrentRecipes.Columns[2].Name = "Вес, кг.";
            dataGridViewCurrentRecipes.Columns[2].HeaderText = "Вес, кг.";
            dataGridViewCurrentRecipes.Columns[2].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dataGridViewCurrentRecipes.Columns[2].DefaultCellStyle.Format = "N0";

            dataGridViewCurrentRecipes.Columns[3].DataPropertyName = "timeCreate";
            dataGridViewCurrentRecipes.Columns[3].Name = "Дата добавления";
            dataGridViewCurrentRecipes.Columns[3].HeaderText = "Дата добавления";
            dataGridViewCurrentRecipes.Columns[3].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;

            dataGridViewCurrentRecipes.Columns[4].DataPropertyName = "isFinished";
            dataGridViewCurrentRecipes.Columns[4].Name = "Завершен";
            dataGridViewCurrentRecipes.Columns[4].HeaderText = "Завершен";
            dataGridViewCurrentRecipes.Columns[4].Visible = false;

            dataGridViewCurrentRecipes.Columns[5].DataPropertyName = "isInProgress";
            dataGridViewCurrentRecipes.Columns[5].Name = "В работе";
            dataGridViewCurrentRecipes.Columns[5].HeaderText = "В работе";
            dataGridViewCurrentRecipes.Columns[5].Visible = false;

            dataGridViewCurrentRecipes.Columns[6].DataPropertyName = "isFinishedErr";
            dataGridViewCurrentRecipes.Columns[6].Name = "Завершен с аварией";
            dataGridViewCurrentRecipes.Columns[6].HeaderText = "Завершен с аварией";
            dataGridViewCurrentRecipes.Columns[6].Visible = false;

            dataGridViewCurrentRecipes.Columns[7].DataPropertyName = "place";
            dataGridViewCurrentRecipes.Columns[7].Name = "Линия";
            dataGridViewCurrentRecipes.Columns[7].HeaderText = "Линия";
            dataGridViewCurrentRecipes.Columns[7].Visible = false;
            
        }

        private void buttonAdd_Clicked(object sender, EventArgs e)
        {
            if (_nr != null)
            {
                _nr.NewRecipeAdded -= nr_NewRecipeAdded;
                _nr.Dispose();
            }
            _nr = new NewRequest.NewRequest();
            _nr.Closing += (snder, args) => { _nr.Owner = null; };
            _nr.NewRecipeAdded += nr_NewRecipeAdded;
            _nr.Show();
        }

        //Обновление текущих рецептов по событию добавления нового рецепта
        private void nr_NewRecipeAdded(object sender, EventArgs e)
        {
            UpdateCurrentRecipes();
        }

        //Добавление заявки по шаблону
        private void buttonAddByTemplate_Click(object sender, EventArgs e)
        {
            if (dataGridViewCurrentRecipes.SelectedRows.Count != 1)
            {
                MessageBox.Show("Выберите один рецепт для создания шаблона", "Внимание", MessageBoxButtons.OK,
                    MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1, (MessageBoxOptions)0x40000);
                dataGridViewCurrentRecipes.ClearSelection();
                return;
            }
            var id = Convert.ToInt32(dataGridViewCurrentRecipes.SelectedRows[0].Cells[0].Value);
            if (_nr != null)
            {
                _nr.NewRecipeAdded -= nr_NewRecipeAdded;
                _nr.Dispose();
            }
            _nr = new NewRequest.NewRequest(id);
            _nr.NewRecipeAdded += nr_NewRecipeAdded;
            _nr.Show();
        }
    }
}