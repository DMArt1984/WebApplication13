﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using LKZ_MF_Widget.Settings;

namespace LKZ_MF_Widget.DBClasses
{
    internal class DbConnect
    {
        private static DbConnect _dbInstance;
        private static readonly SqlConnection Conn = new SqlConnection();
        private static readonly QueryQueue<string> QueryQueue = new QueryQueue<string>();

        private DbConnect()
        {
            Conn.StateChange += StateChanged; //Обрабатываем отключение от базы
            QueryQueue.QueryAdded += ProcessQuery; //Обрабатываем запросы из списка           
        }

        public static event EventHandler ConnectionLost; // Сигнал разрыва соединения
        public static event EventHandler ConnectionEstablished; // Сигнал установления соединения

        //Узнать количество запросов для выполнения
        public static int GetQueueSize()
        {
            if (QueryQueue != null)
                return QueryQueue.Count;
            return 0;
        }


        //Обработка изменения состояния подключения
        private void StateChanged(object sender, EventArgs e)
        {
            if (Conn.State == ConnectionState.Open)
            {
                if (ConnectionEstablished != null)
                {
                    ConnectionEstablished(this, new EventArgs());
                }
            }
            else
            {
                if (ConnectionLost != null)
                {
                    ConnectionLost(this, new EventArgs());
                }
            }
        }

        //Возвращает состояние подключения
        public static bool IsOnline()
        {
            if (Conn == null)
                return false;
            if (Conn.State != ConnectionState.Open)
                return false;
            return true;
        }

        //Выполнение запросов из очереди
        private void ProcessQuery(object sender, EventArgs e)
        {
            if (Conn.State != ConnectionState.Open)
                return;
            
            while (QueryQueue.Count > 0)
            {
                var query = QueryQueue.Dequeue();
                var cmd = new SqlCommand(query) {Connection = Conn};
                try
                {
                   
                    cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }
        }

        //Возвращает экземпляр подключения к БД
        public static DbConnect GetDbInstance()
        {
            if (_dbInstance == null)
            {
                _dbInstance = new DbConnect();
                _dbInstance.Connect();
            }
            return _dbInstance;
        }

        //Подключение к БД
        private void Connect()
        {
            if (_dbInstance == null)
            {
                _dbInstance = new DbConnect();
            }
            if (Conn.State != ConnectionState.Open)
            {
                Conn.Close();
                var dbUserName = widget.Default.dbUserName;
                string dbUserPass;
                using (var secureString = widget.Default.dbUserPassword.DecryptString())
                {
                    dbUserPass = secureString.ToInsecureString();
                }
                var dbLocation = widget.Default.dbLocation;
                var dbName = widget.Default.dbName;
                var connectionString = FormConnectionString(dbUserName, dbUserPass, dbLocation, dbName);
                Conn.ConnectionString = connectionString;
                try
                {
                    Conn.Open();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Не удалось подключиться к БД\n" + ex.Message, @"Ошибка", MessageBoxButtons.OK,
                        MessageBoxIcon.Error, MessageBoxDefaultButton.Button1, (MessageBoxOptions)0x40000);
                    Console.WriteLine(ex.Message);
                    //Для вызова функции из vbs action
                  //  DBClasses.ConnectionLost cnLost = new ConnectionLost();
                  //  cnLost.Show();
                }
            }
        }

        //Для формирования строки подключения к базе
        private string FormConnectionString(string name, string pass, string location, string basename)
        {
            var connString = "Data Source=" + location + @"\WINCC ; Initial Catalog=" + basename + " ; User id = " +
                             name;
            if (!pass.Equals(string.Empty))
                connString += " ; Password=" + pass;
            //Одновременно запрашивать несколько результатов
            connString += " ; MultipleActiveResultSets=True;";
            return connString;
        }

        //Выполнить запрос без возрващаемых данных
        public void PerformNonQuery(string query)
        {
            query = "begin transaction; " + query + " commit;";
            QueryQueue.Enqueue(query);
        }

        //Выполнить запрос с возвращаемыми данными
        public DataTable PerformQuery(string request)
        {
            var set = new DataTable();
            request = "begin transaction; " + request + " commit;";
            if (Conn.State == ConnectionState.Closed)
            {
                try
                {
                    Conn.Open();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(@"Не удалось подключиться к БД", @"Ошибка", MessageBoxButtons.OK,
                        MessageBoxIcon.Error, MessageBoxDefaultButton.Button1, (MessageBoxOptions)0x40000);
                    MessageBox.Show(ex.Message);
                    Console.WriteLine(ex.Message);
                }
            }
            try
            {
                using (var cmd = Conn.CreateCommand())
                {
                    cmd.CommandText = request;
                    using (var r = cmd.ExecuteReader())
                    {
                        set.Load(r);
                        r.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка выполнения запроса к БД\n" + ex.Message, @"Внимание", MessageBoxButtons.OK,
                    MessageBoxIcon.Error, MessageBoxDefaultButton.Button1, (MessageBoxOptions)0x40000);
            }
            return set;
        }

        //Возвращает SCOPE_IDENTITY
        public int GetLastInsertedId()
        {
            var dt = GetDbInstance().PerformQuery("select SCOPE_IDENTITY() as [ident]");
            var result = Convert.ToInt32(dt.Rows[0]["ident"]);
            return result;
        }

        //Попытка подключения после обрыва связи
        public void TryReconnect(string name, string pass, string location, string dbName)
        {
            if (Conn.State == ConnectionState.Open)
            {
                GetDbInstance().StateChanged(this, new EventArgs());
                return;
            }
            var devConnString = FormConnectionString(name, pass, location, dbName);
            Conn.ConnectionString = devConnString;
            try
            {
                Conn.Open();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Не удалось подключиться к БД\n" + ex.Message, @"Ошибка", MessageBoxButtons.OK,
                    MessageBoxIcon.Error, MessageBoxDefaultButton.Button1, (MessageBoxOptions)0x40000);
                Console.WriteLine(ex.Message);
                return;
            }
            if (Conn.State == ConnectionState.Open)
            {
                ProcessQuery(this, new EventArgs());
                widget.Default["dbName"] = dbName;
                widget.Default["dbLocation"] = location;
                widget.Default["dbUserName"] = name;
                using (var secureString = pass.ToSecureString())
                {
                    widget.Default["dbUserPassword"] = secureString.EncryptString();
                }
                widget.Default.Save();
            }
        }
    }
}