﻿using System;
using System.Data;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using LKZ_MF_Widget.DBClasses;

namespace LKZ_MF_Widget.ScadaDataExchanger
{
    //Возвращаем этот класс в скаду для чтения данных о заявке
    [ProgId("LKZ_MF_Widget.GetBunkerData")]
    [ComVisible(true)]
    [ClassInterface(ClassInterfaceType.AutoDispatch)]
    public class GetBunkerData
    {
        //Пустой конструктор нужен для вызова из SCADA, не удалять
        //Список линий
        private enum Line
        {
            Pd1,
            Pd2,
            Od1,
            Od2
        }
        
        //Возвращаем задание для бункера по номеру
        public Bunker GetData(int num)
        {
            //Надо подтянуть приоритет из recipe_ingredient
            var query = "select task, currentPriority from dbo.bunker_card where bunkNum = " + num;
            var dt = DbConnect.GetDbInstance().PerformQuery(query);
            if (dt.Rows.Count != 1)
            {
                MessageBox.Show("Ошибка при запросе данных от бункера " + num + ".\nНеверно указан номер бункера.",
                    "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1, (MessageBoxOptions)0x40000);
                return new Bunker(0f, 0);
            }
            var task = Convert.ToSingle(dt.Rows[0]["task"]);
            var priority = Convert.ToInt32(dt.Rows[0]["currentPriority"]);
            return new Bunker(task, priority);
        }

        public Bunker GetData(string num)
        {
            int bunkNum;
            try
            {
                bunkNum = Convert.ToInt32(num);
            }
            catch (Exception)
            {
                MessageBox.Show("Не удалось принять номер бункера со SCADA", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1, (MessageBoxOptions)0x40000);
                return  new Bunker();
            }
            return GetData(bunkNum);
        }
        //Возвращает имя запущенного рецепта
        private string GetRecipeName(Line ln)
        {
            string query = "select name from dbo.recipe where isInProgress = 1 and place = N'" + GetPlaceName(ln) + "'";
            DataTable dt = DbConnect.GetDbInstance().PerformQuery(query);
            if (dt.Rows.Count != 1)
                return "-";
            return dt.Rows[0]["name"].ToString().Trim();
        }
        //Имя весов для базы по enum
        private object GetPlaceName(Line ln)
        {
            switch (ln)
            {
                case Line.Pd1:
                    return "W6";
                case Line.Pd2:
                    return "W5";
                case Line.Od1:
                    return "W2";
                case Line.Od2:
                    return "W4";
                default:
                    return "Na0";
            }
        }

        //Методы для передачи имени рецепта в SCADA

        #region GetRecipeName
        [ComVisible(true)]
        public string GetRecipeNamePd1()
        {
            return GetRecipeName(Line.Pd1);
        }
        [ComVisible(true)]
        public string GetRecipeNamePd2()
        {
            return GetRecipeName(Line.Pd2);
        }
        [ComVisible(true)]
        public string GetRecipeNameOd1()
        {
            return GetRecipeName(Line.Od1);
        }
        [ComVisible(true)]
        public string GetRecipeNameOd2()
        {
            return GetRecipeName(Line.Od2);
        }

        #endregion
    }
}