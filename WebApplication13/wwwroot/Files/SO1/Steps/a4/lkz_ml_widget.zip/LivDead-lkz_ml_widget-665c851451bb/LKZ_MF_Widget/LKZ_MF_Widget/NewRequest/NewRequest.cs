﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using LKZ_MF_Widget.DBClasses;
using Microsoft.Office.Interop.Excel;
using Application = Microsoft.Office.Interop.Excel.Application;
using DataTable = System.Data.DataTable;

namespace LKZ_MF_Widget.NewRequest
{
    public partial class NewRequest : Form
    {
        private readonly int _tolerance = 3; //Точность округления
        private FastAddIngredient _fai; //Для добавления новых ингредиентов
        public event EventHandler NewRecipeAdded;
        private bool _byTemplate = false;
        private int _templateId = 0;
        private bool _templateLineBeenChanged = false;
        private bool _isGeneralRecipeActive = true; //Если true, то активно основное окно рецепта, если false - приоритеты
        private Timer _tm; //таймер для отображения ошибок
             
        public NewRequest()
        {
            SetupForm();
        }

        //Конструктор для добавления по шаблону
        public NewRequest(int id)
        {
            SetupForm();
            Text = "Шаблон по заявке № " + id;
            _byTemplate = true;
            _templateId = id;
            FillTemplate(id);
            //Если линию меняли, то значит уже не по шаблону !! Важно чтобы бункера не путались между линиями
            radioButtonOd1.CheckedChanged += (sender, args) => { _byTemplate = false; };
            radioButtonPd1.CheckedChanged += (sender, args) => { _byTemplate = false; };
            radioButtonOd2.CheckedChanged += (sender, args) => { _byTemplate = false; };
            radioButtonPd2.CheckedChanged += (sender, args) => { _byTemplate = false; };
        }

        //Конструктор импорта заявки
        public NewRequest(string folderPath)
        {
            SetupForm();
            Text = "Импорт заявки";
            FillbByExcelFile(folderPath);
        }

        //Метод для заполнения формы данными из файла xls
        private void FillbByExcelFile(string folderPath)
        {
            var xlApp = new Application();
            var xlWorkBook = xlApp.Workbooks.Open(folderPath, 0, true, 5, "", "", true, XlPlatform.xlWindows, "\t", false,
                false, 0, true, 1, 0);
            var xlWorkSheet = (Worksheet)xlWorkBook.Worksheets.Item[1];
            var range = xlWorkSheet.UsedRange;
            string parsedStr = xlWorkSheet.Range["A9"].Value; //Строка с названием рецепта
            try
            {
                if (parsedStr != null)
                    FillBoxes(parsedStr); //заполняем текствобсы качества названия и коммент
            }
            catch (Exception)
            {
                ;
            }
            //Забиваем материалы в словарь
            Dictionary<string, string> ingrDict = GetRecipeFromExcel(range);
            if (ingrDict.Count == 0)
            {
                MessageBox.Show("Не удалось найти рецепт в файле", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1, (MessageBoxOptions)0x40000);
                return;
            }
            dataGridViewIngredients.Rows.Add(ingrDict.Count);
            //Проверяем есть ли такие ингредиенты
            foreach (string ing in ingrDict.Keys)
            {
                CheckIngredientExist(ing.Trim(), true);
            }
            //Добавляем в таблицу ингредиенты
            int i = 0;
            foreach (KeyValuePair<string, string> pair in ingrDict)
            {
                dataGridViewIngredients.Rows[i].Cells[1].Value = pair.Key.Trim();
                dataGridViewIngredients.Rows[i].Cells[2].Value = pair.Value.Trim().Replace("%","");
                i++;
            }
            xlWorkBook.Close(false);
            xlApp.Quit();
        }

        //Возвращаем словарь с ингредиентами и процентами из файла в excel
        private Dictionary<string, string> GetRecipeFromExcel(Range range)
        {
            Dictionary<string, string> ingrDict = new Dictionary<string, string>();
            try
            {
                //Ищем начало ингредиентов
                Range ingredientCol = range.Find("Состав", Missing.Value,
                    XlFindLookIn.xlValues, XlLookAt.xlPart,
                    XlSearchOrder.xlByRows, XlSearchDirection.xlNext, false,
                    Missing.Value, Missing.Value);
                //Ищем начало процентов
                Range percentsCol = range.Find("В рецепте", Missing.Value,
                    XlFindLookIn.xlValues, XlLookAt.xlPart,
                    XlSearchOrder.xlByRows, XlSearchDirection.xlNext, false,
                    Missing.Value, Missing.Value);
                int row = ingredientCol.Row + 1;
                int col = ingredientCol.Column;
                //Заполняем словарь с рецептом
                while (row < 150)
                {
                    if (((Range)range.Cells[row, col]).Value2 != null)
                    {
                        string name =
                            (string)((Range)range.Cells[row, ingredientCol.Column]).Value2;
                        if (name == null)
                            break;
                        if (name.Equals(string.Empty) || name.Contains("концентрата:"))
                            break;
                        string perc = (string)((Range)range.Cells[row, percentsCol.Column]).Value2.ToString();
                        ingrDict.Add(name, perc);
                    }
                    row++;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Не удалось найти рецепт в файле", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1, (MessageBoxOptions)0x40000);
                return new Dictionary<string, string>();
            }
            return ingrDict;
        }

        //Проверяем существует ли ингредиент с заданными именем, при необходимости добавляем
        private bool CheckIngredientExist(string name, bool autoAdd = false)
        {
            string query = "select id from dbo.ingredient_list where BINARY_CHECKSUM(name) = BINARY_CHECKSUM(N'" + name + "')";
            DataTable dt = DbConnect.GetDbInstance().PerformQuery(query);
            if (dt.Rows.Count >= 1)
            {
                return true;
            }
            if (autoAdd)
            {
                string push = "insert into dbo.ingredient_list (name) values (N'" + name + "')";
                DbConnect.GetDbInstance().PerformNonQuery(push);
                foreach (DataGridViewRow r in dataGridViewIngredients.Rows)
                {
                    ((DataGridViewComboBoxCell)r.Cells[1]).Items.Add(name);
                    ((DataGridViewComboBoxCell)r.Cells[1]).Sorted = true;
                }
            }
            return false;
        }

        //Инициализация формы
        private void SetupForm()
        {
            InitializeComponent();
            CenterToScreen();
            TopMost = true;
            checkBoxLine.Checked = false;
            buttonSetPriorities.Visible = false;
            groupBoxPlace.Enabled = false;

            tableLayoutPanelNewRequest.ColumnStyles[0].SizeType = SizeType.Absolute;
            tableLayoutPanelNewRequest.ColumnStyles[1].SizeType = SizeType.Absolute;
            tableLayoutPanelNewRequest.ColumnStyles[2].SizeType = SizeType.Absolute;
            tableLayoutPanelNewRequest.ColumnStyles[0].Width = Width/2;
            tableLayoutPanelNewRequest.ColumnStyles[1].Width = Width/2 - 15;
            tableLayoutPanelNewRequest.ColumnStyles[2].Width = 0;
            InitDgv();
            InitDgvPriorities();

            checkBoxCountWeight.Checked = false;
            flowLayoutPanelCountWeight.Enabled = false;
        }

        //Заполнение формы данными из шаблона
        private void FillTemplate(int id)
        {
            FillTemplateIngredients(id);
            FillTemplateBunkers(id);
        }
        //Заполнение информации о бункерах в заявке по шаблону
        private void FillTemplateBunkers(int id)
        {
            dataGridViewIngredients.Sort(dataGridViewIngredients.Columns[2], ListSortDirection.Descending);
            List<string> recipeIngredients = new List<string>();
            foreach (DataGridViewRow r in dataGridViewIngredients.Rows)
            {
                if(r.Cells[1].Value != null)
                    recipeIngredients.Add(r.Cells[1].Value.ToString().Trim());
            }
        /*    string query = "select place from dbo.recipe where id = "+id;
            DataTable dt = DbConnect.GetDbInstance().PerformQuery(query);
            if(dt.Rows.Count != 1)
                return;
            CheckRadioButton(dt.Rows[0]["place"].ToString().Trim());
            query = "select name, bunker from dbo.recipe_ingredient where id_recipe = " + id + " order by percentage desc";
            dt = DbConnect.GetDbInstance().PerformQuery(query);
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                if (!recipeIngredients.Contains(dt.Rows[i]["name"].ToString().Trim()))
                    continue;
                dataGridViewPriorities.Rows.Add();
                int rowNum = dataGridViewPriorities.RowCount - 1;
                dataGridViewPriorities.Rows[rowNum].Cells[1].Value = dt.Rows[i]["name"].ToString().Trim();
                if (((DataGridViewComboBoxCell)dataGridViewPriorities.Rows[rowNum].Cells[2]).Items.Contains(dt.Rows[i]["bunker"].ToString().Trim()))  //Проверка что к комбобоксе есть необходимые бункера
                {
                    ((DataGridViewComboBoxCell)dataGridViewPriorities.Rows[rowNum].Cells[2]).Value =
                        dt.Rows[i]["bunker"].ToString().Trim();
                }
            }
            //Проверяем есть ли новые ингредиенты в рецепте по шаблону и при необходимости добавляем
            if (dataGridViewIngredients.RowCount != dataGridViewPriorities.RowCount)
            {
                List<string> existingIngredients = new List<string>();
                foreach (DataGridViewRow r in dataGridViewPriorities.Rows)
                {
                    existingIngredients.Add(r.Cells[1].Value.ToString().Trim());
                }
                string ingr = "";
                foreach (DataGridViewRow r in dataGridViewIngredients.Rows)
                {
                    if (r.Cells[1].Value != null)
                    {
                        ingr = r.Cells[1].Value.ToString().Trim();
                        if (!existingIngredients.Contains(ingr))
                        {
                            dataGridViewPriorities.Rows.Add();
                            dataGridViewPriorities.Rows[dataGridViewPriorities.RowCount - 1].Cells[1].Value = ingr;
                        }
                    }
                }
            }*/
            Dictionary<string, string> existingBunkers = new Dictionary<string, string>();
            string query = "select place from dbo.recipe where id = " + id;
            DataTable dt = DbConnect.GetDbInstance().PerformQuery(query);
            if (dt.Rows.Count != 1)
                return;
            CheckRadioButton(dt.Rows[0]["place"].ToString().Trim());
            query = "select name, bunker from dbo.recipe_ingredient where id_recipe = " + id + " order by percentage desc";
            dt = DbConnect.GetDbInstance().PerformQuery(query);
            foreach (DataRow r in dt.Rows)
            {
                existingBunkers.Add(r["name"].ToString().Trim(),r["bunker"].ToString().Trim());
            }
            for (int i = 0; i < dataGridViewIngredients.RowCount-1; i++)
            {
                dataGridViewPriorities.Rows.Add();
                string name = dataGridViewIngredients.Rows[i].Cells[1].Value.ToString().Trim();
                dataGridViewPriorities.Rows[i].Cells[1].Value = name;
                if (existingBunkers.ContainsKey(name))
                {
                    if (((DataGridViewComboBoxCell) dataGridViewPriorities.Rows[i].Cells[2]).Items.Contains(existingBunkers[name]))
                    {
                        ((DataGridViewComboBoxCell) dataGridViewPriorities.Rows[i].Cells[2]).Value =
                            existingBunkers[name];
                    }
                }
            }


        }
        //Отметить нужный radiobutton по имени линии
        private void CheckRadioButton(string name)
        {
            checkBoxLine.Checked = true;
            switch (name)
            {
                case "W2":
                {
                    radioButtonOd1.Checked = true;
                    return;
                }
                case "W4":
                {
                    radioButtonOd2.Checked = true;
                    return;
                }
                case "W6":
                {
                    radioButtonPd1.Checked = true;
                    return;
                }
                case "W5":
                {
                    radioButtonPd2.Checked = true;
                    return;
                }
                default:
                {
                    radioButtonOd1.Checked = false;
                    radioButtonOd2.Checked = false;
                    radioButtonPd1.Checked = false;
                    radioButtonPd2.Checked = false;
                    checkBoxLine.Checked = false;
                    return;
                }
            }
        }

        private void FillTemplateIngredients(int id)
        {
            var query = "select name, quality, weight, weightKK from dbo.recipe where id = " + id;
            var dt = DbConnect.GetDbInstance().PerformQuery(query);
            if (dt.Rows.Count != 1)
            {
                MessageBox.Show("Не удалось создать шаблон", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1, (MessageBoxOptions)0x40000);
                Dispose();
            }
            textBoxQuality.Text = dt.Rows[0]["quality"].ToString().Trim();
            textBoxRecipeName.Text = dt.Rows[0]["name"].ToString().Trim();
            textBoxWeight.Text = dt.Rows[0]["weight"].ToString().Trim();
            textBoxWeightKK.Text = dt.Rows[0]["weightKK"].ToString().Trim();
            query = "select name, percentage from dbo.recipe_ingredient where id_recipe = " + id+" order by percentage desc";
            dt = DbConnect.GetDbInstance().PerformQuery(query);
            for (var i = 0; i < dt.Rows.Count; i++)
            {
                dataGridViewIngredients.Rows.Add();
                string ingr = dt.Rows[i]["name"].ToString().Trim();
                CheckIngredientExist(ingr, true);   //добавляем ингредиенты если их не существует
                dataGridViewIngredients.Rows[i].Cells[1].Value = ingr;
                try
                {
                    dataGridViewIngredients.Rows[i].Cells[2].Value = Convert.ToSingle(dt.Rows[i]["percentage"]);
                }
                catch 
                {
                    dataGridViewIngredients.Rows[i].Cells[2].Value = dt.Rows[i]["percentage"].ToString().Trim();
                }
            }
            dataGridViewIngredients.Sort(dataGridViewIngredients.Columns[2],ListSortDirection.Descending);
        }

        //Инициализация таблицы с бункерами и приоритетами
        private void InitDgvPriorities()
        {
            DataGridViewCell cell = new DataGridViewTextBoxCell();
            for (var i = 0; i < 3; i++)
            {
                if (i == 2)
                {
                    dataGridViewPriorities.Columns.Add(GetBunkerColumn());
                    continue;
                }
                dataGridViewPriorities.Columns.Add(new DataGridViewColumn(cell));
                dataGridViewPriorities.Columns[i].SortMode = DataGridViewColumnSortMode.Automatic;
            }

            dataGridViewPriorities.Columns[0].HeaderText = "Приоритет";
            dataGridViewPriorities.Columns[1].HeaderText = "Название ингредиента";
            dataGridViewPriorities.Columns[2].HeaderText = "Бункер";
            dataGridViewPriorities.Columns[0].ReadOnly = true;
            dataGridViewPriorities.Columns[1].ReadOnly = true;
            dataGridViewPriorities.RowHeadersVisible = false;
        }


        //Запись приоритетов в столбец 
        private void SetPriorities()
        {
            for (var i = 0; i < dataGridViewPriorities.Rows.Count; i++)
            {
                dataGridViewPriorities.Rows[i].Cells[0].Value = i + 1;
            }
        }

        //Комбобоксы с бункерами для рецепта
        private DataGridViewColumn GetBunkerColumn()
        {
            var cmbCell = new DataGridViewComboBoxCell();
            var items = FillBunkersList();
            items.Sort();
            foreach (var s in items)
            {
                cmbCell.Items.Add(s);
            }
            return new DataGridViewColumn(cmbCell) {HeaderText = "Бункер"};
        }

        //Возвращает список бункеров для выбранной линии
        private List<string> FillBunkersList()
        {
            var result = new List<string>();
            var query = "select bunkNum from dbo.bunker_card where place = N'";
            if (radioButtonOd1.Checked)
            {
                query += "W2";
            }
            if (radioButtonOd2.Checked)
            {
                query += "W4";
            }
            if (radioButtonPd1.Checked)
            {
                query += "W6";
            }
            if (radioButtonPd2.Checked)
            {
                query += "W5";
            }
            query += "';";
            var dt = DbConnect.GetDbInstance().PerformQuery(query);
            foreach (DataRow r in dt.Rows)
            {
                result.Add(r["bunkNum"].ToString().Trim());
            }
            return result.Distinct().ToList();
        }

        //Инициализация таблицы с рецептом
        private void InitDgv()
        {
            DataGridViewCell cell = new DataGridViewTextBoxCell();
            for (var i = 0; i < 5; i++)
            {
                if (i == 1)
                {
                    dataGridViewIngredients.Columns.Add(GetIngredientsColumn());
                    continue;
                }
                if (i == 4)
                {
                    dataGridViewIngredients.Columns.Add(new DataGridViewButtonColumn
                    {
                        HeaderText = "Удалить",
                        Text = "-",
                        UseColumnTextForButtonValue = true
                    });
                    continue;
                }
                dataGridViewIngredients.Columns.Add(new DataGridViewColumn(cell));
                dataGridViewIngredients.Columns[i].SortMode = DataGridViewColumnSortMode.Automatic;
            }

            dataGridViewIngredients.Columns[0].HeaderText = "№";
            dataGridViewIngredients.Columns[0].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewIngredients.Columns[1].HeaderText = "Название ингредиента";
            dataGridViewIngredients.Columns[1].Width = 160;
            dataGridViewIngredients.Columns[2].HeaderText = "Доля в смеси, %";
            dataGridViewIngredients.Columns[2].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dataGridViewIngredients.Columns[2].DefaultCellStyle.Format = "N3";
            dataGridViewIngredients.Columns[3].HeaderText = "Масса, кг";
            dataGridViewIngredients.Columns[3].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dataGridViewIngredients.Columns[3].DefaultCellStyle.Format = "N3";
            dataGridViewIngredients.Columns[3].ReadOnly = true;
            dataGridViewIngredients.Columns[0].Width = 40;
            dataGridViewIngredients.Columns[4].Width = 55;
            dataGridViewIngredients.Columns[0].ReadOnly = true;
            dataGridViewIngredients.RowHeadersVisible = false;

            dataGridViewIngredients.SortCompare += dataGridViewIngredients_SortCompare;
            dataGridViewIngredients.Sorted += dataGridViewIngredients_Sorted;
        }
        //Обработка сортировки dgv
        void dataGridViewIngredients_SortCompare(object sender, DataGridViewSortCompareEventArgs e)
        {
            e.SortResult = Compare(e.CellValue1.ToString(), e.CellValue2.ToString());
            e.Handled = true;
        }
        //Для обработчика сортировки
        private int Compare(string a, string b)
        {
            try
            {
                return decimal.Parse(a).CompareTo(decimal.Parse(b));
            }
            catch
            {
                return 0;
            }
        }
        //Нумерация ингредиентов в таблице
        void dataGridViewIngredients_Sorted(object sender, EventArgs e)
        {
            for (int i = 0; i < ((DataGridView) sender).RowCount-1; i++)
            {
                ((DataGridView) sender).Rows[i].Cells[0].Value = i + 1;
            }
        }
     

        //Колонка с ингредиентами
        private DataGridViewColumn GetIngredientsColumn()
        {
            var cmbCell = new DataGridViewComboBoxCell();
            var items = FillIngridientsList();
            items.Sort();
            foreach (var s in items)
            {
                cmbCell.Items.Add(s);
            }
            return new DataGridViewColumn(cmbCell);
        }

        //Загрузка списка всех ингредиентов из базы
        private List<string> FillIngridientsList()
        {
            var result = new List<string>();
            var query = "select name from dbo.ingredient_list;";
            var dt = DbConnect.GetDbInstance().PerformQuery(query);
            foreach (DataRow r in dt.Rows)
            {
                result.Add(r["name"].ToString().Trim());
            }
            return result.Distinct().ToList();
        }

        private void buttonCancel_Click(object sender, EventArgs e)
        {
            Dispose();
        }

        private void textBoxWeightKK_TextChanged(object sender, EventArgs e)
        {
            textBoxWeightKK.Text = Regex.Replace(textBoxWeightKK.Text, "[^0-9]", string.Empty);
        }

        //Подсчет веса для процентов в списке ингредиентов
        private void CountMassForIngridient()
        {
            float weight;
            if (textBoxWeight.Text == string.Empty)
                return;
            try
            {
                weight = Convert.ToSingle(textBoxWeight.Text);
            }
            catch
            {
                return;
            }
            for (var i = 0; i < dataGridViewIngredients.Rows.Count; i++)
            {
                if (dataGridViewIngredients.Rows[i].IsNewRow)
                    continue;
                try
                {
                    var percent = Convert.ToSingle(dataGridViewIngredients.Rows[i].Cells[2].Value);
                    dataGridViewIngredients.Rows[i].Cells[3].Value = Math.Round(weight*percent*0.01, _tolerance);
                }
                catch
                {
                    dataGridViewIngredients.Rows[i].Cells[3].Value = 0;
                }
            }
        }

        private void textBoxWeight_TextChanged(object sender, EventArgs e)
        {
            textBoxWeight.Text = Regex.Replace(textBoxWeight.Text, "[^0-9]", string.Empty);
            CountMassForIngridient();
        }

        private void textBoxQuality_TextChanged(object sender, EventArgs e)
        {
            textBoxQuality.Text = Regex.Replace(textBoxQuality.Text, "[^0-9]", string.Empty);
        }

        private void dataGridViewIngredients_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridViewIngredients.Rows[e.RowIndex].Cells[1].Value == null &&
                dataGridViewIngredients.Rows[e.RowIndex].Cells[2].Value == null)
            {
                try
                {
                    if (!dataGridViewIngredients.Rows[e.RowIndex].IsNewRow)
                        dataGridViewIngredients.Rows.Remove(dataGridViewIngredients.Rows[e.RowIndex]);
                    for (var i = 0; i < dataGridViewIngredients.Rows.Count; i++)
                        dataGridViewIngredients.Rows[i].Cells[0].Value = i + 1;
                }
                catch
                {
                    return;
                }
            }
            CountPercentSum();
        }

        //Подсчет суммы процентов
        private float CountPercentSum()
        {
            float res = 0;
            foreach (DataGridViewRow r in dataGridViewIngredients.Rows)
            {
                if (r.IsNewRow)
                    continue;
                if (r.Cells[2].Value != null)
                {
                    try
                    {
                        var f = Convert.ToSingle(r.Cells[2].Value);
                        res += f;
                    }
                    catch
                    {
                        labelSumm.Text = "Сумма: ";
                        return 0f;
                    }
                }
            }
            res = (float) Math.Round(res, _tolerance);
            LabelSetPercents(res);
            return res;
        }

        //Устанавливаем сумму процентов в лейбл
        private void LabelSetPercents(float percents)
        {
            if (Math.Round(percents, _tolerance) > 100)
                labelSumm.BackColor = Color.Yellow;
            else
                labelSumm.BackColor = SystemColors.Control;
            if (Math.Round(percents, _tolerance) == 100)
                labelSumm.BackColor = Color.ForestGreen;
            labelSumm.Text = "Сумма: " + percents + " %";
        }

        private void dataGridViewIngredients_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex == -1)
                return;
            if (e.ColumnIndex != 2)
                return;
            if (dataGridViewIngredients.Rows[e.RowIndex].IsNewRow)
                return;
            var corrected = "";
            if (dataGridViewIngredients.Rows[e.RowIndex].Cells[2].Value != null)
                corrected = dataGridViewIngredients.Rows[e.RowIndex].Cells[2].Value.ToString();
            string separator =Convert.ToChar(CultureInfo.CurrentCulture.NumberFormat.NumberDecimalSeparator).ToString();
        //    corrected = Regex.Replace(corrected, "\\.", ",");
            if(separator.Equals("."))
                corrected = Regex.Replace(corrected, ",", separator);
            else
            {
                corrected = Regex.Replace(corrected, "\\.", ",");
            }
            corrected = Regex.Replace(corrected, "[a-z]+", "");
         /*   if (corrected.Contains(","))
                corrected = Regex.Match(corrected, "([0-9]+,[0-9]+)").ToString();
            else
                corrected = Regex.Match(corrected, "([0-9]+)").ToString();*/
            corrected = Regex.Replace(corrected, "0+,", "0,");
            corrected = Regex.Replace(corrected, "^0+", "");
            if (corrected.Equals(string.Empty))
                return;
            try
            {
                var f = Convert.ToSingle(corrected);
                dataGridViewIngredients.Rows[e.RowIndex].Cells[2].Value = f.ToString();
            }
            catch
            {
                dataGridViewIngredients.Rows[e.RowIndex].Cells[2].Value = null;
                return;
            }
            CountPercentSum();
            CountMassForIngridient();
        }

        //Нумерация
        private void dataGridViewIngredients_RowsAdded(object sender, DataGridViewRowsAddedEventArgs e)
        {
            foreach (DataGridViewRow r in dataGridViewIngredients.Rows)
            {
                if (!r.IsNewRow)
                    r.Cells[0].Value = (r.Index + 1);
            }
        }

        //Удаление строки по нажатию на кнопку
        private void dataGridViewIngredients_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            var senderGrid = (DataGridView) sender;

            if (senderGrid.Columns[e.ColumnIndex] is DataGridViewButtonColumn &&
                e.RowIndex >= 0)
            {
                if (!dataGridViewIngredients.Rows[e.RowIndex].IsNewRow)
                {
                    dataGridViewIngredients.Rows.RemoveAt(e.RowIndex);
                    Update();
                }
            }
        }

        //Нумерация
        private void dataGridViewIngredients_RowsRemoved(object sender, DataGridViewRowsRemovedEventArgs e)
        {
            foreach (DataGridViewRow r in dataGridViewIngredients.Rows)
            {
                if (!r.IsNewRow)
                    r.Cells[0].Value = (r.Index + 1);
            }
            CountPercentSum();
        }

        //Комбобокс открывается по 1му нажатию
        private void dataGridViewIngredients_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            var validRow = (e.RowIndex != -1); //Make sure the clicked row isn't the header.

            // Check to make sure the cell clicked is the cell containing the combobox 
            if (dataGridViewIngredients.Columns[e.ColumnIndex].Index == 1 && validRow)
            {
                dataGridViewIngredients.BeginEdit(true);
                ((ComboBox) dataGridViewIngredients.EditingControl).DroppedDown = true;
            }
        }

        //Добавление рецепта без бункеров и приоритетов
        private void buttonAdd_Click(object sender, EventArgs e)
        {
            if (!CheckRecipe()) return;
            int id;
            try
            {
                id = SaveRecipe();
                if(id==0)
                    throw new Exception();
                var ingredients = PushIngredientsToList(id);
                foreach (var i in ingredients)
                    i.SaveToDb();
            }
            catch
            {
                MessageBox.Show("Не удалось сохранить рецепт", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1, (MessageBoxOptions)0x40000);
                return;
            }
            Hide();
            MessageBox.Show("Добавлен новый рецепт номер: " + id, "Инфо", MessageBoxButtons.OK,
                MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, (MessageBoxOptions)0x40000);
            if (NewRecipeAdded != null) NewRecipeAdded(this, new EventArgs());
            Dispose();
        }

        //Сохраняем рецепт в базу, возвращаем номер добавленной заявки
        private int SaveRecipe()
        {
            var query =
                "insert into dbo.recipe (name, quality, weight, weightKK, comment, isFinished, isInProgress, isFinishedErr, place) values ";
            var name = textBoxRecipeName.Text.Trim();
            var quality = textBoxQuality.Text.Trim();
            var weight = textBoxWeight.Text.Trim();
            var weightKk = textBoxWeightKK.Text.Trim();
            var comment = textBoxComment.Text.Trim();
            query += "(N'" + name + "',N'" + quality + "'," + weight + "," + weightKk + ",N'" + comment + "', 0,0,0,N'" +
                     GetPlace() + "');";
            DbConnect.GetDbInstance().PerformNonQuery(query);
           // var idRecipe = DbConnect.GetDbInstance().GetLastInsertedId(); //работает чере scope_identity
            var idRecipe = GetLastInsertedRecipeId(); //через IDENT_CURRENT
            return idRecipe;
        }
        //Получаем id последнего добавленного рецепта через IDENT_CURRENT
        private int GetLastInsertedRecipeId()
        {
            var query = "select IDENT_CURRENT('recipe') as [ident]";
            DataTable dt = DbConnect.GetDbInstance().PerformQuery(query);
            int id = Convert.ToInt32(dt.Rows[0]["ident"]);
            return id;
        }

        //Возвращаем место положение для рецепта
        private string  GetPlace()
        {
            var res = "";
            if (!checkBoxLine.Checked)
                res = "Na0";
            else
            {
                if (radioButtonOd1.Checked)
                    res = "W2"; //"OD1";
                if (radioButtonPd1.Checked)
                    res = "W6"; // "PD1";
                if (radioButtonOd2.Checked)
                    res = "W4"; //"OD2";
                if (radioButtonPd2.Checked)
                    res = "W5"; //"PD2";
            }
            return res;
        }

        //Сохраняем ингредиенты из DGV в список
        private List<Ingredient> PushIngredientsToList(int idRecipe, bool pushPriorities = false)
        {
            var res = new List<Ingredient>();
            string separator = Convert.ToChar(CultureInfo.CurrentCulture.NumberFormat.NumberDecimalSeparator).ToString();
            foreach (DataGridViewRow r in dataGridViewIngredients.Rows)
            {
                if (r.IsNewRow)
                    continue;
                var name = r.Cells[1].Value.ToString().Trim();
                string per = r.Cells[2].Value.ToString();
                per = per.Replace(",", separator);
                per = per.Replace(".", separator);
                var percentage = Convert.ToSingle(per);
                
                res.Add(new Ingredient(name, percentage, idRecipe));
            }
            if (pushPriorities)
            {
                foreach (var ing in res)
                {
                    foreach (DataGridViewRow r in dataGridViewPriorities.Rows)
                    {
                        if (r.Cells[1].Value.ToString().Equals(ing.Name))
                        {
                            var priority = Convert.ToInt32(r.Cells[0].Value);
                            var bunker = Convert.ToInt32(r.Cells[2].Value);
                            ing.SetBunkerPriority(bunker, priority);
                            break;
                        }
                    }
                }
            }
            return res;
        }


        private void checkBoxLine_CheckedChanged(object sender, EventArgs e)
        {
            buttonSetPriorities.Visible = checkBoxLine.Checked;
            buttonAdd.Visible = !checkBoxLine.Checked;
            groupBoxPlace.Enabled = checkBoxLine.Checked;
            if (!radioButtonOd1.Checked && !radioButtonPd1.Checked && !radioButtonOd2.Checked && !radioButtonPd2.Checked)
            {
                radioButtonPd1.Checked = true;
            }
        }

        //Задать приоритеты для рецепта
        private void buttonSetPriorities_Click(object sender, EventArgs e)
        {
            if (!CheckRecipe())
                return;
            if (!checkBoxLine.Checked)
            {
                MessageBox.Show("Выберите линию", "Внимание",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1, (MessageBoxOptions)0x40000);
                return;
            }
            FillPrioritiesDgv();
            ShowPriorities();
        }

        //Заполняем таблицу с приоритетами нужными данными при переходе от рецепта
        private void FillPrioritiesDgv()
        {
            try
            {
                dataGridViewPriorities.Rows.Clear();
            }
            catch
            {
                // ignored
            }
            dataGridViewPriorities.Columns.RemoveAt(2);
            dataGridViewPriorities.Columns.Add(GetBunkerColumn());
            if (!_byTemplate)
            {
                dataGridViewIngredients.Sort(dataGridViewIngredients.Columns[2],ListSortDirection.Descending);
                for (var i = 0; i < dataGridViewIngredients.Rows.Count; i++)
                {
                    if (dataGridViewIngredients.Rows[i].IsNewRow)
                        continue;
                    dataGridViewPriorities.Rows.Add();
                    dataGridViewPriorities.Rows[i].Cells[1].Value = dataGridViewIngredients.Rows[i].Cells[1].Value;
                }
            }
            else
            {
                FillTemplateBunkers(_templateId);
            }
            dataGridViewPriorities.Columns[0].Width = 40;
            dataGridViewPriorities.Columns[1].Width = 160;
            dataGridViewPriorities.Columns[2].Width = 60;
            SetPriorities();
        }

        //Отобразить часть интерфейса с выбором приоритетов
        private void ShowPriorities()
        {
            tableLayoutPanelNewRequest.ColumnStyles[2].Width = tableLayoutPanelNewRequest.ColumnStyles[0].Width +
                                                               tableLayoutPanelNewRequest.ColumnStyles[1].Width;
            tableLayoutPanelNewRequest.ColumnStyles[0].Width = 0;
            tableLayoutPanelNewRequest.ColumnStyles[1].Width = 0;
            _isGeneralRecipeActive = false;
            labelNotificationGeneral.Text = "";
            labelNotificationPriorities.Text = "";
            labelNotificationGeneral.Visible = false;
            labelNotificationPriorities.Visible = false;
        }

        //Скрыть часть интерфейса с выбором приоритетов
        private void HidePriorities()
        {
            tableLayoutPanelNewRequest.ColumnStyles[0].Width = tableLayoutPanelNewRequest.ColumnStyles[2].Width/2;
            tableLayoutPanelNewRequest.ColumnStyles[1].Width = tableLayoutPanelNewRequest.ColumnStyles[2].Width/2;
            tableLayoutPanelNewRequest.ColumnStyles[2].Width = 0;
            try
            {
                dataGridViewPriorities.Rows.Clear();
            }
            catch
            {
                // ignored
            }
            _isGeneralRecipeActive = true;
            labelNotificationGeneral.Text = "";
            labelNotificationPriorities.Text = "";
            labelNotificationGeneral.Visible = false;
            labelNotificationPriorities.Visible = false;
        }


        //Проверяем что в рецепте все правильно заполено
        private bool CheckRecipe()
        {
            if (textBoxRecipeName.Text == string.Empty)
            {
               // MessageBox.Show("Укажите название рецепта.", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1, (MessageBoxOptions)0x40000);
                ShowNotification("Укажите название рецепта.");
                return false;
            }
            if (textBoxWeight.Text == string.Empty)
            {
               // MessageBox.Show("Введите требуемый вес продукта.", "Внимание", MessageBoxButtons.OK,
              //      MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1, (MessageBoxOptions)0x40000);
                ShowNotification("Введите требуемый вес продукта.");
                return false;
            }
            if (textBoxWeight.Text.Trim() == "0")
            {
               // MessageBox.Show("Требуемый вес продукта равен 0.", "Внимание", MessageBoxButtons.OK,
              //      MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1, (MessageBoxOptions)0x40000);
                ShowNotification("Требуемый вес продукта равен 0.");
                return false;
            }
            if (Math.Round(CountPercentSum(), _tolerance) != 100)
            {
             //   MessageBox.Show("Сумма процентов не равна 100.\nПроверьте правильность рецепта.", "Внимание",
              //      MessageBoxButtons.OK, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1, (MessageBoxOptions)0x40000);
                ShowNotification("Сумма процентов не равна 100.\nПроверьте правильность рецепта.");
                return false;
            }
            if (textBoxQuality.Text == string.Empty)
            {
              //  MessageBox.Show("Не указано качество.", "Внимание",
              //      MessageBoxButtons.OK, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1, (MessageBoxOptions)0x40000);
                ShowNotification("Не указано качество.");
                return false;
            }
            if (textBoxWeightKK.Text == string.Empty)
            {
             //   MessageBox.Show(@"Не указано задание на К/К.", "Внимание",
              //      MessageBoxButtons.OK, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1, (MessageBoxOptions)0x40000);
                ShowNotification(@"Не указано задание на К/К.");
                return false;
            }
            //Проверяем правильность
            foreach (DataGridViewRow r in dataGridViewIngredients.Rows)
            {
                if (r.IsNewRow)
                    continue;
                if (r.Cells[1].Value == null && r.Cells[2].Value != null)
                {
                  /*  MessageBox.Show(
                        "Не указано наименование ингредиента в строке " + (r.Index + 1) +
                        ".\nПроверьте правильность рецепта.", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1, (MessageBoxOptions)0x40000);*/
                    ShowNotification("Не указано наименование ингредиента в строке " + (r.Index + 1) +
                        ".\nПроверьте правильность рецепта.");
                    return false;
                }
                if (r.Cells[1].Value != null && r.Cells[2].Value == null)
                {
                /*    MessageBox.Show(
                        "Не указано процентное содержание ингредиента в строке " + (r.Index + 1) +
                        ".\nПроверьте правильность рецепта.", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1, (MessageBoxOptions)0x40000);*/
                    ShowNotification("Не указано процентное содержание ингредиента в строке " + (r.Index + 1) +
                        ".\nПроверьте правильность рецепта.");
                    return false;
                }
            }
            var lst = new List<string>();
            for (var i = 0; i < dataGridViewIngredients.Rows.Count; i++)
            {
                if (dataGridViewIngredients.Rows[i].IsNewRow)
                    continue;
                lst.Add(dataGridViewIngredients.Rows[i].Cells[1].Value.ToString());
            }
            if (lst.GroupBy(n => n).Any(c => c.Count() > 1))
            {
            /*    MessageBox.Show("Есть повторяющиеся ингредиенты.\nПроверьте правильность рецепта.", "Внимание",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1, (MessageBoxOptions)0x40000);*/
                ShowNotification("Есть повторяющиеся ингредиенты.\nПроверьте правильность рецепта.");
                return false;
            }
            return true;
        }

        //Проверяем правильность заполнения таблицы с приоритетами и бункерами
        private bool CheckPriorities()
        {
            foreach (DataGridViewRow r in dataGridViewPriorities.Rows)
            {
                if (r.IsNewRow)
                    continue;
                if (r.Cells[2].Value == null)
                {
                   /* MessageBox.Show(
                        "Не указан бункер в строке " + (r.Index + 1), "Внимание", MessageBoxButtons.OK,
                        MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1, (MessageBoxOptions)0x40000);*/
                    ShowNotification("Не указан бункер в строке " + (r.Index + 1));
                    return false;
                }
            }
            var lst = new List<string>();
            for (var i = 0; i < dataGridViewPriorities.Rows.Count; i++)
            {
                if (dataGridViewPriorities.Rows[i].IsNewRow)
                    continue;
                lst.Add(dataGridViewPriorities.Rows[i].Cells[2].Value.ToString());
            }
            if (lst.GroupBy(n => n).Any(c => c.Count() > 1))
            {
               /* MessageBox.Show("Есть повторяющиеся бункеры.", "Внимание",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1, (MessageBoxOptions)0x40000);*/
                ShowNotification("Есть повторяющиеся бункеры.");
                return false;
            }
            //Нельзя дозировать жидкие добавки не последними
            if (lst.IndexOf("7") != -1 && (lst.IndexOf("7") + 1) != dataGridViewPriorities.RowCount)
            {
                 /*  MessageBox.Show("Масло (бункер 7) обязательно должно иметь последний приоритет в дозировании.", "Внимание",
                       MessageBoxButtons.OK, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1,
                       (MessageBoxOptions) 0x40000);*/
                ShowNotification("Масло (бункер 7) обязательно должно иметь последний приоритет в дозировании.");
                return false;
            }
            if (lst.IndexOf("8") != -1 && (lst.IndexOf("8") + 1) != dataGridViewPriorities.RowCount)
            {
                /* MessageBox.Show("Масло (бункер 8) обязательно должно иметь последний приоритет в дозировании.", "Внимание",
                     MessageBoxButtons.OK, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1,
                     (MessageBoxOptions)0x40000);*/
                ShowNotification("Масло (бункер 8) обязательно должно иметь последний приоритет в дозировании.");
                return false;
            }
            return true;
        }

        private void buttonCancelPriority_Click(object sender, EventArgs e)
        {
            Dispose();
        }

        private void buttonBackToIngr_Click(object sender, EventArgs e)
        {
            HidePriorities();
        }

        private void dataGridViewPriorities_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            var validRow = (e.RowIndex != -1); //Make sure the clicked row isn't the header.

            // Check to make sure the cell clicked is the cell containing the combobox 
            if (dataGridViewPriorities.Columns[e.ColumnIndex].Index == 2 && validRow)
            {
                dataGridViewPriorities.BeginEdit(true);
                ((ComboBox) dataGridViewPriorities.EditingControl).DroppedDown = true;
            }
        }

        //Сдвиг приоритета вверх
        private void buttonUp_Click(object sender, EventArgs e)
        {
            if (dataGridViewPriorities.SelectedRows.Count == 0)
                return;
            var index = dataGridViewPriorities.SelectedRows[0].Index;
            var name = dataGridViewPriorities.SelectedRows[0].Cells[1].Value.ToString();
            SwapRows(index, index - 1);
            SetPriorities();
            SelectRow(name);
        }

        //Сдвиг приоритета вниз
        private void buttonDown_Click(object sender, EventArgs e)
        {
            if (dataGridViewPriorities.SelectedRows.Count == 0)
                return;
            var index = dataGridViewPriorities.SelectedRows[0].Index;
            var name = dataGridViewPriorities.SelectedRows[0].Cells[1].Value.ToString();
            SwapRows(index + 1, index);
            SetPriorities();
            SelectRow(name);
        }

        //Замена строк в таблице при смене приоритетов
        private void SwapRows(int selected, int old)
        {
            var oldRow = dataGridViewPriorities.Rows[old];
            var newRow = dataGridViewPriorities.Rows[selected];
            dataGridViewPriorities.Rows.Remove(newRow);
            dataGridViewPriorities.Rows.Remove(oldRow);
            dataGridViewPriorities.Rows.Insert(old, newRow);
            dataGridViewPriorities.Rows.Insert(selected, oldRow);
        }

        //Выбираем какой ингредиент выбрать
        private void SelectRow(string name)
        {
            //Не работает !!!
            foreach (DataGridViewRow r in dataGridViewPriorities.Rows)
            {
                if (r.Cells[1].Value.ToString().Trim().Equals(name))
                {
                    r.Selected = true;
                    return;
                }
                r.Selected = false;
            }
        }

        private void dataGridViewPriorities_SelectionChanged(object sender, EventArgs e)
        {
            if (dataGridViewPriorities.SelectedRows.Count == 0)
            {
                buttonUp.Enabled = false;
                buttonDown.Enabled = false;
                return;
            }
            if (dataGridViewPriorities.SelectedRows[0].Index == 0)
            {
                buttonUp.Enabled = false;
            }
            else
            {
                buttonUp.Enabled = true;
            }
            if (dataGridViewPriorities.SelectedRows[0].Index == dataGridViewPriorities.Rows.Count - 1)
            {
                buttonDown.Enabled = false;
            }
            else
            {
                buttonDown.Enabled = true;
            }
        }

        //Добавление рецепта с приоритетами и бункерами
        private void buttonAddPriority_Click(object sender, EventArgs e)
        {
            if (!CheckRecipe())
                return;
            if (!CheckPriorities())
                return;
            int id;
            try
            {
                id = SaveRecipe();
                if(id==0)
                    throw new Exception();
                var ingredients = PushIngredientsToList(id, true);
                foreach (var i in ingredients)
                    i.SaveToDb();
            }
            catch
            {
             //   MessageBox.Show("Не удалось сохранить рецепт", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1, (MessageBoxOptions)0x40000);
                ShowNotification("Не удалось сохранить рецепт");
                return;
            }
            Hide();
            MessageBox.Show("Добавлен новый рецепт номер: " + id, "Инфо", MessageBoxButtons.OK,
                MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, (MessageBoxOptions)0x40000);
            if (NewRecipeAdded != null) NewRecipeAdded(this, new EventArgs());
            Dispose();
        }

        private void buttonAddIngredient_Click(object sender, EventArgs e)
        {
            if(_fai != null)
                _fai.Dispose();
            _fai = new FastAddIngredient();
            _fai.IngredientAdded += _fai_IngredientAdded;
            _fai.Disposed += _fai_Disposed;
            _fai.Show();
        }

        void _fai_Disposed(object sender, EventArgs e)
        {
            if (_fai == null) return;
            _fai.IngredientAdded -= _fai_IngredientAdded;
            _fai.Disposed -= _fai_Disposed;
        }

        //Добавлен новый ингредиент, надо обновить комбобоксы
        void _fai_IngredientAdded(object sender, AddIngredientEventArgs e)
        {
            foreach (DataGridViewRow r in dataGridViewIngredients.Rows)
            {
                ((DataGridViewComboBoxCell)r.Cells[1]).Items.Add(e.Name);
                ((DataGridViewComboBoxCell)r.Cells[1]).Sorted = true;
            }
            if (_fai == null) return;
            _fai.IngredientAdded -= _fai_IngredientAdded;
            _fai.Disposed -= _fai_Disposed;
        }

        //Заполняем текст с именем, качеством
        private void FillBoxes(string parsedStr)
        {
            if (parsedStr.Contains("%"))
            {
                int index = parsedStr.IndexOf("%") + 1;
                textBoxComment.Text = "Концентрат: " + parsedStr.Substring(0, index).Replace("РЕЦЕПТ", "").Trim();
            }

            int startNum = parsedStr.IndexOf("№");
            string qual = parsedStr.Substring(startNum);
            qual = Regex.Replace(qual, "[^0-9]", String.Empty);
            textBoxQuality.Text = qual;

            int start = parsedStr.IndexOf("КОНЦЕНТРАТА") + 13;
            string name = parsedStr.Substring(start);
            int stop = name.IndexOf(" ");
            name = name.Substring(0, stop);
            textBoxRecipeName.Text = name;
        }
        //Для расчета через проценты или четкого указания веса
        private void checkBoxCountWeight_CheckedChanged(object sender, EventArgs e)
        {
            bool state = checkBoxCountWeight.Checked;
            textBoxWeight.Enabled = !state;
            flowLayoutPanelCountWeight.Enabled = state;
            if (!state)
            {
                textBoxProcentsToCount.Clear();
                textBoxWeightToCount.Clear();
            }
            else
            {
                textBoxProcentsToCount.Text = "0.000";
                textBoxWeightToCount.Text = "0";
            }
        }

        private void textBoxWeightToCount_TextChanged(object sender, EventArgs e)
        {
            textBoxWeightToCount.Text = Regex.Replace(textBoxWeightToCount.Text, "[^0-9]", string.Empty);
            CountMassTotal();
        }
        //Умножаем массу при расчете через проценты
        private void CountMassTotal()
        {
            if (textBoxWeightToCount.Text == string.Empty || textBoxProcentsToCount.Text == string.Empty)
            {
                textBoxWeight.Text = "";
                return;
            }
            int totalMass = Convert.ToInt32(textBoxWeightToCount.Text);
            double procents = Convert.ToDouble(textBoxProcentsToCount.Text);
            if (procents > 100)
            {
                procents = 100;
                textBoxProcentsToCount.Text = "100";
            }
            string result = Math.Round(totalMass*procents/100).ToString();
            textBoxWeight.Text = result;
        }

        private void textBoxProcentsToCount_Validated(object sender, EventArgs e)
        {
            textBoxProcentsToCount.Text = textBoxProcentsToCount.Text.Replace(",", ".");
            textBoxProcentsToCount.Text = Regex.Replace(textBoxProcentsToCount.Text, "[a-zA-Z]+$", string.Empty);
            string text = textBoxProcentsToCount.Text;
            if (text == string.Empty)
            {
                textBoxProcentsToCount.Text = "0.000";
                CountMassTotal();
            }
            Match m = Regex.Match(text, @"[0-9]*\.?[0-9]+");
            if (m.Groups.Count != 0 && m.Captures.Count != 0)
            {
                string res = m.Groups[0].Captures[0].ToString();
                double d = 0;
                if (double.TryParse(res, out d))
                {
                    textBoxProcentsToCount.Text = d.ToString("F3");
                    CountMassTotal();
                }
            }
        }

        private void textBoxProcentsToCount_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                textBoxWeightToCount.Focus();
            }
        }
        //Нотификации об ошибках
        private void ShowNotification(string text)
        {
            if (_tm != null)
            {
                if (_tm.Enabled)
                {
                    HideNotification(this, new EventArgs());
                }
            }
            _tm = new Timer() { Interval = 5000 };
            _tm.Tick += HideNotification;
            if (_isGeneralRecipeActive)
            {
                labelNotificationGeneral.Text = text;
                labelNotificationGeneral.Visible = true;
            }
            else
            {
                labelNotificationPriorities.Text = text;
                labelNotificationPriorities.Visible = true;
            }
            _tm.Start();

        }

        void HideNotification(object sender, EventArgs e)
        {
            if (_isGeneralRecipeActive)
            {
                labelNotificationGeneral.Text = "";
                labelNotificationGeneral.Visible = false;
            }
            else
            {
                labelNotificationPriorities.Text = "";
                labelNotificationPriorities.Visible = false;
            }
          _tm.Stop();
        }
    }
}