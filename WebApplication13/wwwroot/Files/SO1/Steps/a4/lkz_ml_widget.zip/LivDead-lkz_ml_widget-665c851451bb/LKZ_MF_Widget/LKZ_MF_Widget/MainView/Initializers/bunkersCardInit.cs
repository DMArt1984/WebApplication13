﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace LKZ_MF_Widget.MainView
{
    public partial class MainView
    {
        private void BunkersCardInit()
        {
            groupBoxBunkerComment.Visible = false;
            buttonBunkerChangeComment.Click += buttonBunkerChangeComment_Clicked;
            buttonBunkerCancel.Click += buttonBunkerCancel_Clicked;
            buttonBunkChangeCommOk.Click += buttonBunkChangeCommOk_Clicked;
            InitDgvBunker(dataGridViewBunkersW2);
            dataGridViewBunkersW2.CellFormatting += dgvBunkersColoring_CellFormatting;
            InitDgvBunker(dataGridViewBunkersW4);
            dataGridViewBunkersW4.CellFormatting += dgvBunkersColoring_CellFormatting;
            InitDgvBunker(dataGridViewBunkersW5);
            dataGridViewBunkersW5.CellFormatting += dgvBunkersColoring_CellFormatting;
            InitDgvBunker(dataGridViewBunkersW6);
            dataGridViewBunkersW6.CellFormatting += dgvBunkersColoring_CellFormatting;

        }

        //Инициализация таблицы с бункерами
        private void InitDgvBunker(DataGridView dgv)
        {
            ClearDgv(dgv);
            for (var i = 0; i < 4; i++)
            {
                var column = new DataGridViewTextBoxColumn();
                dgv.Columns.Add(column);
            }

            dgv.Columns[0].DataPropertyName = "bunkNum";
            dgv.Columns[0].Name = "№";
            dgv.Columns[0].HeaderText = "№";
            dgv.Columns[0].Width = 40;

            dgv.Columns[1].DataPropertyName = "ingredient";
            dgv.Columns[1].Name = "Ингредиент";
            dgv.Columns[1].HeaderText = "Ингредиент";

            dgv.Columns[2].DataPropertyName = "task";
            dgv.Columns[2].Name = "task";
            dgv.Columns[2].HeaderText = "Расход, кг.";
            dgv.Columns[2].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgv.Columns[2].DefaultCellStyle.Format = "N3";
            dgv.Columns[2].Width = 60;


            dgv.Columns[3].DataPropertyName = "isInUse";
            dgv.Columns[3].Name = "isInUse";
            dgv.Columns[3].HeaderText = "isInUse";
            dgv.Columns[3].Visible = false;

            /*    dgv.Columns[2].DataPropertyName = "comment";
            dgv.Columns[2].Name = "Комменатрий";
            dgv.Columns[2].HeaderText = "Комменатрий";

            dgv.Columns[3].DataPropertyName = "timeUpdate";
            dgv.Columns[3].Name = "Дата изменения";
            dgv.Columns[3].HeaderText = "Дата изменения";*/
        }

        private void buttonBunkChangeCommOk_Clicked(object sender, EventArgs e)
        {
            flowLayoutPanelBunkerChange.Enabled = true;
            groupBoxBunkerComment.Visible = false;
        }

        private void buttonBunkerCancel_Clicked(object sender, EventArgs e)
        {
            flowLayoutPanelBunkerChange.Enabled = true;
            groupBoxBunkerComment.Visible = false;
        }

        private void buttonBunkerChangeComment_Clicked(object sender, EventArgs e)
        {
            textBoxBunkerComment.Clear();
            flowLayoutPanelBunkerChange.Enabled = false;
            groupBoxBunkerComment.Visible = true;
        }
    }
}