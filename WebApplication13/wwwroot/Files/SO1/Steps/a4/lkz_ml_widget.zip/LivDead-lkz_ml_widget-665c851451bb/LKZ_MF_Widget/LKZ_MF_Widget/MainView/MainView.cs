﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using LKZ_MF_Widget.DBClasses;
using LKZ_MF_Widget.Reports;
using LKZ_MF_Widget.ScadaDataExchanger;
using LKZ_MF_Widget.Settings;
using LKZ_MF_Widget.VPWeights;

namespace LKZ_MF_Widget.MainView
{
    [ProgId("LKZ_MF_Widget")]
    [ComVisible(true)]
    [ClassInterface(ClassInterfaceType.None)]
    public partial class MainView : UserControl
    {
        [ComVisible(true)] private ConnectionLost _connLost; //Окно с ошибкой потери связи  
        
        //----------------------------------------------------------------
        //Переменные для отладки
        //
        private readonly bool _debug = false;   //режим отладки с дополнительными окнами и кнопками, переносы и пропуски обрабатываются без связи со СКАДА
       // private readonly Timer _batchGenerator = new Timer(){Interval = 500};

        private readonly List<int> _availableBunkers = new List<int>{7,8,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,71,
            72,160,161,162,163,165,166,170,171,172,175,178,185,186,188,189
        }; 
        //
        //----------------------------------------------------------------
        private Timer _currentRecipesUpdateTimer; //Таймер для обновления текущих показаний
        private NewRequest.NewRequest _nr; //Окно с новой заявкой
        private SelectRecipeToClose.SelectRecipeToClose _srtc; //Окно с выбором какой рецепт закрыть
        private SetBunkersAtStart.SetBunkersAtStart _st; //Окно с заданием бункеров перед стартом заявки
        private RecipeDetails.RecipeDetails _details; //Окно с деталями рецепта
        private BunkerSkip.BunkerSkip _bskip; //Окно для пропуска бункера
        private BunkerSwap.BunkerSwap _bswap; //Окно для замены бункеров
     //   private int _tolerance = 3; //Округление до знаков    
        private static Dictionary<string, string> _skippedBunkers; //Список пропущенных бункеров
        private static KeyValuePair<string, string> _swappedBunkers; //Список перенесенных бункеров

        // Сигналы о запуске рцептов на линиях 
        [Browsable(true)]
        public event EventHandler NewRecipeStartedPd1W6;
        [Browsable(true)]
        public event EventHandler NewRecipeStartedOd1W2;
        [Browsable(true)]
        public event EventHandler NewRecipeStartedPd2W5;
        [Browsable(true)]
        public event EventHandler NewRecipeStartedOd2W4;
        //Сигналы требования закрытия заявки
        [Browsable(true)]
        public event EventHandler RecipeClosePd1;
        [Browsable(true)]
        public event EventHandler RecipeCloseOd1;
        [Browsable(true)]
        public event EventHandler RecipeClosePd2;
        [Browsable(true)]
        public event EventHandler RecipeCloseOd2;
        //Сигналы о пропуске бункеров
        [Browsable(true)]
        public event EventHandler BunkerSkippedPd1;
        [Browsable(true)]         
        public event EventHandler BunkerSkippedOd1;
        [Browsable(true)]         
        public event EventHandler BunkerSkippedPd2;
        [Browsable(true)]         
        public event EventHandler BunkerSkippedOd2;
        //Сигналы о переносе бункеров
        [Browsable(true)]
        public event EventHandler BunkerSwappedPd1;
        [Browsable(true)]             
        public event EventHandler BunkerSwappedOd1;
        [Browsable(true)]            
        public event EventHandler BunkerSwappedPd2;
        [Browsable(true)]               
        public event EventHandler BunkerSwappedOd2;
        public MainView()
        {
            InitializeComponent();

            DbConnect.GetDbInstance(); //Инициализируем подключение к базе
            //Обработка подключения и потери связи
            DbConnect.ConnectionLost += ShowConnLost;
            DbConnect.ConnectionEstablished += HideConnLost;
            if (!DbConnect.IsOnline())
            {
                ShowConnLost(this, new EventArgs());
                return;
            }
                //Инициализация GUI
                InitGui();
            //Отладочный таймер для генерации случайных отвесов
           /* if (_debug)
            {
                _batchGenerator.Start();
                _batchGenerator.Tick += RandomBatchGeneration;
            }*/
        }
        //Плодим рандомные отвесы для отладки
      /*  private void RandomBatchGeneration(object obj, EventArgs args)
        {
            Stopwatch sw = new Stopwatch();
            sw.Start();
            Random rnd = new Random(DateTime.Now.Millisecond);
            PushDosedData pdd = new PushDosedData();
            pdd.PushDataBatch(178,500.0f,505.0f,2);
            return;
          //  for (int i = 0; i < 500000; i++)
           // {
                double nextDouble = rnd.NextDouble();
                float planned = (float) (rnd.Next(1000)*nextDouble);
                float dosed = planned;
                if (nextDouble > 0.5)
                {
                    dosed -= (float) (planned*nextDouble);
                }
                else
                {
                    dosed += (float) (planned*nextDouble);

                }
                pdd.PushDataBatch(_availableBunkers[rnd.Next(0, _availableBunkers.Count - 1)],planned,dosed,rnd.Next(50));
                var query =
                    "insert into dbo.recipe_batch (id_ingredient, weight, weightFact, bunker, batchNum, name) values (" +
                    rnd.Next(5,500) + "," + planned + "," + dosed + "," + _availableBunkers[rnd.Next(0, _availableBunkers.Count - 1)] +
                    "," + rnd.Next(50) + ",N'Много отвесов')";
            Vp150 vp150 = new Vp150();
            Vp501 vp501 = new  Vp501();
            Vp502 vp502 = new Vp502();
            Vp503 vp503 = new Vp503();
            int i = rnd.Next(100);
                DbConnect.GetDbInstance().PerformQuery(query);
                vp150.AddInfo("фяфя",planned,dosed,i,i,dosed,dosed,"az","za");
                vp501.AddInfo("azaz",planned,i,dosed);
                vp502.AddInfo("azaz", planned, i, dosed);
                vp503.AddInfo("azaz", planned, i,dosed,"-");
             //}
            //_batchGenerator.Stop();
            sw.Stop();
           // MessageBox.Show("Added 500k batches, time taken: " + sw.Elapsed.ToString(@"hh\:mm\:ss"));
        }*/

        //Инициализация интерфейса
        private void InitGui()
        {
            NewRecipeStartedOd1W2 += MainView_NewRecipeStarted_OD1_W2;
            NewRecipeStartedOd2W4 += MainView_NewRecipeStarted_OD2_W4;
            NewRecipeStartedPd1W6 += MainView_NewRecipeStarted_PD1_W6;
            NewRecipeStartedPd2W5 += MainView_NewRecipeStarted_PD2_W5;

            RecipeCloseOd1 += MainView_RecipeClose_OD1;
            RecipeCloseOd2 += MainView_RecipeClose_OD2;
            RecipeClosePd1 += MainView_RecipeClose_PD1;
            RecipeClosePd2 += MainView_RecipeClose_PD2;

            BunkerSkippedOd1 += MainView_BunkerSkippedOd1;
            BunkerSkippedOd2 += MainView_BunkerSkippedOd2;
            BunkerSkippedPd1 += MainView_BunkerSkippedPd1;
            BunkerSkippedPd2 += MainView_BunkerSkippedPd2;

            BunkerSwappedOd1 += MainView_BunkerSwappedOd1;
            BunkerSwappedOd2 += MainView_BunkerSwappedOd2;
            BunkerSwappedPd1 += MainView_BunkerSwappedPd1;
            BunkerSwappedPd2 += MainView_BunkerSwappedPd2;

            buttonRecipeCloseOper.Click += buttonCloseCurrent_Click;

            //Таймер на проверку обновлений в рецептах
            _currentRecipesUpdateTimer = new Timer { Interval = 5000 };
            _currentRecipesUpdateTimer.Tick += currentRecipesUpdateTimer_Tick;

            //Событие обновления для весов          
            ExternalUpdater.ExternalUpdater.VpUpdateRequired += externalUpdater_VPUpdateRequired;
            //Событие для обновления при закрытии рецепта
            ExternalUpdater.ExternalUpdater.RecipeUpdateRequired += ExternalUpdater_RecipeUpdateRequired;
            //Для отображния окон поверх всего
            ExternalUpdater.ExternalUpdater.MessageBoxRequired += ExternalUpdater_MessageBoxRequired;


            CurrentRecipeInit();
            BunkersCardInit();
            IngredientsInit();
            VpInit();
            ReportInit();
            UpdateBunkerCards();
            UpdateCurrentRecipes();
            _currentRecipesUpdateTimer.Enabled = true;

            //Кнопки в отладочный режим или наоборот
            groupBoxRecipeControl.Visible = _debug;
            buttonStartRecipe.Visible = !_debug;
        }

        //Отображение MessageBox если нужно
        private void ExternalUpdater_MessageBoxRequired(object sender, MessageBoxEventArgs e)
        {
            MessageBox.Show(new Form(){TopMost = true},e.MessageText, e.HeaderText, MessageBoxButtons.OK, e.Icon,
                MessageBoxDefaultButton.Button1, (MessageBoxOptions) 0x40000);
        }
        
        

        void MainView_BunkerSwappedPd2(object sender, EventArgs e)
        {
            if (_debug)
            {
                MessageBox.Show("Замена бункеров на ПД2\nБункер " + _swappedBunkers.Key + " на " + _swappedBunkers.Value);
            }
        }

        void MainView_BunkerSwappedPd1(object sender, EventArgs e)
        {
            if (_debug)
            {
                MessageBox.Show("Замена бункеров на ПД1\nБункер " + _swappedBunkers.Key + " на " + _swappedBunkers.Value);
            }
        }

        void MainView_BunkerSwappedOd2(object sender, EventArgs e)
        {
            if (_debug)
            {
                MessageBox.Show("Замена бункеров на ОД2\nБункер " + _swappedBunkers.Key + " на " + _swappedBunkers.Value);
            }
        }

        void MainView_BunkerSwappedOd1(object sender, EventArgs e)
        {
            if (_debug)
            {
                MessageBox.Show("Замена бункеров на ОД1\nБункер " + _swappedBunkers.Key + " на " + _swappedBunkers.Value);
            }
        }

        void MainView_BunkerSkippedPd2(object sender, EventArgs e)
        {
            ;
        }

        void MainView_BunkerSkippedPd1(object sender, EventArgs e)
        {
            ;
        }

        void MainView_BunkerSkippedOd2(object sender, EventArgs e)
        {
            ;
        }

        void MainView_BunkerSkippedOd1(object sender, EventArgs e)
        {
            ;
        }

        void MainView_RecipeClose_PD2(object sender, EventArgs e)
        {
            if (_debug)
                MessageBox.Show("Оператор закрывает рецепт на ПД2");
        }

        void MainView_RecipeClose_PD1(object sender, EventArgs e)
        {
            if (_debug)
                MessageBox.Show("Оператор закрывает рецепт на ПД1");
        }

        void MainView_RecipeClose_OD2(object sender, EventArgs e)
        {
            if (_debug)
                MessageBox.Show("Оператор закрывает рецепт на ОД2");
        }

        void MainView_RecipeClose_OD1(object sender, EventArgs e)
        {
            if (_debug)
                MessageBox.Show("Оператор закрывает рецепт на ОД1");
        }

        private void ExternalUpdater_RecipeUpdateRequired(object sender, EventArgs e)
        {
            UpdateCurrentRecipes();
        }

        private void MainView_NewRecipeStarted_PD2_W5(object sender, EventArgs e)
        {
            if (_debug)
                MessageBox.Show("Запуск рецепта на ПД2  весы 5");
        }

        private void MainView_NewRecipeStarted_PD1_W6(object sender, EventArgs e)
        {
            if (_debug)
                MessageBox.Show("Запуск рецепта на ПД1  весы 6");
        }

        private void MainView_NewRecipeStarted_OD2_W4(object sender, EventArgs e)
        {
            if (_debug)
                MessageBox.Show("Запуск рецепта на ОД2  весы 4");
        }

        private void MainView_NewRecipeStarted_OD1_W2(object sender, EventArgs e)
        {
            if (_debug)
                MessageBox.Show("Запуск рецепта на ОД1  весы 2");
        }

        private void externalUpdater_VPUpdateRequired(object sender, EventArgs e)
        {
            UpdateVpView();
        }

        private void vp150_Vp150RecordAdded(object sender, EventArgs e)
        {
            UpdateVp150();
        }

        private void vp503_Vp503RecordAdded(object sender, EventArgs e)
        {
            UpdateVp503();
        }

        private void vp502_Vp502RecordAdded(object sender, EventArgs e)
        {
            UpdateVp502();
        }

        private void vp501_Vp501RecordAdded(object sender, EventArgs e)
        {
            UpdateVp501();
        }

        //Обработка сигнала о начале нового рецепта
        private void MainView_NewRecipeStarted(object sender, EventArgs e)
        {
            if (_debug)
                MessageBox.Show("NewRecipeStarted");
        }

        //Обновление текущих рецептов по таймеру
        private void currentRecipesUpdateTimer_Tick(object sender, EventArgs e)
        {
            if (DbConnect.IsOnline())
                UpdateCurrentRecipes();
        }

        //Убираем окно с ошибкой, если соединение установлено
        private void HideConnLost(object sender, EventArgs e)
        {

            if (_connLost != null)
            {
                if(DBClasses.DbConnect.IsOnline())
                    _connLost.SaveSettings();
                _connLost.Dispose();
            }
            DisableControls(false);
            InitGui();
            /*
           // InitDgvCurrentRecipes();
            //Инициализация GUI
            CurrentRecipeInit();
            BunkersCardInit();
            IngredientsInit();
            VpInit();
            ReportInit();
            UpdateBunkerCards();
            UpdateCurrentRecipes();*/
        }

        //Метод для отображения ошибки подключения
        private void ShowConnLost(object sender, EventArgs e)
        {
            DisableControls();
            if (_connLost != null)
                _connLost.Dispose();
            _connLost = new ConnectionLost();
            _connLost.Show();
        }

        //Отключение элементов управления при потере связи с базой
        private void DisableControls(bool state = true)
        {
          //  Enabled = !state;
            if (_currentRecipesUpdateTimer != null)
                _currentRecipesUpdateTimer.Enabled = false;
            tabControlIngredients.Enabled = !state;
        }

        private void tabPageIngredients_Enter(object sender, EventArgs e)
        {
            UpdateIngredientsView();
        }

        private void tabPageBunkersCard_Enter(object sender, EventArgs e)
        {
            UpdateBunkerCards();
        }

        private void radioButtonCurrentById_CheckedChanged(object sender, EventArgs e)
        {
            textBoxCurrentId.Enabled = radioButtonCurrentById.Checked;
            UpdateCurrentRecipes();
        }

        //Оставляем тольео цифры в поле id
        private void textBoxCurrentId_TextChanged(object sender, EventArgs e)
        {
            textBoxCurrentId.Text = Regex.Replace(textBoxCurrentId.Text, "[^0-9]", string.Empty);
            UpdateCurrentRecipes();
        }

        private void radioButtonCurrentAllTime_CheckedChanged(object sender, EventArgs e)
        {
            UpdateCurrentRecipes();
        }

        private void radioButtonCurrentYear_CheckedChanged(object sender, EventArgs e)
        {
            UpdateCurrentRecipes();
        }

        private void radioButtonCurrentMonth_CheckedChanged(object sender, EventArgs e)
        {
            UpdateCurrentRecipes();
        }

        private void radioButtonCurrentWeek_CheckedChanged(object sender, EventArgs e)
        {
            UpdateCurrentRecipes();
        }

        private void tabPageRecipe_Enter(object sender, EventArgs e)
        {
            UpdateCurrentRecipes();
        }

        private void dataGridViewCurrentRecipes_SelectionChanged(object sender, EventArgs e)
        {
            if (dataGridViewCurrentRecipes.SelectedRows.Count == 1 &&
                (dataGridViewCurrentRecipes.SelectedRows[0].Cells[4].Value.ToString() == "True"
                 || dataGridViewCurrentRecipes.SelectedRows[0].Cells[6].Value.ToString() == "True"))
            {
                buttonPrintRepMainView.Enabled = true;
            }
            else
            {
                buttonPrintRepMainView.Enabled = false;
            }
            if (dataGridViewCurrentRecipes.SelectedRows.Count == 0)
            {
                while (dataGridViewRecipe.Rows.Count != 0)
                {
                    foreach (DataGridViewRow r in dataGridViewRecipe.Rows)
                    {
                        dataGridViewRecipe.Rows.Remove(r);
                    }
                }
                SetConsumptionCountMode(false);
                return;
            }
            if (dataGridViewCurrentRecipes.SelectedRows.Count > 1)
            {
                SetConsumptionCountMode(true);
            }
            else
            {
                SetConsumptionCountMode(false);
                UpdateRecipe();
            }
        }

        //Переключаемся к промотру расхода
        private void SetConsumptionCountMode(bool modeEnabled)
        {
            if (modeEnabled)
            {
                labelOneRecipe.Text = "Расход материала";
                InitDgvConsumption();
                groupBoxConsumption.Visible = true;
                UpdateConsumption();
            }
            else
            {
                labelOneRecipe.Text = "Состав";
                InitDgvRecipe();
                groupBoxConsumption.Visible = false;
                UpdateRecipe();
            }
        }

        //Удаление рецепта
        private void buttonDeleteRecipe_Click(object sender, EventArgs e)
        {
            if (dataGridViewCurrentRecipes.SelectedRows.Count != 1)
            {
                MessageBox.Show("Выберите один рецепт для удаления", "Внимание", MessageBoxButtons.OK,
                    MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1, (MessageBoxOptions)0x40000);
                dataGridViewCurrentRecipes.ClearSelection();
                return;
            }
            var id = Convert.ToInt32(dataGridViewCurrentRecipes.SelectedRows[0].Cells[0].Value);
            if (CheckEditAvailable(id))
            {
                var dr = MessageBox.Show("Вы действительно хотите удалить рецепт № " + id, "Внимание",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1, (MessageBoxOptions)0x40000);
                if (dr == DialogResult.No)
                {
                    return;
                }
                var query = "delete from dbo.recipe where id = " + id;
                DbConnect.GetDbInstance().PerformNonQuery(query);
                MessageBox.Show("Рецепт " + id + " удален", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, (MessageBoxOptions)0x40000);
                UpdateCurrentRecipes();
            }
            else
            {
                MessageBox.Show("Рецепт № " + id + " уже был пущен в работу и его нельзя удалить", "Внимание",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1, (MessageBoxOptions)0x40000);
            }
        }

        //Проверка можно ли удалять рецепт
        private bool CheckEditAvailable(int id)
        {
            var query = "select isFinished, isInProgress, isFinishedErr from dbo.recipe where id = " + id;
            var dt = DbConnect.GetDbInstance().PerformQuery(query);
            if (dt.Rows.Count != 1)
            {
                MessageBox.Show("Ошибка при проверке рецепта", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1, (MessageBoxOptions)0x40000);
            }
            if (dt.Rows[0]["isFinished"].ToString() == "True")
                return false;
            if (dt.Rows[0]["isInProgress"].ToString() == "True")
                return false;
            if (dt.Rows[0]["isFinishedErr"].ToString() == "True")
                return false;
            return true;
        }

        //Запуск рецепта в работу
        private void buttonGoToWork_Click(object sender, EventArgs e)
        {
            StartRecipe();
        }
        //Запуск рецепта
        private void StartRecipe()
        {
            if (dataGridViewCurrentRecipes.SelectedRows.Count == 0)
            {
                MessageBox.Show("Не выбран рецепт для запуска", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1, (MessageBoxOptions)0x40000);
                return;
            }
            if (dataGridViewCurrentRecipes.SelectedRows.Count > 1)
            {
                MessageBox.Show("Выбрано несколько рецептов.\nНельзя запустить больше одного рецепта одновременно.",
                    "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1, (MessageBoxOptions)0x40000);
                dataGridViewCurrentRecipes.ClearSelection();
                return;
            }
            var id = Convert.ToInt32(dataGridViewCurrentRecipes.SelectedRows[0].Cells[0].Value);
            //Проверяем что нет уже запущенных рецептов
            var recipeInProgress = CheckRecipesInProgress(id);
            if (recipeInProgress != 0)
            {
                MessageBox.Show(
                    "На линии " + GetLineNameById(recipeInProgress) + " уже запущен рецепт № " + recipeInProgress +
                    "\nДождитесь его завершения или завершите его вручную", "Внимание", MessageBoxButtons.OK,
                    MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1, (MessageBoxOptions)0x40000);
                return;
            }
            if (CheckEditAvailable(id))
            {
                if (CheckIfBunkersRequired(id))
                {
                    if (_st != null)
                    {
                        _st.RecipeStarted -= _st_RecipeStarted;
                        _st.Dispose();
                    }
                    _st = new SetBunkersAtStart.SetBunkersAtStart(id);
                    if (_st != null) _st.RecipeStarted += _st_RecipeStarted;
                    _st.Show();
                  /*  _st.Closing += (sender, args) =>
                    {
                        var findForm = FindForm();
                        if (findForm != null) findForm.Activate();
                       // SetTopLevel(true);
                     
                       BringToFront();
                    }; //Костыли чтобы не сворачилвалась форма при пуске рецепта
                    if (_st.ShowDialog() == DialogResult.OK)
                    {
                        SetRecipeInProgress(id);
                        EmitSignalRecipeStarted(id);
                    }*/
                }
                else
                {
                    SetRecipeInProgress(id);
                    EmitSignalRecipeStarted(id);
                }
                UpdateCurrentRecipes();
                UpdateBunkerCards();
            }
            else
            {
                MessageBox.Show("Рецепт № " + id + " недоступен для запуска в работу", "Внимание", MessageBoxButtons.OK,
                    MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1, (MessageBoxOptions)0x40000);
            }
        }

        //Запуск рецепта из окна выбора бункеров
        void _st_RecipeStarted(object sender, SetBunkersAtStart.RecipeStartEventArgs e)
        {
            SetRecipeInProgress(e.Id);
            EmitSignalRecipeStarted(e.Id);
            UpdateCurrentRecipes();
            UpdateBunkerCards();
            if (_st != null)
            {
                _st.RecipeStarted -= _st_RecipeStarted;
                _st.Dispose();  
            }
        }

        // Метод излучающий сигнал о запуске рецепта на определенном маршруте
        private void EmitSignalRecipeStarted(int id)
        {
            var query = "select place from dbo.recipe where id = " + id + " and isInProgress = 1";
            var dt = DbConnect.GetDbInstance().PerformQuery(query);
            if (dt.Rows.Count != 1)
            {
                MessageBox.Show("Ошибка при попытке запуска рецепта в работу", "Ошибка", MessageBoxButtons.OK,
                    MessageBoxIcon.Error, MessageBoxDefaultButton.Button1, (MessageBoxOptions)0x40000);
                return;
            }
            var place = dt.Rows[0]["place"].ToString().Trim();
            if (place.Equals("W2"))
            {
                if (NewRecipeStartedOd1W2 != null) NewRecipeStartedOd1W2(this, new EventArgs());
                return;
            }
            if (place.Equals("W4"))
            {
                if (NewRecipeStartedOd2W4 != null) NewRecipeStartedOd2W4(this, new EventArgs());
                return;
            }
            if (place.Equals("W6"))
            {
                if (NewRecipeStartedPd1W6 != null) NewRecipeStartedPd1W6(this, new EventArgs());
                return;
            }
            if (place.Equals("W5"))
            {
                if (NewRecipeStartedPd2W5 != null) NewRecipeStartedPd2W5(this, new EventArgs());
            }
        }

        //По заявке определяем на какой линии запущен рецепт, используется для вывода имени линии в сообщениях
        private string GetLineNameById(int id)
        {
            var query = "select place from dbo.recipe where id = " + id;
            var dt = DbConnect.GetDbInstance().PerformQuery(query);
            if (dt.Rows.Count == 0)
            {
                MessageBox.Show("На линии нет запущенных рецептов", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1, (MessageBoxOptions)0x40000);
                return "Ошибка";
            }
            if (dt.Rows.Count > 1)
            {
                MessageBox.Show("На линии оказалось больше одного запущенного рецепта", "Ошибка", MessageBoxButtons.OK,
                    MessageBoxIcon.Error, MessageBoxDefaultButton.Button1, (MessageBoxOptions)0x40000);
                return "Ошибка";
            }
            if (dt.Rows[0]["place"].ToString().Equals("W6"))
                return "1 ПД";
            if (dt.Rows[0]["place"].ToString().Equals("W2"))
                return "1 ОД";
            if (dt.Rows[0]["place"].ToString().Equals("W5"))
                return "2 ПД";
            return "2 ОД";
        }

        //Выставляем в базе что рецепт запущен в работу, вызввать только когда заданы бункера приоритеты  и т.п.
        private void SetRecipeInProgress(int id)
        {
            var query = "update dbo.recipe set isInProgress = 1 , timeInProgress = getdate() where id = " + id;
            DbConnect.GetDbInstance().PerformQuery(query);
            SetBunkersToCard(id);
         /*   MessageBox.Show("Рецепт № " + id + " запущен в работу", "Внимание", MessageBoxButtons.OK,
                MessageBoxIcon.Information);*/
        }

        //Записываем бункера в работе в карту бункеров
        private void SetBunkersToCard(int id)
        {
            var query =
                "update dbo.bunker_card set isInUse = 0, task = 0, currentIngredientId=0 where place = (select place from dbo.recipe where id = " +
                id + ")";
            DbConnect.GetDbInstance().PerformNonQuery(query);
            query = "select bunker, name, percentage from dbo.recipe_ingredient where id_recipe = " + id;
            var dt = DbConnect.GetDbInstance().PerformQuery(query);
            foreach (DataRow r in dt.Rows)
            {
                //query = "update dbo.bunker_card set isInUse = 1, ingredient = N'"+r["name"].ToString()+"' where bunkNum = " + r["bunker"].ToString();
                query = "update dbo.bunker_card set isInUse = 1, ingredient = N'" + r["name"].ToString().Trim() +
                        "', task = (select weight from dbo.recipe where id = " + id + ")/100*" + r["percentage"] +
                        ", currentPriority = (select priority from dbo.recipe_ingredient where id_recipe = " + id +
                        " and bunker = " + r["bunker"] +
                        "),  currentIngredientId = (select id from dbo.recipe_ingredient where id_recipe = " + id +
                        " and bunker = " + r["bunker"] + ")  where bunkNum = " + r["bunker"];
                DbConnect.GetDbInstance().PerformNonQuery(query);
            }
            UpdateBunkerCards();
        //    ApplyColoringToBunkerCard();
        }

        //Метод проверяет запущенные рецепты, 0 - нет запущенных, !0 - номер запущенного
        private int CheckRecipesInProgress(int idRec)
        {
            var query =
                "select COUNT(id) as count from dbo.recipe where isInProgress = 1 and place = (select place from dbo.recipe where id = " +
                idRec + ")";
            var dt = DbConnect.GetDbInstance().PerformQuery(query);
            if (dt.Rows[0]["count"].ToString() == "0")
                return 0;
            if (dt.Rows.Count == 1)
            {
                query =
                    "select id from dbo.recipe where isInProgress = 1 and place = (select place from dbo.recipe where id = " +
                    idRec + ")";
                dt = DbConnect.GetDbInstance().PerformQuery(query);
                var id = Convert.ToInt32(dt.Rows[0]["id"].ToString());
                return id;
            }
            //Если оказалось больше одного рецепта в работе, то оставляем последний
            /*   if (dt.Rows.Count > 1)
            {
                query = "select id, timeInProgress from dbo.recipe where isInProgress = 1 and place = (select place from dbo.recipe where id = "+idRec+" order by timeInProgress asc";
                DataTable res = DbConnect.GetDbInstance().PerformQuery(query);
                string lastId = res.Rows[res.Rows.Count - 1]["id"].ToString();
                query = "update dbo.recipe set isInProgress = 0";
                DBClasses.DbConnect.GetDbInstance().PerformQuery(query);
                query = "update dbo.recipe set isInProgress = 1 where id = " + lastId;
                return checkRecipesInProgress(idRec);
            }
            else*/
            return 0;
        }

        //Проверяем нужно ли указать бункера при запуске рецепта
        private bool CheckIfBunkersRequired(int id)
        {
            var query = "select bunker from dbo.recipe_ingredient where id_recipe = " + id;
            var dt = DbConnect.GetDbInstance().PerformQuery(query);
            foreach (DataRow r in dt.Rows)
            {
                if (r["bunker"].ToString() == "")
                    return true;
            }
            return false;
        }

        private void dataGridViewCurrentRecipes_Sorted(object sender, EventArgs e)
        {
          //  ApplyColoringToRecipes();
        }

        //Аварийное закрытие текущего рецепта вручную
        private void buttonCloseCurrent_Click(object sender, EventArgs e)
        {
           CloseRecipe();
        }

        //Процедура аварийного завершения рецепта
        private void CloseRecipe()
        {
            var query = "select COUNT(id) as count from dbo.recipe where isInProgress = 1";
            var dt = DbConnect.GetDbInstance().PerformQuery(query);
            if (dt.Rows.Count == 0)
                return;
            if (dt.Rows[0]["count"].ToString() == "0")
            {
                MessageBox.Show("В настоящий момент нет запущенных рецептов", "Внимание", MessageBoxButtons.OK,
                    MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1, (MessageBoxOptions)0x40000);
            }
            else
            {
                if (_srtc != null)
                    _srtc.Dispose();
                _srtc = new SelectRecipeToClose.SelectRecipeToClose();
                _srtc.ChangesDone += srtc_ChangesDone; //Обновляем рецепты когда окно выбора уничножено
                _srtc.RecipeClosedOd1 += _srtc_RecipeClosed_OD1;
                _srtc.RecipeClosedOd2 += _srtc_RecipeClosed_OD2;
                _srtc.RecipeClosedPd1 += _srtc_RecipeClosed_PD1;
                _srtc.RecipeClosedPd2 += _srtc_RecipeClosed_PD2;
                _srtc.Show();
            }
        }

        void _srtc_RecipeClosed_PD2(object sender, EventArgs e)
        {
            if(RecipeClosePd2 != null) RecipeClosePd2(this, new EventArgs());
            if (_debug)
            {
                PushDosedData pdd = new PushDosedData();
                pdd.errorRecipePD2_W5(1000f);
                MessageBox.Show("Закрытие рецепта на ПД2");
            }
        }

        void _srtc_RecipeClosed_PD1(object sender, EventArgs e)
        {
            if (RecipeClosePd1 != null) RecipeClosePd1(this, new EventArgs());
            if (_debug)
            {
                PushDosedData pdd = new PushDosedData();
                pdd.errorRecipePD1_W6(1000f);
                MessageBox.Show("Закрытие рецепта на ПД1");
            }
        }

        void _srtc_RecipeClosed_OD2(object sender, EventArgs e)
        {
            if (RecipeCloseOd2 != null) RecipeCloseOd2(this, new EventArgs());
            if (_debug)
            {
                PushDosedData pdd = new PushDosedData();
                pdd.errorRecipeOD2_W4(1000f);
                MessageBox.Show("Закрытие рецепта на ОД2");
            }
        }

        void _srtc_RecipeClosed_OD1(object sender, EventArgs e)
        {
            if (RecipeCloseOd1 != null) RecipeCloseOd1(this, new EventArgs());
            if (_debug)
            {
                PushDosedData pdd = new PushDosedData();
                pdd.errorRecipeOD1_W2(1000f);
                MessageBox.Show("Закрытие рецепта на ОД1");
            }
        }

        private void srtc_ChangesDone(object sender, EventArgs e)
        {
            UpdateCurrentRecipes();
            if (_debug)
                MessageBox.Show("RecipeClosed");
            if (_srtc == null)
                return;
            _srtc.ChangesDone -= srtc_ChangesDone;
            _srtc.RecipeClosedOd1 -= _srtc_RecipeClosed_OD1;
            _srtc.RecipeClosedOd2 -= _srtc_RecipeClosed_OD2;
            _srtc.RecipeClosedPd1 -= _srtc_RecipeClosed_PD1;
            _srtc.RecipeClosedPd2 -= _srtc_RecipeClosed_PD2;
        }

        private void tabControlIngredients_Enter(object sender, EventArgs e)
        {
            UpdateBunkerCards();
        }

        private void radioButtonVPWeek_CheckedChanged(object sender, EventArgs e)
        {
            UpdateVpView();
        }

        private void radioButtonVPMonth_CheckedChanged(object sender, EventArgs e)
        {
            UpdateVpView();
        }

        private void radioButtonVPYear_CheckedChanged(object sender, EventArgs e)
        {
            UpdateVpView();
        }

        private void radioButtonVPAllTime_CheckedChanged(object sender, EventArgs e)
        {
            UpdateVpView();
        }

        private void tabPagePortion_Enter(object sender, EventArgs e)
        {
            UpdateVpView();
        }

        private void checkBoxVP150Details_CheckedChanged(object sender, EventArgs e)
        {
            UpdateVp150();
        }

        private void dataGridViewBunkersW6_Sorted(object sender, EventArgs e)
        {
          //  ApplyColoringToBunkerCard();
        }

        private void dataGridViewBunkersW4_Sorted(object sender, EventArgs e)
        {
          //  ApplyColoringToBunkerCard();
        }

        private void dataGridViewBunkersW2_Sorted(object sender, EventArgs e)
        {
          //  ApplyColoringToBunkerCard();
        }

        private void dataGridViewBunkersW5_Sorted(object sender, EventArgs e)
        {
          //  ApplyColoringToBunkerCard();
        }

        private void dataGridViewBunkersW6_SelectionChanged(object sender, EventArgs e)
        {
            var dgv = sender as DataGridView;
            if (dgv != null) dgv.ClearSelection();
        }

        private void MainView_Validated(object sender, EventArgs e)
        {
            if (DbConnect.IsOnline())
            {
                UpdateBunkerCards();
                UpdateCurrentRecipes();

           //     ApplyColoringToBunkerCard();
           //     ApplyColoringToRecipes();
            }
        }

        private void MainView_VisibleChanged(object sender, EventArgs e)
        {
            if (!Visible || !DbConnect.IsOnline()) return;
            UpdateBunkerCards();
            UpdateCurrentRecipes();
           // ApplyColoringToBunkerCard();
           // ApplyColoringToRecipes();
        }

        //Вызываем детали рецепта при двойном клике по строке
        private void dataGridViewCurrentRecipes_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            int id;
            try
            {
                id = Convert.ToInt32(dataGridViewCurrentRecipes.Rows[e.RowIndex].Cells[0].Value);
            }
            catch (Exception)
            {
                return;
            }
            if(_details != null)
                _details.Dispose();
            _details = new RecipeDetails.RecipeDetails(id);
            _details.Show();
        }

        private void buttonRefreshReport_Click(object sender, EventArgs e)
        {
            UpdateReport();
        }

        private void dataGridViewReport_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            int id;
            try
            {
                id = Convert.ToInt32(dataGridViewReport.Rows[e.RowIndex].Cells[0].Value);
            }
            catch (Exception)
            {
                return;
            }
            if (_details != null)
                _details.Dispose();
            _details = new RecipeDetails.RecipeDetails(id);
            _details.Show();
        }

        private void checkBoxReportAll_CheckedChanged(object sender, EventArgs e)
        {
            checkBoxReportError.Enabled = !checkBoxReportAll.Checked;
            checkBoxReportFinished.Enabled = !checkBoxReportAll.Checked;
            checkBoxReportInProgress.Enabled = !checkBoxReportAll.Checked;
            checkBoxReportNotFinished.Enabled = !checkBoxReportAll.Checked;
        }

        private void buttonSaveTo_Click(object sender, EventArgs e)
        {
            //Больше не обновляем, чтобы не потерять выделение строк
           // buttonRefreshReport.PerformClick();
            if (dataGridViewReport.Rows.Count == 0)
            {
                MessageBox.Show("Не найдено ни одной заявки подходящей под выбранные условия", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1, (MessageBoxOptions)0x40000);
                return;
            }
            List<string> idsList = new List<string>();
            foreach (DataGridViewRow r in dataGridViewReport.Rows)
            {
                if (!r.IsNewRow)
                {
                    if(radioButtonReportSelectorAll.Checked)
                        idsList.Add(r.Cells[0].Value.ToString());
                    else if(r.Selected)
                    {
                        idsList.Add(r.Cells[0].Value.ToString());
                    }
                }
            }
            ReportDose rp = new ReportDose(idsList, checkBoxDetailedReport.Checked,checkBoxTechnological.Checked);
            rp.SaveReport();
        }

        private void buttonReportPrint_Click(object sender, EventArgs e)
        {
            //Больше не обновляем, чтобы не потерять выделение строк
          //  buttonRefreshReport.PerformClick();
            if (dataGridViewReport.Rows.Count == 0)
            {
                MessageBox.Show("Не найдено ни одной заявки подходящей под выбранные условия", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1, (MessageBoxOptions)0x40000);
                return;
            }
            List<string> idsList = new List<string>();
            foreach (DataGridViewRow r in dataGridViewReport.Rows)
            {
                if (radioButtonReportSelectorAll.Checked)
                    idsList.Add(r.Cells[0].Value.ToString());
                else if (r.Selected)
                {
                    idsList.Add(r.Cells[0].Value.ToString());
                }
            }
            ReportDose rp = new ReportDose(idsList, checkBoxDetailedReport.Checked, checkBoxTechnological.Checked);
            rp.PrintReport();
        }

        private void textBoxAccountingId_TextChanged(object sender, EventArgs e)
        {
            textBoxAccountingId.Text = Regex.Replace(textBoxAccountingId.Text, "[^0-9]", string.Empty);
            if (textBoxAccountingId.Text.Equals(string.Empty))
            {
                buttonPrintAccounting.Enabled = false;
                buttonCreateAccountingReport.Enabled = false;
            }
            else
            {
                buttonPrintAccounting.Enabled = true;
                buttonCreateAccountingReport.Enabled = true;
            }
        }

        private void buttonCreateAccountingReport_Click(object sender, EventArgs e)
        {
            string id = textBoxAccountingId.Text.Trim();
            string query = "select name from dbo.recipe where id=" + id;
            DataTable dt = DbConnect.GetDbInstance().PerformQuery(query);
            if (dt.Rows.Count != 1)
            {
                MessageBox.Show("Заявки с номером " + id + " не существует", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1, (MessageBoxOptions)0x40000);
                return;
            }
            List<string> idsList = new List<string> {id};
            ReportDose rp = new ReportDose(idsList);
            rp.IsAccounting = true;
            rp.SaveReport();
        }

        private void buttonPrintAccounting_Click(object sender, EventArgs e)
        {
            string id = textBoxAccountingId.Text.Trim();
            string query = "select name from dbo.recipe where id=" + id;
            DataTable dt = DbConnect.GetDbInstance().PerformQuery(query);
            if (dt.Rows.Count != 1)
            {
                MessageBox.Show("Заявки с номером " + id + " не существует", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1, (MessageBoxOptions)0x40000);
                return;
            }
            List<string> idsList = new List<string> { id };
            var rp = new ReportDose(idsList);
            rp.IsAccounting = true;
            rp.PrintReport();
        }

        private void buttonConsumptionFile_Click(object sender, EventArgs e)
        {
            if (dataGridViewRecipe.Rows.Count != 0)
            {
                ReportConsumption ct = new ReportConsumption(dataGridViewRecipe);
                ct.SaveConsumption();
            }
        }

        private void buttonConsumptionPrint_Click(object sender, EventArgs e)
        {
            if (dataGridViewRecipe.Rows.Count != 0)
            {
                ReportConsumption ct = new ReportConsumption(dataGridViewRecipe);
                ct.PrintConsumption();
            }
        }

        private void buttonReportVpSave_Click(object sender, EventArgs e)
        {
            if (!radioButtonReportVp150.Checked && !radioButtonReportVp501.Checked && !radioButtonReportVp502.Checked &&
                !radioButtonReportVp503.Checked)
            {
                MessageBox.Show("Не выбраны ни одни весы для формирования отчета", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1, (MessageBoxOptions)0x40000);
                return;
            }
            
            if (radioButtonReportVp150.Checked)
            {
                if (dataGridViewVP150.SelectedRows.Count == 0)
                {
                    MessageBox.Show("Весы ВП-150.\nНе выбрана ни одна строка для формирования отчета", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1, (MessageBoxOptions)0x40000);
                    return;
                }
                ReportVp rp = new ReportVp(dataGridViewVP150);
                rp.SetName("ВП-150");
                if (groupBoxVPTimeSelect.Enabled)
                {
                    rp.SetHeader(GetHeaderForVp("ВП-150"));
                }
                rp.SaveVp("Аппаратчик ________________________\nМастер смены_______________________");
                return;
            }
            if (radioButtonReportVp501.Checked)
            {
                if (dataGridViewVP501.SelectedRows.Count == 0)
                {
                    MessageBox.Show("Весы ВП-50-1.\nНе выбрана ни одна строка для формирования отчета", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1, (MessageBoxOptions)0x40000);
                    return;
                }
                ReportVp rp = new ReportVp(dataGridViewVP501);
                rp.SetName("ВП50-1");
                if (groupBoxVPTimeSelect.Enabled)
                {
                    rp.SetHeader(GetHeaderForVp("ВП50-1"));
                }
                rp.SaveVp("Аппаратчик-дозаторщик ________________________");
                return;
            }
            if (radioButtonReportVp502.Checked)
            {
                if (dataGridViewVP502.SelectedRows.Count == 0)
                {
                    MessageBox.Show("Весы ВП-50-2.\nНе выбрана ни одна строка для формирования отчета", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1, (MessageBoxOptions)0x40000);
                    return;
                }
                ReportVp rp = new ReportVp(dataGridViewVP502);
                rp.SetName("ВП50-2");
                if (groupBoxVPTimeSelect.Enabled)
                {
                    rp.SetHeader(GetHeaderForVp("ВП50-2"));
                }
                rp.SaveVp("Аппаратчик-дозаторщик ________________________");
                return;
            }
            if (radioButtonReportVp503.Checked)
            {
                if (dataGridViewVP503.SelectedRows.Count == 0)
                {
                    MessageBox.Show("Весы ВП-50-3.\nНе выбрана ни одна строка для формирования отчета", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1, (MessageBoxOptions)0x40000);
                    return;
                }
                ReportVp rp = new ReportVp(dataGridViewVP503);
                rp.SetName("ВП50-3");
                if (groupBoxVPTimeSelect.Enabled)
                {
                    rp.SetHeader(GetHeaderForVp("ВП50-3"));
                }
                rp.SaveVp("Аппаратчик-дозаторщик ________________________");
            }
        }

        private void buttonReportVpPrint_Click(object sender, EventArgs e)
        {
            if (!radioButtonReportVp150.Checked && !radioButtonReportVp501.Checked && !radioButtonReportVp502.Checked &&
                !radioButtonReportVp503.Checked)
            {
                MessageBox.Show("Не выбраны ни одни весы для формирования отчета", "Внимание", MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
                return;
            }
            if (radioButtonReportVp150.Checked)
            {
                if (dataGridViewVP150.SelectedRows.Count == 0)
                {
                    MessageBox.Show("Весы ВП-150.\nНе выбрана ни одна строка для формирования отчета", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1, (MessageBoxOptions)0x40000);
                    return;
                }
                ReportVp rp = new ReportVp(dataGridViewVP150);
                rp.SetName("ВП-150");
                if (groupBoxVPTimeSelect.Enabled)
                {
                    rp.SetHeader(GetHeaderForVp("ВП-150"));
                }
                rp.PrintVp("Аппаратчик ________________________\nМастер смены_______________________");
                return;
            }
            if (radioButtonReportVp501.Checked)
            {
                if (dataGridViewVP501.SelectedRows.Count == 0)
                {
                    MessageBox.Show("Весы ВП-50-1.\nНе выбрана ни одна строка для формирования отчета", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1, (MessageBoxOptions)0x40000);
                    return;
                }
                ReportVp rp = new ReportVp(dataGridViewVP501);
                rp.SetName("ВП50-1");
                if (groupBoxVPTimeSelect.Enabled)
                {
                    rp.SetHeader(GetHeaderForVp("ВП50-1"));
                }
                rp.PrintVp("Аппаратчик-дозаторщик ________________________");
            }
            if (radioButtonReportVp502.Checked)
            {
                if (dataGridViewVP502.SelectedRows.Count == 0)
                {
                    MessageBox.Show("Весы ВП-50-2.\nНе выбрана ни одна строка для формирования отчета", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1, (MessageBoxOptions)0x40000);
                    return;
                }
                ReportVp rp = new ReportVp(dataGridViewVP502);
                rp.SetName("ВП50-2");
                if (groupBoxVPTimeSelect.Enabled)
                {
                    rp.SetHeader(GetHeaderForVp("ВП50-2"));
                }
                rp.PrintVp("Аппаратчик-дозаторщик ________________________");
            }
            if (radioButtonReportVp503.Checked)
            {
                if (dataGridViewVP503.SelectedRows.Count == 0)
                {
                    MessageBox.Show("Весы ВП-50-3.\nНе выбрана ни одна строка для формирования отчета", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1, (MessageBoxOptions)0x40000);
                    return;
                }
                ReportVp rp = new ReportVp(dataGridViewVP503);
                rp.SetName("ВП50-3");
                if (groupBoxVPTimeSelect.Enabled)
                {
                    rp.SetHeader(GetHeaderForVp("ВП50-3"));
                }
                rp.PrintVp("Аппаратчик-дозаторщик ________________________");
            }
        }

        private void buttonAddImport_Click(object sender, EventArgs e)
        {
            var opn = new OpenFileDialog {Filter = @"Документы Excel (.xls) |*.xls; *.xlsx"};
            var rlst = opn.ShowDialog();
            if (rlst == DialogResult.OK)
            {
                if (_nr != null)
                    _nr.Dispose();
                _nr = new NewRequest.NewRequest(opn.FileName);
                _nr.Show();
            }
        }

        private void buttonSkipBunker_Click(object sender, EventArgs e)
        {
            if(_bskip != null)
                _bskip.Dispose();
            _bskip = new BunkerSkip.BunkerSkip();
            if (!_bskip.IsDisposed)
            {
                _bskip.LineOd1Skip += _bskip_LineOd1Skip;
                _bskip.LineOd2Skip += _bskip_LineOd2Skip;
                _bskip.LinePd1Skip += _bskip_LinePd1Skip;
                _bskip.LinePd2Skip += _bskip_LinePd2Skip;
            }
        }

        void _bskip_LinePd2Skip(object sender, EventArgs e)
        {
           _skippedBunkers = _bskip.GetDict();
           if(BunkerSkippedPd2 != null) BunkerSkippedPd2(this, new EventArgs());
            _bskip.Dispose();
            if (_debug)
            {
                foreach (string s in _skippedBunkers.Keys)
                {
                    IsBunkerSkipped(Convert.ToInt32(s));
                }
            }
        }

        void _bskip_LinePd1Skip(object sender, EventArgs e)
        {
            _skippedBunkers = _bskip.GetDict();
            if (BunkerSkippedPd1 != null) BunkerSkippedPd1(this, new EventArgs());
            _bskip.Dispose();
            if (_debug)
            {
                foreach (string s in _skippedBunkers.Keys)
                {
                    IsBunkerSkipped(Convert.ToInt32(s));
                }
            }
        }

        void _bskip_LineOd2Skip(object sender, EventArgs e)
        {
            _skippedBunkers = _bskip.GetDict();
            if (BunkerSkippedOd2 != null) BunkerSkippedOd2(this, new EventArgs());
            _bskip.Dispose();
            if (_debug)
            {
                foreach (string s in _skippedBunkers.Keys)
                {
                    IsBunkerSkipped(Convert.ToInt32(s));
                }
            }
        }

        void _bskip_LineOd1Skip(object sender, EventArgs e)
        {
            _skippedBunkers = _bskip.GetDict();
            if (BunkerSkippedOd1 != null) BunkerSkippedOd1(this, new EventArgs());
            _bskip.Dispose();
            if (_debug)
            {
                foreach (string s in _skippedBunkers.Keys)
                {
                    IsBunkerSkipped(Convert.ToInt32(s));
                }
            }
        }

        //Для запроса из СКАДА был бункер пропущен или нет
        public bool IsBunkerSkipped(int bunkNum)
        {
            if (_skippedBunkers == null)
                return false;
            if (_debug)
            {
                PushDosedData pdd = new PushDosedData();
                Random rnd = new Random();
                pdd.PushSkipData(bunkNum, (float)rnd.NextDouble() * rnd.Next(0, 300));
            }
            return _skippedBunkers.ContainsKey(bunkNum.ToString().Trim());
        }

        

        private void buttonSwapBunkers_Click(object sender, EventArgs e)
        {
            SwapBunker();
        }

        private void SkipBunker(string place)
        {
            if (_bskip != null)
                _bskip.Dispose();
            _bskip = new BunkerSkip.BunkerSkip(place);
            if (!_bskip.IsDisposed)
            {
                _bskip.LineOd1Skip += _bskip_LineOd1Skip;
                _bskip.LineOd2Skip += _bskip_LineOd2Skip;
                _bskip.LinePd1Skip += _bskip_LinePd1Skip;
                _bskip.LinePd2Skip += _bskip_LinePd2Skip;
            }
        }
        [ComVisible(true)]
        //Для вызова пропуска бункера из SCADA
        public void SkipBunkerPd1()
        {
            SkipBunker("W6");
        }
        [ComVisible(true)]
        public void SkipBunkerPd2()
        {
            SkipBunker("W5");
        }
        [ComVisible(true)]
        public void SkipBunkerOd1()
        {
            SkipBunker("W2");
        }
        [ComVisible(true)]
        public void SkipBunkerOd2()
        {
            SkipBunker("W4");
        }

        //Вызов окна переноса бункера
        private void SwapBunker(string place = "Na")
        {
            _swappedBunkers = new KeyValuePair<string, string>("0","0");
            if (_bswap != null)
                _bswap.Dispose();
            if(place.Equals("Na"))
             _bswap = new BunkerSwap.BunkerSwap();
            else
            {
                _bswap = new BunkerSwap.BunkerSwap(place);
            }
            if (!_bswap.IsDisposed)
            {
                _bswap.LineOd1Swap +=_bswap_LineOd1Swap;
                _bswap.LineOd2Swap +=_bswap_LineOd2Swap;
                _bswap.LinePd1Swap +=_bswap_LinePd1Swap;
                _bswap.LinePd2Swap += _bswap_LinePd2Swap;
            }
        }

        void _bswap_LinePd2Swap(object sender, EventArgs e)
        {
            _swappedBunkers = _bswap.GetSwap();
            _bswap.Dispose();
            if(BunkerSwappedPd2 != null) BunkerSwappedPd2(this, new EventArgs());
            UpdateBunkerCards();
        //    ApplyColoringToBunkerCard();
        }

        void _bswap_LinePd1Swap(object sender, EventArgs e)
        {
            _swappedBunkers = _bswap.GetSwap();
            _bswap.Dispose();
            if (BunkerSwappedPd1 != null) BunkerSwappedPd1(this, new EventArgs());
            UpdateBunkerCards();
           // ApplyColoringToBunkerCard();
        }

        void _bswap_LineOd2Swap(object sender, EventArgs e)
        {
            _swappedBunkers = _bswap.GetSwap();
            _bswap.Dispose();
            if (BunkerSwappedOd2 != null) BunkerSwappedOd2(this, new EventArgs());
            UpdateBunkerCards();
           // ApplyColoringToBunkerCard();
        }

        void _bswap_LineOd1Swap(object sender, EventArgs e)
        {
            _swappedBunkers = _bswap.GetSwap();
            _bswap.Dispose();
            if (BunkerSwappedOd1 != null) BunkerSwappedOd1(this, new EventArgs());
            UpdateBunkerCards();
           // ApplyColoringToBunkerCard();
        }

        //Для запроса смены бункера из СКАДА, возвращает 0 если не заменен и номер того на который заменен, если заменили.
        public string IsBunkerSwapped(int bunkNum)
        {
            if (_swappedBunkers.Key.Equals(bunkNum.ToString()))
                return _swappedBunkers.Value;
            return "0";
        }
        [ComVisible(true)]
        //Для вызова переноса бункера из SCADA
        public void SwapBunkerPd1()
        {
            SwapBunker("W6");
        }
        [ComVisible(true)]
        public void SwapBunkerPd2()
        {
            SwapBunker("W5");
        }
        [ComVisible(true)]
        public void SwapBunkerOd1()
        {
            SwapBunker("W2");
        }
        [ComVisible(true)]
        public void SwapBunkerOd2()
        {
            SwapBunker("W4");
        }
        //Делает то же самое что и GoToWork, но последнюю не видно в продакшене
        private void buttonStartRecipe_Click(object sender, EventArgs e)
        {
            StartRecipe();
        }

        private void MainView_Click(object sender, EventArgs e)
        {
            if (!tabControlIngredients.Enabled && !DbConnect.IsOnline())
            {
                ShowConnLost(this, new EventArgs());
            }
        }
        //Отображение имени линии в таблице с текущими рецептами.
        private void dataGridViewCurrentRecipes_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (dataGridViewCurrentRecipes.Columns[e.ColumnIndex].Name == "Наименование")
            {
                e.Value += " ("+GetLineNameByWeights(dataGridViewCurrentRecipes.Rows[e.RowIndex].Cells["Линия"].Value.ToString())+")";
            }
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged_1(object sender, EventArgs e)
        {

        }

        private void checkBoxVPShowEnabled_CheckedChanged(object sender, EventArgs e)
        {
            groupBoxVPPeriod.Enabled = checkBoxVPShowEnabled.Checked;
            groupBoxVPTimeSelect.Enabled = !checkBoxVPShowEnabled.Checked;
            if (checkBoxVPShowEnabled.Checked && checkBoxVPDetailedShow.Checked)
            {
                checkBoxVPDetailedShow.Checked = false;
                checkBoxVPShowEnabled.Checked = true;
            }
            if (!checkBoxVPShowEnabled.Checked && !checkBoxVPDetailedShow.Checked)
            {
                checkBoxVPDetailedShow.Checked = true;
                checkBoxVPShowEnabled.Checked = false;
            }
            if(checkBoxVPShowEnabled.Enabled)
                UpdateVpView();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            groupBoxVPPeriod.Enabled = !checkBoxVPDetailedShow.Checked;
            groupBoxVPTimeSelect.Enabled = checkBoxVPDetailedShow.Checked;
            if (checkBoxVPShowEnabled.Checked && checkBoxVPDetailedShow.Checked)
            {
                checkBoxVPShowEnabled.Checked = false;
                checkBoxVPDetailedShow.Checked = true;
            }
            if (!checkBoxVPShowEnabled.Checked && !checkBoxVPDetailedShow.Checked)
            {
                checkBoxVPShowEnabled.Checked = true;
                checkBoxVPDetailedShow.Checked = false;
            }
            
        }

        private void groupBoxVPPeriod_EnabledChanged(object sender, EventArgs e)
        {
            if(groupBoxVPPeriod.Enabled)
                UpdateVpView();
        }
        //Формирование выделения для отчетов ВП
        private void buttonReportSelectByTime_Click(object sender, EventArgs e)
        {
            if (dateTimePickerReportDateFrom.Value > dateTimePickerReportDateTo.Value)
            {
                return;
            }
            if (dateTimePickerReportDateFrom.Value.Date == dateTimePickerReportDateTo.Value.Date)
            {
                if(dateTimePickerReportTimeFrom.Value > dateTimePickerReportTimeTo.Value)
                    return;
            }
            UpdateVpView();
        }

        private void tableLayoutPanelVerticalSplit_Paint(object sender, PaintEventArgs e)
        {

        }

        private void tableLayoutPanelRecipes_Paint(object sender, PaintEventArgs e)
        {

        }

        private void buttonPrintRepMainView_Click(object sender, EventArgs e)
        {
            if(dataGridViewCurrentRecipes.SelectedRows.Count != 1)
                return;
            string id = "";
            try
            {
                id = dataGridViewCurrentRecipes.SelectedRows[0].Cells[0].Value.ToString().Trim();
            }
            catch
            {
                return;
            }
            string query = "select name from dbo.recipe where id=" + id;
            DataTable dt = DbConnect.GetDbInstance().PerformQuery(query);
            if (dt.Rows.Count != 1)
            {
                MessageBox.Show("Заявки с номером " + id + " не существует", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1, (MessageBoxOptions)0x40000);
                return;
            }
            List<string> idsList = new List<string> { id };
            var rp = new ReportDose(idsList);
            rp.IsAccounting = true;
            rp.PrintReport();
        }

        private void checkBoxExcelGeneral_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBoxExcelGeneral.Checked)
            {
                checkBoxExcelByRecipes.Checked = false;
                checkBoxExcelByBatches.Checked = false;
            }
        }

        private void checkBoxExcelByRecipes_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBoxExcelByRecipes.Checked)
            {
                checkBoxExcelByBatches.Checked = false;
                checkBoxExcelGeneral.Checked = false;
            }
        }

        private void checkBoxExcelByBatches_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBoxExcelByBatches.Checked)
            {
                checkBoxExcelByRecipes.Checked = false;
                checkBoxExcelGeneral.Checked = false;
            }
        }
        //Сохранение отчетов в Excel
        private void buttonExportToExcel_Click(object sender, EventArgs e)
        {
            if (dataGridViewReport.Rows.Count == 0)
            {
                MessageBox.Show("Не найдено ни одной заявки подходящей под выбранные условия", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1, (MessageBoxOptions)0x40000);
                return;
            }
            TableMaker tbl = new TableMaker(dataGridViewReport, radioButtonExcelSelected.Checked);
            if(checkBoxExcelByBatches.Checked)
                tbl.SetType(ExcelReportType.BatchesReport);
            if(checkBoxExcelByRecipes.Checked)
                tbl.SetType(ExcelReportType.RecipesReport);
            if(checkBoxExcelGeneral.Checked)
                tbl.SetType(ExcelReportType.GeneralReport);
            tbl.MakeReport();
        }

        private void checkBoxTechnological_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBoxTechnological.Checked && checkBoxDetailedReport.Checked)
                checkBoxDetailedReport.Checked = false;

        }

        private void checkBoxDetailedReport_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBoxTechnological.Checked && checkBoxDetailedReport.Checked)
                checkBoxTechnological.Checked = false;
        }
    }
}