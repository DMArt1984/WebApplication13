﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Windows.Forms;

namespace LKZ_MF_Widget.BunkerSkip
{
    public partial class BunkerSkip : Form
    {
        public event EventHandler LinePd1Skip;
        public event EventHandler LinePd2Skip;
        public event EventHandler LineOd1Skip;
        public event EventHandler LineOd2Skip;

        private Dictionary<string, string> _skipList; //Список ингредиентов для пропуска 
        public BunkerSkip()
        {
            InitializeComponent();
            TopMost = true;
            CenterToScreen();
            if (!CheckIfPossible())
            {
                MessageBox.Show("В настоящее время нет запущенных рецептов", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1, (MessageBoxOptions)0x40000);
                Dispose();
                return;
            }
            dataGridViewSkipList.Refresh();
            InitForm();
            Show();
        }

        //При вызове из SCADA для конкретной линии
        public BunkerSkip(string place)
        {
            InitializeComponent();
            TopMost = true;
            CenterToScreen();
            if (!CheckIfPossible())
            {
                MessageBox.Show("В настоящее время нет запущенных рецептов", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1, (MessageBoxOptions)0x40000);
                Dispose();
                return;
            }
            dataGridViewSkipList.Refresh();
            InitForm();
            Show();
            ApplyPlace(place);
        }
        //Изменение интерфейса для отображения одной линии
        private void ApplyPlace(string place)
        {
            if (place.Equals("W2"))
            {
                radioButtonOd1.Checked = true;
            }
            if (place.Equals("W6"))
            {
                radioButtonPd1.Checked = true;
            }
            if (place.Equals("W4"))
            {
                radioButtonOd2.Checked = true;
            }
            if (place.Equals("W5"))
            {
                radioButtonPd2.Checked = true;
            }
            tableLayoutPanelMain.RowStyles[0].Height = 0;
        }

        private void InitForm()
        {
            InitRadioButtons();
            UpdateBunkers();
        }

        private void InitDgv()
        {
           
            var colNames = new List<KeyValuePair<string, string>>
            {   
                new KeyValuePair<string, string>("Наименование","name"),
                new KeyValuePair<string, string>("Бункер","bunker")
            };
            for (int i = 0; i < colNames.Count; i++)
            {
                var column = new DataGridViewTextBoxColumn();
                if (i == 0)
                    column.Width = 50;
                dataGridViewSkipList.Columns.Add(column);
                dataGridViewSkipList.Columns[i].DataPropertyName = colNames[i].Value;
                dataGridViewSkipList.Columns[i].Name = colNames[i].Value;
                dataGridViewSkipList.Columns[i].HeaderText = colNames[i].Key;
                dataGridViewSkipList.Columns[i].DisplayIndex = i;
            }
            var check = new DataGridViewCheckBoxColumn();
            dataGridViewSkipList.Columns.Add(check);
            dataGridViewSkipList.Columns[2].HeaderText = "Пропуск";
            dataGridViewSkipList.Columns[2].Name = "skip";
            dataGridViewSkipList.Columns[2].DataPropertyName = "skip";
            dataGridViewSkipList.Columns[2].DisplayIndex = 2;
        }

        private void InitRadioButtons()
        {
            radioButtonOd1.Enabled = false;
            radioButtonPd1.Enabled = false;
            radioButtonOd2.Enabled = false;
            radioButtonPd2.Enabled = false;
            var query = "select id, place from dbo.recipe where isInProgress = 1";
            DataTable dt = DBClasses.DbConnect.GetDbInstance().PerformQuery(query);
            List<RadioButton> radioList = new List<RadioButton>();
            foreach (DataRow r in dt.Rows)
            {
                string str = r["place"].ToString().Trim();
                if (str.Equals("W2"))
                {
                    radioButtonOd1.Enabled = true;
                    radioList.Add(radioButtonOd1);
                }
                if (str.Equals("W6"))
                {
                    radioButtonPd1.Enabled = true;
                    radioList.Add(radioButtonPd1);
                }
                if (str.Equals("W4"))
                {
                    radioButtonOd2.Enabled = true;
                    radioList.Add(radioButtonOd2);
                }
                if (str.Equals("W5"))
                {
                    radioButtonPd2.Enabled = true;
                    radioList.Add(radioButtonPd2);
                }
            }
            if (radioList.Count != 0)
                radioList[0].Checked = true;
        }

        private bool CheckIfPossible()
        {
            var query = "select id from dbo.recipe where isInProgress = 1";
            DataTable dt = DBClasses.DbConnect.GetDbInstance().PerformQuery(query);
            if (dt.Rows.Count == 0)
                return false;
            return true;
        }

        private void radioButtonPd1_CheckedChanged(object sender, EventArgs e)
        {
            UpdateBunkers();
        }
        private void UpdateBunkers()
        {
            UpdateLabel();
            UpdateDgv();
        }
        //Обновляем таблицу с рецептом
        private void UpdateDgv()
        {
            if (dataGridViewSkipList.Columns.Count == 0)
            {
                InitDgv();
            }
            //, 'false' as skip
            var query =
                "select  name, bunker from dbo.recipe_ingredient where id_recipe = (select id from dbo.recipe where isInProgress = 1 and place = '"+GetPlace()+"')";
            DataTable dt = DBClasses.DbConnect.GetDbInstance().PerformQuery(query);
            if (dataGridViewSkipList.InvokeRequired)
            {
                dataGridViewSkipList.Invoke(new MethodInvoker(() => dataGridViewSkipList.DataSource = dt));
            }
            else
            {
                dataGridViewSkipList.DataSource = dt;
            }
            dataGridViewSkipList.Refresh();
        }

        //Обновляем лейбу с названием рецепта
        private void UpdateLabel()
        {
            string labelText = "";
            var query = "select id,name, quality from dbo.recipe where isInProgress = 1 and place = '"+GetPlace()+"'";
            DataTable dt = DBClasses.DbConnect.GetDbInstance().PerformQuery(query);
            if (dt.Rows.Count == 0)
            {
                MessageBox.Show("На линии нет запущенных рецептов", "Ошибка", MessageBoxButtons.OK,
                    MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1, (MessageBoxOptions)0x40000);
                labelText = "Ошибка";
            }
            else
            {
                if (dt.Rows.Count > 1)
                {
                    MessageBox.Show("На линии больше одного запущенного рецепта", "Ошибка", MessageBoxButtons.OK,
                        MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1, (MessageBoxOptions)0x40000);
                    labelText = "Ошибка";
                }
                else
                {
                    labelText = "Рецепт № "+dt.Rows[0]["id"].ToString().Trim() +" "+dt.Rows[0]["name"].ToString().Trim() + " (" + dt.Rows[0]["quality"].ToString().Trim() +
                                ")";
                }
            }
            if (InvokeRequired)
            {
                Invoke(new MethodInvoker(() => labelRecipe.Text = labelText));
            }
            else
            {
                labelRecipe.Text = labelText;
            }
        }

        //Получить название линии из radioButton
        private string GetPlace()
        {
            if (radioButtonOd1.Checked)
            {
                return "W2";
            }
            if (radioButtonPd1.Checked)
            {
                return "W6";
            }
            if (radioButtonOd2.Checked)
            {
                return "W4";
            }
            if (radioButtonPd2.Checked)
            {
                return "W5";
            }
            return string.Empty;
        }

        private void buttonCancel_Click(object sender, EventArgs e)
        {
            Dispose();
        }

        private void buttonSkip_Click(object sender, EventArgs e)
        {
            _skipList = new Dictionary<string, string>();
            foreach (DataGridViewRow r in dataGridViewSkipList.Rows)
            {
                if(r.Cells[0].Value == null)
                    continue;
                if (r.Cells[0].Value.ToString().Equals("True"))
                {
                    _skipList.Add(r.Cells[2].Value.ToString().Trim(),r.Cells[1].Value.ToString().Trim());
                }
            }
            if (_skipList.Count == 0)
            {
                MessageBox.Show("Не выбрано ни одного ингредиента для пропуска",
                    "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1, (MessageBoxOptions)0x40000);
                return;
            }
          /*  if (skipList.Count == dataGridViewSkipList.RowCount)
            {
                MessageBox.Show("Нельзя пропустить все ингредиенты",
                    "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1, (MessageBoxOptions)0x40000);
                return;
            }*/
            string place = GetPlace();
            if (place.Equals("W2"))
            {
                if(LineOd1Skip != null) LineOd1Skip(this, new EventArgs());
            }
            if (place.Equals("W4"))
            {
                if (LineOd2Skip != null) LineOd2Skip(this, new EventArgs());
            }
            if (place.Equals("W6"))
            {
                if (LinePd1Skip != null) LinePd1Skip(this, new EventArgs());
            }
            if (place.Equals("W5"))
            {
                if (LinePd2Skip != null) LinePd2Skip(this, new EventArgs());
            }
        }

        public Dictionary<string, string> GetDict()
        {
            return _skipList;
        }
    }
}
