﻿using System;

namespace LKZ_MF_Widget.NewRequest
{
    //EventArgs для передачи нового имени ингредиента в форму
    public class AddIngredientEventArgs : EventArgs
    {
        private readonly string _name;

        public AddIngredientEventArgs(string input)
        {
            _name = input;
        }

        public string Name
        {
            get { return _name; }
        }
    }
}
