﻿using System;
using System.Collections.Generic;

namespace LKZ_MF_Widget.DBClasses
{
    //Очередь, испускающая сигнал о добавлении элемента, используется для запросов к базе
    internal class QueryQueue<T> : Queue<T>
    {
        public event EventHandler QueryAdded; // сигнал добавления элемента
        public event EventHandler QueryRemoved; // сигнал извлечения элемента 

        //Добавления элемента в очередь
        public new void Enqueue(T item)
        {
            base.Enqueue(item);
            if (QueryAdded != null)
                QueryAdded(this, new EventArgs());
        }

        //Извлечение элемента из очереди
        public new T Dequeue()
        {
            if (QueryRemoved != null)
                QueryRemoved(this, new EventArgs());
            return base.Dequeue();
        }
    }
}