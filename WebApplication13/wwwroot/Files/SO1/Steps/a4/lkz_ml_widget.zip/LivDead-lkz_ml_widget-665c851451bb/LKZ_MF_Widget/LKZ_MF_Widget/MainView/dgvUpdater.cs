﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using LKZ_MF_Widget.DBClasses;

namespace LKZ_MF_Widget.MainView
{
    //Обновление сведений в таблицах
    public partial class MainView
    {
        private DataTable _currentRecipes = new DataTable(); //Текущие показания в рецептах
        private DataTable _currentVp150 = new DataTable(); //Текущие показания весов ВП150
        private DataTable _currentVp501 = new DataTable(); //Текущие показания весов ВП50-1
        private DataTable _currentVp502 = new DataTable(); //Текущие показания весов ВП50-2
        private DataTable _currentVp503 = new DataTable(); //Текущие показания весов ВП50-3
        private readonly Color _finisheByErrColor = Color.Red; //Цвет для аварийных рецептов

        private readonly Color _finishedColor = Color.Green; //Цвет для успешно завершенных рецептов
        private readonly Color _inProgressColor = Color.Yellow; //Цвет для запущенных рецептов

        private int _consumptionLimit = 200; //Ограничение по количеству выбранных рецептов для подсчета расхода, чтобы не тормозить базу

        //Справочник ингредиентов
        private void UpdateIngredientsView()
        {
            try
            {
                dataGridViewIngredients.Rows.Clear();
            }
            catch
            {
                //  return;
            }
            var query = "select name, comment, timeUpdate, timeCreate, id from dbo.ingredient_list order by name asc";
            var dt = DbConnect.GetDbInstance().PerformQuery(query);
            if (dataGridViewIngredients.InvokeRequired)
            {
                dataGridViewIngredients.Invoke(new MethodInvoker(() => dataGridViewIngredients.DataSource = dt));
            }
            else
                dataGridViewIngredients.DataSource = dt;
            dataGridViewIngredients.Refresh();
        }

        //Карта бункеров
        private void UpdateBunkerCards()
        {
            UpdateBunkerCardForWeights("W6", dataGridViewBunkersW6);
            UpdateBunkerCardForWeights("W2", dataGridViewBunkersW2);
            UpdateBunkerCardForWeights("W5", dataGridViewBunkersW5);
            UpdateBunkerCardForWeights("W4", dataGridViewBunkersW4);
           // ApplyColoringToBunkerCard();
        }

        //Окрашиваем карту бункеров
      /*  private void ApplyColoringToBunkerCard()
        {
            var views = new List<DataGridView>
            {
                dataGridViewBunkersW2,
                dataGridViewBunkersW6,
                dataGridViewBunkersW5,
                dataGridViewBunkersW4
            };
            foreach (var v in views)
            {
                    foreach (DataGridViewRow r in v.Rows)
                    {
                        //isInUse
                        if (r.Cells[2].Value.ToString().Equals("True"))
                        {
                            r.DefaultCellStyle.BackColor = _finishedColor;
                        }
                        else
                            r.DefaultCellStyle.BackColor = Color.Empty;
                    }
            }
        }*/

        void dgvBunkersColoring_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (!((DataGridView)sender).Visible)
                return;
            foreach (DataGridViewRow r in ((DataGridView)sender).Rows)
            {
                if (r.Cells.Count < 2)
                    return;
                //isInUse
                if (r.Cells[2].Value.ToString().Equals("True"))
                {
                    r.DefaultCellStyle.BackColor = _finishedColor;
                }
                else
                    r.DefaultCellStyle.BackColor = Color.Empty;
            }
        }

        //Для одной таблицы в карте бункеров
        private void UpdateBunkerCardForWeights(string w, DataGridView dgv)
        {
            var query = "select bunkNum, ingredient, isInUse,task from dbo.bunker_card where place = '" + w +
                        "' order by bunkNum asc;";
            var dt = DbConnect.GetDbInstance().PerformQuery(query);
            if (dgv.InvokeRequired)
            {
                dgv.Invoke(new MethodInvoker(() => dgv.DataSource = dt));
            }
            else
                dgv.DataSource = dt;
            dgv.Refresh();
        }

        //Обновление текущих рецептов
        private void UpdateCurrentRecipes()
        {
            //  MessageBox.Show("Обновляем текущий рецепт");
            var query = "select id, name,  weight, timeCreate, isFinished, isInProgress, isFinishedErr, place from dbo.recipe ";
            if (radioButtonCurrentMonth.Checked)
            {
                query += "where timeCreate >= GETDATE() - DAY(30)";
            }
            if (radioButtonCurrentWeek.Checked)
            {
                query += "where timeCreate >= GETDATE() - DAY(7)";
            }
            if (radioButtonCurrentYear.Checked)
            {
                query += "where timeCreate >= GETDATE() - YEAR(1)";
            }
            if (radioButtonCurrentById.Checked)
            {
                if (textBoxCurrentId.Text == string.Empty)
                    return;
                int id;
                try
                {
                    id = Convert.ToInt32(textBoxCurrentId.Text);
                }
                catch
                {
                    return;
                }
                query += "where id >= " + id + "";
            }
            query += " order by timeCreate asc";
            var dt = DbConnect.GetDbInstance().PerformQuery(query);
            if (!AreTablesTheSame(dt, _currentRecipes))
            {
                _currentRecipes = dt;
                if (dataGridViewCurrentRecipes.InvokeRequired)
                {
                    dataGridViewCurrentRecipes.Invoke(
                        new MethodInvoker(() => dataGridViewCurrentRecipes.DataSource = _currentRecipes));
                }
                else
                {
                    dataGridViewCurrentRecipes.DataSource = _currentRecipes;
                }
                dataGridViewCurrentRecipes.Refresh();
                if (dataGridViewCurrentRecipes.Rows.Count > 1)
                    dataGridViewCurrentRecipes.FirstDisplayedScrollingRowIndex = dataGridViewCurrentRecipes.RowCount - 1;
              //  ApplyColoringToRecipes();
            }
        }
      
        //Возвращаем имя линии по полю place из базы
        private string GetLineNameByWeights(string input)
        {
            input = input.Trim();
            switch (input)
            {
                case "W2":
                {
                    return "ОД1";
                }
                case "W4":
                {
                    return "ОД2";
                }
                case "W6":
                {
                    return "ПД1";
                }
                case "W5":
                {
                    return "ПД2";
                }
               // case "Na0":
                default:
                {
                    return @"Н/Д";
                }
            }
        }

        //Раскрашиваем строки в текущих рецептах в нужные цвета
      /*  private void ApplyColoringToRecipes()
        {
           foreach (DataGridViewRow r in dataGridViewCurrentRecipes.Rows)
            {
                //isFinished
                if (r.Cells[4].Value.ToString() == "True")
                {
                    r.DefaultCellStyle.BackColor = _finishedColor;
                    continue;
                }
                //isInProgress
                if (r.Cells[5].Value.ToString() == "True")
                {
                    r.DefaultCellStyle.BackColor = _inProgressColor;
                    continue;
                }
                //isFinishedErr
                if (r.Cells[6].Value.ToString() == "True")
                {
                    r.DefaultCellStyle.BackColor = _finisheByErrColor;
                    continue;
                }
                r.DefaultCellStyle.BackColor = Color.Empty;
            }
        }*/

        private void DataGridViewCurrentRecipesOnCellFormatting(object sender, DataGridViewCellFormattingEventArgs dataGridViewCellFormattingEventArgs)
        {
            if (!((DataGridView)sender).Visible)
                return;
            foreach (DataGridViewRow r in ((DataGridView)sender).Rows)
            {
                if(r.Cells.Count<6)
                    return;
                //isFinished
                if (r.Cells[4].Value.ToString() == "True")
                {
                    r.DefaultCellStyle.BackColor = _finishedColor;
                    continue;
                }
                //isInProgress
                if (r.Cells[5].Value.ToString() == "True")
                {
                    r.DefaultCellStyle.BackColor = _inProgressColor;
                    continue;
                }
                //isFinishedErr
                if (r.Cells[6].Value.ToString() == "True")
                {
                    r.DefaultCellStyle.BackColor = _finisheByErrColor;
                    continue;
                }
                r.DefaultCellStyle.BackColor = Color.Empty;
            }
        }

        //Сравнение двух таблиц при обновлении текущих рецептов
        public static bool AreTablesTheSame(DataTable tbl1, DataTable tbl2)
        {
            if (tbl1.Rows.Count != tbl2.Rows.Count || tbl1.Columns.Count != tbl2.Columns.Count)
                return false;
            for (var i = 0; i < tbl1.Rows.Count; i++)
            {
                for (var c = 0; c < tbl1.Columns.Count; c++)
                {
                    if (!Equals(tbl1.Rows[i][c], tbl2.Rows[i][c]))
                        return false;
                }
            }
            return true;
        }

        //Обновление отображения состава для выбранного рецепта
        private void UpdateRecipe()
        {
            if (dataGridViewCurrentRecipes.SelectedRows.Count == 0)
            {
                if (dataGridViewRecipe.Rows.Count > 0)
                {
                    try
                    {
                        dataGridViewRecipe.Rows.Clear();
                    }
                    catch
                    {
                        return;
                    }
                }
                return;
            }
            int id;
            try
            {
                id = Convert.ToInt32(dataGridViewCurrentRecipes.SelectedRows[0].Cells[0].Value);
            }
            catch
            {
                return;
            }
            var query = "select ROW_NUMBER() over(order by percentage desc) as cnt, name, percentage," +
                        "percentage * (select weight from dbo.recipe where id = " + id +
                        " )/100 as mass, bunker, priority " +
                        "from dbo.recipe_ingredient where id_recipe =" + id + "; ";

            var dt = DbConnect.GetDbInstance().PerformQuery(query);
            if (dataGridViewRecipe.InvokeRequired)
            {
                dataGridViewRecipe.Invoke(new MethodInvoker(() => dataGridViewRecipe.DataSource = dt));
            }
            else
                dataGridViewRecipe.DataSource = dt;
            dataGridViewRecipe.Refresh();
        }

        //Обновление расхода материала
        private void UpdateConsumption()
        {
            while (dataGridViewRecipe.Rows.Count != 0)
            {
                foreach (DataGridViewRow r in dataGridViewRecipe.Rows)
                {
                    dataGridViewRecipe.Rows.Remove(r);
                }
            }
            List<string> idsList = new List<string>();
            foreach (DataGridViewRow r in dataGridViewCurrentRecipes.SelectedRows)
            {
                idsList.Add(r.Cells[0].Value.ToString());
            }
            string ids = "";
            for (int i = 0; i < idsList.Count; i++)
            {
                ids += idsList[i];
                if (i != idsList.Count - 1)
                    ids += ",";
            }
            DataTable dt = new DataTable();
            if (idsList.Count <= _consumptionLimit)
            {
                string query = "Select DISTINCT " +
                               "dbo.recipe_ingredient.name, " +
                               "Round(SUM (dbo.recipe.weight * dbo.recipe_ingredient.percentage /100) over (partition by dbo.recipe_ingredient.name),3) as weight from " +
                               "dbo.recipe_ingredient " +
                               "Inner join dbo.recipe on dbo.recipe_ingredient.id_recipe = dbo.recipe.id where dbo.recipe.id in (" +
                               ids + ") order by weight desc";
                 dt = DbConnect.GetDbInstance().PerformQuery(query);
            }
            else
            {
                MessageBox.Show("Выбрано слишком много рецептов.\nМаксимально допустимое количество : " + _consumptionLimit, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1, (MessageBoxOptions)0x40000);
                dataGridViewRecipe.ClearSelection();
            }
            if (dataGridViewRecipe.InvokeRequired)
            {
                dataGridViewRecipe.Invoke(new MethodInvoker(() => dataGridViewRecipe.DataSource = dt));
            }
            else
                dataGridViewRecipe.DataSource = dt;
            dataGridViewRecipe.Refresh();
        }

        //Обновление весов страницы с весами ВП
        private void UpdateVpView()
        {
            UpdateVp150();
            UpdateVp501();
            UpdateVp502();
            UpdateVp503();
        }

        //Обновление DGV с весами ВП50-3
        private void UpdateVp503()
        {
            var query = "select name, task,  cycles, production, bunker, timeCreated  from dbo.vp503_stats ";
            if (!groupBoxVPTimeSelect.Enabled)
            {
                if (radioButtonVPMonth.Checked)
                {
                    query += "where timeCreated >= GETDATE() - DAY(30)";
                }
                if (radioButtonVPWeek.Checked)
                {
                    query += "where timeCreated >= GETDATE() - DAY(7)";
                }
                if (radioButtonVPYear.Checked)
                {
                    query += "where timeCreated >= GETDATE() - YEAR(1)";
                }
            }
            else
            {
                //Делаем отчет по времени для весов ВП
                query += "where timeCreated >= '" + GetTimeFromVp() + "' and timeCreated <= '" + GetTimeToVp()+"'";
            }
            query += " order by timeCreated asc";
            var dt = DbConnect.GetDbInstance().PerformQuery(query);
            if (!AreTablesTheSame(dt, _currentVp503))
            {
                _currentVp503 = dt;
                if (dataGridViewVP503.InvokeRequired)
                {
                    dataGridViewVP503.Invoke(new MethodInvoker(() => dataGridViewVP503.DataSource = _currentVp503));
                }
                else
                {
                    dataGridViewVP503.DataSource = _currentVp503;
                }
                dataGridViewVP503.Refresh();
                if (dataGridViewVP503.Rows.Count > 1)
                    dataGridViewVP503.FirstDisplayedScrollingRowIndex = dataGridViewVP503.RowCount - 1;
                if (groupBoxVPTimeSelect.Enabled)
                    SelectAllRows(dataGridViewVP503);
                else
                {
                    dataGridViewVP503.ClearSelection();
                }
            }
        }
        //Получаем часть where для отчетов по ВП
        private string GetTimeToVp()
        {
            if(dateTimePickerReportTimeTo.Text != string.Empty)
                return dateTimePickerReportDateTo.Value.ToString("MM-dd-yyyy") + " " + dateTimePickerReportTimeTo.Text+":59";
            return DateTime.Now.ToString("MM-dd-yyyy HH:mm:ss");
        }

        //Получаем время для where при формировании отчета по ВП
        private string GetTimeFromVp()
        {
            if(dateTimePickerReportTimeFrom.Text != string.Empty)
                return dateTimePickerReportDateFrom.Value.ToString("MM-dd-yyyy") + " " + dateTimePickerReportTimeFrom.Text + ":00";
            return DateTime.Now.ToString("MM-dd-yyyy HH:mm:ss");
        }

        //Обновление DGV с весами ВП50-2
        private void UpdateVp502()
        {
            var query = "select name, task, cycles, bunker , production, timeCreated from dbo.vp502_stats ";
            if (!groupBoxVPTimeSelect.Enabled)
            {
                if (radioButtonVPMonth.Checked)
                {
                    query += "where timeCreated >= GETDATE() - DAY(30)";
                }
                if (radioButtonVPWeek.Checked)
                {
                    query += "where timeCreated >= GETDATE() - DAY(7)";
                }
                if (radioButtonVPYear.Checked)
                {
                    query += "where timeCreated >= GETDATE() - YEAR(1)";
                }
            }
            else
            {
                //Делаем отчет по времени для весов ВП
                query += "where timeCreated >= '" + GetTimeFromVp() + "' and timeCreated <= '" + GetTimeToVp() + "'";
            }
            query += " order by timeCreated asc";
            var dt = DbConnect.GetDbInstance().PerformQuery(query);
            if (!AreTablesTheSame(dt, _currentVp502))
            {
                _currentVp502 = dt;
                if (dataGridViewVP502.InvokeRequired)
                {
                    dataGridViewVP502.Invoke(new MethodInvoker(() => dataGridViewVP502.DataSource = _currentVp502));
                }
                else
                {
                    dataGridViewVP502.DataSource = _currentVp502;
                }
                dataGridViewVP502.Refresh();
                if (dataGridViewVP502.Rows.Count > 1)
                    dataGridViewVP502.FirstDisplayedScrollingRowIndex = dataGridViewVP502.RowCount - 1;
                if (groupBoxVPTimeSelect.Enabled)
                    SelectAllRows(dataGridViewVP502);
                else
                {
                    dataGridViewVP502.ClearSelection();
                }
            }
        }

        //Обновление DGV с весами ВП50-1
        private void UpdateVp501()
        {
            var query = "select name, task, cycles, bunker, production, timeCreated  from dbo.vp501_stats ";
            if (!groupBoxVPTimeSelect.Enabled)
            {
                if (radioButtonVPMonth.Checked)
                {
                    query += "where timeCreated >= GETDATE() - DAY(30)";
                }
                if (radioButtonVPWeek.Checked)
                {
                    query += "where timeCreated >= GETDATE() - DAY(7)";
                }
                if (radioButtonVPYear.Checked)
                {
                    query += "where timeCreated >= GETDATE() - YEAR(1)";
                }
            }
            else
            {
                //Делаем отчет по времени для весов ВП
                query += "where timeCreated >= '" + GetTimeFromVp() + "' and timeCreated <= '" + GetTimeToVp() + "'";
            }
            query += " order by timeCreated asc";
            var dt = DbConnect.GetDbInstance().PerformQuery(query);
            if (!AreTablesTheSame(dt, _currentVp501))
            {
                _currentVp501 = dt;
                if (dataGridViewVP501.InvokeRequired)
                {
                    dataGridViewVP501.Invoke(new MethodInvoker(() => dataGridViewVP501.DataSource = _currentVp501));
                }
                else
                {
                    dataGridViewVP501.DataSource = _currentVp501;
                }
                dataGridViewVP501.Refresh();
                if (dataGridViewVP501.Rows.Count > 1)
                    dataGridViewVP501.FirstDisplayedScrollingRowIndex = dataGridViewVP501.RowCount - 1;
                if (groupBoxVPTimeSelect.Enabled)
                    SelectAllRows(dataGridViewVP501);
                else
                {
                    dataGridViewVP501.ClearSelection();
                }
            }
        }

        //Обновление DGV с весами ВП150
        private void UpdateVp150()
        {
            var query = "select name," +
                        "Round(taskRight+taskLeft,2) as tasks," +
                        "cyclesLeft+cyclesRight as cycles," +
                        "fromBunker+N' → '+toBunker as direction," +
                        "ROUND(productionLeft+productionRight,2) as production," +
                        "timeCreate " +
                        "from dbo.vp150_stats ";
            if (checkBoxVP150Details.Checked) //Подробная информация в таблице или нет
            {
                query = "select name," +
                        "CONVERT(varchar(10),ROUND(taskLeft,2)) + N' + '+CONVERT(varchar(10),Round(taskRight,2))+N' = '+ CONVERT(varchar(10),Round(taskRight+taskLeft,2)) as tasks," +
                        "CONVERT(varchar(10), cyclesLeft) + N' + '+CONVERT(varchar(10),cyclesRight)+N' = '+ CONVERT(varchar(10),cyclesLeft+cyclesRight) as cycles," +
                        "fromBunker+N' → '+toBunker as direction," +
                        "CONVERT(varchar(10), ROUND(productionLeft,2)) + N' + '+CONVERT(varchar(10),ROUND(productionRight,2))+N' = '+ CONVERT(varchar(10),ROUND(productionLeft+productionRight,2)) as production," +
                        "timeCreate " +
                        "from dbo.vp150_stats ";
            }
            if (!groupBoxVPTimeSelect.Enabled)
            {
                if (radioButtonVPMonth.Checked)
                {
                    query += "where timeCreate >= GETDATE() - DAY(30)";
                }
                if (radioButtonVPWeek.Checked)
                {
                    query += "where timeCreate >= GETDATE() - DAY(7)";
                }
                if (radioButtonVPYear.Checked)
                {
                    query += "where timeCreate >= GETDATE() - YEAR(1)";
                }
            }
            else
            {
                //Делаем отчет по времени для весов ВП
                query += "where timeCreate >= '" + GetTimeFromVp() + "' and timeCreate <= '" + GetTimeToVp() + "'";
            }
            query += " order by timeCreate asc";
            var dt = DbConnect.GetDbInstance().PerformQuery(query);
            if (!AreTablesTheSame(dt, _currentVp150))
            {
                _currentVp150 = dt;
                if (dataGridViewVP150.InvokeRequired)
                {
                    dataGridViewVP150.Invoke(new MethodInvoker(() => dataGridViewVP150.DataSource = _currentVp150));
                }
                else
                {
                    dataGridViewVP150.DataSource = _currentVp150;
                }
                dataGridViewVP150.Refresh();
                if (dataGridViewVP150.Rows.Count > 1)
                    dataGridViewVP150.FirstDisplayedScrollingRowIndex = dataGridViewVP150.RowCount - 1;
                if(groupBoxVPTimeSelect.Enabled)
                    SelectAllRows(dataGridViewVP150);
                else
                {
                    dataGridViewVP150.ClearSelection();
                }
            }
        }
        //Выделить все строки в dgv
        private void SelectAllRows(DataGridView dgv)
        {
            foreach (DataGridViewRow r in dgv.Rows)
            {
                r.Selected = true;
            }
        }

        //Обновляем DGV отчета
        private void UpdateReport()
        {
            if (textBoxFromId.Text.Trim() == string.Empty && textBoxToId.Text.Trim() == string.Empty &&
                checkBoxByNumber.Checked)
            {
                MessageBox.Show("Необходимо указать номера первой и последней заявок для требуемого интервала",
                    "Внимание", MessageBoxButtons.OK,
                    MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1, (MessageBoxOptions)0x40000);
                return;
            }
            string query =
                "select id, name, weight, weightKK, weightFact, timeCreate, timeInProgress, timeFinished, isInProgress, isFinished, isFinishedErr from dbo.recipe where " +
                GetReportWhere();
            query += " order by id asc";
            DataTable dt = DbConnect.GetDbInstance().PerformQuery(query);
            if (dataGridViewReport.InvokeRequired)
            {
                dataGridViewReport.Invoke(new MethodInvoker(() => dataGridViewReport.DataSource = dt));
            }
            else
            {
                dataGridViewReport.DataSource = dt;
            }
            dataGridViewReport.Refresh();
            if (dataGridViewReport.Rows.Count > 1)
                dataGridViewReport.FirstDisplayedScrollingRowIndex = dataGridViewReport.RowCount - 1;
          //  ApplyColoringToReports();
        }

        //Раскрашиваем отчеты
      /*  private void ApplyColoringToReports()
        {
            foreach (DataGridViewRow r in dataGridViewReport.Rows)
            {
                //isFinished
                if (r.Cells[9].Value.ToString() == "True")
                {
                    r.DefaultCellStyle.BackColor = _finishedColor;
                    continue;
                }
                //isInProgress
                if (r.Cells[8].Value.ToString() == "True")
                {
                    r.DefaultCellStyle.BackColor = _inProgressColor;
                    continue;
                }
                //isFinishedErr
                if (r.Cells[10].Value.ToString() == "True")
                {
                    r.DefaultCellStyle.BackColor = _finisheByErrColor;
                    continue;
                }
                r.DefaultCellStyle.BackColor = Color.Empty;
            }
        }*/


        void dataGridViewReport_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (!((DataGridView)sender).Visible)
                return;
            foreach (DataGridViewRow r in ((DataGridView)sender).Rows)
            {
                if(r.Cells.Count<10)
                    return;
                //isFinished
                if (r.Cells[9].Value.ToString() == "True")
                {
                    r.DefaultCellStyle.BackColor = _finishedColor;
                    continue;
                }
                //isInProgress
                if (r.Cells[8].Value.ToString() == "True")
                {
                    r.DefaultCellStyle.BackColor = _inProgressColor;
                    continue;
                }
                //isFinishedErr
                if (r.Cells[10].Value.ToString() == "True")
                {
                    r.DefaultCellStyle.BackColor = _finisheByErrColor;
                    continue;
                }
                r.DefaultCellStyle.BackColor = Color.Empty;
            }
        }

        //Возвращает часть Where для запроса по состоянию выбранных контролов
        private string GetReportWhere()
        {
            string result = "";
            if (checkBoxByDate.Checked)
            {
                var from = dateTimePickerFrom.Value.ToString("yyyy-MM-dd");
                var to = dateTimePickerTo.Value.ToString("yyyy-MM-dd");
                result += " CAST(timeCreate as DATE) between '" + from + "' and '" + to + "'";
            }
            if (checkBoxByNumber.Checked)
            {
                if (checkBoxByDate.Checked)
                    result += " and ";
                if (textBoxFromId.Text.Trim() != string.Empty && textBoxToId.Text.Trim() == string.Empty)
                {
                    result += "(id >=" + textBoxFromId.Text.Trim() + ")";
                }
                if (textBoxFromId.Text.Trim() == string.Empty && textBoxToId.Text.Trim() != string.Empty)
                {
                    result += "(id <=" + textBoxToId.Text.Trim() + ")";
                }
                if (textBoxFromId.Text.Trim() != string.Empty && textBoxToId.Text.Trim() != string.Empty)
                {
                    result += "(id between " + textBoxFromId.Text.Trim() + " and " + textBoxToId.Text.Trim() + ")";
                }
            }
            //По статусу, если ничего не чекнули - значит все
            if (!checkBoxReportAll.Checked && !checkBoxReportNotFinished.Checked && !checkBoxReportFinished.Checked &&
                !checkBoxReportInProgress.Checked && !checkBoxReportNotFinished.Checked && !checkBoxReportError.Checked)  
                checkBoxReportAll.Checked = true;
            if (!checkBoxReportAll.Checked)
            {
                if (checkBoxByNumber.Checked || checkBoxByDate.Checked)
                    result += " and ";
                var j = 0;
                result += " (";
                if (checkBoxReportError.Checked)
                {
                    result += "(isFinishedErr='1')";
                    j++;
                }
                if (checkBoxReportFinished.Checked)
                {
                    if (j != 0)
                        result += " or ";
                    result += "(isInProgress='0' and isFinished='1' and isFinishedErr='0')";
                    j++;
                }
                if (checkBoxReportInProgress.Checked)
                {
                    if (j != 0)
                        result += " or ";
                    result += "(isInProgress='1' and isFinished='0' and isFinishedErr='0')";
                    j++;
                }
                if (checkBoxReportNotFinished.Checked)
                {
                    if (j != 0)
                        result += " or ";
                    result += "(isInProgress='0' and isFinished='0' and isFinishedErr='0')";
                }
                result += " ) ";
            }
            if (result.Trim().Equals(string.Empty))
                return "id > 0 ";
            result += " ";
            return result;
        }

        //При потере и подключении сбрасываем столбцы с таблице
        private void ClearDgv(DataGridView dgv)
        {
            if (dgv.Rows.Count > 0)
            {
                try
                {
                    dgv.Rows.Clear();
                }
                catch
                {
                    // ignored
                }
            }
            if (dgv.Columns.Count > 0)
            {
                try
                {
                    dgv.Columns.Clear();
                }
                catch
                {
                    // ignored
                }  
            }
        }
        //Заголовок для отчета по времени весов ВП
        private string GetHeaderForVp(string vpName)
        {
            return "Расход по весам "+vpName+"\nза период с "+dateTimePickerReportDateFrom.Value.ToString("dd/MM/yyyy") +
                " "+dateTimePickerReportTimeFrom.Value.ToString("HH:mm") +" по "+dateTimePickerReportDateTo.Value.ToString("dd/MM/yyyy")+
                " "+dateTimePickerReportTimeTo.Value.ToString("HH:mm")+".\nСмена №__    ________________\n                       Ф.И.О. мастера";
        }
    }
}