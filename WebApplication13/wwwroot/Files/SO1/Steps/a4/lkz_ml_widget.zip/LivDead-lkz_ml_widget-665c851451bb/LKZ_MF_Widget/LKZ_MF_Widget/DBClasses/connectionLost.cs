﻿using System;
using System.Windows.Forms;
using LKZ_MF_Widget.Settings;

namespace LKZ_MF_Widget.DBClasses
{
    public partial class ConnectionLost : Form
    {
        public ConnectionLost()
        {
            InitializeComponent();
            CenterToScreen();
            textBoxServerName.Text = widget.Default.dbLocation;
            string dbUserPass;
            using (var secureString = widget.Default.dbUserPassword.DecryptString())
            {
                dbUserPass = secureString.ToInsecureString();
            }
            textBoxPassword.Text = dbUserPass;
            textBoxUserName.Text = widget.Default.dbUserName;
            textBoxDbName.Text = widget.Default.dbName;
        }

        //Нажатие кнопки переподключения к базе
        private void buttonReconnect_Click(object sender, EventArgs e)
        {
            if (textBoxServerName.Text.Trim() == string.Empty) 
            {
                MessageBox.Show("Не указано имя сервера БД рецептов", "Ошибка", MessageBoxButtons.OK,
                    MessageBoxIcon.Error,MessageBoxDefaultButton.Button1, (MessageBoxOptions)0x40000);
                return;
            }
            if (textBoxUserName.Text.Trim() == string.Empty)
            {
                MessageBox.Show("Не указано имя пользователя", "Ошибка", MessageBoxButtons.OK,
                    MessageBoxIcon.Error, MessageBoxDefaultButton.Button1, (MessageBoxOptions)0x40000);
                return;
            }
            if (textBoxDbName.Text.Trim() == string.Empty)
            {
                MessageBox.Show("Не указано имя базы данных", "Ошибка", MessageBoxButtons.OK,
                    MessageBoxIcon.Error, MessageBoxDefaultButton.Button1, (MessageBoxOptions)0x40000);
                return;
            }
            var name = textBoxUserName.Text.Trim();
            var pass = textBoxPassword.Text.Trim();
            var location = textBoxServerName.Text.Trim();
            var dbName = textBoxDbName.Text.Trim();
            Enabled = false;
            DbConnect.GetDbInstance().TryReconnect(name, pass, location, dbName);
            Enabled = true;
        }

        //Восстанавливаем пароль по умолчанию
        private void buttonDefaults_Click(object sender, EventArgs e)
        {
            textBoxServerName.Text = widget.Default.dbLocationDefault;
            string dbUserPass;
         /*   using (var secureString = widget.Default.dbUserPasswordDefault.DecryptString())
            {
                dbUserPass = secureString.ToInsecureString();
            }*/
            dbUserPass = widget.Default.dbUserPasswordDefault;
            textBoxPassword.Text = dbUserPass;
            textBoxUserName.Text = widget.Default.dbUserNameDefault;
            textBoxDbName.Text = widget.Default.dbNameDefault;
        }

        private void buttonCancel_Click(object sender, EventArgs e)
        {
            Dispose();
        }

        //Метод для сохранения текущих настроек
        public void SaveSettings()
        {
            widget.Default.dbUserName = textBoxUserName.Text.Trim();
            widget.Default.dbLocation= textBoxServerName.Text.Trim();
            widget.Default.dbName = textBoxDbName.Text.Trim();
            using (var secureString = textBoxPassword.Text.Trim().ToSecureString())
            {
                widget.Default.dbUserPassword = secureString.EncryptString();
            }
            widget.Default.Save();
        }
    }
}