﻿using System;
using System.Data;
using System.Windows.Forms;
using LKZ_MF_Widget.DBClasses;

namespace LKZ_MF_Widget.MainView
{
    public partial class MainView
    {
        private string _idToUpdate = "";

        private void IngredientsInit()
        {
            groupBoxIngredient.Visible = false;
            buttonAddIngredient.Click += buttonAddIngredient_Clicked;
            buttonUpdateIngredient.Click += buttonUpdateIngredient_Clicked;
            buttonDeleteIngredient.Click += buttonDeleteIngredient_Clicked;
            buttonIngredientCancel.Click += buttonIngredientCancel_Clicked;
            buttonIngredientOk.Click += buttonIngredientOk_Clicked;
            InitDgvIngredients();
        }

        private void InitDgvIngredients()
        {
            ClearDgv(dataGridViewIngredients);
            for (var i = 0; i < 5; i++)
            {
                var column = new DataGridViewTextBoxColumn();
                dataGridViewIngredients.Columns.Add(column);
            }
            dataGridViewIngredients.Columns[0].DataPropertyName = "name";
            dataGridViewIngredients.Columns[0].Name = "Наименование";
            dataGridViewIngredients.Columns[0].HeaderText = "Наименование";

            dataGridViewIngredients.Columns[1].DataPropertyName = "comment";
            dataGridViewIngredients.Columns[1].Name = "Комментарий";
            dataGridViewIngredients.Columns[1].HeaderText = "Комментарий";

            dataGridViewIngredients.Columns[2].DataPropertyName = "timeUpdate";
            dataGridViewIngredients.Columns[2].Name = "Дата изменения";
            dataGridViewIngredients.Columns[2].HeaderText = "Дата изменения";
            dataGridViewIngredients.Columns[2].Width = 140;
            dataGridViewIngredients.Columns[2].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;

            dataGridViewIngredients.Columns[3].DataPropertyName = "timeCreate";
            dataGridViewIngredients.Columns[3].Name = "Дата создания";
            dataGridViewIngredients.Columns[3].HeaderText = "Дата создания";
            dataGridViewIngredients.Columns[3].Width = 140;
            dataGridViewIngredients.Columns[3].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;

            dataGridViewIngredients.Columns[4].DataPropertyName = "id";
            dataGridViewIngredients.Columns[4].Name = "id";
            dataGridViewIngredients.Columns[4].HeaderText = "id";
            dataGridViewIngredients.Columns[4].Visible = false;
        }

        private void buttonIngredientOk_Clicked(object sender, EventArgs e)
        {
            string query;
            if (textBoxIngredientName.Text.Trim() == string.Empty)
            {
                MessageBox.Show("Не указано наименование ингредиента", "Внимание", MessageBoxButtons.OK,
                    MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1, (MessageBoxOptions)0x40000);
                return;
            }
            if (buttonIngredientOk.Text == "Добавить")
            {
                var name = textBoxIngredientName.Text.Trim();
                var comment = "";
                if (textBoxIngredientComment.Text.Trim() != string.Empty)
                {
                    comment = textBoxIngredientComment.Text.Trim();
                }
                if (CheckIfNameExists(name))
                {
                    MessageBox.Show("Ингредиент '" + name + "' уже существует", "Внимание", MessageBoxButtons.OK,
                        MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, (MessageBoxOptions)0x40000);
                    return;
                }
                query = "insert into dbo.ingredient_list (name, comment) values (N'" + name + "',N'" + comment + "');";
            }
            else
            {
                if (_idToUpdate == string.Empty)
                {
                    MessageBox.Show("Ошибка изменения ингредиента", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1, (MessageBoxOptions)0x40000);
                    return;
                }
                query = "update dbo.ingredient_list set name = N'" + textBoxIngredientName.Text.Trim() +
                        "', comment = N'" + textBoxIngredientComment.Text.Trim() + "' where id = " + _idToUpdate + ";";
                _idToUpdate = "";
            }
            DbConnect.GetDbInstance().PerformNonQuery(query);
            ClearTextIngredientBoxes();
            groupBoxIngredient.Visible = false;
            flowLayoutPanelIngredientsButtons.Enabled = true;
            flowLayoutPanelIngredientsButtons.Visible = true;
            UpdateIngredientsView();
        }

        private void buttonIngredientCancel_Clicked(object sender, EventArgs e)
        {
            groupBoxIngredient.Visible = false;
            flowLayoutPanelIngredientsButtons.Enabled = true;
            flowLayoutPanelIngredientsButtons.Visible = true;
        }

        private void buttonDeleteIngredient_Clicked(object sender, EventArgs e)
        {
            var id = dataGridViewIngredients.SelectedRows[0].Cells[4].Value.ToString().Trim();
            var name = dataGridViewIngredients.SelectedRows[0].Cells[0].Value.ToString().Trim();
            var res = MessageBox.Show("Вы действительно хотите удалить ингредиент:\n" + name, "Внимание",
                MessageBoxButtons.YesNo, MessageBoxIcon.Asterisk, MessageBoxDefaultButton.Button1, (MessageBoxOptions)0x40000);
            if (res.Equals(DialogResult.No))
                return;
            var query = "delete from dbo.ingredient_list where id = " + id + ";";
            DbConnect.GetDbInstance().PerformNonQuery(query);
            UpdateIngredientsView();
        }

        private void buttonUpdateIngredient_Clicked(object sender, EventArgs e)
        {
            ClearTextIngredientBoxes();
            buttonIngredientOk.Text = "Изменить";
            flowLayoutPanelIngredientsButtons.Enabled = false;
            flowLayoutPanelIngredientsButtons.Visible = false;
            groupBoxIngredient.Visible = true;

            textBoxIngredientName.Text = dataGridViewIngredients.SelectedRows[0].Cells[0].Value.ToString();
            textBoxIngredientComment.Text = dataGridViewIngredients.SelectedRows[0].Cells[1].Value.ToString();
            _idToUpdate = dataGridViewIngredients.SelectedRows[0].Cells[4].Value.ToString();
        }

        private void buttonAddIngredient_Clicked(object sender, EventArgs e)
        {
            ClearTextIngredientBoxes();
            buttonIngredientOk.Text = "Добавить";
            flowLayoutPanelIngredientsButtons.Enabled = false;
            flowLayoutPanelIngredientsButtons.Visible = false;
            groupBoxIngredient.Visible = true;
        }

        private void ClearTextIngredientBoxes()
        {
            textBoxIngredientComment.Clear();
            textBoxIngredientName.Clear();
        }

        //Проверяем есть ли имя в базе  
        private bool CheckIfNameExists(string name)
        {
            //Позволяет добавлять ингредиенты отличающиеся только регистром букв
            /*var query = "select count(name) as cnt from dbo.ingredient_list where BINARY_CHECKSUM(name) = BINARY_CHECKSUM(N'" + name + "');";
            var dt = DbConnect.GetDbInstance().PerformQuery(query);
            if (dt.Rows.Count == 0)
            {
                return true;
            }
            foreach (DataRow r in dt.Rows)
            {
                try
                {
                    var res = Convert.ToInt32(r["cnt"]);
                    return res != 0;
                }
                catch
                {
                    return true;
                }
            }
            return true;*/
            string query = "select id from dbo.ingredient_list where name = N'" + name + "'";
            DataTable dt = DbConnect.GetDbInstance().PerformQuery(query);
            return dt.Rows.Count != 0;
        }
    }
}