﻿using System.Runtime.InteropServices;
using System.Windows.Forms;
using LKZ_MF_Widget.DBClasses;

namespace LKZ_MF_Widget.VPWeights
{
    [ProgId("LKZ_MF_Widget.Vp503")]
    [ComVisible(true)]
    [ClassInterface(ClassInterfaceType.None)]
    //Класс добавления и чтения статистики весов ВП50_3         
    public class Vp503
    {
        public Vp503()
        {
            ;
        }
        [ComVisible(true)]
        //Метод для добавления информации на весы ВП50_3           
        public void AddInfo(string name, float task, int cycles, float production, string bunker)
        {
            var query = "INSERT INTO dbo.vp503_stats (name,task,cycles,production,bunker) values (N'" + name + "'," +
                        task.ToString().Replace(",", ".") + "," + cycles + "," + production.ToString().Replace(",", ".") +
                        ",N'" + bunker.Trim() + "')";
            try
            {
                DbConnect.GetDbInstance().PerformNonQuery(query);
            }
            catch
            {
                MessageBox.Show("Не удалось записать данные о приеме сырья на весы ВП50-3", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1, (MessageBoxOptions)0x40000);
                return;
            }
            ExternalUpdater.ExternalUpdater.GetInstance().UpdateVp();
        }
    }
}