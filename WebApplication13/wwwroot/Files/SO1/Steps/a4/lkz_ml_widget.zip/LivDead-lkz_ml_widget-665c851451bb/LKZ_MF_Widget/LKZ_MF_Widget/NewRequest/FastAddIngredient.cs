﻿using System;
using System.Data;
using System.Windows.Forms;

namespace LKZ_MF_Widget.NewRequest
{
    public partial class FastAddIngredient : Form
    {
      //  public event AddIngredientEventArgs IngredientAdded; //сигнал о добавлении нового ингредиента
        public delegate void AddIngredientEventHandler(object sender, AddIngredientEventArgs args);
        public event AddIngredientEventHandler IngredientAdded; //сигнал о добавлении нового ингредиента
        public FastAddIngredient()
        {
            InitializeComponent();
            TopMost = true;
            CenterToParent();
        }

        private void buttonCancel_Click(object sender, EventArgs e)
        {
            Dispose();
        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
            string name = textBoxName.Text.Trim();
            if (name.Equals(string.Empty))
            {
                MessageBox.Show("Не указано наименование ингредиента", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1, (MessageBoxOptions)0x40000);
                return;
            }
            if (CheckIfExists())
            {
                MessageBox.Show("Ингредиент с таким именем уже существует", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1, (MessageBoxOptions)0x40000);
                return; 
            }
            string query = "insert into dbo.ingredient_list (name, comment) values (N'"+name+"',N'"+textBoxComment.Text.Trim()+"')";
            DBClasses.DbConnect.GetDbInstance().PerformNonQuery(query);
            if(IngredientAdded != null) IngredientAdded(this, new AddIngredientEventArgs(name));
            Dispose();
        }

        //Проверка существует ли ингредиент с таким именем
        private bool CheckIfExists()
        {
            string query = "select id from dbo.ingredient_list where name = N'"+textBoxName.Text.Trim()+"'";
            DataTable dt = DBClasses.DbConnect.GetDbInstance().PerformQuery(query);
            return dt.Rows.Count != 0;
        }
    }
}
