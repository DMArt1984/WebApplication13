﻿using System;
using System.Windows.Forms;

namespace LKZ_MF_Widget.ExternalUpdater
{
    //Статическая прокладка между VPWeights и MainView, используется для обновления view из SCADA
    internal class ExternalUpdater
    {
        private static ExternalUpdater _instance;
        public static event EventHandler VpUpdateRequired;
        public static event EventHandler RecipeUpdateRequired;
        public static event MessageBoxEventArgs.MessageBoxEventHandler MessageBoxRequired;

        public static ExternalUpdater GetInstance()
        {
            if (_instance == null)
                _instance = new ExternalUpdater();
            return _instance;
        }

        public void UpdateVp()
        {
            if (VpUpdateRequired != null)
                VpUpdateRequired(this, new EventArgs());
        }

        public void UpdateRecipe()
        {
            if (RecipeUpdateRequired != null)
                RecipeUpdateRequired(this, new EventArgs());
        }

        public void ShowMessageBox(string message, string header, MessageBoxIcon icon)
        {
            if(MessageBoxRequired != null)
                MessageBoxRequired(this, new MessageBoxEventArgs(message, header, icon));
        }
    }
}