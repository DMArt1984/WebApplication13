﻿namespace LKZ_MF_Widget.RecipeDetails
{
    partial class RecipeDetails
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(RecipeDetails));
            this.tabControlMain = new System.Windows.Forms.TabControl();
            this.tabPageBasic = new System.Windows.Forms.TabPage();
            this.tableLayoutPanelBasic = new System.Windows.Forms.TableLayoutPanel();
            this.dataGridViewBasicStats = new System.Windows.Forms.DataGridView();
            this.labelRecipe = new System.Windows.Forms.Label();
            this.dataGridViewRecipe = new System.Windows.Forms.DataGridView();
            this.tabPageDoseDetails = new System.Windows.Forms.TabPage();
            this.tableLayoutPanelDetails = new System.Windows.Forms.TableLayoutPanel();
            this.dataGridViewBatches = new System.Windows.Forms.DataGridView();
            this.labelBatches = new System.Windows.Forms.Label();
            this.labelPriority = new System.Windows.Forms.Label();
            this.dataGridViewPriority = new System.Windows.Forms.DataGridView();
            this.panelNavigateBatches = new System.Windows.Forms.Panel();
            this.buttonLeft = new System.Windows.Forms.Button();
            this.labelBatchNumber = new System.Windows.Forms.Label();
            this.buttonRight = new System.Windows.Forms.Button();
            this.trackBarBatchNum = new System.Windows.Forms.TrackBar();
            this.tabControlMain.SuspendLayout();
            this.tabPageBasic.SuspendLayout();
            this.tableLayoutPanelBasic.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewBasicStats)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewRecipe)).BeginInit();
            this.tabPageDoseDetails.SuspendLayout();
            this.tableLayoutPanelDetails.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewBatches)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewPriority)).BeginInit();
            this.panelNavigateBatches.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarBatchNum)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControlMain
            // 
            this.tabControlMain.Controls.Add(this.tabPageBasic);
            this.tabControlMain.Controls.Add(this.tabPageDoseDetails);
            this.tabControlMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControlMain.Location = new System.Drawing.Point(0, 0);
            this.tabControlMain.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tabControlMain.Name = "tabControlMain";
            this.tabControlMain.SelectedIndex = 0;
            this.tabControlMain.Size = new System.Drawing.Size(898, 758);
            this.tabControlMain.TabIndex = 0;
            // 
            // tabPageBasic
            // 
            this.tabPageBasic.Controls.Add(this.tableLayoutPanelBasic);
            this.tabPageBasic.Location = new System.Drawing.Point(4, 29);
            this.tabPageBasic.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tabPageBasic.Name = "tabPageBasic";
            this.tabPageBasic.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tabPageBasic.Size = new System.Drawing.Size(890, 725);
            this.tabPageBasic.TabIndex = 0;
            this.tabPageBasic.Text = "Общее";
            this.tabPageBasic.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanelBasic
            // 
            this.tableLayoutPanelBasic.ColumnCount = 1;
            this.tableLayoutPanelBasic.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanelBasic.Controls.Add(this.dataGridViewBasicStats, 0, 0);
            this.tableLayoutPanelBasic.Controls.Add(this.labelRecipe, 0, 1);
            this.tableLayoutPanelBasic.Controls.Add(this.dataGridViewRecipe, 0, 2);
            this.tableLayoutPanelBasic.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanelBasic.Location = new System.Drawing.Point(4, 5);
            this.tableLayoutPanelBasic.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tableLayoutPanelBasic.Name = "tableLayoutPanelBasic";
            this.tableLayoutPanelBasic.RowCount = 3;
            this.tableLayoutPanelBasic.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 277F));
            this.tableLayoutPanelBasic.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 29F));
            this.tableLayoutPanelBasic.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanelBasic.Size = new System.Drawing.Size(882, 715);
            this.tableLayoutPanelBasic.TabIndex = 0;
            // 
            // dataGridViewBasicStats
            // 
            this.dataGridViewBasicStats.AllowUserToAddRows = false;
            this.dataGridViewBasicStats.AllowUserToDeleteRows = false;
            this.dataGridViewBasicStats.AllowUserToResizeColumns = false;
            this.dataGridViewBasicStats.AllowUserToResizeRows = false;
            this.dataGridViewBasicStats.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewBasicStats.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewBasicStats.ColumnHeadersVisible = false;
            this.dataGridViewBasicStats.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridViewBasicStats.Location = new System.Drawing.Point(4, 5);
            this.dataGridViewBasicStats.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.dataGridViewBasicStats.Name = "dataGridViewBasicStats";
            this.dataGridViewBasicStats.ReadOnly = true;
            this.dataGridViewBasicStats.RowHeadersVisible = false;
            this.dataGridViewBasicStats.Size = new System.Drawing.Size(874, 267);
            this.dataGridViewBasicStats.TabIndex = 0;
            // 
            // labelRecipe
            // 
            this.labelRecipe.AutoSize = true;
            this.labelRecipe.Location = new System.Drawing.Point(4, 282);
            this.labelRecipe.Margin = new System.Windows.Forms.Padding(4, 5, 4, 0);
            this.labelRecipe.Name = "labelRecipe";
            this.labelRecipe.Size = new System.Drawing.Size(68, 20);
            this.labelRecipe.TabIndex = 1;
            this.labelRecipe.Text = "Рецепт ";
            // 
            // dataGridViewRecipe
            // 
            this.dataGridViewRecipe.AllowUserToAddRows = false;
            this.dataGridViewRecipe.AllowUserToDeleteRows = false;
            this.dataGridViewRecipe.AllowUserToResizeColumns = false;
            this.dataGridViewRecipe.AllowUserToResizeRows = false;
            this.dataGridViewRecipe.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewRecipe.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewRecipe.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridViewRecipe.Location = new System.Drawing.Point(4, 311);
            this.dataGridViewRecipe.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.dataGridViewRecipe.Name = "dataGridViewRecipe";
            this.dataGridViewRecipe.ReadOnly = true;
            this.dataGridViewRecipe.RowHeadersVisible = false;
            this.dataGridViewRecipe.Size = new System.Drawing.Size(874, 399);
            this.dataGridViewRecipe.TabIndex = 2;
            // 
            // tabPageDoseDetails
            // 
            this.tabPageDoseDetails.Controls.Add(this.tableLayoutPanelDetails);
            this.tabPageDoseDetails.Location = new System.Drawing.Point(4, 29);
            this.tabPageDoseDetails.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tabPageDoseDetails.Name = "tabPageDoseDetails";
            this.tabPageDoseDetails.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tabPageDoseDetails.Size = new System.Drawing.Size(890, 725);
            this.tabPageDoseDetails.TabIndex = 1;
            this.tabPageDoseDetails.Text = "Подробно";
            this.tabPageDoseDetails.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanelDetails
            // 
            this.tableLayoutPanelDetails.ColumnCount = 1;
            this.tableLayoutPanelDetails.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanelDetails.Controls.Add(this.dataGridViewBatches, 0, 3);
            this.tableLayoutPanelDetails.Controls.Add(this.labelBatches, 0, 2);
            this.tableLayoutPanelDetails.Controls.Add(this.labelPriority, 0, 0);
            this.tableLayoutPanelDetails.Controls.Add(this.dataGridViewPriority, 0, 1);
            this.tableLayoutPanelDetails.Controls.Add(this.panelNavigateBatches, 0, 4);
            this.tableLayoutPanelDetails.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanelDetails.Location = new System.Drawing.Point(4, 5);
            this.tableLayoutPanelDetails.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tableLayoutPanelDetails.Name = "tableLayoutPanelDetails";
            this.tableLayoutPanelDetails.RowCount = 5;
            this.tableLayoutPanelDetails.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 31F));
            this.tableLayoutPanelDetails.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 320F));
            this.tableLayoutPanelDetails.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35F));
            this.tableLayoutPanelDetails.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanelDetails.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 62F));
            this.tableLayoutPanelDetails.Size = new System.Drawing.Size(882, 715);
            this.tableLayoutPanelDetails.TabIndex = 0;
            // 
            // dataGridViewBatches
            // 
            this.dataGridViewBatches.AllowUserToAddRows = false;
            this.dataGridViewBatches.AllowUserToDeleteRows = false;
            this.dataGridViewBatches.AllowUserToResizeColumns = false;
            this.dataGridViewBatches.AllowUserToResizeRows = false;
            this.dataGridViewBatches.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewBatches.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewBatches.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridViewBatches.Location = new System.Drawing.Point(4, 391);
            this.dataGridViewBatches.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.dataGridViewBatches.MultiSelect = false;
            this.dataGridViewBatches.Name = "dataGridViewBatches";
            this.dataGridViewBatches.ReadOnly = true;
            this.dataGridViewBatches.RowHeadersVisible = false;
            this.dataGridViewBatches.Size = new System.Drawing.Size(874, 257);
            this.dataGridViewBatches.TabIndex = 3;
            // 
            // labelBatches
            // 
            this.labelBatches.AutoSize = true;
            this.labelBatches.Location = new System.Drawing.Point(4, 359);
            this.labelBatches.Margin = new System.Windows.Forms.Padding(4, 8, 4, 0);
            this.labelBatches.Name = "labelBatches";
            this.labelBatches.Size = new System.Drawing.Size(67, 20);
            this.labelBatches.TabIndex = 2;
            this.labelBatches.Text = "Отвесы";
            // 
            // labelPriority
            // 
            this.labelPriority.AutoSize = true;
            this.labelPriority.Location = new System.Drawing.Point(4, 8);
            this.labelPriority.Margin = new System.Windows.Forms.Padding(4, 8, 4, 0);
            this.labelPriority.Name = "labelPriority";
            this.labelPriority.Size = new System.Drawing.Size(197, 20);
            this.labelPriority.TabIndex = 0;
            this.labelPriority.Text = "Приоритет дозирования";
            // 
            // dataGridViewPriority
            // 
            this.dataGridViewPriority.AllowUserToAddRows = false;
            this.dataGridViewPriority.AllowUserToDeleteRows = false;
            this.dataGridViewPriority.AllowUserToResizeColumns = false;
            this.dataGridViewPriority.AllowUserToResizeRows = false;
            this.dataGridViewPriority.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewPriority.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewPriority.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridViewPriority.Location = new System.Drawing.Point(4, 36);
            this.dataGridViewPriority.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.dataGridViewPriority.MultiSelect = false;
            this.dataGridViewPriority.Name = "dataGridViewPriority";
            this.dataGridViewPriority.ReadOnly = true;
            this.dataGridViewPriority.RowHeadersVisible = false;
            this.dataGridViewPriority.Size = new System.Drawing.Size(874, 310);
            this.dataGridViewPriority.TabIndex = 1;
            // 
            // panelNavigateBatches
            // 
            this.panelNavigateBatches.Controls.Add(this.trackBarBatchNum);
            this.panelNavigateBatches.Controls.Add(this.buttonLeft);
            this.panelNavigateBatches.Controls.Add(this.labelBatchNumber);
            this.panelNavigateBatches.Controls.Add(this.buttonRight);
            this.panelNavigateBatches.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelNavigateBatches.Location = new System.Drawing.Point(4, 658);
            this.panelNavigateBatches.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.panelNavigateBatches.Name = "panelNavigateBatches";
            this.panelNavigateBatches.Size = new System.Drawing.Size(874, 52);
            this.panelNavigateBatches.TabIndex = 4;
            // 
            // buttonLeft
            // 
            this.buttonLeft.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.buttonLeft.Location = new System.Drawing.Point(0, 0);
            this.buttonLeft.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.buttonLeft.Name = "buttonLeft";
            this.buttonLeft.Size = new System.Drawing.Size(112, 51);
            this.buttonLeft.TabIndex = 3;
            this.buttonLeft.Text = "◄";
            this.buttonLeft.UseVisualStyleBackColor = true;
            this.buttonLeft.Click += new System.EventHandler(this.buttonLeft_Click);
            // 
            // labelBatchNumber
            // 
            this.labelBatchNumber.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.labelBatchNumber.AutoSize = true;
            this.labelBatchNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.labelBatchNumber.Location = new System.Drawing.Point(364, 7);
            this.labelBatchNumber.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelBatchNumber.Name = "labelBatchNumber";
            this.labelBatchNumber.Size = new System.Drawing.Size(75, 20);
            this.labelBatchNumber.TabIndex = 2;
            this.labelBatchNumber.Text = "Отвес №";
            // 
            // buttonRight
            // 
            this.buttonRight.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonRight.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.buttonRight.Location = new System.Drawing.Point(761, 0);
            this.buttonRight.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.buttonRight.Name = "buttonRight";
            this.buttonRight.Size = new System.Drawing.Size(112, 51);
            this.buttonRight.TabIndex = 1;
            this.buttonRight.Text = "►";
            this.buttonRight.UseVisualStyleBackColor = true;
            this.buttonRight.Click += new System.EventHandler(this.buttonRight_Click);
            // 
            // trackBarBatchNum
            // 
            this.trackBarBatchNum.AutoSize = false;
            this.trackBarBatchNum.BackColor = System.Drawing.SystemColors.Window;
            this.trackBarBatchNum.Location = new System.Drawing.Point(326, 26);
            this.trackBarBatchNum.Name = "trackBarBatchNum";
            this.trackBarBatchNum.Size = new System.Drawing.Size(232, 23);
            this.trackBarBatchNum.TabIndex = 4;
            this.trackBarBatchNum.TickStyle = System.Windows.Forms.TickStyle.None;
            this.trackBarBatchNum.ValueChanged += new System.EventHandler(this.trackBarBatchNum_ValueChanged);
            // 
            // RecipeDetails
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(898, 758);
            this.Controls.Add(this.tabControlMain);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "RecipeDetails";
            this.Text = "Рецепт № ";
            this.tabControlMain.ResumeLayout(false);
            this.tabPageBasic.ResumeLayout(false);
            this.tableLayoutPanelBasic.ResumeLayout(false);
            this.tableLayoutPanelBasic.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewBasicStats)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewRecipe)).EndInit();
            this.tabPageDoseDetails.ResumeLayout(false);
            this.tableLayoutPanelDetails.ResumeLayout(false);
            this.tableLayoutPanelDetails.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewBatches)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewPriority)).EndInit();
            this.panelNavigateBatches.ResumeLayout(false);
            this.panelNavigateBatches.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarBatchNum)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControlMain;
        private System.Windows.Forms.TabPage tabPageBasic;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelBasic;
        private System.Windows.Forms.DataGridView dataGridViewBasicStats;
        private System.Windows.Forms.Label labelRecipe;
        private System.Windows.Forms.DataGridView dataGridViewRecipe;
        private System.Windows.Forms.TabPage tabPageDoseDetails;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelDetails;
        private System.Windows.Forms.DataGridView dataGridViewBatches;
        private System.Windows.Forms.Label labelBatches;
        private System.Windows.Forms.Label labelPriority;
        private System.Windows.Forms.DataGridView dataGridViewPriority;
        private System.Windows.Forms.Panel panelNavigateBatches;
        private System.Windows.Forms.Button buttonLeft;
        private System.Windows.Forms.Label labelBatchNumber;
        private System.Windows.Forms.Button buttonRight;
        private System.Windows.Forms.TrackBar trackBarBatchNum;
    }
}