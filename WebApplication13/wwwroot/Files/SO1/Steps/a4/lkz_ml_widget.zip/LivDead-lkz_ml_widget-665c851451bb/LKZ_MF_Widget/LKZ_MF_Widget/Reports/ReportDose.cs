﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.Windows.Forms;
using iTextSharp.awt.geom;
using iTextSharp.text;
using iTextSharp.text.pdf;
using LKZ_MF_Widget.RecipeDetails;

namespace LKZ_MF_Widget.Reports
{
    
    //Класс для сохранения отчетов
    class ReportDose
    {
        private List<string> _idsList;
        private bool _detailed;
        private bool _technological;
        private Font _f; //шрифт для печати
        private readonly int _tolerance = 3; //точность округления 
        private string _folderPath = "";
        private bool _print = false;
        private double _toleranceAbs = 0.001f;


        public ReportDose(List<string> idsList, bool detailed = false, bool technological = false)
        {
            _idsList = idsList;
            _detailed = detailed;
            _technological = technological;
            var fontsfolder = Environment.GetFolderPath(Environment.SpecialFolder.Fonts);
            var baseFont = BaseFont.CreateFont(fontsfolder + "\\times.ttf", BaseFont.IDENTITY_H, BaseFont.EMBEDDED);
            _f = new Font(baseFont, 11);
        }

        public void SaveReport()
        {
            MakeReport(false);
        }

        public void PrintReport()
        {
            MakeReport(true);
        }
        //Признак бухгалтерского отчета
        public bool IsAccounting { get; set; }

        private void InvokeReport()
        {
            using (var stream = new FileStream(_folderPath + ".pdf", FileMode.Create))
            {
                var pdfDoc = new Document(PageSize.A4, 20f, 20f, 30f, 30f); //Для альбомной добавить к А4.Rotate()
                var fontsfolder = Environment.GetFolderPath(Environment.SpecialFolder.Fonts);
                var baseFont = BaseFont.CreateFont(fontsfolder + "\\times.ttf", BaseFont.IDENTITY_H, BaseFont.EMBEDDED);
                var f = new Font(baseFont, 5);
                PdfWriter.GetInstance(pdfDoc, stream);
                pdfDoc.Open();
                Paragraph para = new Paragraph();
                if (_idsList.Count != 1)
                {
                    para = new Paragraph("Отчет по выработке комбикорма", new Font(f) { Size = 18 })
                    {
                        Alignment = Element.ALIGN_CENTER,
                        SpacingAfter = 10f,
                        SpacingBefore = 0f
                    };
                }
                else
                {
                    para = new Paragraph("Отчет по выработке комбикорма " + GetPlaceById(_idsList[0]), new Font(f) { Size = 18 })
                    {
                        Alignment = Element.ALIGN_CENTER,
                        SpacingAfter = 10f,
                        SpacingBefore = 0f
                    };
                }

                var whitespace = new Paragraph("      ", new Font(f) { Size = 18 })
                {
                    Alignment = Element.ALIGN_CENTER,
                    SpacingAfter = 10f,
                    SpacingBefore = 0f
                };
                pdfDoc.Add(para);
                for (int i = 0; i < _idsList.Count; i++)
                {
                    pdfDoc.Add(GetMainStats(_idsList[i]));
                    pdfDoc.Add(GetDoseTotal(_idsList[i]));
                    if (_detailed || _technological)
                    {
                        pdfDoc.Add(whitespace);
                        pdfDoc.Add(GetPriority(_idsList[i]));
                        List<IElement> bathces = GetBatches(_idsList[i]);
                        for (int j = 0; j < bathces.Count; j++)
                        {
                            pdfDoc.Add(bathces[j]);
                        }
                    }
                    pdfDoc.Add(whitespace);
                }
                if (IsAccounting)
                {
                    pdfDoc.Add(new Phrase("Аппаратчик-дозаторщик  ____________________________ \n\n",
                        new Font(f) { Size = 12 }));
                    pdfDoc.Add(new Phrase("Мастер смены                   ____________________________ \n\n",
                        new Font(f) { Size = 12 }));
                }
                pdfDoc.Add(new Phrase("Сформировано " + DateTime.Now, new Font(f) { Size = 8 }));
                pdfDoc.Close();
                stream.Close();
            }
            if (_print)
            {
                TryPrint(_folderPath);
            }
            else
            {
                TryOpen(_folderPath);
            }
        }

        private void MakeReport(bool print)
        {
            var fontsfolder = Environment.GetFolderPath(Environment.SpecialFolder.Fonts);
            var baseFont = BaseFont.CreateFont(fontsfolder + "\\times.ttf", BaseFont.IDENTITY_H, BaseFont.EMBEDDED);
            var f = new Font(baseFont, 5);
            _folderPath = GetPath(print);
            if(_folderPath.Equals(string.Empty))
                return;
            MethodInvoker mi = new MethodInvoker(InvokeReport);
            this._print = print;
            mi.BeginInvoke(null, null);
            /* using (var stream = new FileStream(folderPath + ".pdf", FileMode.Create))
            {
               var pdfDoc = new Document(PageSize.A4, 20f, 20f, 30f, 30f); //Для альбомной добавить к А4.Rotate()
                PdfWriter.GetInstance(pdfDoc, stream);
                pdfDoc.Open();
                Paragraph para = new Paragraph();
                if (_idsList.Count != 1)
                {
                    para = new Paragraph("Отчет по выработке комбикорма", new Font(f) {Size = 18})
                    {
                        Alignment = Element.ALIGN_CENTER,
                        SpacingAfter = 10f,
                        SpacingBefore = 0f
                    };
                }
                else 
                {
                    para = new Paragraph("Отчет по выработке комбикорма "+ GetPlaceById(_idsList[0]), new Font(f) { Size = 18 })
                    {
                        Alignment = Element.ALIGN_CENTER,
                        SpacingAfter = 10f,
                        SpacingBefore = 0f
                    };  
                }

                var whitespace = new Paragraph("      ", new Font(f) { Size = 18 })
                {
                    Alignment = Element.ALIGN_CENTER,
                    SpacingAfter = 10f,
                    SpacingBefore = 0f
                };
                pdfDoc.Add(para);
                for(int i=0;i<_idsList.Count;i++)
                {
                    pdfDoc.Add(GetMainStats(_idsList[i]));
                    pdfDoc.Add(GetDoseTotal(_idsList[i]));
                    if (_detailed)
                    {
                        pdfDoc.Add(whitespace);
                        pdfDoc.Add(GetPriority(_idsList[i]));
                        List<IElement> bathces = GetBatches(_idsList[i]);
                        for (int j = 0; j < bathces.Count; j++)
                        {
                            pdfDoc.Add(bathces[j]);
                        }
                    }
                    pdfDoc.Add(whitespace);
                }
                if (IsAccounting)
                {
                    pdfDoc.Add(new Phrase("Аппаратчик-дозаторщик  ____________________________ \n\n",
                        new Font(f) { Size = 12 }));
                    pdfDoc.Add(new Phrase("Мастер смены                   ____________________________ \n\n",
                        new Font(f) {Size = 12}));
                }
                pdfDoc.Add(new Phrase("Сформировано " + DateTime.Now, new Font(f) { Size = 8 }));
                pdfDoc.Close();
                stream.Close();
            }
            if (print)
            {
                TryPrint(folderPath);
            }
            else
            {
                TryOpen(folderPath);
            }*/
        }
        //Метод для формирования имени линии в заголовке отчета по одному рецепту
        private string GetPlaceById(string id)
        {
            var query = "select place from dbo.recipe where id = " + id;
            DataTable dt = DBClasses.DbConnect.GetDbInstance().PerformQuery(query);
            if (dt.Rows.Count != 1)
                return "";
            switch (dt.Rows[0]["place"].ToString().Trim())
            {
                case "W2":
                {
                    return "ОД линия 1";
                }
                case "W4":
                {
                    return "ОД линия 2";
                }
                case "W5":
                {
                    return "ПД линия 2";
                }
                case "W6":
                {
                    return "ПД линия 1";
                }
                default:
                {
                    return "";
                }

            }
        }

        //Получаем таблицу с приоритетами для рецепта
        private IElement GetPriority(string id)
        {
            int ident = Convert.ToInt32(id);
            StatsGetter getter = new StatsGetter(ident);
            DataTable stats = getter.GetPriorities(ident);
            var pdfTable = new PdfPTable(3) { HorizontalAlignment = Element.ALIGN_CENTER };
            pdfTable.DefaultCell.Padding = 3;
            pdfTable.WidthPercentage = 100;
            pdfTable.HorizontalAlignment = Element.ALIGN_LEFT;
            pdfTable.DefaultCell.Phrase = new Phrase { Font = _f };
            pdfTable.DefaultCell.VerticalAlignment = Element.ALIGN_CENTER;
            //Делаем заголовок для таблицы
            List<string> header = new List<string>
            {
                "Бункер",
                "Наименование",
                "Приоритет"
            };
            for (int i = 0; i < header.Count; i++)
            {
                var num = new PdfPCell(new Phrase(header[i], _f))
                {
                    BackgroundColor = new BaseColor(240, 240, 240)
                };
                pdfTable.AddCell(num);
            }
            //Заполняем таблицу данными
            for (int i = 0; i < stats.Rows.Count; i++)
            {
                string bunker = stats.Rows[i]["bunker"].ToString();
                pdfTable.AddCell(new PdfPCell(new Phrase(bunker, _f)));
                string name = stats.Rows[i]["name"].ToString();
                pdfTable.AddCell(new PdfPCell(new Phrase(name, _f)));
                string percentage = stats.Rows[i]["priority"].ToString();
                pdfTable.AddCell(new PdfPCell(new Phrase(percentage, _f)));
            }
            return pdfTable;
        }

        //Сумма по дозированию
        private IElement GetDoseTotal(string id)
        {
            int ident = Convert.ToInt32(id);
            StatsGetter getter = new StatsGetter(ident);
            DataTable stats = getter.GetRecipe(ident);

            var pdfTable = new PdfPTable(7) { HorizontalAlignment = Element.ALIGN_CENTER };
            float[] widths = { 61f, 100f, 100f, 100f, 100f, 100f, 100f };
            pdfTable.SetWidths(widths);
            pdfTable.DefaultCell.Padding = 3;
            pdfTable.WidthPercentage = 100;
            pdfTable.HorizontalAlignment = Element.ALIGN_LEFT;
            pdfTable.DefaultCell.Phrase = new Phrase { Font = _f };
            pdfTable.DefaultCell.VerticalAlignment = Element.ALIGN_CENTER;
            //Делаем заголовок для таблицы
            List<string> header = new List<string>
            {
                "Бункер",
                "Наименование",
                "Доля в смеси, %",
                "Масса, кг.",
                "Фактическая масса, кг.",
                "Отклонение, кг.",
                "Отклонение, %"
            };
            for(int i=0;i<header.Count;i++)
            {
                var num = new PdfPCell(new Phrase(header[i], _f))
                {
                    BackgroundColor = new BaseColor(240, 240, 240)
                };
                pdfTable.AddCell(num);
            }
            float weightTotal = 0;
            float weightFactF = 0;
            float tmp = 0;
            //Заполняем таблицу данными
            for (int i = 0; i < stats.Rows.Count; i++)
            {
                string bunker =stats.Rows[i]["bunker"].ToString();
                pdfTable.AddCell(new PdfPCell(new Phrase(bunker, _f)));
                string name =stats.Rows[i]["name"].ToString();
                pdfTable.AddCell(new PdfPCell(new Phrase(name, _f)));
                string percentage =stats.Rows[i]["percentage"].ToString();
                pdfTable.AddCell(new PdfPCell(new Phrase(percentage, _f)));
                string weight =stats.Rows[i]["weight"].ToString();
                try
                {
                    tmp = Convert.ToSingle(stats.Rows[i]["weight"].ToString().Replace(",","."));
                }
                catch (Exception)
                {
                    tmp = 0;
                }
                weightTotal += tmp;
                pdfTable.AddCell(new PdfPCell(new Phrase(weight, _f)));
                string weightFact =stats.Rows[i]["weightFact"].ToString();
                try
                {
                    tmp = Convert.ToSingle(stats.Rows[i]["weightFact"].ToString().Replace(",", "."));
                }
                catch (Exception)
                {
                    tmp = 0;
                }
                weightFactF += tmp;
                pdfTable.AddCell(new PdfPCell(new Phrase(weightFact, _f)));
                string devKilos =stats.Rows[i]["deviationKilos"].ToString();
                pdfTable.AddCell(new PdfPCell(new Phrase(devKilos, _f)));
                string devPerc = stats.Rows[i]["deviationPercentage"].ToString();
                pdfTable.AddCell(new PdfPCell(new Phrase(devPerc, _f)));
            }
            //Добавляем снизу подпись с "Итого"
            pdfTable.AddCell(new PdfPCell(){BorderWidth = 0});
            pdfTable.AddCell(new PdfPCell() { BorderWidth = 0});
            pdfTable.AddCell(new PdfPCell(new Phrase("Итого: ", _f)));
            pdfTable.AddCell(new PdfPCell(new Phrase(Math.Round(weightTotal,_tolerance).ToString(), _f)));
            pdfTable.AddCell(new PdfPCell(new Phrase(Math.Round(weightFactF,_tolerance).ToString(), _f)));
            pdfTable.AddCell(new PdfPCell(new Phrase(Math.Round(weightFactF - weightTotal, _tolerance).ToString(), _f)));
            pdfTable.AddCell(new PdfPCell(new Phrase(Math.Round((weightFactF - weightTotal)/(weightTotal/100), _tolerance).ToString(), _f)));
            return pdfTable;
        }
        //Таблицы с отвесами
        private List<IElement> GetBatches(string id)
        {
            List<IElement> result = new List<IElement>();
            int ident = Convert.ToInt32(id);
            StatsGetter getter = new StatsGetter(ident);
            List<int> batchesList = getter.GetBatchesList(ident);
            DataTable stats = new DataTable();
            if (!_technological)
            {
                stats = getter.GetBatches(ident);
            }
            else
            {
                stats = getter.GetTechnologicalBatches(ident);
            }
            //Делаем заголовок для таблицы
            List<string> header = new List<string>
            {
                "Бункер",
                "Наименование",
                "Масса, кг.",
                "Фактическая масса, кг.",
                "Отклонение, кг.",
                "Отклонение, %"
            };
            if (_technological)
            {
                header.Add("Ошибка дозирования, кг.");
                header.Add("Высота столба, кг.");
            }
            using (DataView dv = new DataView(stats))
            {
                for (int i = 0; i < batchesList.Count; i++)
                {
                    result.Add(new Phrase("Отвес № " + batchesList[i], _f));
                    var pdfTable = new PdfPTable(header.Count) { HorizontalAlignment = Element.ALIGN_CENTER };
                    List<float> widths =new List<float>{ 61f, 100f, 100f, 100f, 100f, 100f };
                    if (_technological)
                    {
                        widths.Add(100f);
                        widths.Add(100f);
                    }
                    pdfTable.SetWidths(widths.ToArray());
                    pdfTable.SpacingBefore = 0;
                    pdfTable.DefaultCell.Padding = 3;
                    pdfTable.WidthPercentage = 100;
                    pdfTable.HorizontalAlignment = Element.ALIGN_LEFT;
                    pdfTable.DefaultCell.Phrase = new Phrase { Font = _f };
                    pdfTable.DefaultCell.VerticalAlignment = Element.ALIGN_CENTER;
                    for (int j=0;j<header.Count;j++)
                    {
                        var num = new PdfPCell(new Phrase(header[j], _f))
                        {
                            BackgroundColor = new BaseColor(240, 240, 240)
                        };
                        pdfTable.AddCell(num);
                    }
                    dv.RowFilter = string.Format("batchNum = '{0}'", batchesList[i]);
                    foreach (DataRowView drv in dv)
                    {
                        DataRow r = drv.Row;
                        string bunker = r["bunker"].ToString();
                        if(bunker.Equals(string.Empty))
                            pdfTable.AddCell(new PdfPCell() { BorderWidth = 0 });
                        else
                            pdfTable.AddCell(new Phrase(bunker, _f));
                        string name = r["name"].ToString();
                        pdfTable.AddCell(new Phrase(name, _f));
                        string weight = r["weight"].ToString();
                        pdfTable.AddCell(new Phrase(weight, _f));
                        string weightFact = r["weightFact"].ToString();
                        pdfTable.AddCell(new Phrase(weightFact, _f));
                        string deviationKilos = r["deviationKilos"].ToString();
                        pdfTable.AddCell(new Phrase(deviationKilos, _f));
                        string deviationPercents = r["deviationPercents"].ToString();
                        pdfTable.AddCell(new Phrase(deviationPercents, _f));
                        if (_technological)
                        {
                            string doseError = r["doseErrorSize"].ToString();
                            pdfTable.AddCell(new Phrase(doseError, _f));
                            string fallingColumn = r["fallingColumnSize"].ToString();
                            pdfTable.AddCell(new Phrase(fallingColumn, _f));
                        }
                    }
                    result.Add(pdfTable);
                }
            }
            return result;
        }

        //Сводная таблица о статусе рецепта
        private IElement GetMainStats(string id)
        {
            var statNames = new List<string>{"Номер","Линия", "Название", "Качество", @"Задание на к/к, кг.",
              // Данные вынес из шапки под таблицу
                //  "Требуемый вес, кг.", "Фактический вес, кг.", "Отклонение, кг.", "Отклонение, %",
                "Статус", "Комментарий", "Служебная информация", "Создан", "Запущен в работу", "Завершен", "Продолжительность, мин."};
            StatsGetter getter = new StatsGetter(Convert.ToInt32(id));
            Dictionary<string, string> stats = getter.GetBasicStats(statNames, Convert.ToInt32(id));
            var pdfTable = new PdfPTable(2) { HorizontalAlignment = Element.ALIGN_CENTER };
            pdfTable.DefaultCell.Padding = 3;
            pdfTable.WidthPercentage = 100;
            pdfTable.HorizontalAlignment = Element.ALIGN_LEFT;
            pdfTable.DefaultCell.Phrase = new Phrase { Font = _f };
            pdfTable.DefaultCell.VerticalAlignment = Element.ALIGN_CENTER;
            foreach (KeyValuePair<string,string> pair in stats)
            {
                if (pair.Key.Equals("Номер"))
                {
                    var num = new PdfPCell(new Phrase(pair.Key, _f))
                    {
                        BackgroundColor = new BaseColor(240, 240, 240)
                    };
                    pdfTable.AddCell(num);
                    var idCell = new PdfPCell(new Phrase(pair.Value, _f))
                    {
                        BackgroundColor = new BaseColor(240, 240, 240)
                    };
                    pdfTable.AddCell(idCell);
                }
                else
                {
                    if (statNames.Contains(pair.Key)) 
                    {
                        pdfTable.AddCell(new PdfPCell(new Phrase(pair.Key, _f)));
                        pdfTable.AddCell(new PdfPCell(new Phrase(pair.Value, _f)));
                    }
                }
            }
            return pdfTable;
        }

        private string GetPath(bool print)
        {
            string folderPath = Path.GetPathRoot(Environment.SystemDirectory);
            folderPath += "Aseng\\ReportDose\\" + DateTime.Now.ToString("yy-MM-dd HH-MM-ss");
            //Спрашиваем куда сохранять
            if (!print)
            {
                var dlg = new SaveFileDialog(){Filter = "PDF (*.pdf)|*.pdf"};
                dlg.FileName = DateTime.Now.ToString("yy-MM-dd HH-MM-ss");

                if (dlg.ShowDialog() != DialogResult.OK) return "";
                folderPath = dlg.FileName;
            }
            if (folderPath != string.Empty)
                Directory.CreateDirectory(Path.GetDirectoryName(folderPath));
            else
            {
                MessageBox.Show("Неверно указан путь для записи");
                return "";
            }
            return folderPath;
        }

        //Для открытия файла pdf по пути до него
        private void TryOpen(string folderPath)
        {
            try
            {
                Process.Start(folderPath + ".pdf"); //открываем файл после сохранения
            }
            catch (Exception)
            {
                MessageBox.Show("Не удалось открыть файл отчета", "Ошибка", MessageBoxButtons.OK,
                    MessageBoxIcon.Error, MessageBoxDefaultButton.Button1, (MessageBoxOptions)0x40000);
            }
        }
        //Для печати файла pdf по пути до него
        private void TryPrint(string folderPath)
        {
            try
            {
                var sArgs = " /p \"" + folderPath + ".pdf" + "\"";
                var startInfo = new ProcessStartInfo
                {
                    FileName = @"C:\Program Files (x86)\Foxit Software\Foxit Reader\FoxitReader.exe",
                    Arguments = sArgs,
                    CreateNoWindow = true,
                    WindowStyle = ProcessWindowStyle.Hidden
                };
                var proc = Process.Start(startInfo);
                if (proc != null)
                {
                    proc.WaitForExit(10000); // Ждем 10 сек для закрытия
                    if (!proc.HasExited)
                    {
                        proc.Kill();
                        proc.Dispose();
                    }
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Не удалось распечатать файл отчета", "Ошибка", MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }
    }
}
