select LKZ_MF.dbo.recipe.id as id, LKZ_MF.dbo.recipe.name as RecipeName, LKZ_MF.dbo.recipe.weight as TotalWeight,  LKZ_MF.dbo.recipe_ingredient.name as IngredientName, 
LKZ_MF.dbo.recipe.place as place, LKZ_MF.dbo.recipe.timeCreate as timeCreate, LKZ_MF.dbo.recipe.timeFinished as timeFinished, LKZ_MF.dbo.recipe.weightKK as weightKK, 
ROUND(LKZ_MF.dbo.recipe_ingredient.percentage*LKZ_MF.Dbo.recipe.weight/100,2) as weight, LKZ_MF.dbo.recipe_ingredient.weightFact as weightFact,
ROUND(LKZ_MF.dbo.recipe_ingredient.weightFact - (LKZ_MF.dbo.recipe_ingredient.percentage*LKZ_MF.Dbo.recipe.weight/100),2) as devKg,
ROUND(((LKZ_MF.dbo.recipe_ingredient.weightFact - LKZ_MF.dbo.recipe_ingredient.percentage*LKZ_MF.Dbo.recipe.weight/100)
/((LKZ_MF.Dbo.recipe.weight*LKZ_MF.dbo.recipe_ingredient.percentage)/10000))
,2) as devPerc,
LKZ_MF.dbo.recipe.commentService as commentService
from LKZ_MF.dbo.recipe_ingredient inner join LKZ_MF.dbo.recipe on LKZ_MF.dbo.recipe.id = LKZ_MF.dbo.recipe_ingredient.id_recipe and id_recipe  > 300 order by id asc 