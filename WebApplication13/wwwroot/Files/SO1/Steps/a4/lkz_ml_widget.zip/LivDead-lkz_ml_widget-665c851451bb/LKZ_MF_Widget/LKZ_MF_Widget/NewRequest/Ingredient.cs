﻿using LKZ_MF_Widget.DBClasses;

namespace LKZ_MF_Widget.NewRequest
{
    //Класс для хранения и добавления ингредиентов для рецепта
    internal class Ingredient
    {
        private int _bunker;
        private int _idRecipe;
        private readonly float _percentage;
        private int _priority;
        public string Name;

        public Ingredient(string name, float percentage, int idRecipe)
        {
            Name = name;
            _percentage = percentage;
            _idRecipe = idRecipe;
        }

        public Ingredient(string name, float percentage, int idRecipe, int priority, int bunker)
        {
            Name = name;
            _percentage = percentage;
            _idRecipe = idRecipe;
            _bunker = bunker;
            _priority = priority;
        }


        //Устанавливаем приоритет для бункера
        public void SetBunkerPriority(int bunker, int priority)
        {
            _priority = priority;
            _bunker = bunker;
        }

        //Устанавливаем id рецепта
        public void SetRecipeId(int id)
        {
            _idRecipe = id;
        }

        //Сохранение ингредиента в базу
        public void SaveToDb()
        {
            
            var query = "insert into dbo.recipe_ingredient (id_recipe, name, percentage";
            if (_bunker != 0 && _priority != 0)
            {
                query += ", bunker, priority) values (" + _idRecipe + ",N'" + Name + "'," +
                         _percentage.ToString().Replace(",", ".") + "," + _bunker + "," + _priority + ");";
            }
            else
            {
                query += ") values (" + _idRecipe + ",N'" + Name + "'," + _percentage.ToString().Replace(",", ".") +
                         ");";
            }
            DbConnect.GetDbInstance().PerformNonQuery(query);
        }
    }
}