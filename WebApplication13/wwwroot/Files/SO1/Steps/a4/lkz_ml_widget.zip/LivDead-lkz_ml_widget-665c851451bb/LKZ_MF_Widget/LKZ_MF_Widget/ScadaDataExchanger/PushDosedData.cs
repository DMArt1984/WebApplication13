﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using LKZ_MF_Widget.DBClasses;

namespace LKZ_MF_Widget.ScadaDataExchanger
{
    //Возвращаем этот класс в скаду для чтения данных о заявке
    [ProgId("LKZ_MF_Widget.DoseData")]
    [ComVisible(true)]
    [ClassInterface(ClassInterfaceType.AutoDispatch)]
    public class PushDosedData
    {
        private float _tolerance = 0.001f;
        //ведем логи отвесов - сделано для ловли багов на ПЦ
        private static bool _loggingEnabled = true;
        //Сохранение скриншотов при дубликатах отвесов
        private static bool _screenshotsEnabled = true;
        //для отладки, чтобы не грузить базу запросам бункеров
        private static readonly List<int> _availableBunkers = new List<int>{7,8,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,71,
            72,160,161,162,163,165,166,170,171,172,175,178,185,186,188,189
        }; 
        //Таймер отсчета новых скриншотов, чтобы не создавать много одинаковых скринов
        private readonly Timer _screenshotTimeout = new Timer(){Interval = 5000}; 
        public PushDosedData()
        {
            _screenshotTimeout.Tick += (sender, args) => _screenshotTimeout.Stop();
        }
        
        //Принимаем данные о сдозированном материале. Берем номер бункера, плановую и фактическую дозу и номер отвеса, величину ошибки дозирования и высоту столба. 
        public void PushDataBatch(int bunkNum, float planned, float dosed, int batchNum, float errorSize = 0f, float columnSize = 0f)
        {
          //  if(Math.Abs(planned) < tolerance && Math.Abs(dosed) < tolerance)
             //  return;
            bool batchAlreadyExists = CheckIfBatchAlreadyExists(bunkNum, batchNum); // не дает писать дубликаты отвесов
            bool bunkerNotInUse = !CheckIfBunkerUsed(bunkNum); // не дает записывать бункеры, которые не используются
            if (_loggingEnabled && !bunkerNotInUse)
            {
                WriteLogBatch(bunkNum,planned,dosed,batchNum,batchAlreadyExists);
            }
            if(batchAlreadyExists || bunkerNotInUse) //Не дает записывать дубликаты отвесов
                return;

            var query = "insert into dbo.recipe_batch (id_ingredient, weight, weightFact, bunker, batchNum, name, fallingColumnSize, doseErrorSize) values (" +
                        "(select currentIngredientId from dbo.bunker_card where bunkNum = " + bunkNum + "), " +
                        planned.ToString().Replace(",", ".") + ", " + dosed.ToString().Replace(",", ".") + ", " +
                        bunkNum + ", " + batchNum + ",(select ingredient from dbo.bunker_card where bunkNum = " + bunkNum + "), "+columnSize.ToString().Replace(",",".")+","+
                        errorSize.ToString().Replace(",",".")+")";
            DbConnect.GetDbInstance().PerformNonQuery(query);
        }
        //Логгинг входных параметров - ловим убежавшие отвесы
        private void WriteLogBatch(int bunkNum, float planned, float dosed, int batchNum, bool duplicate = false,
            bool notInUse = false)
        {
            try
            {
                string logString = "- " + DateTime.Now.ToString("G") + ": ";
                if (duplicate)
                {
                    logString += "Error! Duplicate write attempt" + Environment.NewLine;
                    if (_screenshotsEnabled)
                    {
                        MethodInvoker invoker = WriteScreenshot;
                        invoker.Invoke();
                    }
                }
                if(notInUse)
                    logString += "Error! Tried to write not used bunker" + Environment.NewLine;
                if (Math.Abs(planned) < _tolerance)
                    logString += "Error! Planned weight = 0" + Environment.NewLine;
                if (Math.Abs(dosed) < _tolerance)
                    logString += "Error! Dosed weight = 0" + Environment.NewLine;
                if (batchNum == 0)
                    logString += "Error! Batch number = 0" + Environment.NewLine;
                if (!_availableBunkers.Contains(bunkNum))
                    logString += "Error! No such bunker: " + bunkNum + Environment.NewLine;
                logString += "Bunk = " + bunkNum + " ; Planned = " + Math.Round(planned, 3) +
                            " ; Dosed = " + Math.Round(dosed, 3) + " ; Batch num = " + batchNum +
                            " ;" + Environment.NewLine;
                FileInfo f = new FileInfo("c:\\Aseng\\WidgetBatchLog.txt");
                if (f.Exists)
                {
                    if (f.Length > 10485760)  // 10mb
                        return;
                }
                using (StreamWriter file = File.AppendText("c:\\Aseng\\WidgetBatchLog.txt"))
                {
                    file.WriteLine(logString);
                    file.Close();
                }

            }
            catch (Exception)
            {
                // ignored
            }
        }
        //Делаем скриншоты для логов
        public void WriteScreenshot()
        {
            if(_screenshotTimeout.Enabled)
                return;
            _screenshotTimeout.Start();
            var left = Screen.AllScreens.Min(screen => screen.Bounds.X);
            var top = Screen.AllScreens.Min(screen => screen.Bounds.Y);
            var right = Screen.AllScreens.Max(screen => screen.Bounds.X + screen.Bounds.Width);
            var bottom = Screen.AllScreens.Max(screen => screen.Bounds.Y + screen.Bounds.Height);
            var width = right - left;
            var height = bottom - top;

            using (var screenBmp = new Bitmap(width, height, PixelFormat.Format32bppArgb))
            {
                using (var bmpGraphics = Graphics.FromImage(screenBmp))
                {
                    bmpGraphics.CopyFromScreen(left, top, 0, 0, new Size(width, height));
                    var path = GetScreenShotName();
                    if(!path.Equals(string.Empty))
                        screenBmp.Save(path,ImageFormat.Jpeg);
                }
            }
        }
        //Выбираем место для сохранения скриншота
        private string GetScreenShotName()
        {
            var path = @"C:\Aseng\Screenshot\"+DateTime.Now.ToString("dd_MM_yyyy_(HH_mm_ss)")+".jpeg";
            var info = new FileInfo(path);
            if (info.DirectoryName == null)
                return string.Empty;
            if (!Directory.Exists(info.DirectoryName))
            {
                Directory.CreateDirectory(info.DirectoryName);
            }
            if (info.Exists)
                return string.Empty;
            if (info.Directory != null && info.Directory.GetFiles().Length > 1500)
                return string.Empty;
            return path;
        }


        //Проверяем существует ли уже отвес для заданного бункера и рецепта
        private bool CheckIfBatchAlreadyExists(int bunkNum, int batchNum)
        {
            var query =
                "select id from dbo.recipe_batch where id_ingredient = (select currentIngredientId from dbo.bunker_card where bunkNum = " +
                bunkNum + ") and  batchNum = " + batchNum + "; ";
            DataTable dt = DbConnect.GetDbInstance().PerformQuery(query);
            return dt.Rows.Count != 0;
        }

        //Проверяем используется ли бункер в текущих рецептах
        private bool CheckIfBunkerUsed(int bunkNum)
        {
            var query = "select bunkNum from dbo.bunker_card where isInUse = 1";
            DataTable dt = DbConnect.GetDbInstance().PerformQuery(query);
            List<string> bunkers = new List<string>();
            foreach (DataRow r in dt.Rows)
            {
                bunkers.Add(r["bunkNum"].ToString().Trim());
            }
            return bunkers.Contains(bunkNum.ToString());
        }

        //Перед завершением рецепта принимаем данные о том сколько материала сдозировано с бункера
        public void PushDataIngredient(int bunkNum, float dosed)
        {
            if(_loggingEnabled)
                WriteLogIngredient(bunkNum,dosed);
            var query = "update dbo.recipe_ingredient set weightFact = " + dosed.ToString().Replace(",", ".") +
                        "  where id_recipe = (select id from dbo.recipe where isInProgress = 1 and place = (select place from dbo.bunker_card where bunkNum = " +
                        bunkNum + ")) and bunker = " + bunkNum;
            DbConnect.GetDbInstance().PerformNonQuery(query);
        }
        //Ловим убежавшую статистику
        private void WriteLogIngredient(int bunkNum, float dosed)
        {
            try
            {
                string logString = "- " + DateTime.Now.ToString("G") + ":   ";
                if (Math.Abs(dosed) < _tolerance) 
                    logString += "Error! Dosed weight = 0" + Environment.NewLine;
                if (!_availableBunkers.Contains(bunkNum))
                    logString += "Error! No such bunker: " + bunkNum + Environment.NewLine;
                logString += "Bunker = " + bunkNum + " ;  Dosed weight = " + Math.Round(dosed, 3) + " ;" + Environment.NewLine;
                FileInfo f = new FileInfo("c:\\Aseng\\WidgetIngredientLog.txt");
                if (f.Exists)
                {
                    if (f.Length > 10485760)  // 10mb
                        return;
                }
                using (StreamWriter file = File.AppendText("c:\\Aseng\\WidgetIngredientLog.txt"))
                {
                    file.WriteLine(logString);
                    file.Close();
                }

            }
            catch (Exception)
            {
                // ignored
            }
        }

        //Для записи в базу информации о том что бункер был пропущен
        public void PushSkipData(int bunkNum, float dosed)
        {
            var query = "select id, commentService from dbo.recipe where isInProgress = 1 AND id in "+
                " (select dbo.recipe_ingredient.id_recipe from dbo.recipe_ingredient CROSS APPLY (values (id_recipe)) as X (id_recipe) where bunker = "+bunkNum+")";
            DataTable dt = DbConnect.GetDbInstance().PerformQuery(query);
            if (dt.Rows.Count != 1)
            {
              //  MessageBox.Show("Не удалось найти рецепт для записи пропуска бункера", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1, (MessageBoxOptions)0x40000);
                ExternalUpdater.ExternalUpdater.GetInstance().ShowMessageBox("Не удалось найти рецепт для записи пропуска бункера", "Внимание", MessageBoxIcon.Warning);
                return;
            }
            string curComment = dt.Rows[0]["commentService"].ToString().Trim();
            string id = dt.Rows[0]["id"].ToString().Trim();
            curComment += "Пропущен бункер "+bunkNum+" ("+Math.Round(dosed,2)+" кг., "+DateTime.Now.ToString("HH:mm:ss")+"); ";
            query = "update dbo.recipe set commentService = N'"+curComment+"' where id = "+id;
            DbConnect.GetDbInstance().PerformNonQuery(query);
        }

        //Метод для закрытия рецепта 
        private void FinishRecipe(string place, bool byErr, float wFact)
        {
            var weightFact = wFact.ToString().Replace(",", ".");
            var getId = "select id from dbo.recipe where place = '" + place + "' and isInProgress = 1";
            var dt = DbConnect.GetDbInstance().PerformQuery(getId);
            if (dt.Rows.Count != 1)
            {
              /*  MessageBox.Show("Ошибка при получении текущего рецепта с весов " + place, "Ошибка", MessageBoxButtons.OK,
                    MessageBoxIcon.Error);*/
                if (_loggingEnabled)
                    WriteLogRecipe(place, byErr, wFact, true);
                return;
            }
            if (_loggingEnabled)
                WriteLogRecipe(place, byErr, wFact);
            var idToUpdate = dt.Rows[0]["id"].ToString();
            var query = "update dbo.recipe set weightFact = " + weightFact + ", timeFinished = getdate() , isInProgress = 0, isFinishedErr = ";
            if (byErr)
            {
                query += " 1 , isFinished = 0 ";
            }
            else
            {
                query += " 0 , isFinished = 1 ";
            }
            query += "where id = " + idToUpdate;
            DbConnect.GetDbInstance().PerformQuery(query);
            //Сбрасываем задание на бункерах
            query =
                "update dbo.bunker_card set isInUse = 0, task = 0, currentPriority = 0, currentIngredientId = 0 where place = '" +
                place + "'";
            DbConnect.GetDbInstance().PerformNonQuery(query);
            
            //Убрал окна с выводом, СКАДА выводит сама
          /*  if (byErr)
            {
              //  MessageBox.Show("Рецепт № " + idToUpdate + " аварийно завершен", "Внимание", MessageBoxButtons.OK,
                //    MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1, (MessageBoxOptions)0x40000);
                ExternalUpdater.ExternalUpdater.GetInstance().ShowMessageBox("Рецепт № " + idToUpdate + " аварийно завершен", "Внимание", MessageBoxIcon.Warning);
            }
            else
            {
               // MessageBox.Show("Рецепт № " + idToUpdate + " успешно завершен", "Внимание", MessageBoxButtons.OK,
                //    MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, (MessageBoxOptions)0x40000);
                ExternalUpdater.ExternalUpdater.GetInstance().ShowMessageBox("Рецепт № " + idToUpdate + " успешно завершен", "Внимание", MessageBoxIcon.Information);
            }*/
            ExternalUpdater.ExternalUpdater.GetInstance().UpdateRecipe();
        }
        //Ловим убежавшую статистику
        private void WriteLogRecipe(string place, bool byErr, float wFact, bool noCurrentRecipe = false)
        {
            try
            {
                string logString = "- " + DateTime.Now.ToString("G") + ": ";
                if (Math.Abs(wFact) < _tolerance)
                    logString += "Error! Dosed weight = 0" + Environment.NewLine;
                if (noCurrentRecipe)
                    logString += "Error! Current recipe was not found on line " + place + " " + Environment.NewLine;
                if (byErr)
                    logString += "Recipe finished by error "+ Environment.NewLine;
                logString += "Place = " + place+ " ;  Dosed weight = " + Math.Round(wFact, 3) + " ;" + Environment.NewLine;
                FileInfo f = new FileInfo("c:\\Aseng\\WidgetRecipeLog.txt");
                if (f.Exists)
                {
                    if (f.Length > 10485760)  // 10mb
                        return;
                }
                using (StreamWriter file = File.AppendText("c:\\Aseng\\WidgetRecipeLog.txt"))
                {
                    file.WriteLine(logString);
                    file.Close();
                }

            }
            catch (Exception)
            {
                // ignored
            }
        }

        #region finishInterface

        //-------------------------------------------------------
        //Закрываем рецепт успешно
        public void finishRecipeOD1_W2(float dosed)
        {
            FinishRecipe("W2", false, dosed);
        }

        //Закрываем рецепт успешно
        public void finishRecipePD1_W6(float dosed)
        {
            FinishRecipe("W6", false, dosed);
        }

        //Закрываем рецепт успешно
        public void finishRecipePD2_W5(float dosed)
        {
            FinishRecipe("W5", false, dosed);
        }

        //Закрываем рецепт успешно
        public void finishRecipeOD2_W4(float dosed)
        {
            FinishRecipe("W4", false, dosed);
        }

        //-------------------------------------------------------
        //Закрываем рецепт аварией
        public void errorRecipeOD1_W2(float dosed)
        {
            FinishRecipe("W2", true, dosed);
        }

        //Закрываем рецепт аварией
        public void errorRecipePD1_W6(float dosed)
        {
            FinishRecipe("W6", true, dosed);
        }

        //Закрываем рецепт аварией
        public void errorRecipePD2_W5(float dosed)
        {
            FinishRecipe("W5", true, dosed);
        }

        //Закрываем рецепт аварией
        public void errorRecipeOD2_W4(float dosed)
        {
            FinishRecipe("W4", true, dosed);
        }

        #endregion
    }
}