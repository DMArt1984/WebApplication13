﻿namespace LKZ_MF_Widget.VPWeights
{
    //Интерфейс работы с весами ВП50
    internal interface IWeightsVp50
    {
        //Метод для добавления информации об отвесе 
        void AddInfo(string name, float task, int cycles, float production);
    }
}