﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Windows.Forms;

namespace LKZ_MF_Widget.BunkerSwap
{
    public partial class BunkerSwap : Form
    {
        public event EventHandler LinePd1Swap;
        public event EventHandler LinePd2Swap;
        public event EventHandler LineOd1Swap;
        public event EventHandler LineOd2Swap;

        private KeyValuePair<string, string> _swapRes; //Какой бункер надо на какой поменять 
        public BunkerSwap()
        {
            InitializeComponent();
            TopMost = true;
            CenterToScreen();
            if (!CheckIfPossible())
            {
                MessageBox.Show("В настоящее время нет запущенных рецептов", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1, (MessageBoxOptions)0x40000);
                Dispose();
                return;
            }
            InitForm();
            Show();
        }

        //Для вызова конкретной линии из SCADA
        public BunkerSwap(string place)
        {
            InitializeComponent();
            TopMost = true;
            CenterToScreen();
            if (!CheckIfPossible())
            {
                MessageBox.Show("В настоящее время нет запущенных рецептов", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1, (MessageBoxOptions)0x40000);
                Dispose();
                return;
            }
            InitForm();
            Show();
            ApplyPlace(place);
        }

        //Изменение интерфейса для отображения нужной линии
        private void ApplyPlace(string place)
        {
            if (place.Equals("W2"))
            {
                radioButtonOd1.Checked = true;
            }
            if (place.Equals("W6"))
            {
                radioButtonPd1.Checked = true;
            }
            if (place.Equals("W4"))
            {
                radioButtonOd2.Checked = true;
            }
            if (place.Equals("W5"))
            {
                radioButtonPd2.Checked = true;
            }
            tableLayoutPanelMain.RowStyles[0].Height = 0;
        }

        private void InitForm()
        {
            InitRadioButtons();
            UpdateBunkers();
        }

        private bool CheckIfPossible()
        {
            var query = "select id from dbo.recipe where isInProgress = 1";
            DataTable dt = DBClasses.DbConnect.GetDbInstance().PerformQuery(query);
            if (dt.Rows.Count == 0)
                return false;
            return true;
        }

        private void InitDgv()
        {

            var colNames = new List<KeyValuePair<string, string>>
            {   
                new KeyValuePair<string, string>("Наименование","name"),
                new KeyValuePair<string, string>("Бункер","bunker")
            };
            for (int i = 0; i < colNames.Count; i++)
            {
                var column = new DataGridViewTextBoxColumn();
                if (i == 0)
                    column.Width = 50;
                dataGridViewSkipList.Columns.Add(column);
                dataGridViewSkipList.Columns[i].DataPropertyName = colNames[i].Value;
                dataGridViewSkipList.Columns[i].Name = colNames[i].Value;
                dataGridViewSkipList.Columns[i].HeaderText = colNames[i].Key;
                dataGridViewSkipList.Columns[i].DisplayIndex = i;
            }
        }

        private void InitRadioButtons()
        {
            radioButtonOd1.Enabled = false;
            radioButtonPd1.Enabled = false;
            radioButtonOd2.Enabled = false;
            radioButtonPd2.Enabled = false;
            var query = "select id, place from dbo.recipe where isInProgress = 1";
            DataTable dt = DBClasses.DbConnect.GetDbInstance().PerformQuery(query);
            List<RadioButton> radioList = new List<RadioButton>();
            foreach (DataRow r in dt.Rows)
            {
                string str = r["place"].ToString().Trim();
                if (str.Equals("W2"))
                {
                    radioButtonOd1.Enabled = true;
                    radioList.Add(radioButtonOd1);
                }
                if (str.Equals("W6"))
                {
                    radioButtonPd1.Enabled = true;
                    radioList.Add(radioButtonPd1);
                }
                if (str.Equals("W4"))
                {
                    radioButtonOd2.Enabled = true;
                    radioList.Add(radioButtonOd2);
                }
                if (str.Equals("W5"))
                {
                    radioButtonPd2.Enabled = true;
                    radioList.Add(radioButtonPd2);
                }
            }
            if (radioList.Count != 0)
                radioList[0].Checked = true;
        }

        private void UpdateBunkers()
        {
            UpdateLabel();
            UpdateDgv();
            UpdateCombo();
        }

        private void UpdateCombo()
        {
            List<string> bunkersList = new List<string>();
            if (radioButtonOd1.Checked)
            {
                bunkersList = GetBunkerList("W2");
            }
            if (radioButtonOd2.Checked)
            {
                bunkersList = GetBunkerList("W4");
            }
            if (radioButtonPd1.Checked)
            {
                bunkersList = GetBunkerList("W6");
            }
            if (radioButtonPd2.Checked)
            {
                bunkersList = GetBunkerList("W5");
            }
            comboBoxBunkers.Items.Clear();
            if (bunkersList.Count != 0)
            {
                
                foreach (string s in bunkersList)
                {
                    comboBoxBunkers.Items.Add(s);
                }
            }
        }
        
        //Получаем список бункеров для нужной линии из базы
        private List<string> GetBunkerList(string place)
        {
            var query = "select bunkNum from dbo.bunker_card where place = '"+place+"' order by bunkNum asc";
            DataTable dt = DBClasses.DbConnect.GetDbInstance().PerformQuery(query);
            List<string> res = new List<string>();
            foreach ( DataRow r in dt.Rows)
            {
                res.Add(r["bunkNum"].ToString().Trim());
            }
            return res;
        }

        //Обновляем таблицу с рецептом
        private void UpdateDgv()
        {
            if (dataGridViewSkipList.Columns.Count == 0)
            {
                InitDgv();
            }
            //, 'false' as skip
            var query =
                "select  name, bunker from dbo.recipe_ingredient where id_recipe = (select id from dbo.recipe where isInProgress = 1 and place = '" + GetPlace() + "')";
            DataTable dt = DBClasses.DbConnect.GetDbInstance().PerformQuery(query);
            if (dataGridViewSkipList.InvokeRequired)
            {
                dataGridViewSkipList.Invoke(new MethodInvoker(() => dataGridViewSkipList.DataSource = dt));
            }
            else
            {
                dataGridViewSkipList.DataSource = dt;
            }
            dataGridViewSkipList.Refresh();
        }

        //Обновляем лейбу с названием рецепта
        private void UpdateLabel()
        {
            string labelText = "";
            var query = "select id,name, quality from dbo.recipe where isInProgress = 1 and place = '" + GetPlace() + "'";
            DataTable dt = DBClasses.DbConnect.GetDbInstance().PerformQuery(query);
            if (dt.Rows.Count == 0)
            {
                MessageBox.Show("На линии нет запущенных рецептов", "Ошибка", MessageBoxButtons.OK,
                    MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1, (MessageBoxOptions)0x40000);
                labelText = "Ошибка";
            }
            else
            {
                if (dt.Rows.Count > 1)
                {
                    MessageBox.Show("На линии больше одного запущенного рецепта", "Ошибка", MessageBoxButtons.OK,
                        MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1, (MessageBoxOptions)0x40000);
                    labelText = "Ошибка";
                }
                else
                {
                    labelText = "Рецепт № " + dt.Rows[0]["id"].ToString().Trim() + " " + dt.Rows[0]["name"].ToString().Trim() + " (" + dt.Rows[0]["quality"].ToString().Trim() +
                                ")";
                }
            }
            if (InvokeRequired)
            {
                Invoke(new MethodInvoker(() => labelRecipe.Text = labelText));
            }
            else
            {
                labelRecipe.Text = labelText;
            }
        }

        //Получить название линии из radioButton
        private string GetPlace()
        {
            if (radioButtonOd1.Checked)
            {
                return "W2";
            }
            if (radioButtonPd1.Checked)
            {
                return "W6";
            }
            if (radioButtonOd2.Checked)
            {
                return "W4";
            }
            if (radioButtonPd2.Checked)
            {
                return "W5";
            }
            return string.Empty;
        }

        public KeyValuePair<string, string> GetSwap()
        {
            return _swapRes;
        }

        private void buttonCancel_Click(object sender, EventArgs e)
        {
            Dispose();
        }

        private void radioButtonPd2_CheckedChanged(object sender, EventArgs e)
        {
            UpdateBunkers();
        }

        private void buttonSwap_Click(object sender, EventArgs e)
        {
            if (dataGridViewSkipList.SelectedRows.Count != 1)
            {
                MessageBox.Show("Не выбран бункер для замены или выбрано несколько", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1, (MessageBoxOptions)0x40000);
                return;
            }
            if (comboBoxBunkers.SelectedItem == null)
            {
                MessageBox.Show("Не указано в какой бункер переносить", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1, (MessageBoxOptions)0x40000);
                return;
            }
            string fromBunk = dataGridViewSkipList.SelectedRows[0].Cells[1].Value.ToString()
                .Trim();
            string toBunk = comboBoxBunkers.SelectedItem.ToString().Trim();
            List<string> current = new List<string>();
            foreach (DataGridViewRow r in dataGridViewSkipList.Rows)
            {
                string ingr = r.Cells[1].Value.ToString().Trim();
                if(!ingr.Equals(fromBunk))
                 current.Add(r.Cells[1].Value.ToString().Trim());
            }
            if (current.Contains(toBunk))
            {
                MessageBox.Show("Бункер № " + toBunk + " уже используется для другого ингредиента", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1, (MessageBoxOptions)0x40000);
                return;
            }
            if (fromBunk.Equals(toBunk))
            {
                MessageBox.Show("Нельзя заменить бункер на самого себя", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1, (MessageBoxOptions)0x40000);
                return;
            }
            List<string> liquidBunkersList = GetLiquidList();
            if (liquidBunkersList.Contains(fromBunk) || liquidBunkersList.Contains(toBunk))
            {
                MessageBox.Show("Нельзя переносить жидкие добавки", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1, (MessageBoxOptions)0x40000);
                return;
            }
            _swapRes = new KeyValuePair<string, string>(fromBunk, toBunk);
            PerformSqlOperations(fromBunk, toBunk);
            if (radioButtonOd1.Checked)
            {
                if(LineOd1Swap != null) LineOd1Swap(this, new EventArgs());
            }
            if (radioButtonPd1.Checked)
            {
                if (LinePd1Swap != null) LinePd1Swap(this, new EventArgs());
            }
            if (radioButtonOd2.Checked)
            {
                if (LineOd2Swap != null) LineOd2Swap(this, new EventArgs());
            }
            if (radioButtonPd2.Checked)
            {
                if (LinePd2Swap != null) LinePd2Swap(this, new EventArgs());
            }
        }
        //Записываем в базу изменения по переносу бункеров
        private void PerformSqlOperations(string fromBunk, string toBunk)
        {
            //Меняем бункер в рецепте
            var query = "select id, name, percentage, priority from dbo.recipe_ingredient  where id_recipe = (select id from dbo.recipe where isInProgress = 1 and place = '" + GetPlace() + "') and bunker = "+fromBunk;
            DataTable dt = DBClasses.DbConnect.GetDbInstance().PerformQuery(query);
            if (dt.Rows.Count != 1)
            {
                MessageBox.Show("Ошибка при запросе к БД для переноса бункера", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1, (MessageBoxOptions)0x40000);
                return;
            }
            string name = dt.Rows[0]["name"].ToString().Trim();
            string priority = dt.Rows[0]["priority"].ToString().Trim();
            int id = Convert.ToInt32(dt.Rows[0]["id"]);
            float percentage = Convert.ToSingle(dt.Rows[0]["percentage"]);
            //Делаем запись о переносе в служебный комментарий
            query = "select id,commentService from dbo.recipe where isInProgress = 1 and place = '" + GetPlace() + "'";
            dt = DBClasses.DbConnect.GetDbInstance().PerformQuery(query);
            if (dt.Rows.Count != 1)
            {
                MessageBox.Show("Не удалось найти требуемый текущий рецепт", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1, (MessageBoxOptions)0x40000);
                return;
            }
            string idRecipe = dt.Rows[0]["id"].ToString().Trim();
            string currentComment = dt.Rows[0]["commentService"].ToString().Trim();
            currentComment += "Перенос из "+fromBunk+" в "+toBunk+" ("+DateTime.Now.ToString("HH:mm:ss")+"); ";
            query = "update dbo.recipe set commentService = N'" + currentComment + "' where id = " + idRecipe;
            DBClasses.DbConnect.GetDbInstance().PerformNonQuery(query);
            //Меняем ингредиент в рецепте
            query = "update dbo.recipe_ingredient set bunker = " + toBunk + " where id = " + id;
            DBClasses.DbConnect.GetDbInstance().PerformNonQuery(query);
            //Запрашиваем что было в карте бункеров
            query = "select task, currentIngredientId from dbo.bunker_card where bunkNum = " + fromBunk;
            dt = DBClasses.DbConnect.GetDbInstance().PerformQuery(query);
            if (dt.Rows.Count != 1)
            {
                MessageBox.Show("Ошибка при запросе к карте бункеров для переноса бункера", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1, (MessageBoxOptions)0x40000);
                return;
            }
            int ingrId = Convert.ToInt32(dt.Rows[0]["currentIngredientId"]);
            float task = Convert.ToSingle(dt.Rows[0]["task"]);
            //Стираем старое из карты
            query =
                "update dbo.bunker_card set isInUse = 0, task = 0, currentPriority = 0, currentIngredientId = 0 where bunkNum = " +
                fromBunk;
            DBClasses.DbConnect.GetDbInstance().PerformNonQuery(query);
            //Записываем новое в карту
            query =
                "update dbo.bunker_card set isInUse = 1, task = "+task.ToString().Replace(",",".")+", currentPriority = "+priority+", currentIngredientId = "+ingrId+" where bunkNum = " +
                toBunk;
            DBClasses.DbConnect.GetDbInstance().PerformNonQuery(query);
        }

        //Возвращает список бункеров для жидких добавок
        private List<string> GetLiquidList()
        {
            List<string> res = new List<string>();
            var query = "select bunkNum from dbo.bunker_card where isLiquid = 1";
            DataTable dt = DBClasses.DbConnect.GetDbInstance().PerformQuery(query);
            foreach (DataRow r in dt.Rows)
            {
                res.Add(r[0].ToString().Trim());
            }
            return res;
        }
    }
}
