﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using LKZ_MF_Widget.DBClasses;

namespace LKZ_MF_Widget.SetBunkersAtStart
{
    public partial class SetBunkersAtStart : Form
    {
        private readonly int _id; //id заявки
        public event RecipeStartEventArgs.RecipeStartEventHandler RecipeStarted; //сигнал о запуске нового рецепта
        private Timer _tm; //таймер для отображения ошибок

        public SetBunkersAtStart(int id)
        {
            InitializeComponent();
            CenterToScreen();
            TopMost = true;
            _id = id;
            radioButtonPd1.Checked = true;
            InitDgv();
            FillDgv(id);
            Text += "Заявка № " + id;
            
        }

        //Заполнение формы ингредиентами для заданного рецепта
        private void FillDgv(int id)
        {
            if (dataGridViewPriorities.Rows.Count != 0)
            {
                dataGridViewPriorities.Rows.Clear();
            }
            var query = "select name,id from dbo.recipe_ingredient where id_recipe = " + id+" order by percentage desc";
            var dt = DbConnect.GetDbInstance().PerformQuery(query);
            for (var i = 0; i < dt.Rows.Count; i++)
            {
                dataGridViewPriorities.Rows.Add();
                dataGridViewPriorities.Rows[i].Cells[1].Value = dt.Rows[i]["name"].ToString();
                dataGridViewPriorities.Rows[i].Cells[3].Value = dt.Rows[i]["id"].ToString();
            }
            SetPriorities();
        }

        //Инициализация формы с приоритетами
        private void InitDgv()
        {
            if (dataGridViewPriorities.Columns.Count != 0)
            {
                dataGridViewPriorities.Columns.Clear();
            }
            DataGridViewCell cell = new DataGridViewTextBoxCell();
            for (var i = 0; i < 4; i++)
            {
                if (i == 2)
                {
                    dataGridViewPriorities.Columns.Add(GetBunkerColumn());
                    continue;
                }
                dataGridViewPriorities.Columns.Add(new DataGridViewColumn(cell));
                dataGridViewPriorities.Columns[i].SortMode = DataGridViewColumnSortMode.Automatic;
            }

            dataGridViewPriorities.Columns[0].HeaderText = "Приоритет";
            dataGridViewPriorities.Columns[0].Name = "priority";
            dataGridViewPriorities.Columns[0].Width = 60;
            dataGridViewPriorities.Columns[1].HeaderText = "Название ингредиента";
            dataGridViewPriorities.Columns[1].Name = "name";
            dataGridViewPriorities.Columns[2].HeaderText = "Бункер";
            dataGridViewPriorities.Columns[2].Name = "bunker";
            dataGridViewPriorities.Columns[2].Width = 60;
            dataGridViewPriorities.Columns[0].ReadOnly = true;
            dataGridViewPriorities.Columns[1].ReadOnly = true;
            dataGridViewPriorities.RowHeadersVisible = false;

            dataGridViewPriorities.Columns[3].Name = "id";
            dataGridViewPriorities.Columns[3].HeaderText = "id";
            dataGridViewPriorities.Columns[3].Visible = false;
        }

        //Комбобоксы с бункерами для рецепта
        private DataGridViewColumn GetBunkerColumn()
        {
            var cmbCell = new DataGridViewComboBoxCell();
            var items = FillBunkersList(_id);
            items.Sort();
            foreach (var s in items)
            {
                cmbCell.Items.Add(s);
            }
            return new DataGridViewColumn(cmbCell) {HeaderText = "Бункер"};
        }

        //Возвращает список бункеров для выбранной линии
        private List<string> FillBunkersList(int id)
        {
            var result = new List<string>();
            var query = "select bunkNum from dbo.bunker_card where place = N'";
            if (radioButtonOd1.Checked)
            {
                query += "W2";
            }
            if (radioButtonOd2.Checked)
            {
                query += "W4";
            }
            if (radioButtonPd1.Checked)
            {
                query += "W6";
            }
            if (radioButtonPd2.Checked)
            {
                query += "W5";
            }
            query += "';";
            var dt = DbConnect.GetDbInstance().PerformQuery(query);
            foreach (DataRow r in dt.Rows)
            {
                result.Add(r["bunkNum"].ToString().Trim());
            }
            return result.Distinct().ToList();
        }

        private int CheckRecipesInProgress(string place)
        {
            var query = "select COUNT(id) as count from dbo.recipe where isInProgress = 1 and place = '" + place + "'";
            var dt = DbConnect.GetDbInstance().PerformQuery(query);
            if (dt.Rows[0]["count"].ToString() == "0")
                return 0;
            if (dt.Rows.Count == 1)
            {
                query = "select id from dbo.recipe where isInProgress = 1 and place = '" + place + "'";
                dt = DbConnect.GetDbInstance().PerformQuery(query);
                var id = Convert.ToInt32(dt.Rows[0]["id"].ToString());
                return id;
            }
            return 0;
        }

        private void buttonStart_Click(object sender, EventArgs e)
        {
            if (!CheckPriorities())
                return;
            var place = "";
            var placeName = "";
            if (radioButtonOd1.Checked)
            {
                place = "W2";
                placeName = "1 ОД";
            }
            if (radioButtonOd2.Checked)
            {
                place = "W4";
                placeName = "2 ОД";
            }
            if (radioButtonPd1.Checked)
            {
                place = "W6";
                placeName = "1 ПД";
            }
            if (radioButtonPd2.Checked)
            {
                place = "W5";
                placeName = "2 ПД";
            }
            var idRunning = CheckRecipesInProgress(place);
            if (idRunning != 0)
            {
               /* MessageBox.Show(
                    "На линии " + placeName + " уже запущен рецепт № " + idRunning +
                    ".\nДождитесь его завершения или завершите вручную.", "Внимание", MessageBoxButtons.OK,
                    MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1, (MessageBoxOptions)0x40000);*/
                ShowNotification("На линии " + placeName + " уже запущен рецепт № " + idRunning +
                    ".\nДождитесь его завершения или завершите вручную.");
                return;
            }
            //Записываем бункера и приоритеты в базу
            foreach (DataGridViewRow r in dataGridViewPriorities.Rows)
            {
                if (r.IsNewRow)
                    continue;
                var bunker = Convert.ToInt32(r.Cells[2].Value);
                var query = "update dbo.recipe_ingredient set bunker = " + bunker + " , priority =  " + r.Cells[0].Value +
                            " where id = " + r.Cells[3].Value;
                DbConnect.GetDbInstance().PerformNonQuery(query);
            }
            //Записываем линию для рецепта
            var qry = "update dbo.recipe set place = N'";
            if (radioButtonOd1.Checked)
            {
                qry += "W2";
            }
            if (radioButtonOd2.Checked)
            {
                qry += "W4";
            }
            if (radioButtonPd1.Checked)
            {
                qry += "W6";
            }
            if (radioButtonPd2.Checked)
            {
                qry += "W5";
            }
            qry += "' where id = " + _id;
            DbConnect.GetDbInstance().PerformNonQuery(qry);

          //  DialogResult = DialogResult.OK;
            if(RecipeStarted != null) RecipeStarted(this, new RecipeStartEventArgs(_id));
            Dispose();
        }

        private void buttonCancel_Click(object sender, EventArgs e)
        {
           // DialogResult = DialogResult.Cancel;
            Dispose();
        }

        private void radioButtonPd2_CheckedChanged(object sender, EventArgs e)
        {
            InitDgv();
            FillDgv(_id);
        }

        private void dataGridViewPriorities_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            var validRow = (e.RowIndex != -1); //Make sure the clicked row isn't the header.

            // Check to make sure the cell clicked is the cell containing the combobox 
            if (dataGridViewPriorities.Columns[e.ColumnIndex].Index == 2 && validRow)
            {
                dataGridViewPriorities.BeginEdit(true);
                ((ComboBox) dataGridViewPriorities.EditingControl).DroppedDown = true;
            }
        }

        private void dataGridViewPriorities_SelectionChanged(object sender, EventArgs e)
        {
            
            if (dataGridViewPriorities.SelectedRows.Count == 0)
            {
                buttonUp.Enabled = false;
                buttonDown.Enabled = false;
                return;
            }
            if (dataGridViewPriorities.SelectedRows[0].Index == 0)
            {
                buttonUp.Enabled = false;
            }
            else
            {
                buttonUp.Enabled = true;
            }
            if (dataGridViewPriorities.SelectedRows[0].Index == dataGridViewPriorities.Rows.Count - 1)
            {
                buttonDown.Enabled = false;
            }
            else
            {
                buttonDown.Enabled = true;
            }
            /*
            //Нельзя менять приоритет жидких добавок
            if (dataGridViewPriorities.SelectedRows[0].Cells[2].Value.ToString().Trim().Equals("7") ||
                dataGridViewPriorities.SelectedRows[0].Cells[2].Value.ToString().Trim().Equals("8"))
            {
                buttonUp.Enabled = false;
                buttonDown.Enabled = false;
            }
            //Нельзя поставить предпоследний ингредиент на место жидкой добавки
            bool isLiquid = false;
            foreach (DataGridViewRow r in dataGridViewPriorities.Rows)
            {
                if(r.IsNewRow)
                    continue;
                if (r.Cells[2].Value.ToString().Trim().Equals("7") || r.Cells[2].Value.ToString().Trim().Equals("8"))
                {
                    isLiquid = true;
                    break;
                }
                
            }
            if(!isLiquid)
                return;
            int index = dataGridViewPriorities.SelectedRows[0].Index;
            if (dataGridViewPriorities.RowCount - 2 == index)
            {
                buttonDown.Enabled = false;
                buttonUp.Enabled = true;
            }*/
        }

        private void buttonUp_Click(object sender, EventArgs e)
        {
            if (dataGridViewPriorities.SelectedRows.Count == 0)
                return;
            var index = dataGridViewPriorities.SelectedRows[0].Index;
            var name = dataGridViewPriorities.SelectedRows[0].Cells[1].Value.ToString();
            SwapRows(index, index - 1);
            SetPriorities();
            SelectRow(name);
        }

        //Замена строк в таблице при смене приоритетов
        private void SwapRows(int selected, int old)
        {
            var oldRow = dataGridViewPriorities.Rows[old];
            var newRow = dataGridViewPriorities.Rows[selected];
            dataGridViewPriorities.Rows.Remove(newRow);
            dataGridViewPriorities.Rows.Remove(oldRow);
            dataGridViewPriorities.Rows.Insert(old, newRow);
            dataGridViewPriorities.Rows.Insert(selected, oldRow);
        }

        //Выбираем какой ингредиент выбрать
        private void SelectRow(string name)
        {
            //Не работает !!!
            foreach (DataGridViewRow r in dataGridViewPriorities.Rows)
            {
                if (r.Cells[1].Value.ToString().Trim().Equals(name))
                {
                    r.Selected = true;
                    return;
                }
                r.Selected = false;
            }
        }

        //Запись приоритетов в столбец 
        private void SetPriorities()
        {
            for (var i = 0; i < dataGridViewPriorities.Rows.Count; i++)
            {
                dataGridViewPriorities.Rows[i].Cells[0].Value = i + 1;
            }
        }

        private void buttonDown_Click(object sender, EventArgs e)
        {
            if (dataGridViewPriorities.SelectedRows.Count == 0)
                return;
            var index = dataGridViewPriorities.SelectedRows[0].Index;
            var name = dataGridViewPriorities.SelectedRows[0].Cells[1].Value.ToString();
            SwapRows(index + 1, index);
            SetPriorities();
            SelectRow(name);
        }

        private void radioButtonPd1_CheckedChanged(object sender, EventArgs e)
        {
            InitDgv();
            FillDgv(_id);
        }

        private void radioButtonOd1_CheckedChanged(object sender, EventArgs e)
        {
            InitDgv();
            FillDgv(_id);
        }

        private void radioButtonOd2_CheckedChanged(object sender, EventArgs e)
        {
            InitDgv();
            FillDgv(_id);
        }

        //Проверяем правильность заполнения таблицы с приоритетами и бункерами
        private bool CheckPriorities()
        {
            foreach (DataGridViewRow r in dataGridViewPriorities.Rows)
            {
                if (r.IsNewRow)
                    continue;
                if (r.Cells[2].Value == null)
                {
                    ShowNotification("Не указан бункер в строке " + (r.Index + 1));
                  /*  MessageBox.Show(
                        "Не указан бункер в строке " + (r.Index + 1), "Внимание", MessageBoxButtons.OK,
                        MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1, (MessageBoxOptions)0x40000);*/
                    return false;
                }
            }
            var lst = new List<string>();
            for (var i = 0; i < dataGridViewPriorities.Rows.Count; i++)
            {
                if (dataGridViewPriorities.Rows[i].IsNewRow)
                    continue;
                lst.Add(dataGridViewPriorities.Rows[i].Cells[2].Value.ToString());
            }
            if (lst.GroupBy(n => n).Any(c => c.Count() > 1))
            {
                ShowNotification("Есть повторяющиеся бункеры.");
             /*   MessageBox.Show("Есть повторяющиеся бункеры.", "Внимание",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1, (MessageBoxOptions)0x40000);*/
                return false;
            }
            //Нельзя дозировать жидкие добавки не последними
            if (lst.IndexOf("7") != -1 && (lst.IndexOf("7")+1) != dataGridViewPriorities.RowCount)
            {
                 /*   MessageBox.Show("Масло (бункер 7) обязательно должно иметь последний приоритет в дозировании.", "Внимание",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1,
                        (MessageBoxOptions) 0x40000);*/
                    ShowNotification("Масло (бункер 7) обязательно должно иметь последний приоритет в дозировании.");
                    return false;
            }
            if (lst.IndexOf("8") != -1 && (lst.IndexOf("8") + 1) != dataGridViewPriorities.RowCount)
            {
               /* MessageBox.Show("Масло (бункер 8) обязательно должно иметь последний приоритет в дозировании.", "Внимание",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1,
                    (MessageBoxOptions)0x40000);*/
                ShowNotification("Масло (бункер 8) обязательно должно иметь последний приоритет в дозировании.");
                return false;
            }
            return true;
        }

        //Отображение нотификации об ошибке
        private void ShowNotification(string text)
        {
            if (_tm != null)
            {
                if (_tm.Enabled)
                {
                    HideNotification(this,new EventArgs());
                }
            }
            _tm = new Timer(){Interval = 5000};
            _tm.Tick += HideNotification;
            labelNotification.Text = text;
            labelNotification.Visible = true;
            _tm.Start();

        }

        void HideNotification(object sender, EventArgs e)
        {
            labelNotification.Visible = false;
            labelNotification.Text = "";
            _tm.Stop();
        }

    }


}