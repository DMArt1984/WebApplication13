﻿using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using LKZ_MF_Widget.DBClasses;

namespace LKZ_MF_Widget
{
    //Выбор типа отчета для Excel
    internal enum ExcelReportType
    {
        GeneralReport,
        RecipesReport,
        BatchesReport
    };

    //Класс для формирования исходных данных при сохранении в Excel
    internal class TableMaker
    {
        //Шапки для отчетов - надо заполнить после формирования запросов и отладки
        private readonly List<string> _batchesHeader = new List<string>
        {
            "№ Рецепта",
            "Наименование",
            "Линия",
            "Бункер",
            "Наименование ингредиента",
            "Номер отвеса",
            "Требуемый вес, кг.",
            "Фактический вес, кг.",
            "Отклонение, кг.",
            "Отклонение, %",
            "Ошибка дозирования, кг.",
            "Высота столба, кг."
          };

        private readonly List<string> _recipesHeader = new List<string>
        {
            "№ Рецепта",
            "Наименование",
            "Общий вес, кг.",
            "Наименование ингредиента",
            "Линия",
            "Время создания",
            "Время завершения",
            "Задание на К-К, кг.",
            "Требуемый вес, кг.",
            "Фактический вес, кг.",
            "Отклонение, кг.",
            "Отклонение, %",
            "Служебный комментарий"
        };

        private readonly DataGridView _inputDgv;
        private ExcelReportType _type = ExcelReportType.GeneralReport;
        private readonly bool _selected;
        private readonly List<List<string>> _result = new List<List<string>>();

        public TableMaker(DataGridView inputDgv, bool selected = false)
        {
            _inputDgv = inputDgv;
            _selected = selected;
        }

        public void SetType(ExcelReportType type)
        {
            _type = type;
        }

        //Делаем отчет
        public void MakeReport()
        {
            MethodInvoker inv = new MethodInvoker(Invoker);
            inv.BeginInvoke(null, null);
            ExcelSaver sav = new ExcelSaver(_result);
            sav.FileCreate();
        }

        //Invoker для формирования отчета без блокирования GUI
        private void Invoker()
        {
            AddHeader();
            AddRows();
        }

        //Добавляем заголовок
        private void AddHeader()
        {
            switch (_type)
            {
                case ExcelReportType.GeneralReport:
                    List<string> headers = new List<string>();
                    foreach (DataGridViewColumn cl in _inputDgv.Columns)
                    {
                        if (!cl.Visible)
                            continue;
                        headers.Add(cl.HeaderText);
                    }
                    _result.Insert(0, headers);
                    break;
                case ExcelReportType.BatchesReport:
                    _result.Insert(0, _batchesHeader);
                    break;
                case ExcelReportType.RecipesReport:
                    _result.Insert(0, _recipesHeader);
                    break;
            }
        }

        //Добавляем строки в таблицу
        private void AddRows()
        {
            if (_type == ExcelReportType.GeneralReport)
            {
                foreach (DataGridViewRow r in _inputDgv.Rows)
                {
                    if (!r.Selected && _selected)
                        continue;
                    List<string> tmp = new List<string>();
                    foreach (DataGridViewCell cl in r.Cells)
                    {
                        if (cl.Visible)
                            tmp.Add(cl.Value.ToString().Trim());
                    }
                    _result.Add(tmp);
                }
            }
            else
            {
                string sql = PrepareQuery();
                DataTable dt = DbConnect.GetDbInstance().PerformQuery(sql);
                dt = ConvertPlace(dt);
                foreach (DataRow r in dt.Rows)
                {
                    List<string> tmp = new List<string>();
                    tmp.AddRange(r.ItemArray.Select(v => v.ToString()));
                    _result.Add(tmp);
                }
            }
        }

        //Делаем необходимый запрос
        private string PrepareQuery()
        {
            if (_type == ExcelReportType.RecipesReport) //По рецептам
            {
                return "select recipe.id as id, recipe.name as RecipeName, recipe.weight as TotalWeight,  " +
                       "recipe_ingredient.name as IngredientName,recipe.place as place, recipe.timeCreate as timeCreate," +
                       " recipe.timeFinished as timeFinished, recipe.weightKK as weightKK, ROUND(recipe_ingredient.percentage*recipe.weight/100,2) as weight, " +
                       "recipe_ingredient.weightFact as weightFact,ROUND(recipe_ingredient.weightFact - (recipe_ingredient.percentage*recipe.weight/100),2) as devKg, " +
                       "ROUND(((recipe_ingredient.weightFact - recipe_ingredient.percentage*recipe.weight/100)/((recipe.weight*recipe_ingredient.percentage)/10000)),2) as devPerc," +
                       "recipe.commentService as commentService " +
                       "from recipe_ingredient inner join recipe on recipe.id = recipe_ingredient.id_recipe and id_recipe in (" +
                       GetWhere() + ") order by id asc ";
            }
            //По отвесам
            return
                "select rec.id as id,rec.name as nameRecipe, rec.place as place, batch.bunker as bunker, batch.name as nameIngredient, batch.batchNum as batchNum,"+
                "ROUND(batch.weight,2) as weight, ROUND(batch.weightFact,2) as weightFact,ROUND(batch.weightFact-batch.weight,2) as devKg,"+
                " ROUND((batch.weightFact-batch.weight)/(NULLIF(batch.weight,0)/100),2) as devPerc, ROUND(doseErrorSize,2) as doseErrorSize," +
                " ROUND(fallingColumnSize,2) as fallingColumnSize from " +
                " dbo.recipe as rec INNER JOIN dbo.recipe_ingredient as ingr on rec.id = ingr.id_recipe INNER JOIN dbo.recipe_batch as batch "
                +" ON batch.id_ingredient = ingr.id and rec.id in (" +
                GetWhere() + ") order by id asc, batchNum asc";
        }

        //Возвращает список id необходимых рецептов
        private string GetWhere()
        {
            string res = "";
            foreach (DataGridViewRow r in _inputDgv.Rows)
            {
                if (!r.Selected && _selected)
                    continue;
                res += r.Cells[0].Value.ToString().Trim() + ",";
            }
            res = res.Remove(res.Length - 1);
            return res;
        }

        //Заменяем наименование линии из базы на читабельное
        private static DataTable ConvertPlace(DataTable dt)
        {
            if (!dt.Columns.Contains("place"))
                return dt;
            foreach (DataRow r in dt.Rows)
            {
                switch (r["place"].ToString().Trim())
                {
                    case "W4":
                        r["place"] = "ОД линия 2";
                        break;
                    case "W5":
                        r["place"] = "ПД линия 2";
                        break;
                    case "W2":
                        r["place"] = "ОД линия 1";
                        break;
                    case "W6":
                        r["place"] = "ПД линия 1";
                        break;
                    case "Na0":
                        r["place"] = "-";
                        break;
                    default:
                        r["place"] = "-";
                        break;
                }
            }
            return dt;
        }
    }
}
