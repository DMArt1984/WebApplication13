﻿namespace LKZ_MF_Widget.SelectRecipeToClose
{
    partial class SelectRecipeToClose
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SelectRecipeToClose));
            this.tableLayoutPanelMain = new System.Windows.Forms.TableLayoutPanel();
            this.flowLayoutPanelButtons = new System.Windows.Forms.FlowLayoutPanel();
            this.buttonCloseForm = new System.Windows.Forms.Button();
            this.buttonFinishRecipe = new System.Windows.Forms.Button();
            this.groupBoxChoose = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanelRecipes = new System.Windows.Forms.TableLayoutPanel();
            this.dataGridViewOD2 = new System.Windows.Forms.DataGridView();
            this.radioButtonOD2 = new System.Windows.Forms.RadioButton();
            this.dataGridViewPD2 = new System.Windows.Forms.DataGridView();
            this.radioButtonPD2 = new System.Windows.Forms.RadioButton();
            this.dataGridViewOD1 = new System.Windows.Forms.DataGridView();
            this.radioButtonOD1 = new System.Windows.Forms.RadioButton();
            this.dataGridViewPD1 = new System.Windows.Forms.DataGridView();
            this.radioButtonPD1 = new System.Windows.Forms.RadioButton();
            this.tableLayoutPanelMain.SuspendLayout();
            this.flowLayoutPanelButtons.SuspendLayout();
            this.groupBoxChoose.SuspendLayout();
            this.tableLayoutPanelRecipes.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewOD2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewPD2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewOD1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewPD1)).BeginInit();
            this.SuspendLayout();
            // 
            // tableLayoutPanelMain
            // 
            this.tableLayoutPanelMain.ColumnCount = 1;
            this.tableLayoutPanelMain.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanelMain.Controls.Add(this.flowLayoutPanelButtons, 0, 1);
            this.tableLayoutPanelMain.Controls.Add(this.groupBoxChoose, 0, 0);
            this.tableLayoutPanelMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanelMain.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanelMain.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tableLayoutPanelMain.Name = "tableLayoutPanelMain";
            this.tableLayoutPanelMain.RowCount = 2;
            this.tableLayoutPanelMain.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanelMain.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 54F));
            this.tableLayoutPanelMain.Size = new System.Drawing.Size(938, 435);
            this.tableLayoutPanelMain.TabIndex = 0;
            // 
            // flowLayoutPanelButtons
            // 
            this.flowLayoutPanelButtons.Controls.Add(this.buttonCloseForm);
            this.flowLayoutPanelButtons.Controls.Add(this.buttonFinishRecipe);
            this.flowLayoutPanelButtons.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanelButtons.FlowDirection = System.Windows.Forms.FlowDirection.RightToLeft;
            this.flowLayoutPanelButtons.Location = new System.Drawing.Point(4, 386);
            this.flowLayoutPanelButtons.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.flowLayoutPanelButtons.Name = "flowLayoutPanelButtons";
            this.flowLayoutPanelButtons.Size = new System.Drawing.Size(930, 44);
            this.flowLayoutPanelButtons.TabIndex = 0;
            // 
            // buttonCloseForm
            // 
            this.buttonCloseForm.Location = new System.Drawing.Point(814, 5);
            this.buttonCloseForm.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.buttonCloseForm.Name = "buttonCloseForm";
            this.buttonCloseForm.Size = new System.Drawing.Size(112, 35);
            this.buttonCloseForm.TabIndex = 0;
            this.buttonCloseForm.Text = "Отмена";
            this.buttonCloseForm.UseVisualStyleBackColor = true;
            this.buttonCloseForm.Click += new System.EventHandler(this.buttonCloseForm_Click);
            // 
            // buttonFinishRecipe
            // 
            this.buttonFinishRecipe.Location = new System.Drawing.Point(634, 5);
            this.buttonFinishRecipe.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.buttonFinishRecipe.Name = "buttonFinishRecipe";
            this.buttonFinishRecipe.Size = new System.Drawing.Size(172, 35);
            this.buttonFinishRecipe.TabIndex = 1;
            this.buttonFinishRecipe.Text = "Завершить рецепт";
            this.buttonFinishRecipe.UseVisualStyleBackColor = true;
            this.buttonFinishRecipe.Click += new System.EventHandler(this.buttonFinishRecipe_Click);
            // 
            // groupBoxChoose
            // 
            this.groupBoxChoose.Controls.Add(this.tableLayoutPanelRecipes);
            this.groupBoxChoose.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBoxChoose.Location = new System.Drawing.Point(4, 5);
            this.groupBoxChoose.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBoxChoose.Name = "groupBoxChoose";
            this.groupBoxChoose.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBoxChoose.Size = new System.Drawing.Size(930, 371);
            this.groupBoxChoose.TabIndex = 1;
            this.groupBoxChoose.TabStop = false;
            this.groupBoxChoose.Text = "Запущенные рецепты";
            // 
            // tableLayoutPanelRecipes
            // 
            this.tableLayoutPanelRecipes.ColumnCount = 2;
            this.tableLayoutPanelRecipes.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 206F));
            this.tableLayoutPanelRecipes.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanelRecipes.Controls.Add(this.dataGridViewOD2, 1, 3);
            this.tableLayoutPanelRecipes.Controls.Add(this.radioButtonOD2, 0, 3);
            this.tableLayoutPanelRecipes.Controls.Add(this.dataGridViewPD2, 1, 2);
            this.tableLayoutPanelRecipes.Controls.Add(this.radioButtonPD2, 0, 2);
            this.tableLayoutPanelRecipes.Controls.Add(this.dataGridViewOD1, 1, 1);
            this.tableLayoutPanelRecipes.Controls.Add(this.radioButtonOD1, 0, 1);
            this.tableLayoutPanelRecipes.Controls.Add(this.dataGridViewPD1, 1, 0);
            this.tableLayoutPanelRecipes.Controls.Add(this.radioButtonPD1, 0, 0);
            this.tableLayoutPanelRecipes.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanelRecipes.Location = new System.Drawing.Point(4, 24);
            this.tableLayoutPanelRecipes.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tableLayoutPanelRecipes.Name = "tableLayoutPanelRecipes";
            this.tableLayoutPanelRecipes.RowCount = 4;
            this.tableLayoutPanelRecipes.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanelRecipes.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanelRecipes.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanelRecipes.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanelRecipes.Size = new System.Drawing.Size(922, 342);
            this.tableLayoutPanelRecipes.TabIndex = 1;
            // 
            // dataGridViewOD2
            // 
            this.dataGridViewOD2.AllowUserToAddRows = false;
            this.dataGridViewOD2.AllowUserToResizeColumns = false;
            this.dataGridViewOD2.AllowUserToResizeRows = false;
            this.dataGridViewOD2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewOD2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.Transparent;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewOD2.DefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridViewOD2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridViewOD2.Location = new System.Drawing.Point(210, 260);
            this.dataGridViewOD2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.dataGridViewOD2.Name = "dataGridViewOD2";
            this.dataGridViewOD2.ReadOnly = true;
            this.dataGridViewOD2.RowHeadersVisible = false;
            this.dataGridViewOD2.Size = new System.Drawing.Size(708, 77);
            this.dataGridViewOD2.TabIndex = 4;
            this.dataGridViewOD2.SelectionChanged += new System.EventHandler(this.dataGridViewPD1_SelectionChanged);
            // 
            // radioButtonOD2
            // 
            this.radioButtonOD2.AutoSize = true;
            this.radioButtonOD2.Location = new System.Drawing.Point(4, 286);
            this.radioButtonOD2.Margin = new System.Windows.Forms.Padding(4, 31, 4, 5);
            this.radioButtonOD2.Name = "radioButtonOD2";
            this.radioButtonOD2.Size = new System.Drawing.Size(170, 24);
            this.radioButtonOD2.TabIndex = 3;
            this.radioButtonOD2.TabStop = true;
            this.radioButtonOD2.Text = "Линия 2 ОД весы 4";
            this.radioButtonOD2.UseVisualStyleBackColor = true;
            // 
            // dataGridViewPD2
            // 
            this.dataGridViewPD2.AllowUserToAddRows = false;
            this.dataGridViewPD2.AllowUserToResizeColumns = false;
            this.dataGridViewPD2.AllowUserToResizeRows = false;
            this.dataGridViewPD2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewPD2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.Transparent;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewPD2.DefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridViewPD2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridViewPD2.Location = new System.Drawing.Point(210, 175);
            this.dataGridViewPD2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.dataGridViewPD2.Name = "dataGridViewPD2";
            this.dataGridViewPD2.ReadOnly = true;
            this.dataGridViewPD2.RowHeadersVisible = false;
            this.dataGridViewPD2.Size = new System.Drawing.Size(708, 75);
            this.dataGridViewPD2.TabIndex = 3;
            this.dataGridViewPD2.SelectionChanged += new System.EventHandler(this.dataGridViewPD1_SelectionChanged);
            // 
            // radioButtonPD2
            // 
            this.radioButtonPD2.AutoSize = true;
            this.radioButtonPD2.Location = new System.Drawing.Point(4, 201);
            this.radioButtonPD2.Margin = new System.Windows.Forms.Padding(4, 31, 4, 5);
            this.radioButtonPD2.Name = "radioButtonPD2";
            this.radioButtonPD2.Size = new System.Drawing.Size(170, 24);
            this.radioButtonPD2.TabIndex = 2;
            this.radioButtonPD2.TabStop = true;
            this.radioButtonPD2.Text = "Линия 2 ПД весы 5";
            this.radioButtonPD2.UseVisualStyleBackColor = true;
            // 
            // dataGridViewOD1
            // 
            this.dataGridViewOD1.AllowUserToAddRows = false;
            this.dataGridViewOD1.AllowUserToResizeColumns = false;
            this.dataGridViewOD1.AllowUserToResizeRows = false;
            this.dataGridViewOD1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewOD1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.Transparent;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewOD1.DefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridViewOD1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridViewOD1.Location = new System.Drawing.Point(210, 90);
            this.dataGridViewOD1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.dataGridViewOD1.Name = "dataGridViewOD1";
            this.dataGridViewOD1.ReadOnly = true;
            this.dataGridViewOD1.RowHeadersVisible = false;
            this.dataGridViewOD1.Size = new System.Drawing.Size(708, 75);
            this.dataGridViewOD1.TabIndex = 2;
            this.dataGridViewOD1.SelectionChanged += new System.EventHandler(this.dataGridViewPD1_SelectionChanged);
            // 
            // radioButtonOD1
            // 
            this.radioButtonOD1.AutoSize = true;
            this.radioButtonOD1.Location = new System.Drawing.Point(4, 116);
            this.radioButtonOD1.Margin = new System.Windows.Forms.Padding(4, 31, 4, 5);
            this.radioButtonOD1.Name = "radioButtonOD1";
            this.radioButtonOD1.Size = new System.Drawing.Size(170, 24);
            this.radioButtonOD1.TabIndex = 1;
            this.radioButtonOD1.TabStop = true;
            this.radioButtonOD1.Text = "Линия 1 ОД весы 2";
            this.radioButtonOD1.UseVisualStyleBackColor = true;
            // 
            // dataGridViewPD1
            // 
            this.dataGridViewPD1.AllowUserToAddRows = false;
            this.dataGridViewPD1.AllowUserToResizeColumns = false;
            this.dataGridViewPD1.AllowUserToResizeRows = false;
            this.dataGridViewPD1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewPD1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.Transparent;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewPD1.DefaultCellStyle = dataGridViewCellStyle4;
            this.dataGridViewPD1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridViewPD1.Location = new System.Drawing.Point(210, 5);
            this.dataGridViewPD1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.dataGridViewPD1.Name = "dataGridViewPD1";
            this.dataGridViewPD1.ReadOnly = true;
            this.dataGridViewPD1.RowHeadersVisible = false;
            this.dataGridViewPD1.Size = new System.Drawing.Size(708, 75);
            this.dataGridViewPD1.TabIndex = 1;
            this.dataGridViewPD1.SelectionChanged += new System.EventHandler(this.dataGridViewPD1_SelectionChanged);
            // 
            // radioButtonPD1
            // 
            this.radioButtonPD1.AutoSize = true;
            this.radioButtonPD1.Location = new System.Drawing.Point(4, 31);
            this.radioButtonPD1.Margin = new System.Windows.Forms.Padding(4, 31, 4, 5);
            this.radioButtonPD1.Name = "radioButtonPD1";
            this.radioButtonPD1.Size = new System.Drawing.Size(170, 24);
            this.radioButtonPD1.TabIndex = 0;
            this.radioButtonPD1.TabStop = true;
            this.radioButtonPD1.Text = "Линия 1 ПД весы 6";
            this.radioButtonPD1.UseVisualStyleBackColor = true;
            // 
            // SelectRecipeToClose
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(938, 435);
            this.Controls.Add(this.tableLayoutPanelMain);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "SelectRecipeToClose";
            this.Text = "Завершение рецепта";
            this.tableLayoutPanelMain.ResumeLayout(false);
            this.flowLayoutPanelButtons.ResumeLayout(false);
            this.groupBoxChoose.ResumeLayout(false);
            this.tableLayoutPanelRecipes.ResumeLayout(false);
            this.tableLayoutPanelRecipes.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewOD2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewPD2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewOD1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewPD1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelMain;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanelButtons;
        private System.Windows.Forms.Button buttonCloseForm;
        private System.Windows.Forms.Button buttonFinishRecipe;
        private System.Windows.Forms.RadioButton radioButtonOD2;
        private System.Windows.Forms.DataGridView dataGridViewOD2;
        private System.Windows.Forms.RadioButton radioButtonPD2;
        private System.Windows.Forms.DataGridView dataGridViewPD2;
        private System.Windows.Forms.RadioButton radioButtonOD1;
        private System.Windows.Forms.DataGridView dataGridViewOD1;
        private System.Windows.Forms.RadioButton radioButtonPD1;
        private System.Windows.Forms.DataGridView dataGridViewPD1;
        private System.Windows.Forms.GroupBox groupBoxChoose;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelRecipes;
    }
}