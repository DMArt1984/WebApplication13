select NULL as bunker, N'�����' as name, NULL as percentage, 
ROUND(SUM(weight),3) as weight, ROUND(SUM(dbo.recipe_batch.weightFact),3) as weightFact,
ROUND(SUM(dbo.recipe_batch.weightFact)-SUM(weight),3) as deviationKilos,
Round((SUM(dbo.recipe_batch.weightFact) - SUM(weight))/(NULLIF(SUM(weight),0)/100),3) as deviationPercents, 
batchNum from dbo.recipe_batch INNER JOIN dbo.recipe_ingredient ON dbo.recipe_batch.id_ingredient = dbo.recipe_ingredient.id 
where id_ingredient in (select id from dbo.recipe_ingredient where id_recipe = 3337) group by batchNum   order by batchNum asc 