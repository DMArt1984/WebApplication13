﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Windows.Forms;

namespace LKZ_MF_Widget.RecipeDetails
{
    public partial class RecipeDetails : Form
    {
        private readonly StatsGetter _getter;
        private int _currentBatch = 0;
        private int _maxBatch = 0;
        private int _minBatch = 0;
        public RecipeDetails(int id)
        {
            InitializeComponent();
            Text += id;
            TopMost = true;
            CenterToScreen();
            _getter = new StatsGetter(id);
            InitDgvBasicStats(dataGridViewBasicStats);
            InitDgvRecipe(dataGridViewRecipe);
            FillBasicData(dataGridViewBasicStats, id);
            FillRecipeData(dataGridViewRecipe, id);
            InitDgvPriority(dataGridViewPriority);
            FillPriorityData(dataGridViewPriority, id);
            InitDgvBatches(dataGridViewBatches);
            FillDgvBatches(dataGridViewBatches, id);
            CheckButtons();
            
        }

        private void FillDgvBatches(DataGridView dgv, int id)
        {
            if (dgv.InvokeRequired)
            {
                dgv.Invoke(new MethodInvoker(() => dgv.DataSource = _getter.GetBatches(id)));
            }
            else
                dgv.DataSource = _getter.GetBatches(id);
            dgv.Refresh();
            _maxBatch = _getter.GetMaxBatchNum(id);
            _minBatch = _getter.GetMinBatchNum(id);
            _currentBatch = _minBatch;
            trackBarBatchNum.Minimum = _minBatch;
            trackBarBatchNum.Maximum = _maxBatch;
            trackBarBatchNum.Visible = _maxBatch != 0;
            SetCurrentBatch(_currentBatch);
        }

        //Записываем отвес в лейбу и выставляем нужный номер отвеса
        private void SetCurrentBatch(int batchNum)
        {
            labelBatchNumber.Text = "Отвес № " + batchNum + " из " + _maxBatch;
            var dataTable = dataGridViewBatches.DataSource as DataTable;
            if (dataTable != null)
                dataTable.DefaultView.RowFilter = string.Format("batchNum = '{0}'", batchNum);
        }

        private void InitDgvBatches(DataGridView dgv)
        {
            var colNames = new List<KeyValuePair<string, string>>
            {   
                new KeyValuePair<string, string>("Наименование","name"),
                new KeyValuePair<string, string>("Доля в смеси, %","percentage"),
                new KeyValuePair<string, string>("Требуемый вес, кг.","weight"),
                new KeyValuePair<string, string>("Фактический вес, кг.","weightFact"),
                new KeyValuePair<string, string>("Отклонение, кг.","deviationKilos"),
                new KeyValuePair<string, string>("Отклонение, %","deviationPercents"),
                new KeyValuePair<string, string>("Номер отвеса","batchNum"),
                new KeyValuePair<string, string>("Бункер","bunker")
            };
            for (int i = 0; i < colNames.Count; i++)
            {
                var column = new DataGridViewTextBoxColumn();
                dgv.Columns.Add(column);
                dgv.Columns[i].DataPropertyName = colNames[i].Value;
                dgv.Columns[i].Name = colNames[i].Value;
                dgv.Columns[i].HeaderText = colNames[i].Key;
                if (i != 0)
                {
                    dgv.Columns[i].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                    dgv.Columns[i].DefaultCellStyle.Format = "N3";
                }
            }
            dgv.Columns[6].Visible = false;
            dgv.Columns[7].Visible = false;
        }

        private void FillPriorityData(DataGridView dgv, int id)
        {
            if (dgv.InvokeRequired)
            {
                dgv.Invoke(new MethodInvoker(() => dgv.DataSource = _getter.GetPriorities(id)));
            }
            else
                dgv.DataSource = _getter.GetPriorities(id);
            dgv.Refresh();
        }

        private void InitDgvPriority(DataGridView dgv)
        {
            var colNames = new List<KeyValuePair<string, string>>
            {   
                new KeyValuePair<string, string>("Наименование","name"),
                new KeyValuePair<string, string>("Бункер","bunker"),
                new KeyValuePair<string, string>("Приоритет","priority")
            };
            for (int i = 0; i < colNames.Count; i++)
            {
                var column = new DataGridViewTextBoxColumn();
                dgv.Columns.Add(column);
                dgv.Columns[i].DataPropertyName = colNames[i].Value;
                dgv.Columns[i].Name = colNames[i].Value;
                dgv.Columns[i].HeaderText = colNames[i].Key;
                if (i != 0)
                {
                    dgv.Columns[i].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                }
            }
        }

        private void InitDgvRecipe(DataGridView dgv)
        {
            var colNames = new List<KeyValuePair<string,string>>
            {   
                new KeyValuePair<string, string>("Наименование","name"),
                new KeyValuePair<string, string>("Доля в смеси, %","percentage"),
                new KeyValuePair<string, string>("Масса, кг.","weight"),
                new KeyValuePair<string, string>("Фактическая масса, кг.","weightFact"),
                new KeyValuePair<string, string>("Отклонение, кг.","deviationKilos"),
                new KeyValuePair<string, string>("Отклонение, %","deviationPercentage"),
                new KeyValuePair<string, string>("Бункер","bunker")
            };
            for (int i = 0; i < colNames.Count; i++)
            {
                var column = new DataGridViewTextBoxColumn();
                dgv.Columns.Add(column);
                dgv.Columns[i].DataPropertyName = colNames[i].Value;
                dgv.Columns[i].Name = colNames[i].Value;
                dgv.Columns[i].HeaderText = colNames[i].Key;
                if (i != 0)
                {
                    dgv.Columns[i].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                    dgv.Columns[i].DefaultCellStyle.Format = "N3";
                }
            }
            dgv.Columns[6].Visible = false;
        }

        //Заполняем рецепт в основную информацию
        private void FillRecipeData(DataGridView dgv, int id)
        {
            DataTable dt = _getter.GetRecipe(id);
            AddTotalToRecipeDataTable(dt);
            if (dgv.InvokeRequired)
            {
                dgv.Invoke(new MethodInvoker(() => dgv.DataSource = dt));
            }
            else
                dgv.DataSource = dt;
            CheckComplitness();
            dgv.Refresh();
        }
        //Добавляем "Итого", как в отчете
        private void AddTotalToRecipeDataTable(DataTable dt)
        {
            double totalWeight = 0;
            double totalWeightFact = 0;
            foreach (DataRow r in dt.Rows)
            {
                try
                {
                    totalWeight += Convert.ToSingle(r[3]);
                }
                catch
                {
                    totalWeight += 0;
                }
                try
                {
                    totalWeightFact += Convert.ToSingle(r[4]);
                }
                catch
                {
                    totalWeightFact += 0;
                }
            }
            DataRow row = dt.NewRow();
            row[1] = "Итого";
            row[3] = totalWeight;
            row[4] = totalWeightFact;
            row[5] = totalWeightFact - totalWeight;
            row[6] = (totalWeightFact - totalWeight)/(totalWeight/100);
            dt.Rows.Add(row);

        }

        //Если рецепт не заврешен, то отчищаем столбцы в рецепте
        private void CheckComplitness()
        {
            if (dataGridViewBasicStats.Rows[5].Cells[1].Value.ToString().Trim().Equals("Еще не выполнялся"))
            {
               // dataGridViewRecipe.Columns[3].Visible = false;
                dataGridViewRecipe.Columns[4].Visible = false;
                dataGridViewRecipe.Columns[5].Visible = false;
                dataGridViewRecipe.Columns[6].Visible = false;
            }
            if (dataGridViewBasicStats.Rows[5].Cells[1].Value.ToString().Trim().Equals("В работе"))
            {
                SwitchToBatchSumResults();
            }
        }
        //Убираем таблицу расхода и ставим на ее место подсчет расхода по отвесам для рецептов "в работе"
        private void SwitchToBatchSumResults()
        {
            string recipeId = dataGridViewBasicStats.Rows[0].Cells[1].Value.ToString().Trim();
            dataGridViewRecipe.Columns[4].Visible = false;
            dataGridViewRecipe.Columns[5].Visible = false;
            dataGridViewRecipe.Columns[6].Visible = false;
            DataTable dat = new DataTable();
            dat.Columns.Add(new DataColumn() { ColumnName = "Наименование", DataType = typeof(string) });
            dat.Columns.Add(new DataColumn() { ColumnName = "Доля в смеси, %", DataType = typeof(double) });
            dat.Columns.Add(new DataColumn() { ColumnName = "Задание, кг.", DataType = typeof(double) });
            dat.Columns.Add(new DataColumn() { ColumnName = "Выработка, кг.", DataType = typeof(double) });
            dat.Columns.Add(new DataColumn() { ColumnName = "Выработка, %", DataType = typeof(double) });
            dat.Columns.Add(new DataColumn() { ColumnName = "Осталось, кг.", DataType = typeof(double) });
            double totalWeight = 0;
            double totalWeightBatch = 0;
            for (int i = 0; i < dataGridViewRecipe.RowCount - 1; i++)
            {
                string ingredientName = dataGridViewRecipe.Rows[i].Cells[1].Value.ToString().Trim();
                string query = "select SUM(weightFact) as batchSum from dbo.recipe_batch where id_ingredient = (select id from dbo.recipe_ingredient where id_recipe = " + recipeId +
                               " and name = N'" + ingredientName + "')";
                DataTable dt = DBClasses.DbConnect.GetDbInstance().PerformQuery(query);
                double w;
                double tmp;
                if (dt.Rows.Count == 1)
                {
                    try
                    {
                        w = Convert.ToSingle(dt.Rows[0]["batchSum"]);
                    }
                    catch (Exception)
                    {
                        w = 0;
                    }
                    try
                    {
                        tmp = Convert.ToSingle(dataGridViewRecipe.Rows[i].Cells[3].Value);
                    }
                    catch (Exception)
                    {
                        tmp = 0;
                    }
                    dat.Rows.Add();
                    dat.Rows[i][0] = dataGridViewRecipe.Rows[i].Cells[1].Value;
                    dat.Rows[i][1] = dataGridViewRecipe.Rows[i].Cells[2].Value;
                    dat.Rows[i][2] = dataGridViewRecipe.Rows[i].Cells[3].Value;
                    dat.Rows[i][3] = w;   //суммарный вес по отвесам
                    totalWeightBatch += w;
                    totalWeight += tmp;
                    dat.Rows[i][4] = w / (tmp / 100) - 100; //процент уже сдозированного материала
                    dat.Rows[i][5] = tmp - w;  //остаток для дозирования в кг
                }
            }
            dat.Rows.Add();
            dat.Rows[dat.Rows.Count - 1][0] = "Итого";
            dat.Rows[dat.Rows.Count - 1][2] = totalWeight;
            dat.Rows[dat.Rows.Count - 1][3] = totalWeightBatch;
            dat.Rows[dat.Rows.Count - 1][4] = totalWeightBatch/(totalWeight/100)-100;
            dat.Rows[dat.Rows.Count - 1][5] = totalWeight - totalWeightBatch;
            if (dataGridViewRecipe.InvokeRequired)
            {
                dataGridViewRecipe.Invoke(new MethodInvoker(() => dataGridViewRecipe.DataSource = dat));
            }
            else
                dataGridViewRecipe.DataSource = dat;
            for (int i = 1; i < 6; i++)
            {
                dataGridViewRecipe.Columns[i].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dataGridViewRecipe.Columns[i].DefaultCellStyle.Format = "N3";
            }
            dataGridViewRecipe.Update();
            dataGridViewRecipe.Refresh();
        }

        private void InitDgvBasicStats(DataGridView dgv)
        {
            for (var i = 0; i < 2; i++)
            {
                var column = new DataGridViewTextBoxColumn();
                dgv.Columns.Add(column);
                dgv.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            }
            dgv.Columns[0].DataPropertyName = "statName";
            dgv.Columns[0].Name = "statName";
            dgv.Columns[0].Width = 200;

            dgv.Columns[1].DataPropertyName = "statValue";
            dgv.Columns[1].Name = "statValue";
        }

        //Заполняем базовую информацию
        private void FillBasicData(DataGridView dgv, int id)
        {
            var statNames = new List<string>{"Номер","Линия", "Название", "Качество", @"Задание на к/к, кг.", 
              //  "Требуемый вес, кг.", "Фактический вес, кг.", "Отклонение, кг.", "Отклонение, %",   //Данные показатели перенесены в нижнюю таблицу для приведения в соотвествие с отчетами
                "Статус", "Комментарий", "Служебная информация", "Создан", "Запущен в работу", "Завершен", "Продолжительность"};
            for (int i = 0; i < statNames.Count; i++)
            {
                dgv.Rows.Add();
                dgv.Rows[i].Cells[0].Value = statNames[i];
            }

            Dictionary<string, string> stats = _getter.GetBasicStats(statNames, id);
            foreach (DataGridViewRow r in dgv.Rows)
            {
                var buf = r.Cells[0].Value.ToString();
                if(stats.ContainsKey(buf))
                    r.Cells[1].Value = stats[buf];
            }
        }

        private void buttonLeft_Click(object sender, System.EventArgs e)
        {
            _currentBatch -= 1;
            trackBarBatchNum.Value = _currentBatch;
            SetCurrentBatch(_currentBatch);
            CheckButtons();
        }

        //Проверяем доступность кнопок
        private void CheckButtons()
        {
            if (_maxBatch == 0)
            {
                buttonLeft.Enabled = false;
                buttonRight.Enabled = false;
                return;
            }
            buttonLeft.Enabled = _currentBatch != _minBatch;
            buttonRight.Enabled = _currentBatch != _maxBatch;
        }

        private void buttonRight_Click(object sender, System.EventArgs e)
        {
            _currentBatch += 1;
            trackBarBatchNum.Value = _currentBatch;
            SetCurrentBatch(_currentBatch);
            CheckButtons();
        }

        private void trackBarBatchNum_ValueChanged(object sender, EventArgs e)
        {
            _currentBatch = trackBarBatchNum.Value;
            SetCurrentBatch(_currentBatch);
            CheckButtons();
        }
    }
}
