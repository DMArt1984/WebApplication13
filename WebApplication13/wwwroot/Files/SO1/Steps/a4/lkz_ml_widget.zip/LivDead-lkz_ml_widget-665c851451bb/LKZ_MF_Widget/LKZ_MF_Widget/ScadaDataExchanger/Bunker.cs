﻿using System.Runtime.InteropServices;

namespace LKZ_MF_Widget.ScadaDataExchanger
{
    //Возвращаем этот класс в скаду для чтения данных о заявке
    [ProgId("LKZ_MF_Widget.Bunker")]
    [ComVisible(true)]
    [ClassInterface(ClassInterfaceType.AutoDispatch)]
    public class Bunker
    {
        public bool InUse;
        public int Priority;
        public float Task;

        public Bunker(float task, int priority, bool inUse = false)
        {
            Task = task;
            Priority = priority;
            InUse = inUse;
        }

        public Bunker()
        {
            Task = 0f;
            Priority = 0;
            InUse = false;
        }
    }
}