﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Windows.Forms;
using iTextSharp.text;
using iTextSharp.text.pdf;

namespace LKZ_MF_Widget.Reports
{
    //Для формирования пустографки с расходом материала
    class ReportConsumption
    {
        private DataGridView _dgv;
        //В конструктор передается таблица с результатами расчета расхода
        public ReportConsumption(DataGridView dgv)
        {
            _dgv = dgv;
        }

        public void PrintConsumption()
        {
            MakeConsumption(true);
        }

        public void SaveConsumption()
        {
            MakeConsumption(false);
        }

        private void MakeConsumption(bool print)
        {
            if(_dgv.Rows.Count == 0)
                return;
            var fontsfolder = Environment.GetFolderPath(Environment.SpecialFolder.Fonts);
            var baseFont = BaseFont.CreateFont(fontsfolder + "\\times.ttf", BaseFont.IDENTITY_H, BaseFont.EMBEDDED);
            string folderPath = GetPath(print);
            if (folderPath.Equals(string.Empty))
                return;
            var pdfTable = new PdfPTable(2) { HorizontalAlignment = Element.ALIGN_CENTER };
            pdfTable.DefaultCell.Padding = 3;
            pdfTable.WidthPercentage = 100;
            pdfTable.HorizontalAlignment = Element.ALIGN_LEFT;
            var f = new Font(baseFont, 11);
            pdfTable.DefaultCell.Phrase = new Phrase { Font = f };
            pdfTable.DefaultCell.VerticalAlignment = Element.ALIGN_CENTER;
            using (var stream = new FileStream(folderPath + ".pdf", FileMode.Create))
            {
                var pdfDoc = new Document(PageSize.A4, 20f, 20f, 30f, 30f); //Для альбомной добавить к А4.Rotate()
                PdfWriter.GetInstance(pdfDoc, stream);
                pdfDoc.Open();
                var para = new Paragraph("Расход сырья", new Font(f) { Size = 18 })
                {
                    Alignment = Element.ALIGN_CENTER,
                    SpacingAfter = 10f,
                    SpacingBefore = 0f
                };
               
                //Делаем заголовок для таблицы
                List<string> header = new List<string>
            {
                "Наименование",
                "Плановый расход, кг."
            };
                for (int i = 0; i < header.Count; i++)
                {
                    var num = new PdfPCell(new Phrase(header[i], f))
                    {
                        BackgroundColor = new BaseColor(240, 240, 240)
                    };
                    pdfTable.AddCell(num);
                }
                pdfDoc.Add(para);
                for (int i = 0; i < _dgv.Rows.Count; i++)
                {
                    string name = _dgv.Rows[i].Cells[0].Value.ToString();
                    pdfTable.AddCell(new PdfPCell(new Phrase(name,f)));
                    string cons = _dgv.Rows[i].Cells[1].Value.ToString();
                    pdfTable.AddCell(new PdfPCell(new Phrase(cons, f)));
                }
                pdfDoc.Add(pdfTable);
                pdfDoc.Add(new Phrase("Сформировано " + DateTime.Now, new Font(f) { Size = 8 }));
                pdfDoc.Close();
                stream.Close();
            }
            if (print)
            {
                TryPrint(folderPath);
            }
            else
            {
                TryOpen(folderPath);
            }
        }

        //Для открытия файла pdf по пути до него
        private void TryOpen(string folderPath)
        {
            try
            {
                Process.Start(folderPath + ".pdf"); //открываем файл после сохранения
            }
            catch (Exception)
            {
                MessageBox.Show("Не удалось открыть файл отчета", "Ошибка", MessageBoxButtons.OK,
                    MessageBoxIcon.Error, MessageBoxDefaultButton.Button1, (MessageBoxOptions)0x40000);
            }
        }
        //Для печати файла pdf по пути до него
        private void TryPrint(string folderPath)
        {
            try
            {
                var sArgs = " /p \"" + folderPath + ".pdf" + "\"";
                var startInfo = new ProcessStartInfo
                {
                    FileName = @"C:\Program Files (x86)\Foxit Software\Foxit Reader\FoxitReader.exe",
                    Arguments = sArgs,
                    CreateNoWindow = true,
                    WindowStyle = ProcessWindowStyle.Hidden
                };
                var proc = Process.Start(startInfo);
                if (proc != null)
                {
                    proc.WaitForExit(10000); // Ждем 10 сек для закрытия
                    if (!proc.HasExited)
                    {
                        proc.Kill();
                        proc.Dispose();
                    }
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Не удалось распечатать файл отчета", "Ошибка", MessageBoxButtons.OK,
                    MessageBoxIcon.Error, MessageBoxDefaultButton.Button1, (MessageBoxOptions)0x40000);
            }
        }

        private string GetPath(bool print)
        {
            string folderPath = Path.GetPathRoot(Environment.SystemDirectory);
            folderPath += "Aseng\\Consumption\\" + DateTime.Now.ToString().Replace(":", "-");
            //Спрашиваем куда сохранять
            if (!print)
            {
                var dlg = new SaveFileDialog();
                dlg.FileName = DateTime.Now.ToString().Replace(":", "-");

                if (dlg.ShowDialog() != DialogResult.OK) return "";
                folderPath = dlg.FileName;
            }
            if (folderPath != string.Empty)
                Directory.CreateDirectory(Path.GetDirectoryName(folderPath));
            else
            {
                MessageBox.Show("Неверно указан путь для записи");
                return "";
            }
            return folderPath;
        }
    }
}
