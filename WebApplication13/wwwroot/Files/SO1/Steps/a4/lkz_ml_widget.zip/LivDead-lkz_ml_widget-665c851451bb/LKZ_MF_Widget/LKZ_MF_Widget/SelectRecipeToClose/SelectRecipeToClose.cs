﻿using System;
using System.Windows.Forms;
using LKZ_MF_Widget.DBClasses;

namespace LKZ_MF_Widget.SelectRecipeToClose
{
    public partial class SelectRecipeToClose : Form
    {
        public event EventHandler ChangesDone; //Излучается когда был закрыт один из рецептов
        public event EventHandler RecipeClosedPd1;
        public event EventHandler RecipeClosedOd1;
        public event EventHandler RecipeClosedPd2;
        public event EventHandler RecipeClosedOd2;
        private int _id = 0;
        private string _place = "";
        public SelectRecipeToClose()
        {
            InitializeComponent();
            CenterToScreen();
            TopMost = true;
            InitDgv(dataGridViewOD1);
            InitDgv(dataGridViewPD1);
            InitDgv(dataGridViewOD2);
            InitDgv(dataGridViewPD2);
            FillTables();
            
        }

        //Заполнение таблиц данными 
        private void FillTables()
        {
            FillTableByPlace("W6");
            FillTableByPlace("W2");
            FillTableByPlace("W5");
            FillTableByPlace("W4");
        }

        //Заполнение таблицы для определенных весов
        private void FillTableByPlace(string p)
        {
            var query = "select id, name, weight, timeCreate from dbo.recipe where isInProgress = 1 and place = '" + p +
                        "'";
            var dt = DbConnect.GetDbInstance().PerformQuery(query);
            var dgv = new DataGridView();
            if (p.Equals("W6"))
                dgv = dataGridViewPD1;
            if (p.Equals("W2"))
                dgv = dataGridViewOD1;
            if (p.Equals("W5"))
                dgv = dataGridViewPD2;
            if (p.Equals("W4"))
                dgv = dataGridViewOD2;
            if (dgv.InvokeRequired)
            {
                dgv.Invoke(new MethodInvoker(() => dgv.DataSource = dt));
            }
            else
            {
                dgv.DataSource = dt;
            }
            dgv.Refresh();
            if (dt.Rows.Count == 0)
            {
                dgv.Enabled = false;
                if (p.Equals("W6"))
                    radioButtonPD1.Enabled = false;
                if (p.Equals("W2"))
                    radioButtonOD1.Enabled = false;
                if (p.Equals("W5"))
                    radioButtonPD2.Enabled = false;
                if (p.Equals("W4"))
                    radioButtonOD2.Enabled = false;
            }
        }

        //Инициализация DGV
        private void InitDgv(DataGridView input)
        {
            var dgv = input;
            var count = 4;
            for (var i = 0; i < count; i++)
            {
                var column = new DataGridViewTextBoxColumn();
                dgv.Columns.Add(column);
            }
            dgv.Columns[0].DataPropertyName = "id";
            dgv.Columns[0].Name = "№";
            dgv.Columns[0].HeaderText = "№";
            dgv.Columns[0].Width = 60;

            dgv.Columns[1].DataPropertyName = "name";
            dgv.Columns[1].Name = "name";
            dgv.Columns[1].HeaderText = "Наименование";

            dgv.Columns[2].DataPropertyName = "weight";
            dgv.Columns[2].Name = "Вес, кг.";
            dgv.Columns[2].HeaderText = "Вес, кг.";
            dgv.Columns[2].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgv.Columns[2].DefaultCellStyle.Format = "N0";

            dgv.Columns[3].DataPropertyName = "timeCreate";
            dgv.Columns[3].Name = "Дата добавления";
            dgv.Columns[3].HeaderText = "Дата добавления";
            dgv.Columns[3].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;

            //Избавляемся от серого просвета под списком
            dgv.RowTemplate.Height = dgv.Height - dgv.ColumnHeadersHeight;
        }

        private void buttonCloseForm_Click(object sender, EventArgs e)
        {
            
            Dispose();
        }

        private void buttonFinishRecipe_Click(object sender, EventArgs e)
        {
            if (!radioButtonOD1.Checked && !radioButtonOD2.Checked && !radioButtonPD1.Checked && !radioButtonPD2.Checked)
            {
                MessageBox.Show("Не выбрана ни одна заявка для закрытия", "Внимание", MessageBoxButtons.OK,
                    MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1, (MessageBoxOptions)0x40000);
                return;
            }
            if (radioButtonOD1.Checked)
            {
                _id = Convert.ToInt32(dataGridViewOD1.Rows[0].Cells[0].Value);
                _place = "W2";
                if(RecipeClosedOd1 != null)  RecipeClosedOd1(this, new EventArgs());
            }
            if (radioButtonPD1.Checked)
            {
                _id = Convert.ToInt32(dataGridViewPD1.Rows[0].Cells[0].Value);
                _place = "W6";
                if (RecipeClosedPd1 != null) RecipeClosedPd1(this, new EventArgs());
            }
            if (radioButtonOD2.Checked)
            {
                _id = Convert.ToInt32(dataGridViewOD2.Rows[0].Cells[0].Value);
                _place = "W4";
                if (RecipeClosedOd2 != null) RecipeClosedOd2(this, new EventArgs());
            }
            if (radioButtonPD2.Checked)
            {
                _id = Convert.ToInt32(dataGridViewPD2.Rows[0].Cells[0].Value);
                _place = "W5";
                if (RecipeClosedPd2 != null) RecipeClosedPd2(this, new EventArgs());
            }
           // buttonCloseForm.Enabled = false;
            Dispose();
        }

        //Метод для закрытия заявки
        public void CloseRequest()
        {
            if (_id == 0 || _place.Equals(string.Empty))
            {
                MessageBox.Show("Ошибка при закрытии рецепта", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1, (MessageBoxOptions)0x40000);
                return;
            }
            var query = "update dbo.recipe set isInProgress = 0, isFinishedErr = 1, timeFinished = getdate() where id = " + _id;
            DbConnect.GetDbInstance().PerformNonQuery(query);
            query =
                "update dbo.bunker_card set isInUse = 0, task = 0, currentPriority = 0, currentIngredientId = 0 where place = '" +
                _place + "'";
            DbConnect.GetDbInstance().PerformNonQuery(query);
            MessageBox.Show("Рецепт № " + _id + " завершен вручную", "Внимание", MessageBoxButtons.OK,
                MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, (MessageBoxOptions)0x40000);
            if (ChangesDone != null) ChangesDone(this, new EventArgs());
            Dispose();
        }

        private void dataGridViewPD1_SelectionChanged(object sender, EventArgs e)
        {
            var dgv = sender as DataGridView;
            if (dgv != null) dgv.ClearSelection();
        }
    }
}