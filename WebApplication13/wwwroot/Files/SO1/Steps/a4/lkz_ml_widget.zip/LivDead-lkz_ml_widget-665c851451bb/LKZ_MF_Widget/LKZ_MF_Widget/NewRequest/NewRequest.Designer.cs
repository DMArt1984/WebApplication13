﻿namespace LKZ_MF_Widget.NewRequest
{
    partial class NewRequest
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(NewRequest));
            this.tableLayoutPanelNewRequest = new System.Windows.Forms.TableLayoutPanel();
            this.dataGridViewIngredients = new System.Windows.Forms.DataGridView();
            this.flowLayoutPanelButtons = new System.Windows.Forms.FlowLayoutPanel();
            this.buttonCancel = new System.Windows.Forms.Button();
            this.buttonAdd = new System.Windows.Forms.Button();
            this.buttonSetPriorities = new System.Windows.Forms.Button();
            this.buttonAddIngredient = new System.Windows.Forms.Button();
            this.tableLayoutPanelInfo = new System.Windows.Forms.TableLayoutPanel();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.textBoxRecipeName = new System.Windows.Forms.TextBox();
            this.textBoxWeight = new System.Windows.Forms.TextBox();
            this.textBoxWeightKK = new System.Windows.Forms.TextBox();
            this.textBoxQuality = new System.Windows.Forms.TextBox();
            this.textBoxComment = new System.Windows.Forms.TextBox();
            this.checkBoxLine = new System.Windows.Forms.CheckBox();
            this.groupBoxPlace = new System.Windows.Forms.GroupBox();
            this.radioButtonOd2 = new System.Windows.Forms.RadioButton();
            this.radioButtonPd2 = new System.Windows.Forms.RadioButton();
            this.radioButtonOd1 = new System.Windows.Forms.RadioButton();
            this.radioButtonPd1 = new System.Windows.Forms.RadioButton();
            this.checkBoxCountWeight = new System.Windows.Forms.CheckBox();
            this.flowLayoutPanelCountWeight = new System.Windows.Forms.FlowLayoutPanel();
            this.textBoxWeightToCount = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.textBoxProcentsToCount = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.flowLayoutPanelButtonsPriority = new System.Windows.Forms.FlowLayoutPanel();
            this.buttonCancelPriority = new System.Windows.Forms.Button();
            this.buttonAddPriority = new System.Windows.Forms.Button();
            this.buttonBackToIngr = new System.Windows.Forms.Button();
            this.flowLayoutPanelSummTag = new System.Windows.Forms.FlowLayoutPanel();
            this.labelSumm = new System.Windows.Forms.Label();
            this.panelPriorities = new System.Windows.Forms.Panel();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.panelPriorButtons = new System.Windows.Forms.Panel();
            this.buttonDown = new System.Windows.Forms.Button();
            this.buttonUp = new System.Windows.Forms.Button();
            this.dataGridViewPriorities = new System.Windows.Forms.DataGridView();
            this.labelNotificationGeneral = new System.Windows.Forms.Label();
            this.flowLayoutPanelNotification = new System.Windows.Forms.FlowLayoutPanel();
            this.labelNotificationPriorities = new System.Windows.Forms.Label();
            this.tableLayoutPanelNewRequest.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewIngredients)).BeginInit();
            this.flowLayoutPanelButtons.SuspendLayout();
            this.tableLayoutPanelInfo.SuspendLayout();
            this.groupBoxPlace.SuspendLayout();
            this.flowLayoutPanelCountWeight.SuspendLayout();
            this.flowLayoutPanelButtonsPriority.SuspendLayout();
            this.flowLayoutPanelSummTag.SuspendLayout();
            this.panelPriorities.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.panelPriorButtons.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewPriorities)).BeginInit();
            this.flowLayoutPanelNotification.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanelNewRequest
            // 
            this.tableLayoutPanelNewRequest.ColumnCount = 3;
            this.tableLayoutPanelNewRequest.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 400F));
            this.tableLayoutPanelNewRequest.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 400F));
            this.tableLayoutPanelNewRequest.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 464F));
            this.tableLayoutPanelNewRequest.Controls.Add(this.dataGridViewIngredients, 0, 0);
            this.tableLayoutPanelNewRequest.Controls.Add(this.flowLayoutPanelButtons, 1, 1);
            this.tableLayoutPanelNewRequest.Controls.Add(this.tableLayoutPanelInfo, 1, 0);
            this.tableLayoutPanelNewRequest.Controls.Add(this.flowLayoutPanelButtonsPriority, 2, 1);
            this.tableLayoutPanelNewRequest.Controls.Add(this.flowLayoutPanelSummTag, 0, 1);
            this.tableLayoutPanelNewRequest.Controls.Add(this.panelPriorities, 2, 0);
            this.tableLayoutPanelNewRequest.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanelNewRequest.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanelNewRequest.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tableLayoutPanelNewRequest.Name = "tableLayoutPanelNewRequest";
            this.tableLayoutPanelNewRequest.RowCount = 2;
            this.tableLayoutPanelNewRequest.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 88.6076F));
            this.tableLayoutPanelNewRequest.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.3924F));
            this.tableLayoutPanelNewRequest.Size = new System.Drawing.Size(1184, 562);
            this.tableLayoutPanelNewRequest.TabIndex = 0;
            // 
            // dataGridViewIngredients
            // 
            this.dataGridViewIngredients.AllowUserToResizeRows = false;
            this.dataGridViewIngredients.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewIngredients.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCellsExceptHeaders;
            this.dataGridViewIngredients.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewIngredients.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridViewIngredients.Location = new System.Drawing.Point(4, 5);
            this.dataGridViewIngredients.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.dataGridViewIngredients.Name = "dataGridViewIngredients";
            this.dataGridViewIngredients.RowHeadersVisible = false;
            this.dataGridViewIngredients.Size = new System.Drawing.Size(392, 487);
            this.dataGridViewIngredients.TabIndex = 1;
            this.dataGridViewIngredients.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewIngredients_CellClick);
            this.dataGridViewIngredients.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewIngredients_CellContentClick);
            this.dataGridViewIngredients.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewIngredients_CellEndEdit);
            this.dataGridViewIngredients.CellValueChanged += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewIngredients_CellValueChanged);
            this.dataGridViewIngredients.RowsAdded += new System.Windows.Forms.DataGridViewRowsAddedEventHandler(this.dataGridViewIngredients_RowsAdded);
            this.dataGridViewIngredients.RowsRemoved += new System.Windows.Forms.DataGridViewRowsRemovedEventHandler(this.dataGridViewIngredients_RowsRemoved);
            // 
            // flowLayoutPanelButtons
            // 
            this.flowLayoutPanelButtons.Controls.Add(this.buttonCancel);
            this.flowLayoutPanelButtons.Controls.Add(this.buttonAdd);
            this.flowLayoutPanelButtons.Controls.Add(this.buttonSetPriorities);
            this.flowLayoutPanelButtons.Controls.Add(this.buttonAddIngredient);
            this.flowLayoutPanelButtons.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanelButtons.Location = new System.Drawing.Point(404, 502);
            this.flowLayoutPanelButtons.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.flowLayoutPanelButtons.Name = "flowLayoutPanelButtons";
            this.flowLayoutPanelButtons.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.flowLayoutPanelButtons.Size = new System.Drawing.Size(392, 55);
            this.flowLayoutPanelButtons.TabIndex = 0;
            // 
            // buttonCancel
            // 
            this.buttonCancel.Location = new System.Drawing.Point(276, 5);
            this.buttonCancel.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.buttonCancel.Name = "buttonCancel";
            this.buttonCancel.Size = new System.Drawing.Size(112, 35);
            this.buttonCancel.TabIndex = 1;
            this.buttonCancel.Text = "Отмена";
            this.buttonCancel.UseVisualStyleBackColor = true;
            this.buttonCancel.Click += new System.EventHandler(this.buttonCancel_Click);
            // 
            // buttonAdd
            // 
            this.buttonAdd.Location = new System.Drawing.Point(156, 5);
            this.buttonAdd.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.buttonAdd.Name = "buttonAdd";
            this.buttonAdd.Size = new System.Drawing.Size(112, 35);
            this.buttonAdd.TabIndex = 0;
            this.buttonAdd.Text = "Добавить";
            this.buttonAdd.UseVisualStyleBackColor = true;
            this.buttonAdd.Click += new System.EventHandler(this.buttonAdd_Click);
            // 
            // buttonSetPriorities
            // 
            this.buttonSetPriorities.Location = new System.Drawing.Point(242, 50);
            this.buttonSetPriorities.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.buttonSetPriorities.Name = "buttonSetPriorities";
            this.buttonSetPriorities.Size = new System.Drawing.Size(146, 35);
            this.buttonSetPriorities.TabIndex = 2;
            this.buttonSetPriorities.Text = "Задать бункера";
            this.buttonSetPriorities.UseVisualStyleBackColor = true;
            this.buttonSetPriorities.Click += new System.EventHandler(this.buttonSetPriorities_Click);
            // 
            // buttonAddIngredient
            // 
            this.buttonAddIngredient.Location = new System.Drawing.Point(64, 50);
            this.buttonAddIngredient.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.buttonAddIngredient.Name = "buttonAddIngredient";
            this.buttonAddIngredient.Size = new System.Drawing.Size(170, 35);
            this.buttonAddIngredient.TabIndex = 3;
            this.buttonAddIngredient.Text = "Новый ингредиент";
            this.buttonAddIngredient.UseVisualStyleBackColor = true;
            this.buttonAddIngredient.Click += new System.EventHandler(this.buttonAddIngredient_Click);
            // 
            // tableLayoutPanelInfo
            // 
            this.tableLayoutPanelInfo.ColumnCount = 2;
            this.tableLayoutPanelInfo.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 35.97285F));
            this.tableLayoutPanelInfo.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 64.02715F));
            this.tableLayoutPanelInfo.Controls.Add(this.label1, 0, 0);
            this.tableLayoutPanelInfo.Controls.Add(this.label2, 0, 2);
            this.tableLayoutPanelInfo.Controls.Add(this.label4, 0, 5);
            this.tableLayoutPanelInfo.Controls.Add(this.label3, 0, 4);
            this.tableLayoutPanelInfo.Controls.Add(this.label5, 0, 3);
            this.tableLayoutPanelInfo.Controls.Add(this.textBoxRecipeName, 1, 0);
            this.tableLayoutPanelInfo.Controls.Add(this.textBoxWeight, 1, 2);
            this.tableLayoutPanelInfo.Controls.Add(this.textBoxWeightKK, 1, 3);
            this.tableLayoutPanelInfo.Controls.Add(this.textBoxQuality, 1, 4);
            this.tableLayoutPanelInfo.Controls.Add(this.textBoxComment, 1, 5);
            this.tableLayoutPanelInfo.Controls.Add(this.checkBoxLine, 0, 6);
            this.tableLayoutPanelInfo.Controls.Add(this.groupBoxPlace, 1, 6);
            this.tableLayoutPanelInfo.Controls.Add(this.checkBoxCountWeight, 0, 1);
            this.tableLayoutPanelInfo.Controls.Add(this.flowLayoutPanelCountWeight, 1, 1);
            this.tableLayoutPanelInfo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanelInfo.Location = new System.Drawing.Point(404, 5);
            this.tableLayoutPanelInfo.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tableLayoutPanelInfo.Name = "tableLayoutPanelInfo";
            this.tableLayoutPanelInfo.RowCount = 7;
            this.tableLayoutPanelInfo.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanelInfo.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 46F));
            this.tableLayoutPanelInfo.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanelInfo.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanelInfo.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanelInfo.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanelInfo.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 31F));
            this.tableLayoutPanelInfo.Size = new System.Drawing.Size(392, 487);
            this.tableLayoutPanelInfo.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(4, 0);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(133, 35);
            this.label1.TabIndex = 0;
            this.label1.Text = "Название рецепта";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(4, 82);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(133, 35);
            this.label2.TabIndex = 1;
            this.label2.Text = "Требуемый вес, кг.";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(4, 190);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(133, 35);
            this.label4.TabIndex = 3;
            this.label4.Text = "Комментарий";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(4, 154);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(133, 35);
            this.label3.TabIndex = 2;
            this.label3.Text = "Качество";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label5
            // 
            this.label5.Location = new System.Drawing.Point(4, 118);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(133, 35);
            this.label5.TabIndex = 4;
            this.label5.Text = "Задание на к/к";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // textBoxRecipeName
            // 
            this.textBoxRecipeName.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxRecipeName.Location = new System.Drawing.Point(145, 5);
            this.textBoxRecipeName.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxRecipeName.Name = "textBoxRecipeName";
            this.textBoxRecipeName.Size = new System.Drawing.Size(243, 26);
            this.textBoxRecipeName.TabIndex = 5;
            // 
            // textBoxWeight
            // 
            this.textBoxWeight.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxWeight.Location = new System.Drawing.Point(145, 87);
            this.textBoxWeight.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxWeight.Name = "textBoxWeight";
            this.textBoxWeight.Size = new System.Drawing.Size(243, 26);
            this.textBoxWeight.TabIndex = 6;
            this.textBoxWeight.TextChanged += new System.EventHandler(this.textBoxWeight_TextChanged);
            // 
            // textBoxWeightKK
            // 
            this.textBoxWeightKK.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxWeightKK.Location = new System.Drawing.Point(145, 123);
            this.textBoxWeightKK.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxWeightKK.Name = "textBoxWeightKK";
            this.textBoxWeightKK.Size = new System.Drawing.Size(243, 26);
            this.textBoxWeightKK.TabIndex = 7;
            this.textBoxWeightKK.TextChanged += new System.EventHandler(this.textBoxWeightKK_TextChanged);
            // 
            // textBoxQuality
            // 
            this.textBoxQuality.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxQuality.Location = new System.Drawing.Point(145, 159);
            this.textBoxQuality.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxQuality.Name = "textBoxQuality";
            this.textBoxQuality.Size = new System.Drawing.Size(243, 26);
            this.textBoxQuality.TabIndex = 8;
            this.textBoxQuality.TextChanged += new System.EventHandler(this.textBoxQuality_TextChanged);
            // 
            // textBoxComment
            // 
            this.textBoxComment.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxComment.Location = new System.Drawing.Point(145, 195);
            this.textBoxComment.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxComment.Name = "textBoxComment";
            this.textBoxComment.Size = new System.Drawing.Size(243, 26);
            this.textBoxComment.TabIndex = 9;
            // 
            // checkBoxLine
            // 
            this.checkBoxLine.Location = new System.Drawing.Point(4, 231);
            this.checkBoxLine.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.checkBoxLine.Name = "checkBoxLine";
            this.checkBoxLine.Size = new System.Drawing.Size(133, 57);
            this.checkBoxLine.TabIndex = 10;
            this.checkBoxLine.Text = "Указать линию";
            this.checkBoxLine.UseVisualStyleBackColor = true;
            this.checkBoxLine.CheckedChanged += new System.EventHandler(this.checkBoxLine_CheckedChanged);
            // 
            // groupBoxPlace
            // 
            this.groupBoxPlace.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBoxPlace.Controls.Add(this.radioButtonOd2);
            this.groupBoxPlace.Controls.Add(this.radioButtonPd2);
            this.groupBoxPlace.Controls.Add(this.radioButtonOd1);
            this.groupBoxPlace.Controls.Add(this.radioButtonPd1);
            this.groupBoxPlace.Location = new System.Drawing.Point(145, 231);
            this.groupBoxPlace.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBoxPlace.Name = "groupBoxPlace";
            this.groupBoxPlace.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBoxPlace.Size = new System.Drawing.Size(243, 106);
            this.groupBoxPlace.TabIndex = 11;
            this.groupBoxPlace.TabStop = false;
            this.groupBoxPlace.Text = "Линия";
            // 
            // radioButtonOd2
            // 
            this.radioButtonOd2.AutoSize = true;
            this.radioButtonOd2.Location = new System.Drawing.Point(130, 66);
            this.radioButtonOd2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButtonOd2.Name = "radioButtonOd2";
            this.radioButtonOd2.Size = new System.Drawing.Size(116, 24);
            this.radioButtonOd2.TabIndex = 3;
            this.radioButtonOd2.TabStop = true;
            this.radioButtonOd2.Text = "2 Линия ОД";
            this.radioButtonOd2.UseVisualStyleBackColor = true;
            // 
            // radioButtonPd2
            // 
            this.radioButtonPd2.AutoSize = true;
            this.radioButtonPd2.Location = new System.Drawing.Point(130, 29);
            this.radioButtonPd2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButtonPd2.Name = "radioButtonPd2";
            this.radioButtonPd2.Size = new System.Drawing.Size(116, 24);
            this.radioButtonPd2.TabIndex = 2;
            this.radioButtonPd2.TabStop = true;
            this.radioButtonPd2.Text = "2 Линия ПД";
            this.radioButtonPd2.UseVisualStyleBackColor = true;
            // 
            // radioButtonOd1
            // 
            this.radioButtonOd1.AutoSize = true;
            this.radioButtonOd1.Location = new System.Drawing.Point(10, 66);
            this.radioButtonOd1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButtonOd1.Name = "radioButtonOd1";
            this.radioButtonOd1.Size = new System.Drawing.Size(116, 24);
            this.radioButtonOd1.TabIndex = 1;
            this.radioButtonOd1.TabStop = true;
            this.radioButtonOd1.Text = "1 Линия ОД";
            this.radioButtonOd1.UseVisualStyleBackColor = true;
            // 
            // radioButtonPd1
            // 
            this.radioButtonPd1.AutoSize = true;
            this.radioButtonPd1.Location = new System.Drawing.Point(10, 29);
            this.radioButtonPd1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButtonPd1.Name = "radioButtonPd1";
            this.radioButtonPd1.Size = new System.Drawing.Size(116, 24);
            this.radioButtonPd1.TabIndex = 0;
            this.radioButtonPd1.TabStop = true;
            this.radioButtonPd1.Text = "1 Линия ПД";
            this.radioButtonPd1.UseVisualStyleBackColor = true;
            // 
            // checkBoxCountWeight
            // 
            this.checkBoxCountWeight.AutoSize = true;
            this.checkBoxCountWeight.Location = new System.Drawing.Point(4, 47);
            this.checkBoxCountWeight.Margin = new System.Windows.Forms.Padding(4, 11, 4, 5);
            this.checkBoxCountWeight.Name = "checkBoxCountWeight";
            this.checkBoxCountWeight.Size = new System.Drawing.Size(121, 24);
            this.checkBoxCountWeight.TabIndex = 12;
            this.checkBoxCountWeight.Text = "Расчет веса";
            this.checkBoxCountWeight.UseVisualStyleBackColor = true;
            this.checkBoxCountWeight.CheckedChanged += new System.EventHandler(this.checkBoxCountWeight_CheckedChanged);
            // 
            // flowLayoutPanelCountWeight
            // 
            this.flowLayoutPanelCountWeight.Controls.Add(this.textBoxWeightToCount);
            this.flowLayoutPanelCountWeight.Controls.Add(this.label6);
            this.flowLayoutPanelCountWeight.Controls.Add(this.textBoxProcentsToCount);
            this.flowLayoutPanelCountWeight.Controls.Add(this.label7);
            this.flowLayoutPanelCountWeight.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanelCountWeight.Location = new System.Drawing.Point(141, 36);
            this.flowLayoutPanelCountWeight.Margin = new System.Windows.Forms.Padding(0);
            this.flowLayoutPanelCountWeight.Name = "flowLayoutPanelCountWeight";
            this.flowLayoutPanelCountWeight.Size = new System.Drawing.Size(251, 46);
            this.flowLayoutPanelCountWeight.TabIndex = 13;
            // 
            // textBoxWeightToCount
            // 
            this.textBoxWeightToCount.Location = new System.Drawing.Point(4, 5);
            this.textBoxWeightToCount.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxWeightToCount.Name = "textBoxWeightToCount";
            this.textBoxWeightToCount.Size = new System.Drawing.Size(118, 26);
            this.textBoxWeightToCount.TabIndex = 0;
            this.textBoxWeightToCount.TextChanged += new System.EventHandler(this.textBoxWeightToCount_TextChanged);
            // 
            // label6
            // 
            this.label6.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(130, 8);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 8, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(51, 28);
            this.label6.TabIndex = 1;
            this.label6.Text = "кг.   X";
            // 
            // textBoxProcentsToCount
            // 
            this.textBoxProcentsToCount.Location = new System.Drawing.Point(4, 41);
            this.textBoxProcentsToCount.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxProcentsToCount.Name = "textBoxProcentsToCount";
            this.textBoxProcentsToCount.Size = new System.Drawing.Size(118, 26);
            this.textBoxProcentsToCount.TabIndex = 2;
            this.textBoxProcentsToCount.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxProcentsToCount_KeyPress);
            this.textBoxProcentsToCount.Validated += new System.EventHandler(this.textBoxProcentsToCount_Validated);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(130, 44);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 8, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(23, 20);
            this.label7.TabIndex = 3;
            this.label7.Text = "%";
            // 
            // flowLayoutPanelButtonsPriority
            // 
            this.flowLayoutPanelButtonsPriority.Controls.Add(this.buttonCancelPriority);
            this.flowLayoutPanelButtonsPriority.Controls.Add(this.buttonAddPriority);
            this.flowLayoutPanelButtonsPriority.Controls.Add(this.buttonBackToIngr);
            this.flowLayoutPanelButtonsPriority.Controls.Add(this.flowLayoutPanelNotification);
            this.flowLayoutPanelButtonsPriority.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanelButtonsPriority.FlowDirection = System.Windows.Forms.FlowDirection.RightToLeft;
            this.flowLayoutPanelButtonsPriority.Location = new System.Drawing.Point(804, 502);
            this.flowLayoutPanelButtonsPriority.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.flowLayoutPanelButtonsPriority.Name = "flowLayoutPanelButtonsPriority";
            this.flowLayoutPanelButtonsPriority.Size = new System.Drawing.Size(456, 55);
            this.flowLayoutPanelButtonsPriority.TabIndex = 4;
            // 
            // buttonCancelPriority
            // 
            this.buttonCancelPriority.Location = new System.Drawing.Point(340, 5);
            this.buttonCancelPriority.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.buttonCancelPriority.Name = "buttonCancelPriority";
            this.buttonCancelPriority.Size = new System.Drawing.Size(112, 35);
            this.buttonCancelPriority.TabIndex = 3;
            this.buttonCancelPriority.Text = "Отмена";
            this.buttonCancelPriority.UseVisualStyleBackColor = true;
            this.buttonCancelPriority.Click += new System.EventHandler(this.buttonCancelPriority_Click);
            // 
            // buttonAddPriority
            // 
            this.buttonAddPriority.Location = new System.Drawing.Point(220, 5);
            this.buttonAddPriority.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.buttonAddPriority.Name = "buttonAddPriority";
            this.buttonAddPriority.Size = new System.Drawing.Size(112, 35);
            this.buttonAddPriority.TabIndex = 1;
            this.buttonAddPriority.Text = "Добавить";
            this.buttonAddPriority.UseVisualStyleBackColor = true;
            this.buttonAddPriority.Click += new System.EventHandler(this.buttonAddPriority_Click);
            // 
            // buttonBackToIngr
            // 
            this.buttonBackToIngr.Location = new System.Drawing.Point(100, 5);
            this.buttonBackToIngr.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.buttonBackToIngr.Name = "buttonBackToIngr";
            this.buttonBackToIngr.Size = new System.Drawing.Size(112, 35);
            this.buttonBackToIngr.TabIndex = 4;
            this.buttonBackToIngr.Text = "Назад";
            this.buttonBackToIngr.UseVisualStyleBackColor = true;
            this.buttonBackToIngr.Click += new System.EventHandler(this.buttonBackToIngr_Click);
            // 
            // flowLayoutPanelSummTag
            // 
            this.flowLayoutPanelSummTag.Controls.Add(this.labelSumm);
            this.flowLayoutPanelSummTag.Controls.Add(this.labelNotificationGeneral);
            this.flowLayoutPanelSummTag.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanelSummTag.Location = new System.Drawing.Point(4, 502);
            this.flowLayoutPanelSummTag.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.flowLayoutPanelSummTag.Name = "flowLayoutPanelSummTag";
            this.flowLayoutPanelSummTag.Size = new System.Drawing.Size(392, 55);
            this.flowLayoutPanelSummTag.TabIndex = 5;
            // 
            // labelSumm
            // 
            this.labelSumm.Location = new System.Drawing.Point(4, 0);
            this.labelSumm.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelSumm.Name = "labelSumm";
            this.labelSumm.Size = new System.Drawing.Size(148, 35);
            this.labelSumm.TabIndex = 3;
            this.labelSumm.Text = "Сумма: ";
            this.labelSumm.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panelPriorities
            // 
            this.panelPriorities.Controls.Add(this.tableLayoutPanel1);
            this.panelPriorities.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelPriorities.Location = new System.Drawing.Point(804, 5);
            this.panelPriorities.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.panelPriorities.Name = "panelPriorities";
            this.panelPriorities.Size = new System.Drawing.Size(456, 487);
            this.panelPriorities.TabIndex = 6;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 75F));
            this.tableLayoutPanel1.Controls.Add(this.panelPriorButtons, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.dataGridViewPriorities, 0, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(456, 487);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // panelPriorButtons
            // 
            this.panelPriorButtons.Controls.Add(this.buttonDown);
            this.panelPriorButtons.Controls.Add(this.buttonUp);
            this.panelPriorButtons.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelPriorButtons.Location = new System.Drawing.Point(385, 5);
            this.panelPriorButtons.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.panelPriorButtons.Name = "panelPriorButtons";
            this.panelPriorButtons.Size = new System.Drawing.Size(67, 477);
            this.panelPriorButtons.TabIndex = 0;
            // 
            // buttonDown
            // 
            this.buttonDown.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonDown.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonDown.Location = new System.Drawing.Point(4, 331);
            this.buttonDown.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.buttonDown.Name = "buttonDown";
            this.buttonDown.Size = new System.Drawing.Size(58, 146);
            this.buttonDown.TabIndex = 6;
            this.buttonDown.Text = "↓";
            this.buttonDown.UseVisualStyleBackColor = true;
            this.buttonDown.Click += new System.EventHandler(this.buttonDown_Click);
            // 
            // buttonUp
            // 
            this.buttonUp.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonUp.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonUp.Location = new System.Drawing.Point(4, 5);
            this.buttonUp.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.buttonUp.Name = "buttonUp";
            this.buttonUp.Size = new System.Drawing.Size(58, 146);
            this.buttonUp.TabIndex = 5;
            this.buttonUp.Text = "↑";
            this.buttonUp.UseVisualStyleBackColor = true;
            this.buttonUp.Click += new System.EventHandler(this.buttonUp_Click);
            // 
            // dataGridViewPriorities
            // 
            this.dataGridViewPriorities.AllowUserToAddRows = false;
            this.dataGridViewPriorities.AllowUserToResizeRows = false;
            this.dataGridViewPriorities.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewPriorities.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCellsExceptHeaders;
            this.dataGridViewPriorities.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewPriorities.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridViewPriorities.Location = new System.Drawing.Point(4, 5);
            this.dataGridViewPriorities.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.dataGridViewPriorities.MultiSelect = false;
            this.dataGridViewPriorities.Name = "dataGridViewPriorities";
            this.dataGridViewPriorities.RowHeadersVisible = false;
            this.dataGridViewPriorities.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewPriorities.Size = new System.Drawing.Size(373, 477);
            this.dataGridViewPriorities.TabIndex = 1;
            this.dataGridViewPriorities.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewPriorities_CellClick);
            this.dataGridViewPriorities.SelectionChanged += new System.EventHandler(this.dataGridViewPriorities_SelectionChanged);
            // 
            // labelNotificationGeneral
            // 
            this.labelNotificationGeneral.AutoSize = true;
            this.labelNotificationGeneral.BackColor = System.Drawing.Color.Yellow;
            this.labelNotificationGeneral.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labelNotificationGeneral.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelNotificationGeneral.Location = new System.Drawing.Point(159, 0);
            this.labelNotificationGeneral.Name = "labelNotificationGeneral";
            this.labelNotificationGeneral.Size = new System.Drawing.Size(2, 35);
            this.labelNotificationGeneral.TabIndex = 4;
            // 
            // flowLayoutPanelNotification
            // 
            this.flowLayoutPanelNotification.Controls.Add(this.labelNotificationPriorities);
            this.flowLayoutPanelNotification.Dock = System.Windows.Forms.DockStyle.Left;
            this.flowLayoutPanelNotification.Location = new System.Drawing.Point(53, 48);
            this.flowLayoutPanelNotification.Name = "flowLayoutPanelNotification";
            this.flowLayoutPanelNotification.Size = new System.Drawing.Size(400, 0);
            this.flowLayoutPanelNotification.TabIndex = 5;
            // 
            // labelNotificationPriorities
            // 
            this.labelNotificationPriorities.AutoSize = true;
            this.labelNotificationPriorities.BackColor = System.Drawing.Color.Yellow;
            this.labelNotificationPriorities.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labelNotificationPriorities.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelNotificationPriorities.Location = new System.Drawing.Point(3, 0);
            this.labelNotificationPriorities.Name = "labelNotificationPriorities";
            this.labelNotificationPriorities.Size = new System.Drawing.Size(2, 22);
            this.labelNotificationPriorities.TabIndex = 0;
            // 
            // NewRequest
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1184, 562);
            this.Controls.Add(this.tableLayoutPanelNewRequest);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "NewRequest";
            this.Text = "Новая заявка";
            this.tableLayoutPanelNewRequest.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewIngredients)).EndInit();
            this.flowLayoutPanelButtons.ResumeLayout(false);
            this.tableLayoutPanelInfo.ResumeLayout(false);
            this.tableLayoutPanelInfo.PerformLayout();
            this.groupBoxPlace.ResumeLayout(false);
            this.groupBoxPlace.PerformLayout();
            this.flowLayoutPanelCountWeight.ResumeLayout(false);
            this.flowLayoutPanelCountWeight.PerformLayout();
            this.flowLayoutPanelButtonsPriority.ResumeLayout(false);
            this.flowLayoutPanelSummTag.ResumeLayout(false);
            this.flowLayoutPanelSummTag.PerformLayout();
            this.panelPriorities.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.panelPriorButtons.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewPriorities)).EndInit();
            this.flowLayoutPanelNotification.ResumeLayout(false);
            this.flowLayoutPanelNotification.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelNewRequest;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanelButtons;
        private System.Windows.Forms.Button buttonAdd;
        private System.Windows.Forms.Button buttonCancel;
        private System.Windows.Forms.DataGridView dataGridViewIngredients;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelInfo;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBoxRecipeName;
        private System.Windows.Forms.TextBox textBoxWeight;
        private System.Windows.Forms.TextBox textBoxWeightKK;
        private System.Windows.Forms.TextBox textBoxQuality;
        private System.Windows.Forms.TextBox textBoxComment;
        private System.Windows.Forms.Label labelSumm;
        private System.Windows.Forms.CheckBox checkBoxLine;
        private System.Windows.Forms.GroupBox groupBoxPlace;
        private System.Windows.Forms.RadioButton radioButtonOd2;
        private System.Windows.Forms.RadioButton radioButtonPd2;
        private System.Windows.Forms.RadioButton radioButtonOd1;
        private System.Windows.Forms.RadioButton radioButtonPd1;
        private System.Windows.Forms.Button buttonSetPriorities;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanelButtonsPriority;
        private System.Windows.Forms.Button buttonCancelPriority;
        private System.Windows.Forms.Button buttonAddPriority;
        private System.Windows.Forms.Button buttonBackToIngr;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanelSummTag;
        private System.Windows.Forms.Panel panelPriorities;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Panel panelPriorButtons;
        private System.Windows.Forms.Button buttonDown;
        private System.Windows.Forms.Button buttonUp;
        private System.Windows.Forms.DataGridView dataGridViewPriorities;
        private System.Windows.Forms.Button buttonAddIngredient;
        private System.Windows.Forms.CheckBox checkBoxCountWeight;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanelCountWeight;
        private System.Windows.Forms.TextBox textBoxWeightToCount;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBoxProcentsToCount;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanelNotification;
        private System.Windows.Forms.Label labelNotificationPriorities;
        private System.Windows.Forms.Label labelNotificationGeneral;
    }
}