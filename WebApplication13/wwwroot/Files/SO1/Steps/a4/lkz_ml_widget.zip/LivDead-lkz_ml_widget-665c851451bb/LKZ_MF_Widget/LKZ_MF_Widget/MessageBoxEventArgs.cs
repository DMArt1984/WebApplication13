﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace LKZ_MF_Widget
{
    //Аргументы для передачи MessageBox в главное окно
    class MessageBoxEventArgs : EventArgs
    {
        private readonly string _messageText;
        private readonly string _headerText;
        private readonly MessageBoxIcon _icon;
        public delegate void MessageBoxEventHandler(object sender, MessageBoxEventArgs args);

        public MessageBoxEventArgs(string message, string header = "Ошибка", MessageBoxIcon icon = MessageBoxIcon.Error )
        {
            _messageText = message;
            _headerText = header;
            _icon = icon;
        }

        public string MessageText
        {
            get { return _messageText; }
        }

        public string HeaderText
        {
            get { return _headerText; }
        }

        public MessageBoxIcon Icon
        {
            get { return _icon; }
        }
    }
}
