﻿using LKZ_MF_Widget.Settings;

namespace LKZ_MF_Widget.DBClasses
{
    //Класс для установки настроек подключения по умолчанию
    internal static class DefaultSetter
    {
        //Запись настроек подключения по умолчанию
        public static void SetDefaultSettings(string name, string pass, string dbName, string dbLocation)
        {
            widget.Default["dbNameDefault"] = dbName;
            widget.Default["dbLocationDefault"] = dbLocation;
            widget.Default["dbUserNameDefault"] = name;
            using (var secureString = pass.ToSecureString())
            {
                widget.Default["dbUserPasswordDefault"] = secureString.EncryptString();
            }
            widget.Default.Save();
        }
    }
}