﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.Windows.Forms;
using Excel = Microsoft.Office.Interop.Excel;

namespace LKZ_MF_Widget
{
    //Класс для сохранения данных в файл excel
    internal class ExcelSaver
    {
        private string _folderPath = "";
        private List<List<string>> _input;

        public ExcelSaver(List<List<string>> input)
        {
            this._input = input;
            //Спрашиваем куда сохранять
            var dlg = new SaveFileDialog();
            dlg.FileName = DateTime.Now.ToString("dd_MM_yyyy hh-mm");
            dlg.Filter = "Книга xlsx | *.xlsx";
            if (dlg.ShowDialog() != DialogResult.OK) return;
            _folderPath = dlg.FileName;
        }

        public void FileCreate()
        {
            MethodInvoker inv = new MethodInvoker(Invoker);
            inv.BeginInvoke(null, null);
        }

        private void Invoker()
        {
            Excel.Application xlApp = new Excel.Application();
            xlApp.DisplayAlerts = false;
            if (xlApp == null)
            {
                MessageBox.Show("Excel is not properly installed!!");
                return;
            }
            object misValue = System.Reflection.Missing.Value;
            Excel.Workbook xlWorkBook = xlApp.Workbooks.Add(misValue);
            Excel.Worksheet xlWorkSheet = (Excel.Worksheet) xlWorkBook.Worksheets.Item[1];
            xlWorkSheet.EnableFormatConditionsCalculation = true;
            xlWorkSheet.Name = "ЦПС";
            MakeFileContentsMatrix(xlWorkSheet);
            if (_folderPath.Equals(string.Empty))
                return;
            try
            {
                xlWorkBook.SaveAs(_folderPath, misValue, misValue, misValue, misValue, misValue,
                    Excel.XlSaveAsAccessMode.xlNoChange, Excel.XlSaveConflictResolution.xlLocalSessionChanges, misValue,
                    misValue);
            }
            catch
            {
                MessageBox.Show("Ошибка при сохранении файла", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                xlWorkBook.Close(true, misValue, misValue);
                xlApp.Quit();
                ReleaseObject(xlWorkSheet);
                ReleaseObject(xlWorkBook);
                ReleaseObject(xlApp);
            }
            try
            {
                xlWorkBook.Close(true, misValue, misValue);
                xlApp.Quit();
                ReleaseObject(xlWorkSheet);
                ReleaseObject(xlWorkBook);
                ReleaseObject(xlApp);
            }
            catch
            {
                ;
            }
        }

        //Заполняем таблицу содержимым матрицей
        private void MakeFileContentsMatrix(Excel.Worksheet sheet)
        {
            if (_input.Count == 0)
                return;
            Stopwatch sw = Stopwatch.StartNew();
            int sizeX = _input.Count;
            int sizeY = _input[0].Count;
            object[,] matrix = new object[sizeX, sizeY];
            string separator = CultureInfo.CurrentCulture.NumberFormat.NumberDecimalSeparator;
            for (int i = 0; i < _input.Count; i++)
            {
                for (int j = 0; j < _input[i].Count; j++)
                {
                    //Приводим что можно к числовому виду
                    if ((_input[i][j].Contains(",") || _input[i][j].Contains(",")) && i != 0)
                    {
                        _input[i][j] = _input[i][j].Replace(",", separator);
                        _input[i][j] = _input[i][j].Replace(".", separator);
                    }
                    double val;
                    if (double.TryParse(_input[i][j], NumberStyles.Integer,
                        new CultureInfo(CultureInfo.CurrentUICulture.LCID), out val))
                        matrix[i, j] = val;
                    else
                    {
                        matrix[i, j] = _input[i][j];
                    }
                }
            }
            // Get dimensions of the 2-d array
            int rowCount = matrix.GetLength(0);
            int columnCount = matrix.GetLength(1);
            // Get an Excel Range of the same dimensions
            Excel.Range range = (Excel.Range) sheet.Cells[1, 1];
            range = range.Resize[rowCount, columnCount];
            // Assign the 2-d array to the Excel Range

            range.set_Value(Excel.XlRangeValueDataType.xlRangeValueDefault, matrix);
            //  range.NumberFormat = "0.0";
            sheet.Columns.AutoFit();
            //Заголовок жирным шрифтом
            sheet.Cells[1, 1].EntireRow.Font.Bold = true;
            //Выравниваем наименования заявок
            sheet.Cells[1, 1].EntireColumn.Style.HorizontalAlignment = Excel.XlHAlign.xlHAlignRight;
            //Выравниваем шапку
            sheet.Cells[1, 1].EntireRow.Style.HorizontalAlignment = Excel.XlHAlign.xlHAlignLeft;
            //  sheet.Columns.
            sw.Stop();
            Console.WriteLine("Time taken to write: {0} s", sw.Elapsed.TotalSeconds);
        }

        private void ReleaseObject(object obj)
        {
            try
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
                obj = null;
            }
            catch (Exception ex)
            {
                obj = null;
                MessageBox.Show("Exception Occured while releasing object " + ex.ToString());
            }
            finally
            {
                GC.Collect();
            }
        }
    }
}
