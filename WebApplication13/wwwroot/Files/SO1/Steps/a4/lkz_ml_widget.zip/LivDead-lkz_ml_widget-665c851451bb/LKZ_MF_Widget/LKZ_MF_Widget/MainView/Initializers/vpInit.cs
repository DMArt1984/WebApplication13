﻿using System.Windows.Forms;

namespace LKZ_MF_Widget.MainView
{
    public partial class MainView
    {
        public void VpInit()
        {
            SetupDatePickersFormats();
            radioButtonVPWeek.Checked = true;
            checkBoxVP150Details.Checked = false;
            checkBoxVPDetailedShow.Checked = false;
            checkBoxVPShowEnabled.Checked = true;
            radioButtonReportVp150.Checked = true;
            InitVp150();
            InitVp50(dataGridViewVP501);
            InitVp50(dataGridViewVP502);
            InitVp50(dataGridViewVP503, true);
            UpdateVpView();
        }
        //Инициализация форматов datetimepicker для выбора отчетов порционных весов
        private void SetupDatePickersFormats()
        {
            dateTimePickerReportDateFrom.Format = DateTimePickerFormat.Custom;
            dateTimePickerReportDateTo.Format = DateTimePickerFormat.Custom;

            dateTimePickerReportDateFrom.CustomFormat = "dd-MM-yyyy";
            dateTimePickerReportDateTo.CustomFormat = "dd-MM-yyyy";

            dateTimePickerReportTimeFrom.Format = DateTimePickerFormat.Custom;
            dateTimePickerReportTimeTo.Format = DateTimePickerFormat.Custom;

            dateTimePickerReportTimeFrom.CustomFormat = "HH:mm";
            dateTimePickerReportTimeTo.CustomFormat = "HH:mm";
        }

        private void InitVp150()
        {
            var dgv = dataGridViewVP150;
            var count = 6;
            ClearDgv(dgv);
            for (var i = 0; i < count; i++)
            {
                var column = new DataGridViewTextBoxColumn();
                dgv.Columns.Add(column);
            }
            dgv.Columns[1].DataPropertyName = "name";
            dgv.Columns[1].Name = "name";
            dgv.Columns[1].HeaderText = "Сырье";

            dgv.Columns[4].DataPropertyName = "tasks";
            dgv.Columns[4].Name = "tasks";
            dgv.Columns[4].HeaderText = "Задание";
            // dgv.Columns[1].Visible = false;
            dgv.Columns[4].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;

            dgv.Columns[5].DataPropertyName = "cycles";
            dgv.Columns[5].Name = "cycles";
            dgv.Columns[5].HeaderText = "Циклы";
            dgv.Columns[5].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;

            dgv.Columns[2].DataPropertyName = "direction";
            dgv.Columns[2].Name = "direction";
            dgv.Columns[2].HeaderText = "Перекачка";

            dgv.Columns[3].DataPropertyName = "production";
            dgv.Columns[3].Name = "production";
            dgv.Columns[3].HeaderText = "Выработка, кг.";
            dgv.Columns[3].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgv.Columns[3].DefaultCellStyle.Format = "N3";

            dgv.Columns[0].DataPropertyName = "timeCreate";
            dgv.Columns[0].Name = "timeCreate";
            dgv.Columns[0].HeaderText = "Дата добавления";
            dgv.Columns[0].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
        }

        private void InitVp50(DataGridView input, bool isCps = false)
        {
            var dgv = input;
            ClearDgv(dgv);
          /*  var count = 5;
            if (isCps)
                count = 6;*/
            var count = 6;
            for (var i = 0; i < count; i++)
            {
                var column = new DataGridViewTextBoxColumn();
                dgv.Columns.Add(column);
            }
        
            dgv.Columns[1].DataPropertyName = "name";
            dgv.Columns[1].Name = "name";
            dgv.Columns[1].HeaderText = "Рецепт";

            dgv.Columns[2].DataPropertyName = "task";
            dgv.Columns[2].Name = "task";
            dgv.Columns[2].HeaderText = "Задание";
            dgv.Columns[2].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgv.Columns[2].DefaultCellStyle.Format = "N3";
          //  dgv.Columns[2].Width = 60;
           
            dgv.Columns[3].DataPropertyName = "cycles";
            dgv.Columns[3].Name = "cycles";
            dgv.Columns[3].HeaderText = "Циклы";
            dgv.Columns[3].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgv.Columns[3].DefaultCellStyle.Format = "N0";
         //   dgv.Columns[3].Width = 60;

          /*  if (!isCps)
            {
                dgv.Columns[3].DataPropertyName = "production";
                dgv.Columns[3].Name = "production";
                dgv.Columns[3].HeaderText = "Выработка, кг.";
                dgv.Columns[3].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgv.Columns[3].DefaultCellStyle.Format = "N3";

                dgv.Columns[4].DataPropertyName = "timeCreated";
                dgv.Columns[4].Name = "timeCreated";
                dgv.Columns[4].HeaderText = "Дата добавления";
                dgv.Columns[4].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            }
            else
            {*/
                dgv.Columns[4].DataPropertyName = "bunker";
                dgv.Columns[4].Name = "bunker";
                dgv.Columns[4].HeaderText = "Бункер";
             //   dgv.Columns[4].Width = 60;

                dgv.Columns[5].DataPropertyName = "production";
                dgv.Columns[5].Name = "production";
              //  dgv.Columns[5].Width = 120;
                dgv.Columns[5].HeaderText = "Выработка, кг.";
                dgv.Columns[5].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgv.Columns[5].DefaultCellStyle.Format = "N3";

                dgv.Columns[0].DataPropertyName = "timeCreated";
                dgv.Columns[0].Name = "timeCreated";
                dgv.Columns[0].HeaderText = "Дата добавления";
            //    dgv.Columns[0].Width = 150;
                dgv.Columns[0].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            //}
            
        }
    }
}