﻿using System.Collections.Generic;
using System.Windows.Forms;

namespace LKZ_MF_Widget.MainView
{
    public partial class MainView
    {
        private void ReportInit()
        {
            InitDgvReport(dataGridViewReport);
            dataGridViewReport.CellFormatting += dataGridViewReport_CellFormatting;
            radioButtonReportSelectorAll.Checked = true;
            radioButtonExcelAll.Checked = true;
            checkBoxExcelGeneral.Checked = true;
        }

        private void InitDgvReport(DataGridView dgv)
        {
            ClearDgv(dgv);
            var colNames = new List<KeyValuePair<string, string>>
            {   
                new KeyValuePair<string, string>("№","id"),
                new KeyValuePair<string, string>("Название","name"),
                new KeyValuePair<string, string>("Вес, кг.","weight"),
                new KeyValuePair<string, string>(@"Задание на к\к, кг.","weightKK"),
                new KeyValuePair<string, string>("Фактический вес, кг.","weightFact"),
                new KeyValuePair<string, string>("Создание","timeCreate"),
                new KeyValuePair<string, string>("Запуск в работу","timeInProgress"),
                new KeyValuePair<string, string>("Завершен","timeFinished"),
                new KeyValuePair<string, string>("isInProgress","isInProgress"),
                new KeyValuePair<string, string>("isFinished","isFinished"),
                new KeyValuePair<string, string>("isFinishedErr","isFinishedErr")
            };
            for (int i = 0; i < colNames.Count; i++)
            {
                var column = new DataGridViewTextBoxColumn();
                dgv.Columns.Add(column);
                dgv.Columns[i].DataPropertyName = colNames[i].Value;
                dgv.Columns[i].Name = colNames[i].Value;
                dgv.Columns[i].HeaderText = colNames[i].Key;
                if (i != 0)
                {
                    dgv.Columns[i].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                }
            }
            dgv.Columns[0].Width = 60;

            dgv.Columns[8].Visible = false;
            dgv.Columns[9].Visible = false;
            dgv.Columns[10].Visible = false;
        }
    }
}