﻿namespace LKZ_MF_Widget.MainView
{
    partial class MainView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.tabPagePortion = new System.Windows.Forms.TabPage();
            this.tableLayoutPanelVPMain = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanelWeights = new System.Windows.Forms.TableLayoutPanel();
            this.groupBoxVP150 = new System.Windows.Forms.GroupBox();
            this.dataGridViewVP150 = new System.Windows.Forms.DataGridView();
            this.groupBoxVP502 = new System.Windows.Forms.GroupBox();
            this.dataGridViewVP502 = new System.Windows.Forms.DataGridView();
            this.groupBoxVP503 = new System.Windows.Forms.GroupBox();
            this.dataGridViewVP503 = new System.Windows.Forms.DataGridView();
            this.groupBoxVP501 = new System.Windows.Forms.GroupBox();
            this.dataGridViewVP501 = new System.Windows.Forms.DataGridView();
            this.label2 = new System.Windows.Forms.Label();
            this.panelVpControls = new System.Windows.Forms.Panel();
            this.checkBoxVPDetailedShow = new System.Windows.Forms.CheckBox();
            this.checkBoxVPShowEnabled = new System.Windows.Forms.CheckBox();
            this.groupBoxVPTimeSelect = new System.Windows.Forms.GroupBox();
            this.flowLayoutPanelSelectByTime = new System.Windows.Forms.FlowLayoutPanel();
            this.label3 = new System.Windows.Forms.Label();
            this.dateTimePickerReportDateFrom = new System.Windows.Forms.DateTimePicker();
            this.dateTimePickerReportTimeFrom = new System.Windows.Forms.DateTimePicker();
            this.label4 = new System.Windows.Forms.Label();
            this.dateTimePickerReportDateTo = new System.Windows.Forms.DateTimePicker();
            this.dateTimePickerReportTimeTo = new System.Windows.Forms.DateTimePicker();
            this.buttonReportSelectByTime = new System.Windows.Forms.Button();
            this.groupBoxVpReport = new System.Windows.Forms.GroupBox();
            this.flowLayoutPanel4 = new System.Windows.Forms.FlowLayoutPanel();
            this.radioButtonReportVp150 = new System.Windows.Forms.RadioButton();
            this.radioButtonReportVp501 = new System.Windows.Forms.RadioButton();
            this.radioButtonReportVp502 = new System.Windows.Forms.RadioButton();
            this.radioButtonReportVp503 = new System.Windows.Forms.RadioButton();
            this.buttonReportVpPrint = new System.Windows.Forms.Button();
            this.buttonReportVpSave = new System.Windows.Forms.Button();
            this.groupBoxVPPeriod = new System.Windows.Forms.GroupBox();
            this.flowLayoutPanel2 = new System.Windows.Forms.FlowLayoutPanel();
            this.radioButtonVPAllTime = new System.Windows.Forms.RadioButton();
            this.radioButtonVPYear = new System.Windows.Forms.RadioButton();
            this.radioButtonVPMonth = new System.Windows.Forms.RadioButton();
            this.radioButtonVPWeek = new System.Windows.Forms.RadioButton();
            this.checkBoxVP150Details = new System.Windows.Forms.CheckBox();
            this.tabPageBunkersCard = new System.Windows.Forms.TabPage();
            this.tableLayoutPanelBunkersCard = new System.Windows.Forms.TableLayoutPanel();
            this.groupBoxBunkerComment = new System.Windows.Forms.GroupBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.buttonBunkChangeCommOk = new System.Windows.Forms.Button();
            this.buttonBunkerCancel = new System.Windows.Forms.Button();
            this.textBoxBunkerComment = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.labelBunkerNumber = new System.Windows.Forms.Label();
            this.flowLayoutPanelBunkerChange = new System.Windows.Forms.FlowLayoutPanel();
            this.buttonBunkerChangeComment = new System.Windows.Forms.Button();
            this.labelBunkersCard = new System.Windows.Forms.Label();
            this.groupBoxBunkersLine2 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanelBunkersLine2 = new System.Windows.Forms.TableLayoutPanel();
            this.labelW5 = new System.Windows.Forms.Label();
            this.labelW4 = new System.Windows.Forms.Label();
            this.dataGridViewBunkersW5 = new System.Windows.Forms.DataGridView();
            this.dataGridViewBunkersW4 = new System.Windows.Forms.DataGridView();
            this.groupBoxBunkersLine1 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanelLine1 = new System.Windows.Forms.TableLayoutPanel();
            this.dataGridViewBunkersW6 = new System.Windows.Forms.DataGridView();
            this.labelW6 = new System.Windows.Forms.Label();
            this.labelW2 = new System.Windows.Forms.Label();
            this.dataGridViewBunkersW2 = new System.Windows.Forms.DataGridView();
            this.tabPageIngredients = new System.Windows.Forms.TabPage();
            this.tableLayoutPanelIngredients = new System.Windows.Forms.TableLayoutPanel();
            this.labelIngredients = new System.Windows.Forms.Label();
            this.groupBoxIngredient = new System.Windows.Forms.GroupBox();
            this.panelIngredientAdd = new System.Windows.Forms.Panel();
            this.buttonIngredientOk = new System.Windows.Forms.Button();
            this.buttonIngredientCancel = new System.Windows.Forms.Button();
            this.textBoxIngredientComment = new System.Windows.Forms.TextBox();
            this.textBoxIngredientName = new System.Windows.Forms.TextBox();
            this.labelIngredientComment = new System.Windows.Forms.Label();
            this.labelIngredientName = new System.Windows.Forms.Label();
            this.flowLayoutPanelIngredientsButtons = new System.Windows.Forms.FlowLayoutPanel();
            this.buttonAddIngredient = new System.Windows.Forms.Button();
            this.buttonUpdateIngredient = new System.Windows.Forms.Button();
            this.buttonDeleteIngredient = new System.Windows.Forms.Button();
            this.dataGridViewIngredients = new System.Windows.Forms.DataGridView();
            this.tabPageRecipe = new System.Windows.Forms.TabPage();
            this.tableLayoutPanelVerticalSplit = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanelRecipes = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanelLeftData = new System.Windows.Forms.TableLayoutPanel();
            this.labelRecipe = new System.Windows.Forms.Label();
            this.dataGridViewCurrentRecipes = new System.Windows.Forms.DataGridView();
            this.groupBoxCurrentPeriod = new System.Windows.Forms.GroupBox();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.radioButtonCurrentAllTime = new System.Windows.Forms.RadioButton();
            this.radioButtonCurrentYear = new System.Windows.Forms.RadioButton();
            this.radioButtonCurrentMonth = new System.Windows.Forms.RadioButton();
            this.radioButtonCurrentWeek = new System.Windows.Forms.RadioButton();
            this.radioButtonCurrentById = new System.Windows.Forms.RadioButton();
            this.textBoxCurrentId = new System.Windows.Forms.TextBox();
            this.tableLayoutPanelRightData = new System.Windows.Forms.TableLayoutPanel();
            this.labelOneRecipe = new System.Windows.Forms.Label();
            this.dataGridViewRecipe = new System.Windows.Forms.DataGridView();
            this.panel1 = new System.Windows.Forms.Panel();
            this.flowLayoutPanelButtons = new System.Windows.Forms.FlowLayoutPanel();
            this.groupBoxAddButtons = new System.Windows.Forms.GroupBox();
            this.buttonAddImport = new System.Windows.Forms.Button();
            this.buttonAddByTemplate = new System.Windows.Forms.Button();
            this.buttonAdd = new System.Windows.Forms.Button();
            this.buttonStartRecipe = new System.Windows.Forms.Button();
            this.buttonRecipeCloseOper = new System.Windows.Forms.Button();
            this.buttonDeleteRecipe = new System.Windows.Forms.Button();
            this.groupBoxRecipeControl = new System.Windows.Forms.GroupBox();
            this.buttonSwapBunkers = new System.Windows.Forms.Button();
            this.buttonSkipBunker = new System.Windows.Forms.Button();
            this.buttonGoToWork = new System.Windows.Forms.Button();
            this.buttonCloseCurrent = new System.Windows.Forms.Button();
            this.groupBoxConsumption = new System.Windows.Forms.GroupBox();
            this.buttonConsumptionFile = new System.Windows.Forms.Button();
            this.buttonConsumptionPrint = new System.Windows.Forms.Button();
            this.buttonPrintRepMainView = new System.Windows.Forms.Button();
            this.tabControlIngredients = new System.Windows.Forms.TabControl();
            this.tabPageReport = new System.Windows.Forms.TabPage();
            this.tableLayoutPanelReport = new System.Windows.Forms.TableLayoutPanel();
            this.labelReport = new System.Windows.Forms.Label();
            this.panelReportControls = new System.Windows.Forms.Panel();
            this.groupBoxAccounting = new System.Windows.Forms.GroupBox();
            this.buttonPrintAccounting = new System.Windows.Forms.Button();
            this.buttonCreateAccountingReport = new System.Windows.Forms.Button();
            this.labelAccounting = new System.Windows.Forms.Label();
            this.textBoxAccountingId = new System.Windows.Forms.TextBox();
            this.checkBoxByDate = new System.Windows.Forms.CheckBox();
            this.checkBoxByNumber = new System.Windows.Forms.CheckBox();
            this.textBoxToId = new System.Windows.Forms.TextBox();
            this.labelSplit = new System.Windows.Forms.Label();
            this.groupBoxExcelExport = new System.Windows.Forms.GroupBox();
            this.buttonExportToExcel = new System.Windows.Forms.Button();
            this.checkBoxExcelByBatches = new System.Windows.Forms.CheckBox();
            this.checkBoxExcelByRecipes = new System.Windows.Forms.CheckBox();
            this.checkBoxExcelGeneral = new System.Windows.Forms.CheckBox();
            this.radioButtonExcelAll = new System.Windows.Forms.RadioButton();
            this.radioButtonExcelSelected = new System.Windows.Forms.RadioButton();
            this.textBoxFromId = new System.Windows.Forms.TextBox();
            this.dateTimePickerFrom = new System.Windows.Forms.DateTimePicker();
            this.label10 = new System.Windows.Forms.Label();
            this.dateTimePickerTo = new System.Windows.Forms.DateTimePicker();
            this.groupBoxReportStatus = new System.Windows.Forms.GroupBox();
            this.checkBoxReportInProgress = new System.Windows.Forms.CheckBox();
            this.checkBoxReportAll = new System.Windows.Forms.CheckBox();
            this.checkBoxReportError = new System.Windows.Forms.CheckBox();
            this.checkBoxReportNotFinished = new System.Windows.Forms.CheckBox();
            this.checkBoxReportFinished = new System.Windows.Forms.CheckBox();
            this.buttonRefreshReport = new System.Windows.Forms.Button();
            this.dataGridViewReport = new System.Windows.Forms.DataGridView();
            this.flowLayoutPanel3 = new System.Windows.Forms.FlowLayoutPanel();
            this.buttonSaveTo = new System.Windows.Forms.Button();
            this.buttonReportPrint = new System.Windows.Forms.Button();
            this.checkBoxDetailedReport = new System.Windows.Forms.CheckBox();
            this.radioButtonReportSelectorAll = new System.Windows.Forms.RadioButton();
            this.radioButtonReportSelectorOnlySelected = new System.Windows.Forms.RadioButton();
            this.bindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.checkBoxTechnological = new System.Windows.Forms.CheckBox();
            this.tabPagePortion.SuspendLayout();
            this.tableLayoutPanelVPMain.SuspendLayout();
            this.tableLayoutPanelWeights.SuspendLayout();
            this.groupBoxVP150.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewVP150)).BeginInit();
            this.groupBoxVP502.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewVP502)).BeginInit();
            this.groupBoxVP503.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewVP503)).BeginInit();
            this.groupBoxVP501.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewVP501)).BeginInit();
            this.panelVpControls.SuspendLayout();
            this.groupBoxVPTimeSelect.SuspendLayout();
            this.flowLayoutPanelSelectByTime.SuspendLayout();
            this.groupBoxVpReport.SuspendLayout();
            this.flowLayoutPanel4.SuspendLayout();
            this.groupBoxVPPeriod.SuspendLayout();
            this.flowLayoutPanel2.SuspendLayout();
            this.tabPageBunkersCard.SuspendLayout();
            this.tableLayoutPanelBunkersCard.SuspendLayout();
            this.groupBoxBunkerComment.SuspendLayout();
            this.panel2.SuspendLayout();
            this.flowLayoutPanelBunkerChange.SuspendLayout();
            this.groupBoxBunkersLine2.SuspendLayout();
            this.tableLayoutPanelBunkersLine2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewBunkersW5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewBunkersW4)).BeginInit();
            this.groupBoxBunkersLine1.SuspendLayout();
            this.tableLayoutPanelLine1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewBunkersW6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewBunkersW2)).BeginInit();
            this.tabPageIngredients.SuspendLayout();
            this.tableLayoutPanelIngredients.SuspendLayout();
            this.groupBoxIngredient.SuspendLayout();
            this.panelIngredientAdd.SuspendLayout();
            this.flowLayoutPanelIngredientsButtons.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewIngredients)).BeginInit();
            this.tabPageRecipe.SuspendLayout();
            this.tableLayoutPanelVerticalSplit.SuspendLayout();
            this.tableLayoutPanelRecipes.SuspendLayout();
            this.tableLayoutPanelLeftData.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewCurrentRecipes)).BeginInit();
            this.groupBoxCurrentPeriod.SuspendLayout();
            this.flowLayoutPanel1.SuspendLayout();
            this.tableLayoutPanelRightData.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewRecipe)).BeginInit();
            this.panel1.SuspendLayout();
            this.flowLayoutPanelButtons.SuspendLayout();
            this.groupBoxAddButtons.SuspendLayout();
            this.groupBoxRecipeControl.SuspendLayout();
            this.groupBoxConsumption.SuspendLayout();
            this.tabControlIngredients.SuspendLayout();
            this.tabPageReport.SuspendLayout();
            this.tableLayoutPanelReport.SuspendLayout();
            this.panelReportControls.SuspendLayout();
            this.groupBoxAccounting.SuspendLayout();
            this.groupBoxExcelExport.SuspendLayout();
            this.groupBoxReportStatus.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewReport)).BeginInit();
            this.flowLayoutPanel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // tabPagePortion
            // 
            this.tabPagePortion.Controls.Add(this.tableLayoutPanelVPMain);
            this.tabPagePortion.Location = new System.Drawing.Point(4, 29);
            this.tabPagePortion.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tabPagePortion.Name = "tabPagePortion";
            this.tabPagePortion.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tabPagePortion.Size = new System.Drawing.Size(1792, 675);
            this.tabPagePortion.TabIndex = 4;
            this.tabPagePortion.Text = "Порционные весы";
            this.tabPagePortion.UseVisualStyleBackColor = true;
            this.tabPagePortion.Enter += new System.EventHandler(this.tabPagePortion_Enter);
            // 
            // tableLayoutPanelVPMain
            // 
            this.tableLayoutPanelVPMain.ColumnCount = 1;
            this.tableLayoutPanelVPMain.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanelVPMain.Controls.Add(this.tableLayoutPanelWeights, 0, 2);
            this.tableLayoutPanelVPMain.Controls.Add(this.label2, 0, 0);
            this.tableLayoutPanelVPMain.Controls.Add(this.panelVpControls, 0, 1);
            this.tableLayoutPanelVPMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanelVPMain.Location = new System.Drawing.Point(4, 5);
            this.tableLayoutPanelVPMain.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tableLayoutPanelVPMain.Name = "tableLayoutPanelVPMain";
            this.tableLayoutPanelVPMain.RowCount = 3;
            this.tableLayoutPanelVPMain.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 31F));
            this.tableLayoutPanelVPMain.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 169F));
            this.tableLayoutPanelVPMain.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanelVPMain.Size = new System.Drawing.Size(1784, 665);
            this.tableLayoutPanelVPMain.TabIndex = 1;
            // 
            // tableLayoutPanelWeights
            // 
            this.tableLayoutPanelWeights.ColumnCount = 2;
            this.tableLayoutPanelWeights.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanelWeights.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanelWeights.Controls.Add(this.groupBoxVP150, 1, 0);
            this.tableLayoutPanelWeights.Controls.Add(this.groupBoxVP502, 0, 1);
            this.tableLayoutPanelWeights.Controls.Add(this.groupBoxVP503, 1, 1);
            this.tableLayoutPanelWeights.Controls.Add(this.groupBoxVP501, 0, 0);
            this.tableLayoutPanelWeights.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanelWeights.Location = new System.Drawing.Point(4, 205);
            this.tableLayoutPanelWeights.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tableLayoutPanelWeights.Name = "tableLayoutPanelWeights";
            this.tableLayoutPanelWeights.RowCount = 2;
            this.tableLayoutPanelWeights.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanelWeights.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanelWeights.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanelWeights.Size = new System.Drawing.Size(1776, 455);
            this.tableLayoutPanelWeights.TabIndex = 0;
            // 
            // groupBoxVP150
            // 
            this.groupBoxVP150.Controls.Add(this.dataGridViewVP150);
            this.groupBoxVP150.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBoxVP150.Location = new System.Drawing.Point(892, 5);
            this.groupBoxVP150.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBoxVP150.Name = "groupBoxVP150";
            this.groupBoxVP150.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBoxVP150.Size = new System.Drawing.Size(880, 217);
            this.groupBoxVP150.TabIndex = 7;
            this.groupBoxVP150.TabStop = false;
            this.groupBoxVP150.Text = "Весы ВП150 (Перекачка)";
            // 
            // dataGridViewVP150
            // 
            this.dataGridViewVP150.AllowUserToAddRows = false;
            this.dataGridViewVP150.AllowUserToDeleteRows = false;
            this.dataGridViewVP150.AllowUserToResizeRows = false;
            this.dataGridViewVP150.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewVP150.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCellsExceptHeaders;
            this.dataGridViewVP150.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewVP150.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridViewVP150.Location = new System.Drawing.Point(4, 24);
            this.dataGridViewVP150.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.dataGridViewVP150.Name = "dataGridViewVP150";
            this.dataGridViewVP150.ReadOnly = true;
            this.dataGridViewVP150.RowHeadersVisible = false;
            this.dataGridViewVP150.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewVP150.Size = new System.Drawing.Size(872, 188);
            this.dataGridViewVP150.TabIndex = 0;
            // 
            // groupBoxVP502
            // 
            this.groupBoxVP502.Controls.Add(this.dataGridViewVP502);
            this.groupBoxVP502.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBoxVP502.Location = new System.Drawing.Point(4, 232);
            this.groupBoxVP502.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBoxVP502.Name = "groupBoxVP502";
            this.groupBoxVP502.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBoxVP502.Size = new System.Drawing.Size(880, 218);
            this.groupBoxVP502.TabIndex = 4;
            this.groupBoxVP502.TabStop = false;
            this.groupBoxVP502.Text = "Весы ВП50-2 (Готовая продукция линии 2)";
            // 
            // dataGridViewVP502
            // 
            this.dataGridViewVP502.AllowUserToAddRows = false;
            this.dataGridViewVP502.AllowUserToDeleteRows = false;
            this.dataGridViewVP502.AllowUserToResizeRows = false;
            this.dataGridViewVP502.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewVP502.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCellsExceptHeaders;
            this.dataGridViewVP502.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewVP502.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridViewVP502.Location = new System.Drawing.Point(4, 24);
            this.dataGridViewVP502.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.dataGridViewVP502.Name = "dataGridViewVP502";
            this.dataGridViewVP502.ReadOnly = true;
            this.dataGridViewVP502.RowHeadersVisible = false;
            this.dataGridViewVP502.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewVP502.Size = new System.Drawing.Size(872, 189);
            this.dataGridViewVP502.TabIndex = 0;
            // 
            // groupBoxVP503
            // 
            this.groupBoxVP503.Controls.Add(this.dataGridViewVP503);
            this.groupBoxVP503.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBoxVP503.Location = new System.Drawing.Point(892, 232);
            this.groupBoxVP503.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBoxVP503.Name = "groupBoxVP503";
            this.groupBoxVP503.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBoxVP503.Size = new System.Drawing.Size(880, 218);
            this.groupBoxVP503.TabIndex = 5;
            this.groupBoxVP503.TabStop = false;
            this.groupBoxVP503.Text = "Весы ВП50-3 (Прием с ЦПС)";
            // 
            // dataGridViewVP503
            // 
            this.dataGridViewVP503.AllowUserToAddRows = false;
            this.dataGridViewVP503.AllowUserToDeleteRows = false;
            this.dataGridViewVP503.AllowUserToResizeRows = false;
            this.dataGridViewVP503.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewVP503.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCellsExceptHeaders;
            this.dataGridViewVP503.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewVP503.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridViewVP503.Location = new System.Drawing.Point(4, 24);
            this.dataGridViewVP503.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.dataGridViewVP503.Name = "dataGridViewVP503";
            this.dataGridViewVP503.ReadOnly = true;
            this.dataGridViewVP503.RowHeadersVisible = false;
            this.dataGridViewVP503.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewVP503.Size = new System.Drawing.Size(872, 189);
            this.dataGridViewVP503.TabIndex = 0;
            // 
            // groupBoxVP501
            // 
            this.groupBoxVP501.Controls.Add(this.dataGridViewVP501);
            this.groupBoxVP501.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBoxVP501.Location = new System.Drawing.Point(4, 5);
            this.groupBoxVP501.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBoxVP501.Name = "groupBoxVP501";
            this.groupBoxVP501.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBoxVP501.Size = new System.Drawing.Size(880, 217);
            this.groupBoxVP501.TabIndex = 3;
            this.groupBoxVP501.TabStop = false;
            this.groupBoxVP501.Text = "Весы ВП50-1 (Готовая продукция линии 1)";
            // 
            // dataGridViewVP501
            // 
            this.dataGridViewVP501.AllowUserToAddRows = false;
            this.dataGridViewVP501.AllowUserToDeleteRows = false;
            this.dataGridViewVP501.AllowUserToResizeRows = false;
            this.dataGridViewVP501.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewVP501.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCellsExceptHeaders;
            this.dataGridViewVP501.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewVP501.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridViewVP501.Location = new System.Drawing.Point(4, 24);
            this.dataGridViewVP501.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.dataGridViewVP501.Name = "dataGridViewVP501";
            this.dataGridViewVP501.ReadOnly = true;
            this.dataGridViewVP501.RowHeadersVisible = false;
            this.dataGridViewVP501.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewVP501.Size = new System.Drawing.Size(872, 188);
            this.dataGridViewVP501.TabIndex = 0;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(4, 0);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(206, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Работа порционных весов";
            // 
            // panelVpControls
            // 
            this.panelVpControls.Controls.Add(this.checkBoxVPDetailedShow);
            this.panelVpControls.Controls.Add(this.checkBoxVPShowEnabled);
            this.panelVpControls.Controls.Add(this.groupBoxVPTimeSelect);
            this.panelVpControls.Controls.Add(this.groupBoxVpReport);
            this.panelVpControls.Controls.Add(this.groupBoxVPPeriod);
            this.panelVpControls.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelVpControls.Location = new System.Drawing.Point(4, 36);
            this.panelVpControls.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.panelVpControls.Name = "panelVpControls";
            this.panelVpControls.Size = new System.Drawing.Size(1776, 159);
            this.panelVpControls.TabIndex = 2;
            // 
            // checkBoxVPDetailedShow
            // 
            this.checkBoxVPDetailedShow.AutoSize = true;
            this.checkBoxVPDetailedShow.Location = new System.Drawing.Point(11, 118);
            this.checkBoxVPDetailedShow.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.checkBoxVPDetailedShow.Name = "checkBoxVPDetailedShow";
            this.checkBoxVPDetailedShow.Size = new System.Drawing.Size(15, 14);
            this.checkBoxVPDetailedShow.TabIndex = 8;
            this.checkBoxVPDetailedShow.UseVisualStyleBackColor = true;
            this.checkBoxVPDetailedShow.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // checkBoxVPShowEnabled
            // 
            this.checkBoxVPShowEnabled.AutoSize = true;
            this.checkBoxVPShowEnabled.Location = new System.Drawing.Point(11, 46);
            this.checkBoxVPShowEnabled.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.checkBoxVPShowEnabled.Name = "checkBoxVPShowEnabled";
            this.checkBoxVPShowEnabled.Size = new System.Drawing.Size(15, 14);
            this.checkBoxVPShowEnabled.TabIndex = 7;
            this.checkBoxVPShowEnabled.UseVisualStyleBackColor = true;
            this.checkBoxVPShowEnabled.CheckedChanged += new System.EventHandler(this.checkBoxVPShowEnabled_CheckedChanged);
            // 
            // groupBoxVPTimeSelect
            // 
            this.groupBoxVPTimeSelect.Controls.Add(this.flowLayoutPanelSelectByTime);
            this.groupBoxVPTimeSelect.Location = new System.Drawing.Point(39, 83);
            this.groupBoxVPTimeSelect.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBoxVPTimeSelect.Name = "groupBoxVPTimeSelect";
            this.groupBoxVPTimeSelect.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBoxVPTimeSelect.Size = new System.Drawing.Size(632, 74);
            this.groupBoxVPTimeSelect.TabIndex = 6;
            this.groupBoxVPTimeSelect.TabStop = false;
            this.groupBoxVPTimeSelect.Text = "Выделить по времени";
            // 
            // flowLayoutPanelSelectByTime
            // 
            this.flowLayoutPanelSelectByTime.Controls.Add(this.label3);
            this.flowLayoutPanelSelectByTime.Controls.Add(this.dateTimePickerReportDateFrom);
            this.flowLayoutPanelSelectByTime.Controls.Add(this.dateTimePickerReportTimeFrom);
            this.flowLayoutPanelSelectByTime.Controls.Add(this.label4);
            this.flowLayoutPanelSelectByTime.Controls.Add(this.dateTimePickerReportDateTo);
            this.flowLayoutPanelSelectByTime.Controls.Add(this.dateTimePickerReportTimeTo);
            this.flowLayoutPanelSelectByTime.Controls.Add(this.buttonReportSelectByTime);
            this.flowLayoutPanelSelectByTime.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanelSelectByTime.Location = new System.Drawing.Point(4, 24);
            this.flowLayoutPanelSelectByTime.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.flowLayoutPanelSelectByTime.Name = "flowLayoutPanelSelectByTime";
            this.flowLayoutPanelSelectByTime.Size = new System.Drawing.Size(624, 45);
            this.flowLayoutPanelSelectByTime.TabIndex = 0;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(4, 0);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Padding = new System.Windows.Forms.Padding(0, 8, 0, 0);
            this.label3.Size = new System.Drawing.Size(24, 28);
            this.label3.TabIndex = 0;
            this.label3.Text = "C ";
            // 
            // dateTimePickerReportDateFrom
            // 
            this.dateTimePickerReportDateFrom.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePickerReportDateFrom.Location = new System.Drawing.Point(36, 5);
            this.dateTimePickerReportDateFrom.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.dateTimePickerReportDateFrom.Name = "dateTimePickerReportDateFrom";
            this.dateTimePickerReportDateFrom.Size = new System.Drawing.Size(115, 26);
            this.dateTimePickerReportDateFrom.TabIndex = 3;
            this.dateTimePickerReportDateFrom.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged);
            // 
            // dateTimePickerReportTimeFrom
            // 
            this.dateTimePickerReportTimeFrom.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePickerReportTimeFrom.Location = new System.Drawing.Point(159, 5);
            this.dateTimePickerReportTimeFrom.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.dateTimePickerReportTimeFrom.Name = "dateTimePickerReportTimeFrom";
            this.dateTimePickerReportTimeFrom.ShowUpDown = true;
            this.dateTimePickerReportTimeFrom.Size = new System.Drawing.Size(80, 26);
            this.dateTimePickerReportTimeFrom.TabIndex = 4;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(247, 0);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Padding = new System.Windows.Forms.Padding(0, 8, 0, 0);
            this.label4.Size = new System.Drawing.Size(35, 28);
            this.label4.TabIndex = 1;
            this.label4.Text = " по ";
            // 
            // dateTimePickerReportDateTo
            // 
            this.dateTimePickerReportDateTo.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePickerReportDateTo.Location = new System.Drawing.Point(290, 5);
            this.dateTimePickerReportDateTo.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.dateTimePickerReportDateTo.Name = "dateTimePickerReportDateTo";
            this.dateTimePickerReportDateTo.Size = new System.Drawing.Size(130, 26);
            this.dateTimePickerReportDateTo.TabIndex = 5;
            this.dateTimePickerReportDateTo.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged_1);
            // 
            // dateTimePickerReportTimeTo
            // 
            this.dateTimePickerReportTimeTo.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePickerReportTimeTo.Location = new System.Drawing.Point(428, 5);
            this.dateTimePickerReportTimeTo.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.dateTimePickerReportTimeTo.Name = "dateTimePickerReportTimeTo";
            this.dateTimePickerReportTimeTo.ShowUpDown = true;
            this.dateTimePickerReportTimeTo.Size = new System.Drawing.Size(80, 26);
            this.dateTimePickerReportTimeTo.TabIndex = 6;
            // 
            // buttonReportSelectByTime
            // 
            this.buttonReportSelectByTime.Location = new System.Drawing.Point(516, 1);
            this.buttonReportSelectByTime.Margin = new System.Windows.Forms.Padding(4, 1, 4, 5);
            this.buttonReportSelectByTime.Name = "buttonReportSelectByTime";
            this.buttonReportSelectByTime.Size = new System.Drawing.Size(100, 35);
            this.buttonReportSelectByTime.TabIndex = 2;
            this.buttonReportSelectByTime.Text = "Выделить";
            this.buttonReportSelectByTime.UseVisualStyleBackColor = true;
            this.buttonReportSelectByTime.Click += new System.EventHandler(this.buttonReportSelectByTime_Click);
            // 
            // groupBoxVpReport
            // 
            this.groupBoxVpReport.Controls.Add(this.flowLayoutPanel4);
            this.groupBoxVpReport.Location = new System.Drawing.Point(679, 5);
            this.groupBoxVpReport.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBoxVpReport.Name = "groupBoxVpReport";
            this.groupBoxVpReport.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBoxVpReport.Size = new System.Drawing.Size(591, 74);
            this.groupBoxVpReport.TabIndex = 5;
            this.groupBoxVpReport.TabStop = false;
            this.groupBoxVpReport.Text = "Отчет";
            // 
            // flowLayoutPanel4
            // 
            this.flowLayoutPanel4.Controls.Add(this.radioButtonReportVp150);
            this.flowLayoutPanel4.Controls.Add(this.radioButtonReportVp501);
            this.flowLayoutPanel4.Controls.Add(this.radioButtonReportVp502);
            this.flowLayoutPanel4.Controls.Add(this.radioButtonReportVp503);
            this.flowLayoutPanel4.Controls.Add(this.buttonReportVpPrint);
            this.flowLayoutPanel4.Controls.Add(this.buttonReportVpSave);
            this.flowLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel4.Location = new System.Drawing.Point(4, 24);
            this.flowLayoutPanel4.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.flowLayoutPanel4.Name = "flowLayoutPanel4";
            this.flowLayoutPanel4.Size = new System.Drawing.Size(583, 45);
            this.flowLayoutPanel4.TabIndex = 0;
            // 
            // radioButtonReportVp150
            // 
            this.radioButtonReportVp150.AutoSize = true;
            this.radioButtonReportVp150.Location = new System.Drawing.Point(4, 11);
            this.radioButtonReportVp150.Margin = new System.Windows.Forms.Padding(4, 11, 4, 5);
            this.radioButtonReportVp150.Name = "radioButtonReportVp150";
            this.radioButtonReportVp150.Size = new System.Drawing.Size(77, 24);
            this.radioButtonReportVp150.TabIndex = 26;
            this.radioButtonReportVp150.TabStop = true;
            this.radioButtonReportVp150.Text = "ВП150";
            this.radioButtonReportVp150.UseVisualStyleBackColor = true;
            // 
            // radioButtonReportVp501
            // 
            this.radioButtonReportVp501.AutoSize = true;
            this.radioButtonReportVp501.Location = new System.Drawing.Point(89, 11);
            this.radioButtonReportVp501.Margin = new System.Windows.Forms.Padding(4, 11, 4, 5);
            this.radioButtonReportVp501.Name = "radioButtonReportVp501";
            this.radioButtonReportVp501.Size = new System.Drawing.Size(82, 24);
            this.radioButtonReportVp501.TabIndex = 27;
            this.radioButtonReportVp501.TabStop = true;
            this.radioButtonReportVp501.Text = "ВП50-1";
            this.radioButtonReportVp501.UseVisualStyleBackColor = true;
            // 
            // radioButtonReportVp502
            // 
            this.radioButtonReportVp502.AutoSize = true;
            this.radioButtonReportVp502.Location = new System.Drawing.Point(179, 11);
            this.radioButtonReportVp502.Margin = new System.Windows.Forms.Padding(4, 11, 4, 5);
            this.radioButtonReportVp502.Name = "radioButtonReportVp502";
            this.radioButtonReportVp502.Size = new System.Drawing.Size(82, 24);
            this.radioButtonReportVp502.TabIndex = 28;
            this.radioButtonReportVp502.TabStop = true;
            this.radioButtonReportVp502.Text = "ВП50-2";
            this.radioButtonReportVp502.UseVisualStyleBackColor = true;
            // 
            // radioButtonReportVp503
            // 
            this.radioButtonReportVp503.AutoSize = true;
            this.radioButtonReportVp503.Location = new System.Drawing.Point(269, 11);
            this.radioButtonReportVp503.Margin = new System.Windows.Forms.Padding(4, 11, 4, 5);
            this.radioButtonReportVp503.Name = "radioButtonReportVp503";
            this.radioButtonReportVp503.Size = new System.Drawing.Size(82, 24);
            this.radioButtonReportVp503.TabIndex = 29;
            this.radioButtonReportVp503.TabStop = true;
            this.radioButtonReportVp503.Text = "ВП50-3";
            this.radioButtonReportVp503.UseVisualStyleBackColor = true;
            // 
            // buttonReportVpPrint
            // 
            this.buttonReportVpPrint.Location = new System.Drawing.Point(359, 5);
            this.buttonReportVpPrint.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.buttonReportVpPrint.Name = "buttonReportVpPrint";
            this.buttonReportVpPrint.Size = new System.Drawing.Size(105, 35);
            this.buttonReportVpPrint.TabIndex = 25;
            this.buttonReportVpPrint.Text = "Печать";
            this.buttonReportVpPrint.UseVisualStyleBackColor = true;
            this.buttonReportVpPrint.Click += new System.EventHandler(this.buttonReportVpPrint_Click);
            // 
            // buttonReportVpSave
            // 
            this.buttonReportVpSave.Location = new System.Drawing.Point(472, 5);
            this.buttonReportVpSave.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.buttonReportVpSave.Name = "buttonReportVpSave";
            this.buttonReportVpSave.Size = new System.Drawing.Size(105, 35);
            this.buttonReportVpSave.TabIndex = 24;
            this.buttonReportVpSave.Text = "Сохранить";
            this.buttonReportVpSave.UseVisualStyleBackColor = true;
            this.buttonReportVpSave.Click += new System.EventHandler(this.buttonReportVpSave_Click);
            // 
            // groupBoxVPPeriod
            // 
            this.groupBoxVPPeriod.Controls.Add(this.flowLayoutPanel2);
            this.groupBoxVPPeriod.Location = new System.Drawing.Point(38, 5);
            this.groupBoxVPPeriod.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBoxVPPeriod.Name = "groupBoxVPPeriod";
            this.groupBoxVPPeriod.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBoxVPPeriod.Size = new System.Drawing.Size(633, 74);
            this.groupBoxVPPeriod.TabIndex = 4;
            this.groupBoxVPPeriod.TabStop = false;
            this.groupBoxVPPeriod.Text = "Отображать";
            this.groupBoxVPPeriod.EnabledChanged += new System.EventHandler(this.groupBoxVPPeriod_EnabledChanged);
            // 
            // flowLayoutPanel2
            // 
            this.flowLayoutPanel2.Controls.Add(this.radioButtonVPAllTime);
            this.flowLayoutPanel2.Controls.Add(this.radioButtonVPYear);
            this.flowLayoutPanel2.Controls.Add(this.radioButtonVPMonth);
            this.flowLayoutPanel2.Controls.Add(this.radioButtonVPWeek);
            this.flowLayoutPanel2.Controls.Add(this.checkBoxVP150Details);
            this.flowLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel2.Location = new System.Drawing.Point(4, 24);
            this.flowLayoutPanel2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.flowLayoutPanel2.Name = "flowLayoutPanel2";
            this.flowLayoutPanel2.Size = new System.Drawing.Size(625, 45);
            this.flowLayoutPanel2.TabIndex = 0;
            // 
            // radioButtonVPAllTime
            // 
            this.radioButtonVPAllTime.AutoSize = true;
            this.radioButtonVPAllTime.Location = new System.Drawing.Point(4, 11);
            this.radioButtonVPAllTime.Margin = new System.Windows.Forms.Padding(4, 11, 4, 5);
            this.radioButtonVPAllTime.Name = "radioButtonVPAllTime";
            this.radioButtonVPAllTime.Size = new System.Drawing.Size(128, 24);
            this.radioButtonVPAllTime.TabIndex = 5;
            this.radioButtonVPAllTime.TabStop = true;
            this.radioButtonVPAllTime.Text = "За все время";
            this.radioButtonVPAllTime.UseVisualStyleBackColor = true;
            this.radioButtonVPAllTime.CheckedChanged += new System.EventHandler(this.radioButtonVPAllTime_CheckedChanged);
            // 
            // radioButtonVPYear
            // 
            this.radioButtonVPYear.AutoSize = true;
            this.radioButtonVPYear.Location = new System.Drawing.Point(140, 11);
            this.radioButtonVPYear.Margin = new System.Windows.Forms.Padding(4, 11, 4, 5);
            this.radioButtonVPYear.Name = "radioButtonVPYear";
            this.radioButtonVPYear.Size = new System.Drawing.Size(56, 24);
            this.radioButtonVPYear.TabIndex = 2;
            this.radioButtonVPYear.TabStop = true;
            this.radioButtonVPYear.Text = "Год";
            this.radioButtonVPYear.UseVisualStyleBackColor = true;
            this.radioButtonVPYear.CheckedChanged += new System.EventHandler(this.radioButtonVPYear_CheckedChanged);
            // 
            // radioButtonVPMonth
            // 
            this.radioButtonVPMonth.AutoSize = true;
            this.radioButtonVPMonth.Location = new System.Drawing.Point(204, 11);
            this.radioButtonVPMonth.Margin = new System.Windows.Forms.Padding(4, 11, 4, 5);
            this.radioButtonVPMonth.Name = "radioButtonVPMonth";
            this.radioButtonVPMonth.Size = new System.Drawing.Size(75, 24);
            this.radioButtonVPMonth.TabIndex = 1;
            this.radioButtonVPMonth.TabStop = true;
            this.radioButtonVPMonth.Text = "Месяц";
            this.radioButtonVPMonth.UseVisualStyleBackColor = true;
            this.radioButtonVPMonth.CheckedChanged += new System.EventHandler(this.radioButtonVPMonth_CheckedChanged);
            // 
            // radioButtonVPWeek
            // 
            this.radioButtonVPWeek.AutoSize = true;
            this.radioButtonVPWeek.Location = new System.Drawing.Point(287, 11);
            this.radioButtonVPWeek.Margin = new System.Windows.Forms.Padding(4, 11, 4, 5);
            this.radioButtonVPWeek.Name = "radioButtonVPWeek";
            this.radioButtonVPWeek.Size = new System.Drawing.Size(87, 24);
            this.radioButtonVPWeek.TabIndex = 0;
            this.radioButtonVPWeek.TabStop = true;
            this.radioButtonVPWeek.Text = "Неделя";
            this.radioButtonVPWeek.UseVisualStyleBackColor = true;
            this.radioButtonVPWeek.CheckedChanged += new System.EventHandler(this.radioButtonVPWeek_CheckedChanged);
            // 
            // checkBoxVP150Details
            // 
            this.checkBoxVP150Details.AutoSize = true;
            this.checkBoxVP150Details.Location = new System.Drawing.Point(382, 11);
            this.checkBoxVP150Details.Margin = new System.Windows.Forms.Padding(4, 11, 4, 5);
            this.checkBoxVP150Details.Name = "checkBoxVP150Details";
            this.checkBoxVP150Details.Size = new System.Drawing.Size(159, 24);
            this.checkBoxVP150Details.TabIndex = 6;
            this.checkBoxVP150Details.Text = "Подробно ВП150";
            this.checkBoxVP150Details.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBoxVP150Details.UseVisualStyleBackColor = true;
            this.checkBoxVP150Details.CheckedChanged += new System.EventHandler(this.checkBoxVP150Details_CheckedChanged);
            // 
            // tabPageBunkersCard
            // 
            this.tabPageBunkersCard.Controls.Add(this.tableLayoutPanelBunkersCard);
            this.tabPageBunkersCard.Location = new System.Drawing.Point(4, 29);
            this.tabPageBunkersCard.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tabPageBunkersCard.Name = "tabPageBunkersCard";
            this.tabPageBunkersCard.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tabPageBunkersCard.Size = new System.Drawing.Size(1792, 675);
            this.tabPageBunkersCard.TabIndex = 2;
            this.tabPageBunkersCard.Text = "Карта бункеров";
            this.tabPageBunkersCard.UseVisualStyleBackColor = true;
            this.tabPageBunkersCard.Enter += new System.EventHandler(this.tabPageBunkersCard_Enter);
            // 
            // tableLayoutPanelBunkersCard
            // 
            this.tableLayoutPanelBunkersCard.ColumnCount = 2;
            this.tableLayoutPanelBunkersCard.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanelBunkersCard.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanelBunkersCard.Controls.Add(this.groupBoxBunkerComment, 0, 3);
            this.tableLayoutPanelBunkersCard.Controls.Add(this.flowLayoutPanelBunkerChange, 0, 2);
            this.tableLayoutPanelBunkersCard.Controls.Add(this.labelBunkersCard, 0, 0);
            this.tableLayoutPanelBunkersCard.Controls.Add(this.groupBoxBunkersLine2, 1, 1);
            this.tableLayoutPanelBunkersCard.Controls.Add(this.groupBoxBunkersLine1, 0, 1);
            this.tableLayoutPanelBunkersCard.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanelBunkersCard.Location = new System.Drawing.Point(4, 5);
            this.tableLayoutPanelBunkersCard.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tableLayoutPanelBunkersCard.Name = "tableLayoutPanelBunkersCard";
            this.tableLayoutPanelBunkersCard.RowCount = 4;
            this.tableLayoutPanelBunkersCard.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 31F));
            this.tableLayoutPanelBunkersCard.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanelBunkersCard.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 0F));
            this.tableLayoutPanelBunkersCard.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 0F));
            this.tableLayoutPanelBunkersCard.Size = new System.Drawing.Size(1784, 665);
            this.tableLayoutPanelBunkersCard.TabIndex = 0;
            // 
            // groupBoxBunkerComment
            // 
            this.groupBoxBunkerComment.Controls.Add(this.panel2);
            this.groupBoxBunkerComment.Location = new System.Drawing.Point(4, 670);
            this.groupBoxBunkerComment.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBoxBunkerComment.Name = "groupBoxBunkerComment";
            this.groupBoxBunkerComment.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBoxBunkerComment.Size = new System.Drawing.Size(699, 1);
            this.groupBoxBunkerComment.TabIndex = 3;
            this.groupBoxBunkerComment.TabStop = false;
            this.groupBoxBunkerComment.Text = "Комментарий";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.buttonBunkChangeCommOk);
            this.panel2.Controls.Add(this.buttonBunkerCancel);
            this.panel2.Controls.Add(this.textBoxBunkerComment);
            this.panel2.Controls.Add(this.textBox2);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.labelBunkerNumber);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(4, 24);
            this.panel2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(691, 0);
            this.panel2.TabIndex = 0;
            // 
            // buttonBunkChangeCommOk
            // 
            this.buttonBunkChangeCommOk.Location = new System.Drawing.Point(450, 86);
            this.buttonBunkChangeCommOk.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.buttonBunkChangeCommOk.Name = "buttonBunkChangeCommOk";
            this.buttonBunkChangeCommOk.Size = new System.Drawing.Size(112, 35);
            this.buttonBunkChangeCommOk.TabIndex = 5;
            this.buttonBunkChangeCommOk.Text = "Изменить";
            this.buttonBunkChangeCommOk.UseVisualStyleBackColor = true;
            // 
            // buttonBunkerCancel
            // 
            this.buttonBunkerCancel.Location = new System.Drawing.Point(572, 86);
            this.buttonBunkerCancel.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.buttonBunkerCancel.Name = "buttonBunkerCancel";
            this.buttonBunkerCancel.Size = new System.Drawing.Size(112, 35);
            this.buttonBunkerCancel.TabIndex = 4;
            this.buttonBunkerCancel.Text = "Отмена";
            this.buttonBunkerCancel.UseVisualStyleBackColor = true;
            // 
            // textBoxBunkerComment
            // 
            this.textBoxBunkerComment.Location = new System.Drawing.Point(129, 45);
            this.textBoxBunkerComment.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxBunkerComment.Name = "textBoxBunkerComment";
            this.textBoxBunkerComment.Size = new System.Drawing.Size(554, 26);
            this.textBoxBunkerComment.TabIndex = 3;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(129, 5);
            this.textBox2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBox2.Name = "textBox2";
            this.textBox2.ReadOnly = true;
            this.textBox2.Size = new System.Drawing.Size(85, 26);
            this.textBox2.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(4, 45);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(113, 20);
            this.label1.TabIndex = 1;
            this.label1.Text = "Комментарий";
            // 
            // labelBunkerNumber
            // 
            this.labelBunkerNumber.AutoSize = true;
            this.labelBunkerNumber.Location = new System.Drawing.Point(4, 9);
            this.labelBunkerNumber.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelBunkerNumber.Name = "labelBunkerNumber";
            this.labelBunkerNumber.Size = new System.Drawing.Size(59, 20);
            this.labelBunkerNumber.TabIndex = 0;
            this.labelBunkerNumber.Text = "Номер";
            // 
            // flowLayoutPanelBunkerChange
            // 
            this.flowLayoutPanelBunkerChange.Controls.Add(this.buttonBunkerChangeComment);
            this.flowLayoutPanelBunkerChange.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanelBunkerChange.Location = new System.Drawing.Point(4, 670);
            this.flowLayoutPanelBunkerChange.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.flowLayoutPanelBunkerChange.Name = "flowLayoutPanelBunkerChange";
            this.flowLayoutPanelBunkerChange.Size = new System.Drawing.Size(884, 1);
            this.flowLayoutPanelBunkerChange.TabIndex = 1;
            // 
            // buttonBunkerChangeComment
            // 
            this.buttonBunkerChangeComment.Location = new System.Drawing.Point(4, 5);
            this.buttonBunkerChangeComment.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.buttonBunkerChangeComment.Name = "buttonBunkerChangeComment";
            this.buttonBunkerChangeComment.Size = new System.Drawing.Size(216, 35);
            this.buttonBunkerChangeComment.TabIndex = 2;
            this.buttonBunkerChangeComment.Text = "Изменить комментарий";
            this.buttonBunkerChangeComment.UseVisualStyleBackColor = true;
            this.buttonBunkerChangeComment.Visible = false;
            // 
            // labelBunkersCard
            // 
            this.labelBunkersCard.AutoSize = true;
            this.labelBunkersCard.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelBunkersCard.Location = new System.Drawing.Point(4, 0);
            this.labelBunkersCard.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelBunkersCard.Name = "labelBunkersCard";
            this.labelBunkersCard.Size = new System.Drawing.Size(128, 20);
            this.labelBunkersCard.TabIndex = 2;
            this.labelBunkersCard.Text = "Карта бункеров";
            // 
            // groupBoxBunkersLine2
            // 
            this.groupBoxBunkersLine2.Controls.Add(this.tableLayoutPanelBunkersLine2);
            this.groupBoxBunkersLine2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBoxBunkersLine2.Location = new System.Drawing.Point(896, 36);
            this.groupBoxBunkersLine2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBoxBunkersLine2.Name = "groupBoxBunkersLine2";
            this.groupBoxBunkersLine2.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBoxBunkersLine2.Size = new System.Drawing.Size(884, 624);
            this.groupBoxBunkersLine2.TabIndex = 5;
            this.groupBoxBunkersLine2.TabStop = false;
            this.groupBoxBunkersLine2.Text = "Линия 2";
            // 
            // tableLayoutPanelBunkersLine2
            // 
            this.tableLayoutPanelBunkersLine2.ColumnCount = 1;
            this.tableLayoutPanelBunkersLine2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanelBunkersLine2.Controls.Add(this.labelW5, 0, 0);
            this.tableLayoutPanelBunkersLine2.Controls.Add(this.labelW4, 0, 2);
            this.tableLayoutPanelBunkersLine2.Controls.Add(this.dataGridViewBunkersW5, 0, 1);
            this.tableLayoutPanelBunkersLine2.Controls.Add(this.dataGridViewBunkersW4, 0, 3);
            this.tableLayoutPanelBunkersLine2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanelBunkersLine2.Location = new System.Drawing.Point(4, 24);
            this.tableLayoutPanelBunkersLine2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tableLayoutPanelBunkersLine2.Name = "tableLayoutPanelBunkersLine2";
            this.tableLayoutPanelBunkersLine2.RowCount = 4;
            this.tableLayoutPanelBunkersLine2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 31F));
            this.tableLayoutPanelBunkersLine2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanelBunkersLine2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 31F));
            this.tableLayoutPanelBunkersLine2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanelBunkersLine2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 31F));
            this.tableLayoutPanelBunkersLine2.Size = new System.Drawing.Size(876, 595);
            this.tableLayoutPanelBunkersLine2.TabIndex = 6;
            // 
            // labelW5
            // 
            this.labelW5.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.labelW5.AutoSize = true;
            this.labelW5.Location = new System.Drawing.Point(4, 0);
            this.labelW5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelW5.Name = "labelW5";
            this.labelW5.Size = new System.Drawing.Size(98, 31);
            this.labelW5.TabIndex = 3;
            this.labelW5.Text = "Весы 5 - ПД";
            this.labelW5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelW4
            // 
            this.labelW4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.labelW4.AutoSize = true;
            this.labelW4.Location = new System.Drawing.Point(4, 297);
            this.labelW4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelW4.Name = "labelW4";
            this.labelW4.Size = new System.Drawing.Size(98, 31);
            this.labelW4.TabIndex = 4;
            this.labelW4.Text = "Весы 4 - ОД";
            this.labelW4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // dataGridViewBunkersW5
            // 
            this.dataGridViewBunkersW5.AllowUserToAddRows = false;
            this.dataGridViewBunkersW5.AllowUserToDeleteRows = false;
            this.dataGridViewBunkersW5.AllowUserToResizeRows = false;
            this.dataGridViewBunkersW5.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewBunkersW5.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCellsExceptHeaders;
            this.dataGridViewBunkersW5.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewBunkersW5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridViewBunkersW5.Location = new System.Drawing.Point(4, 36);
            this.dataGridViewBunkersW5.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.dataGridViewBunkersW5.Name = "dataGridViewBunkersW5";
            this.dataGridViewBunkersW5.ReadOnly = true;
            this.dataGridViewBunkersW5.RowHeadersVisible = false;
            this.dataGridViewBunkersW5.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewBunkersW5.Size = new System.Drawing.Size(868, 256);
            this.dataGridViewBunkersW5.TabIndex = 6;
            this.dataGridViewBunkersW5.SelectionChanged += new System.EventHandler(this.dataGridViewBunkersW6_SelectionChanged);
            this.dataGridViewBunkersW5.Sorted += new System.EventHandler(this.dataGridViewBunkersW5_Sorted);
            // 
            // dataGridViewBunkersW4
            // 
            this.dataGridViewBunkersW4.AllowUserToAddRows = false;
            this.dataGridViewBunkersW4.AllowUserToDeleteRows = false;
            this.dataGridViewBunkersW4.AllowUserToResizeRows = false;
            this.dataGridViewBunkersW4.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewBunkersW4.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCellsExceptHeaders;
            this.dataGridViewBunkersW4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewBunkersW4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridViewBunkersW4.Location = new System.Drawing.Point(4, 333);
            this.dataGridViewBunkersW4.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.dataGridViewBunkersW4.Name = "dataGridViewBunkersW4";
            this.dataGridViewBunkersW4.ReadOnly = true;
            this.dataGridViewBunkersW4.RowHeadersVisible = false;
            this.dataGridViewBunkersW4.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewBunkersW4.Size = new System.Drawing.Size(868, 257);
            this.dataGridViewBunkersW4.TabIndex = 5;
            this.dataGridViewBunkersW4.SelectionChanged += new System.EventHandler(this.dataGridViewBunkersW6_SelectionChanged);
            this.dataGridViewBunkersW4.Sorted += new System.EventHandler(this.dataGridViewBunkersW4_Sorted);
            // 
            // groupBoxBunkersLine1
            // 
            this.groupBoxBunkersLine1.Controls.Add(this.tableLayoutPanelLine1);
            this.groupBoxBunkersLine1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBoxBunkersLine1.Location = new System.Drawing.Point(4, 36);
            this.groupBoxBunkersLine1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBoxBunkersLine1.Name = "groupBoxBunkersLine1";
            this.groupBoxBunkersLine1.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBoxBunkersLine1.Size = new System.Drawing.Size(884, 624);
            this.groupBoxBunkersLine1.TabIndex = 4;
            this.groupBoxBunkersLine1.TabStop = false;
            this.groupBoxBunkersLine1.Text = "Линия 1";
            // 
            // tableLayoutPanelLine1
            // 
            this.tableLayoutPanelLine1.ColumnCount = 1;
            this.tableLayoutPanelLine1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanelLine1.Controls.Add(this.dataGridViewBunkersW6, 0, 1);
            this.tableLayoutPanelLine1.Controls.Add(this.labelW6, 0, 0);
            this.tableLayoutPanelLine1.Controls.Add(this.labelW2, 0, 2);
            this.tableLayoutPanelLine1.Controls.Add(this.dataGridViewBunkersW2, 0, 3);
            this.tableLayoutPanelLine1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanelLine1.Location = new System.Drawing.Point(4, 24);
            this.tableLayoutPanelLine1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tableLayoutPanelLine1.Name = "tableLayoutPanelLine1";
            this.tableLayoutPanelLine1.RowCount = 4;
            this.tableLayoutPanelLine1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 31F));
            this.tableLayoutPanelLine1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanelLine1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 31F));
            this.tableLayoutPanelLine1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanelLine1.Size = new System.Drawing.Size(876, 595);
            this.tableLayoutPanelLine1.TabIndex = 0;
            // 
            // dataGridViewBunkersW6
            // 
            this.dataGridViewBunkersW6.AllowUserToAddRows = false;
            this.dataGridViewBunkersW6.AllowUserToDeleteRows = false;
            this.dataGridViewBunkersW6.AllowUserToResizeRows = false;
            this.dataGridViewBunkersW6.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewBunkersW6.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCellsExceptHeaders;
            this.dataGridViewBunkersW6.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewBunkersW6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridViewBunkersW6.Location = new System.Drawing.Point(4, 36);
            this.dataGridViewBunkersW6.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.dataGridViewBunkersW6.Name = "dataGridViewBunkersW6";
            this.dataGridViewBunkersW6.ReadOnly = true;
            this.dataGridViewBunkersW6.RowHeadersVisible = false;
            this.dataGridViewBunkersW6.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewBunkersW6.Size = new System.Drawing.Size(868, 256);
            this.dataGridViewBunkersW6.TabIndex = 0;
            this.dataGridViewBunkersW6.SelectionChanged += new System.EventHandler(this.dataGridViewBunkersW6_SelectionChanged);
            this.dataGridViewBunkersW6.Sorted += new System.EventHandler(this.dataGridViewBunkersW6_Sorted);
            // 
            // labelW6
            // 
            this.labelW6.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.labelW6.AutoSize = true;
            this.labelW6.Location = new System.Drawing.Point(4, 0);
            this.labelW6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelW6.Name = "labelW6";
            this.labelW6.Size = new System.Drawing.Size(98, 31);
            this.labelW6.TabIndex = 1;
            this.labelW6.Text = "Весы 6 - ПД";
            this.labelW6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelW2
            // 
            this.labelW2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.labelW2.AutoSize = true;
            this.labelW2.Location = new System.Drawing.Point(4, 297);
            this.labelW2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelW2.Name = "labelW2";
            this.labelW2.Size = new System.Drawing.Size(98, 31);
            this.labelW2.TabIndex = 2;
            this.labelW2.Text = "Весы 2 - ОД";
            this.labelW2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // dataGridViewBunkersW2
            // 
            this.dataGridViewBunkersW2.AllowUserToAddRows = false;
            this.dataGridViewBunkersW2.AllowUserToDeleteRows = false;
            this.dataGridViewBunkersW2.AllowUserToResizeRows = false;
            this.dataGridViewBunkersW2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewBunkersW2.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCellsExceptHeaders;
            this.dataGridViewBunkersW2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewBunkersW2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridViewBunkersW2.Location = new System.Drawing.Point(4, 333);
            this.dataGridViewBunkersW2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.dataGridViewBunkersW2.Name = "dataGridViewBunkersW2";
            this.dataGridViewBunkersW2.ReadOnly = true;
            this.dataGridViewBunkersW2.RowHeadersVisible = false;
            this.dataGridViewBunkersW2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewBunkersW2.Size = new System.Drawing.Size(868, 257);
            this.dataGridViewBunkersW2.TabIndex = 3;
            this.dataGridViewBunkersW2.SelectionChanged += new System.EventHandler(this.dataGridViewBunkersW6_SelectionChanged);
            this.dataGridViewBunkersW2.Sorted += new System.EventHandler(this.dataGridViewBunkersW2_Sorted);
            // 
            // tabPageIngredients
            // 
            this.tabPageIngredients.Controls.Add(this.tableLayoutPanelIngredients);
            this.tabPageIngredients.Location = new System.Drawing.Point(4, 29);
            this.tabPageIngredients.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tabPageIngredients.Name = "tabPageIngredients";
            this.tabPageIngredients.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tabPageIngredients.Size = new System.Drawing.Size(1792, 675);
            this.tabPageIngredients.TabIndex = 3;
            this.tabPageIngredients.Text = "Ингредиенты";
            this.tabPageIngredients.UseVisualStyleBackColor = true;
            this.tabPageIngredients.Enter += new System.EventHandler(this.tabPageIngredients_Enter);
            // 
            // tableLayoutPanelIngredients
            // 
            this.tableLayoutPanelIngredients.ColumnCount = 1;
            this.tableLayoutPanelIngredients.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanelIngredients.Controls.Add(this.labelIngredients, 0, 0);
            this.tableLayoutPanelIngredients.Controls.Add(this.groupBoxIngredient, 0, 3);
            this.tableLayoutPanelIngredients.Controls.Add(this.flowLayoutPanelIngredientsButtons, 0, 2);
            this.tableLayoutPanelIngredients.Controls.Add(this.dataGridViewIngredients, 0, 1);
            this.tableLayoutPanelIngredients.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanelIngredients.Location = new System.Drawing.Point(4, 5);
            this.tableLayoutPanelIngredients.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tableLayoutPanelIngredients.Name = "tableLayoutPanelIngredients";
            this.tableLayoutPanelIngredients.RowCount = 4;
            this.tableLayoutPanelIngredients.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 24F));
            this.tableLayoutPanelIngredients.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanelIngredients.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 54F));
            this.tableLayoutPanelIngredients.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanelIngredients.Size = new System.Drawing.Size(1784, 665);
            this.tableLayoutPanelIngredients.TabIndex = 0;
            // 
            // labelIngredients
            // 
            this.labelIngredients.AutoSize = true;
            this.labelIngredients.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelIngredients.Location = new System.Drawing.Point(4, 0);
            this.labelIngredients.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelIngredients.Name = "labelIngredients";
            this.labelIngredients.Size = new System.Drawing.Size(212, 20);
            this.labelIngredients.TabIndex = 1;
            this.labelIngredients.Text = "Справочник ингредиентов";
            // 
            // groupBoxIngredient
            // 
            this.groupBoxIngredient.Controls.Add(this.panelIngredientAdd);
            this.groupBoxIngredient.Location = new System.Drawing.Point(4, 506);
            this.groupBoxIngredient.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBoxIngredient.Name = "groupBoxIngredient";
            this.groupBoxIngredient.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBoxIngredient.Size = new System.Drawing.Size(699, 154);
            this.groupBoxIngredient.TabIndex = 1;
            this.groupBoxIngredient.TabStop = false;
            this.groupBoxIngredient.Text = "Ингредиент";
            // 
            // panelIngredientAdd
            // 
            this.panelIngredientAdd.Controls.Add(this.buttonIngredientOk);
            this.panelIngredientAdd.Controls.Add(this.buttonIngredientCancel);
            this.panelIngredientAdd.Controls.Add(this.textBoxIngredientComment);
            this.panelIngredientAdd.Controls.Add(this.textBoxIngredientName);
            this.panelIngredientAdd.Controls.Add(this.labelIngredientComment);
            this.panelIngredientAdd.Controls.Add(this.labelIngredientName);
            this.panelIngredientAdd.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelIngredientAdd.Location = new System.Drawing.Point(4, 24);
            this.panelIngredientAdd.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.panelIngredientAdd.Name = "panelIngredientAdd";
            this.panelIngredientAdd.Size = new System.Drawing.Size(691, 125);
            this.panelIngredientAdd.TabIndex = 0;
            // 
            // buttonIngredientOk
            // 
            this.buttonIngredientOk.Location = new System.Drawing.Point(450, 86);
            this.buttonIngredientOk.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.buttonIngredientOk.Name = "buttonIngredientOk";
            this.buttonIngredientOk.Size = new System.Drawing.Size(112, 35);
            this.buttonIngredientOk.TabIndex = 5;
            this.buttonIngredientOk.Text = "Добавить";
            this.buttonIngredientOk.UseVisualStyleBackColor = true;
            // 
            // buttonIngredientCancel
            // 
            this.buttonIngredientCancel.Location = new System.Drawing.Point(572, 86);
            this.buttonIngredientCancel.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.buttonIngredientCancel.Name = "buttonIngredientCancel";
            this.buttonIngredientCancel.Size = new System.Drawing.Size(112, 35);
            this.buttonIngredientCancel.TabIndex = 4;
            this.buttonIngredientCancel.Text = "Отмена";
            this.buttonIngredientCancel.UseVisualStyleBackColor = true;
            // 
            // textBoxIngredientComment
            // 
            this.textBoxIngredientComment.Location = new System.Drawing.Point(129, 45);
            this.textBoxIngredientComment.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxIngredientComment.Name = "textBoxIngredientComment";
            this.textBoxIngredientComment.Size = new System.Drawing.Size(554, 26);
            this.textBoxIngredientComment.TabIndex = 3;
            // 
            // textBoxIngredientName
            // 
            this.textBoxIngredientName.Location = new System.Drawing.Point(129, 5);
            this.textBoxIngredientName.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxIngredientName.Name = "textBoxIngredientName";
            this.textBoxIngredientName.Size = new System.Drawing.Size(554, 26);
            this.textBoxIngredientName.TabIndex = 2;
            // 
            // labelIngredientComment
            // 
            this.labelIngredientComment.AutoSize = true;
            this.labelIngredientComment.Location = new System.Drawing.Point(4, 45);
            this.labelIngredientComment.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelIngredientComment.Name = "labelIngredientComment";
            this.labelIngredientComment.Size = new System.Drawing.Size(113, 20);
            this.labelIngredientComment.TabIndex = 1;
            this.labelIngredientComment.Text = "Комментарий";
            // 
            // labelIngredientName
            // 
            this.labelIngredientName.AutoSize = true;
            this.labelIngredientName.Location = new System.Drawing.Point(4, 9);
            this.labelIngredientName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelIngredientName.Name = "labelIngredientName";
            this.labelIngredientName.Size = new System.Drawing.Size(83, 20);
            this.labelIngredientName.TabIndex = 0;
            this.labelIngredientName.Text = "Название";
            // 
            // flowLayoutPanelIngredientsButtons
            // 
            this.flowLayoutPanelIngredientsButtons.Controls.Add(this.buttonAddIngredient);
            this.flowLayoutPanelIngredientsButtons.Controls.Add(this.buttonUpdateIngredient);
            this.flowLayoutPanelIngredientsButtons.Controls.Add(this.buttonDeleteIngredient);
            this.flowLayoutPanelIngredientsButtons.Location = new System.Drawing.Point(4, 452);
            this.flowLayoutPanelIngredientsButtons.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.flowLayoutPanelIngredientsButtons.Name = "flowLayoutPanelIngredientsButtons";
            this.flowLayoutPanelIngredientsButtons.Size = new System.Drawing.Size(1776, 44);
            this.flowLayoutPanelIngredientsButtons.TabIndex = 0;
            // 
            // buttonAddIngredient
            // 
            this.buttonAddIngredient.Location = new System.Drawing.Point(4, 5);
            this.buttonAddIngredient.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.buttonAddIngredient.Name = "buttonAddIngredient";
            this.buttonAddIngredient.Size = new System.Drawing.Size(112, 35);
            this.buttonAddIngredient.TabIndex = 0;
            this.buttonAddIngredient.Text = "Добавить";
            this.buttonAddIngredient.UseVisualStyleBackColor = true;
            // 
            // buttonUpdateIngredient
            // 
            this.buttonUpdateIngredient.Location = new System.Drawing.Point(124, 5);
            this.buttonUpdateIngredient.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.buttonUpdateIngredient.Name = "buttonUpdateIngredient";
            this.buttonUpdateIngredient.Size = new System.Drawing.Size(112, 35);
            this.buttonUpdateIngredient.TabIndex = 2;
            this.buttonUpdateIngredient.Text = "Изменить";
            this.buttonUpdateIngredient.UseVisualStyleBackColor = true;
            // 
            // buttonDeleteIngredient
            // 
            this.buttonDeleteIngredient.Location = new System.Drawing.Point(244, 5);
            this.buttonDeleteIngredient.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.buttonDeleteIngredient.Name = "buttonDeleteIngredient";
            this.buttonDeleteIngredient.Size = new System.Drawing.Size(112, 35);
            this.buttonDeleteIngredient.TabIndex = 1;
            this.buttonDeleteIngredient.Text = "Удалить";
            this.buttonDeleteIngredient.UseVisualStyleBackColor = true;
            // 
            // dataGridViewIngredients
            // 
            this.dataGridViewIngredients.AllowUserToAddRows = false;
            this.dataGridViewIngredients.AllowUserToDeleteRows = false;
            this.dataGridViewIngredients.AllowUserToResizeRows = false;
            this.dataGridViewIngredients.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewIngredients.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCellsExceptHeaders;
            this.dataGridViewIngredients.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewIngredients.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridViewIngredients.Location = new System.Drawing.Point(4, 29);
            this.dataGridViewIngredients.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.dataGridViewIngredients.Name = "dataGridViewIngredients";
            this.dataGridViewIngredients.ReadOnly = true;
            this.dataGridViewIngredients.RowHeadersVisible = false;
            this.dataGridViewIngredients.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewIngredients.Size = new System.Drawing.Size(1776, 413);
            this.dataGridViewIngredients.TabIndex = 2;
            // 
            // tabPageRecipe
            // 
            this.tabPageRecipe.Controls.Add(this.tableLayoutPanelVerticalSplit);
            this.tabPageRecipe.Location = new System.Drawing.Point(4, 29);
            this.tabPageRecipe.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tabPageRecipe.Name = "tabPageRecipe";
            this.tabPageRecipe.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tabPageRecipe.Size = new System.Drawing.Size(1792, 675);
            this.tabPageRecipe.TabIndex = 0;
            this.tabPageRecipe.Text = "Текущие рецепты";
            this.tabPageRecipe.UseVisualStyleBackColor = true;
            this.tabPageRecipe.Enter += new System.EventHandler(this.tabPageRecipe_Enter);
            // 
            // tableLayoutPanelVerticalSplit
            // 
            this.tableLayoutPanelVerticalSplit.ColumnCount = 1;
            this.tableLayoutPanelVerticalSplit.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanelVerticalSplit.Controls.Add(this.tableLayoutPanelRecipes, 0, 0);
            this.tableLayoutPanelVerticalSplit.Controls.Add(this.panel1, 0, 1);
            this.tableLayoutPanelVerticalSplit.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanelVerticalSplit.Location = new System.Drawing.Point(4, 5);
            this.tableLayoutPanelVerticalSplit.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tableLayoutPanelVerticalSplit.Name = "tableLayoutPanelVerticalSplit";
            this.tableLayoutPanelVerticalSplit.RowCount = 2;
            this.tableLayoutPanelVerticalSplit.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanelVerticalSplit.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 92F));
            this.tableLayoutPanelVerticalSplit.Size = new System.Drawing.Size(1784, 665);
            this.tableLayoutPanelVerticalSplit.TabIndex = 0;
            this.tableLayoutPanelVerticalSplit.Paint += new System.Windows.Forms.PaintEventHandler(this.tableLayoutPanelVerticalSplit_Paint);
            // 
            // tableLayoutPanelRecipes
            // 
            this.tableLayoutPanelRecipes.ColumnCount = 2;
            this.tableLayoutPanelRecipes.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanelRecipes.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanelRecipes.Controls.Add(this.tableLayoutPanelLeftData, 0, 0);
            this.tableLayoutPanelRecipes.Controls.Add(this.tableLayoutPanelRightData, 1, 0);
            this.tableLayoutPanelRecipes.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanelRecipes.Location = new System.Drawing.Point(4, 5);
            this.tableLayoutPanelRecipes.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tableLayoutPanelRecipes.Name = "tableLayoutPanelRecipes";
            this.tableLayoutPanelRecipes.RowCount = 1;
            this.tableLayoutPanelRecipes.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanelRecipes.Size = new System.Drawing.Size(1776, 563);
            this.tableLayoutPanelRecipes.TabIndex = 0;
            this.tableLayoutPanelRecipes.Paint += new System.Windows.Forms.PaintEventHandler(this.tableLayoutPanelRecipes_Paint);
            // 
            // tableLayoutPanelLeftData
            // 
            this.tableLayoutPanelLeftData.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.tableLayoutPanelLeftData.ColumnCount = 1;
            this.tableLayoutPanelLeftData.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanelLeftData.Controls.Add(this.labelRecipe, 0, 0);
            this.tableLayoutPanelLeftData.Controls.Add(this.dataGridViewCurrentRecipes, 0, 2);
            this.tableLayoutPanelLeftData.Controls.Add(this.groupBoxCurrentPeriod, 0, 1);
            this.tableLayoutPanelLeftData.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanelLeftData.Location = new System.Drawing.Point(4, 5);
            this.tableLayoutPanelLeftData.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tableLayoutPanelLeftData.Name = "tableLayoutPanelLeftData";
            this.tableLayoutPanelLeftData.RowCount = 3;
            this.tableLayoutPanelLeftData.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanelLeftData.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 77F));
            this.tableLayoutPanelLeftData.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanelLeftData.Size = new System.Drawing.Size(880, 553);
            this.tableLayoutPanelLeftData.TabIndex = 0;
            // 
            // labelRecipe
            // 
            this.labelRecipe.AutoSize = true;
            this.labelRecipe.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelRecipe.Location = new System.Drawing.Point(4, 0);
            this.labelRecipe.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelRecipe.Name = "labelRecipe";
            this.labelRecipe.Size = new System.Drawing.Size(142, 20);
            this.labelRecipe.TabIndex = 0;
            this.labelRecipe.Text = "Текущие рецепты";
            // 
            // dataGridViewCurrentRecipes
            // 
            this.dataGridViewCurrentRecipes.AllowUserToAddRows = false;
            this.dataGridViewCurrentRecipes.AllowUserToDeleteRows = false;
            this.dataGridViewCurrentRecipes.AllowUserToOrderColumns = true;
            this.dataGridViewCurrentRecipes.AllowUserToResizeRows = false;
            this.dataGridViewCurrentRecipes.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewCurrentRecipes.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCellsExceptHeaders;
            this.dataGridViewCurrentRecipes.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewCurrentRecipes.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridViewCurrentRecipes.Location = new System.Drawing.Point(4, 102);
            this.dataGridViewCurrentRecipes.Margin = new System.Windows.Forms.Padding(4, 5, 4, 8);
            this.dataGridViewCurrentRecipes.Name = "dataGridViewCurrentRecipes";
            this.dataGridViewCurrentRecipes.ReadOnly = true;
            this.dataGridViewCurrentRecipes.RowHeadersVisible = false;
            this.dataGridViewCurrentRecipes.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewCurrentRecipes.Size = new System.Drawing.Size(872, 443);
            this.dataGridViewCurrentRecipes.TabIndex = 1;
            this.dataGridViewCurrentRecipes.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewCurrentRecipes_CellDoubleClick);
            this.dataGridViewCurrentRecipes.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.dataGridViewCurrentRecipes_CellFormatting);
            this.dataGridViewCurrentRecipes.SelectionChanged += new System.EventHandler(this.dataGridViewCurrentRecipes_SelectionChanged);
            this.dataGridViewCurrentRecipes.Sorted += new System.EventHandler(this.dataGridViewCurrentRecipes_Sorted);
            // 
            // groupBoxCurrentPeriod
            // 
            this.groupBoxCurrentPeriod.Controls.Add(this.flowLayoutPanel1);
            this.groupBoxCurrentPeriod.Location = new System.Drawing.Point(4, 25);
            this.groupBoxCurrentPeriod.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBoxCurrentPeriod.Name = "groupBoxCurrentPeriod";
            this.groupBoxCurrentPeriod.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBoxCurrentPeriod.Size = new System.Drawing.Size(612, 67);
            this.groupBoxCurrentPeriod.TabIndex = 2;
            this.groupBoxCurrentPeriod.TabStop = false;
            this.groupBoxCurrentPeriod.Text = "Отображать";
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Controls.Add(this.radioButtonCurrentAllTime);
            this.flowLayoutPanel1.Controls.Add(this.radioButtonCurrentYear);
            this.flowLayoutPanel1.Controls.Add(this.radioButtonCurrentMonth);
            this.flowLayoutPanel1.Controls.Add(this.radioButtonCurrentWeek);
            this.flowLayoutPanel1.Controls.Add(this.radioButtonCurrentById);
            this.flowLayoutPanel1.Controls.Add(this.textBoxCurrentId);
            this.flowLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel1.Location = new System.Drawing.Point(4, 24);
            this.flowLayoutPanel1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(604, 38);
            this.flowLayoutPanel1.TabIndex = 0;
            // 
            // radioButtonCurrentAllTime
            // 
            this.radioButtonCurrentAllTime.AutoSize = true;
            this.radioButtonCurrentAllTime.Location = new System.Drawing.Point(4, 5);
            this.radioButtonCurrentAllTime.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButtonCurrentAllTime.Name = "radioButtonCurrentAllTime";
            this.radioButtonCurrentAllTime.Size = new System.Drawing.Size(128, 24);
            this.radioButtonCurrentAllTime.TabIndex = 5;
            this.radioButtonCurrentAllTime.TabStop = true;
            this.radioButtonCurrentAllTime.Text = "За все время";
            this.radioButtonCurrentAllTime.UseVisualStyleBackColor = true;
            this.radioButtonCurrentAllTime.CheckedChanged += new System.EventHandler(this.radioButtonCurrentAllTime_CheckedChanged);
            // 
            // radioButtonCurrentYear
            // 
            this.radioButtonCurrentYear.AutoSize = true;
            this.radioButtonCurrentYear.Location = new System.Drawing.Point(140, 5);
            this.radioButtonCurrentYear.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButtonCurrentYear.Name = "radioButtonCurrentYear";
            this.radioButtonCurrentYear.Size = new System.Drawing.Size(56, 24);
            this.radioButtonCurrentYear.TabIndex = 2;
            this.radioButtonCurrentYear.TabStop = true;
            this.radioButtonCurrentYear.Text = "Год";
            this.radioButtonCurrentYear.UseVisualStyleBackColor = true;
            this.radioButtonCurrentYear.CheckedChanged += new System.EventHandler(this.radioButtonCurrentYear_CheckedChanged);
            // 
            // radioButtonCurrentMonth
            // 
            this.radioButtonCurrentMonth.AutoSize = true;
            this.radioButtonCurrentMonth.Location = new System.Drawing.Point(204, 5);
            this.radioButtonCurrentMonth.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButtonCurrentMonth.Name = "radioButtonCurrentMonth";
            this.radioButtonCurrentMonth.Size = new System.Drawing.Size(75, 24);
            this.radioButtonCurrentMonth.TabIndex = 1;
            this.radioButtonCurrentMonth.TabStop = true;
            this.radioButtonCurrentMonth.Text = "Месяц";
            this.radioButtonCurrentMonth.UseVisualStyleBackColor = true;
            this.radioButtonCurrentMonth.CheckedChanged += new System.EventHandler(this.radioButtonCurrentMonth_CheckedChanged);
            // 
            // radioButtonCurrentWeek
            // 
            this.radioButtonCurrentWeek.AutoSize = true;
            this.radioButtonCurrentWeek.Location = new System.Drawing.Point(287, 5);
            this.radioButtonCurrentWeek.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButtonCurrentWeek.Name = "radioButtonCurrentWeek";
            this.radioButtonCurrentWeek.Size = new System.Drawing.Size(87, 24);
            this.radioButtonCurrentWeek.TabIndex = 0;
            this.radioButtonCurrentWeek.TabStop = true;
            this.radioButtonCurrentWeek.Text = "Неделя";
            this.radioButtonCurrentWeek.UseVisualStyleBackColor = true;
            this.radioButtonCurrentWeek.CheckedChanged += new System.EventHandler(this.radioButtonCurrentWeek_CheckedChanged);
            // 
            // radioButtonCurrentById
            // 
            this.radioButtonCurrentById.AutoSize = true;
            this.radioButtonCurrentById.Location = new System.Drawing.Point(382, 5);
            this.radioButtonCurrentById.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButtonCurrentById.Name = "radioButtonCurrentById";
            this.radioButtonCurrentById.Size = new System.Drawing.Size(89, 24);
            this.radioButtonCurrentById.TabIndex = 3;
            this.radioButtonCurrentById.TabStop = true;
            this.radioButtonCurrentById.Text = "Номер с";
            this.radioButtonCurrentById.UseVisualStyleBackColor = true;
            this.radioButtonCurrentById.CheckedChanged += new System.EventHandler(this.radioButtonCurrentById_CheckedChanged);
            // 
            // textBoxCurrentId
            // 
            this.textBoxCurrentId.Location = new System.Drawing.Point(479, 5);
            this.textBoxCurrentId.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxCurrentId.Name = "textBoxCurrentId";
            this.textBoxCurrentId.Size = new System.Drawing.Size(118, 26);
            this.textBoxCurrentId.TabIndex = 4;
            this.textBoxCurrentId.TextChanged += new System.EventHandler(this.textBoxCurrentId_TextChanged);
            // 
            // tableLayoutPanelRightData
            // 
            this.tableLayoutPanelRightData.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.tableLayoutPanelRightData.ColumnCount = 1;
            this.tableLayoutPanelRightData.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanelRightData.Controls.Add(this.labelOneRecipe, 0, 0);
            this.tableLayoutPanelRightData.Controls.Add(this.dataGridViewRecipe, 0, 1);
            this.tableLayoutPanelRightData.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanelRightData.Location = new System.Drawing.Point(892, 5);
            this.tableLayoutPanelRightData.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tableLayoutPanelRightData.Name = "tableLayoutPanelRightData";
            this.tableLayoutPanelRightData.RowCount = 2;
            this.tableLayoutPanelRightData.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanelRightData.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanelRightData.Size = new System.Drawing.Size(880, 553);
            this.tableLayoutPanelRightData.TabIndex = 1;
            // 
            // labelOneRecipe
            // 
            this.labelOneRecipe.AutoSize = true;
            this.labelOneRecipe.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelOneRecipe.Location = new System.Drawing.Point(4, 0);
            this.labelOneRecipe.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelOneRecipe.Name = "labelOneRecipe";
            this.labelOneRecipe.Size = new System.Drawing.Size(64, 20);
            this.labelOneRecipe.TabIndex = 1;
            this.labelOneRecipe.Text = "Состав";
            // 
            // dataGridViewRecipe
            // 
            this.dataGridViewRecipe.AllowUserToAddRows = false;
            this.dataGridViewRecipe.AllowUserToDeleteRows = false;
            this.dataGridViewRecipe.AllowUserToResizeRows = false;
            this.dataGridViewRecipe.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewRecipe.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCellsExceptHeaders;
            this.dataGridViewRecipe.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewRecipe.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridViewRecipe.Location = new System.Drawing.Point(4, 25);
            this.dataGridViewRecipe.Margin = new System.Windows.Forms.Padding(4, 5, 4, 8);
            this.dataGridViewRecipe.Name = "dataGridViewRecipe";
            this.dataGridViewRecipe.ReadOnly = true;
            this.dataGridViewRecipe.RowHeadersVisible = false;
            this.dataGridViewRecipe.Size = new System.Drawing.Size(872, 520);
            this.dataGridViewRecipe.TabIndex = 2;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.flowLayoutPanelButtons);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(4, 578);
            this.panel1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1776, 82);
            this.panel1.TabIndex = 1;
            // 
            // flowLayoutPanelButtons
            // 
            this.flowLayoutPanelButtons.Controls.Add(this.groupBoxAddButtons);
            this.flowLayoutPanelButtons.Controls.Add(this.buttonStartRecipe);
            this.flowLayoutPanelButtons.Controls.Add(this.buttonRecipeCloseOper);
            this.flowLayoutPanelButtons.Controls.Add(this.buttonDeleteRecipe);
            this.flowLayoutPanelButtons.Controls.Add(this.groupBoxRecipeControl);
            this.flowLayoutPanelButtons.Controls.Add(this.groupBoxConsumption);
            this.flowLayoutPanelButtons.Controls.Add(this.buttonPrintRepMainView);
            this.flowLayoutPanelButtons.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanelButtons.Location = new System.Drawing.Point(0, 0);
            this.flowLayoutPanelButtons.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.flowLayoutPanelButtons.Name = "flowLayoutPanelButtons";
            this.flowLayoutPanelButtons.Size = new System.Drawing.Size(1776, 82);
            this.flowLayoutPanelButtons.TabIndex = 0;
            // 
            // groupBoxAddButtons
            // 
            this.groupBoxAddButtons.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.groupBoxAddButtons.Controls.Add(this.buttonAddImport);
            this.groupBoxAddButtons.Controls.Add(this.buttonAddByTemplate);
            this.groupBoxAddButtons.Controls.Add(this.buttonAdd);
            this.groupBoxAddButtons.Location = new System.Drawing.Point(4, 5);
            this.groupBoxAddButtons.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBoxAddButtons.Name = "groupBoxAddButtons";
            this.groupBoxAddButtons.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBoxAddButtons.Size = new System.Drawing.Size(390, 72);
            this.groupBoxAddButtons.TabIndex = 5;
            this.groupBoxAddButtons.TabStop = false;
            this.groupBoxAddButtons.Text = "Добавить";
            // 
            // buttonAddImport
            // 
            this.buttonAddImport.Location = new System.Drawing.Point(132, 31);
            this.buttonAddImport.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.buttonAddImport.Name = "buttonAddImport";
            this.buttonAddImport.Size = new System.Drawing.Size(112, 35);
            this.buttonAddImport.TabIndex = 2;
            this.buttonAddImport.Text = "Импорт";
            this.buttonAddImport.UseVisualStyleBackColor = true;
            this.buttonAddImport.Click += new System.EventHandler(this.buttonAddImport_Click);
            // 
            // buttonAddByTemplate
            // 
            this.buttonAddByTemplate.Location = new System.Drawing.Point(254, 31);
            this.buttonAddByTemplate.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.buttonAddByTemplate.Name = "buttonAddByTemplate";
            this.buttonAddByTemplate.Size = new System.Drawing.Size(128, 35);
            this.buttonAddByTemplate.TabIndex = 1;
            this.buttonAddByTemplate.Text = "По шаблону";
            this.buttonAddByTemplate.UseVisualStyleBackColor = true;
            // 
            // buttonAdd
            // 
            this.buttonAdd.Location = new System.Drawing.Point(10, 31);
            this.buttonAdd.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.buttonAdd.Name = "buttonAdd";
            this.buttonAdd.Size = new System.Drawing.Size(112, 35);
            this.buttonAdd.TabIndex = 0;
            this.buttonAdd.Text = "Новый";
            this.buttonAdd.UseVisualStyleBackColor = true;
            // 
            // buttonStartRecipe
            // 
            this.buttonStartRecipe.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.buttonStartRecipe.Location = new System.Drawing.Point(402, 36);
            this.buttonStartRecipe.Margin = new System.Windows.Forms.Padding(4, 30, 4, 5);
            this.buttonStartRecipe.MinimumSize = new System.Drawing.Size(0, 35);
            this.buttonStartRecipe.Name = "buttonStartRecipe";
            this.buttonStartRecipe.Size = new System.Drawing.Size(159, 35);
            this.buttonStartRecipe.TabIndex = 11;
            this.buttonStartRecipe.Text = "Пустить в работу";
            this.buttonStartRecipe.UseVisualStyleBackColor = true;
            this.buttonStartRecipe.Click += new System.EventHandler(this.buttonStartRecipe_Click);
            // 
            // buttonRecipeCloseOper
            // 
            this.buttonRecipeCloseOper.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.buttonRecipeCloseOper.Location = new System.Drawing.Point(569, 36);
            this.buttonRecipeCloseOper.Margin = new System.Windows.Forms.Padding(4, 30, 4, 5);
            this.buttonRecipeCloseOper.MinimumSize = new System.Drawing.Size(0, 35);
            this.buttonRecipeCloseOper.Name = "buttonRecipeCloseOper";
            this.buttonRecipeCloseOper.Size = new System.Drawing.Size(166, 35);
            this.buttonRecipeCloseOper.TabIndex = 12;
            this.buttonRecipeCloseOper.Text = "Завершить рецепт";
            this.buttonRecipeCloseOper.UseVisualStyleBackColor = true;
            // 
            // buttonDeleteRecipe
            // 
            this.buttonDeleteRecipe.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.buttonDeleteRecipe.Location = new System.Drawing.Point(743, 36);
            this.buttonDeleteRecipe.Margin = new System.Windows.Forms.Padding(4, 30, 4, 5);
            this.buttonDeleteRecipe.MaximumSize = new System.Drawing.Size(150, 35);
            this.buttonDeleteRecipe.MinimumSize = new System.Drawing.Size(0, 35);
            this.buttonDeleteRecipe.Name = "buttonDeleteRecipe";
            this.buttonDeleteRecipe.Size = new System.Drawing.Size(99, 35);
            this.buttonDeleteRecipe.TabIndex = 8;
            this.buttonDeleteRecipe.Text = "Удалить";
            this.buttonDeleteRecipe.UseVisualStyleBackColor = true;
            this.buttonDeleteRecipe.Click += new System.EventHandler(this.buttonDeleteRecipe_Click);
            // 
            // groupBoxRecipeControl
            // 
            this.groupBoxRecipeControl.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.groupBoxRecipeControl.Controls.Add(this.buttonSwapBunkers);
            this.groupBoxRecipeControl.Controls.Add(this.buttonSkipBunker);
            this.groupBoxRecipeControl.Controls.Add(this.buttonGoToWork);
            this.groupBoxRecipeControl.Controls.Add(this.buttonCloseCurrent);
            this.groupBoxRecipeControl.Location = new System.Drawing.Point(850, 5);
            this.groupBoxRecipeControl.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBoxRecipeControl.Name = "groupBoxRecipeControl";
            this.groupBoxRecipeControl.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBoxRecipeControl.Size = new System.Drawing.Size(687, 72);
            this.groupBoxRecipeControl.TabIndex = 10;
            this.groupBoxRecipeControl.TabStop = false;
            this.groupBoxRecipeControl.Text = "Управление рецептами";
            // 
            // buttonSwapBunkers
            // 
            this.buttonSwapBunkers.Location = new System.Drawing.Point(520, 31);
            this.buttonSwapBunkers.Margin = new System.Windows.Forms.Padding(4, 23, 4, 5);
            this.buttonSwapBunkers.MinimumSize = new System.Drawing.Size(0, 35);
            this.buttonSwapBunkers.Name = "buttonSwapBunkers";
            this.buttonSwapBunkers.Size = new System.Drawing.Size(159, 35);
            this.buttonSwapBunkers.TabIndex = 11;
            this.buttonSwapBunkers.Text = "Замена бункера";
            this.buttonSwapBunkers.UseVisualStyleBackColor = true;
            this.buttonSwapBunkers.Click += new System.EventHandler(this.buttonSwapBunkers_Click);
            // 
            // buttonSkipBunker
            // 
            this.buttonSkipBunker.Location = new System.Drawing.Point(352, 31);
            this.buttonSkipBunker.Margin = new System.Windows.Forms.Padding(4, 23, 4, 5);
            this.buttonSkipBunker.MinimumSize = new System.Drawing.Size(0, 35);
            this.buttonSkipBunker.Name = "buttonSkipBunker";
            this.buttonSkipBunker.Size = new System.Drawing.Size(159, 35);
            this.buttonSkipBunker.TabIndex = 10;
            this.buttonSkipBunker.Text = "Пропуск бункера";
            this.buttonSkipBunker.UseVisualStyleBackColor = true;
            this.buttonSkipBunker.Click += new System.EventHandler(this.buttonSkipBunker_Click);
            // 
            // buttonGoToWork
            // 
            this.buttonGoToWork.Location = new System.Drawing.Point(9, 31);
            this.buttonGoToWork.Margin = new System.Windows.Forms.Padding(4, 23, 4, 5);
            this.buttonGoToWork.MinimumSize = new System.Drawing.Size(0, 35);
            this.buttonGoToWork.Name = "buttonGoToWork";
            this.buttonGoToWork.Size = new System.Drawing.Size(159, 35);
            this.buttonGoToWork.TabIndex = 7;
            this.buttonGoToWork.Text = "Пустить в работу";
            this.buttonGoToWork.UseVisualStyleBackColor = true;
            this.buttonGoToWork.Click += new System.EventHandler(this.buttonGoToWork_Click);
            // 
            // buttonCloseCurrent
            // 
            this.buttonCloseCurrent.Location = new System.Drawing.Point(177, 31);
            this.buttonCloseCurrent.Margin = new System.Windows.Forms.Padding(4, 23, 4, 5);
            this.buttonCloseCurrent.MinimumSize = new System.Drawing.Size(0, 35);
            this.buttonCloseCurrent.Name = "buttonCloseCurrent";
            this.buttonCloseCurrent.Size = new System.Drawing.Size(166, 35);
            this.buttonCloseCurrent.TabIndex = 9;
            this.buttonCloseCurrent.Text = "Завершить рецепт";
            this.buttonCloseCurrent.UseVisualStyleBackColor = true;
            // 
            // groupBoxConsumption
            // 
            this.groupBoxConsumption.Controls.Add(this.buttonConsumptionFile);
            this.groupBoxConsumption.Controls.Add(this.buttonConsumptionPrint);
            this.groupBoxConsumption.Location = new System.Drawing.Point(4, 87);
            this.groupBoxConsumption.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBoxConsumption.Name = "groupBoxConsumption";
            this.groupBoxConsumption.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBoxConsumption.Size = new System.Drawing.Size(258, 75);
            this.groupBoxConsumption.TabIndex = 6;
            this.groupBoxConsumption.TabStop = false;
            this.groupBoxConsumption.Text = "Расход материала";
            // 
            // buttonConsumptionFile
            // 
            this.buttonConsumptionFile.Location = new System.Drawing.Point(132, 31);
            this.buttonConsumptionFile.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.buttonConsumptionFile.Name = "buttonConsumptionFile";
            this.buttonConsumptionFile.Size = new System.Drawing.Size(112, 35);
            this.buttonConsumptionFile.TabIndex = 2;
            this.buttonConsumptionFile.Text = "Сохранить";
            this.buttonConsumptionFile.UseVisualStyleBackColor = true;
            this.buttonConsumptionFile.Click += new System.EventHandler(this.buttonConsumptionFile_Click);
            // 
            // buttonConsumptionPrint
            // 
            this.buttonConsumptionPrint.Location = new System.Drawing.Point(10, 31);
            this.buttonConsumptionPrint.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.buttonConsumptionPrint.Name = "buttonConsumptionPrint";
            this.buttonConsumptionPrint.Size = new System.Drawing.Size(112, 35);
            this.buttonConsumptionPrint.TabIndex = 0;
            this.buttonConsumptionPrint.Text = "Печать";
            this.buttonConsumptionPrint.UseVisualStyleBackColor = true;
            this.buttonConsumptionPrint.Click += new System.EventHandler(this.buttonConsumptionPrint_Click);
            // 
            // buttonPrintRepMainView
            // 
            this.buttonPrintRepMainView.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.buttonPrintRepMainView.Location = new System.Drawing.Point(270, 119);
            this.buttonPrintRepMainView.Margin = new System.Windows.Forms.Padding(4, 29, 4, 5);
            this.buttonPrintRepMainView.MinimumSize = new System.Drawing.Size(0, 35);
            this.buttonPrintRepMainView.Name = "buttonPrintRepMainView";
            this.buttonPrintRepMainView.Size = new System.Drawing.Size(159, 35);
            this.buttonPrintRepMainView.TabIndex = 13;
            this.buttonPrintRepMainView.Text = "Печать отчета";
            this.buttonPrintRepMainView.UseVisualStyleBackColor = true;
            this.buttonPrintRepMainView.Click += new System.EventHandler(this.buttonPrintRepMainView_Click);
            // 
            // tabControlIngredients
            // 
            this.tabControlIngredients.Controls.Add(this.tabPageRecipe);
            this.tabControlIngredients.Controls.Add(this.tabPageIngredients);
            this.tabControlIngredients.Controls.Add(this.tabPageBunkersCard);
            this.tabControlIngredients.Controls.Add(this.tabPagePortion);
            this.tabControlIngredients.Controls.Add(this.tabPageReport);
            this.tabControlIngredients.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControlIngredients.Location = new System.Drawing.Point(0, 0);
            this.tabControlIngredients.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tabControlIngredients.Name = "tabControlIngredients";
            this.tabControlIngredients.SelectedIndex = 0;
            this.tabControlIngredients.Size = new System.Drawing.Size(1800, 708);
            this.tabControlIngredients.TabIndex = 0;
            this.tabControlIngredients.Enter += new System.EventHandler(this.tabControlIngredients_Enter);
            // 
            // tabPageReport
            // 
            this.tabPageReport.Controls.Add(this.tableLayoutPanelReport);
            this.tabPageReport.Location = new System.Drawing.Point(4, 29);
            this.tabPageReport.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tabPageReport.Name = "tabPageReport";
            this.tabPageReport.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tabPageReport.Size = new System.Drawing.Size(1792, 675);
            this.tabPageReport.TabIndex = 5;
            this.tabPageReport.Text = "Отчет";
            this.tabPageReport.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanelReport
            // 
            this.tableLayoutPanelReport.ColumnCount = 1;
            this.tableLayoutPanelReport.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanelReport.Controls.Add(this.labelReport, 0, 0);
            this.tableLayoutPanelReport.Controls.Add(this.panelReportControls, 0, 1);
            this.tableLayoutPanelReport.Controls.Add(this.dataGridViewReport, 0, 2);
            this.tableLayoutPanelReport.Controls.Add(this.flowLayoutPanel3, 0, 3);
            this.tableLayoutPanelReport.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanelReport.Location = new System.Drawing.Point(4, 5);
            this.tableLayoutPanelReport.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tableLayoutPanelReport.Name = "tableLayoutPanelReport";
            this.tableLayoutPanelReport.RowCount = 4;
            this.tableLayoutPanelReport.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 24F));
            this.tableLayoutPanelReport.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 184F));
            this.tableLayoutPanelReport.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanelReport.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 54F));
            this.tableLayoutPanelReport.Size = new System.Drawing.Size(1784, 665);
            this.tableLayoutPanelReport.TabIndex = 0;
            // 
            // labelReport
            // 
            this.labelReport.AutoSize = true;
            this.labelReport.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelReport.Location = new System.Drawing.Point(4, 0);
            this.labelReport.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelReport.Name = "labelReport";
            this.labelReport.Size = new System.Drawing.Size(192, 20);
            this.labelReport.TabIndex = 2;
            this.labelReport.Text = "Формирование отчетов";
            // 
            // panelReportControls
            // 
            this.panelReportControls.Controls.Add(this.groupBoxAccounting);
            this.panelReportControls.Controls.Add(this.checkBoxByDate);
            this.panelReportControls.Controls.Add(this.checkBoxByNumber);
            this.panelReportControls.Controls.Add(this.textBoxToId);
            this.panelReportControls.Controls.Add(this.labelSplit);
            this.panelReportControls.Controls.Add(this.groupBoxExcelExport);
            this.panelReportControls.Controls.Add(this.textBoxFromId);
            this.panelReportControls.Controls.Add(this.dateTimePickerFrom);
            this.panelReportControls.Controls.Add(this.label10);
            this.panelReportControls.Controls.Add(this.dateTimePickerTo);
            this.panelReportControls.Controls.Add(this.groupBoxReportStatus);
            this.panelReportControls.Controls.Add(this.buttonRefreshReport);
            this.panelReportControls.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelReportControls.Location = new System.Drawing.Point(4, 29);
            this.panelReportControls.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.panelReportControls.Name = "panelReportControls";
            this.panelReportControls.Size = new System.Drawing.Size(1776, 174);
            this.panelReportControls.TabIndex = 3;
            // 
            // groupBoxAccounting
            // 
            this.groupBoxAccounting.Controls.Add(this.buttonPrintAccounting);
            this.groupBoxAccounting.Controls.Add(this.buttonCreateAccountingReport);
            this.groupBoxAccounting.Controls.Add(this.labelAccounting);
            this.groupBoxAccounting.Controls.Add(this.textBoxAccountingId);
            this.groupBoxAccounting.Location = new System.Drawing.Point(232, 5);
            this.groupBoxAccounting.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBoxAccounting.Name = "groupBoxAccounting";
            this.groupBoxAccounting.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBoxAccounting.Size = new System.Drawing.Size(478, 67);
            this.groupBoxAccounting.TabIndex = 31;
            this.groupBoxAccounting.TabStop = false;
            this.groupBoxAccounting.Text = "Отчет для бухгалтерии";
            // 
            // buttonPrintAccounting
            // 
            this.buttonPrintAccounting.Location = new System.Drawing.Point(252, 28);
            this.buttonPrintAccounting.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.buttonPrintAccounting.Name = "buttonPrintAccounting";
            this.buttonPrintAccounting.Size = new System.Drawing.Size(105, 35);
            this.buttonPrintAccounting.TabIndex = 23;
            this.buttonPrintAccounting.Text = "Печать";
            this.buttonPrintAccounting.UseVisualStyleBackColor = true;
            this.buttonPrintAccounting.Click += new System.EventHandler(this.buttonPrintAccounting_Click);
            // 
            // buttonCreateAccountingReport
            // 
            this.buttonCreateAccountingReport.Location = new System.Drawing.Point(366, 28);
            this.buttonCreateAccountingReport.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.buttonCreateAccountingReport.Name = "buttonCreateAccountingReport";
            this.buttonCreateAccountingReport.Size = new System.Drawing.Size(105, 35);
            this.buttonCreateAccountingReport.TabIndex = 22;
            this.buttonCreateAccountingReport.Text = "Сохранить";
            this.buttonCreateAccountingReport.UseVisualStyleBackColor = true;
            this.buttonCreateAccountingReport.Click += new System.EventHandler(this.buttonCreateAccountingReport_Click);
            // 
            // labelAccounting
            // 
            this.labelAccounting.AutoSize = true;
            this.labelAccounting.Location = new System.Drawing.Point(9, 34);
            this.labelAccounting.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelAccounting.Name = "labelAccounting";
            this.labelAccounting.Size = new System.Drawing.Size(115, 20);
            this.labelAccounting.TabIndex = 21;
            this.labelAccounting.Text = "Номер заявки";
            // 
            // textBoxAccountingId
            // 
            this.textBoxAccountingId.Location = new System.Drawing.Point(138, 29);
            this.textBoxAccountingId.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxAccountingId.Name = "textBoxAccountingId";
            this.textBoxAccountingId.Size = new System.Drawing.Size(103, 26);
            this.textBoxAccountingId.TabIndex = 20;
            this.textBoxAccountingId.TextChanged += new System.EventHandler(this.textBoxAccountingId_TextChanged);
            // 
            // checkBoxByDate
            // 
            this.checkBoxByDate.AutoSize = true;
            this.checkBoxByDate.Location = new System.Drawing.Point(448, 97);
            this.checkBoxByDate.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.checkBoxByDate.Name = "checkBoxByDate";
            this.checkBoxByDate.Size = new System.Drawing.Size(95, 24);
            this.checkBoxByDate.TabIndex = 30;
            this.checkBoxByDate.Text = "По дате:";
            this.checkBoxByDate.UseVisualStyleBackColor = true;
            // 
            // checkBoxByNumber
            // 
            this.checkBoxByNumber.AutoSize = true;
            this.checkBoxByNumber.Location = new System.Drawing.Point(448, 134);
            this.checkBoxByNumber.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.checkBoxByNumber.Name = "checkBoxByNumber";
            this.checkBoxByNumber.Size = new System.Drawing.Size(167, 24);
            this.checkBoxByNumber.TabIndex = 26;
            this.checkBoxByNumber.Text = "По номеру заявки:";
            this.checkBoxByNumber.UseVisualStyleBackColor = true;
            // 
            // textBoxToId
            // 
            this.textBoxToId.Location = new System.Drawing.Point(810, 127);
            this.textBoxToId.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxToId.Name = "textBoxToId";
            this.textBoxToId.Size = new System.Drawing.Size(128, 26);
            this.textBoxToId.TabIndex = 29;
            // 
            // labelSplit
            // 
            this.labelSplit.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.labelSplit.AutoSize = true;
            this.labelSplit.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelSplit.Location = new System.Drawing.Point(777, 121);
            this.labelSplit.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelSplit.Name = "labelSplit";
            this.labelSplit.Size = new System.Drawing.Size(16, 24);
            this.labelSplit.TabIndex = 28;
            this.labelSplit.Text = "-";
            // 
            // groupBoxExcelExport
            // 
            this.groupBoxExcelExport.Controls.Add(this.buttonExportToExcel);
            this.groupBoxExcelExport.Controls.Add(this.checkBoxExcelByBatches);
            this.groupBoxExcelExport.Controls.Add(this.checkBoxExcelByRecipes);
            this.groupBoxExcelExport.Controls.Add(this.checkBoxExcelGeneral);
            this.groupBoxExcelExport.Controls.Add(this.radioButtonExcelAll);
            this.groupBoxExcelExport.Controls.Add(this.radioButtonExcelSelected);
            this.groupBoxExcelExport.Location = new System.Drawing.Point(717, 5);
            this.groupBoxExcelExport.Name = "groupBoxExcelExport";
            this.groupBoxExcelExport.Size = new System.Drawing.Size(697, 67);
            this.groupBoxExcelExport.TabIndex = 32;
            this.groupBoxExcelExport.TabStop = false;
            this.groupBoxExcelExport.Text = "Экспорт в Excel";
            // 
            // buttonExportToExcel
            // 
            this.buttonExportToExcel.Location = new System.Drawing.Point(589, 29);
            this.buttonExportToExcel.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.buttonExportToExcel.Name = "buttonExportToExcel";
            this.buttonExportToExcel.Size = new System.Drawing.Size(105, 35);
            this.buttonExportToExcel.TabIndex = 24;
            this.buttonExportToExcel.Text = "Сохранить";
            this.buttonExportToExcel.UseVisualStyleBackColor = true;
            this.buttonExportToExcel.Click += new System.EventHandler(this.buttonExportToExcel_Click);
            // 
            // checkBoxExcelByBatches
            // 
            this.checkBoxExcelByBatches.AutoSize = true;
            this.checkBoxExcelByBatches.Location = new System.Drawing.Point(466, 32);
            this.checkBoxExcelByBatches.Name = "checkBoxExcelByBatches";
            this.checkBoxExcelByBatches.Size = new System.Drawing.Size(117, 24);
            this.checkBoxExcelByBatches.TabIndex = 11;
            this.checkBoxExcelByBatches.Text = "По отвесам";
            this.checkBoxExcelByBatches.UseVisualStyleBackColor = true;
            this.checkBoxExcelByBatches.CheckedChanged += new System.EventHandler(this.checkBoxExcelByBatches_CheckedChanged);
            // 
            // checkBoxExcelByRecipes
            // 
            this.checkBoxExcelByRecipes.AutoSize = true;
            this.checkBoxExcelByRecipes.Location = new System.Drawing.Point(333, 32);
            this.checkBoxExcelByRecipes.Name = "checkBoxExcelByRecipes";
            this.checkBoxExcelByRecipes.Size = new System.Drawing.Size(127, 24);
            this.checkBoxExcelByRecipes.TabIndex = 10;
            this.checkBoxExcelByRecipes.Text = "По рецептам";
            this.checkBoxExcelByRecipes.UseVisualStyleBackColor = true;
            this.checkBoxExcelByRecipes.CheckedChanged += new System.EventHandler(this.checkBoxExcelByRecipes_CheckedChanged);
            // 
            // checkBoxExcelGeneral
            // 
            this.checkBoxExcelGeneral.AutoSize = true;
            this.checkBoxExcelGeneral.Location = new System.Drawing.Point(247, 32);
            this.checkBoxExcelGeneral.Name = "checkBoxExcelGeneral";
            this.checkBoxExcelGeneral.Size = new System.Drawing.Size(80, 24);
            this.checkBoxExcelGeneral.TabIndex = 9;
            this.checkBoxExcelGeneral.Text = "Общий";
            this.checkBoxExcelGeneral.UseVisualStyleBackColor = true;
            this.checkBoxExcelGeneral.CheckedChanged += new System.EventHandler(this.checkBoxExcelGeneral_CheckedChanged);
            // 
            // radioButtonExcelAll
            // 
            this.radioButtonExcelAll.AutoSize = true;
            this.radioButtonExcelAll.Dock = System.Windows.Forms.DockStyle.Left;
            this.radioButtonExcelAll.Location = new System.Drawing.Point(185, 22);
            this.radioButtonExcelAll.Name = "radioButtonExcelAll";
            this.radioButtonExcelAll.Size = new System.Drawing.Size(55, 42);
            this.radioButtonExcelAll.TabIndex = 7;
            this.radioButtonExcelAll.TabStop = true;
            this.radioButtonExcelAll.Text = "Все";
            this.radioButtonExcelAll.UseVisualStyleBackColor = true;
            // 
            // radioButtonExcelSelected
            // 
            this.radioButtonExcelSelected.AutoSize = true;
            this.radioButtonExcelSelected.Dock = System.Windows.Forms.DockStyle.Left;
            this.radioButtonExcelSelected.Location = new System.Drawing.Point(3, 22);
            this.radioButtonExcelSelected.Name = "radioButtonExcelSelected";
            this.radioButtonExcelSelected.Size = new System.Drawing.Size(182, 42);
            this.radioButtonExcelSelected.TabIndex = 8;
            this.radioButtonExcelSelected.TabStop = true;
            this.radioButtonExcelSelected.Text = "Только выделенные";
            this.radioButtonExcelSelected.UseVisualStyleBackColor = true;
            // 
            // textBoxFromId
            // 
            this.textBoxFromId.Location = new System.Drawing.Point(640, 128);
            this.textBoxFromId.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxFromId.Name = "textBoxFromId";
            this.textBoxFromId.Size = new System.Drawing.Size(127, 26);
            this.textBoxFromId.TabIndex = 27;
            // 
            // dateTimePickerFrom
            // 
            this.dateTimePickerFrom.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.dateTimePickerFrom.Location = new System.Drawing.Point(640, 100);
            this.dateTimePickerFrom.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.dateTimePickerFrom.Name = "dateTimePickerFrom";
            this.dateTimePickerFrom.Size = new System.Drawing.Size(298, 26);
            this.dateTimePickerFrom.TabIndex = 23;
            // 
            // label10
            // 
            this.label10.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label10.Location = new System.Drawing.Point(950, 107);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(19, 13);
            this.label10.TabIndex = 24;
            this.label10.Text = "по";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // dateTimePickerTo
            // 
            this.dateTimePickerTo.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.dateTimePickerTo.Location = new System.Drawing.Point(987, 100);
            this.dateTimePickerTo.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.dateTimePickerTo.Name = "dateTimePickerTo";
            this.dateTimePickerTo.Size = new System.Drawing.Size(298, 26);
            this.dateTimePickerTo.TabIndex = 25;
            // 
            // groupBoxReportStatus
            // 
            this.groupBoxReportStatus.Controls.Add(this.checkBoxReportInProgress);
            this.groupBoxReportStatus.Controls.Add(this.checkBoxReportAll);
            this.groupBoxReportStatus.Controls.Add(this.checkBoxReportError);
            this.groupBoxReportStatus.Controls.Add(this.checkBoxReportNotFinished);
            this.groupBoxReportStatus.Controls.Add(this.checkBoxReportFinished);
            this.groupBoxReportStatus.Location = new System.Drawing.Point(6, 70);
            this.groupBoxReportStatus.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBoxReportStatus.Name = "groupBoxReportStatus";
            this.groupBoxReportStatus.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBoxReportStatus.Size = new System.Drawing.Size(434, 98);
            this.groupBoxReportStatus.TabIndex = 18;
            this.groupBoxReportStatus.TabStop = false;
            this.groupBoxReportStatus.Text = "Статус";
            // 
            // checkBoxReportInProgress
            // 
            this.checkBoxReportInProgress.AutoSize = true;
            this.checkBoxReportInProgress.Location = new System.Drawing.Point(226, 65);
            this.checkBoxReportInProgress.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.checkBoxReportInProgress.Name = "checkBoxReportInProgress";
            this.checkBoxReportInProgress.Size = new System.Drawing.Size(97, 24);
            this.checkBoxReportInProgress.TabIndex = 19;
            this.checkBoxReportInProgress.Text = "В работе";
            this.checkBoxReportInProgress.UseVisualStyleBackColor = true;
            // 
            // checkBoxReportAll
            // 
            this.checkBoxReportAll.AutoSize = true;
            this.checkBoxReportAll.Location = new System.Drawing.Point(363, 29);
            this.checkBoxReportAll.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.checkBoxReportAll.Name = "checkBoxReportAll";
            this.checkBoxReportAll.Size = new System.Drawing.Size(56, 24);
            this.checkBoxReportAll.TabIndex = 18;
            this.checkBoxReportAll.Text = "Все";
            this.checkBoxReportAll.UseVisualStyleBackColor = true;
            this.checkBoxReportAll.CheckedChanged += new System.EventHandler(this.checkBoxReportAll_CheckedChanged);
            // 
            // checkBoxReportError
            // 
            this.checkBoxReportError.AutoSize = true;
            this.checkBoxReportError.Location = new System.Drawing.Point(10, 66);
            this.checkBoxReportError.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.checkBoxReportError.Name = "checkBoxReportError";
            this.checkBoxReportError.Size = new System.Drawing.Size(193, 24);
            this.checkBoxReportError.TabIndex = 2;
            this.checkBoxReportError.Text = "Завершены аварийно";
            this.checkBoxReportError.UseVisualStyleBackColor = true;
            // 
            // checkBoxReportNotFinished
            // 
            this.checkBoxReportNotFinished.AutoSize = true;
            this.checkBoxReportNotFinished.Location = new System.Drawing.Point(10, 29);
            this.checkBoxReportNotFinished.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.checkBoxReportNotFinished.Name = "checkBoxReportNotFinished";
            this.checkBoxReportNotFinished.Size = new System.Drawing.Size(198, 24);
            this.checkBoxReportNotFinished.TabIndex = 1;
            this.checkBoxReportNotFinished.Text = "Ожидают выполнения";
            this.checkBoxReportNotFinished.UseVisualStyleBackColor = true;
            // 
            // checkBoxReportFinished
            // 
            this.checkBoxReportFinished.AutoSize = true;
            this.checkBoxReportFinished.Location = new System.Drawing.Point(226, 29);
            this.checkBoxReportFinished.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.checkBoxReportFinished.Name = "checkBoxReportFinished";
            this.checkBoxReportFinished.Size = new System.Drawing.Size(117, 24);
            this.checkBoxReportFinished.TabIndex = 0;
            this.checkBoxReportFinished.Text = "Завершены";
            this.checkBoxReportFinished.UseVisualStyleBackColor = true;
            // 
            // buttonRefreshReport
            // 
            this.buttonRefreshReport.Location = new System.Drawing.Point(4, 5);
            this.buttonRefreshReport.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.buttonRefreshReport.Name = "buttonRefreshReport";
            this.buttonRefreshReport.Size = new System.Drawing.Size(170, 35);
            this.buttonRefreshReport.TabIndex = 3;
            this.buttonRefreshReport.Text = "Обновить";
            this.buttonRefreshReport.UseVisualStyleBackColor = true;
            this.buttonRefreshReport.Click += new System.EventHandler(this.buttonRefreshReport_Click);
            // 
            // dataGridViewReport
            // 
            this.dataGridViewReport.AllowUserToAddRows = false;
            this.dataGridViewReport.AllowUserToDeleteRows = false;
            this.dataGridViewReport.AllowUserToResizeRows = false;
            this.dataGridViewReport.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewReport.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCellsExceptHeaders;
            this.dataGridViewReport.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewReport.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridViewReport.Location = new System.Drawing.Point(4, 213);
            this.dataGridViewReport.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.dataGridViewReport.Name = "dataGridViewReport";
            this.dataGridViewReport.ReadOnly = true;
            this.dataGridViewReport.RowHeadersVisible = false;
            this.dataGridViewReport.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewReport.Size = new System.Drawing.Size(1776, 393);
            this.dataGridViewReport.TabIndex = 4;
            this.dataGridViewReport.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewReport_CellDoubleClick);
            // 
            // flowLayoutPanel3
            // 
            this.flowLayoutPanel3.Controls.Add(this.buttonSaveTo);
            this.flowLayoutPanel3.Controls.Add(this.buttonReportPrint);
            this.flowLayoutPanel3.Controls.Add(this.checkBoxDetailedReport);
            this.flowLayoutPanel3.Controls.Add(this.checkBoxTechnological);
            this.flowLayoutPanel3.Controls.Add(this.radioButtonReportSelectorAll);
            this.flowLayoutPanel3.Controls.Add(this.radioButtonReportSelectorOnlySelected);
            this.flowLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel3.Location = new System.Drawing.Point(4, 616);
            this.flowLayoutPanel3.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.flowLayoutPanel3.Name = "flowLayoutPanel3";
            this.flowLayoutPanel3.Size = new System.Drawing.Size(1776, 44);
            this.flowLayoutPanel3.TabIndex = 5;
            // 
            // buttonSaveTo
            // 
            this.buttonSaveTo.Location = new System.Drawing.Point(4, 5);
            this.buttonSaveTo.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.buttonSaveTo.Name = "buttonSaveTo";
            this.buttonSaveTo.Size = new System.Drawing.Size(170, 35);
            this.buttonSaveTo.TabIndex = 0;
            this.buttonSaveTo.Text = "Сохранить";
            this.buttonSaveTo.UseVisualStyleBackColor = true;
            this.buttonSaveTo.Click += new System.EventHandler(this.buttonSaveTo_Click);
            // 
            // buttonReportPrint
            // 
            this.buttonReportPrint.Location = new System.Drawing.Point(182, 5);
            this.buttonReportPrint.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.buttonReportPrint.Name = "buttonReportPrint";
            this.buttonReportPrint.Size = new System.Drawing.Size(159, 35);
            this.buttonReportPrint.TabIndex = 2;
            this.buttonReportPrint.Text = "Печать";
            this.buttonReportPrint.UseVisualStyleBackColor = true;
            this.buttonReportPrint.Click += new System.EventHandler(this.buttonReportPrint_Click);
            // 
            // checkBoxDetailedReport
            // 
            this.checkBoxDetailedReport.AutoSize = true;
            this.checkBoxDetailedReport.Location = new System.Drawing.Point(349, 11);
            this.checkBoxDetailedReport.Margin = new System.Windows.Forms.Padding(4, 11, 4, 5);
            this.checkBoxDetailedReport.Name = "checkBoxDetailedReport";
            this.checkBoxDetailedReport.Size = new System.Drawing.Size(116, 24);
            this.checkBoxDetailedReport.TabIndex = 4;
            this.checkBoxDetailedReport.Text = "Подробный";
            this.checkBoxDetailedReport.UseVisualStyleBackColor = true;
            this.checkBoxDetailedReport.CheckedChanged += new System.EventHandler(this.checkBoxDetailedReport_CheckedChanged);
            // 
            // radioButtonReportSelectorAll
            // 
            this.radioButtonReportSelectorAll.AutoSize = true;
            this.radioButtonReportSelectorAll.Dock = System.Windows.Forms.DockStyle.Left;
            this.radioButtonReportSelectorAll.Location = new System.Drawing.Point(638, 3);
            this.radioButtonReportSelectorAll.Name = "radioButtonReportSelectorAll";
            this.radioButtonReportSelectorAll.Size = new System.Drawing.Size(55, 39);
            this.radioButtonReportSelectorAll.TabIndex = 5;
            this.radioButtonReportSelectorAll.TabStop = true;
            this.radioButtonReportSelectorAll.Text = "Все";
            this.radioButtonReportSelectorAll.UseVisualStyleBackColor = true;
            // 
            // radioButtonReportSelectorOnlySelected
            // 
            this.radioButtonReportSelectorOnlySelected.AutoSize = true;
            this.radioButtonReportSelectorOnlySelected.Dock = System.Windows.Forms.DockStyle.Left;
            this.radioButtonReportSelectorOnlySelected.Location = new System.Drawing.Point(699, 3);
            this.radioButtonReportSelectorOnlySelected.Name = "radioButtonReportSelectorOnlySelected";
            this.radioButtonReportSelectorOnlySelected.Size = new System.Drawing.Size(182, 39);
            this.radioButtonReportSelectorOnlySelected.TabIndex = 6;
            this.radioButtonReportSelectorOnlySelected.TabStop = true;
            this.radioButtonReportSelectorOnlySelected.Text = "Только выделенные";
            this.radioButtonReportSelectorOnlySelected.UseVisualStyleBackColor = true;
            // 
            // checkBoxTechnological
            // 
            this.checkBoxTechnological.AutoSize = true;
            this.checkBoxTechnological.Location = new System.Drawing.Point(473, 11);
            this.checkBoxTechnological.Margin = new System.Windows.Forms.Padding(4, 11, 4, 5);
            this.checkBoxTechnological.Name = "checkBoxTechnological";
            this.checkBoxTechnological.Size = new System.Drawing.Size(158, 24);
            this.checkBoxTechnological.TabIndex = 7;
            this.checkBoxTechnological.Text = "Технологический";
            this.checkBoxTechnological.UseVisualStyleBackColor = true;
            this.checkBoxTechnological.CheckedChanged += new System.EventHandler(this.checkBoxTechnological_CheckedChanged);
            // 
            // MainView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.tabControlIngredients);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "MainView";
            this.Size = new System.Drawing.Size(1800, 708);
            this.VisibleChanged += new System.EventHandler(this.MainView_VisibleChanged);
            this.Click += new System.EventHandler(this.MainView_Click);
            this.Validated += new System.EventHandler(this.MainView_Validated);
            this.tabPagePortion.ResumeLayout(false);
            this.tableLayoutPanelVPMain.ResumeLayout(false);
            this.tableLayoutPanelVPMain.PerformLayout();
            this.tableLayoutPanelWeights.ResumeLayout(false);
            this.groupBoxVP150.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewVP150)).EndInit();
            this.groupBoxVP502.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewVP502)).EndInit();
            this.groupBoxVP503.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewVP503)).EndInit();
            this.groupBoxVP501.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewVP501)).EndInit();
            this.panelVpControls.ResumeLayout(false);
            this.panelVpControls.PerformLayout();
            this.groupBoxVPTimeSelect.ResumeLayout(false);
            this.flowLayoutPanelSelectByTime.ResumeLayout(false);
            this.flowLayoutPanelSelectByTime.PerformLayout();
            this.groupBoxVpReport.ResumeLayout(false);
            this.flowLayoutPanel4.ResumeLayout(false);
            this.flowLayoutPanel4.PerformLayout();
            this.groupBoxVPPeriod.ResumeLayout(false);
            this.flowLayoutPanel2.ResumeLayout(false);
            this.flowLayoutPanel2.PerformLayout();
            this.tabPageBunkersCard.ResumeLayout(false);
            this.tableLayoutPanelBunkersCard.ResumeLayout(false);
            this.tableLayoutPanelBunkersCard.PerformLayout();
            this.groupBoxBunkerComment.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.flowLayoutPanelBunkerChange.ResumeLayout(false);
            this.groupBoxBunkersLine2.ResumeLayout(false);
            this.tableLayoutPanelBunkersLine2.ResumeLayout(false);
            this.tableLayoutPanelBunkersLine2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewBunkersW5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewBunkersW4)).EndInit();
            this.groupBoxBunkersLine1.ResumeLayout(false);
            this.tableLayoutPanelLine1.ResumeLayout(false);
            this.tableLayoutPanelLine1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewBunkersW6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewBunkersW2)).EndInit();
            this.tabPageIngredients.ResumeLayout(false);
            this.tableLayoutPanelIngredients.ResumeLayout(false);
            this.tableLayoutPanelIngredients.PerformLayout();
            this.groupBoxIngredient.ResumeLayout(false);
            this.panelIngredientAdd.ResumeLayout(false);
            this.panelIngredientAdd.PerformLayout();
            this.flowLayoutPanelIngredientsButtons.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewIngredients)).EndInit();
            this.tabPageRecipe.ResumeLayout(false);
            this.tableLayoutPanelVerticalSplit.ResumeLayout(false);
            this.tableLayoutPanelRecipes.ResumeLayout(false);
            this.tableLayoutPanelLeftData.ResumeLayout(false);
            this.tableLayoutPanelLeftData.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewCurrentRecipes)).EndInit();
            this.groupBoxCurrentPeriod.ResumeLayout(false);
            this.flowLayoutPanel1.ResumeLayout(false);
            this.flowLayoutPanel1.PerformLayout();
            this.tableLayoutPanelRightData.ResumeLayout(false);
            this.tableLayoutPanelRightData.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewRecipe)).EndInit();
            this.panel1.ResumeLayout(false);
            this.flowLayoutPanelButtons.ResumeLayout(false);
            this.groupBoxAddButtons.ResumeLayout(false);
            this.groupBoxRecipeControl.ResumeLayout(false);
            this.groupBoxConsumption.ResumeLayout(false);
            this.tabControlIngredients.ResumeLayout(false);
            this.tabPageReport.ResumeLayout(false);
            this.tableLayoutPanelReport.ResumeLayout(false);
            this.tableLayoutPanelReport.PerformLayout();
            this.panelReportControls.ResumeLayout(false);
            this.panelReportControls.PerformLayout();
            this.groupBoxAccounting.ResumeLayout(false);
            this.groupBoxAccounting.PerformLayout();
            this.groupBoxExcelExport.ResumeLayout(false);
            this.groupBoxExcelExport.PerformLayout();
            this.groupBoxReportStatus.ResumeLayout(false);
            this.groupBoxReportStatus.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewReport)).EndInit();
            this.flowLayoutPanel3.ResumeLayout(false);
            this.flowLayoutPanel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.TabPage tabPagePortion;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelVPMain;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelWeights;
        private System.Windows.Forms.GroupBox groupBoxVP501;
        private System.Windows.Forms.DataGridView dataGridViewVP501;
        private System.Windows.Forms.GroupBox groupBoxVP502;
        private System.Windows.Forms.DataGridView dataGridViewVP502;
        private System.Windows.Forms.GroupBox groupBoxVP503;
        private System.Windows.Forms.DataGridView dataGridViewVP503;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TabPage tabPageBunkersCard;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelBunkersCard;
        private System.Windows.Forms.GroupBox groupBoxBunkerComment;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button buttonBunkChangeCommOk;
        private System.Windows.Forms.Button buttonBunkerCancel;
        private System.Windows.Forms.TextBox textBoxBunkerComment;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label labelBunkerNumber;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanelBunkerChange;
        private System.Windows.Forms.Button buttonBunkerChangeComment;
        private System.Windows.Forms.Label labelBunkersCard;
        private System.Windows.Forms.GroupBox groupBoxBunkersLine1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelLine1;
        private System.Windows.Forms.DataGridView dataGridViewBunkersW2;
        private System.Windows.Forms.Label labelW2;
        private System.Windows.Forms.DataGridView dataGridViewBunkersW6;
        private System.Windows.Forms.Label labelW6;
        private System.Windows.Forms.TabPage tabPageIngredients;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelIngredients;
        private System.Windows.Forms.Label labelIngredients;
        private System.Windows.Forms.GroupBox groupBoxIngredient;
        private System.Windows.Forms.Panel panelIngredientAdd;
        private System.Windows.Forms.Button buttonIngredientOk;
        private System.Windows.Forms.Button buttonIngredientCancel;
        private System.Windows.Forms.TextBox textBoxIngredientComment;
        private System.Windows.Forms.TextBox textBoxIngredientName;
        private System.Windows.Forms.Label labelIngredientComment;
        private System.Windows.Forms.Label labelIngredientName;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanelIngredientsButtons;
        private System.Windows.Forms.Button buttonAddIngredient;
        private System.Windows.Forms.Button buttonUpdateIngredient;
        private System.Windows.Forms.Button buttonDeleteIngredient;
        private System.Windows.Forms.DataGridView dataGridViewIngredients;
        private System.Windows.Forms.TabPage tabPageRecipe;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelVerticalSplit;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelRecipes;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelLeftData;
        private System.Windows.Forms.Label labelRecipe;
        private System.Windows.Forms.DataGridView dataGridViewCurrentRecipes;
        private System.Windows.Forms.GroupBox groupBoxCurrentPeriod;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.RadioButton radioButtonCurrentAllTime;
        private System.Windows.Forms.RadioButton radioButtonCurrentYear;
        private System.Windows.Forms.RadioButton radioButtonCurrentMonth;
        private System.Windows.Forms.RadioButton radioButtonCurrentWeek;
        private System.Windows.Forms.RadioButton radioButtonCurrentById;
        private System.Windows.Forms.TextBox textBoxCurrentId;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelRightData;
        private System.Windows.Forms.Label labelOneRecipe;
        private System.Windows.Forms.DataGridView dataGridViewRecipe;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanelButtons;
        private System.Windows.Forms.GroupBox groupBoxAddButtons;
        private System.Windows.Forms.Button buttonAddImport;
        private System.Windows.Forms.Button buttonAddByTemplate;
        private System.Windows.Forms.Button buttonAdd;
        private System.Windows.Forms.Button buttonGoToWork;
        private System.Windows.Forms.Button buttonCloseCurrent;
        private System.Windows.Forms.Button buttonDeleteRecipe;
        private System.Windows.Forms.GroupBox groupBoxConsumption;
        private System.Windows.Forms.Button buttonConsumptionFile;
        private System.Windows.Forms.Button buttonConsumptionPrint;
        private System.Windows.Forms.TabControl tabControlIngredients;
        private System.Windows.Forms.TabPage tabPageReport;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelReport;
        private System.Windows.Forms.Label labelReport;
        private System.Windows.Forms.GroupBox groupBoxBunkersLine2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelBunkersLine2;
        private System.Windows.Forms.Label labelW5;
        private System.Windows.Forms.Label labelW4;
        private System.Windows.Forms.DataGridView dataGridViewBunkersW4;
        private System.Windows.Forms.DataGridView dataGridViewBunkersW5;
        private System.Windows.Forms.Panel panelReportControls;
        private System.Windows.Forms.DataGridView dataGridViewReport;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel3;
        private System.Windows.Forms.Button buttonSaveTo;
        private System.Windows.Forms.Button buttonReportPrint;
        private System.Windows.Forms.CheckBox checkBoxByDate;
        private System.Windows.Forms.CheckBox checkBoxByNumber;
        private System.Windows.Forms.TextBox textBoxToId;
        private System.Windows.Forms.Label labelSplit;
        private System.Windows.Forms.TextBox textBoxFromId;
        private System.Windows.Forms.DateTimePicker dateTimePickerFrom;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.DateTimePicker dateTimePickerTo;
        private System.Windows.Forms.GroupBox groupBoxReportStatus;
        private System.Windows.Forms.CheckBox checkBoxReportInProgress;
        private System.Windows.Forms.CheckBox checkBoxReportAll;
        private System.Windows.Forms.CheckBox checkBoxReportError;
        private System.Windows.Forms.CheckBox checkBoxReportNotFinished;
        private System.Windows.Forms.CheckBox checkBoxReportFinished;
        private System.Windows.Forms.CheckBox checkBoxDetailedReport;
        private System.Windows.Forms.Button buttonRefreshReport;
        private System.Windows.Forms.GroupBox groupBoxAccounting;
        private System.Windows.Forms.Button buttonPrintAccounting;
        private System.Windows.Forms.Button buttonCreateAccountingReport;
        private System.Windows.Forms.Label labelAccounting;
        private System.Windows.Forms.TextBox textBoxAccountingId;
        private System.Windows.Forms.Panel panelVpControls;
        private System.Windows.Forms.GroupBox groupBoxVpReport;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel4;
        private System.Windows.Forms.Button buttonReportVpPrint;
        private System.Windows.Forms.Button buttonReportVpSave;
        private System.Windows.Forms.GroupBox groupBoxVPPeriod;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel2;
        private System.Windows.Forms.RadioButton radioButtonVPAllTime;
        private System.Windows.Forms.RadioButton radioButtonVPYear;
        private System.Windows.Forms.RadioButton radioButtonVPMonth;
        private System.Windows.Forms.RadioButton radioButtonVPWeek;
        private System.Windows.Forms.CheckBox checkBoxVP150Details;
        private System.Windows.Forms.BindingSource bindingSource1;
        private System.Windows.Forms.RadioButton radioButtonReportVp150;
        private System.Windows.Forms.RadioButton radioButtonReportVp501;
        private System.Windows.Forms.RadioButton radioButtonReportVp502;
        private System.Windows.Forms.RadioButton radioButtonReportVp503;
        private System.Windows.Forms.GroupBox groupBoxRecipeControl;
        private System.Windows.Forms.Button buttonSwapBunkers;
        private System.Windows.Forms.Button buttonSkipBunker;
        private System.Windows.Forms.Button buttonStartRecipe;
        private System.Windows.Forms.Button buttonRecipeCloseOper;
        private System.Windows.Forms.GroupBox groupBoxVPTimeSelect;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanelSelectByTime;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DateTimePicker dateTimePickerReportDateFrom;
        private System.Windows.Forms.DateTimePicker dateTimePickerReportTimeFrom;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button buttonReportSelectByTime;
        private System.Windows.Forms.DateTimePicker dateTimePickerReportDateTo;
        private System.Windows.Forms.DateTimePicker dateTimePickerReportTimeTo;
        private System.Windows.Forms.CheckBox checkBoxVPDetailedShow;
        private System.Windows.Forms.CheckBox checkBoxVPShowEnabled;
        private System.Windows.Forms.GroupBox groupBoxVP150;
        private System.Windows.Forms.DataGridView dataGridViewVP150;
        private System.Windows.Forms.Button buttonPrintRepMainView;
        private System.Windows.Forms.RadioButton radioButtonReportSelectorAll;
        private System.Windows.Forms.RadioButton radioButtonReportSelectorOnlySelected;
        private System.Windows.Forms.GroupBox groupBoxExcelExport;
        private System.Windows.Forms.CheckBox checkBoxExcelGeneral;
        private System.Windows.Forms.RadioButton radioButtonExcelAll;
        private System.Windows.Forms.RadioButton radioButtonExcelSelected;
        private System.Windows.Forms.Button buttonExportToExcel;
        private System.Windows.Forms.CheckBox checkBoxExcelByBatches;
        private System.Windows.Forms.CheckBox checkBoxExcelByRecipes;
        private System.Windows.Forms.CheckBox checkBoxTechnological;

    }
}
