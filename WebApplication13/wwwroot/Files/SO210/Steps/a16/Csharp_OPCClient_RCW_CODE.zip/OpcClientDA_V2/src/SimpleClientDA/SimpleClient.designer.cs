namespace Siemens.Opc.DaClient
{
    partial class SimpleClientDA
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnConnect = new System.Windows.Forms.Button();
            this.txtServerUrl = new System.Windows.Forms.TextBox();
            this.txtItemID1 = new System.Windows.Forms.TextBox();
            this.txtItemID2 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtMonitor2 = new System.Windows.Forms.TextBox();
            this.txtWrite2 = new System.Windows.Forms.TextBox();
            this.txtWrite1 = new System.Windows.Forms.TextBox();
            this.txtMonitor1 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtRead1 = new System.Windows.Forms.TextBox();
            this.txtRead2 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.btnWrite = new System.Windows.Forms.Button();
            this.btnMonitor = new System.Windows.Forms.Button();
            this.btnRead = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.grpBoxBlockRead = new System.Windows.Forms.GroupBox();
            this.txtMonitorBlock = new System.Windows.Forms.RichTextBox();
            this.btnMonitorBlock = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.txtItemIDBlockRead = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.grpBoxBlockWrite = new System.Windows.Forms.GroupBox();
            this.label11 = new System.Windows.Forms.Label();
            this.btnWriteBlock2 = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.btnWriteBlock1 = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.txtWriteBlockLength = new System.Windows.Forms.TextBox();
            this.txtItemIDBlockWrite = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.radioBtn300 = new System.Windows.Forms.RadioButton();
            this.radioBtn1200 = new System.Windows.Forms.RadioButton();
            this.tableLayoutPanel1.SuspendLayout();
            this.grpBoxBlockRead.SuspendLayout();
            this.grpBoxBlockWrite.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnConnect
            // 
            this.btnConnect.AutoSize = true;
            this.btnConnect.Location = new System.Drawing.Point(12, 12);
            this.btnConnect.Name = "btnConnect";
            this.btnConnect.Size = new System.Drawing.Size(75, 23);
            this.btnConnect.TabIndex = 4;
            this.btnConnect.Text = "Connect";
            this.btnConnect.UseVisualStyleBackColor = true;
            this.btnConnect.Click += new System.EventHandler(this.btnConnect_Click);
            // 
            // txtServerUrl
            // 
            this.txtServerUrl.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtServerUrl.Location = new System.Drawing.Point(93, 14);
            this.txtServerUrl.Name = "txtServerUrl";
            this.txtServerUrl.Size = new System.Drawing.Size(678, 20);
            this.txtServerUrl.TabIndex = 5;
            // 
            // txtItemID1
            // 
            this.txtItemID1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtItemID1.Location = new System.Drawing.Point(3, 28);
            this.txtItemID1.Name = "txtItemID1";
            this.txtItemID1.Size = new System.Drawing.Size(166, 20);
            this.txtItemID1.TabIndex = 6;
            // 
            // txtItemID2
            // 
            this.txtItemID2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtItemID2.Location = new System.Drawing.Point(3, 53);
            this.txtItemID2.Name = "txtItemID2";
            this.txtItemID2.Size = new System.Drawing.Size(166, 20);
            this.txtItemID2.TabIndex = 7;
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(235, 6);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(166, 13);
            this.label3.TabIndex = 10;
            this.label3.Text = "Monitored Value";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(3, 6);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(38, 13);
            this.label4.TabIndex = 11;
            this.label4.Text = "ItemID";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtMonitor2
            // 
            this.txtMonitor2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtMonitor2.Location = new System.Drawing.Point(235, 53);
            this.txtMonitor2.Name = "txtMonitor2";
            this.txtMonitor2.Size = new System.Drawing.Size(166, 20);
            this.txtMonitor2.TabIndex = 12;
            // 
            // txtWrite2
            // 
            this.txtWrite2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtWrite2.Location = new System.Drawing.Point(699, 53);
            this.txtWrite2.Name = "txtWrite2";
            this.txtWrite2.Size = new System.Drawing.Size(169, 20);
            this.txtWrite2.TabIndex = 13;
            // 
            // txtWrite1
            // 
            this.txtWrite1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtWrite1.Location = new System.Drawing.Point(699, 28);
            this.txtWrite1.Name = "txtWrite1";
            this.txtWrite1.Size = new System.Drawing.Size(169, 20);
            this.txtWrite1.TabIndex = 14;
            // 
            // txtMonitor1
            // 
            this.txtMonitor1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtMonitor1.Location = new System.Drawing.Point(235, 28);
            this.txtMonitor1.Name = "txtMonitor1";
            this.txtMonitor1.Size = new System.Drawing.Size(166, 20);
            this.txtMonitor1.TabIndex = 15;
            // 
            // label5
            // 
            this.label5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(699, 6);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(169, 13);
            this.label5.TabIndex = 16;
            this.label5.Text = "Write Value";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtRead1
            // 
            this.txtRead1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtRead1.Location = new System.Drawing.Point(467, 28);
            this.txtRead1.Name = "txtRead1";
            this.txtRead1.Size = new System.Drawing.Size(166, 20);
            this.txtRead1.TabIndex = 19;
            // 
            // txtRead2
            // 
            this.txtRead2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtRead2.Location = new System.Drawing.Point(467, 53);
            this.txtRead2.Name = "txtRead2";
            this.txtRead2.Size = new System.Drawing.Size(166, 20);
            this.txtRead2.TabIndex = 18;
            // 
            // label6
            // 
            this.label6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(467, 6);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(166, 13);
            this.label6.TabIndex = 17;
            this.label6.Text = "Read Value";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel1.ColumnCount = 7;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 60F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 60F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 60F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.Controls.Add(this.txtWrite2, 6, 2);
            this.tableLayoutPanel1.Controls.Add(this.txtWrite1, 6, 1);
            this.tableLayoutPanel1.Controls.Add(this.txtRead2, 4, 2);
            this.tableLayoutPanel1.Controls.Add(this.txtRead1, 4, 1);
            this.tableLayoutPanel1.Controls.Add(this.txtMonitor2, 2, 2);
            this.tableLayoutPanel1.Controls.Add(this.txtMonitor1, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.label5, 6, 0);
            this.tableLayoutPanel1.Controls.Add(this.label6, 4, 0);
            this.tableLayoutPanel1.Controls.Add(this.txtItemID1, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.txtItemID2, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.label3, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.label4, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.btnWrite, 5, 1);
            this.tableLayoutPanel1.Controls.Add(this.btnMonitor, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.btnRead, 3, 1);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(12, 101);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 3;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(871, 81);
            this.tableLayoutPanel1.TabIndex = 20;
            // 
            // btnWrite
            // 
            this.btnWrite.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btnWrite.Enabled = false;
            this.btnWrite.Location = new System.Drawing.Point(639, 28);
            this.btnWrite.Name = "btnWrite";
            this.tableLayoutPanel1.SetRowSpan(this.btnWrite, 2);
            this.btnWrite.Size = new System.Drawing.Size(54, 45);
            this.btnWrite.TabIndex = 21;
            this.btnWrite.Text = "Write";
            this.btnWrite.UseVisualStyleBackColor = true;
            this.btnWrite.Click += new System.EventHandler(this.btnWrite_Click);
            // 
            // btnMonitor
            // 
            this.btnMonitor.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btnMonitor.Enabled = false;
            this.btnMonitor.Location = new System.Drawing.Point(175, 28);
            this.btnMonitor.Name = "btnMonitor";
            this.tableLayoutPanel1.SetRowSpan(this.btnMonitor, 2);
            this.btnMonitor.Size = new System.Drawing.Size(54, 45);
            this.btnMonitor.TabIndex = 24;
            this.btnMonitor.Text = "Monitor";
            this.btnMonitor.UseVisualStyleBackColor = true;
            this.btnMonitor.Click += new System.EventHandler(this.btnMonitor_Click);
            // 
            // btnRead
            // 
            this.btnRead.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btnRead.Enabled = false;
            this.btnRead.Location = new System.Drawing.Point(407, 28);
            this.btnRead.Name = "btnRead";
            this.tableLayoutPanel1.SetRowSpan(this.btnRead, 2);
            this.btnRead.Size = new System.Drawing.Size(54, 45);
            this.btnRead.TabIndex = 20;
            this.btnRead.Text = "Read";
            this.btnRead.UseVisualStyleBackColor = true;
            this.btnRead.Click += new System.EventHandler(this.btnRead_Click);
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(777, 17);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(106, 13);
            this.label1.TabIndex = 21;
            this.label1.Text = "OPC DA Server URL";
            // 
            // grpBoxBlockRead
            // 
            this.grpBoxBlockRead.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.grpBoxBlockRead.Controls.Add(this.txtMonitorBlock);
            this.grpBoxBlockRead.Controls.Add(this.btnMonitorBlock);
            this.grpBoxBlockRead.Controls.Add(this.button3);
            this.grpBoxBlockRead.Controls.Add(this.txtItemIDBlockRead);
            this.grpBoxBlockRead.Controls.Add(this.label7);
            this.grpBoxBlockRead.Controls.Add(this.label2);
            this.grpBoxBlockRead.Location = new System.Drawing.Point(12, 188);
            this.grpBoxBlockRead.Name = "grpBoxBlockRead";
            this.grpBoxBlockRead.Size = new System.Drawing.Size(871, 173);
            this.grpBoxBlockRead.TabIndex = 22;
            this.grpBoxBlockRead.TabStop = false;
            this.grpBoxBlockRead.Text = "Block Read";
            // 
            // txtMonitorBlock
            // 
            this.txtMonitorBlock.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtMonitorBlock.Location = new System.Drawing.Point(307, 32);
            this.txtMonitorBlock.Name = "txtMonitorBlock";
            this.txtMonitorBlock.ReadOnly = true;
            this.txtMonitorBlock.Size = new System.Drawing.Size(558, 135);
            this.txtMonitorBlock.TabIndex = 18;
            this.txtMonitorBlock.Text = "";
            // 
            // btnMonitorBlock
            // 
            this.btnMonitorBlock.Enabled = false;
            this.btnMonitorBlock.Location = new System.Drawing.Point(218, 32);
            this.btnMonitorBlock.Name = "btnMonitorBlock";
            this.btnMonitorBlock.Size = new System.Drawing.Size(83, 23);
            this.btnMonitorBlock.TabIndex = 17;
            this.btnMonitorBlock.Text = "Monitor Block";
            this.btnMonitorBlock.UseVisualStyleBackColor = true;
            this.btnMonitorBlock.Click += new System.EventHandler(this.btnMonitorBlock_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(218, 32);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 17;
            this.button3.Text = "button3";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // txtItemIDBlockRead
            // 
            this.txtItemIDBlockRead.Location = new System.Drawing.Point(9, 32);
            this.txtItemIDBlockRead.Name = "txtItemIDBlockRead";
            this.txtItemIDBlockRead.Size = new System.Drawing.Size(203, 20);
            this.txtItemIDBlockRead.TabIndex = 16;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(388, 16);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(96, 13);
            this.label7.TabIndex = 1;
            this.label7.Text = "Block Read Result";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 16);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(97, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "ItemID Block Read";
            // 
            // grpBoxBlockWrite
            // 
            this.grpBoxBlockWrite.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.grpBoxBlockWrite.Controls.Add(this.label11);
            this.grpBoxBlockWrite.Controls.Add(this.btnWriteBlock2);
            this.grpBoxBlockWrite.Controls.Add(this.label10);
            this.grpBoxBlockWrite.Controls.Add(this.btnWriteBlock1);
            this.grpBoxBlockWrite.Controls.Add(this.label9);
            this.grpBoxBlockWrite.Controls.Add(this.txtWriteBlockLength);
            this.grpBoxBlockWrite.Controls.Add(this.txtItemIDBlockWrite);
            this.grpBoxBlockWrite.Controls.Add(this.label8);
            this.grpBoxBlockWrite.Location = new System.Drawing.Point(12, 367);
            this.grpBoxBlockWrite.Name = "grpBoxBlockWrite";
            this.grpBoxBlockWrite.Size = new System.Drawing.Size(868, 70);
            this.grpBoxBlockWrite.TabIndex = 23;
            this.grpBoxBlockWrite.TabStop = false;
            this.grpBoxBlockWrite.Text = "Block Write";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(761, 35);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(104, 13);
            this.label11.TabIndex = 23;
            this.label11.Text = "Write [255, 254, ...0]";
            // 
            // btnWriteBlock2
            // 
            this.btnWriteBlock2.Enabled = false;
            this.btnWriteBlock2.Location = new System.Drawing.Point(666, 30);
            this.btnWriteBlock2.Name = "btnWriteBlock2";
            this.btnWriteBlock2.Size = new System.Drawing.Size(89, 23);
            this.btnWriteBlock2.TabIndex = 22;
            this.btnWriteBlock2.Text = "Write Block 2";
            this.btnWriteBlock2.UseVisualStyleBackColor = true;
            this.btnWriteBlock2.Click += new System.EventHandler(this.btnWriteBlock2_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(534, 35);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(101, 13);
            this.label10.TabIndex = 21;
            this.label10.Text = "Write [0, 1, 2 ...255]";
            // 
            // btnWriteBlock1
            // 
            this.btnWriteBlock1.Enabled = false;
            this.btnWriteBlock1.Location = new System.Drawing.Point(439, 30);
            this.btnWriteBlock1.Name = "btnWriteBlock1";
            this.btnWriteBlock1.Size = new System.Drawing.Size(89, 23);
            this.btnWriteBlock1.TabIndex = 20;
            this.btnWriteBlock1.Text = "Write Block 1";
            this.btnWriteBlock1.UseVisualStyleBackColor = true;
            this.btnWriteBlock1.Click += new System.EventHandler(this.btnWriteBlock1_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(282, 35);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(103, 13);
            this.label9.TabIndex = 19;
            this.label9.Text = "Write Length in Byte";
            // 
            // txtWriteBlockLength
            // 
            this.txtWriteBlockLength.Location = new System.Drawing.Point(218, 32);
            this.txtWriteBlockLength.Name = "txtWriteBlockLength";
            this.txtWriteBlockLength.Size = new System.Drawing.Size(58, 20);
            this.txtWriteBlockLength.TabIndex = 18;
            this.txtWriteBlockLength.Text = "4096";
            // 
            // txtItemIDBlockWrite
            // 
            this.txtItemIDBlockWrite.Location = new System.Drawing.Point(6, 32);
            this.txtItemIDBlockWrite.Name = "txtItemIDBlockWrite";
            this.txtItemIDBlockWrite.Size = new System.Drawing.Size(206, 20);
            this.txtItemIDBlockWrite.TabIndex = 18;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(6, 16);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(96, 13);
            this.label8.TabIndex = 17;
            this.label8.Text = "ItemID Block Write";
            // 
            // radioBtn300
            // 
            this.radioBtn300.AutoSize = true;
            this.radioBtn300.Checked = true;
            this.radioBtn300.Location = new System.Drawing.Point(12, 42);
            this.radioBtn300.Name = "radioBtn300";
            this.radioBtn300.Size = new System.Drawing.Size(371, 17);
            this.radioBtn300.TabIndex = 24;
            this.radioBtn300.TabStop = true;
            this.radioBtn300.Text = "S7 300 - using items on an S7 300 device. Block Read / Write is enabled";
            this.radioBtn300.UseVisualStyleBackColor = true;
            this.radioBtn300.CheckedChanged += new System.EventHandler(this.radioBtn_CheckedChanged);
            // 
            // radioBtn1200
            // 
            this.radioBtn1200.AutoSize = true;
            this.radioBtn1200.Location = new System.Drawing.Point(12, 65);
            this.radioBtn1200.Name = "radioBtn1200";
            this.radioBtn1200.Size = new System.Drawing.Size(384, 17);
            this.radioBtn1200.TabIndex = 25;
            this.radioBtn1200.Text = "S7 1200 - using items on an S7 1200 device. Block Read / Write is disabled";
            this.radioBtn1200.UseVisualStyleBackColor = true;
            this.radioBtn1200.CheckedChanged += new System.EventHandler(this.radioBtn_CheckedChanged);
            // 
            // SimpleClientDA
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(895, 449);
            this.Controls.Add(this.radioBtn1200);
            this.Controls.Add(this.radioBtn300);
            this.Controls.Add(this.grpBoxBlockWrite);
            this.Controls.Add(this.grpBoxBlockRead);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.txtServerUrl);
            this.Controls.Add(this.btnConnect);
            this.Name = "SimpleClientDA";
            this.Text = "Simple Client OPC COM DA";
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.grpBoxBlockRead.ResumeLayout(false);
            this.grpBoxBlockRead.PerformLayout();
            this.grpBoxBlockWrite.ResumeLayout(false);
            this.grpBoxBlockWrite.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnConnect;
        private System.Windows.Forms.TextBox txtServerUrl;
        private System.Windows.Forms.TextBox txtItemID1;
        private System.Windows.Forms.TextBox txtItemID2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtMonitor2;
        private System.Windows.Forms.TextBox txtWrite2;
        private System.Windows.Forms.TextBox txtWrite1;
        private System.Windows.Forms.TextBox txtMonitor1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtRead1;
        private System.Windows.Forms.TextBox txtRead2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Button btnWrite;
        private System.Windows.Forms.Button btnRead;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnMonitor;
        private System.Windows.Forms.GroupBox grpBoxBlockRead;
        private System.Windows.Forms.GroupBox grpBoxBlockWrite;
        private System.Windows.Forms.RichTextBox txtMonitorBlock;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.TextBox txtItemIDBlockRead;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnMonitorBlock;
        private System.Windows.Forms.TextBox txtItemIDBlockWrite;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button btnWriteBlock2;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button btnWriteBlock1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtWriteBlockLength;
        private System.Windows.Forms.RadioButton radioBtn300;
        private System.Windows.Forms.RadioButton radioBtn1200;
    }
}

