﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Siemens.Opc.Da
{
    public class ReadResult
    {
    }
}
