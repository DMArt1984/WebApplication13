#ifndef _CONNTBL_H_
#define _CONNTBL_H_

#include <PtrList.hxx>
#include <ConnTblEntry.hxx>

/*  author VERANTWORTUNG: Martin Koller */
/** Connection-Table.
  * Holds the list of pairs (DpIdentList*, CtrlFunc*, DpHLGroups) which are connected.
  * We want to make sure, that one connection will only start one thread at a time.
  * Therefore we have to store new DpHLGroups coming with a CtrlScript::dpValueChanged
  @classification ETM internal
*/
class DLLEXP_CTRL ConnTbl
{
  public:
    bool isEmpty() const { return (list.getNumberOfItems() == 0); }

    ConnTblEntry *getFirstEntry() const
      { return (ConnTblEntry *)(list.getFirst()); }

    ConnTblEntry *getNextEntry(ConnTblEntry *last) const
      { return (ConnTblEntry *)(list.getNext(last)); }

    // insert the new entry but keep sorting: invalid, QUERY_CONN, others
    void insertSorted(ConnTblEntry *entry);

    void remove(ConnTblEntry *entry) { list.remove(entry); }

    void clear() { list.clear(); }

    // mark as invalid if it's busy, else delete it immediately
    void invalidate(ConnTblEntry *entry);

  private:
    PtrList list;
};

#endif /* _CONNTBL_H_ */
