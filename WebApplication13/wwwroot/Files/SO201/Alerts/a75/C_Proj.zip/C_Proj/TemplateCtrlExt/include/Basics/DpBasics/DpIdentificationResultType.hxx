// ========== DpIdentificationResult ============================================================
// Fehlerkode fuer DpIdentification-Funktionen.
// Kann nicht im DpIdentification.hxx stehen - andere Klassen brauchen
// das auch (zyklische Abhaengigkeiten)

#ifndef _DPIDENTIFICATIONRESULTTYPE_H_
#define _DPIDENTIFICATIONRESULTTYPE_H_

/// the return codes for DpIdentification operations
enum DpIdentificationResult {
  /// operation OK
  DpIdentOK,
  /// (1). no more names found
  DpIdentNoMoreNames,
  /// (2). dp name exists
  DpIdentNameExists,
  /// (3). dp id eists
  DpIdentIdExists,
  /// (4). unknown dp name 
  DpIdentNoSuchName,
  /// (5). unknown dp id
  DpIdentNoSuchId,
  /// (6). unknown dp
  DpIdentNoSuchCategory,
  /// (7). wrong name space category
  DpIdentNoSuchConfig,
  /// (8). unknown dp type
  DpIdentNoSuchTypeHere,
  /// (9). unknown dp type
  DpIdentNoSuchTypeInTypeCont,
  /// (10). unknown system identifier
  DpIdentNoSuchSystemHere,
  /// (11). dp identifier has empty fields in between
  DpIdentHolesInIdentifier,
  /// (12). internal type container error
  DpIdentBadTypeCont,
  /// (13). manager has no type container
  DpIdentNoTypeCont,
  /// (14). syntax error
  DpIdentSyntaxError,
  /// (15). syntax error in array index
  DpIdentArrayIndexSyntaxError,
  /// (16). language number not set
  DpIdentLangNoNotSet,
  /// (17). invalid language number
  DpIdentInvalidLanguage,
  /// (18). alias already exists
  DpIdentAliasExists,
  /// (19). no alias found
  DpIdentNoSuchAlias,
  /// (20). no comment found
  DpIdentNoComment,
  /// (21). out of memory
  DpIdentOutOfMemory,
  /// (22). internal identification error
  DpIdentInternalError,
  /// (23). maxDpNamesCount reached
  DpIdentMaxDpNamesCount,
  /// (23). deprecated alias for DpIdentMaxDpNamesCount
  DpIdentTableOverflow = DpIdentMaxDpNamesCount,

  /// (24). no such detail
  DpIdentNoSuchDetail,
  /// (25). no such attribute
  DpIdentNoSuchAttribute,  
  
  /// (26). no common name service
  DpIdentNoCNS,
  /// (27). no such view
  DpIdentNoSuchView,
  /// (28). no such CNSNode
  DpIdentNoSuchCNSNode,
  /// (29). view already exists
  DpIdentViewAlreadyExists,
  /// (30). CNSNode already exists
  DpIdentCNSNodeAlreadyExists,
  
  // change DpIdentification::getErrorMsg if you add
  // result types
  DpIdentNoOfResults    // nr of results
};
#endif /* _DPIDENTIFICATIONRESULTTYPE_H_ */
