#ifndef _NEXTVALIDLISTTIME_H_
#define _NEXTVALIDLISTTIME_H_


// Author:        Heinz Meissl
// Date:          1.5.1997
// Description:   Functor class to retrieve times (TimeVar) meeting certain conditions
//                The conditions are passed as lists. A valid time meets any 
//                possible combination of list entries.
//                Example:
//                  MonthList:    2, 4, 12
//                  MonthDayList: 1, 15
//                  WeekDayList:  2, 7
//                  DayTimeList:  43200
//                Results to the following valid times:
//                  Month:    2      2    2    2    4     4   ...  12  ...
//                  MonthDay: 1      1    15   15   1     1   ...  1   ...
//                  WeekDay:  2      7    2    7    2     7   ...  2   ...
//                  DayTime:  43200  --------------------->   ...  -->
// ---------------------------------------------------------------------------
// Usage:
// 1. Instantiate an object
//    The conditions are set to some default values
// 2. Call setConditions() to change the conditions to be met
//    Impossible conditions are not accepted and False is returned
//    Call the function-operator()() with a time to start the search
//    The search direction is an optional parameter, default is FOREWARD
// ---------------------------------------------------------------------------
// Condition entry value ranges:
// 
// condition:    aMonthList    aMonthDayList      aWeekDayList      aDayTimeList
// VariableType: UINTEGER_VAR  UINTEGER_VAR       UINTEGER_VAR      UINTEGER_VAR
// entry range:    1-12             1-31               1-7             0-86399
// default:        none             none              none               0
//
// none  stands for an empty list and means any value -> that condition is ignored
// 31    as aMonthDay stands for the last day in month
//       (even if the current checked month has less days)
// 1-7 as aWeekDay corresponds to monday to sunday
//
// DayTime is measured in seconds and corresponds to [00:00:00, 23:59:59]. See below! 
// ----------------------------------------------------------------------------
// A feature?!
// This functor works also with daylight saving periods. The seconds given by
// DayTime are directly mapped to a time of 24 hours, even, if a day has more
// or less than 24*3600 = 86400 seconds ( the first and last day of the daylight
// savings period ). For instance: 84600 means always 23:30:00 and 1800 means
// always 00:30:00.
// So, DayTime does not always mean the same as seconds past midnight!
// ----------------------------------------------------------------------------

#ifndef _TIMEVAR_H_
#include <TimeVar.hxx>
#endif

#ifndef _DYNVAR_H_
#include <DynVar.hxx>
#endif

/// Functor class to retrieve times (TimeVar) meeting certain conditions.
/// The conditions are passed as lists. A valid time meets any possible combination of list entries.
/// <p>
/// <b>Usage:</b>
/// <ol>
/// <li> Instantiate an object (the conditions are set to default values)
/// <li> Call setConditions() to change the conditions to be met.
/// @n   Impossible conditions are not accepted and False is returned.
/// <li> Call the TimeVar operator() with a time to start the search.
/// </ol>
///
/// <b>Condition value ranges:</b>
/// <p>aMonthList: 1-12; default: none
/// @n aMonthDayList: 1-31; default: none
/// @n aWeekDayList: 1-7; default: none
/// @n aDayTimeList: 0-86399; default: 0
/// </p>
/// <p>
/// none  stands for an empty list and means any value -> that condition is ignored
/// @n 31 as aMonthDay stands for the last day in month
///       (even if the current checked month has less days)
/// @n 1-7 as aWeekDay corresponds to monday to sunday
/// </p>
/// DayTime is measured in seconds and corresponds to [00:00:00, 23:59:59]. See below!
/// 
/// A feature?!
/// This functor works also with daylight saving periods. The seconds given by
/// DayTime are directly mapped to a time of 24 hours, even, if a day has more
/// or less than 24*3600 = 86400 seconds ( the first and last day of the daylight
/// savings period ). For instance: 84600 means always 23:30:00 and 1800 means
/// always 00:30:00.
/// So, DayTime does not always mean the same as seconds past midnight!
/// @classification ETM internal
class DLLEXP_OABASICS NextValidListTime
{
  public:
    friend class UNIT_TEST_FRIEND_CLASS;
    /// Constructor.
    NextValidListTime();
    
    /// Set the conditions for the search algorithm, if the conditions can't be met,
    /// setCondition returns PVSS_FALSE.
    /// @param aMonthList List of allowed months (1-12).
    /// @param aMonthDayList List of allowed monthdays (1-31).
    /// @param aWeekDayList List of allowed weekdays (1-7).
    /// @param aDayTimeList List of allowed daytimes (0-86399 corresponding to seconds after midnight.
    /// @return PVSS_TRUE if the condition can be met, otherwise PVSS_FALSE.
    PVSSboolean setConditions( const DynVar &aMonthList,
                               const DynVar &aMonthDayList,
                               const DynVar &aWeekDayList,
                               const DynVar &aDayTimeList );
  
    /// Find a time >= startTime that meets the conditions set by setConditions();
    /// @param startTime Starting time.
    /// @return TimeVar with the first time higher than startTime which meets the conditions
    const TimeVar operator()( const TimeVar &startTime );

  protected:

  private:

    /// called by the functor
    const TimeVar getNextValidListTime ( const TimeVar &startTime );

    /// check if the conditions defined by the lists can be met
    PVSSboolean isConditionPossible ( const DynVar &aMonthList,
                                      const DynVar &aMonthDayList,
                                      const DynVar &aWeekDayList,
                                      const DynVar &aDayTimeList );
    
    /// convert weekday to BC_ constants
    void convertToBooch( DynVar &aWeekDay );
    
    /// Find DayTime >= current DayTime given by theTime
    PVSSboolean goNextValidListTime( BC_CTime & theTime );

    /// Find valid Day within Month given by theTime >= current Day of theTime.
    PVSSboolean goNextValidListDay( BC_CTime & theTime );

    /// Find valid Month >= Month of theTime.
    void goNextValidListMonth( BC_CTime & theTime );

    /// List of months as a part of the defined condition (can be empty)
    DynVar condMonthList;

    /// List of monthdays as a part of the defined condition (can be empty)
    DynVar condMonthDayList;

    /// List of weekdays as a part of the defined condition (can be empty)
    DynVar condWeekDayList;

    /// List of daytimes as a part of the defined condition (must have at least one value)
    DynVar condDayTimeList;
};

#endif /* _NEXTVALIDLISTTIME_H_ */
