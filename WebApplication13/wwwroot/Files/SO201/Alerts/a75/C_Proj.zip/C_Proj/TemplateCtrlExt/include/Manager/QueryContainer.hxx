// Base class for storing QueryList objects

#ifndef _QUERYCONTAINER_H_
#define _QUERYCONTAINER_H_

#include <DynPtrArray.hxx>
#include <QueryList.hxx>

#if defined(LIBS_AS_DLL)

#ifdef WIN32
#pragma warning ( disable: 4231 )
#endif
  //COVINFO BLOCK: defensive (AP: not reachable code)
  EXTERN_MANAGER template class DLLEXP_MANAGER DynPtrArray<QueryList>;
  inline DynPtrArrayIndex DynPtrArray<QueryList>::deepCopy(const DynPtrArray<QueryList> &) {return 0;}
  //COVINFO BLOCKEND
#ifdef WIN32
#pragma warning ( default: 4231 )
#endif

#endif


class DLLEXP_MANAGER QueryContainer
{
  public:
  
  QueryContainer();
  ~QueryContainer();
  
  
  DynPtrArrayIndex append(QueryList *ql);
  DynPtrArrayIndex remove(QueryList *ql) {return list.remove(ql);}
  
  // print out current query state
  void reportStatus(std::ostream &, bool summary) const;

  protected:
    DynPtrArray<QueryList> list;
  
  private:
    // so that the compiler does not define them itself !!
    // copy constructor
    QueryContainer(const QueryContainer &) {} //COVINFO LINE: defensive (AP: no copy allowed)
    // assignment operator
    QueryContainer & operator=(const QueryContainer &) { return *this; } //COVINFO LINE: defensive (AP: no assignment allowed)
};

#endif /* _QUERYCONTAINER_H_ */
