#ifndef _HOTLINKWAITFORANSWER_H_
#define _HOTLINKWAITFORANSWER_H_
// DATEIBESCHREIBUNG ==============================================================
// VERANTWORTUNG: Wolfram Klebel (Johannes Ertl)
// BESCHREIBUNG:  Soll ein Call-back bei einer Antwort gemacht werden, so muss man von dieser
//                Klasse ableiten. Die virtuelle Methode callBack wird dann aufgerufen.
//                HotLink-Bearbeitung wurde anlaesslich der Beschleunigung der HotLinks abgeleitet.
// ======================================Ende======================================

#include <WaitForAnswer.hxx>
#include <DpHLGroup.hxx>

class DpMsgAnswer;
class DpMsg;

/** The hotlink callback class. This class is an abstract base class for 
  hotlink messages. It will also handle the answer message received as 
  response on the connect message. It contains callback functions for the
  answer message as well as for hotlink groups.
  @see DpMsgAnswer, DpMsgHotLink
  @classification public use, overload
 */
class DLLEXP_MANAGER HotLinkWaitForAnswer: public WaitForAnswer
{
  public:
    /// constructor
    HotLinkWaitForAnswer(){}
    /// destructor
    virtual ~HotLinkWaitForAnswer(){}

    virtual answerType isA(){ return WaitForAnswer::HOT_LINK_ANSWER; };

    /*  no need to overload this function, because it is never called.
	@classification public do not use
     */
    virtual void callBack(DpMsgAnswer &answer) { hotLinkCallBack(answer); } 

    /** The answer callback function. 
      This function is abstract since this is a base class.
      Use this function by overloading to handle the answer message. 
      You need to overload this class whenever you want to handle answer messages. 
      Objects of this type  are used by the manager to distribute answer messages.
      @param answer the answer message received
      @classification public use, overload
     */
    virtual void hotLinkCallBack(DpMsgAnswer &answer) = 0;

    // virtual void callBack(DpMsgAnswer &answer) { hotLinkCallBack (answer); }
    // Ueberladene Callback-Methode speziell fuer HotLinks nach der Suche im Manager
    virtual void hotLinkCallBack(const DpMsg & /* hlMsg */, DpHLGroup &group)
    {
      hotLinkCallBack(group);
    }

  protected:

    // Ueberladene Callback-Methode speziell fuer HotLinks nach der Suche im Manager
    /** The hotlink callback function. This function is abstract since this is a
      base class. Use this function by overloading to handle hotlink messages.
      As hotlink messages may contain several groups they are split into groups 
      before this function is called. 
      @param group A hotlink group received
      @classification public use, overload
     */
    virtual void hotLinkCallBack(DpHLGroup &group) = 0;
};

#endif /* _HOTLINKWAITFORANSWER_H_ */
