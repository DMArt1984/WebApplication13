#ifndef _CTRLSCRIPT_H_
#define _CTRLSCRIPT_H_

#include <Types.hxx>
#include <PTreeNode.hxx>
#include <ScriptId.hxx>
#include <ConnTbl.hxx>
#include <CtrlThread.hxx>
#include <ExecReturn.hxx>
#include <SplitTbl.hxx>
#include <CtrlVar.hxx>

class CtrlFunc;
class CharString;
class CtrlModule;
class Variable;
class DpHLGroup;
class DpIdentList;
class ExternData;
class DoneCB;
class DpMsgAnswer;
class UserType;
class ClassVar;
class CtrlScriptTrackable;
class TypeAlias;

/*  author Martin Koller */
/** Represents a parsed CTRL script and is the container for all running CTRL threads
    of this script.
*/
class DLLEXP_CTRL CtrlScript : public PTreeNode
{
  public:
    static int compareScriptId(const CtrlScript *item1, const CtrlScript *item2);

    /** constructor.
        holdCData ... are we responsible for the pointer (can we delete it)
        del ......... delete the Script when done (default: keep it)
      */
    CtrlScript(ExternData *cData, PVSSboolean holdCData = PVSS_FALSE, PVSSboolean del = PVSS_FALSE,
        const DynVar &theSubst = DynVar(), int line = -1, int file = -1);

    /// destructor
    virtual ~CtrlScript();

    void appendFunc(CtrlFunc *func, int scriptLineNumber = -1);
    void appendEventFunc(CtrlFunc *func, int scriptLineNumber = -1);

    /// all items in this list will be moved into the own container; the given list is then empty
    void appendGlobals(CtrlVarList *list);

    /// Cut the CtrlVarList object from this script and return it; result can be 0 if there are no globals
    CtrlVarList *cutGlobals();

    /// returns the thread with the given number or a 0-pointer if not found
    CtrlThread *findThread(ThreadId which) const;

    /** starts main()
        @return EXEC_OK if we could start the main() function
        @return EXEC_DONE if we could start the main() function and the
          function was fully executed (every statement executed)
          and there is no connection active
        @return EXEC_ERROR if we could not find the main() function
      */
    ExecReturn start(const Variable *args);

    /** starts a specific function.
        It also searches in the libraries.
        The return-value tells the state of the started function, not the whole script:
        @return EXEC_OK .. the thread of this functions is running
        @return EXEC_DONE .. the function is fully executed and there is no thread for it
        @return EXEC_ERROR .. function not found, etc.
        The DoneCB object is handled by the CtrlScript, so dont delete it
        If you give a DoneCB object, it will call DoneCB::execute(returnVal)
        when the function calls return
      */
    ExecReturn startFunc(const CharString &funcName, const Variable *args, DoneCB *done = 0);

    // as startFunc, but a new thread will be started, if this function has no thread currently running
    void startSingleThreadFunc(const CharString &funcName, const Variable *args, PVSSboolean doExecDone = PVSS_FALSE);

    /** same as startFunc() but also returns the pointer to the newly created thread,
        @return EXEC_OK, otherwise the thread-pointer is 0
      */
    ExecReturn startThread(
            CtrlThread * &t,
            CtrlFunc *func,
      const Variable *args = nullptr,
            DoneCB *done = nullptr,
            ClassVar *object = nullptr);

    ExecReturn startThreadRefParam(
      CtrlThread * &t,
      CtrlFunc *func,
      Variable *args = 0,
      DoneCB *done = 0);

    /** Create a thread but don't start it.
        @return EXEC_OK if the thread was created.
      */
    ExecReturn createThread(CtrlThread *&t, CtrlFunc *func, const Variable *args = 0, DoneCB *done = 0);

    /** removes the given thread from the list of running threads and deletes it.
        the given thread-variable will be set to 0
      */
    void removeThread(CtrlThread * &thread);

    /** connects a new CtrlModule to the CtrlScript.
        The next work() call also calls its work() method
        CtrlModule pointer is handled by CtrlScript (captured and also deleted by this)
      */
    void startModule(CtrlModule *mod);

    /** remove a given CtrlModule from the CtrlScript and delete it
      */
    void removeModule(CtrlModule *mod);

    /** gives the max number of statements to execute to this script.
        this number will be divided through all the threads but is min 1.
        If the argument is 0, the next statement of the first thread will be executed.
        @return EXEC_OK if everything is ok
        @return EXEC_DONE if there is no more thread to execute and there
                is no Dp-Connection active
      */
    ExecReturn work(PVSSlong maxWeight, TimeVar &timeNextWork);

    /** @name Simple Get/Set Functions */
    //@{
    ///
    bool hasThread() const { return (threads || (modules.getNumberOfItems() != 0)); }
    ///
    bool hasConnection() const { return (! conn.isEmpty()); }
    ///
    ScriptId getId() const { return id; }
    ///
    void setId(ScriptId newId) { id = newId; }
    ///
    ExternData *getClientData() const { return clientData; }
    ///
    CtrlFunc *findFunc(const CharString &which) const;
    ///
    Variable *findGlobal(const CharString &which) const;
    /** returns the container of variables of the global namespace
        of the script
    */
    CtrlVar *getGlobalCtrlVar(const CharString &which);
    ///
    CtrlVar *getGlobalCtrlVar(CtrlVarId id);

    CtrlVar *getCtrlVar(const CharString &which);
    CtrlVar *getCtrlVar(CtrlVarId id);

    /// return pointer to associated scopeLib, if there is one; else nullptr
    CtrlScript *getScopeLib() const;

    ///
    void setDelWhenDone(PVSSboolean b) { delWhenDone = b; }
    ///
    PVSSboolean getDelWhenDone() const { return delWhenDone; }
    ///
    CtrlThread *getCurrentThread() {return currentThread;}
    ///
    int getScriptClientData() const {return scriptClientData;}
    //@}

    ThreadId getNextThreadId() const
    {
      return (threadsLast ? threadsLast->getId() + 1 : 0);
    }

    /** @name  connects/disconnects a function
        @internal
     */
    //@{
    bool dpDisconnect(ClassVar *object, CtrlFunc *func, const DpIdentList &dpList,
                      ConnTblEntry::EntryType eType, const Variable *userData);

    bool queryDisconnect(ClassVar *object, CtrlFunc *func, const Variable *userData);

    bool sysDisconnect(ClassVar *object, CtrlFunc *func, const CharString &eventName, const Variable *userData);

    void connect(ConnTblEntry *entry);
    void disconnect(ConnTblEntry *entry);
    //@}

    /// adds a new split table entry for message splitting
    void splitAdd(SplitTblEntry *entry);

    /// removes a split table entry (message splitting)
    void splitRemove(SplitTblEntry *entry);

    /// gets a split table entry (message splitting)
    SplitTblEntry * splitGet(PVSSulong reqId);

    /// split the values from the answer in single values (look at comment in Controller)
    void splitPeriodAnswer(DpMsgAnswer &answer, const DpIdentList &dpList, DoneCB *doneCB);

    /// this starts a new thread on a response-msg coming from dpConnect
    void dpVC(ConnTblEntry *entry, const DpHLGroup &group, DoneCB *doneCB,
              const char * const *dpNames = 0);

    /// this starts a new thread on a response-msg coming from alertConnect
    void alertVC(ConnTblEntry *entry, const AlertAttrList &alert, DoneCB *doneCB);

    /// this starts a new thread on a response-msg coming from dpQueryConnect
    ExecReturn dpQueryVC(ConnTblEntry *entry, const DpHLGroup &group, DoneCB *doneCB, bool cache = false);

    //@internal
    ExecReturn startManagerExitPhase();

    //@internal
    ExecReturn handleSystemEvent(const CharString &eventName, const Variable *args);

    /// disconnects all pending connections
    void disconnectAll();

    /// Semantik check (undefinierte Variablen)
    bool checkIntegrity(CtrlThread *thread = 0, bool strict = false) const;

    /// Remove all running Moduls
    void moduleDisconnectAll();
    CtrlFunc *getCtrlFuncs() const { return funcs; }

    CtrlFunc *getEventFuncs() const { return eventFuncs; }

    // for CtrlDbg this is a goodie
    const CtrlVarList *getGlobals() const { return globals; }
    const CtrlThread *getThreads() const { return threads; }
    const PtrList &getModules() const { return modules; }
    const ConnTbl &getConnTbl() const { return conn; }

    const DynVar &getSubstParam() const {return subst;}

    bool isCoded() const { return m_coded; }
    void setCoded() { m_coded = true;}

    bool isRestrictedMode() const;
    void setRestrictedMode(bool on);

    void setScriptUserId(PVSSuserIdType userId);
    PVSSuserIdType * getScriptUserId() const {return scriptUserId;}

    void setScriptLangId(GlobalLanguageIdType langId);
    GlobalLanguageIdType * getScriptLangId() const {return scriptLangId;}

    void reportStatus(std::ostream &os, const CharString &location) const;

    /** dump the whole tree for code coverage analysis
        @param to output stream
      */
    virtual void dumpCoverageTree(std::ostream &to, CoverageAction action = DUMP) const;

    void addUserType(UserType *type);
    UserType *getUserType(const CharString &name) const;
    UserType *getUserTypes() const;

    void addTypeAlias(TypeAlias *alias);
    TypeAlias *getTypeAlias(const CharString &name) const;
    TypeAlias *getTypeAliases() const;

    // get a trackable object which will be deleted whenever this CtrlScript is deleted
    // @internal
    CtrlScriptTrackable *getTrackableObject() const;

    // initializes all statics variables of classes and global variables
    // @internal
    void initVars();

    // initializes all static variables (in a class)
    // @internal
    void initStatics();

  private:  // methods
    // appends the thread to the list of running threads
    void appendThread(CtrlThread *thread);

    // check the connections
    void checkConnTblEntries(TimeVar &nextWork);

    bool sendDisconnect(ConnTblEntry *entry);
    CtrlThread *createEntryThread(ConnTblEntry *entry, DoneCB *done = 0, const Variable *args = 0);
    ExecReturn runThread(CtrlThread *&t);
    ExecReturn workOnNewThread(CtrlThread *&t);

  private:  // members
    ScriptId id;
    CtrlFunc *funcs;
    CtrlFunc *eventFuncs;  // declared functions which act as a triggerable events (in UI)
    CtrlThread *threads, *threadsLast;
    CtrlThread *currentThread;
    PtrList modules;
    ExternData *clientData;
    PVSSboolean holdClientData;  // are we responsible for this pointer ?
    ConnTbl conn;
    SplitTbl splitTbl;          // message splitting table
    CtrlVarList *globals;       // global variables, script scope
    PVSSlong threadCount;
    PVSSboolean delWhenDone;   // shall this script be deleted when EXEC_DONE
    int scriptClientData;

    DynVar subst;

    bool m_coded;
    PVSSuserIdType *scriptUserId;
    GlobalLanguageIdType *scriptLangId;

    class CtrlScriptPrivate *d;
};


#endif /* _CTRLSCRIPT_H_ */
