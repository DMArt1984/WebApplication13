// DATEIBESCHREIBUNG ==============================================================
// DATEINAME:     DpMsgIdentification.hxx
// VERANTWORTUNG:       WOLFGANG SCHUH + PETER PENTEK
// 
// BESCHREIBUNG:        Ist eine Message, die die Mappings zwischen DpIdentifier und
//              symbolischen Datenpunktidentifizierungen verschickt.
//              
//              Diese Message hat keine Antwort-Message und keine Items.
//
// AENDERUNGS-HISTORIE
// Ver.  | Datum      | Aenderungen                            | ModNr.| Autor
// ------+------------+-----------------Anfang-----------------+-------+-----------
//   1.0 |            | 1.Erstellung mit Westmount-OMT         |     0 |
// ======================================Ende======================================
#ifndef _DPMSGIDENTIFICATION_H_
#define _DPMSGIDENTIFICATION_H_

// Vorwaerts-Deklaration der Eigenen Klasse
class DpMsgIdentification;

// System-Include-Files
#include <DpMsg.hxx>

// Vorwaerts-Deklarationen :
class DpIdentification;
class DpMsgIdentification;
class ManagerIdentifier;
class Msg;

class MappingVar;
class Blob;

// ========== DpMsgIdentification ============================================================
class DLLEXP_MESSAGES DpMsgIdentification : public DpMsg 
{
    friend DLLEXP_MESSAGES itcNdrUbSend &operator<<(itcNdrUbSend &ndrStream, const DpMsgIdentification &dpMsg);
    friend DLLEXP_MESSAGES itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream, DpMsgIdentification &dpMsg);

    enum CompressionType
    {
      none = 0,
      zlib = 1,
      bzip = 2,
      last
    };

  public:
    // Konstruktor
    DpMsgIdentification();
    // Konstruktor
    DpMsgIdentification(const DpMsgIdentification &newMsg);
    // Konstruktor
    DpMsgIdentification(const ManagerIdentifier &newManId);
    // Destruktor
    ~DpMsgIdentification();


    // Operatoren :
    int operator==(const DpMsgIdentification &rVal) const;
    virtual int operator==(const Msg &rVal) const;
    DpMsgIdentification &operator=(const DpMsgIdentification &rVal);
    virtual Msg &operator=(const Msg &rVal);

    // Spezielle Methoden :
    virtual Msg *allocate() const;
    MsgType isA(MsgType dpMsgType) const;
    virtual MsgType isA() const;
    virtual void outNdrUb(itcNdrUbSend &ndrStream) const;
    virtual void inNdrUb(itcNdrUbReceive &ndrStream);
    virtual void debug(std::ostream &to, int level) const;
    virtual PVSSulong getNrOfGroups() const {return 1;};

    // Message compression. 
    void setCompressionType(const char *type);

    // Timestamps
    const MappingVar * getTimestamps() const;
    PVSSulonglong getTimestamp(SystemNumType sys) const;

    // Generierte Methoden :
    const DpIdentification *getIdentification() const;
    DpIdentification *getIdentification();

    // Diese Funktion nicht mehr verwenden
    void setIdentification(DpIdentification *newIdentification);
    void removeIdentification();
    int isValidIdentification() const;

  private:
    bool inflateIdentification();

  private:
    DpIdentification *identificationPtr;
    MappingVar * timestamps;

    // Cached compression. mutable because it acts like a cache
    mutable  Blob*   compCache_;
    mutable  int     compType_;
    mutable  size_t  rawLen_;
    mutable  short   version_;

};

// Inline-Funktionen :
inline const DpIdentification *DpMsgIdentification::getIdentification() const
{
  // use non-const version, as we need to modify the object anyway
  return const_cast<DpMsgIdentification *>(this)->getIdentification();
}

inline DpIdentification *DpMsgIdentification::getIdentification()
{
  if (!identificationPtr)
    inflateIdentification();

  return identificationPtr;
}

inline int DpMsgIdentification::isValidIdentification() const
{
  return (getIdentification() != 0);
}


inline const MappingVar * DpMsgIdentification::getTimestamps() const
{
  return timestamps;
}

#endif /* _DPMSGIDENTIFICATION_H_ */
