#ifndef _REPORTCALCULATIONVISITOR_H_
#define _REPORTCALCULATIONVISITOR_H_

#include <CNSTreeVisitor.hxx>


/**
 * Stores the number of visited nodes and the size of the names and
 * display names (incl. null char) of these nodes.
 */
class ReportCalculationVisitor : public CNSTreeVisitor
{
public:
  /// Default constructor
  ReportCalculationVisitor();

  /// Visitor method
  virtual CNSVisitor::NavigationHints visit(const CNSTreeNode &node);

  /// Returns the number of nodes visited
  unsigned int getNodeCount() const { return nodeCount; }

  /// Returns the number of non-empty CNSDataIdentifiers found
  unsigned int getDataCount() const { return dataCount; }

  /// Returns the size of the names and display names of all visited nodes
  size_t getStringSize() const { return stringSize; }

  /// Returns the size of the CNSDataIdentifiers of all visited nodes
  size_t getDataSize() const { return dataSize; }

private:
  /// the number of nodes visited
  unsigned int nodeCount;

  /// the number of non-empty CNSDataIdentifiers
  unsigned int dataCount;

  /**
   * The size of all names and display names in the visited nodes,
   * including null characters.
   */
  size_t stringSize;

  /**
   * The size of all CNSDataIdentifiers in the visited nodes.
   * Pretty useless for now, since this is included in sizeof(CNSTreeNode),
   * but it is planned for later versions to store various things in them.
   */
  size_t dataSize;
};


#endif // _REPORTCALCULATIONVISITOR_H_
