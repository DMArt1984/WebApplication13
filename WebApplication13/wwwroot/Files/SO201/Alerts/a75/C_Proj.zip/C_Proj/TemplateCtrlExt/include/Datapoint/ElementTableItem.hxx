#ifndef _ELEMENTTABLEITEM_H_
#define _ELEMENTTABLEITEM_H_

#ifndef  _DPTYPES_H_
#include <DpTypes.hxx>
#endif

#ifndef  _MAPTABLE_H_
#include <MapTable.hxx>
#endif

// ========== ElementTableItem ============================================================
/**Item in the ElementTable, supports language dependent descriptors
*/
class DLLEXP_DATAPOINT ElementTableItem 
{
public:
  ///constructor
  ElementTableItem();

  // only compares the DpTypeId
  
  /**== operator
    @param anItem the item to compare to
    @return nonzero when equal, zero otherwise
  */
  int operator==(const ElementTableItem &anItem) const;

  /**!= operator
    @param anItem the item to compare to
    @return nonzero when not equal, zero otherwise
  */
  int operator!=(const ElementTableItem &anItem) const;

  /**< operator
    @param anItem the item to compare to
    @return nonzero when lower, zero otherwise
  */
  int operator<(const ElementTableItem &anItem) const;
  
  /** operator << for itcNdrUbSend stream
      @param[in,out] ndrStream the stream to send to
      @param item ElementTableItem
    */
  friend DLLEXP_DATAPOINT itcNdrUbSend &operator<<(itcNdrUbSend &ndrStream, const ElementTableItem &item);
  /** operator >> for itcNdrUbReceive stream
      @param[in,out] ndrStream the stream to receive from
      @param[out] item ElementTableItem
    */
  friend DLLEXP_DATAPOINT itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream, ElementTableItem &item);

  ///returns the type id
  DpTypeId getTypeId() const;

  /**sets the type id
    @param newTypeId the new type id
  */
  void setTypeId(DpTypeId newTypeId);

  ///get language table, const version
  const MapTable &getLangTable() const { return dpes; }

  ///get language table
  MapTable &getLangTable() { return dpes; }

  /**Visits every element in language table using the given callback
    @param callback examination routine
    @return PVSS_TRUE if callback returned PVSS_TRUE for each item,
            PVSS_FALSE otherwise
  */
  PVSSboolean visitEveryElement(PVSSboolean (*callback)(const MapTableItem &langItem)) const;

  /** statistical summary of all items in language table
    @param[out] items number of items
    @param[out] strings number of strings
    @param[out] size total size in byte
  */
  void  summary(unsigned &items, unsigned &strings, unsigned &size);

private:
  DpTypeId typeId;
  MapTable dpes;

  // So the compiler doesn't define it
  ///copy ctor
  ElementTableItem(const ElementTableItem &) {} // COVINFO LINE: defensive (defined private so no one can use it)
  /** = operator
    @param el element to be assigned
  */
  ElementTableItem & operator=(const ElementTableItem &el) {return *this;} // COVINFO LINE: defensive (defined private so no one can use it)

  friend class UNIT_TEST_FRIEND_CLASS;
};

// ================================================================================
// Inline-Funktionen :
inline DpTypeId ElementTableItem::getTypeId() const
{
  return typeId;
}


inline void ElementTableItem::setTypeId(DpTypeId newTypeId)
{
  typeId = newTypeId;
}

inline PVSSboolean ElementTableItem::visitEveryElement(PVSSboolean (*callback)(const MapTableItem &langItem)) const
{
  return dpes.visitEveryElement(callback);
}


inline void ElementTableItem::summary(unsigned &items, unsigned &strings, unsigned &size)
{
  dpes.summary(items, strings, size);

  size += sizeof(typeId);
}



#endif /* _ELEMENTTABLEITEM_H_ */
