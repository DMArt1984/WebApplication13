// DATEIBESCHREIBUNG ==============================================================
// DATEINAME:     DpTriggerConv.hxx
// VERANTWORTUNG:	Stanislav Meduna
// 
// BESCHREIBUNG:	Trigger Umrechnung.
//
// AENDERUNGS-HISTORIE
// Ver.  | Datum      | Aenderungen                            | ModNr.| Autor
// ------+------------+-----------------Anfang-----------------+-------+-----------
//   1.0 |            | 1.Erstellung mit Westmount-OMT         |     0 |
// ======================================Ende======================================
#ifndef _DPTRIGGERCONV_H_
#define _DPTRIGGERCONV_H_

// Vorwaerts-Deklaration der Eigenen Klasse
class DpTriggerConv;

// System-Include-Files
#include <BitVar.hxx>
#include <DpConversion.hxx>
#include <FloatVar.hxx>

// Vorwaerts-Deklarationen :
class DpConvSmooth;
class DpTriggerConv;
class Variable;

class BitVec;

// ========== DpTriggerConv ============================================================
/** Trigger conversion class. 
    If the value exceeds preset limit, the trigger BitVar as output will be set.
*/
class DLLEXP_CONFIGS DpTriggerConv : public DpConversion 
{

  // Klassen-Enums:

// ..........................Anfang User-Klasseninterne-Definitionen..................
// ...........................Ende User-Klasseninterne-Definitionen...................
public:
  /// ctor
  DpTriggerConv();
  /// Destructor
  ~DpTriggerConv();


  // Operatoren :
  /**streaming send operator
    @param ndrStream itcNdrUbSend stream
    @param aConv DpTriggerConv conversion object
    @return ndr stream
    */
  friend DLLEXP_CONFIGS itcNdrUbSend &operator<<(itcNdrUbSend &ndrStream, const DpTriggerConv &aConv);
  /**streaming receive operator
    @param ndrStream itcNdrUbSend stream
    @param aConv DpTriggerConv conversion object
    @return ndr stream
    */
  friend DLLEXP_CONFIGS itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream, DpTriggerConv &aConv);
  /**assign operator
    @param aConv DpConvSmooth conversion object
    @return DpConvSmooth object
    */
  virtual DpConvSmooth &operator=(const DpConvSmooth &aConv);

  // Spezielle Methoden :
  ///returns DpConvTrigger conversion type
  virtual DpConversionType convType() const;
  /**An input variable is compared with the defined limit. If the value is greater a new bitvar is set to 1. The outVarPtr pointer is set to that bitvar. The caller is responsible for deletion. In case of an invalid variable a nullpointer is returned.
    @param inpVar input variable
    @param outVarPtr [out] points to the output, null if input variable was invalid
    @param unused BitVec value, not used in the code
    @return DpConversionResultType error code
    */
  virtual DpConversionResultType convert(const Variable &inpVar, Variable * & outVarPtr, const BitVec &unused);
  
  ///allocates instance of DpConvSmooth
  virtual DpConvSmooth *allocate() const;
  
  /**set attribute
    @param attrNr DpAttributeNrType attribute number
    @param var Variable& value
    @return PVSSboolean
    */
  virtual PVSSboolean setAttribut(DpAttributeNrType attrNr, const Variable &var);
  /**get attribute
    @param attrNr DpAttributeNrType attribute number
    @return Variable* attribute value
    */
  virtual Variable *getAttribut(DpAttributeNrType attrNr) const;

  // Generierte Methoden :
  ///returns limit for triggering(const)
  const FloatVar &getAttrLimit() const;
  ///returns limit for triggering
  FloatVar &getAttrLimit();
  /**sets limit for triggering
    @param newAttrLimit new limit
  */
  void setAttrLimit(const FloatVar &newAttrLimit);
  ///returns if inverse mode set(const)
  const BitVar &getAttrInvert() const;
  ///returns if inverse mode set(const)
  BitVar &getAttrInvert();
  /**sets/resets inverse mode 
    @param newAttrInvert BitVar inver mode
  */
  void setAttrInvert(const BitVar &newAttrInvert);
protected:
private:
  FloatVar attrLimit;
  BitVar attrInvert;

// ............................Anfang User-Attribut-Definitionen...................
// .............................Ende User-Attribut-Definitionen....................
};

// ================================================================================
// Inline-Funktionen :
inline const FloatVar &DpTriggerConv::getAttrLimit() const
{
  return attrLimit;
}

inline FloatVar &DpTriggerConv::getAttrLimit()
{
  return attrLimit;
}
inline void DpTriggerConv::setAttrLimit(const FloatVar &newAttrLimit)
{
  attrLimit = (FloatVar &) newAttrLimit;
}
inline const BitVar &DpTriggerConv::getAttrInvert() const
{
  return attrInvert;
}

inline BitVar &DpTriggerConv::getAttrInvert()
{
  return attrInvert;
}
inline void DpTriggerConv::setAttrInvert(const BitVar &newAttrInvert)
{
  attrInvert = (BitVar &) newAttrInvert;
}

// ............................Anfang User-Inlines.................................
// .............................Ende User-Inlines..................................

#endif /* _DPTRIGGERCONV_H_ */
