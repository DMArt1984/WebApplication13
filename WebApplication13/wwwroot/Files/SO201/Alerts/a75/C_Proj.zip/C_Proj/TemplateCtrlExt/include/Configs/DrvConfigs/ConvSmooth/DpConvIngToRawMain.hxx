// DATEIBESCHREIBUNG ==============================================================
// DATEINAME:     DpConvIngToRawMain.hxx
//
//
// AENDERUNGS-HISTORIE
// Ver.  | Datum      | Aenderungen                            | ModNr.| Autor
// ------+------------+-----------------Anfang-----------------+-------+-----------
//   1.0 |            | 1.Erstellung mit Westmount-OMT         |     0 |
// ======================================Ende======================================
#ifndef _DPCONVINGTORAWMAIN_H_
#define _DPCONVINGTORAWMAIN_H_

// Vorwaerts-Deklaration der Eigenen Klasse
class DpConvIngToRawMain;

// System-Include-Files
#include <DpConvSmoothContainer.hxx>

// Vorwaerts-Deklarationen :
class DpConfig;

/// Conversion for engineering value to raw (hardware) value.
class DLLEXP_CONFIGS DpConvIngToRawMain : public DpConvSmoothContainer 
{

  // Klassen-Enums:

// ..........................Anfang User-Klasseninterne-Definitionen..................
// ...........................Ende User-Klasseninterne-Definitionen...................
public:
  /// Default construktor.
  DpConvIngToRawMain();
  /// Destructor.
  ~DpConvIngToRawMain();

  /// Assignment operator.
  DpConvIngToRawMain &operator=(const DpConvIngToRawMain &rVal)
    { DpConvSmoothContainer::operator=((const DpConvSmoothContainer &) rVal); return *this; }

  // Spezielle Methoden :

  /** Check the config type. 
      @return The type if the transformation types are identical, else DPCONFIG_NOCONFIG.
      @classification public use, overload.
  */
  virtual DpConfigType isA(DpConfigType conf) const;
  /** Get the config type.
      @return The transformation type represented by this object.
      @classification public use, overload
  */
  virtual DpConfigNrType getDpConfigNrUncached() const;
  /** Allocate new instance of the class.
      @classification public use, overload
  */
  virtual DpConfig *allocate() const;

  // Generierte Methoden :
protected:
private:

// ............................Anfang User-Attribut-Definitionen...................
public:
  /** Get the config type.
      @return The transformation type represented by this object.
      @classification public use, overload
  */
  virtual DpConfigType isA() const { return DPCONFIG_CONVERSION_ING_TO_RAW_MAIN; };
  /// Returns the size of the object.
  virtual unsigned long sizeOf() const;
// .............................Ende User-Attribut-Definitionen....................
};

// ================================================================================
// Inline-Funktionen :

// ............................Anfang User-Inlines.................................
inline unsigned long DpConvIngToRawMain::sizeOf() const
{
  return sizeof(DpConvIngToRawMain);
}
// .............................Ende User-Inlines..................................

#endif /* _DPCONVINGTORAWMAIN_H_ */
