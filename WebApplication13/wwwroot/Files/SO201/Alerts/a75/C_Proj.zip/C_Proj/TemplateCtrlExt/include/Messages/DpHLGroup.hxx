// DATEIBESCHREIBUNG ==============================================================
// DATEINAME:     DpHLGroup.hxx
// VERANTWORTUNG: Johannes Ertl
// BESCHREIBUNG:  Das ist eine Gruppe einer HotLink-Message.
//                Normalerweise hat eine HotLink-Gruppe keine Error description
//                   (ErrClass), da sie eine normale spontane
//                   Benachrichtigung ist. In diesem Fall enthaelt jedes Item der
//                   Gruppe (DpVCItem) einen DpIdentifier und eine Variable.
//                Wird eine Gruppe geloescht, so wird die Gruppe ein letzes Mal
//                   mit einer Error description geschickt, damit derjenige, der
//                   die Gruppe angemeldet hat erfaehrt, dass seine Anmeldung
//                   nicht mehr existiert. In diesem Fall enthaelt jedes Item der
//                   Gruppe (DpVCItem) nur einen DpIdentifier und keine Variable,
//                   die Variable darf also nicht abgefragt werden!
// BEMERKUNG:    Wenn man eine Gruppe mit nur einem Item braucht, so ist die
//               DpSimpleHLGroup um einiges effizienter und wenn moeglich zu
//               benuetzen. DpSimpleHLGroup hat die gleiche Schnittstelle zum
//               Lesen der Items.

#ifndef _DPHLGROUP_H_
#define _DPHLGROUP_H_

#include <ostream>
#include <ErrClass.hxx>
#include <DpVCGroup.hxx>

#include <Allocator.hxx>

// Vorwaerts-Deklarationen :
class DpIdentifier;
class AnswerGroup;

// ========== DpHLGroup ============================================================

/** This is the group of a hotlink message. The group contains one or more items. 
  The order of the items is the order of the datapoints in the dpConnect statement.
  If the group is a notification of a value change, all items are a pair of a
  DpIdentifier and a VariablePtr and the group has no errorPtr. 
  If a connection group is deleted a DpHLGroup is sent a last time with items 
  containing no VariablePtr and the errorPtr is set.
 */
class DLLEXP_MESSAGES DpHLGroup : public DpVCGroup
{
  friend class DpMsgHotLink;
  friend class DpMsgFilterHL;
  friend class SpontNotifItem;
  friend class ConnTblEntry;

  public:

  /// default constructor, initialisation with zero values
  DpHLGroup();

  /// copy constructor, append copies of all items of rVal
  /// @param rVal the DpHLGroup to copy
  DpHLGroup(const DpHLGroup &rVal);

  /// param constructor, create a hotlink group with the errorPtr set to error
  DpHLGroup(const ErrClass &error);

  /// destructor
  virtual ~DpHLGroup();

  /// AllocatorDecl
  AllocatorDecl;

  // Operatoren :

  /// operator << for itcNdrUbSend stream
  /// @param ndrStream the stream, which to send to
  /// @param group the DpHLGroup
  friend DLLEXP_MESSAGES itcNdrUbSend &operator<<(itcNdrUbSend &ndrStream, const DpHLGroup &group);

  /// operator >> for itcNdrUbReceive stream
  /// @param ndrStream the stream, which to receive from
  /// @param group the DpHLGroup
  friend DLLEXP_MESSAGES itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream, DpHLGroup &group);

  /// clone function, create an exact copy of this hotlink group
  virtual DpIdValueList *makeACopy() const;

  /// send debug info to output stream
  /// @param to the output stream
  /// @param level the debug level, nothing is written if level == 0
  virtual void debug(std::ostream &to, int level) const;

# if 0 // DOC++

  /** append a new item to the group, make deep copy
    @param dpId  The identifier of the datapoint.
    @param value The value of the datapoint. The new item grabs a clone of value.
    @return 		 PVSS_TRUE, if the new item could be appended, PVSS_FALSE otherwise.
    @classification public use, call
   */

  virtual PVSSboolean appendItem(const DpIdentifier &dpId, const Variable &value);
  /** append a new item, make NO deep copy
    @param dpId 		The identifier of the datapoint.
    @param valuePtr The value of the datapoint. The new item grabs the pointer, 
    so don't delete the pointer later.
    @return 		 PVSS_TRUE, if the new item could be appended, PVSS_FALSE otherwise.
    @classification public use, call
   */
  virtual PVSSboolean appendItem(const DpIdentifier &dpId, VariablePtr valuePtr = 0);
# endif 

  /// set the ErrClass object
  /// @param error the error object to set
  void setErrorDescription(ErrClass &error);

  /// set the ErrClass object
  /// @param ptr the error object to set
  void  setErrorPtr(ErrClass *ptr) {delete errorPtr; errorPtr = ptr;}

  /// get the ErrClass object or 0 if this is a normal notification
  ErrClass * getErrorPtr() const { return errorPtr; }

  /// cut out the ErrClass object, the caller must delete the pointer
  ErrClass * cutErrorPtr() {ErrClass *tmp = errorPtr; errorPtr = 0; return tmp;}

# if 0 // For DOC++

  /// get the first item of this group
  DpVCItem *getFirstItem() const { return (DpVCItem *)itemList.getFirst(); }

  /// get the next item of this group
  DpVCItem *getNextItem() const { return (DpVCItem *)itemList.getNext(); }
  
  /// get the number of items in this group
  unsigned int getNumberOfItems() const { return itemList.getNumberOfItems(); }
# endif

  /// convert an AnswerGroup into a hotlink group
  /// @n The AnswerGroup is left empty.
  /// @param agrp the AnswerGroup to convert
  /// @return TRUE if success else FALSE
  bool swallowAnswer(AnswerGroup &agrp);

  /// get the connection ID
  PVSSulong getIdentifier() const {return connectOn;}

  /// set the connection ID
  /// @param id the value to set
  void setIdentifier(PVSSulong id) {connectOn = id;}

  /// check if this is the response on a reconnect
  PVSSboolean  isRefresh() const {return refresh;}

  /// set the refresh flag
  void setRefresh()              {refresh = PVSS_TRUE;}

  /// check if these are the values from an answer
  PVSSboolean  isAnswer() const  {return answer;}

  /// set the answer flag
  void setAnswer()               {answer = PVSS_TRUE;}

  private:
  ErrClass *errorPtr;
  PVSSulong connectOn;  // ID of the connect

  PVSSboolean refresh;  // Set in the manager, if this is the response on a refresh
  PVSSboolean answer;   // Set in the ctrl, if these are the values from an answer

  // Diese Funktion braucht nur SpontNotifItem
  void appendEmptyItem(const DpIdentifier &dpIdentifier){append(new DpVCItem(dpIdentifier,0));}

  DpHLGroup &operator=(const DpHLGroup &rVal);
  int operator==(const DpHLGroup &rVal) const;
};

#endif /* _DPHLGROUP_H_ */
