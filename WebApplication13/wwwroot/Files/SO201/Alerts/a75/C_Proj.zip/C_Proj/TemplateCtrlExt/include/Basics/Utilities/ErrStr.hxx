#ifndef _ERRSTR_H_
#define _ERRSTR_H_

// VERANTWORTUNG:	Laszlo Szakony
// BESCHREIBUNG:	Diese Klasse ist von string stream abgeleitet,
// 		            und alle operatoren des streams sind zu verwenden!
//                  DpIdentifer und Variable koennen auch in das Stream
//                  geschrieben werden!!!!!
//                  ErrStr allokiert kein Speicher, sondern verwendet
//                  ein internen Speicher fuer den String.


// ========== ErrStr ============================================================

// forward declarations
class DpIdentifier;
class Variable;


/** The internal errorstream class. 
    @classification CoreTest
*/
class DLLEXP_BASICS ErrStr 
{
public:
  /** Constructor.
  */
  ErrStr();

// Das Leben der Programmierer vereinfachen, sind hier einige Mustern,
// die in ErrorHandler verwendet werden koennen
  /** Writes the specified arguments to the error stream.
      @param idRef Reference to DpIdentifier.
      @return String written to the error stream.
   */
  static const char *text(const DpIdentifier& idRef);

  /** Writes the specified arguments to the error stream.
      @param varRef Reference to Variable.
      @return String written to the error stream.
  */
  static const char *text(const Variable& varRef);
  
  /** Writes the specified arguments to the error stream.
      @param prompt Prompt string.
      @param idRef Reference to DpIdentifier.
      @return String written to the error stream.
  */
  static const char *text(const char *prompt, const DpIdentifier& idRef);

  /** Writes the specified arguments to the error stream.
      @param prompt Prompt string.
      @param idRef Reference to DpIdentifier.
      @param varRef Reference to Variable.
      @return String written to the error stream.
  */
  static const char *text(const char *prompt, const DpIdentifier& idRef, const Variable& varRef);
  
  /** Writes the specified arguments to the error stream.
      @param prompt Prompt string.
      @param code Integer code.
      @return String written to the error stream.
  */
  static const char *text(const char *prompt, int code);
  
  /** Writes the specified arguments to the error stream.
      @param prompt Prompt string.
      @param varRef Reference to Variable.
      @return String written to the error stream.
  */  
  static const char *text(const char *prompt, const Variable& varRef);

  /** Writes the specified arguments to the error stream.
      @param prompt Prompt string.
      @param code Integer code.
      @param varRef Reference to Variable.
      @return String written to the error stream.
  */
  static const char *text(const char *prompt, int code, const Variable& varRef);

  /** Writes the specified arguments to the error stream.
      @param prompt Prompt string.
      @param code Integer code.
      @param idRef Reference to DpIdentifier.
      @return String written to the error stream.
  */
  static const char *text(const char *prompt, int code, const DpIdentifier& idRef);
  
  /** Writes the specified arguments to the error stream.
      @param prompt Prompt string.
      @param code Integer code.
      @param idRef Reference to DpIdentifier.
      @param varRef Reference to Variable.
      @return String written to the error stream.
   */  
  static const char *text(const char *prompt, int code, const DpIdentifier& idRef, const Variable& varRef);

};

#endif /* _ERRSTR_H_ */
