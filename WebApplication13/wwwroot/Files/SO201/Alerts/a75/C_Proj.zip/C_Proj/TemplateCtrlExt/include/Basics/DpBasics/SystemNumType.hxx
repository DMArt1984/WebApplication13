#ifndef _SYSTEMNUMTYPE_H_
#define _SYSTEMNUMTYPE_H_

// DATEIBESCHREIBUNG ==============================================================
// DATEINAME:     SystemNumType.hxx
// VERANTWORTUNG: Andreas Pfluegl
// BESCHREIBUNG: System-Nummer Klasse 
//
// AENDERUNGS-HISTORIE
// Ver.  | Datum      | Aenderungen                            | ModNr.| Autor
// ------+------------+-----------------Anfang-----------------+-------+-----------
//   1.0 |            | 1.inital                               |     0 |
// ======================================Ende======================================
// System-Include-Files
#ifndef _TYPES_HXX_
#include <Types.hxx>
#endif

#ifndef _CHARSTRING_HXX_
#include <CharString.hxx>
#endif

/** The PVSS-II system number type. */
class DLLEXP_BASICS SystemNumType
{
  // this is the numerical maximum of nodes
  // use SystemNumType::maxSystemNumber() instead of this define
  #define     MAX_SYSTEM_NUM_TYPE       0x3FFE
  #define     SUPPORTED_MAX_SYSTEM_NUM  2048

public:
  /// Default Constructor creates a valid system number with the
  /// special meaning of "not defined".
  SystemNumType()                         :sys_(0) {}

  //@{
  /// Constructor from short.
  SystemNumType(short _sys)          :sys_(_sys) {}

  /// Constructor from unsigned short.
  SystemNumType(unsigned short _sys) :sys_(_sys) {}

  /// Constructor from int.
  SystemNumType(int _sys)            :sys_(_sys) {}

  /// Constructor from unsigned int.
  SystemNumType(unsigned int _sys)   :sys_(_sys) {}

  /// Constructor from long.
  SystemNumType(long _sys)           :sys_(static_cast<PVSSulong>(_sys)) {}

  /// Constructor from unsigned long.
  SystemNumType(unsigned long _sys)  :sys_(static_cast<PVSSulong>(_sys)) {}
  //@}

  /// Copy Constructor
  SystemNumType(const SystemNumType& _op) :sys_(_op.sys_) {}

  //@{
  /// Operator needed
  bool operator! () const { return(!this->sys_); }

  /// Operator needed
  SystemNumType &operator=(const SystemNumType& _op) { sys_ = _op.sys_; return(*this); }

  /// Operator needed
  SystemNumType operator+(const SystemNumType& _op) const { return(SystemNumType(sys_+ _op.sys_)); }

  /// Operator needed
  bool operator> (const SystemNumType& _op) const { return(this->sys_ >  _op.sys_); }
  /// Operator needed
  bool operator< (const SystemNumType& _op) const { return(this->sys_ <  _op.sys_); }

  /// Operator needed
  bool operator==(const SystemNumType& _op) const { return(this->sys_ == _op.sys_); }
  /// Operator needed
  bool operator!=(const SystemNumType& _op) const { return(this->sys_ != _op.sys_); }
  /// Operator needed
  bool operator&&(const SystemNumType& _op) const { return(this->sys_ && _op.sys_); }
  //@}

  /// type conversions
  //@{
  /// Type Conversion to PVSSulong.
  PVSSulong  toPVSSulong() const   { return(sys_);             }
  ///
  /// Type Conversion to CharString.
  CharString toString( )   const   { return(CharString(sys_)); }
  //@}

  //@{
  /// cast operator
  operator bool( ) const             { return(this->sys_ != 0 ); }
  /// cast operator
  operator short( ) const            { return(this->sys_);       }
  /// cast operator
  operator unsigned short( ) const   { return(this->sys_);       }
  /// cast operator
  operator int( ) const              { return(this->sys_);       }
  /// cast operator
  operator unsigned int( ) const     { return(this->sys_);       }
  /// cast operator
  operator long( ) const             { return(this->sys_);       }
  /// cast operator
  operator unsigned long( ) const    { return(this->sys_);       }
  /// cast operator
  operator long long( ) const        { return(this->sys_);       }
  //@}

  /** Check that the system number is 0.
      0 has the special meaning "not defined".
      @return true if the system number is 0.
  */
  bool isNull() const { return(this->sys_ == 0); }

  /** Check that the system number is not 0.
      The system number may an invalid one or a not supported one.
      @see isInvalid().
      @see maxSystemNumber().
      @return true if the system number is not 0.
  */
  bool notNull() const { return(this->sys_ != 0); }

  /** valid system numbers are in the range 0..MAX_SYSTEM_NUM_TYPE.
      The system number may null or a not supported one.
 
      @see isNull()
      @see notNull()
      @see maxSystemNumber()
      @return true if the system number is greater MAX_SYSTEM_NUM_TYPE.
  */
  bool isInvalid() const { return(sys_ >= MAX_SYSTEM_NUM_TYPE+1); }

  /** Check that the system number is the broadcast number.
      The fist invalid system number (MAX_SYSTEM_NUM_TYPE+1) can be used 
      to express "all existing systems" (broadcast).
      @see getBroadCast().
      @return true if the system number is the broadcast number.
  */
  bool isBroadCast() const { return(sys_ == MAX_SYSTEM_NUM_TYPE+1); }

  /// writes the system number to a BCM stream.
  /// It takes care about the MSG-Version.
  ///   @param ndrStream the stream to write to.
  void writeOn(itcNdrUbSend &ndrStream) const;

  /// reads the system number from a BCM stream.
  /// It takes care about the MSG-Version.
  ///   @param ndrStream the stream to read from.
  void readFrom(itcNdrUbReceive &ndrStream);


public:
  /** @name static Methods */
  //@{
  /// the biggest supported system number.
  /// The biggest supported systemnumber may me smaller than the
  /// biggest valid system number.
  ///   @return the biggest supporte system number.
  static PVSSulong maxSystemNumber() { return(SUPPORTED_MAX_SYSTEM_NUM); }

  /** the broadcast number.
      The first invalid system number (MAX_SYSTEM_NUM_TYPE+1) can be used 
      to express "all existing systems" (broadcast).
      @see isBroadCast().
      @return broadcast system number.
  */
  static SystemNumType getBroadCast() { return(SystemNumType(MAX_SYSTEM_NUM_TYPE+1)); }
  //@}
  
public:
  /// SystemNumType + int
  friend DLLEXP_BASICS SystemNumType operator+(const SystemNumType &_op1, int _op2);
  /// SystemNumType - int
  friend DLLEXP_BASICS SystemNumType operator-(const SystemNumType &_op1, int _op2);

public:
  /// writes the system number to an output stream
  friend DLLEXP_BASICS std::ostream &operator<<(std::ostream &_o, const SystemNumType &_t);
  /// read the system number from an input stream
  friend DLLEXP_BASICS std::istream &operator>>(std::istream &_i, SystemNumType &_t);

  /// writes the system number to a BCM stream and takes care about the MSG-Version.
  friend DLLEXP_BASICS itcNdrUbSend    &operator<<(itcNdrUbSend    &ndrStream, const SystemNumType &_t);
  /// reads the system number from a BCM stream and takes care about the MSG-Version.
  friend DLLEXP_BASICS itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream, SystemNumType &_t);

private: 
  /// Avoid Construction with that types. Should never be called.
  SystemNumType(PVSSchar)   {}  //COVINFO LINE: defensive (AP: disallow ctor)
  SystemNumType(PVSSuchar)  {}  //COVINFO LINE: defensive (AP: disallow ctor)


private: 
  PVSSulong sys_;
};

// ---------------------------------------------------------------------------------
// --
// ---------------------------------------------------------------------------------
inline SystemNumType operator+(const SystemNumType &_op1, int _op2)
{
  return(SystemNumType(_op1.sys_ + _op2));
}

// ---------------------------------------------------------------------------------
// --
// ---------------------------------------------------------------------------------
inline SystemNumType operator-(const SystemNumType &_op1, int _op2)
{
  return(SystemNumType(_op1.sys_ - _op2));
}

#endif /* _SYSTEMNUMTYPE_H_ */

