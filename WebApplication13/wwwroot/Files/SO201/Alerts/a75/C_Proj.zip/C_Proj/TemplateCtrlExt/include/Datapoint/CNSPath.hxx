#ifndef _CNSPATH_H_
#define _CNSPATH_H_

#include <SimplePtrArray.hxx>
#include <CharString.hxx>

/**
 * Parses a CNS path into system, view and nodes.
 */
class DLLEXP_DATAPOINT CNSPath
{
public:

  /// Values for Ctrl function cnsSubStr()
  enum SubStrFlags
  {
    /// System name
    CNSSUB_SYS    = (1 << 0),
    /// View name when not combined with otherflags, otherwise view path
    CNSSUB_VIEW   = (1 << 1),
    /// Node path
    CNSSUB_PATH   = (1 << 2),
    /// Parent node path
    CNSSUB_PARENT = (1 << 3),
    /// Root node name
    CNSSUB_ROOT   = (1 << 4),
    /// Last segment of the node path (which is the name of the addressed node)
    CNSSUB_NODE   = (1 << 5),
    /// Everything behind a valid CNS path
    CNSSUB_TAIL   = (1 << 6)
  };

  /**
   * The separator between the view name and the tree name,
   * e.g. 'System1.View1:Tree1.Node1'.
   * Used for technical and display names.
   */
  static const char VIEW_SEPARATOR; // ':'

  /**
   * The separator between system and view, and between
   * nodes of a tree.
   * Used only for technical names, display names can define
   * custom path separators.
   */
  static const char PATH_SEPARATOR; // '.'

  /**
   * Default constructor. Creates an empty, invalid path.
   */
  CNSPath() : separator(PATH_SEPARATOR), valid(false) { }

  /**
   * Tries to parse the given path as a CNS path. See CNSNodeNames for more
   * information about CNS paths.
   * The path must not be complete, it can also address just the view
   * (e.g. 'System1.View1' or '.View1:').
   *
   * Parsing stops as soon as the path is identified as invalid.
   * The path segments are not checked for illegal characters, so path patterns
   * like '*.*:Node1.Node*' can be parsed and will be considered valid.
   * The path separator is checked for illegal characters.
   * See isValid() for details.
   *
   * If the given path is a combined CNS+DP path (e.g. 'Sys.View:Tree.DPE1.DPE2:_config.._attribute'),
   * parsing will stop at the second colon (before '_config') and the resulting
   * path will be considered valid.
   *
   * @param pathString The path to parse
   * @param separator The separator to use for the path. It has to be a legal
   *                  display name separator, otherwise the path will be
   *                  empty and invalid.
   *                  If no separator is specified, the default separator ('.')
   *                  will be used.
   *
   * @see CNSNodeNames::isLegalDisplayNameSeparator()
   */

  CNSPath(const CharString &pathString, char pathSeparator = PATH_SEPARATOR);

  /// Copy constructor
  CNSPath(const CNSPath &rval);

  /// Assignment operator
  CNSPath & operator=(const CNSPath &rval);

  /**
   * Returns the path separator used to parse this path.
   */
  char getSeparator() const { return separator; }

  /**
   * Returns the system part of the path. May be empty if no system was
   * specified.
   */
  const CharString &getSystem() const { return system; }

  /**
   * Returns the view part of the path. Should never be empty.
   */
  const CharString &getView() const { return view; }

  /**
   * Returns a list of the node segments of the path, starting with the
   * root node.
   */
  const SimplePtrArray<CharString> &getNodes() const { return nodes; }

  /**
   * Removes the last node segment of the path.
   * Does nothing if there are no nodes.
   *
   * Useful for getting the parent path of a node.
   */
  void popNode();

  /**
   * Returns true if this path is valid. It does not have to be complete
   * to be valid, as long as a syntactically correct view path is given
   * (e.g. '.View1').
   *
   * This method only checks that the necessary parts of a path exist,
   * not whether it contains illegal characters.
   */
  bool isValid() const { return valid; }

  /**
   * Returns true if this path is valid and can be used to address a node.
   * It does not have to contain a system, but the view and at least one node
   * are required for the path to be complete.
   */
  bool isCompletePath() const { return isValid() && (nodes.getNumberOfItems() > 0); }

  /**
   * Returns this path as string. Note that it may very well return an invalid path,
   * so use isValid() to determine the validity of the path.
   *
   * If no nodes were specified, the returned path will be in the format
   * 'System.View:', with nodes it will return 'System.View:Node1.Node2'.
   * If a custom separator character was specified in the constructor,
   * this separator will be used instead of the default path separator.
   *
   * @param withSystem Decides whether the system name will be included in the path.
   *                   Example without system: '.View1:Tree1.Node1'.
   * @param withNodes Decides whether the nodes will be included in the path.
   *                  Example without nodes: 'System1.View1:'.
   */
  CharString toString(bool withSystem = true, bool withNodes = true) const;

  /**
   * Compares a CNS path with a pattern which can contain the wildcards
   * '?' and '*'.
   *
   * If the pattern does not match the path, willFailForChildren will tell
   * whether the same pattern would definitely fail for descendants of a node
   * with the given path.
   *
   * @param mask The pattern to match with
   * @param str The CNS path to match
   * @param [out] willFailForChildren Tells whether the same pattern would
   *                                  definitely fail for descendants of a node
   *                                  with the given path.
   */
  static bool match(const char *mask, const char *str, bool &willFailForChildren);

private:
  char separator;
  CharString system;
  CharString view;
  SimplePtrArray<CharString> nodes;
  bool valid;

  /**
   * Parses the given path into the current instance.
   *
   * @return True if the path was valid, otherwise false.
   * @see isValid()
   */
  bool init(const CharString &pathString, char separator);

  /**
   * Internal matching method used by match(). Acts like described for match(),
   * except that it stops if a VIEW_SEPARATOR is found in the mask.
   */
  static bool internalMatch(const char *&m, const char *&s,
                            bool &willFailForChildren);
};

//------------------------------------------------------------------------------
// inline methods:

inline CNSPath::CNSPath(const CharString &pathString, char pathSeparator)
  : separator(pathSeparator)
{
  valid = init(pathString, pathSeparator);
}

//------------------------------------------------------------------------------

inline CNSPath::CNSPath(const CNSPath &rval)
{
  *this = rval;
}

//------------------------------------------------------------------------------

inline CNSPath & CNSPath::operator=(const CNSPath &rVal)
{
  if (this == &rVal)
    return *this;

  separator = rVal.separator;
  system = rVal.system;
  view = rVal.view;
  valid = rVal.valid;

  nodes.clear();
  for (unsigned idx = 0; idx < rVal.nodes.getNumberOfItems(); idx++)
    nodes.append(new CharString(*rVal.nodes.getAt(idx)));

  return *this;
}

#endif // _CNSPATH_H_
