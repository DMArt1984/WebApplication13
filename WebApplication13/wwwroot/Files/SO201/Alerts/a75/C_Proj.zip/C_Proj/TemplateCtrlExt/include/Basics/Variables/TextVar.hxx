#ifndef _TEXTVAR_H_
#define _TEXTVAR_H_

#ifndef _VARIABLE_H_
#include <Variable.hxx>
#endif

#ifndef _CHARSTRING_H_
#include <CharString.hxx>
#endif

class DpIdentifier;

// ========== TextVar ============================================================

/** Variable class representing a string
    @n For all passed pointer parameters will be always a new copy of given object created (allocate + strcpy).
    This class will never return a 0-pointer in getValue().
  */
//author Johannes Ertl, Robert Trausmuth, Martin Koller
class DLLEXP_BASICS TextVar : public Variable
{

  /** operator << for itcNdrUbSend stream
      @param ndrStream the stream, which to send to
      @param tVar the TextVar
    */
  friend DLLEXP_BASICS itcNdrUbSend &operator<<(itcNdrUbSend &ndrStream, const TextVar &tVar);

  /** operator >> for itcNdrUbReceive stream
      @param ndrStream the stream, which to receive from
      @param tVar the TextVar
    */
  friend DLLEXP_BASICS itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream, TextVar &tVar);

  /** operator << for std stream
      @param ofStream the stream, which to send to
    */
  friend DLLEXP_BASICS std::ostream &operator<<(std::ostream &ofStream, const TextVar &);

  /** operator >> for std stream
      @param ifStream the stream, which to receive from
    */
  friend DLLEXP_BASICS std::istream &operator>>(std::istream &ifStream, TextVar &);

  public:
  
    /** constructor, initialisation with zero values
      */
    TextVar()
    {
      cachedIsA = TEXT_VAR;
    }

    /** constructor, initialisation with array of char
        @param init the array of char, which shall be initialised with
        @param len the size of the array of char
      */
    TextVar(const char *init, size_t len = (size_t)-1) : value(init, len)
    {
      cachedIsA = TEXT_VAR;
      // value.shareString();
    }

    /** constructor, initialisation with CharString
        @param init the CharString, which shall be initialised with
      */
    TextVar(const CharString &init) : value(init) 
    { 
      cachedIsA = TEXT_VAR; 
      // value.shareString();
    }

    /** copy constructor
        @param rVal the TextVar, which shall be copied from
      */
    TextVar(const TextVar &rVal) : Variable(rVal), value(rVal.value) 
    { 
      cachedIsA = TEXT_VAR; 
      // value.shareString();
    }

    /** allocator deallocator class
      */
    AllocatorDecl;

    /** comparison operator ==
        @param rVal the Variable to compare with
            @n Important: this operator checks the VariableType, so two objects are only equal, if
               they also have the same class (no conversion is done; see other operators).
        @return 0 if not equal else 1
      */
    virtual int operator==(const Variable &rVal) const;

    /** comparison operator <
        @param rVal the Variable to compare with
        @n Important: this operator also converts the given rVal to its own class-type if needed.
        @return 0 if the Variable to compare with is smaller else 1
	  */
    virtual int operator<(const Variable &rVal) const;

    /** comparison operator >
        @param rVal the Variable to compare with
        @n Important: this operator also converts the given rVal to its own class-type if needed.
        @return 0 if the Variable to compare with is bigger else 1
	  */
    virtual int operator>(const Variable &rVal) const;

    /** non virtual comparison operator ==
        @param rVal the TextVar to compare with
        @return 0 if not equal else 1
	  */
    int operator==(const TextVar &rVal) const;

    /** non virtual comparison operator <
        @param rVal the TextVar to compare with
        @return 0 if the TextVar to compare with is smaller else 1
	*/
    int operator<(const TextVar &rVal) const;

    /** append array of char
        @param text the array of char to append
        @return the resulting TextVar
	  */
    TextVar & operator +=(const char *text) 
    {
      value += text; 
      // value.shareString();
      return *this;
    }

    /** append CharString
        @param text the CharString to append
        @return the resulting TextVar
	  */
    TextVar & operator +=(const CharString &text)
    {
      value += text;
      // value.shareString();
      return *this;
    }

    /** append TextVar
        @param text the TextVar to append
        @return the resulting TextVar
	  */
    TextVar & operator +=(const TextVar &text)
    {
      value += text.getString();
      // value.shareString();
      return *this;
    }

    /** concatenate two TextVars
        @param add1 the 1st TextVar to concatenate
        @param add2 the 2nd TextVar to concatenate
        @return the resulting TextVar
	  */
    friend DLLEXP_BASICS TextVar operator+(const TextVar &add1, const TextVar &add2);

    /** concatenate TextVars and array of char
        @param add1 the TextVar to concatenate
        @param add2 the array of char to concatenate
        @return the resulting TextVar
	  */
    friend DLLEXP_BASICS TextVar operator+(const TextVar &add1, const char *add2);

    /** concatenate array of char and TextVars
        @param add1 the array of char to concatenate
        @param add2 the TextVar to concatenate
        @return the resulting TextVar
      */
    friend DLLEXP_BASICS TextVar operator+(const char *add1, const TextVar &add2);

    /** wildcard comparison
        @param mask the TextVar mask to compare with. This mask can hold wildcard chars like * and ?
        @return 0 if not matching else 1
      */
    int wildCompare(const TextVar &mask) const;

    /** assignment operator used for type conversion
        @param rVal the Variable to convert
        @n Almost every variable type can be converted to a TextVar.
        @return the resulting Variable
      */
    virtual Variable &operator=(const Variable &rVal);

    /** non virtual assignment operator for array of char
        @param rVal the array of char to assign
        @return the resulting TextVar
      */
    TextVar &operator=(const char *rVal) 
    { 
      value = rVal; 
      // value.shareString();
      return *this; 
    }

    /** non virtual assignment operator for CharString
        @param rVal the CharString to assign
        @return the resulting TextVar
      */
    TextVar &operator=(const CharString &rVal) 
    { 
      value = rVal; 
      // value.shareString();
      return *this; 
    }

    /** cast to const char *
        @return the resulting const char * or "" if casting not possible
      */
    operator const char *() const { return ((const char *)value) ? ((const char *)value) : ""; }

    /** cast to const CharString &
        @return the resulting CharString
      */
    operator const CharString &() const { return value; }

    /** allocate new TextVar
        @return the new TextVar
      */
    virtual Variable *allocate() const { return new TextVar; }

    /** return type of variable
        @return TEXT_VAR
      */
    virtual VariableType isAUncached() const { return TEXT_VAR; }

	/** return type of variable
        @param varType the VariableType to check
	    @return TEXT_VAR if TextVar else return other VariableType
      */
	virtual VariableType isAUncached(VariableType varType) const;

# if 0
    /** return own variable type
        @return TEXT_VAR
      */
    VariableType  isA() const;

	/** check if own variable type matches other variable type
        @param varType the VariableType to check
        @return TEXT_VAR, if argument is TextVar, else NOTYPE_VAR.
      */
    VariableType  isA(VariableType varType);

# endif

	/** send to output stream
        @param ofStream the stream, which to send to
      */
    virtual void outToFile(std::ostream &ofStream) const;

	/** get from input stream
        @param ifStream the stream, which to get from
      */
	virtual void inFromFile(std::istream &ifStream);

    /** format the value according to the format string
        @param  format the CharString format
		    @n  If the value is not empty it is used as an argument to the sprintf function. Else the value
                itself is returned.
        @return the string representation of the value
      */
    virtual CharString formatValue(const CharString &format) const;

    /** format the value according to a format string.
        @param format the CharString format
		    @n If the string is not empty, it is used as an argument to the sprintf function (if useful).
               Else a default is used.
        @param target the array of char as a buffer, which is directly written to
            @n This method is more performant than the one, which returns a CharString,
               because no alloc is done.
        @param len the size of the buffer
        @return the number of bytes written into target without 0-byte,
                or a negative value on error (like buffer too small)
             @n Special case: if no format is given and the value is larger than the buffer,
                the result is a truncated value, ending in " ..."; Return value is then -2
      */
    virtual int formatValue(const CharString &format, char *target, size_t len) const;

    /** set a value given by array of char
        @param val the array of char to set (a copy of the string is set)
	  */
    void setValue(const char *val) 
    { 
      value = val; 
      // value.shareString(); 
    }

    /** set a value given by CharString
        @param str the CharString to set
      */
    void setValue(const CharString &str) 
    { 
      value = str; 
      // value.shareString(); 
    }

    /** set a value given by pointer
        @param val the pointer to a array of char, 0-pointer is allowed
            @n The pointer shall not be deleted later.
        @param len the length of the given string
		    @n If not given, it is determined with strlen(val). In this case, make sure,
			   that the array is 0-terminated.
        @param size the length of the given array (not necessarily the string up to the 0-byte)
            @n If not given, the length will be determined by strlen(val). In this case, make sure that,
			   the array is 0-terminated.
      */
    void setValuePtr(char *val, size_t len = (size_t) -1, size_t size = (size_t) -1) 
    {
      value.setCharPtr(val, len, size); 
      // value.shareString();
    }

	/** get the stored string as a const char *
        @return the pointer to the stored string
    */
    const char *getValue() const { return ((const char *)value) ? (const char *)value : ""; }

	/** get pointer to the stored string as char *
	   @n Obsolete, use cutValuePtr instead.
        @return the pointer to the stored string
             @n The caller is responsible to delete the memory.
      */
    IL_DEPRECATED("deprecated, use cutValuePtr() instead")
    char *getValuePtr() {return value.cutCharPtr();}

    /** cut the value
        @return the pointer to the stored string
             @n The caller is responsible to delete the memory.
      */
    char *cutValuePtr() {return value.cutCharPtr();}

    /** set the TextVar by CharString
        @param newValue the CharString to set
      */
    void setString(const CharString &newValue) {setValue(newValue);}

    /** get the value of this TextVar as const CharString
        @return the CharString as value of this TextVar
      */
    const CharString &getString() const { return value; }

    /** get the value of this TextVar as CharString
        @return the CharString as value of this TextVar
      */
    CharString & getString() 
    { 
      // Not necessary, CharString takes care for itself
      // value.unshareString(); 
      return value; 
    }

    /** check if this TextVar object is logically true, i.e. if there is a text stored in it
        @return PVSS_FALSE if this TextVar object is empty or "false" or "FALSE" else PVSS_TRUE
      */
    virtual PVSSboolean isTrue() const;

    /** clone the current TextVar object
        @return the Variable as clone of this object
      */
    virtual Variable *clone() const;

  private:
    int wildComp(char *mask, char *string) const;

    void outNdrUb(itcNdrUbSend &ndrStream) const;
    void inNdrUb(itcNdrUbReceive &ndrStream);

    CharString value;
};

#endif /* _TEXTVAR_H_ */
