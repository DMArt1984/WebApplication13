#ifndef _SYNCEDPG_H_
#define _SYNCEDPG_H_

#ifndef _PERIODGENERATOR_H_
#include <PeriodGenerator.hxx>
#endif

#ifndef _NEXTVALIDLISTTIME_H_
#include <NextValidListTime.hxx>
#endif

// ========== SyncedPG ============================================================

/** synced period generator
    @n This class generates cyclic periods of given time interval within
    certain validity period of given validity time interval.
    A sync time meeting conditions can be specified.
    For the first period (period 0) getPeriodEnd() returns NullTimeVar.

    Example:

    ..._____0______x______1______x_____2______x____3_____x____#____x

    ___F___________^_____________^____________^__________^___U_____^_____

    symbols:
    @n x__n__x  period with number n = 0, 1, 2...   x marks start and end
    @n x__#__x  the last period, considered invalid
    @n ___F___  validity period from
    @n ___U___  validity period until
    @n ___^___  sync time meeting conditions aMonthList - aDayTimeList, conditions interpreted like in NextValidListTime
 
    @classification ETM internal
*/
class DLLEXP_OABASICS SyncedPG : public PeriodGenerator
{
  public:
    friend class UNIT_TEST_FRIEND_CLASS;
    /// constructor, initialisation with zero values
    SyncedPG();

    /** set conditions of the intermittently active period generator
        @param aStartTime the starting time of generation
        @param aMonthList the generator activity schedule within a year
        @param aMonthDayList the generator activity schedule within a month
        @param aWeekDayList the generator activity schedule within a week
        @param aDayTimeList the generator activity schedule within a day
        @param aValidFrom the starting time of validity period
            @n If NullTimeVar, then the first period ends at aStartTime.
        @param aValidUntil the ending time of validity period
            @n If NullTimeVar, then periods never get invalid (may work forever).
        @return PVSS_TRUE if everything is OK, else PVSS_FALSE 
      */
    PVSSboolean setConditions( const TimeVar &aStartTime,
                               const DynVar &aMonthList,
                               const DynVar &aMonthDayList,
                               const DynVar &aWeekDayList,
                               const DynVar &aDayTimeList,
                               const TimeVar &aValidFrom = TimeVar::NullTimeVar,
                               const TimeVar &aValidUntil = TimeVar::NullTimeVar );
    
    /** go to the next period
        @return PVSS_TRUE if within given validity period, else PVSS_FALSE 
      */
    virtual PVSSboolean goNextPeriod();
    
  protected:

  private:
    // so that the compiler does not define them itself !!

    // copy constructor
    SyncedPG(const SyncedPG &) {}
    // assignment operator
    SyncedPG &operator=(const SyncedPG &) { return *this; }
    
    void initialize( const TimeVar &aStartTime );
    
    NextValidListTime myNextTrigger;
    TimeVar validFrom;
    TimeVar validUntil;
};

#endif /* _SyncedPG_H_ */
