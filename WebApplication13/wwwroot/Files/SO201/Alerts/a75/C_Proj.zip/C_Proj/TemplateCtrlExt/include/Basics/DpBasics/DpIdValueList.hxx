// DATEIBESCHREIBUNG ==============================================================
// DATEINAME:     DpIdValueList.hxx
// VERANTWORTUNG: Guenter Szolderits
// BESCHREIBUNG:  Die DpIdValueList ist eine Liste von DpVCItem Objekten
//                Sie wird unter anderem als Basisklasse fuer DpHLGroup verwendet

#ifndef _DPIDVALUELIST_H_
#define _DPIDVALUELIST_H_

// System-Include-Files
#ifndef _PTRLIST_H_
#include <PtrList.hxx>
#endif

#ifndef _PTRLISTITEM_H_
#include <PtrListItem.hxx>
#endif

#ifndef _VARIABLE_H_
#include <Variable.hxx>
#endif

#ifndef _DPVCITEM_H_
#include <DpVCItem.hxx>
#endif

// Vorwaerts-Deklarationen :
class DpIdentifier;
class itcNdrUbSend;
class itcNdrUbReceive;

/** The DpIdValueList class. 
    This class holds a list of DpVCItem objects which are a combination of DpIdentifier 
    and Variable. This class is the mother of most message groups. 
    Since a message can hold more groups this class is derived from PtrListItem, too.
*/
class DLLEXP_BASICS DpIdValueList : public PtrListItem
{
  /// Write the content into the stream.
  friend DLLEXP_BASICS itcNdrUbSend & operator<<(itcNdrUbSend &ndrStream, const DpIdValueList &list);
  /// Read the content from the stream.
  friend DLLEXP_BASICS itcNdrUbReceive & operator>>(itcNdrUbReceive &ndrStream, DpIdValueList &list);

public:
  /// Constructor.
  DpIdValueList();
  /// Copy constructor.
  DpIdValueList(const DpIdValueList &rVal);

  /// Destructor.
  virtual ~DpIdValueList();

  // Operatoren :
  /// Create a clone from the current list. A full deep copy is performed.
  virtual DpIdValueList *makeACopy() const;
  /** Print the contents of the list to an output stream.   
      Level controls the amount of debug information printed and shall be > 0.
  */
  virtual void debug(std::ostream &to, int level) const;

  // macht deep-copy der Variablen
  /** Add a new dpId / value pair to the list. 
      The value is cloned.
      @param  dpIdentifier  DP ID to be added.
      @param  value  Value of the DP ID.
      */
  virtual PVSSboolean appendItem(const DpIdentifier &dpIdentifier, const Variable &value);
  // macht KEIN deep-copy der Variablen
  /** Add a new dpId / value pair to the list. 
      The valuePtr is captured and shall not deleted.
      @param  dpIdentifier  DP ID to be added.
      @param  valuePtr  Value of the DP ID.
      */
  virtual PVSSboolean appendItem(const DpIdentifier &dpIdentifier, VariablePtr valuePtr = 0);

  /// Get the first item in the list or 0 if list is empty.
  DpVCItem *getFirstItem() const { return (DpVCItem *)itemList.getFirst(); }
  /// Get the next item in the list or 0 if no more items.
  DpVCItem *getNextItem() const { return (DpVCItem *)itemList.getNext(); }
  /// Get the item following the argument or 0 if no more items.
  DpVCItem *getNextItem(DpVCItem *p) const { return (DpVCItem *) itemList.getNext(p); }
  /// Cut out and return the first item in the list or 0 if list is empty.
  DpVCItem * cutFirstItem() { return (DpVCItem *) itemList.cutFirst(); }
  /// Get the number of items in the list.
  unsigned int getNumberOfItems() const { return itemList.getNumberOfItems(); }

  /// Comparison operator. DpIDentifiers and values are compared.
  int operator==(const DpIdValueList &rVal) const;
  /// Assignment operator. A deep copy is performed.
  DpIdValueList &operator=(const DpIdValueList &rVal);

protected:
  /// List of dpId / value pairs.
  PtrList itemList;
};

#endif /* _DPIDVALUELIST_H_ */
