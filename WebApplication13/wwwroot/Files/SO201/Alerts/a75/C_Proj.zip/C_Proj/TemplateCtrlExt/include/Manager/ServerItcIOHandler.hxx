// DATEIBESCHREIBUNG ==============================================================
// DATEINAME:     ServerItcIOHandler.hxx
// VERANTWORTUNG: Gerhard Fellrieser
// BESCHREIBUNG: Die Klasse SocketItcIOHandler wird von der Klasse itcIOHandler
// 		(BCM) abgeleitet. Sie hat die Aufgabe, als Server auf Verbindungen 
// 		von Clients zu warten, bzw. bei Verbindungsaufbau dem MsgSender die
// 		Verbindung mitzuteilen. 
//
// AENDERUNGS-HISTORIE
// Ver.  | Datum      | Aenderungen                            | ModNr.| Autor
// ------+------------+-----------------Anfang-----------------+-------+-----------
//   1.0 |            | 1.Erstellung mit Westmount-OMT         |     0 |
// ======================================Ende======================================
#ifndef _SERVERITCIOHANDLER_H_
#define _SERVERITCIOHANDLER_H_

// Vorwaerts-Deklaration der Eigenen Klasse
class ServerItcIOHandler;

// System-Include-Files
#ifndef _TYPES_HXX_
#include <Types.hxx>
#endif

#include <BreakPoint.hxx>

// Vorwaerts-Deklarationen :
class ServerItcIOHandler;
class itcConnection;
class MsgItcDispatcher;

// ========== ServerItcIOHandler ============================================================
class DLLEXP_MANAGER ServerItcIOHandler : public itcIOHandler 
{
  public:
    // Konstruktor
    ServerItcIOHandler(itcConnection *conn);
    
    // Destruktor
    virtual ~ServerItcIOHandler();

    // inputReady des Basissocket ruft accept, um einen neuen Socketdeskriptor 
    // (itcConnection *conn) f�r den Peer zu erhalten. Die Callback-Funktion wird
    // ausgeloest, da ein Connect-Aufruf eines Client erfolgte. Der Socketdeskriptor
    // wird mit einem PeerItcIOHandler im Dispatcher verkn�pft.
    virtual int inputReady(itcConnection *conn, char *data);
    // Not used
    virtual int outputReady(itcConnection *conn, char *data);
    // Not used
    virtual int exeptionRaised(itcConnection *conn, char *data);
    // Not used
    virtual void timerExpired(long sec, long usec) override;
    
    const itcConnection *getConnect() const;
    itcConnection *getConnect();

    
  private:
    itcConnection  *connectPtr;
};


inline const itcConnection * ServerItcIOHandler::getConnect() const
{
  return connectPtr;
}


inline itcConnection * ServerItcIOHandler::getConnect()
{
  return connectPtr;
}





#endif /* _SERVERITCIOHANDLER_H_ */
