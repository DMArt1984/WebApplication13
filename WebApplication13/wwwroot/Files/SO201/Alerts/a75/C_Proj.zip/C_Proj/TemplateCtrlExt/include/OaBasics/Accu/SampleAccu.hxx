#ifndef _SAMPLEACCU_H_
#define _SAMPLEACCU_H_

#ifndef _SIMPLEACCU_H_
#include <SimpleAccu.hxx>
#endif

#ifndef _VARIABLE_H_
#include <Variable.hxx>
#endif

#ifndef _TIMEVAR_H_
#include <TimeVar.hxx>
#endif

// ========== SampleAccu ============================================================

/** the sample accumulator class
    @n This class implements a statistic accumulator to determine the first value (sample) within a period.
    An internal value is checked every time when the accumulate function is called.
    @classification ETM internal
*/
class DLLEXP_OABASICS SampleAccu: public SimpleAccu
{
  public:
    /// constructor
    /// @param aVarType the type of variable for accu
    SampleAccu(const VariableType aVarType);

    /// virtual destructor
    virtual ~SampleAccu();
    
    /// process a new value
    /// @param theValue the value to process
    /// @param atTime the time of the processing
    virtual void accumulate(const Variable &theValue, const TimeVar &atTime );

    /// get result
    /// @return the result
    virtual const Variable &getResult();

    /// get intermediate result
    /// @return the intermediate result
    virtual const Variable &getIntermResult(  const Variable &theValue, const TimeVar &/*start*/, 
                                                     const TimeVar &/*stop*/, bool /*valid*/ );
    
    /// reset internal values
    virtual void reset();
    
  protected:
  
  private:
    SampleAccu(const SampleAccu &);
    SampleAccu &operator=(const SampleAccu &);
  
    Variable *sample;					// Begin value returned
};

#endif
