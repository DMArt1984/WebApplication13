// DATEIBESCHREIBUNG ==============================================================
// DATEINAME:     DpMsgValueChange.hxx
// VERANTWORTUNG:	Johannes Ertl
// BESCHREIBUNG:	DpMsgValueChange ist die Aenderungsmeldung, es koenne beliebig
//                 viele Aenderungen in einer Nachricht enthalten sein.
//                 Alle Wertaenderungen einer Konfiguration werden zu einer Gruppe
//                 zusammengefasst (DpVCGroup) - mit einer Ausnahme: Lockattribute
//                 kommen in eine eigene Gruppe.
//                 
//                 Legt man eine DpMsgValueChange an, so muss man sich nicht um das
//                 anlegen der Gruppen kuemmern, das tut automatisch die Methode
//                 "insertValueChange".
// 		
//
// AENDERUNGS-HISTORIE
// Ver.  | Datum      | Aenderungen                            | ModNr.| Autor
// ------+------------+-----------------Anfang-----------------+-------+-----------
//   1.0 |            | 1.Erstellung mit Westmount-OMT         |     0 |
// ======================================Ende======================================
#ifndef _DPMSGVALUECHANGE_H_
#define _DPMSGVALUECHANGE_H_

// Vorwaerts-Deklaration der Eigenen Klasse
class DpMsgValueChange;

// ========== DpMsgValueChangePtr ============================================================

typedef DpMsgValueChange* DpMsgValueChangePtr;

#include <ostream>
#include <DpMsg.hxx>

// Vorwaerts-Deklarationen :
class DpMsgValueChange;
class DpVCGroup;
class ManagerIdentifier;

// ========== DpMsgValueChange ============================================================

/** The value change message. The message may contain many value changes, summarized to a group (DpVCGroup),
    with one exception - lock attributes are in a distinct group.
    @n If a DpMsgValueChange is going to be used, it is not needed to care about the groups. It will be done
    automatically, using the function insertValueChange().
*/
class DLLEXP_MESSAGES DpMsgValueChange : public DpMsg 
{
  // Operatoren :

  /// operator << for itcNdrUbSend stream
  /// @param ndrStream the stream, which to send to
  /// @param msg the DpMsgValueChange message
  friend DLLEXP_MESSAGES itcNdrUbSend &operator<<(itcNdrUbSend &ndrStream, const DpMsgValueChange &msg);

  /// operator >> for itcNdrUbReceive stream
  /// @param ndrStream the stream, which to receive from
  /// @param msg the DpMsgValueChange message
  friend DLLEXP_MESSAGES itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream, DpMsgValueChange &msg);

  public:

  /// constructor, initialisation with zero values
  DpMsgValueChange();

  /// param constructor
  /// @param newDestination the ManagerIdentifier of new destination
  /// @param answer the answer flag
  DpMsgValueChange(const ManagerIdentifier &newDestination, PVSSboolean answer);

  /// destructor
  virtual ~DpMsgValueChange();

  /// send debug info to output stream
  /// @param to the output stream
  /// @param level the debug level
  virtual void debug(std::ostream &to, int level) const;

  /// comparison operator ==
  /// @param rVal the DpMsgValueChange to compare with
  /// @return 0 if not equal else 1
  int operator==(const DpMsgValueChange &rVal) const;

  /// comparison operator !=
  /// @param rVal the DpMsgValueChange to compare with
  /// @return 1 if not equal else 0
  int operator!=(const DpMsgValueChange &rVal) const {return !operator==(rVal);}

  /// assignment operator for DpMsgValueChange
  /// @param rVal the DpMsgValueChange to assign
  /// @return the resulting DpMsgValueChange
  DpMsgValueChange &operator=(const DpMsgValueChange &rVal);

  // Spezielle Methoden :

  /// get needs answer flag
  virtual PVSSboolean needsAnswer() const;
  
  /// set needs answer flag
  /// @param answer the value to set
  void setWantAnswer(PVSSboolean answer) { wantAnswer = answer; }
  
  /// set iterator on the first group
  /// @return the first group
  virtual DpVCGroup *getFirstGroup() const = 0;
  
  /// set iterator to the next group
  /// @return the next group
  virtual DpVCGroup *getNextGroup() const = 0;

  /// remove a group
  /// @param g the group to remove
  /// @return if g == lastAccessed then g.getNext() else lastAccessed
  virtual DpVCGroup *removeGroup(DpVCGroup *g) = 0;

  /// get own DP message type, always DP_MSG_VALUECHANGE
  virtual MsgType isA() const {return DP_MSG_VALUECHANGE;};

	/// check if own DP message type matches other DP message type
  /// @param dpMsgType the MsgType to check
  /// @return DpMsgValueChange type if argument is DpMsgValueChange else a DP message type
  virtual MsgType isA(MsgType dpMsgType) const
  {return (dpMsgType == DP_MSG_VALUECHANGE ? DP_MSG_VALUECHANGE : DpMsg::isA(dpMsgType));};

  private:
  PVSSboolean wantAnswer;
};

// ================================================================================
// Inline-Funktionen :

#endif /* _DPMSGVALUECHANGE_H_ */
