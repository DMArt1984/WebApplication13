#ifndef FUNCNAMES_STRUCT_H
#define FUNCNAMES_STRUCT_H

struct FuncNamesStruct
{
  const char *name;
  PVSSulong number;
  bool allowed;       // is this a function which is allowed in "restricted mode" TFS #55838
  const char *tooltip;
};

#endif
