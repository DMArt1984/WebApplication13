#ifndef _SOCKET_H_
#define _SOCKET_H_

/*
VERANTWORTUNG: Detlef Sommer
BESCHREIBUNG: Independent implementation for sockets
*/

#ifndef _TYPES_HXX_
#include <Types.hxx>
#endif

#ifdef _WIN32
#include <winsock2.h>
typedef SOCKET PVSSsocket;
typedef sockaddr PVSSsockaddr;
typedef char PVSSsockopt;
#else
#ifdef OS_FREEBSD
  #include <sys/types.h>
  #include <sys/time.h>
#endif
#include <netdb.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <arpa/inet.h>

#ifndef INVALID_SOCKET
  #define INVALID_SOCKET (-1)
#endif
#define SOCKET_ERROR (-1)
typedef int PVSSsocket;
typedef struct sockaddr PVSSsockaddr;
typedef void PVSSsockopt;
#endif

#if defined (_WIN32)
typedef int socklen_t;
#elif defined (OS_HPUX)
typedef int socklen_t;
#elif defined (OS_LINUX)
// Kennt schon das typedef
#endif

class CharString;

//--------------------------------------------------------------------------------

/** the socket class. since sockets are a bit different under WIN32, this class is used as a
    wrapper to maintain platform independence.
*/
class DLLEXP_OABASICS Socket
{
  public:

    // all errors must be less than 0 !!!
    /// The detailed result of the last methode call.
    enum SocketCompletionCodes
    {
        /// Operation completed successfully.
      NoError            =   0,
        /// Connect is pending and comes asynchronous.
      InProgress         =   1,
        /// Nothing could be done to recover from this error. This is really fatal.
      SystemError        =  -1,
        /** Such errors could be caused by wrong configuration. (e.g. port number in invalid range)
            this class makes a difference between SystemError and ConfigError, but for the
            above layers it is for the moment the same (both set to -1).
            It might be possible for the future that the above layer must differ the error cases.
        */
      ConfigError        =  -1,
        /// For such error it could help to try it again later.
      ResourceError      =  -3,
        /// Peer has closed the connection.
      PeerClosed         =  -4, 
        /** There is no event pending on the socket. Only the upper layer can decide if this is an
            error or not (we return PVSS_FALSE in that case).
        */
      NoEvent            =  -5,
        /** These error types are errors, which indicate that a socket is unusable. (e.g. reset by peer).
            In that case a reconnect may help.
        */
      NetworkError       =  -6,
        /// A function for a buffered socket has been called without creating the socket with a buffer.
      NoUserBuffer       =  -7,
        /// User buffer overflow.
      UserBufferOverflow =  -8,
        /// Error during select call.
      SelectError        =  -9, 
        /// Error in SSL (secure socket layer) function.
      SSLError           = -10   
    };


    /// The mask used for select.
    enum SelectMasks
    {
      /// The empty mask.
      NullMask = 0,
      /// The mask to check for avaliable data to read.
      ReadMask,
      /// The mask to check for space to write.
      WriteMask,
      /// The mask to check for errors.
      ErrorMask,
      /// The mask to check for avaliable data to read or space to write.
      ReadWriteMask,
      /// The mask to check for any event.
      AllMask
    };

    /// constructor
    Socket(PVSSboolean throwErrorsDeprecated = PVSS_FALSE);

    /// destructor
    virtual ~Socket();

    /** returns the internal socket completion code (one of the enum SocketCompletionCodes)
        When the calling function wants to take specific action for different error codes
        this function can be used to get more detailed information about the error.
        @see SocketCompletionCodes - "real" return type. For getting system error codes see
        @see getCompletionSysCode()
        @return       NoError = 0,
                      < 0 error (see enum SocketCompletionCodes).
     */
    int getCompletionCode() const;


    /** DEPRECATED - replaced by lastSockSysErr().
        @see lastSockSysErr()
        */
    static int SockErr();

    /** returns last system error code for sockets 
        ( errno on unix, WSAGetLastError() on Windows).
        */
    static int lastSockSysErr();

    /** DEPRECATED - replaced by sockSysErrString().
        @param sysErrno error code returned by lastSockSysErr()
        @return error string
        @see sockSysErrString()
        
    */
    static const CharString & SockStringErr(int sysErrno);


    /** converts system error codes for sockets into a human readable string.
        @param sysErrno error code e.g. returned by lastSockSysErr()
               or getCompletionSysCode()
        @return error string
        @see lastSockSysErr()
        @see getCompletionSysCode()
    */
    static const CharString & sockSysErrString(int sysErrno);

    /// assignment operator
    Socket &operator=(PVSSsocket fdSock);

    /// create a socket
    PVSSboolean socket(int af, int type, int protocol);

    /** bind a socket
        @param host name of the host
        @param port port number to bind the socket to
        @return PVSS_TRUE for success
                PVSS_FALSE for error
    */
    PVSSboolean bind(const CharString &host, unsigned short port);

    /** listen on a socket
        @param backlog number of pending connect requests without accept
        @return PVSS_TRUE for success
                PVSS_FALSE for error
    */
    PVSSboolean listen(int backlog);

    /** connect to a server
        @param host name of the server
        @param port port number to bind the socket to
        @return 1 for success
                2 for pending
                0 for error
    */
    virtual PVSSuchar connect(const CharString &host, unsigned short port);

    /** accept a connection from a client
        @param host returns the hostname of the client
        @param port returns the peer port number
        @param [out] newSock the socket for the real work.
        @return PVSS_TRUE for success
                PVSS_FALSE for error
    */
    virtual PVSSboolean accept(CharString &host, unsigned short &port, Socket &newSock);

    /** read from a TCP socket (calls recv with flags = 0)
        @param buf pointer to user buffer
        @param len length of user buffer
        @param byteRecv returned bytes received
        @return PVSS_TRUE for success
                PVSS_FALSE for error
    */
    PVSSboolean recv(char *buf, int len, int &byteRecv) { return recv(buf, len, 0, byteRecv); }

    /** read from a TCP socket
        @param buf pointer to user buffer
        @param len length of user buffer
        @param flags recv flags (see recv manual page) normally = 0
        @param byteRecv returned bytes received
        @return PVSS_TRUE for success
                PVSS_FALSE for error
    */
    virtual PVSSboolean recv(char *buf, int len, int flags, int &byteRecv);

    /** write to a TCP socket (calls send with flags = 0)
        @param buf pointer to user buffer
        @param len length of user data
        @param byteSend returned number of bytes send
        @return PVSS_TRUE for success
                PVSS_FALSE for error
    */
    PVSSboolean send(const char *buf, int len, int &byteSend) { return send(buf, len, 0, byteSend); }

    /** write to a TCP socket (calls send with flags = 0)
        @param buf pointer to user buffer
        @param len length of user data
        @param flags send flags (see send manual page) normally = 0
        @param byteSend returned number of bytes send
        @return PVSS_TRUE for success
                PVSS_FALSE for error
    */
    virtual PVSSboolean send(const char *buf, int len, int flags, int &byteSend);

    /** read from a UDP socket
        @param buf pointer to user buffer
        @param len length of user buffer
        @param flags recvfrom flags (see recvfrom manual page) normally = 0
        @param host sender hostname
        @param port returns sender port number
        @param byteRecv returned bytes received
        @return PVSS_TRUE for success
                PVSS_FALSE for error
    */
    virtual PVSSboolean recvfrom(char *buf, int len, int flags, CharString &host, unsigned short &port,
                                 int &byteRecv);

    /** write to an UDP socket
        @param buf pointer to user buffer
        @param len length of user data
        @param flags sendto flags (see sendto manual page) normally = 0
        @param host receiver hostname
        @param port receiver port number
        @param byteSend returnes bytes sent
        @return PVSS_TRUE for success
                PVSS_FALSE for error
    */
    virtual PVSSboolean sendto(const char *buf, int len, int flags, const CharString &host, unsigned short port,
                               int &byteSend);
    /// close a socket
    virtual void close();

    /// shutdown output
    void  shutdownOutput();


    /// get the socket descriptor
    PVSSsocket getFd() const { return fd; }

    /// set the socket descriptor
    virtual void setFd(PVSSsocket newFd);

    /// check if socket is valid
    PVSSboolean isValid() const { return (fd != INVALID_SOCKET); }

    /// set the blocking mode of the socket Blocking = TRUE or Blocking = FALSE
    PVSSboolean setBlocking(PVSSboolean block);

    /// set the socket inheritable
    PVSSboolean setInheritable(PVSSboolean inherit);

    /// get the inheritable flag
    PVSSboolean getInheritable(PVSSboolean &inherit) const;

    /** set socket linger mode
        @param linger true switch linger on and false switches linger off
        @param lingerTimeout linger timeout
        @return PVSS_TRUE for success
                PVSS_FALSE for error
    */
    PVSSboolean setLinger (PVSSboolean linger, int lingerTimeout = 0);

    /** get socket linger mode
        @param linger returns linger mode
        @param lingerTimeout returns linger timeout
        @return PVSS_TRUE for success
                PVSS_FALSE for error
    */
    PVSSboolean getLinger (PVSSboolean &linger, int &lingerTimeout);

    /// set Keepalive
    PVSSboolean setKeepAlive (PVSSboolean keepAlive);
    /// get Keepalive
    PVSSboolean getKeepAlive (PVSSboolean &keepAlive);

    /// set Reuseaddress
    PVSSboolean setReuseAddress (PVSSboolean reuseAddress);
    /// get Reuseaddress
    PVSSboolean getReuseAddress (PVSSboolean &reuseAddress);

    /** disables the Nagle algorithmus
        This option should be used with care because it could lead to higher
        network traffic.
        It is in general usefull when tiny packets have to be send and they
        they should not be delayed by grouping several tiny packets together.
        Per default the Nagle algorithmus is enabled.
        @param tcpNoDelay PVSS_TRUE if it should be switched on and
                          PVSS_FALSE to switch it off
        @return PVSS_TRUE success
                PVSS_FALSE error
    */
    PVSSboolean setTcpNoDelay (PVSSboolean tcpNoDelay);

    /// read the TCP_NODELAY setting
    PVSSboolean getTcpNoDelay (PVSSboolean &tcpNoDelay);

    /// Set the IPV6_V6ONLY setting
    PVSSboolean setIPv6Only(PVSSboolean ipv6Only);

    /// Read the IPv6_V6ONLY setting
    PVSSboolean getIPv6Only(PVSSboolean &ipv6Only);


    /// get peer name
    PVSSboolean getPeername (CharString &host, unsigned short & port);

    /// get socket name
    PVSSboolean getSockname (CharString &host, unsigned short & port);

    /** check if there is something for us on the file descriptor
        @param mask determines which types should be checked (see SelectMask enum)
              and return the kind of pending event.
        @param timeoutMs  timeout in milliseconds
        @return PVSS_TRUE for success
                PVSS_FALSE for error
    */
    PVSSboolean select(enum SelectMasks &mask, int timeoutMs);

    
    /** get platform dependent last system error code
          @return int system error code from errno or WSAGetLastError()
          @see getCompletionSysCodeString()
    */
    int getCompletionSysCode() const;


    /** get the string representation of last socket system error
          @return string representation of last (socket-) system error
          @see getCompletionSysCode()
    */
    const CharString & getCompletionSysCodeString(void) const;
    // { return sockStringSysErr( getCompletionSysCode() ); };

    /// return true, if socket is secured (e.g. https connection); default: false
    virtual PVSSboolean isSecured() const { return PVSS_FALSE; }

  protected:
    /// Setup the content in struct sockaddr.
    ///
    ///   @param [in] host the hostname or its IP-address.
    ///   @param [in] port the portnumber.
    ///   @param [out] addr the address useable for socketoperations.
    ///   @param [in, out] size the avaliable size in addr and realy used.
    ///   @return true when the address could be build, false otherweise.
    PVSSboolean setAddr(const CharString &host, unsigned short port, struct sockaddr * addr, int &size);

    /** converts the socket structure into a hostname and port.
        @param addr pointer to socket structure
        @param len  length of socket structure
        @param host reference for host name
        @param port reference for port
        @return PVSS_TRUE for success
                PVSS_False for failure
    */
    PVSSboolean setName(const struct sockaddr * addr, socklen_t len, CharString &host, unsigned short &port);

    /** sets the completion code as well as the system completion code for subsequent calls of
        getCompletionCode() and getCompletionSysCode().
        @param cc     one of enum SocketCompletionCodes
        @see SocketCompletionCodes
        @see getCompletionCode()
        @see getCompletionSysCode()
    */
    void setCompletionCode( SocketCompletionCodes cc );

    /// The qualified error.
    enum SocketCompletionCodes completionCode_;

    /// The filehandle for the socket.
    PVSSsocket fd;

  private:
    // so that the compiler does not define them itself !!

    // copy constructor
    Socket(const Socket &) {}   //COVINFO LINE: defensive (AP: disallow copy ctor)
    // assignment operator
    Socket &operator=(const Socket &) { return *this; } //COVINFO LINE: defensive (AP: disallow =operator)

    //------------------------- DEPRECATED methods BEGIN -----------------------

public:
    /** DEPRECATED - replaced by setBlocking()
        @see setBlocking()
        */
    PVSSboolean nonBlockingMode(const PVSSboolean aMode) {return setBlocking(!aMode);}

    /// define whether errors shall be thrown to ErrHdl automatically
    void setThrowErrors(PVSSboolean th) { throwErrors_ = th; }

    /** DEPRECATED - use variant with programmer-friendly parameters !
        @see bind()
        */
    PVSSboolean bind(const PVSSsockaddr * addr, int addrlen);

    /** DEPRECATED - use variant with programmer-friendly parameters !
        @see connect()
        */
    PVSSuchar connect(const PVSSsockaddr * addr, int addrlen);

    /** DEPRECATED - use variant with programmer-friendly parameters !
        @see accept()
        */
    PVSSboolean accept(PVSSsockaddr *addr, int *addrlen, Socket &newSock);

    /** DEPRECATED - use variant with programmer-friendly parameters !
        @see recvfrom()
        */
    PVSSboolean recvfrom(char *buf, int len, int flags,
                         PVSSsockaddr *addr, int *alen, int &byteRecv);

    /** DEPRECATED - use variant with programmer-friendly parameters !
        @see sendto()
        */
    PVSSboolean sendto(const char *buf, int len, int flags,
                       const PVSSsockaddr *addr, int alen, int &byteSend);

    /// DEPRECATED - please use getxxx
    PVSSboolean getsockopt(int level, int optname,
                           PVSSsockopt *optval, int *optlen);

    /// DEPRECATED - please use setxxx
    PVSSboolean setsockopt(int level, int optname,
                           const PVSSsockopt *optval, int optlen);

    //------------------------- DEPRECATED methods END -------------------------

private:
    PVSSboolean throwErrors_;   // shall we throw errors to ErrHdl

    int completionSysCode_;
	
   friend class UNIT_TEST_FRIEND_CLASS;
};

#endif /* _SOCKET_H_ */
