#ifndef _DIAGCONFIGANDDPITCIOHANDLER_H_
#define _DIAGCONFIGANDDPITCIOHANDLER_H_

#include <DiagItcIOHandler.hxx>

/*
VERANTWORTUNG: Andreas Pfluegl
BESCHREIBUNG: 
*/


/** the DiagItcIOHandler class is a Timer-Object that writes some PVSS-Resource Counter
  * to a DP of the type _Statistics.
  * once the Timer is started by the Manager-Class it restarts itself periodically
  * 
  * @classification internal use
  */
class DLLEXP_MANAGER DiagConfigAndDpItcIOHandler : public DiagItcIOHandler 
{
  public:
    DiagConfigAndDpItcIOHandler() {}

    virtual ~DiagConfigAndDpItcIOHandler() {}

    virtual void timerExpired(long sec, long usec) override;

	private:
};


#endif /* _DIAGCONFIGANDDPITCIOHANDLER_H_ */
