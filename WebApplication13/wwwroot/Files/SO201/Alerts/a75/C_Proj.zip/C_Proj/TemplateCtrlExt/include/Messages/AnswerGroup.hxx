// DATEIBESCHREIBUNG ==============================================================
// DATEINAME:		AnswerGroup.hxx
// VERANTWORTUNG:	Thomas Exner
// 
// BESCHREIBUNG:	Die AnswerGroup gibt Auskunft, ob die zugehoerige Gruppe der zu
//					beantwortenden Message gut gegangen ist (Methode: wasOk()). Im
//					Fehlerfall liefert getError() einen gueltigen Ptr auf eine
//					ErrClass, welche eine Fehlerbeschreibung enthaelt
//					(evtl. spaeter bei Bedarf auf ErrClass umstellen). Im
//					einfachsten Fall kann also diese ErrClass an den lokalen
//					ErrorHandler uebergeben werden.
//					Manche Antworten muessen noch mehr als die Aussage Ok/Fehler
//					enthalten. Zu diesem Zweck besitzt die Klasse eine PtrList von
//					AnswerItems (siehe dort), welche halt bei Bedarf mit insertItem()
//					zu fuellen ist.

#ifndef _ANSWERGROUP_H_
#define _ANSWERGROUP_H_

// Vorwaerts-Deklaration der Eigenen Klasse
class AnswerGroup;

// ========== AnswerGroupPtr ============================================================

typedef AnswerGroup* AnswerGroupPtr;

#include <ostream>
#include <AlertList.hxx>
#include <AnswerItem.hxx>
#include <ErrClass.hxx>
#include <TimeVar.hxx>

// Vorwaerts-Deklarationen :
class DpVCItem;
class DpHLGroup;

#ifdef WIN32
#pragma warning ( disable: 4231 )
#endif

#if defined(LIBS_AS_DLL)
EXTERN_MESSAGES template class DLLEXP_MESSAGES DynPtrArray<AnswerItem>;
#endif

#ifdef WIN32
#pragma warning ( default: 4231 )
#endif


// ========== AnswerGroup ============================================================

/** The AnswerGroup class.
  It gives information whether the referenced message was handled successfuly
  and may contain additional information as the values of dpGet call. 
  Datapoint values are stored as AnswerItem objects, alert values as AlertAttrList objects.
  Both types of values are accessed by different functions. Usually API developer deal 
  with datapoint values, i.e. AnswerItems only.
 */
class DLLEXP_MESSAGES AnswerGroup : public PtrListItem
{
  friend class DpHLGroup;

  public:

    /// constructor
    /// @param errorPtr the optional error object if an error occured
    AnswerGroup(ErrClass *errorPtr = 0);

    /// copy constructor
    /// @param group the AnswerGroup to copy
    AnswerGroup(const AnswerGroup &group);

    /// destructor
    ~AnswerGroup();

    // Operatoren :

    /// operator << for itcNdrUbSend stream
    /// @param ndrStream the stream, which to send to
    /// @param group the AnswerGroup
    friend DLLEXP_MESSAGES itcNdrUbSend &operator<<(itcNdrUbSend &ndrStream, const AnswerGroup &group);

    /// operator >> for itcNdrUbReceive stream
    /// @param ndrStream the stream, which to receive from
    /// @param group the AnswerGroup
    friend DLLEXP_MESSAGES itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream, AnswerGroup &group);

    /// comparison operator ==
    /// @param rVal the AnswerGroup to compare with
    /// @return 0 if not equal else 1
    int operator==(const AnswerGroup &rVal) const;
  
    /// assignment operator for AnswerGroup
    /// @param rVal the AnswerGroup to assign
    /// @return the resulting AnswerGroup
    AnswerGroup &operator=(const AnswerGroup &rVal);

    // Spezielle Methoden :
  
    /// check if the referenced message was handled successfuly
    /// @return PVSS_TRUE if there was no error, PVSS_FALSE if it contains an ErrClass object
    /// @classification public use, call
    PVSSboolean wasOk() const {return (error == 0);};
  
    /// get the ErrClass object
    /// @n This object can then be used as an argument to a call to ErrHdl::error.
    /// @return the pointer to the error object, the error object shall not be deleted
    ErrClass *getErrorPtr() const {return error;};
  
    /// get the ErrClass object (old function call)
    /// @n This object can then be used as an argument to a call to ErrHdl::error.
    /// @return the pointer to the error object, the error object shall not be deleted
    ErrClass  *getError() const {return getErrorPtr();}

    /// set the ErrClass object
    /// @n This object can then be used as an argument to a call to ErrHdl::error.
    /// @param errorPtr the pointer to the error object to set
    void setErrorPtr(ErrClass *errorPtr);
  
    /// set the ErrClass object (old function call)
    /// @n This object can then be used as an argument to a call to ErrHdl::error.
    /// @param errorPtr the pointer to the error object to set
    void setError(ErrClass *errorPtr) {setErrorPtr(errorPtr);}

    /// insert a new item to the group
    /// @param id the DpIdentifier to insert
    /// @param value the pointer to a Variable object which holds the value
    /// @n The call takes ownership of this pointer.
    /// @param time the time stamp
    /// @param newType the type of the new item
    /// @return PVSS_TRUE if success else PVSS_FALSE
    PVSSboolean insertItem(const DpIdentifier &id, Variable *value = 0, const TimeVar &time = TimeVar(0, 0), 
                           AnswerItem::ItemType newType = AnswerItem::EVENT);
  
    /// insert a new item to the group
    /// @param id the DpIdentifier to insert
    /// @param value the Variable object which holds the value
    /// @param time the time stamp
    /// @param newType the type of the new item
    /// @return PVSS_TRUE if success else PVSS_FALSE
    PVSSboolean insertItem(const DpIdentifier &id, const Variable &value, const TimeVar &time = TimeVar(0, 0),
                           AnswerItem::ItemType newType = AnswerItem::EVENT);

    /// @name Access datapoint values
    //@{
    
    /// get a pointer to the first AnswerItem or 0, if the list is empty
    AnswerItem *getFirstItem() const {if (!list.isSortArray()) ((AnswerGroup *)this)->list.sort();
      return (AnswerItem *) list.getFirst();};
    
    /// get a pointer to the laste AnswerItem or 0, if the list is empty
    AnswerItem *getLastItem() const {if (!list.isSortArray()) ((AnswerGroup *)this)->list.sort();
      return (AnswerItem *) list.getLast();};
   
    /// get a pointer to the next AnswerItem or 0, if there are no more items
    AnswerItem *getNextItem() const {return (AnswerItem *) list.getNext();};
  
    /// get the number of AnswerItems in the list
    unsigned int getNrOfItems() const { return list.getNumberOfItems(); }

    /// delete all AnswerItems in the list
    void clearItemList() {list.clear();};
    //@}

    /// sort the AnswerItems in the list
    void sort() { if (!list.isSortArray()) list.sort(); }

    /// @name Access alert values
    //@{

    /// get first AlertAttrList item or 0 if the list is empty
    AlertAttrList *getFirstAAList() const {return aList.getFirstAttrList();}

    /// get next AlertAttrList item or 0 if there are no more items
    AlertAttrList *getNextAAList() const {return aList.getNextAttrList();}

    /// insert a new AlertAttribute to the group
    /// @param identifier the AlertIdentifier to insert
    /// @param valuePtr the pointer to a Variable object which holds the value
    /// @return PVSS_TRUE if success else PVSS_FALSE
    PVSSboolean insertAlertAttribute(const AlertIdentifier &identifier, Variable *valuePtr)
      {return aList.insertAttribute(identifier, valuePtr);}

    /// get the alert list
    const AlertList &getAlertList() const { return aList; }

    /// get the alert list
    AlertList &getAlertList() {return aList;}
    //@}

    /// send debug info to output stream
    /// @param to the output stream
    /// @param level the debug level
    void debug(std::ostream &to, int level) const;

  private:
      DynPtrArray<AnswerItem> list;
      ErrClass *error;
      AlertList aList;
      unsigned long serial; // for Items with the same time
};

// ========== inline-functions ============================================================
// Konstruktor
inline AnswerGroup::AnswerGroup(ErrClass *errorPtr)
  : PtrListItem(),
  error(errorPtr),
  aList(),
serial(0)
{
  list.setCompareFunction(&AnswerItem::cmp);
}

// Copy-Konstruktor
inline AnswerGroup::AnswerGroup(const AnswerGroup &group)
  : PtrListItem(),
  error(0),
  aList(),
serial(0)
{
  list.setCompareFunction(&AnswerItem::cmp);
  operator=(group);
}

// Destruktor
inline AnswerGroup::~AnswerGroup()
{
  delete error;
}

#endif /* _ANSWERGROUP_H_ */


