#ifndef _EnumClass_H_
#define _EnumClass_H_

#include <UserType.hxx>
#include <IntegerVar.hxx>
class CtrlVarList;

// 8.11.2015 MK: A class holding the defintion of an enum type
// I only allow named enum classes (as in C++11), and the user
// can use them like Name::EnumValue
// @classification internal use

class DLLEXP_CTRL EnumClass : public UserType
{
  public:
    EnumClass(CharString *theName, int lineNum, int fileNum);

    virtual ~EnumClass();

    virtual bool isA(Type type) const { return type == ENUM_TYPE; }

    void setItems(CtrlVarList &list);

    const IntegerVar *getValue(const CharString &theName) const;

    virtual ClassVar *createInstance(bool doRefCount) const;

    bool contains(const IntegerVar &value) const;

    struct Item
    {
      Item() : name(0), value(0), next(0) { }
      ~Item() { delete name; delete value; }

      // capture the pointer from the parser (avoid memcpy)
      CharString *name;

      // value is a pointer which can be 0 in parsing a definition
      // which does not set the initial value. In ctor of EnumClass
      // these values will automatically be given the next int value
      IntegerVar *value;

      Item *next;
    };

    const Item *getItems() const { return items; }

  private:
    class EnumClassPrivate *d;
    Item *items;
};

#endif
