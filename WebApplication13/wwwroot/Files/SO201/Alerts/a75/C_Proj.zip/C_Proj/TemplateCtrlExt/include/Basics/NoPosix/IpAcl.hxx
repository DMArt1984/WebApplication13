#ifndef _IP_ACL_H_
#define _IP_ACL_H_

#include <AccessControlList.hxx>

#ifndef _WIN32
#  include <arpa/inet.h>
#endif

/** 
    @class IpAcl
    This implements an access control list for checking against ip numbers and names.
    First check is against the IP number, then against all defined hostnames (official and aliases)
    Matching is done using the PatternMatch::patternMatch() function.

    @classification ETM internal use
*/

//  Author: Martin Koller

//---------------------------------------------------------------

class DLLEXP_BASICS IpAcl : public AccessControlList
{
  public:

    /**
        Constructor: Uses given keyword-prefix for reading of the configuration file.
        
        The keyword is defined and used as follows :
         - keyword_allow ( "ip_allow" for keyword="ip" ) defines all allowed IP adresses.
         - keyword_deny  ( "ip_deny" for keyword="ip" ) defines all not permitted IP adresses.
        
        @param  keyword The keyword prefix in config file. 
    */
    IpAcl(const char* keyword = "ip");

    /**
       Checks if the given IP address is an allowed one
    
       @param  addr    The IP address to be tested. 
       @return true if IP address is allowed, otherwise false. 
    */
    bool accessAllowed(const struct sockaddr &addr);
};

//---------------------------------------------------------------
//---------------------------------------------------------------

/** 
    @class IpAclItem
    IpAcl helper class which implements the matching function.

    @classification ETM internal use
*/

class DLLEXP_BASICS IpAclItem : public AclItem
{
  public:
     /**
        Default constructor
     */
     IpAclItem();

     /**
        Default destructor
     */
    virtual ~IpAclItem();

    /**
       Copies all the aliases for the given address into the internal structure.
    
       @param  addr    The socket address structure. 
       @return bool    true if things were OK, else false (e.g. DNS failure, etc.) 
    */
    bool setAddress(const struct sockaddr &addr);

    /**
       The matching function uses PatternMatch::patternMatch()
    
       @param  pattern    The IP address pattern. 
       @return true if IP address is allowed, otherwise false. 
    */
    virtual bool matches(const CharString &pattern) const;

  private:
    CharString ip_;      // ip address in "numbers-and-dot" notation
    unsigned numNames_;  // number of aliases
    CharString *names_;  // list of aliases; [0] ... official hostname
	
   friend class UNIT_TEST_FRIEND_CLASS;
};

#endif /* _IP_ACL_H_ */
