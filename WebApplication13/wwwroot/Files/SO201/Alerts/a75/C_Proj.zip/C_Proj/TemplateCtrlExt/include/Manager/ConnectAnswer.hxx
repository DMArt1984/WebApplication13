#ifndef _CONNECTANSWER_H_
#define _CONNECTANSWER_H_
// DATEIBESCHREIBUNG ==============================================================
// VERANTWORTUNG: Thomas Exner
// BESCHREIBUNG:  Wandelt die Antwort auf ein dp(alert)Connect in einen HotLink
//                und schickt diesen an sich selbst
// ======================================Ende======================================

#include <ManagerIdentifier.hxx>
#include <WaitForAnswer.hxx>

class DpMsgAnswer;

/** helper class. converts a connect answer message to an internally used hotlink message
    @classification ETM internal
*/
class DLLEXP_MANAGER ConnectAnswer : public WaitForAnswer
{
public:
	virtual void callBack(DpMsgAnswer &answer);
};

#endif /* _CONNECTANSWER_H_ */
