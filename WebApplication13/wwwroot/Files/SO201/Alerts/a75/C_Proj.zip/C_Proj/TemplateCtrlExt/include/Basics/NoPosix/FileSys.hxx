#ifndef _FILESYS_H_
#define _FILESYS_H_

/*
VERANTWORTUNG: Guenter Szolderits / wklebel 4.3.03
BESCHREIBUNG: wrapper class for file system related functions
*/

#include <FileSysSlim.hxx>
#include <Types.hxx>
#include <TimeVar.hxx>
class RecVar;

//------------------------------------------------------------------------------

/** The file system wrapper. Since PVSS-II is a multi platform application, we need to
 *  abstract the different file system operations. This class mainly consists of
 *  static functions.
 */
class DLLEXP_BASICS FileSys : public FileSysSlim
{
public:
    /// constructor
  FileSys();
  /// destructor
  ~FileSys();

  /** Get file access and modification times. The result depends on the file system where
   *  the file resides, not all file systems store both, modification and access time.
   *
   *  @param [in] path a valid file name, must not be 0
   *  @param [out] accessTime on success, this variable receives the access time
   *  @param [out] modifTime on success, this variable receives the modification time
   *  @return PVSS_TRUE on success, PVSS_FALSE on error
   */
  static PVSSboolean getFileTimes(const char *path, TimeVar &accessTime, TimeVar &modifTime);

  /** Get file modification time.
   *
   *  @param fname a valid file name, must not be 0
   *  @return on success, the file modification time. on error, the return value is
   *          equal to <tt>TimeVar(0, 0)</tt>
   */
  static TimeVar getFileMTime(const char *fname);

  /** Get file access and modification times. Since not all file systems store both,
   *  access and modification time, the values set here may not be retrieved exactly.
   *
   *  @param path a valid file name, must not be 0
   *  @param accessTime the new access time for the file
   *  @param modifTime the new modification time for the file
   *  @return PVSS_TRUE on success, PVSS_FALSE on error
   */
  static PVSSboolean setFileTimes(const char *path, const TimeVar &accessTime, const TimeVar &modifTime);

  /** Get size, modification time and checksum. Since this function generates a
   *  checksum of the file's content, it needs read access to the file and has
   *  time complexity O( @e filesize ).
   *
   *  @param [in] fname a valid file name, must not be 0
   *  @param [out] stats a RecVar consisting of (in this order)
   *                       - a UIntegerVar holding the file size
   *                       - a TimeVar holding the modification time
   *                       - a TextVar holding the MD5 checksum of the file's content
   */
  static PVSSboolean getFileStats(const char *fname, RecVar &stats);
  
  /** Compare file stats (size and checksum only) of file @e fname with argument
   *  @e stats. Since this function generates a checksum of the file's content, it
   *  needs read access to the file and has time complexity O( @e filesize ).
   *  The file content is compared against the checksum in @e stats, so there is a very
   *  small (but nonzero) probability that the content's checksum matches, altough it
   *  differs from the original content, from which the checksum was generated.
   *  
   *
   *  @param fname a valid file name, must not be 0
   *  @param [out] stats a RecVar consisting of (in this order)
   *                       - a UIntegerVar holding a file size
   *                       - a TimeVar holding a modification time
   *                       - a TextVar holding an MD5 checksum of a file's content
   *  @return PVSS_TRUE when the file matches the stats with reasonable high probability,
   *          PVSS_FALSE when not
   */
  static PVSSboolean isSameFile(const char *fname, const RecVar &stats);

};

#endif /* _FILESYS_H_ */
