// DATEIBESCHREIBUNG ==============================================================
// DATEINAME:     DpIdListItem.hxx
// VERANTWORTUNG: Johannes Ertl
// BESCHREIBUNG:  Das ist fuer eine Liste von Datenpunkttypenummern
//
// AENDERUNGS-HISTORIE
// Ver.  | Datum      | Aenderungen                            | ModNr.| Autor
// ------+------------+-----------------Anfang-----------------+-------+-----------
//   1.0 |            | 1.Erstellung mit Westmount-OMT         |     0 |
// ======================================Ende======================================
#ifndef _DPIDLISTITEM_H_
#define _DPIDLISTITEM_H_

// Vorwaerts-Deklaration der Eigenen Klasse
class DpIdListItem;

// System-Include-Files
#include <DpTypes.hxx>
#include <PtrListItem.hxx>

// Vorwaerts-Deklarationen :

/// ========== DpIdListItem ============================================================
class DLLEXP_MESSAGES DpIdListItem : public PtrListItem 
{

  // Klassen-Enums:

// ..........................Anfang User-Klasseninterne-Definitionen..................
// ...........................Ende User-Klasseninterne-Definitionen...................
public:
  /// Constructor.
  DpIdListItem(DpIdType theDpId);
  /// Destructor.
  ~DpIdListItem();

  // Operatoren :

  // Spezielle Methoden :

  /// Get DpType ID.
  const DpIdType &getDpId();

  // Generierte Methoden :

protected:
private:
  DpIdType dpId;

// ............................Anfang User-Attribut-Definitionen...................
// .............................Ende User-Attribut-Definitionen....................
};

// ================================================================================
// Inline-Funktionen :

// ............................Anfang User-Inlines.................................
// .............................Ende User-Inlines..................................

inline const DpIdType &DpIdListItem::getDpId()
{
  return dpId;
}

// ................................OMT-Regeneration................................

#endif /* _DPIDLISTITEM_H_ */
