// Eine Anytype, die sich bei einer Zuweisung nichts merkt.

#ifndef  _MIXEDVAR_H_
#define  _MIXEDVAR_H_

#include <AnyTypeVar.hxx>

/** Class MixedVar
*/
//author	Christoph Theis 
class DLLEXP_BASICS MixedVar : public AnyTypeVar
{
  public:

    /** Default constructor.
        @param v Variable* Pointer.
    */
    MixedVar(Variable *v = 0) : AnyTypeVar(v) { cachedIsA = MIXED_VAR; };
 
    /** Constructor.
        @param rVal Const reference to AnyTypeVar.
    */    
    MixedVar(const AnyTypeVar &rVal) : AnyTypeVar(rVal) { cachedIsA = MIXED_VAR; }

    /** Create a new variable of type MixedVar, uses default constructor.
        @return Variable* pointer to a newly allocated instance.
    */
    virtual Variable *allocate() const { return new MixedVar(); }

    /** Create a clone of the instance (performs deep copy).
        @return Variable* pointer to a new instance.
    */
    virtual Variable *clone() const 
    {
      return new MixedVar((var) ? var->clone() : 0);
    }

    /** Return the type of the Variable.
        @return VariableType MIXED_VAR.
    */
    virtual VariableType isAUncached() const { return MIXED_VAR; }

    /** Returns the VariableType for the specified type.
        @param varType VariableType.
        @return MIXED_VAR or the type of AnyTypeVar.
    */  
    virtual VariableType isAUncached(VariableType varType) const
    {
      if (varType == MIXED_VAR)
        return varType;
      return AnyTypeVar::isAUncached(varType);
    }
    
    /** Overloaded assignment operator used for type conversions.
        @param rVal Assigned value.
        @return Variable with assigned value.
    */
    virtual Variable &operator=(const Variable &rVal)
    {
      if ( &rVal == var )
        return *this;

      setVar(0);
      return AnyTypeVar::operator=(rVal);
    }

    /** Equality operator.
        @param rVal Compared value.
        @return int 1 if the values are equal, otherwise 0. 
        @n Important: this operator checks the VariableType, so two objects are equal only if
        they also have the same class (no conversion is done; see other operators).
    */
    int operator==(const Variable &rVal) const
    {
      if (rVal.isA(MIXED_VAR) == MIXED_VAR)
        return AnyTypeVar::operator==(rVal);
      return 0;
    }
};

#endif
