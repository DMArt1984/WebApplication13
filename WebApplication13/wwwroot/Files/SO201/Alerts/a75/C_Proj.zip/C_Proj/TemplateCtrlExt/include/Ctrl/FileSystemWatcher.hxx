#ifndef _FileSystemWatcher_H_
#define _FileSystemWatcher_H_

#include <QFileSystemWatcher>
#include <CharString.hxx>

// author: Martin Koller
/** Implements watching for file/dir changes and triggering sysConnect callbacks
    @classification internal use
*/

class FileSystemWatcher : public QObject
{
  Q_OBJECT

  public:
    static FileSystemWatcher *instance();  // singleton

    bool addPath(const CharString &path);
    bool removePath(const CharString &path);

  private slots:
    void directoryChanged(const QString &path);
    void fileChanged(const QString &path);

  private:
    FileSystemWatcher();

  private:
    QFileSystemWatcher fsw;
};

#endif
