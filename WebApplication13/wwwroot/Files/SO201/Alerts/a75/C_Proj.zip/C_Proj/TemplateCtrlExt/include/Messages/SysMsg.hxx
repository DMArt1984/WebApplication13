// DATEIBESCHREIBUNG ==============================================================
// DATEINAME:     SysMsg.hxx
// VERANTWORTUNG : Gerhard Fellrieser
// BESCHREIBUNG : SysMsg ist eine Unterklasse der Msg-Klasse. Alle Systemmeldungen
// 		(Alive-Message, Shutdown-Message, Manager-Stati, ..) werden in dieser
// 		Klasse zusammengefaszt. Fuer die einzelnen Message-Typen wurden die
// 		enum-Bezeichner SysMsgType definiert.
//
// 		Die Klasse ist ein Container fuer alle Items von Sytemmeldungen.
// 	Attribute :
// 		sysMsgType : Typ der sytemmeldung z.B.: "Keep-Alive-Message"
// 		handleMsgPtr : Pointer auf einen Messagehandler vom Typ
//
// AENDERUNGS-HISTORIE
// Ver.  | Datum      | Aenderungen                            | ModNr.| Autor
// ------+------------+-----------------Anfang-----------------+-------+-----------
//   1.0 |            | 1.Erstellung mit Westmount-OMT         |     0 |
// ======================================Ende======================================
#ifndef _SYSMSG_H_
#define _SYSMSG_H_

// Vorwaerts-Deklaration der Eigenen Klasse
class SysMsg;

// ========== SysMsgType ============================================================
// Liste aller Typen von System-Messages.
enum SysMsgType {
  NO_SYS_MSG,
  KEEP_ALIVE,
  INIT_SYS_MSG,
  START_DP_INIT,
  END_DP_INIT,
  START_MANAGER,
  SHUT_DOWN_MANAGER,
  NAMESERVER_SYS_MSG,
  OPEN_SERVER,
  CLOSE_SERVER,
  LICENSE_SYS_MSG,
  RECOVERY_SYS_MSG,
  REDUNDANCY_SYS_MSG,
  DIST_SYS_MSG,
  FILETRANSFER_SYS_MSG,
  LOGIN_SYS_MSG,
  MAX_SYS_MSG
};


// Recovery subtypes
enum RecoverySubType
{
  RECOVERY_REQ_ACTIVE = 1, // Information only, we are active and want to recover. sent server --> client
  RECOVERY_REQ_PASSIVE,    // Request for recovery from passive client. sent client --> server
  RECOVERY_ABORT,          // Abort Recovery, sent client --> server or data <--> event
  RECOVERY_ACK,            // Request accepted, sent server --> client
  RECOVERY_NACK,           // Recovery temp. not possible, sent server --> client
  RECOVERY_NACK_NORETRY,   // Recovery perm. not possible, sent server --> client
  RECOVERY_NACK_SPLIT,     // Recovery not possible (system splitted), sent server --> client
  RECOVERY_END,            // Recovery ended successful, sent server --> client
  RECOVERY_FAIL            // Recovery failed, sent server --> client
};


// File transfer types
enum FileTransferSubType
{
  FILETRANSFER_LIST_REQ = 1, // Request list of files, sent client --> server
  FILETRANSFER_LIST_RESP,    // Response with file list, sent server --> client
  FILETRANSFER_SYNC_REQ,     // Request single file, sent client --> server
  FILETRANSFER_SYNC_ABORT,   // Abort transfer of single file, sent client --> server
  FILETRANSFER_SYNC_DATA,    // Response with file data, sent server --> client
  FILETRANSFER_SYNC_END,     // Transfer of single file ended successful, sent server --> cllient
  FILETRANSFER_SYNC_FAIL     // Transfer of single file failed, sent server --> client
};


// Redundancy state switch
enum RedundancySubType
{
  REDUNDANCY_ACTIVE = 1,     // Manager goes active
  REDUNDANCY_PASSIVE,        // Manager goes passive
  REDUNDANCY_REFRESH,        // Tell manager to refresh the connects to origSource
  REDUNDANCY_DISCONNECT,     // Tell event to clear all connects to origSource
  DM_START_TOUCHING,         // Tell data to start touching
  DM_STOP_TOUCHING,          // Tell data to stop touching
  REDUNDANCY_ACTIVE_REQ,     // Initiate Redu-State-Switch
  REDUNDANCY_PASSIVE_REQ     // Initiate Redu-State-Switch
};


// Messages in distributed systems
enum DistSubType
{
  DIST_SYSTEM_CONNECT = 1,    // Got connection to a system (first replica)
  DIST_SYSTEM_DISCONNECT,     // Lost connection to a system (all replicas)
  DIST_SYSTEM_ALL_DISCONNECT, // Lost connection to all systems (dist died)
  DIST_MANAGER_CONNECT,       // A manager connected to the event
  DIST_MANAGER_DISCONNECT     // A manager disconnected from the event
};


// Name service
enum NameServiceSubType
{
  /// Request the DpIdentifier for a given Dp name
  NAME_SERVICE_DPID_QUERY = 1,
  /// NOT IMPLEMENTED
  NAME_SERVICE_DPTYPE_QUERY,
  /// Response for a NAME_SERVICE_DPTYPE_QUERY
  NAME_SERVICE_DPTYPE_RESPONSE,
  /// Response for a NAME_SERVICE_DPID_QUERY
  NAME_SERVICE_DPID_RESPONSE,
  /// NOT IMPLEMENTED
  NAME_SERVICE_DPNAME_QUERY,
  /// Response for a NAME_SERVICE_DPNAME_QUERY
  NAME_SERVICE_DPNAME_RESPONSE,

  // cns system
  /// Request the display names for a given system name (like cnsGetSystemNames)
  NAME_SERVICE_CNS_SYSTEMNAMES_QUERY,
  /// Response for a NAME_SERVICE_CNS_SYSTEMNAMES_QUERY
  NAME_SERVICE_CNS_SYSTEMNAMES_RESPONSE,
  // cns view
  /// Request the names of the views existing in a given system (like cnsGetViews)
  NAME_SERVICE_CNS_VIEWS_QUERY,
  /// Response to NAME_SERVICE_CNS_VIEWS_QUERY
  NAME_SERVICE_CNS_VIEWS_RESPONSE,
  /// Request the display names for a given view path (like cnsGetViewDisplayNames)
  NAME_SERVICE_CNS_VIEW_DISPLAYNAMES_QUERY,
  /// Response to NAME_SERVICE_CNS_VIEW_DISPLAYNAMES_QUERY
  NAME_SERVICE_CNS_VIEW_DISPLAYNAMES_RESPONSE,
  /// Request the display name separators for a given view path (like cnsGetViewSeparators)
  NAME_SERVICE_CNS_VIEW_SEPARATORS_QUERY,
  /// Response to NAME_SERVICE_CNS_VIEW_SEPARATORS_QUERY
  NAME_SERVICE_CNS_VIEW_SEPARATORS_RESPONSE,
  // cns tree
  /// Request the names of the trees existing in a given view (like cnsGetTrees)
  NAME_SERVICE_CNS_TREES_QUERY,
  /// Response to NAME_SERVICE_CNS_TREES_QUERY
  NAME_SERVICE_CNS_TREES_RESPONSE,
  // cns nodes
  /// Request the paths of the child nodes of a given node (like cnsGetChildren)
  NAME_SERVICE_CNS_CHILDREN_QUERY,
  /// Response to NAME_SERVICE_CNS_CHILDREN_QUERY
  NAME_SERVICE_CNS_CHILDREN_RESPONSE,
  /// Request the display names of a given node (like cnsGetDisplayNames)
  NAME_SERVICE_CNS_DISPLAYNAMES_QUERY,
  /// Response to NAME_SERVICE_CNS_DISPLAYNAMES_QUERY
  NAME_SERVICE_CNS_DISPLAYNAMES_RESPONSE,
  /// Request the CNSDataIdentifier stored in the given node (like cnsGetId)
  NAME_SERVICE_CNS_ID_QUERY,
  /// Response to NAME_SERVICE_CNS_ID_QUERY
  NAME_SERVICE_CNS_ID_RESPONSE,
  // cns queries
  /// Request the CNSDataIdentifiers stored in the nodes that match
  /// the specified search criteria (like cnsGetIdSet)
  NAME_SERVICE_CNS_IDSET_QUERY,
  /// Response to NAME_SERVICE_CNS_IDSET_QUERY
  NAME_SERVICE_CNS_IDSET_RESPONSE,
  /// Request the paths of the nodes that match the specified search criteria (like cnsGetNodesByName)
  NAME_SERVICE_CNS_NODESBYNAME_QUERY,
  /// Response to NAME_SERVICE_CNS_NODESBYNAME_RESPONSE
  NAME_SERVICE_CNS_NODESBYNAME_RESPONSE,
  /// Request the paths of the nodes that contain a CNSDataIdentifier which matches
  /// the specified search criteria (like cnsGetNodesByData)
  NAME_SERVICE_CNS_NODESBYDATA_QUERY,
  /// Response to NAME_SERVICE_CNS_NODESBYDATA_QUERY
  NAME_SERVICE_CNS_NODESBYDATA_RESPONSE
};



// Lizenzmessages
enum LicenseSubType
{
  LICENSE_OPTION_REQUEST = 1,  // License request
  LICENSE_OPTION_RESPONSE      // License response
};

// UserChange subtypes
enum LoginSubType
{
  LOGIN_REQ = 1,     // request a challenge / response handshake
  LOGIN_CHALLENGE,   // SSA Challenge response
  LOGIN_RESPONSE,    // SSA Response to prev Challenge
  LOGIN_SYNC,        // active Event syncs session binding with his passive peer
  LOGIN_NACK,        // login failed
  LOGIN_ACK          // login succeded
};

// System-Include-Files
#include <Msg.hxx>
#include <fstream>

// Vorwaerts-Deklarationen :
class ManagerIdentifier;
class SysMsg;

// ========== SysMsg ============================================================
/** The base class for all SysMsg. Most SysMsg are sent between manager to exchange
    non datapoint related information. For API developers the only relevant SysMsg is
    the NameServerSysMsg.
    <p> This class does not contain any methods that are of interest for an API developer.
    @see NameServerSysMsg
*/
class DLLEXP_MESSAGES SysMsg : public Msg
{
  public:
    /** Method returns the system message type name
     * (used for logging purpose)
     *   @param type A system message type
     *   @return const char, A system message type name string
     */
    static const char *getSysMsgTypeName(SysMsgType type);

    /** Method returns the system message subtype name
     * (used for logging purpose)
     *   @param type A system message type
     *   @param subType A system message subtype
     *   @return const char, A system message subtype name string
     */
    static const char *getSysMsgSubTypeName(SysMsgType type, PVSSuchar subType);

  public:
    /// Default constructor
    SysMsg();

    /** Copy constructor
     *   @param newDestination a message destination identifier
     *   @param type A message type
     *   @param subType A message subtype
     */
    SysMsg(const ManagerIdentifier &newDestination, SysMsgType type = NO_SYS_MSG, PVSSuchar subType = 0);

    /** Copy constructor
        @param newMsg An instance of the message to be copied from
     */
    SysMsg(const SysMsg &newMsg);

    /// Destructor
    virtual ~SysMsg();

    // Operatoren :

   /** BCM output streaming operator.
    *
    *  @param [in,out] ndrStream the BCM output stream
    *  @param sysMsg The SysMsg object to stream over BCM
    *  @return ndrStream
    *
    */
    friend DLLEXP_MESSAGES itcNdrUbSend &operator<<(itcNdrUbSend &ndrStream, const SysMsg &sysMsg);

   /** BCM input streaming operator. All properties found in the stream replace the
    *  corresponding propertiess in the SysMsg
    *
    *  @param [in,out] ndrStream the BCM input stream
    *  @param [out] sysMsg The SysMsg object to receive from BCM
    *  @return ndrStream
    */
    friend DLLEXP_MESSAGES itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream, SysMsg &sysMsg);

   /** Output streaming operator.
    *
    *  @param [in,out] ofStream the output stream
    *  @param sysMsg A reference to a SysMsg object to stream over BCM
    *  @return ndrStream
    *
    */
    friend DLLEXP_MESSAGES std::ostream &operator<<(std::ostream &ofStream, const SysMsg &sysMsg);

   /** Output streaming operator.
    *
    *  @param [in,out] ofStream the output stream
    *  @param sysMsgPtr A pointer to a SysMsg object to stream over BCM
    *  @return ndrStream
    *
    */
    friend DLLEXP_MESSAGES std::ostream &operator<<(std::ostream &ofStream, const SysMsg *sysMsgPtr);

    /** Output streaming operator.
    *
    *  @param [in,out] ofStream the output stream
    *  @param msgType The SysMsg type
    *  @return ndrStream
    *
    */
    friend DLLEXP_MESSAGES std::ostream &operator<<(std::ostream &ofStream, const MsgType &msgType);

    /** Output streaming operator.
    *
    *  @param [in,out] ofStream the output stream
    *  @param sysMsgType The SysMsg subtype
    *  @return ndrStream
    *
    */
    friend DLLEXP_MESSAGES std::ostream &operator<<(std::ostream &ofStream, const SysMsgType &sysMsgType);

   /** Equal operator. The operator compares the messages instances.
    *
    *  @param rVal An instance of Msg to be compared to
    *  @return int 0, if instances are equal, or not 0 otherwise
    *
    */
    virtual int operator==(const Msg &rVal) const;

    /** Equal operator. The operator compares the system messages instances.
     *
     *  @param rVal An instance of SysMsg to be compared to
     *  @return int 0, if instances are equal, or not 0 otherwise
     *
     */
    int operator==(const SysMsg &rVal) const;

    /** Assignment operator. The operator assigns the content of the specified message instances.
     *
     *  @param rVal An instance of Msg to assign from
     *  @return Msg, assigned message instance
     *
     */
    virtual Msg &operator=(const Msg &rVal);

    /** Assignment operator. The operator assigns the content of the specified system message instances.
     *
     *  @param rVal An instance of SysMsg to assign from
     *  @return Msg, assigned SysMsg instance
     *
     */
    SysMsg &operator=(const SysMsg &rVal);

    // Spezielle Methoden :

    /** Method creates a new SysMsg instance of the specifed message type.
     *   @param  type A system message type
     *   @return SysMsg, A new SysMsg instance
     */
    static SysMsg *allocate(MsgType type);

    /** Method returns the type of the system message.
     *   @param  msgType A system message type
     *   @return MsgType, A message type is returned for a SysMsg type, or NO_MSG otherwise
     */
    virtual MsgType isA(MsgType msgType) const;

    /** Method returns a system message type.
     *   @return MsgType, A message type is returned
     */
    virtual MsgType isA() const;

    /** Method returns a special system message type.
     *   @return SysMsgType, A system message type is returned
     */
    virtual SysMsgType isType() const;

    /** Receives from itcNdrUbReceive stream
     *   @param ist the stream, which to receive from
     */
    virtual void inNdrUb(itcNdrUbReceive &ist);

    /** Sends to itcNdrUbSend stream
     *   @param ost the stream, which to send to
     */
    virtual void outNdrUb(itcNdrUbSend &ost) const;

    /** Sends a formatted output about internal status of the instance to the specified stream.
     * (used for logging purpose)
     *  @param ofStream   output stream
     */
    virtual void outToFile(std::ostream &ofStream) const;

    /** Method creates a new SysMsg instance of the NO_SYS_MSG type.
     *   @return Msg, A new SysMsg instance
     */
    virtual Msg *allocate() const;

    // The debug functions.
    /** Method returns the system message type name
     * (used for logging purpose)
     *   @return const char, A system message type name string
     */
    virtual const char *getMsgName() const;

    /** Sends a formatted output about internal status of the instance to the specified stream.
     * (used for logging purpose)
     *  @param to   output stream
     *  @param level   debugging level
     */
    virtual void debug(std::ostream &to, int level) const;

    /** Sends a formatted output about internal status of the instance to the specified stream.
     * (used for logging purpose)
     *  @param to   output stream
     *  @param level   debugging level
     *  @param type   message type
     */
    virtual void debugMsgType(std::ostream &to, int level, MsgType type) const;

    // Generierte Methoden :

    /** Method returns the system message type
     *   @return SysMsgType, A system message type
     */
    SysMsgType getSysMsgType() const;

    /** Method sets the system message type
     *   @param newSysMsgType A new system message type
     */
    void       setSysMsgType(SysMsgType newSysMsgType);

    /** Method returns the system message subtype
     *   @return PVSSuchar, A system message subtype
     */
    PVSSuchar  getSysMsgSubType() const;

    /** Method sets the system message subtype
     *   @param newSubType A new system message subtype
     */
    void       setSysMsgSubType(PVSSuchar newSubType);

    /** Method sets a additional message data pointer of a Variable type
     *   @param newVarPtr A Variable pointer
     */
    void       setAdditionalData(Variable *newVarPtr) {delete varPtr; varPtr = newVarPtr;}

    /** Method returns a Variable pointer to additional message data
     *   @return Variable, A Variable pointer
     */
    const Variable * getAdditionalData() const        {return varPtr;}

    /// get answer message ID
    PVSSulong getAnswerId() const {return answerId;}

    /// set answer message ID
    /// @param dpMsgAnswerId the value to set
    void setAnswerId(PVSSulong dpMsgAnswerId) {answerId = dpMsgAnswerId;};

  protected:
    /// System message type
    SysMsgType sysMsgType;

    /// System message subtype
    PVSSuchar  sysMsgSubType;

    /// A Variable pointer for additional message data
    Variable  *varPtr;
};

// ================================================================================
// Inline-Funktionen :
inline  SysMsgType SysMsg::getSysMsgType() const
{
  return sysMsgType;
}

inline void SysMsg::setSysMsgType( SysMsgType newSysMsgType)
{
  sysMsgType = (SysMsgType &) newSysMsgType;
}


inline PVSSuchar SysMsg::getSysMsgSubType() const
{
  return sysMsgSubType;
}


inline void SysMsg::setSysMsgSubType(PVSSuchar newType)
{
  sysMsgSubType = newType;
}

#endif /* _SYSMSG_H_ */
