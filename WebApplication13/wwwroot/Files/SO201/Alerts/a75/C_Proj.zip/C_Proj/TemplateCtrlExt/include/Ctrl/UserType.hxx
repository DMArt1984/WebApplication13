#ifndef _UserType_H_
#define _UserType_H_

// 9.11.2015 MK: Baseclass for definition of a user defined datatype
// struct, class, enum

class CharString;
class ClassVar;
class CtrlScript;

class DLLEXP_CTRL UserType
{
  public:
    UserType(CharString *theName, int lineNum, int fileNum);

    virtual ~UserType();

    enum Type
    {
      ENUM_TYPE,
      CLASS_TYPE
    };

    virtual bool isA(Type type) const = 0;

    const CharString &getName() const { return *name; }

    int getLineNumber() const { return lineNumber; }
    int getFileNumber() const { return fileNumber; }

    int getRefCount() const { return refCount; }
    void incRefCount() const { refCount++; }
    void decRefCount() const { refCount--; }

    UserType *getNext() const { return next; }
    void setNext(UserType *n) { next = n; }

    // store the script in which this type is created
    void setScript(CtrlScript *s);
    CtrlScript *getScript() const;

    virtual ClassVar *createInstance(bool doRefCount) const = 0;

    // when Controller is deleting all libraries in arbitrary order while destructing,
    // it does not matter that libA still references a UserType in libB,
    // since Controller deletes all libs anyway
    static bool ignoreStillReferenced;

  protected:
    class UserTypePrivate *d;
    CharString *name;
    int lineNumber;    // for debugging/error reporting
    int fileNumber;    // for debugging/error reporting
    mutable int refCount;
    UserType *next;
};

#endif
