#ifndef _Average1Accu_H_
#define _Average1Accu_H_

// Author: Heinz MEISSL
// Date:   14.4.1997
// Purpose: implement a statistic Accumulator to determine the sum of values

#ifndef _SIMPLEACCU_H_
#include <SimpleAccu.hxx>
#endif

#ifndef _INTEGRAL1ACCU_H_
#include <Integral1Accu.hxx>
#endif

#ifndef _SUMACCU_H_
#include <SumAccu.hxx>
#endif

#ifndef _VARIABLE_H_
#include <Variable.hxx>
#endif

#ifndef _FLOATVAR_H_
#include <FloatVar.hxx>
#endif

#ifndef _TIMEVAR_H_
#include <TimeVar.hxx>
#endif

/** a first order value accumulator class. this class is used to determine a 
    mean value of variables over time. a linear approximation for value changes
    over time is applied.
    @classification ETM internal
*/
class DLLEXP_OABASICS Average1Accu: public SimpleAccu
{
  friend class UNIT_TEST_FRIEND_CLASS;
  public:
		/** constructor
		@param aVarType Variable type for accu
		*/
    Average1Accu(const VariableType aVarType);
    
		/**increases the accumulator by theValue
		@param theValue Value to increase
		@param atTime		time of the value
		*/
    virtual void accumulate(const Variable &theValue, const TimeVar &atTime );

		/**increases the accumulator by theValue
		@param theValue Value is handled as invalid
		@param atTime		time of the value
		*/
    virtual void accumulateInvalid( const Variable &theValue, const TimeVar &atTime );

		/**computes the result
		@return result
		*/
    virtual const Variable &getResult();

    /** Berechnet den Zwischenwert temporaer WOKL 2.2.01 TI 7411
		@param theValue
		@param start time
		@param stop time
		@return result
		*/
    virtual const Variable &getIntermResult( const Variable &theValue, const TimeVar &start, const TimeVar &stop, bool valid );

    /** resets accumulator
		*/
    virtual void reset();
    
  protected:
  
  private:
		/** copy constructor
		*/
    Average1Accu(const Average1Accu &);
		/** = operator
		*/
    Average1Accu &operator=(const Average1Accu &);
  
    Integral1Accu myIntegral1Accu;
    SumAccu myTimeSumAccu;
    FloatVar theAverage;
    TimeVar start;
    TimeVar end;
    FloatVar intermResult_;
};

#endif
