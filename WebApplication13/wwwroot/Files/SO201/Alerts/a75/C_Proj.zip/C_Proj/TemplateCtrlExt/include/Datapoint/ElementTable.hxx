#ifndef _ELEMENTTABLE_H_
#define _ELEMENTTABLE_H_

// VERANTWORTUNG:  Stanislav Meduna
//
// BESCHREIBUNG:  Eine Tabelle, die mit DpTypKontainer kommuniziert
//     und ermoeglicht eine bidirektionale Umwandlung
//     zwischen symbolische Bezeichner (Pfad-Syntax) und
//     interne Bezeichner innerhalb des Types.
// Vorwaerts-Deklaration der Eigenen Klasse

// System-Include-Files
#ifndef  _DPTYPE_H_
#include <DpType.hxx>
#endif

#ifndef  _DPTYPES_H_
#include <DpTypes.hxx>
#endif

#ifndef  _ELEMENTTABLEITEM_H_
#include <ElementTableItem.hxx>
#endif

#ifndef  _ELEMENTTABLEITERATORNODE_H_
#include <ElementTableIteratorNode.hxx>
#endif

#include <ostream>

class DpSymIdentifier;
class DpTypeContainer;
class LangText;

typedef SimplePtrArray<ElementTableItem>          ElementTableList;
typedef SimplePtrArray<ElementTableIteratorNode>  ElementTableIteratorList;

#ifdef WIN32
#pragma warning ( disable: 4231 )
#endif

#if defined(LIBS_AS_DLL)
  EXTERN_DATAPOINT template class DLLEXP_DATAPOINT  SimplePtrArray<ElementTableItem>;
  EXTERN_DATAPOINT template class DLLEXP_DATAPOINT  SimplePtrArray<ElementTableIteratorNode>;
#endif

#ifdef WIN32
#pragma warning ( default: 4231 )
#endif


// ========== ElementTable ============================================================
/**
  Table which communicates with DpTypKontainer and allows bidirectional conversion of
  symbolic names(path syntax) and internal descriptors inside the types
*/
class DLLEXP_DATAPOINT ElementTable
{
public:
  friend class UNIT_TEST_FRIEND_CLASS;

  /// constructor
  ElementTable();

  /** operator << for itcNdrUbSend stream
      @param[in,out] ndrStream the stream to send to
      @param table ElementTable
    */
  friend DLLEXP_DATAPOINT itcNdrUbSend &operator<<(itcNdrUbSend &ndrStream, const ElementTable &table);
  /** operator >> for itcNdrUbReceive stream
      @param[in,out] ndrStream the stream to receive from
      @param table ElementTable
    */
  friend DLLEXP_DATAPOINT itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream, ElementTable &table);

  /** get element id of some type, filtered according to symId
    @param symId DpSymIdentifier filter
    @param typeId DpTypeId
    @param[out] id DpElementId& output value
    */
  DpIdentificationResult getId(const DpSymIdentifier &symId, DpTypeId typeId, DpElementId &id) const;

  /** get name for element id
    @param typeId element datapoint type
    @param id element id
    @param[out] name corresponding name
    @return DpIdentificationResult
    */
  DpIdentificationResult getName(DpTypeId typeId, DpElementId id, CharString &name) const;

  /** get language dependent names for element id
    @param typeId element datapoint type
    @param id element id
    @param[out] namesRef corresponding multilanguage names
    @return DpIdentificationResult
    */
  DpIdentificationResult getNames(DpTypeId typeId, DpElementId id, LangText &namesRef) const;

  /** get full name for element id
    @param typeId element datapoint type
    @param id element id
    @param[out] name corresponding name including full path
    @return DpIdentificationResult
    */
  DpIdentificationResult getElementFullName(DpTypeId typeId, DpElementId id, CharString &name) const;

  /** adds an element name
    @param typeId element datapoint type
    @param elementId element id
    @param name the name to add for the element
    @return DpIdentificationResult
    */
  DpIdentificationResult addElementName(const DpTypeId &typeId, const DpElementId &elementId, const char *name);

  /** removes the name of an element
    @param typeId element datapoint type
    @param elementId element id
    @return DpIdentificationResult
    */
  DpIdentificationResult removeElementName(const DpTypeId &typeId, const DpElementId &elementId);

  /** reset iterator for specific type id
    @param typeId
    @return DpIdentificationResult
    */
  DpIdentificationResult iteratorReset(DpTypeId typeId);

  /** iterate to next name and idRef according to given mask and return them
    @param mask DpSymIdentifier& filter for the iterator
    @param[out] name the current element name
    @param[out] idRef the current element id
    @return DpIdentificationResult
    */
  DpIdentificationResult iteratorNextName(const DpSymIdentifier &mask, CharString &name, DpElementId &idRef);

  DpIdentificationResult iteratorNextNameIgnoreCase(const DpSymIdentifier &mask, CharString &name,
                                                    DpElementId &idRef, GlobalLanguageIdType langIdg = 0);

private:
  DpIdentificationResult iteratorNextNameCommon(const DpSymIdentifier &mask, CharString &name,
                                                DpElementId &idRef, GlobalLanguageIdType langIdg,
                                                bool ignoreCase);

public:
  /** go through all elements of given typeId, and check the content of type
    @param callback user defined callback which checks the content and delivers
                    PVSS_TRUE or PVSS_FALSE, depending on callback implementation
    @param  typeId DpTypeId
    @return PVSS_TRUE when callback returned PVSS_TRUE for each element, PVSS_FALSE otherwise
    */
  PVSSboolean visitEveryElement(PVSSboolean (*callback)(const MapTableItem &langItem), DpTypeId typeId) const;

  /**find ElementTableItem
    @param key item to be found
    @return found item or 0 if no item found
    */
  ElementTableItem * findItem(const ElementTableItem &key);

  /**set system id
    @param newSys the new system id
    */
  void  setSysId(SystemNumType newSys)  {sysId = newSys;}

  /**get system id
    @return the current system id
    */
  SystemNumType  getSysId() const       {return sysId;}

  /** report the status to stream
    @param[out] os output stream
    @param summary bool, include summary or not
    @param[out] bytes output bytes count
    */
  void  reportStatus(std::ostream &os, bool summary, unsigned &bytes);

private:

  /** Finds type and node, where the names for given type
   and node reside
   @param typeId DpTypeId
   @param elId DpElementId
   @param nameTypePtrRef DpType*&
   @param nameNodePtrRef DpTypeNode*&
   */  
  DpIdentificationResult findNameLocation(DpTypeId typeId, DpElementId elId,
          const DpType *&nameTypePtrRef, const DpTypeNode *&nameNodePtrRef) const;
  /** Finds type and node, where the names for given type
   and node reside
   @param typePtr DpType
   @param elId DpElementId
   @param nameTypePtrRef DpType*&
   @param nameNodePtrRef DpTypeNode*&
   */  
  DpIdentificationResult findNameLocation(const DpType *typePtr, DpElementId elId,
          const DpType *&nameTypePtrRef, const DpTypeNode *&nameNodePtrRef) const;

  /**compare 2 ElementTableItems
    @param item1
    @param item2
    @return 0 equal, -1 item1<item2, 1 item1>item2
    */
  static int compareElementTableItem(const ElementTableItem *item1, const ElementTableItem *item2);

  SystemNumType             sysId;
  ElementTableList          elementTableList;

  // For iterating
  const DpType             *iterCurrentTypePtr;
  ElementTableIteratorList  elementTableIteratorList;

  PVSSboolean doWildCompare;

  ///copy ctor
  ElementTable(const ElementTable &) {} // COVINFO LINE: defensive (defined private so no one can use it)
  ///= operator
  ElementTable & operator=(const ElementTable &) {return *this;} // COVINFO LINE: defensive (defined private so no one can use it)

};


inline ElementTableItem * ElementTable::findItem(const ElementTableItem &key)
{
  return elementTableList.getAt(elementTableList.findItem(&key, &ElementTable::compareElementTableItem));
}




#endif /* _ELEMENTTABLE_H_ */
