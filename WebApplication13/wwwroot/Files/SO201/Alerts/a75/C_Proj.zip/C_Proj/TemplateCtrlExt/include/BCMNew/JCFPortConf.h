
/* %Z%JESSI-COMMON-FRAMEWORK 2.0
 * %Z%Copyright (C) by Siemens Nixdorf Informationssysteme AG 1992
 * %Z%Copyright (C) by Universitaet GH Paderborn 1992
 * %Z%Development of this software was partially funded by ESPRIT project 7364.
 * %Z%PORT %M% %I% %E%
 */
/*
*  $RCSfile$
*  $Locker$
*  $State$
*  $Source$
*/

/* Configuration file for the Portabilty Layer. Here is the place to insert 
 * new platform/compiler types.
 */

#ifndef JCFPortConf_h
#define JCFPortConf_h

#ifdef _WIN32

#ifndef IS_MSWIN__
#define IS_MSWIN__
#endif

#endif

#ifndef _BOOL_T_DEFINED
#define _BOOL_T_DEFINED
#endif

/********** List of all known platforms(machine/OS/compiler) ***********/
/* MS Windows */
#ifdef IS_MSWIN__
#define IS_LITTLEENDIAN__
#define IS_IEEEFLOAT__
#endif

/* Linux */

#if defined(OS_LINUX) || defined(__EMSCRIPTEN__)
#define IS_SVR__
#define HAS_POSIX__

#ifndef __ANDROID__
#define HAS_BSD__
#endif

#define IS_LITTLEENDIAN__
#define IS_IEEEFLOAT__

#  ifndef ATT_VERSION__
#   define ATT_VERSION__ 21
#  endif
#endif

/* FreeBSD */
#ifdef OS_FREEBSD
 
#define IS_SVR__
#define HAS_POSIX__
#define HAS_BSD__
#define IS_LITTLEENDIAN__
#define IS_IEEEFLOAT__
 
#endif

/* Apple OSX */
#ifdef __APPLE__

#define IS_SVR__
#define HAS_POSIX__
#define HAS_BSD__
#define IS_LITTLEENDIAN__
#define IS_IEEEFLOAT__

#endif

/* HP700 running hp-ux9.0 */

#ifdef __HP
/* general OS defines */
#  define IS_SVR__
#  define HAS_POSIX__
#  define IS_BIGENDIAN__
#  define IS_IEEEFLOAT__

#  ifndef _ALL_SOURCE /* when running xlc or c89 (ansi cc)*/
#   define _ALL_SOURCE
#  endif

#  ifndef ATT_VERSION__
#   define ATT_VERSION__ 30 /* a guess, but it has at least 3.0's iostream.h */
#  endif
#endif /* __HP */


/* IBM RS600 running AIX 3.2.? */

#ifdef aix32_rs6k
/* general OS defines */
#  define IS_SVR__
#  define HAS_BSD__
#  define HAS_POSIX__
#  define IS_BIGENDIAN__
#  define IS_IEEEFLOAT__

#  define IS_AIX__
#  define IS_AIX32__
#  define HAS_NET2_TCPIP__ /* new fields for sockaddr lengths */
#  ifndef _ALL_SOURCE /* when running xlc or c89 (ansi cc)*/
#   define _ALL_SOURCE
#  endif

#  ifndef ATT_VERSION__
#   define ATT_VERSION__ 30 /* a guess, but it has at least 3.0's iostream.h */
#  endif

#endif /* aix32 */

/* SGI Indigo/Iris (MIPS) running Irix 4D */

#ifdef iris4d_mips
/* general OS defines */
#  define IS_SVR__
#  define HAS_BSD__
#  define HAS_POSIX__
#  define IS_BIGENDIAN__
#  define IS_IEEEFLOAT__

#  define IS_IRIX40__
#  ifndef __EXTENSIONS__  /* when using cc -ansi. Not recommended... */
#   define __EXTENSIONS__
#  endif

#  ifndef ATT_VERSION__
#   define ATT_VERSION__ 20
#  endif
#endif /* iris4d */

#ifdef IRIX52
/* general OS defines */
#  define IS_SVR__
#  define HAS_BSD__
#  define HAS_POSIX__
#  define IS_BIGENDIAN__
#  define IS_IEEEFLOAT__

#  ifndef ATT_VERSION__
#   define ATT_VERSION__ 30
#  endif
#endif /* IRIX52 */


/* Sun4 (SPARC) running SunOS 4.1.? */

#ifdef sunos41_sparc
/* general OS defines */
#  define IS_BSD__
#  define HAS_SVR__
#  define HAS_POSIX__
#  define IS_BIGENDIAN__
#  define IS_IEEEFLOAT__

#  define IS_SUNOS4__
#  ifndef ATT_VERSION__
#   define ATT_VERSION__ 21
#  endif
#endif /* sunos41 */

/* Sun (SPARC) running SunOS 5.8.? */

#ifdef OS_SOLARIS
/* general OS defines */
#  define IS_BSD__
#  define HAS_SVR__
#  define HAS_POSIX__
#ifndef OS_SOLARIS_10X86
#  define IS_BIGENDIAN__
#else
#  define IS_LITTLEENDIAN__
#endif
#  define IS_IEEEFLOAT__
#  define MISSING_BSD_PROTOS__

#  define IS_SUNOS5__
#  ifndef ATT_VERSION__
#   define ATT_VERSION__ 21
#  endif
#endif /* OS_SOLARIS */


/* MX300i (i386) running SINIX 5.41 or hopefully any System V Release 4 */

#ifdef sinix54_i386
/* general OS defines */
#  define IS_SVR__
#  define HAS_POSIX__
#  define IS_LITTLEENDIAN__
#  define IS_IEEEFLOAT__

#  define IS_SVR4__
#  define IS_SINIX54__
#  define MISSING_BSD_PROTOS__

#  ifndef ATT_VERSION__
#   define ATT_VERSION__ 21
#  endif

#endif /* sinix */

/* sanity checks */

#if !defined(IS_BSD__) && !defined(IS_SVR__) && !defined(IS_VMS__)
/*Error:  there seems no operating system to be defined !! */
#endif /* sanity */

#endif /* JCFPortConf_h */
