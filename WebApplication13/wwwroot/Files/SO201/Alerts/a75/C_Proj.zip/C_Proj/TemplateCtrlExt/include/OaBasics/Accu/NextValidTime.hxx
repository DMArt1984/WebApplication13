#ifndef _NEXTVALIDTIME_H_
#define _NEXTVALIDTIME_H_


// Functor class to retrieve times (TimeVar) meeting certain conditions
// ---------------------------------------------------------------------------
// Usage:
// 1. Instantiate an object
//    The conditions are set to some default values
// 2. Call setConditions() to change the conditions to be met
//    Impossible conditions are not accepted and False is returned
//    Call the function-operator()() with a time to start the search
//    The search direction is an optional parameter, default is FOREWARD
// ---------------------------------------------------------------------------
// Condition value ranges:
// 
// condition:    aMonth    aMonthDay      aWeekDay      aDayTime
// range:      -1 / 1-12   -1 / 1-31      -1 / 1-7      0-86399
// default:      -1            -1            -1            0
//
// -1  stands for any value -> that condition is ignored
// 31  as aMonthDay together with aMonth = -1 stands for the last day in month
//     (even if the current checked month has less days)
// 1-7 as aWeekDay corresponds to monday to sunday
//
// DayTime is measured in seconds and corresponds to [00:00:00, 23:59:59]. See below! 
// ----------------------------------------------------------------------------
// A feature?!
// This functor works also with daylight saving periods. The seconds given by
// DayTime are directly mapped to a time of 24 hours, even, if a day has more
// or less than 24*3600 = 86400 seconds ( the first and last day of the daylight
// savings period ). For instance: 84600 means always 23:30:00 and 1800 means
// always 00:30:00.
// So, DayTime does not always mean the same as seconds past midnight!
// ----------------------------------------------------------------------------
// @author Heinz Meissl
// @date 1.5.1997

#ifndef _TIMEVAR_H_
#include <TimeVar.hxx>
#endif

/// Functor class to retrieve times (TimeVar) meeting certain conditions
/// <p>
/// <b>Usage:</b>
/// <ol>
/// <li> Instantiate NextValidTime object (the conditions are set to default values)
/// <li> Call setConditions() to change the conditions to be met.
/// @n   Impossible conditions are not accepted and False is returned.
/// <li> Call the TimeVar operator() with a time to start the search.
/// @n   The search direction is an optional parameter, default is FOREWARD.
/// </ol>
///
/// <b>Condition value ranges:</b>
/// <p>aMonth: -1,1-12; default: -1
/// @n aMonthDay: -1,1-31; default: -1
/// @n aWeekDay: -1,1-7; default: -1
/// @n aDayTime: 0-86399; default: 0
/// </p>
/// <p>
/// -1  stands for any value -> that condition is ignored
/// @n 31  as aMonthDay together with aMonth = -1 stands for the last day in month
///     (even if the current checked month has less days)
/// @n 1-7 as aWeekDay corresponds to monday to sunday
/// </p>
/// DayTime is measured in seconds and corresponds to [00:00:00, 23:59:59]. See below!
/// 
/// A feature?!
/// This functor works also with daylight saving periods. The seconds given by
/// DayTime are directly mapped to a time of 24 hours, even, if a day has more
/// or less than 24*3600 = 86400 seconds ( the first and last day of the daylight
/// savings period ). For instance: 84600 means always 23:30:00 and 1800 means
/// always 00:30:00.
/// So, DayTime does not always mean the same as seconds past midnight!
/// @classification ETM internal
class DLLEXP_OABASICS NextValidTime
{
  public:
    friend class UNIT_TEST_FRIEND_CLASS;
    /// Constructor.
    NextValidTime();
    
    /// Set the conditions for the search algorithm.
    /// @param aMonth Specifies month from 1..12, -1 means any month.
    /// @param aMonthDay Specifies day of the month (1..31), -1 means any day.
    /// @param aWeekDay Specifies day of the week, 1 - Monday, ... -1 means any day.
    /// @param aDayTime Seconds from midnight, range is 0..86399.
    /// @return PVSS_TRUE if the conditions can be met, PVSS_FALSE if not.
    PVSSboolean setConditions( const PVSSshort aMonth,
                               const PVSSshort aMonthDay,
                               const PVSSshort aWeekDay,
                               const PVSSlong aDayTime );
  
    /// Direction to search for the first time meeting the condition set by setConditions method.
    enum Direction { FOREWARD, BACK };
  
    /// Find a closest time >= or <= startTime that meets the condition set by setConditions. 
    /// @param startTime Starting time to search from.
    /// @param aDirection If FOREWARD, search the future, if BACK, search the past from startTime.
    /// return TimeVar containing the time meeting the condition.
    const TimeVar operator()( const TimeVar &startTime,
                              const Direction aDirection = FOREWARD );
    
    // check for day of DST change WOKL 24.11.08 IM 87812
    /// Checks if the given datetime is the day when DST change occurs
    /// @param T BC_CTime to check.
    /// @param spring PVSS_TRUE if the change is in spring.
    /// @param autumn PVSS_TRUE if the change is in autumn.
    /// @param chgSpring Exact time (in seconds per midnight) when the DST change occurs.
    /// @param chgAutumn Exact time (in seconds per midnight) when the DST change occurs.
    static PVSSboolean getDSTChangeDay( BC_CTime &T, PVSSboolean &spring, PVSSboolean &autumn, PVSSlong *chgSpring = 0, PVSSlong *chgAutumn = 0 );

    /// Returns the hour of the day when the DST change will occur
    /// @param T Datetime to check.
    /// @return Hour of DST change. It is usually 2 on spring DST change day and 3 on autumn. For
    /// the days when DST doesn't not occur, the method returns 24.
    static PVSSlong getDSTChangeHour( const BC_CTime &T );

    /// Checks whether a DST switch occured in specified time interval.
    /// @param start Starting time of the interval.
    /// @param end Ending time of the interval.
    /// @param spring PVSS_TRUE if the change is in spring.
    /// @param autumn PVSS_TRUE if the change is in autumn.
    /// @return PVSS_TRUE if the switch day is in the interval, PVSS_FALSE otherwise.
    static PVSSboolean isDSTSwitch( const TimeVar &start, const TimeVar &end,  PVSSboolean &spring, PVSSboolean &autumn );

  protected:

  private:

    /// returns closest future time meeting condition set by setConditions; used by TimeVar operator()
    /// when called with FOREWARD direction.
    const TimeVar getNextValidTime ( const TimeVar &startTime );

    /// returns closest past time meeting condition set by setConditions; used by TimeVar operator()
    /// when called with BACK direction.
    const TimeVar getPrevValidTime ( const TimeVar &startTime );
  
    /// checks whether condition set by setConditions() can be met.
    PVSSboolean isConditionPossible ( const PVSSshort aMonth,
                                             const PVSSshort aMonthDay,
                                             const PVSSshort aWeekDay,
                                             const PVSSlong aDayTime );

    /// returns the weekdays numbers to their equivalent constants defined in the BCTime.h
    PVSSshort convertToBooch( PVSSshort aWeekDay );
    
    /// Find DayTime >= current DayTime given by theTime. Advance to next day if necessary.
    PVSSboolean goNextValidTime( BC_CTime & theTime );

    /// Find valid Day within Month given by theTime >= current Day of theTime.
    PVSSboolean goNextValidDay( BC_CTime & theTime );

    /// Find valid Month >= Month of theTime.
    void goNextValidMonth( BC_CTime & theTime );

    /// Find DayTime <= current DayTime given by theTime
    PVSSboolean goPrevValidTime( BC_CTime & theTime );

    /// Find valid Day within Month given by theTime <= current Day of theTime.
    PVSSboolean goPrevValidDay( BC_CTime & theTime );

    /// Find valid Month <= Month of theTime.
    void goPrevValidMonth( BC_CTime & theTime );

    /// Specifies month from 1..12, -1 means any month. Set by setConditions().
    PVSSshort condMonth;

    /// Specifies day of the month (1..31), -1 means any day. Set by setConditions().
    PVSSshort condMonthDay;

    /// Specifies day of the week, 1 - Monday, ... -1 means any day. Set by setConditions().
    PVSSshort condWeekDay;

    /// Seconds from midnight, range is 0..86399. Set by setConditions().
    PVSSlong condDayTime;
};

#endif /* _NEXTVALIDTIME_H_ */
