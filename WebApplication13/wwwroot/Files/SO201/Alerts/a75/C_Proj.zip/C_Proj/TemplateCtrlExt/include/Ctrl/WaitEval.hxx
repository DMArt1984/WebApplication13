#ifndef _WAITEVAL_H_
#define _WAITEVAL_H_

/*  author: Martin Koller */
/** WaitCond-Object for script.
  This is the WaitCond-Object which blocks further execution of the CTRL-script
  until the new script (with given scriptId) is finished. The new script
  tells this object with setDone() when it is finished.
  This class also checks out the CTRL-script when this is destroyed.
*/
#include <WaitCond.hxx>
#include <ScriptId.hxx>

///
class DLLEXP_CTRL WaitEval : public WaitCond
{
  public:
    WaitEval(ScriptId scriptId) : doneFlag_(0), scriptId_(scriptId) {}

    /// Destructor
    virtual ~WaitEval();

    /// when shall we call checkDone next
    virtual const TimeVar &nextCheck() const;

    /// checks if the wait condition has finished
    virtual int checkDone();

    void setDone();

  protected:

  private:
    int doneFlag_;
    ScriptId scriptId_;
};

#endif /* _WAITEVAL_H_ */
