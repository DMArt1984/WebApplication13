/* %Z%JESSI-COMMON-FRAMEWORK 2.0
 * %Z%Copyright (C) by Siemens Nixdorf Informationssysteme AG 1992
 * %Z%Copyright (C) by Universitaet GH Paderborn 1992
 * %Z%Development of this software was partially funded by ESPRIT project 7364.
 * %Z%PORT %M% %I% %E%
 */
/*
*  $RCSfile$
*  $Date$
*  $Revision$
*  $Author$
*  $Locker$
*  $State$
*  $Source$
*/

/* "Head" file for the Portability Layer. You only have to include this
 * file ! (mj)
 */

/* first include the configuration - it's only needed once */

#ifndef JCFPortConf_h
#include "JCFPortConf.h"
#endif

/* this is always needed in order to be able to add new modules */
#include "JCFPortMod.h"

