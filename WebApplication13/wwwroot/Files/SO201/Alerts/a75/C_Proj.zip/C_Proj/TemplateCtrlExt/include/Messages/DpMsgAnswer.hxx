// DATEIBESCHREIBUNG ==============================================================
// DATEINAME:     DpMsgAnswer.hxx
// VERANTWORTUNG:	WOLFGANG SCHUH + PETER PENTEK
// 
// BESCHREIBUNG:	DpMsgAnswer ist eine generelle Antwort-Message und wird
// 		a) bei einer verlangten Antwort zur Bestaetigung,
// 		b) zu einem Request (=Response),
// 		
// 		Beim Anlegen einer Antwort-Message muss im Konstruktor
// 		die AnswerId (= MsgId der zu beantwortenden Message) 
// 		uebergeben werden.
// 		
// 		Das Abfragen der AnswerId geschieht mit der Funktion 
// 		isAnswer(), welche einen long-Pointer auf die AnswerId
// 		zurueckliefert, falls es sich um eine Antwort handelt. 
// 		Handelt es sich um keine Antwort, so liefert die Funktion
// 		einen 0-Pointer zurueck.
//
// 28.03.96 komplette Umstellung der Message (Thomas Exner)
// Aenderungen:
// - die Message enthaelt jetzt eine PtrList von AnswerGroups (siehe dort)
// - im Konstruktor wird jetzt noch zusaetzlich der Msg-Typ der Message, auf welche
//   diese Message eine Antwort ist, uebergeben (kann mit isAnswerOn() abgefragt werden)
// - es gibt zwei Methoden insertGroup; eine mit einem Ptr auf eine Gruppe und eine
//   mit einem Ptr auf eine ErrClass (default-Wert 0), mit der zweiten
//   koennen auf einfache Weise ok- und error-Answers eingefuegt werden

#ifndef _DPMSGANSWER_H_
#define _DPMSGANSWER_H_

// Vorwaerts-Deklarationen :
class DpMsgAnswer;

// ========== DpMsgAnswerPtr ============================================================

typedef DpMsgAnswer* DpMsgAnswerPtr;

#include <ostream>
#include <AnswerGroup.hxx>
#include <DpMsg.hxx>

// Vorwaerts-Deklarationen :
class ManagerIdentifier;
class ErrClass;

// ========== DpMsgAnswer ============================================================

/** The DP message answer class
  A DpMsgAnswer is always sent if an answer was requested. It may only contain information
  if the operation was successful, but may also contain the requested data.
  All requested data are put into one AnswerGroup with the data in the order they were 
  requested. If several requests were answered in a row this message may contain several
  AnswerGroups.
 */

class DLLEXP_MESSAGES DpMsgAnswer : public DpMsg 
{
  friend class UNIT_TEST_FRIEND_CLASS;    // ein Unit-Test braucht erweiterten zugriff auf diese Klasse

  public:

    /// constructor, initialisation with zero values
    DpMsgAnswer();

    /// copy constructor
    /// @param newMsg the answer message to copy
    DpMsgAnswer(const DpMsgAnswer &newMsg);

    /// param constructor
    /// @param requestMsg the request message
    DpMsgAnswer(const DpMsg &requestMsg);

    // DpMsgAnswer(PVSSulong dpMsgAnswerId, MsgType newAnswerOn, const ManagerIdentifier &newDestination);

    /// destructor
    ~DpMsgAnswer();

    // Operatoren :

    /// operator << for itcNdrUbSend stream
    /// @param ndrStream the stream, which to send to
    /// @param dpMsgAnswer the answer message
    friend DLLEXP_MESSAGES itcNdrUbSend &operator<<(itcNdrUbSend &ndrStream, const DpMsgAnswer &dpMsgAnswer);

    /// operator >> for itcNdrUbReceive stream
    /// @param ndrStream the stream, which to receive from
    /// @param dpMsgAnswer the answer message
    friend DLLEXP_MESSAGES itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream, DpMsgAnswer &dpMsgAnswer);

    /// comparison operator ==
    /// @param rVal the message to compare with
    /// @return 0 if not equal else 1
    virtual int operator==(const Msg &rVal) const;

    /// assignment operator used for type conversion
    /// @param rVal the message to convert
    /// @return the resulting message
    virtual Msg &operator=(const Msg &rVal);

    /// assignment operator for DpMsgAnswer
    /// @param rVal the answer message to assign
    /// @return the resulting DpMsgAnswer
    DpMsgAnswer &operator=(const DpMsgAnswer &rVal) { operator=((const Msg&)rVal); return *this; }

    // Spezielle Methoden :

    /// allocate a new message
    virtual Msg *allocate() const;

  	/// check if own DP message type matches other DP message type
    /// @param dpMsgType the MsgType to check
    /// @return DpMsgAnswer type if argument is DpMsgAnswer else a DP message type
    virtual MsgType isA(MsgType dpMsgType) const
    {return dpMsgType == DP_MSG_ANSWER ? DP_MSG_ANSWER : DpMsg::isA(dpMsgType);};

    /// get own DP message type, always returns DP_MSG_ANSWER
    MsgType isA() const {return DP_MSG_ANSWER;};

    /// get pointer to the answer message id
    virtual const PVSSulong *isAnswer() const {return (const PVSSulong *) &answerId;};

    /// get answer flag
    MsgType isAnswerOn() const {return answerOn;};

    /// get answer message ID
    PVSSulong getAnswerId() const {return answerId;}

    /// set answer message ID
    /// @param dpMsgAnswerId the value to set
    void setAnswerId(PVSSulong dpMsgAnswerId) {answerId = dpMsgAnswerId;};

    /// set answer flag
    /// @param newAnswerOn the value to set
    void setAnswerOn(MsgType newAnswerOn) {answerOn = newAnswerOn;};

    /// insert error group
    /// @param errorPtr the item to insert
    /// @n The call takes ownership of this pointer.
    /// @return PVSS_TRUE if success else PVSS_FALSE
    PVSSboolean insertGroup(ErrClass *errorPtr = 0)
    {return insertGroup(new AnswerGroup(errorPtr));};

    /// insert answer group
    /// @param group the item to insert
    /// @n The call takes ownership of this pointer.
    /// @return PVSS_TRUE if success else PVSS_FALSE
    PVSSboolean insertGroup(AnswerGroup *group);

    /// get pointer to the first AnswerGroup or 0 if the list is empty
    AnswerGroup *getFirstGroup() const {return (AnswerGroup *) list.getFirst();};

    /// get pointer to the next AnswerGroup or 0 if the list is empty
    AnswerGroup *getNextGroup() const {return (AnswerGroup *) list.getNext();};

    /// get number of AnswerGroups in this message
    virtual PVSSulong getNrOfGroups() const {return list.getNumberOfItems();};

    /// cut out the first group
    /// @n You are responsible to delete it.
    AnswerGroup *cutFirstGroup() {return (AnswerGroup *) list.cutFirst();}

    /// cut out the last group
    /// @n You are responsible to delete it.
    AnswerGroup *cutLastGroup() {return (AnswerGroup *) list.cutLast();}

    /// send debug info to output stream
    /// @param to the output stream
    /// @param level the debug level
    virtual void debug(std::ostream &to, int level) const;

    // Get the percentage value of outstanding work to handle the request
    unsigned int getOutstandingProgress() const;

    // Set the percentage value of outstanding work to handle the request
    // @param percents Percentage value to set (range 0..100).
    //                 The value 0 indicates that this is the last answer.
    //                 A value > 100 leads to an internal fatal error
    void setOutstandingProgress(unsigned int percents);
    
    // The method notLastAnswer() is dropped.
    // The method isLastAnswer() is kept for convenience, but is renamed.
    PVSSboolean isFinalAnswer() const { return outstandingProgress == 0 ? PVSS_TRUE : PVSS_FALSE; }


  protected:

    /// send to itcNdrUbSend stream
    /// @param ndrStream the stream, which to send to
    virtual void outNdrUb(itcNdrUbSend &ndrStream) const;

    /// receive from itcNdrUbReceive stream
    /// @param ndrStream the stream, which to receive from
    virtual void inNdrUb(itcNdrUbReceive &ndrStream);

  private:
    PtrList list;
    MsgType answerOn;
    // Progress indication. Initialized with 0 in constructor.
    // Replaces bool lastAnswer_.
    unsigned int outstandingProgress;

};

// ========== inline-functions ============================================================
// Destruktor

inline DpMsgAnswer::~DpMsgAnswer()
{
}

// Konstruktor

inline DpMsgAnswer::DpMsgAnswer()
  : DpMsg(), list(), answerOn(DP_MSG), outstandingProgress(0)
{
}

// Konstruktor

inline DpMsgAnswer::DpMsgAnswer(const DpMsgAnswer &newMsg)
  : DpMsg(), list(), outstandingProgress(newMsg.outstandingProgress)
{
  operator=(newMsg);
}


inline Msg *DpMsgAnswer::allocate() const
{
  return new DpMsgAnswer;
}

#endif /* _DPMSGANSWER_H_ */
