#ifndef _DRVMANAGER_H_
#define _DRVMANAGER_H_

// Vorwaerts-Deklaration der Eigenen Klasse
class DrvManager;
class DpMsgComplexVC;

class DrvPluginHdl;
class DrvInitValues;

class DpMsgDrvAnswer;

// System-Include-Files
#include <AbstractHWMapper.hxx>
#include <HWService.hxx>
#include <AlertService.hxx>
#include <PollList.hxx>
#include <PollGroupList.hxx>
#include <IOTransCont.hxx>
#include <DrvConfigManager.hxx>
#include <DrvDpConfMan.hxx>  //old deprecated symbol
#include <DrvConfigContainer.hxx>
#include <DrvDpCont.hxx>  //old deprecated symbol
#include <RequestHandler.hxx>
#include <Manager.hxx>
#include <DpMsgInitConfig.hxx>
#include <DpMsgValueChange.hxx>
#include <DpMsgHotLink.hxx>
#include <DpMsgConnection.hxx>
#include <DpHLGroup.hxx>
#include <AnswerGroup.hxx>
#include <AlertHotLinkWaitForAnswer.hxx>
#include <DpIdVarFlgObj.hxx>

#include <deque>
using namespace std;

// ................................Anfang User-Definitionen........................
#define  MSG_EXITING                   1

#define  SET_VCMSG_OUT_OF_RANGE_BIT          0x00000001L
#define  SET_VCMSG_GENERAL_BIT               0x00000002L
#define  SET_VCMSG_SINGLE_BIT                0x00000004L
#define  SET_VCMSG_INTERFACE_INVALID_BIT     0x00000008L
#define  SET_VCMSG_USER1_BIT                 0x00000010L
#define  SET_VCMSG_USER2_BIT                 0x00000020L
#define  SET_VCMSG_USER3_BIT                 0x00000040L
#define  SET_VCMSG_USER4_BIT                 0x00000080L
#define  SET_VCMSG_USER5_BIT                 0x00000100L
#define  SET_VCMSG_USER6_BIT                 0x00000200L
#define  SET_VCMSG_USER7_BIT                 0x00000400L
#define  SET_VCMSG_USER8_BIT                 0x00000800L

#define  RESET_VCMSG_OUT_OF_RANGE_BIT        0x00010000L
#define  RESET_VCMSG_GENERAL_BIT             0x00020000L
#define  RESET_VCMSG_SINGLE_BIT              0x00040000L
#define  RESET_VCMSG_INTERFACE_INVALID_BIT   0x00080000L
#define  RESET_VCMSG_USER1_BIT               0x00100000L
#define  RESET_VCMSG_USER2_BIT               0x00200000L
#define  RESET_VCMSG_USER3_BIT               0x00400000L
#define  RESET_VCMSG_USER4_BIT               0x00800000L
#define  RESET_VCMSG_USER5_BIT               0x01000000L
#define  RESET_VCMSG_USER6_BIT               0x02000000L
#define  RESET_VCMSG_USER7_BIT               0x04000000L
#define  RESET_VCMSG_USER8_BIT               0x08000000L

#define  BITVECBLOCKSIZE            1024

/** This is an internal state.
  * To set the state use the _Driver.SM dp element.
  */
enum DrvSmoothMode
{
      /** (0). do smoothing in any case */
      SMOOTH_MODE_ALWAYS,
      /** (1). do smoothing except on answers for general query */
      SMOOTH_MODE_NOTGQ,
      /** (2). turn off smoothing */
      SMOOTH_MODE_NEVER
};

/** This is an internal state.
  * To set the state use the _Driver.EM dp element.
  */
enum DrvErrorMode
{
      /** (0). do not report errors */
      ERROR_MODE_OFF,
      /** (1). do error reporting */
      ERROR_MODE_ON
};

enum ConnectMachineItemType
{
  CMI_undefined,
  CMI_Connect,
  CMI_ConnectNoSource,
  CMI_ConnectDispatchInfo,
  CMI_ConnectAlert,
  CMI_Disconnect,
  CMI_DisconnectDispatchInfo,
  CMI_DisconnectAlert,
};

/// Connection machine item
struct ConnectMachineItem
{
    /// Message type
    ConnectMachineItemType type;

    /// List of DpIdentifiers
    DpIdentList members;
};

typedef std::deque<ConnectMachineItem *> ConnectMachineQueue;


/** The driver manager class.
  * This class uses the API and builds a more complicated layer on it.
  * It mainly consists of several PVSS_II related config handlers and an
  * installable hardware interface handler (HWService, HWMapper and HWObject).
  *
  * <p> this driver manager also covers polling purposes by executing single requests.
  * <p> to create a new driver you must derive your own driver manager from this class
  * and install your hardware service classes.
  *
  * @classification public use
  */
class DrvManager : public Manager
{
public:
/** This is an internal state. When the driver is running, he can use this
  * states to indicate what to do.
  */
  enum DrvInternalMode
    {
      /** (0). driver is up and running */
      DRVMODE_NORMAL,
      /** (1). driver has lost connection to the event manager
          and is trying to reconnect */
      DRVMODE_RECONNECTING,
      /** (2). driver is running in simulation mode.
          this state is used for internal purposes. */
      DRVMODE_SIMULATING,
      /** (3). driver has got exiting signal and is shutting down. */
      DRVMODE_EXITING
    };

/** The default constant is DRVCONNMODE_VALUE.
  * If you need more, you have to overload the getAttribs2Connect() member function.
  * You can combine these constants with binary OR.
  */
  enum DrvConnectMode
    {
      /** connect for _original.._value */
      DRVCONNMODE_VALUE = 0x00000001,
      /** connect for _original.._stime */
      DRVCONNMODE_TIME = 0x00000002,
      /** connect for status bit GA */
      DRVCONNMODE_GA = 0x00000004,
      /** connect for status bit EA */
      DRVCONNMODE_EA = 0x00000008,
      /** connect for status bit INVALD */
      DRVCONNMODE_INVALID = 0x00000010,
      /** connect for status bit USER1 */
      DRVCONNMODE_USER1 = 0x00000020,
      /** connect for status bit USER2 */
      DRVCONNMODE_USER2 = 0x00000040,
      /** connect for status bit USER3 */
      DRVCONNMODE_USER3 = 0x00000080,
      /** connect for status bit USER4 */
      DRVCONNMODE_USER4 = 0x00000100,
      /** connect for status bit USER5 */
      DRVCONNMODE_USER5 = 0x00000200,
      /** connect for status bit USER6 */
      DRVCONNMODE_USER6 = 0x00000400,
      /** connect for status bit USER7 */
      DRVCONNMODE_USER7 = 0x00000800,
      /** connect for status bit USER8 */
      DRVCONNMODE_USER8 = 0x00001000,
      /** connect for status bit USER9 */
      DRVCONNMODE_USER9 = 0x00002000,
      /** connect for status bit USER10 */
      DRVCONNMODE_USER10 = 0x00004000,
      /** connect for status bit USER11 */
      DRVCONNMODE_USER11 = 0x00008000,
      /** connect for status bit USER12 */
      DRVCONNMODE_USER12 = 0x00010000,
      /** connect for status bit USER13 */
      DRVCONNMODE_USER13 = 0x00020000,
      /** connect for status bit USER14 */
      DRVCONNMODE_USER14 = 0x00040000,
      /** connect for status bit USER15 */
      DRVCONNMODE_USER15 = 0x00080000,
      /** connect for status bit USER16 */
      DRVCONNMODE_USER16 = 0x00100000,
      /** connect for status byte USER1 */
      DRVCONNMODE_USERBYTE1 = 0x00200000,
      /** connect for status byte USER2 */
      DRVCONNMODE_USERBYTE2 = 0x00400000,
      /** connect for status byte USER3 */
      DRVCONNMODE_USERBYTE3 = 0x00800000,
      /** connect for status byte USER4 */
      DRVCONNMODE_USERBYTE4 = 0x01000000,
      DRVCONNMODE_MAX = 0x02000000,        // adjust this if adding values - this must be the last!
    };

  /** Constructor
    */
  DrvManager();

  /** Destructor
    */
  virtual ~DrvManager();

  /** The driver main procedure. This function is the equivalent to Manager::run() used in API
    * applications. It calls all the install_XX funcs and tries to connect to data manager (DM).
    * On initialisation the ComDrv gets the TYPE_CONTAINER from DM.
    *
    * <p>After initialisation from DM it issues a HWService->initialize() command to set up the
    * hardware. It then gathers the internal dpId's via DrvResources funcs and connects to event manager (EM).
    * ManagerState is set to STATE_RUNNING and HWService->start() is called.
    *
    * <p>After this the main loop is started. The driver stays there until the internalState
    * is set to DRVMODE_EXITING. In this case the main loop is stopped, HWService->stop is called and the
    * driver exits via Manager::exit();
    *
    * <p>take care in your driver in case of overloading!
    * @param argc number of arg of main procedure
    * @param argv array of arg of main procedure
    *
  * @classification ETM internal
    */
  virtual int            mainProcedure(int argc, char *argv[]);

  /** The driver main loop. The driver stays in this loop until someone sets the internalState to
    * DRVMODE_EXITING. In this loop the driver takes care of the polling of the hardware. The polling
    * is done via single requests. Polling is limited to 32 elements per loop.
    *
    * Every time the loop is traversed the connection to the event manager is checked and - if
    * necessary - a reconnect is tried. The call of the Manager::dispatch() function is done to make
    * sure new messages are fetched.
    *
    * The HWService->workProc() is called to allow for polling of the hardware interface.
    * If you want to stop the driver due to HW problems you should use the setInternalMode member
    * (setInternalMode(DRVMODE_EXITING) to exit in an ordered manner.
    *
    * @classification ETM internal
    */
  virtual void           mainLoop();

  /** This function simply calls all the install_XXX funcs to set up the
    * driver manager before starting work.
    *
    * @param argc number of arg of main procedure
    * @param argv array of arg
    * @classification ETM internal
    */
  virtual PVSSboolean    init(int argc, char *argv[]);

  /** This function is called to install the HWMapper. If you write your own driver
    * you have to overload the HWMapper class and therefore you must also overload this function to
    * install your own HWMapper.
    *
    * <p>your function should contain the line: <b>hwMapper = new myHwMapper;</b>
    *
    * @classification public use, overload
    */
  virtual void           install_HWMapper();

  /** This function is called to install the HWService. If you write your own driver
    * you have to overload the HWService class and therefore you must also overload this function to
    * install your own HWService service handler.
    *
    * <p>your function should contain the line: <b>hwService = new myHwService;</b>
    *
    * @classification public use, overload
    */
  virtual void           install_HWService();

  /** This function is called to install the AlertService. If you write your own driver,
    * which should have an interface to alert handling you can overload the AlertService class and in
    * that case you must also overload this function to install your own AlertService handler.
    *
    * <p>your function should contain the line: <b>alertService = new myAlertService;</b>
    *
    * @classification public use, overload
    */
  virtual void           install_AlertService();

  /** The function for sending new values to PVSS-II.
    * This function should be used to send new values to the PVSS-II system.
    * The data buffer is converted according to the chosen transformation and, if necessary,
    * any further calculations are done inside the ComDrv.
    * @param dataPtr this object holds the received data
    * @param hwAdrPtr this is the corresponding HW object found in the HWMapper
    * @return PVSS_TRUE on success
    *
    * @classification public use, call by user
    */
  virtual PVSSboolean    toDp(HWObject *dataPtr, HWObject *hwAdrPtr);

  /** The function for confirming write requests in case the HWObject is of type
    * ObjectSourceType::srcDirectWrite. In this case the HWObject passed to the
    * writeData() call with the answer id set must be passed along to this function.
    * @param theHWObject a HWObject to confirm the successful write for answer id.
    * @param error an error object for the answer message, this object is captured or deleted.
    *
    * @classification public use, call by user
    */
  virtual void confirmWrite(HWObject *objPtr, ErrClass *error);

  /** The function for sending new values to the HWService.
    * This function is called by the system to submit new values to the HW-layer.
    * The values are transformed according to chosen transformations and are preprocessed inside
    * the ComDrv. as a result each group will fill a new HWObject data buffer and will be sent to
    * the hardware via the HWService->preWriteData() function.
    * @param grpPtr pointer to new values
    * @param isIGQ - data are from IGQ
    * @return PVSS_TRUE if sending was successful or driver is not ready
    *
    * @classification ETM internal
    */
  virtual PVSSboolean    toHW(DpHLGroup *grpPtr, PVSSboolean isIGQ = PVSS_FALSE);

  /** The function for directly writing values to the HWService.
    * This function is called by the system to submit new values to the HW-layer.
    * The result of this function call is used to submit an answer to the caller.
    * Direct write is suported for DpIds with direct PeriphAddr configs, no DpType tree walk is supported here.
    * The values are transformed according to chosen transformations and are preprocessed inside
    * the ComDrv. as a result each group will fill a new HWObject data buffer and will be sent to
    * the hardware via the HWService->preWriteData() function.
    * @param grpPtr pointer to new values
    * @param ansPtr pointer to answer message
    * @return AnswerGroup object to include in answer on DP_MSG_REQUEST message. The caller must delete this object.
    *
    * @classification ETM internal
    */
  virtual AnswerGroup * toHW(DpVCGroup *grpPtr, DpMsgDrvAnswer *ansPtr);

  /** The function for sending new values to the HWService local data.
    * This function is called by the system to submit new values to the HW-layer.
    * Data is redirected to this function when the AM_internal bit is set in the PA config.
    * This function should be overloaded when you want to use this special behavior.
    * @param grpPtr pointer to new values
    * @return state to caller
    *
    * @classification ETM internal
    */
  virtual PVSSboolean    toInternal(DpHLGroup *grpPtr);

  /** This function is called when the connect for value changes
    * concerning outgoing values is made. You should overload this fuction if you need more than the
    * original..wert field when building a hardware bound message.
    *
    * This function returns DRVCONNMODE_VALUE by default. You can use the binary | to choose any other
    * connect form.

    * @param pa holds the PeriphAddr config concerned (to have a look at the periph address string, f.e.)
    * you can therefore decide on a per hardware object basis which connects to choose.
    *
    * @return a binary OR value of DrvConnectMode enums.
    *
    * @see DrvConnectMode
    *
    * @classification public use, overload
    */
  virtual unsigned int   getAttribs2Connect(const PeriphAddr *pa) const;

  // setInternalMode has to be const, because it is called inside
  // doConnectionClose, which is const, too
  // casting away constness ...

  /** Set the internal driver mode. Use this function if you want to exit the driver.
    * This is the only public purpose of this function.
    *
    * <p>beware of setting any other value than DRVMODE_EXITING since you will probably confuse
    * the driver!
    * @param mode mode to be set
    *
    * @classification public use, restricted call
    */
  void                   setInternalMode(DrvInternalMode mode) const { (DrvInternalMode&)internalMode = mode; }

  /** Create a new HWObject. If you derive your own HWObject overload this function.
    * Caller is responsible for the new object.
    * @return pointer new HWObject
    *
    * @classification public use, overload
    */
  virtual HWObject *     getHWObject() const;

  /** Send collected values to the event manager. This function is called automatically
    * by the driver in each cycle once, thus you don't have to care about it.
    * If you have data which differ in their origin time you shall call this
    * function every time after you called 'toDp'.
    *
    * @classification public use, restricted call
    */
  void                   sendData2Dp();

  /** Mask determines the DpMsgRequest group contents.
    * Masks separated by ';' determine extra groups
    * @param name to determine DpMsg group content by HWaddress. all matches go into one group.
    *             groups are separated by ';'
    * @param conn optional connection id
    *
    * @classification public use, call
    */
  void doPVSSGQ(const char *name, DpIdType conn = 0);

  // -----------------------------------------------------------------
  // statische methoden:

  /** This is a static function to get access to the currently running manager.
    * Since we have only one manager per running program this is a legal manner.
    *
    * @return pointer to the Manager instance.
    *
    * @classification public use, call
    */
  static DrvManager*     getSelfPtr();

  /** This static function returns a pointer to the installed HWMapper. Since
    * there is only one manager per program and only one HWMapper per manager instance this is
    * a legal manner.
    * @return pointer to the HWMapper instance installed by install_HWMapper()
    *
    * @classification public use, call
    */
  static AbstractHWMapper*       getHWMapperPtr();

  /** This static function returns a pointer to the installed HWService service handler.
    * Since there is only one manager per program and only one HWService per manager instance
    * this is a legal manner.
    * @return pointer to the HWService instance installed by install_HWService()
    *
    * @classification public use, call
    */
  static HWService*      getHWServicePtr();

  /** This static function returns a pointer to the installed AlertService handler.
    * Since there is only one manager per program and only one AlertService per manager instance
    * this is a legal manner.
    * @return pointer to the AlertService instance installed by install_AlertService()
    *
    * @classification public use, call
    */
  static AlertService*      getAlertServicePtr();

  /** This static function returns a pointer to the IOTransContainer.
    * Since there is only one manager per program and only one IOTransContainer per manager instance
    * this is a legal manner.
    * @return pointer to the IOTransCont object
    *
    * @classification public use, call
    */
  static IOTransCont *      getIOTransCont();

  /** This static function returns a pointer to the DrvInitValues handler.
    * Since there is only one manager per program and only one DrvInitValues handler per manager instance
    * this is a legal manner.
    * @return pointer to the DrvInitValues handler instance
    *
    * @classification public use, call
    */
  static DrvInitValues*  getInitValuesPtr();

  /** Use this function to enable / disable polling in your driver
    * @param state use PVSS_TRUE to enable polling, PVSS_FALSE to disable polling
    *
    * @classification public use, call
    */
  static void            setPollMode(PVSSboolean state);

  /** This function returns the internal driver state. You can use this function
    * to check the driver status according to the enum description.
    * @return the driver internal mode
    *
    * @classification public use, call
    */
  static DrvInternalMode getInternalMode() { return internalMode; }

  /** Called, when a driver receives a REDUNDANCY_REFRESH message from the (active) event.
    * The default behaviour is to do a generalQuery with a value of "0"
    * @classification overload, call
    */
  virtual void doRefresh(const ManagerIdentifier &manId);

  /** Reports status to stream.
    * @param os output stream
    */
  virtual void reportStatus(std::ostream &os) const;

  // statics
  /** Gets a non-owning pointer to the driver's config container.
   * @returns a pointer to the DrvConfigContainer instance.
   **/
  static DrvConfigContainer * getDrvConfigContainer();

  // statics
  /** Gets datapoint container pointer.
    * @return datapoint container pointer
  */
  IL_DEPRECATED("deprecated, use getDrvConfigContainer() instead")
  static DrvConfigContainer*      getDrvDpContPtr() { return DrvManager::getDrvConfigContainer(); }

  /** Gets pointer to datapoint config manager.
    * @return pointer to datapoint config manager
    */
  static DrvConfigManager * getDrvConfigManager();

  /** Gets pointer to datapoint config manager.
    * @return pointer to datapoint config manager
    */
  IL_DEPRECATED("deprecated, use getDrvConfigManager() instead")
  static DrvConfigManager*   getDrvDpConfManPtr() { return DrvManager::getDrvConfigManager(); }

  /** Gets pointer to pollList.
    * @return pointer to pollList
    */
  static PollList*       getPollListPtr();

  /** Gets pointer to pollGroupList.
    * @return pointer to pollGroupList
    */
  static PollGroupList*  getPollGroupListPtr();

  /** Sets smooth mode, checks legal value.
    * @param mode mode be set
    */
  static void            setSmoothMode(int mode);

  /** Gets smooth mode.
    * @return smoothMode
    */
  static int             getSmoothMode();

  /** Sets error mode on/off.
    * @param mode error mode to be switch on or off
    */
  static void            setErrorMode(int mode);


  /** Gets error mode on/off.
    * @return error mode
    */
  static int             getErrorMode();

  // 26.04.04 esperrer IM61848: fuer PagerDrv Methode fuer PollGroupList Init
  /** Initialise GroupPollList
    */
  static void initPollGroupList() { pollGroupList = new PollGroupList; }

  // internals --------------------------------------------------------
  /** Appends item to group, creates and sends message for dp message hotlink.
    * @param dpId dp identifier
    * @param varPtr Variable pointer to variable
    */
  void sendHotDog(const DpIdentifier &dpId, const Variable * varPtr);

  /** Appends item to group, creates and sends message for dp message hotlink which are connected for this DPE+config
  * @param dpId dp identifier
  */
  void sendHotDogs(const DpIdentifier &dpId);

  /** Creates and sends VC message.
    * @param dpId dp identifier
    * @param var variable
    * @param orgTime origin time
    * @param setBits bitvector to be set
    */
  void sendVCMsg(const DpIdentifier &dpId, const Variable &var, const TimeVar &orgTime, const BitVec &setBits = 0L);

  /** Creates and sends VC message.
    * @param dpId dp identifier
    * @param varPtr pointer to variable
    * @param orgTime origin time
    * @param setBits bitvector to be set
    */
  void sendVCMsg(const DpIdentifier &dpId, const VariablePtr varPtr, const TimeVar &orgTime, const BitVec &setBits = 0L);

  /** Receives, evaluates and handles dp message.
    * @param msg message
    */
  virtual void doReceive(DpMsg& msg);

  /** Receives, evaluates and handles sys message
    * @param msg dp message
    */
  virtual void doReceive(SysMsg& msg);

  /** Sets configuration, details and attributes of dp
    * @param dpIdf dp identifier
    * @param type type of connection
    */
  void connectMachine(const DpIdentifier &dpIdf, ConnectMachineItemType type);

  /** Maps hw address,attributes, sets configuration, details and attributes
    * @param confPtr pointer to periphery address
    * @param type type of connection
    */
  void connectMachine(PeriphAddr *confPtr, ConnectMachineItemType type);

  /** Closes connection and in some case sets internal mode
    * @param mId manager identifier
    */
  void doConnectionClose(const ManagerIdentifier& mId);

  /** Subtracts grops from outstanding answers or sets it to zero
    * @param groups number of groups
    */
  void gotVCAnswer(unsigned groups);

  /** Decrease outstanding answers of connect machine
    */
  void gotCMAnswer();

  /** Check if it is the expected answer
    * remove all non matching items before
    * because normally the first item should match
    * process correct answer
    * @param answer dp message answer
    */
  void gotExplVCAnswer(DpMsgAnswer &answer);

  /** This method handles alertConnect answers and creates AlertObjects accordingly.
   * For each AlertAttrList in the answer
   * - it checks if the AlertID is set.
   * - it checks if we have an AM_Alert PeriphAddr for that DpId.
   * - it assembles an AlertObject with the alert attributes received.
   *
   * @param answer The alertConnect answer message.
   **/
  void gotAlertConnectAnswer(const DpMsgAnswer & answer) const;

  /** This method handles alertConnect hotlinks and creates AlertObjects accordingly.
   * - It checks if the AlertID is set.
   * - It checks if we have an AM_Alert PeriphAddr for that DpId.
   * - It assembles an AlertObject with the alert attributes received in the hotlink.
   *
   * @param group The AlertAttrList received in the hotlink.
   **/
  void gotAlertHL(AlertAttrList & group) const;

  /** monitor state of _alert_hdl config.
    * this is the answer on _alert_hdl.._type (check for existence) or
    * _alert_hdl.._active (check for activation).
    * the result is stored in the periphaddr config
    * if no config is found or config is not active an error message is output
    * @param answer dp message answer
   */
  void gotAlertConfigAnswer(DpMsgAnswer &answer);

  /** monitor state of _alert_hdl config.
    * this is the notification on _alert_hdl.._type (check for existence) or
    * _alert_hdl.._active (check for activation).
    * the result is stored in the periphaddr config
    * if config is removed or not active an error message is output
    * @param group dp message hotlink group
   */
  void gotAlertConfigHL(DpHLGroup &group);

  /**
   * Add user bits defined by `flags` to a VC group.
   *
   * @param flags is a collection of status bits.
   *              User bits will be extracted from it.
   * @param dpId is the DpIdentifier to use when adding items to the group.
   *             Config will be set to _original, attribute to the appropriate user bit attribute.
   * @param group is the VC group to which items will be appended (if any).
   **/
  static void addUserBits(const BitVec & flags, const DpIdentifier & dpId, DpVCGroup & group);

  /** Gets user defined DP value word atribute, index range is <0,1>
    * @param index
    * @return user defined word atribute
    */
  static DpAttributeNrType getUserWordAttr(int index);

  /** Gets user defined DP value byte atribute, index range is <0,3>
    * @param index
    * @return user defined byte atribute
    */
  static DpAttributeNrType getUserByteAttr(int index);

  /** This function sets the Overflow-Bit
    * @param setOv overflow bit value
    * @param force if PVSS_TRUE internal value is always set
    * @return PVSS_TRUE if OK, otherwise PVSS_FALSE
    */
  const PVSSboolean setOV(PVSSboolean setOv = PVSS_TRUE, PVSSboolean force = PVSS_FALSE);

  /** This function cleares the Overflow-Bit
    * @param force if TRUE internal value is always set
    * @return PVSS_TRUE if OK, otherwise PVSS_FALSE
    */
  const PVSSboolean clearOV(PVSSboolean force = PVSS_FALSE);

  /** Update the subscription counter for the given dpId
    * @param dpId the datapoint element
    * @param varPtr the current subscription count
    */
  void updateSubscriptionCount(const DpIdentifier &dpId, Variable *varPtr);

  /** grant access to the timestamp of the latest mainLoop round.
      @return start of the latest mainLoop round
    */
  static const TimeVar &getLastPollTime() { return lastPollTime; }

  /** check if we should abort current work for better throughput. This function
      uses the number of calls to toDp and the config file entry maxToDpBeforeSend.
      If the function returns true the current work function should be interrupted and
      work continued in the next call.
    */
  static bool shouldAbortWorkProc();

  static size_t getToDpCount() { return toDpCount; }

  // ------------------------------------------------------------------
  // internal use only
protected:
  /** Creates dp container pointer
    */
  virtual void           install_DpContainer();

  /** Creates dp config manager pointer
    */
  virtual void           install_DpConfigManager();

  /** Creates PollList
    */
  virtual void           install_PollList();

  /** Creates PollGroupList
    */
  virtual void           install_PollGroupList();

  /** Creates IOTransCont
    */
  virtual void           install_IOTransCont();

  /** Initializes dp configuration init list
    */
  virtual void           set_DpConfigInitList();

  /** Gets dp configuration init type
    * @param idx index
    * @return dp configuration init type
    */
  virtual DpConfigNrType get_DpConfigInitType(int idx);

  /** Signal handler for resource class
    */
  virtual void           signalMessage();

  // new iterator versions
  /** Mask out the selected bits
    * then call processData2Dp()
    * @param dataPtr pointer to HW object data
    * @param hwAdrPtr pointer to hw address
    * @param chkPtr pointer to periphery address
    * @param trnsPtr pointer to transformation
    */
  virtual void           passLowLevelFilter(HWObject *dataPtr, HWObject *hwAdrPtr,
                         PeriphAddr* chkPtr, Transformation* trnsPtr, HWMapDpPa *dpPaPtr);

  /** Converts dat to enginnering units, handles user bits
    * @param dataPtr pointer to HW object data
    * @param hwAdrPtr pointer to hw address
    * @param chkPtr pointer to periphery address
    */
  virtual void           processData2Dp(HWObject *dataPtr, HWObject *hwAdrPtr, PeriphAddr* chkPtr, HWMapDpPa *dpPaPtr);

  /** Check possibility of connection, read licence data, make connection
    */
  void                   connect4orgValues();

  /** Virtual function (connect for internal Dps - HotLinks)
    */
  virtual void           connect4iDps();

  /// pointer to the dp config init list
  static const DpConfigNrType* dpConfigInitList;
  /// pointer to to the dp configuration manager
  static DrvConfigManager*   dpConfigManager;
  /// pointer to the HWMapper instance
  static AbstractHWMapper*       hwMapper;
  /// pointer to the HWService instance
  static HWService*      hwService;
  /// pointer to the AlertService instance
  static AlertService*      alertService;
  /// pointer to the HWObject template
  static HWObject *       hwObject;
    /// pointer to the pool list
  static PollList*       pollList;
  /// pointer to the pool group list
  static PollGroupList*  pollGroupList;
  /// pointer to the IO transaction
  static IOTransCont*    ioTransCont_;
  /// smooth mode
  static DrvSmoothMode   smoothMode;
  /// error mode
  static DrvErrorMode    errorMode;
  /// internal mode
  static DrvInternalMode internalMode;
  /// message selector
  int                    msgSelector;

  /// pointer to a dynamic array that contains list of VC by time and DpId
  DynPtrArray<DpIdVarFlgObj> valueChangeList;

  /// pointer to a dynamic array that contains list of VC overflow
  DynPtrArray<DpIdVarFlgObj> overflowList;

  /// count of overflow
  unsigned overflowCount;

  /// count of VC's between send
  unsigned vcsBetweenSend;

  /// determines  reset of the VC between send
  bool resetVcsBetweenSend;

  /** Processing of the dp connection message
    * @param msg dp connection message
    */
  virtual void processConnectionMsg(const DpMsgConnection &msg);

  /** Processing of the dp value change
    * @param msg value change message
    */
  virtual void processValueChange(const DpMsgValueChange &msg);

  /** Processing of the hotling message
    * @param msg hotling message
    */
  virtual void processHotLink(const DpMsgHotLink &msg);

  /** Deletes dp and informs HWMapper and Alert Service
    * @param msg dp manipulation message
    */
  virtual void processNewDelDp(const DpMsgManipDp &msg);

  /** Set the actual dp
    * @param msg dp type manipulation message
    */
  virtual void processManipDpType(const DpMsgManipDpType &msg);   // squirt, 11.12.2003, IM56581

  // intended to be overloaded for handling AM_Internal configs

  /** Intended to be overloaded for handling AM_Internal configs (here do nothing)
    * @param dpId  dp identifier
    * @param confPtr pointer to periph address
    * @return PVSS_TRUE if internal configuration was inserted
    */
  virtual PVSSboolean insertInternalConfig(DpIdentifier &dpId, PeriphAddr *confPtr);

  /** Intended to be overloaded for handling AM_Internal configs (here do nothing)
    * @param dpId  dp identifier
    * @param confPtr pointer to periph address
    * @return PVSS_TRUE if internal configuration was removed
    */
  virtual PVSSboolean deleteInternalConfig(DpIdentifier &dpId, PeriphAddr *confPtr);

   /** Insert new DpIdVarFlgObj value constructed from the input parameters into the
    * vcListOverflow list. If the flag has the bit DRV_WANT_ANSWER set, the method
    * first checks if such item already exist in the list, and removes it.
    * @param dpId DpIdentifier used in constructor of a DpIdVarFlgObj item.
    * @param varPtr Pointer to a variable used in constructor of a DpIdVarFlgObj item.
    * @param flags BitVec of flag used in constructor of a DpIdVarFlgObj item. If flag
    * DRV_WANT_ANSWER is set, the DpIdVarFlgObj item will first be removed if it exist.
    * @param orgTime Origin time used in constructor of a DpIdVarFlgObj item.
    * @param hwoId HWObject identifier used in constructor of a DpIdVarFlgObj item.
    */
  void insertValueChange(const DpIdentifier &dpId, Variable *varPtr, const BitVec &flags,
    const TimeVar &orgTime, PVSSulong hwoId);

  /* Callback to signal specific driver that the connect machine calls are all out and the
     initialization of comdrv is finally done
  */
  virtual void connectQueueDone();

private:
  // Copy constructor
  DrvManager(DrvManager const &);
  // Assignment operator
  DrvManager& operator=(DrvManager const &);

  /** Compare two DpIdVarFlgObj by origin time.
   * Earlier times are sorted first.
   *
   * @param item1 first item to compare
   * @param item2 second item to compare
   * @return -1 if time1 is earlier than time2
   *         +1 if time2 is earlier than time1
   *          0 otherwise
   **/
  static int compareByTime(DpIdVarFlgObj const * item1, DpIdVarFlgObj const * item2);

  /** Compare two DpIdVarFlgObj by DpIdentifier.
   * Only DpId is compared, lower IDs are sorted first.
   *
   * @param item1 first item to compare
   * @param item2 second item to compare
   * @return -1 if id1 is lower than id2
   *         +1 if id2 is lower than id1
   *          0 otherwise
   **/
  static int compareByDpId(DpIdVarFlgObj const * item1, DpIdVarFlgObj const * item2);

  /** Compares two IdVarFlgObj for sorting into the valueChangeList.
   * Items are sorted in the following order:
   * * origin time (@see compareByTime),
   * * DpId (@see compareByDpId), and
   * * whether they require an explicit answer.
   *
   * @param item1 first item to compare
   * @param item2 second item to compare
   * @return -1 if item1 has to be sorted first
   *         +1 if item2 has to be sorted first
   *          0 otherwise
   **/
  static int compareForVcList(DpIdVarFlgObj const * item1, DpIdVarFlgObj const * item2);

    /** Appends message by Id to connection message and set attributes
      * @param what driver connection mode
      * @param dpId dp identifier
      * @param dpList List of dp identifiers where the dpId will be added
      */
    static void appendId2ConnectMsg ( unsigned int what, DpIdentifier &dpId, DpIdentList &dpList);

    /** Inserts item by Id to group
      * @param what driver connection mode
      * @param dpId dp identifier
      * @param grp request group
      */
    static void appendId2RequestGroup ( unsigned int what, DpIdentifier &dpId, RequestGroup * grp);

  /** Sends item with Invalid-Bit
    * @param itemPtr pointer to item
    */
  void  sendInvalid(const DpIdVarFlgObj *);

  /** Sents item as value for correction
    * @param itemPtr pointer to item
    */
  void  sendCorrValue(const DpIdVarFlgObj *);

  /** This method gets several specific flags from the DpIdVarFlgObj item passed
    * as a second parameter, and then change the corresponding value in the DpMsgComplexVC
    * message (passed as a first parameter), using the method DpMsgComplexVC::insertValueChange().
    * @param msgPtr Pointer to a DpMsgComplexVC message.
    * @param itemPtr Pointer to a DpIdVarFlgObj item.
    * @return PVSS_TRUE if values were changed successfully, PVSS_FALSE otherwise.
    */
  PVSSboolean  insertValueChange(DpMsgComplexVC *, const DpIdVarFlgObj *);

  /** This method gets several specific flags from the DpIdVarFlgObj item passed
    * as a second parameter, and then add the status bits in the DpMsgComplexVC
    * message (passed as a first parameter), using the method DpMsgComplexVC::insertValueChange().
    * @param msgPtr Pointer to a DpMsgComplexVC message.
    * @param itemPtr Pointer to a DpIdVarFlgObj item.
    * @return PVSS_TRUE if values were changed successfully, PVSS_FALSE otherwise.
    */
  PVSSboolean  insertInvalid(DpMsgComplexVC *,const DpIdVarFlgObj *);

  /** According to groups and items from msg sets system, dp type, dp,
    * element, config, details and attribute of dp.
    * @param msg pointer to init conf message
    */
  void processInitConfig(DpMsgInitConfig &msg);

  /** Gets configuration, adds dp identifier to connectio config
    * @param dpId dp identifier
    * @return PVSS_TRUE if addition of dp identifier to config was successful
    */
  PVSSboolean setConnection(const DpIdentifier &dpId);

  /** Removes dp identifier from connection configuration
    * @param dpId dp identifier
    * @return PVSS_TRUE if removing of dp identifier from config was successful
    */
  PVSSboolean clrConnection(const DpIdentifier &dpId);

  /** Inserts config, check whether is new, changed or equal
    * @param grpPtr pointer to VC group
    * @param itmPtr pointer to VC item
    * @param confPtr pointer to dp config
    * @param orgPtr pointer to org dp config
    * @return NOERR if  the configuration was updated
    *         CONFIG_NOT_CHANGED if no change was detected
    *         LICENSE_INVALID if the number of licences was exceeded
    */
  ErrClass::ErrCode processGroup(DpVCGroup *grpPtr, DpVCItem *itmPtr, DpConfig *confPtr, DpConfig *orgPtr);

  /** checks for a new periphaddr config if the output PA is unique
    * @param dpId dp identifier
    * @param confPtr pointer to configuration
    * @param orgPtr pointer to original configuration (not used!)
    * @return
    */
  PVSSboolean overlappingPARange(const DpIdentifier &dpId, PeriphAddr *confPtr, PeriphAddr *orgPtr);

  /** checks for a new periphaddr config if the alertAddress is unique
    * @param dpId dp identifier
    * @param confPtr pointer to configuration
    * @param orgPtr pointer to original configuration (not used!)
    * @return
    */
  PVSSboolean ambiguousAlertAddress(const DpIdentifier &dpId, PeriphAddr *confPtr, PeriphAddr *orgPtr);

  /** Adds config by dp identifier
    * @param dpId dp identifier
    * @param confPtr pointer to config
    * @return PVSS_TRUE if insertion was successful
    */
  PVSSboolean insertConfigByDpIdentifier(DpIdentifier &dpId, DpConfig *confPtr);

  /** Deletes config by dp identifier
    * @param dpId dp identifier
    * @param confPtr pointer to config
    * @return PVSS_TRUE if removing was successful
  */
  PVSSboolean deleteConfigByDpIdentifier(DpIdentifier &dpId);

  /** Gets pointer to varibale by dp identifier
    * @param dpId dp identifier
    * @return pointer to variable
    */
  Variable *getVariablePtr(const DpIdentifier &dpId);

  /** Creates pointer to error by dpId, errCode and manId
    * and pointer to answer group
    * @param dpId dp identifier
    * @param manId manager identifier
    * @param errCode code of error
    * @return pointer to created answer group
     */
  AnswerGroup* newAnswerErrorItem(const DpIdentifier &dpId, const ManagerIdentifier &manId, ErrClass::ErrCode errCode);

  /** This method is called in the case of configuration update
    * to release the connections from the back-up configuration
    * only new connections are valid
    * @param dpId dp identifier
    * @param manId manager identifier
    */
  void sendNegativeHotLinks(const DpIdentifier &dpId, const ManagerIdentifier &manId);

  /** Old version of polling, Polling is handeled for each config
    * @param objPtr pointer to HW object
    * @param actPoll time interval
    */
  void poll (HWObject * objPtr, TimeVar & actPoll);

  /** Polling is handled in groups
    * @param objPtr pointer to HW object
    * @param actPoll time interval
    */
  void pollGroup (HWObject * objPtr, TimeVar & actPoll);

  /** Reset and recalculate polling.
   * This affects both individually polled addresses and poll groups.
   **/
  void resetPolling();

  /** work on the connect machine queue to keep scalability
    */
  void processConnectMachineQueue();

  /** this actually is the time of the start of the current main loop
      where the poll goups are checked for their due time
      we use this timestamp also for cumulating all uncertain and invalid bits
      delivered in one round of the main loop.
  */
  static TimeVar lastPollTime;

  ConnectMachineQueue theConnectMachineQueue;

  /** Number of messages where the WantAnswer flag should be set
    * @return 1 or int of CommitCount/10
    */
  static unsigned getWantAnswerNum();

  static RequestHandler    *reqHdlPtr;
  static PVSSboolean       exitFlag;

    class  VCWaitForAnswer : public WaitForAnswer
    {
      public:
        VCWaitForAnswer() : WaitForAnswer() {};
        virtual void  callBack(DpMsgAnswer &);
    };
    VCWaitForAnswer * vcWaitForAnswer;
    unsigned int  outstandingAnswers;

    class AlertHLWaitForAnswer : public AlertHotLinkWaitForAnswer
    {
      public:
        AlertHLWaitForAnswer() : AlertHotLinkWaitForAnswer() {answerReceived = false;};
        void alertHotLinkCallBack(DpMsgAnswer &answer);
        void alertHotLinkCallBack(AlertAttrList &group);
        bool answerReceived;
    };
    AlertHLWaitForAnswer *alertHLWaitForAnswer;

    // ---------------------------------------------------------
    // this class is used to monitor _alert_hdl configs for active AM_Alert periphaddr configs
   class AlertConfigWaitForAnswer : public HotLinkWaitForAnswer
    {
      public:
        AlertConfigWaitForAnswer() : HotLinkWaitForAnswer() {answerReceived = false;};
        void hotLinkCallBack(DpMsgAnswer &answer);
        void hotLinkCallBack(DpHLGroup &group);
        bool answerReceived;
    };
    AlertConfigWaitForAnswer *alertConfigWaitForAnswer;

    //----------- stuff for explicit answer handling--------------
    class  VCWaitForExplAnswer : public WaitForAnswer
    {
      public:
        VCWaitForExplAnswer() : WaitForAnswer() {};
        virtual void  callBack(DpMsgAnswer & answer);
    };

    VCWaitForExplAnswer * vcWaitForExplAnswer;

    class ExplAnswerItem
    {
      public:
        ExplAnswerItem(PVSSulong hwoId, PVSSulong mid) : hwoId_(hwoId), msgId_(mid) {};
        ~ExplAnswerItem() {}
        PVSSulong hwoId_;
        PVSSulong msgId_;
    };

    class  CMWaitForAnswer : public WaitForAnswer
    {
      public:
        CMWaitForAnswer() : WaitForAnswer() {};
        virtual void  callBack(DpMsgAnswer &);
    };
    CMWaitForAnswer * cmWaitForAnswer;
    unsigned int  outstandingConnectAnswers;

    class  ConnectWaitForAnswer : public WaitForAnswer
    {
      public:
        ConnectWaitForAnswer() : WaitForAnswer() {};
        virtual void  callBack(DpMsgAnswer &);
    };
    ConnectWaitForAnswer * connectWaitForAnswer;

    // list containing the waiting explicite answers
    DynPtrArray<ExplAnswerItem>  explAnswerList_;
    //----------- stuff for explicit answer handling--------------

    //----------- stuff for initial value retrieval--------------
    static DrvInitValues *initValues_;
    //----------- stuff for initial value retrieval--------------


    // count calls to toDp and use DrvResources::maxToDpBeforeSend to trigger send if set
    static size_t toDpCount;

public:
  /// driver plug-in handler
  static DrvPluginHdl *drvPluginHdl;

friend class UNIT_TEST_FRIEND_CLASS;
};


inline void DrvManager::gotVCAnswer(unsigned groups)
{
  if (outstandingAnswers > groups)
    outstandingAnswers -= groups;
  else  //COVINFO LINE: obsolete (mhorvath: Coverage Bug - Path covered, only else condition not marked)
    outstandingAnswers = 0;
}

inline void DrvManager::gotCMAnswer()
{
  if (outstandingConnectAnswers)
    --outstandingConnectAnswers;
  else
    outstandingConnectAnswers = 0;

  // cerr << "new count is " << outstandingConnectAnswers << endl;
}


#endif /* _DRVMANAGER_H_ */
