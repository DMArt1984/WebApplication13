#ifndef _SUMACCU_H_
#define _SUMACCU_H_

#ifndef _SIMPLEACCU_H_
#include <SimpleAccu.hxx>
#endif

#ifndef _VARIABLE_H_
#include <Variable.hxx>
#endif

#ifndef _FLOATVAR_H_
#include <FloatVar.hxx>
#endif

#ifndef _TIMEVAR_H_
#include <TimeVar.hxx>
#endif

// ========== SumAccu ============================================================

/** the sum accumulator class
    @n This class implements a statistic accumulator to determine the sum of values within a period.
    A value is added to internal value every time when the accumulate function is called.
    @classification ETM internal
*/
class DLLEXP_OABASICS SumAccu: public SimpleAccu
{
  public:
    /// constructor
    /// @param aVarType the type of variable for accu
    SumAccu(const VariableType aVarType);
    
    /// process a new value
    /// @param theValue the value to process
    /// @param atTime the time of the processing
    virtual void accumulate(const Variable &theValue, const TimeVar &atTime );

    /// get result
    /// @return the result
    virtual const Variable &getResult();

    /// reset internal values
    virtual void reset();
    
  protected:
  
  private:
    SumAccu(const SumAccu &);
    SumAccu &operator=(const SumAccu &);
  
    FloatVar theSum;
};

#endif
