// declare basic instances of template classes
// to prevent link errors

#include <ProjDirs.hxx>
#include <Variable.hxx>
#include <DpIdentifier.hxx>
#include <AlertIdentifier.hxx>
#include <PathItem.hxx>
#include <CharString.hxx>
#include <ManagerIdentifier.hxx>

#include <DynPtrArray.cxx>

#ifndef LIBS_AS_DLL

// void * DynPtrArray<Item>::staticUserDataPtr = 0;


template <>
DynPtrArrayIndex DynPtrArray<Variable>::deepCopy(const DynPtrArray<Variable> &src) 
{
  DynPtrArrayIndex i, count = src.nofItems();
  Variable *newItem, *srcItem;
  
  for (i=0; i<count; i++)
    {
    if ((srcItem = src.getAt(i)) != 0)
      {
      newItem = srcItem->clone();
      if (!newItem) {clear(); i = 0; break;}    //nothing has been copied - no memory 
      }
    else newItem = 0;
    setPtr(i, newItem);
    }
    
  return i;
}


#else
  #include <DynPtrArray.hxx>
  #include <SimplePtrArray.hxx>
  #include <DynPtrArrayTpl.hxx>
#endif

  template class DLLEXP_BASICS DynPtrArray<Variable>;
  template class DLLEXP_BASICS DynPtrArray<DpIdentifier>;
  template class DLLEXP_BASICS DynPtrArray<AlertIdentifier>;
  template class DLLEXP_BASICS DynPtrArray<PathItem>;
  template class DLLEXP_BASICS DynPtrArray<CharString>;
  template class DLLEXP_BASICS DynPtrArray<ManagerIdentifier>;
  template class DLLEXP_BASICS DynPtrArray<PVSSulong>;
  template class DLLEXP_BASICS DynPtrArray<ProjDirs>;
