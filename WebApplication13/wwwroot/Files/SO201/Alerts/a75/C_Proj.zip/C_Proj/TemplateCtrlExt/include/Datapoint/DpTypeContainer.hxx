#ifndef _DPTYPECONTAINER_H_
#define _DPTYPECONTAINER_H_

// DATEIBESCHREIBUNG ==============================================================
// DATEINAME:     DpTypeContainer.hxx
// VERANTWORTUNG:  Stanislav Meduna
//
// BESCHREIBUNG:   Ein Kontainer zur Verwaltung aller DpTypen.
//
// VERWENDUNG:     Die Methoden dieser Klasse ermoeglichen:
//     - ein Typ in den Kontainer zu speichern (addType)
//     - ein Typ loeschen (deleteType)
//     - auf einem Typ zuzugreifen (getTypePtr)
//
//     Der Kontainer macht immer eine Kopie des Typs.
//     Nach dem Eintrag muss man also auf den Typ
//     nur mit Hilfe der getTypePtr-Methode zugreifen.

#ifndef _DPTYPE_H_
#include <DpType.hxx>
#endif

#ifndef _DPTYPES_H_
#include <DpTypes.hxx>
#endif

#ifndef _VARIABLE_H_
#include <Variable.hxx>
#endif

#include <SimplePtrArray.hxx>

#include <ostream>

class itcNdrUbSend;
class itcNdrUbReceive;

// ========== DpTypeContResult ============================================================
// Returntyp des Typcontainers
enum DpTypeContResult
{
  DpTypeContOK,
  DpTypeContDup,
  DpTypeContInconsistent,
  DpTypeContNotFound,
  DpTypeContRefExists,
  DpTypeContRefDoesntExist,
  DpTypeContRefLoop,
  DpTypeContInternalError
};

// Vorwaerts-Deklarationen :
class DpIdentifier;
class DpIdentList;

typedef DynPtrArray<DpType>  DpTypeList;

#if defined(LIBS_AS_DLL)
template class DLLEXP_DATAPOINT SimplePtrArray<class DpTypeContainer>;
#endif

/** DpTypeContainer provides following functionality for adding, deleting and retrieving the types from the container.

Container makes always a copy of the type. 
After the type is inserted into the container, it can be retrieved by getTypePtr() method.
*/
class DLLEXP_DATAPOINT DpTypeContainer
{
  /// <summary>
  /// Declare test class as a friended class, having access to private/protected methods
  /// </summary>    
  friend class UNIT_TEST_FRIEND_CLASS;
	
public:
  /// Get type container via system number.
  static DpTypeContainer * getTypeContainerPtr(SystemNumType sys);
  /// Cut type container via system number.
  static DpTypeContainer * cutTypeContainerPtr(SystemNumType sys);
  /// Set type container via system number.
  static void setTypeContainerPtr(DpTypeContainer *nwePtr);
  /// Delete all containers and free all used memory.
  static void deleteAllContainers();

public:
  /// Default constructor.
  DpTypeContainer();
  /// Constructor.
  DpTypeContainer(const DpTypeContainer &newTypeCont);
  /// Destructor.
  ~DpTypeContainer();

  /// Get system number.
  SystemNumType  getSystem() const;
  /// Set system number.
  void  setSystem(SystemNumType newSys);

  /// Interface class for list of original types before a change
  class DLLEXP_DATAPOINT TypeList
  {
  public:
    /// Constructor.
    TypeList() : typeList(0) {}
    /// Destructor
    ~TypeList() { clear(); }
    /// Clear the list.
    void clear()
    {
      if (typeList)
      {
        for(DpType **typePtr = typeList; *typePtr; typePtr++) delete *typePtr;
        delete [] typeList;
        typeList = 0;
      }
    }

    /// Array of types.
    DpType **typeList;
  };

  /// Assignment operator.
  const DpTypeContainer &operator=(const DpTypeContainer &newTypeCont);
  /// Write the instance into the itcNdrUbSend stream.
  friend DLLEXP_DATAPOINT itcNdrUbSend &operator<<(itcNdrUbSend &ndrStream, const DpTypeContainer &typeCont);
  /// Read the instance from the itcNdrUbReceive stream.
  friend DLLEXP_DATAPOINT itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream, DpTypeContainer &typeCont);

  /** Get the type object.
  @retval Returns NULL if the type was not found.
  */
  DpType *getTypePtr(DpTypeId typeName);
  /** Get the type object.
  @retval Returns NULL if the type was not found.
  */
  const DpType *getTypePtr(DpTypeId typeName) const;
  /// Get element type.
  DpTypeContResult getElementType(const DpIdentifier &id, DpElementType &elTypeRef) const;
  /// Get attribute type.
  DpTypeContResult getAttributeType(const DpIdentifier &id, VariableType &varTypeRef) const;

  /** Add new type into the container.
  Check for consistency, rebuild fwd refs, but not backward refs.
  */
  DpTypeContResult addType(const DpType &newType);

  /** Add new type into the container.
  No consistency check is done, rebuild fwd refs, but not backward refs.
  */
  DpTypeContResult addType(DpType *typePtr);

  /** Remove the type from the container.
  Clears the type from other's backward references, but don't check if references exist (this can change).
  */
  DpTypeContResult deleteType(DpTypeId typeId);

  /** Change a type and all types, that reference it.
  @param newType Type to be changed.
  @param[out] origTypes List of original types (ends with 0).
  @param[out] newTypes List of new types (ends with 0).        
  */
  DpTypeContResult changeType(const DpType &newType, TypeList &origTypes, TypeList &newTypes);

  /// Traverse all types in the container.
  PVSSboolean visitEveryType(int (*callback)(const DpType &));

  /** Traverse in the order of dependence.
  If node B references node A, node A will be visited first.
  */
  PVSSboolean visitEveryTypeInDepOrder(int (*callback)(const DpType &));

  /// Rebuild forward references in all Types.
  DpTypeContResult rebuildFwdRefs();
  /// Rebuild backward references in all Types.
  DpTypeContResult rebuildBwdRefs();
  /** Add backward reference.
  If this type references other types, inform them, that they are referenced.
  */
  DpTypeContResult addBwdRefsFromType(DpTypeId typeId);
  /** Delete backward reference.
  If this type referenced other types, inform them, that they are no more referenced.
  */
  DpTypeContResult deleteBwdRefsFromType(DpTypeId typeId);

  /// Rebuild all references.
  DpTypeContResult rebuildTypeRefs();

  // Check functions. They are giving correct results
  // only if the forward and backward references in the
  // container are up-to-date.

  /** Check whether the type can be inserted.
  The type must not be in the container, must be consistent, the references must not form a loop and all referenced types must exist.
  The function gives correct result only if the forward and backward references in the container are up-to-date.
  */
  DpTypeContResult canBeInserted(const DpType &aType) const;

  /** Check whether the type can be changed.
  The type must be consistent, the references must not form a loop and all referenced types must exist.
  The function gives correct result only if the forward and backward references in the container are up-to-date.
  */
  DpTypeContResult canBeChanged(const DpType &aType) const;

  /** Check whether the type can be deleted.
  The function gives correct result only if the forward and backward references in the container are up-to-date.
  @retval Returns OK if yes, RefExists if not.
  */
  DpTypeContResult canBeDeleted(DpTypeId typeId) const;

  /** Expand references in the type.
  If the given type contains references, which are not expanded, allocate element numbers and expand the type using types in the container.
  */
  DpTypeContResult expandRefsInType(DpType &bareType) const;

  /// Strip the expanded references from the type.
  DpTypeContResult stripRefsFromType(DpType &adjType) const;

  /** Adjust references in the type.
  Adjust the given type according to its version in the typecontainer and to the referenced types. If there 
  are elements added (compared to expanded type in the container), new elIds will be allocated. After 
  running this function, the adjType contains the to-be expanded version of the type.
  The typical usage is adjusting the type after a referenced type has been changed. After adjustRefsInType we have 
  a new image of the type, which we can then compare, insert.
  @param[in,out] adjType The type of which references are to be adjusted.
  */
  DpTypeContResult adjustRefsInType(DpType &adjType) const;

  /** Get a list of types, which are affected by change of the said type. 
  @param typeId Type ID of the inspected type. 
  @param[out] list List of affected types (end is marked with 0). Delete the list when it is no more needed. The list is sorted according to 'distance' from the given type.        
  */
  DpTypeContResult getListOfAffectedTypes(DpTypeId typeId, DpTypeId *&list);

  /** Compare the type containers. 
  They are equal iff they have the same types and the types have the same structure, including the element numbers.
  */
  static PVSSboolean equal(const DpTypeContainer &tc1, const DpTypeContainer &tc2);

  /** Print debug information to a stream.
  @param to     The output stream.
  @param level  Controls the amount of debug information printed. The higher level the more information is printed.
  */
  void debug(std::ostream &to, int level) const;

  /// Get the length of TypeContainer.
  DynPtrArrayIndex  length() {return dpTypeList.getNumberOfItems();}

  /** This function determines the ElementIds for all leafes
  of a given data point type.
  The type must be defined in the DpIndentifier sDpId.
  The dpeList contains copies of the sDpIds but fill filled ElementIds.
  @param dpeList contains DPIDs with the different ElementIds of the given type.
  @param sDpId contains the type identifier for which ElemetnIds should de determined
  @return PVSS_TRUE  in case of success
  PVSS_FALSE in case of error
  */
  PVSSboolean getElementIdsForType(DpIdentList &dpeList, const DpIdentifier &sDpId) const;

private:
  // Recursive search for unfilled references. Expand, when found
  DpTypeContResult expandRefsInTypeSubTree(DpType &bareType, DpTypeNode *nodePtr) const;

  // Recursive expand. srcNode will be appended to dstNode. Then the
  // dstNode will be set to the new node and the function will be
  // called for all children of srcNodePtr.
  DpTypeContResult expandRefsInTypeSubTree(
    DpType &bareType,
    DpTypeNode *dstNodePtr,
    const DpType *srcTypePtr, const DpTypeNode *srcNodePtr) const;

  // Recursive copying, without copying the expanded references
  DpTypeContResult stripRefsFromTypeSubTree(
    DpType &adjType,
    const DpType *srcTypePtr, const DpTypeNode *srcNodePtr) const;

  // Recursive adjusting - top half. Copy all up to first
  // reference. Then call the bottom half to perform the adjusting.
  DpTypeContResult adjustRefsInTypeSubTree(
    DpType &adjType,
    const DpType *contTypePtr,
    const DpType *srcTypePtr, const DpTypeNode *srcNodePtr) const;

  // Recursive adjusting - bottom half. Each source node will be
  // checked, whether it exists in the container's version of the type
  // and if not, new id will be allocated. If allocNew is set,
  // (or if contNodePtr is null) the new id will be allocated
  // unconditionally.
  DpTypeContResult adjustRefsInTypeSubTree(
    DpType &adjType,
    PVSSboolean allocNew,
    DpTypeNode *dstNodePtr,
    const DpType *contTypePtr, const DpTypeNode *contNodePtr,
    const DpType *srcTypePtr, const DpTypeNode *srcNodePtr) const;

  // Check for loops. Traverse the references, checking
  // for their presence in the past runs.
  DpTypeContResult checkForLoops(const DpType *srcTypePtr, DpTypeId *historyList, DpTypeId *historyPtr) const;

  // List of affected types
  DpTypeContResult getListOfAffTypes(const DpType *srcTypePtr, DpTypeId *historyList, DpTypeId *&historyPtr) const;

  // append Item without checks
  DpTypeContResult appendType(DpType *typePtr);

  PVSSboolean rebuildFwdRef(DpType &type);
  PVSSboolean rebuildBwdRef(DpType &type);

  static int compareDpType(const DpType *a, const DpType *b);

  static int cmpDepend(const void *item1Ptr, const void *item2Ptr)
  {
    return *((DpTypeId *) item1Ptr) - *((DpTypeId *) item2Ptr);
  }

  PVSSboolean getOneElementIdForType(DpIdentList &dpeList, DpIdentifier &dpId,
    const DpType *theType, const DpTypeNode *node) const;

private:
  static SimplePtrArray<DpTypeContainer> typeContArray;
  SystemNumType   sysNum;
  DpTypeList      dpTypeList;
};

// ---------------------------------------------------------------------------------------
// Access type container via static function ("singleton")

inline DpTypeContainer * DpTypeContainer::getTypeContainerPtr(SystemNumType sys)
{
  return typeContArray[sys.toPVSSulong()];
}

//--------------------------------------------------------------------------------

inline DpTypeContainer * DpTypeContainer::cutTypeContainerPtr(SystemNumType sys)
{
  return typeContArray.replaceAt(sys.toPVSSulong(), 0);
}

//--------------------------------------------------------------------------------
// Get / Set system number

inline SystemNumType DpTypeContainer::getSystem() const
{
  return sysNum;
}

//--------------------------------------------------------------------------------

inline void DpTypeContainer::setSystem(SystemNumType newSys)
{
  sysNum = newSys;
}

// ================================================================================

#endif /* _DPTYPECONTAINER_H_ */
