//----------------------------------------------------------------------------
//  Copyright (C) Siemens AG 2018. All Rights Reserved.
//----------------------------------------------------------------------------

#ifndef _DEBUG_OUTPUT_HXX_
#define _DEBUG_OUTPUT_HXX_

#include <CharString.hxx>
#include <Types.hxx>
#include <iostream>
#include <sstream>

// forward declarations
namespace Tracing { class TraceEngine; }

// type for debug flag ids
typedef PVSSshort DbgFlagId;

namespace DebugOutput
{
  // migrated functions from Resources

  /** flags for logging.
  @n These constants are used when -log command is given.
  Since logging is handled internally, this is for information only.
  */
  enum LogFlags
  {
    /// -log +dp
    LOG_DATAPOINT,
    /// -log +file
    LOG_FILE,
    /// -log +stderr
    LOG_STDERR
  };

  /** flags for dbgLevel
      @n These flags can be set by number on cmdline. Numbers can
      be separated by , to get more flags, like -dbg 2,8,15.
      For API purposes there are constants DBG_API_USR1 to DBG_API_USR3,
      for ComDrv there are DBG_DRV_USR1 to DBG_DRV_USR3.
  */
  // If you add a flag here, don't forget to update the List in DebugLevelSettings, too!
  enum DbgFlags
  {
    // changes should be protocoled in dispatch as well
    /// (1). no time info will be printed on streams
    DBG_TIMEOFF=1,
    /// (2). the general purpose debug flag; used for run info on current manager
    DBG_WORK=2,
    /// (3). give warning when send buffer is extended
    DBG_EXTBUFFER=3,
    /// (4). check sockets if input is ready
    DBG_INPUTREADY=4,
    /// (5). check sockets if output is ready
    DBG_OUTPUTREADY=5,
    /// (6). SND stamp;
    DBG_SNDSTAMP=6,
    /// (7). BCV stamp
    DBG_RCVSTAMP=7,
    /// (8). debug query actions
    DBG_QUERY=8,
    /// (9). show manager heartbeat
    DBG_DISPATCH = 9,
    /// (10). first available API debug flag - use at your will
    DBG_API_USR1=10,
    /// (11). second available API debug flag - use at your will
    DBG_API_USR2=11,
    /// (12). third available API debug flag - use at your will
    DBG_API_USR3=12,
    /// (13). time
    DBG_DM_TIME=13,
    /// (13). status function
    DBG_EV_STATFUNC=13,
    /// (14). set temp. slot
    DBG_DM_SETEMPTYSLOT=14,
    /// (15). service mode
    DBG_DM_SERVICEMODE=15,
    /// (16). event work
    DBG_EV_WORK=16,
    /// (17). event time 100
    DBG_EV_TIME100=17,
    /// (18). source time
    DBG_EV_SOURCETIME=18, // XXX remove, wenn Systemzeitbeigabe geklaert ist!!!
    /// (19). event file
    DBG_EV_EVENTFILE=19,
    /// (20). alert file
    DBG_EV_ALERTFILE=20,
    /// (21). event main
    DBG_EV_EVMAIN=21,
    /// (22). panel time
    DBG_UI_PANELTIME=22,
    /// (23). show report manager actions (obsolete)
    DBG_UI_RENT=23,
    /// (24). common DRV heartbeat - use
    DBG_DRV_WORK=24,
    /// (25). first available DRV debug flag - use at your will
    DBG_DRV_USR1=25,
    /// (26). second available API debug flag - use at your will
    DBG_DRV_USR2=26,
    /// (27). third available API debug flag - use at your will
    DBG_DRV_USR3=27,
    /// (28). show redundancy messages
    DBG_REDUNDANCY=28,      // redundancy messages
    /// (28). for people who can't write redundancy
    DBG_REDU=DBG_REDUNDANCY,
    /// (29). show ctrl trace
    DBG_CTRL_TRACE=29,
    /// (30), show every n sec a snd/rcv statistic
    DBG_MSG_STATISTIC=30,
    /// (31), extended Warnings   
    DBG_EXT_WARNING=31,           // don't modify number BCM relies on it
    /// (32), use of old status
    DBG_STATUS32=32,
    /// (33), HTTP traffic
    DBG_HTTP=33,
    /// (34), BCM                 
    DBG_BCM = 34,                 // don't modify number BCM relies on it
    /// (35), NFR outputs         
    DBG_NFR = 35,                 // don't modify number BCM relies on it
    /// (36), Statistics counter, simple version
    DBG_STAT_SIMPLE = 36,
    /// (37), Statistics counter, long version
    DBG_STAT_HISTO = 37,
    // Must be last
    DBG_LAST
  };

  /// flags for reportLevel
  /// @n They are set by -report cmdline arg.
  enum ReportFlags
  {
    /// (0). restrict report output to summary
    REP_SUMMARY = 0,
    /// (1). report CPU usage
    REP_CPU = 1,
    /// (2). report HEAP usage
    REP_HEAP = 2,
    /// (3). report dispatcher state & message queue len
    REP_DISPATCH = 3,
    /// (4). report pending query state
    REP_QUERY = 4,    // this flag is used by data & event
    /// (5). call backs
    REP_CALLBACKS = 5,
    /// (6). db type
    REP_DPTYPE = 6,
    /// (7). DP identification
    REP_DPIDENTIFICATION = 7,
    /// (8). config manager
    REP_CONFIGMANAGER = 8,
    /// (9) give overview of scripts, etc. in Controller
    REP_CTRL = 9,
    /// (10). DM action
    REP_DM_ACTION = 10,
    /// (11). DM status
    REP_DM_STATUS = 11,
    /// (12). DM time list
    REP_DM_TIMELIST = 12, // 09.05.00 esperrer HDB timelist
    // Must be last
    REP_LAST
  };

  /// check if log flag is set
  /// @param logFlag the log flag
  DLLEXP_BASICS bool isLogFlag(LogFlags logFlag);

  /// returns true if debug output to stderr is enabled
  DLLEXP_BASICS bool isLogToStderr();

  /// check if any log flag is set which determines that log output should be written to stderr.
  DLLEXP_BASICS bool isLogFlagCerr();

  /// set log flag
  /// @param logFlag the log flag
  DLLEXP_BASICS void setLogFlag(LogFlags logFlag);

  /// clear log flag
  /// @param logFlag the log flag
  DLLEXP_BASICS void clearLogFlag(LogFlags logFlag);

  /// enable/disable debug output to stderr
  //DLLEXP_BASICS void setLogToStderr(bool enabled);

  /// print out the used debug flags and their meaning
  DLLEXP_BASICS void printHelpDbg(std::ostream &os);

  /// set a list of debug flags as given on the commandline
  /// @param dbgList the list of flags, e.g. "1,2,3" which is the equivalent to the commandline "-dbg 1,2,3"
  DLLEXP_BASICS void setDbgFlagList(const CharString &dbgList);

  /// get a list of active debug flags
  /// @return a string describing the list of active debug flags
  DLLEXP_BASICS CharString getDbgFlagList();

  /// check if given debug flag is set
  /// @param dbgFlag the debug flag
  DLLEXP_BASICS bool isDbgFlag(DbgFlagId flag);

  /// check if given debug flag is set
  /// @param dbgFlag the debug flag
  IL_DEPRECATED("deprecated, use isDbgFlag(DbgFlagId)")
  DLLEXP_BASICS bool isDbgFlag(const CharString &flag);

  /// check if given debug flag is set and ouput should go to stderr
  /// @param flag the debug flag
  DLLEXP_BASICS bool isDbgFlagCerr(DbgFlagId flag);

  /// register debug flag with optional description
  /// @param dbgName the debug name
  /// @param description the description
  /// @return the debug flag
  DLLEXP_BASICS DbgFlagId registerDbgFlag(const CharString &dbgName, const char *description = 0);

  /// get name of the given debug flag
  /// @param dbgFlag the debug flag
  DLLEXP_BASICS CharString getDbgFlagName(DbgFlagId dbgFlag);

  /// get name of the given debug flag
  /// @param dbgName the debug name
  IL_DEPRECATED("deprecated, use getDbgFlagName(DbgFlagId)")
  DLLEXP_BASICS CharString getDbgFlagName(const CharString &dbgName);

  /// get the id of the debug flag with the given name
  /// @param dbgName the name of a debug flag
  /// @return the numeric flag id, or -1 if there is no such flag
  DLLEXP_BASICS DbgFlagId getDbgFlagId(const char *dbgName);

  /// set given debug flag
  /// @param dbgFlag the debug flag
  /// @param state the state to set
  /// @return old state of the flag
  DLLEXP_BASICS bool setDbgFlag(DbgFlagId dbgFlag, bool state = true);

  /// set given debug flag
  /// @param dbgName the debug name
  /// @param state the state to set
  /// @return old state of the flag
  DLLEXP_BASICS bool setDbgFlag(const CharString &dbgName, bool state = true);

  /// print out the used report flags
  DLLEXP_BASICS void printHelpReport(std::ostream &os);

  /// set a list of report flags as given on the commandline
  /// @param reportList the list of flags, e.g. "1,2,3" which is the equivalent to the commandline "-report 1,2,3"
  DLLEXP_BASICS void setReportFlagList(const CharString &reportList);

  /// get a list of active report flags
  /// @return a string describing the list of active report flags
  DLLEXP_BASICS CharString getReportFlagList();

  /// chcek if report flag is set
  /// @param flag the report flag
  DLLEXP_BASICS bool isReportFlag(DbgFlagId flag);

  /// check if report flag is set
  /// @param repName the report name
  IL_DEPRECATED("deprecated, use isReportFlag(DbgFlagId)")
  DLLEXP_BASICS bool isReportFlag(const CharString &repName);

  /// get the id of the report flag with the given name
  /// @param reportName the name of a report flag
  /// @return the numeric flag id, or -1 if there is no such flag
  DLLEXP_BASICS DbgFlagId getReportFlagId(const char *reportName);

  /// set report flag
  /// @param repName the report name
  /// @param on the value to set
  DLLEXP_BASICS void setReportFlag(const CharString &repName, bool on);

  /// register report flag with optional description
  /// @param repName the report name
  /// @param description the description
  /// @return report level
  DLLEXP_BASICS DbgFlagId registerReportFlag(const CharString &repName, const char *description = 0);

  /// check if report is pending
  DLLEXP_BASICS bool isReportPending();

  /// clear report pending flag
  DLLEXP_BASICS void clearReportPending();

  /// get the msg receive debug level
  DLLEXP_BASICS int getRcvLevel();

  /// get the msg send debug level
  DLLEXP_BASICS int getSndLevel();

  /// set the msg receive debug level
  /// @return the previous level
  DLLEXP_BASICS int setRcvLevel(int _level);

  /// set the msg send debug level
  /// @return the previous level
  DLLEXP_BASICS int setSndLevel(int _level);

  /// Flags for writeSndRcvTrace()
  enum SndRcvFlags
  {
    /// -snd 1
    SND_SHORT = 0,
    /// -snd 2
    SND_FULL,
    /// -rcv 1
    RCV_SHORT,
    /// -rcv 2
    RCV_FULL
  };

  /// Writes a text message with the given debug flag to stderr and tracing
  /// @internal
  DLLEXP_BASICS void writeFlagMsg(DbgFlagId flag, const char *msg);

  /// Writes a text message with the given debug flag to stderr and tracing
  /// @internal
  IL_DEPRECATED("deprecated, use writeFlagMsg(DbgFlagId, const char*)")
  inline DLLEXP_BASICS void writeFlagMsg(const CharString &flagName, const char *msg)
  {
    writeFlagMsg(getDbgFlagId(flagName), msg);
  }

} // namespace DebugOutput

#endif // _DEBUG_OUTPUT_HXX_
