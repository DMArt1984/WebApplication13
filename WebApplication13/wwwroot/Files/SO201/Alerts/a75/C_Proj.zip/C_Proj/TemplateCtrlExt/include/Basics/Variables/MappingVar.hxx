#ifndef _MAPPINGVAR_H_
#define _MAPPINGVAR_H_

// BESCHREIBUNG:  Enth�lt ein assotiatives Array von Variablen.

#ifndef _VARIABLE_H_
#include <Variable.hxx>
#endif

#ifndef _SIMPLEPTRARRAY_H_
#include <SimplePtrArray.hxx>
#endif

#ifndef _CHARSTRING_H_
#include <CharString.hxx>
#endif


/**
    A Mapping class represents a hashmap of variables.

    This class is designed to hold a hashmap os discrete variables of different types.
    @n The mapping type variable. This variable is not for being sent through a
    message. It has only locally restricted purposes.

    @classification ETM internal

*/
class DLLEXP_BASICS MappingVar : public Variable
{
  public:
    /** Default constructor
    */
    MappingVar() { cachedIsA = MAPPING_VAR; }

    /** Copy constructor
        @param mapVar MappingVar value to be copied.
    */
    MappingVar(const MappingVar &mapVar) : Variable(mapVar) { cachedIsA = MAPPING_VAR; operator=(mapVar); }

    /** Default destructor
    */
    ~MappingVar() {}

    /** Declares new and delete operator.
    */
    AllocatorDecl;

     /** Writes MappingVar value to the itcNdrUbSend stream.
        @param ndrStream Output stream.
        @param map Streamed MappingVar variable.
        @return itcNdrUbSend stream.
    */
    friend DLLEXP_BASICS itcNdrUbSend &operator<<(itcNdrUbSend &ndrStream, const MappingVar &map);

    /** Reads the MappingVar value from the itcNdrUbReceive stream.
        @param ndrStream input stream.
        @param map MappingVar variable receiving the value from the stream.
        @return itcNdrUbReceive stream.
    */
    friend DLLEXP_BASICS itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream, MappingVar &map);

    /** Comparison operator ==
        @param rVal Compared value.
        @return int 1 if the values are equal, otherwise 0.
        @n Important: this operator checks the VariableType, so two objects are only equal, if
        they also have the same class (no conversion is done; see other operators)
    */
    int operator==(const Variable &rVal) const;

    /** Overloaded assignment operator used for type conversions.
        @param rVal Assigned value.
        @return Variable with assigned value.
    */
    Variable &operator=(const Variable &rVal);

    /** Overloaded single assignment operator used for type conversions.
        @param rVal MappingVar assigned value.
        @return Variable with assigned value.
    */
    MappingVar &operator=(const MappingVar &rVal) { operator=((const Variable&)rVal); return *this; }

    ///
    /** Set the value at key. Both variables are cloned
        @param key Variable hashmap key.
        @param value Variable hashmap value.
        @return PVSS_TRUE or PVSS_FALSE.
    */
    PVSSboolean  setAt(const Variable &key, const Variable &value);

    ///
    /** Set the value at key. Both variables are captured
        @param key Variable hashmap key.
        @param value Variable hashmap value.
        @return PVSS_TRUE or PVSS_FALSE.
    */
    PVSSboolean  setAt(Variable *key, Variable *value);

    /** Returns the value for the specified key.
        @param key Variable hashmap key the value is returned for.
        @return NULL if not found, Variable value otherwise
    */
    const Variable * getAt(const Variable &key) const;

    /** Cut the value at key. The caller is responsible to free the memory.
        @param key Variable hashmap key to be cut.
        @return NULL if not found, Variable value otherwise
    */
    Variable *cutAt(const Variable &key);

    /** Access operator.
        @param key Variable hashmap key to be accessed.
        @return NULL if not found, Variable value otherwise
    */
    const Variable * operator[](const Variable &key) const { return getAt(key); }

    /** Returns the key according to the specified index <0,n>. Returns 0 if n >= length
        @param idx unsigned int key index.
        @return NULL if not found, Variable key otherwise
    */
    const Variable * getKey(unsigned int idx) const { return keys[idx]; }

    /** Returns the value according to the specified index <0,n>. Returns 0 if n >= length
        @param idx unsigned int key index.
        @return NULL if not found, Variable key otherwise
    */
    const Variable * getValue(unsigned int idx) const { return values[idx]; }

    /** Empties the MappingVar variable : deletes all variables
    */
    void clear() {keys.clear(); values.clear();}

    /** Returns the length of the hashmap
        @return int a number of items in the hashmap
    */
    unsigned int getNumberOfItems() const {return keys.getNumberOfItems();}

    /** Creates a new dynamicaly allocated MappingVar variable
        @return Variable* pointer to a newly allocated MappingVar created by the
        default constructor (value is 0).
    */
    Variable *allocate() const { return new MappingVar; }

    /** Overloaded function returning MAPPING_VAR
        @return VariableType (MAPPING_VAR)
    */
    VariableType isAUncached() const { return MAPPING_VAR; }

    /** Returns the VariableType for the specified type
        @param varType VariableType.
        @return VariableType for this type.
    */
    VariableType isAUncached(VariableType varType) const;

    /** Clones the current variable object, a deeps copy of the original object is created
        @return Variable* pointer to a newly created MappingVar with the same value,
        created by the copy constructor.
    */
    virtual Variable *clone() const {return new MappingVar(*this);}

    /** Writes the ndr stream
        @param ndrStream itcNdrUbSend the stream to be written to.
    */
    void outNdrUb(itcNdrUbSend &ndrStream) const;

    /** Reads the ndr stream
        @param ndrStream itcNdrUbReceive the steam to be read from.
    */
    void inNdrUb(itcNdrUbReceive &ndrStream);

     /** Formats the value acording to the format string.
        @param  format  The format string. If the string is not empty it is
                used as an argument to the sprintf function.
                Else a default is used.
        @return The string representation of the value.
    */
    virtual CharString formatValue(const CharString &format) const;

    /** Format the value according to a format string.
        @param format The format string. If the string is not empty is is
               used as an argument to the sprintf function (if useful).
               Else a default is used
        @param target This is a buffer with length len, which is directly written to.
               This method is more performant than the one which returns a CharString,
               because no alloc is done.
        @param len the length of the target
        @return Number of bytes written into target without 0-byte,
                or a negative value on error (like buffer too small)
    */
    virtual int formatValue(const CharString &format, char *target, size_t len) const;

  private:
    static int keyCompare(const Variable *, const Variable *);

    SimplePtrArray<Variable> keys;
    SimplePtrArray<Variable> values;
};

#endif
