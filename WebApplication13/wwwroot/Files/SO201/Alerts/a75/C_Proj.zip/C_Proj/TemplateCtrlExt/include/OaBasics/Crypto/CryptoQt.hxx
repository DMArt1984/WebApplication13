// -----------------------------------------------------------------------------
// creator: Andras Horvath - 01.09.2017
// purpose: Symmetric encryption - with Qt dependency
// Internal use
// -----------------------------------------------------------------------------
#ifndef _CRYPTOQT_H_
#define _CRYPTOQT_H_

#include <QByteArray>
#include <CharString.hxx>

/**
  @class Crypto_Internal
  @brief Collection of cryptoraphic functions
*/
struct DLLEXP_OABASICS CryptoQt
{
  /**
    @brief Symmetric-key encryption
    @param source    data to encrypt
    @param password  secret key for the encryption
    @param algoNum   select the used algorythm. -1 means to use the best
                     available, in this case algoNum returns the algorithm used
    @param doEncrypt true: encrypt the data, false: decrypt the data
    @return          array of the result
  */
  static QByteArray encrypt(const QByteArray& source,
                            const QByteArray& password,
                            int& algoNum,
                            bool doEncrypt = true);

  /**
    @brief Symmetric-key decryption
    @param source    data to decrypt
    @param password  secret key for the decryption
    @param algoNum   use the returned algoNum from Crypt::encrypt()
    @return          array of the result
  */
  static QByteArray decrypt(const QByteArray& source,
                            const QByteArray& password,
                            int algoNum);

private:
  // encrypt @source data with @password using DES
  static QByteArray encryptDES(const QByteArray& source,
                               const QByteArray& password,
                               bool doEncrypt = true);

  // encrypt @source data with @password using AES-256
  static QByteArray encryptAES256(const QByteArray& source,
                                  const QByteArray& password,
                                  bool doEncrypt = true);
};

#endif
