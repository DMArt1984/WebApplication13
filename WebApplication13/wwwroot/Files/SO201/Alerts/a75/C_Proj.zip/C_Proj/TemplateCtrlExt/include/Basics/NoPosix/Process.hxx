#ifndef _PROCESS_H_
#define _PROCESS_H_

/*
VERANTWORTUNG: Johann Klugsberger    
BESCHREIBUNG:
*/
#ifdef _WIN32
#include <Windows.h>
#endif

#include <signal.h>
#include <stdio.h>

#ifndef _CHARSTRING_H_
#include <CharString.hxx>
#endif

#ifndef SIGKILL  // ! defined in WIN32
#define SIGKILL 9
#endif

#ifdef _WIN32
typedef DWORD pid_t;
#endif

#ifndef _WIN32
#define INFINITE -1
#endif

/** the process control functions wrapper. this class covers all process related calls
    for platform compatibility and keeps track of the process state.
*/
class DLLEXP_BASICS Process
{
public:
    /// constructor
  Process();

#ifdef _WIN32
  /**  constructor to catch an existing process (Windows only)
       the process name is compared case insensitive up to the length of procName;
       if not unique, the first match is taken
   */
  Process(const char *procName, const PVSSboolean noKill = true);
#endif

    /// destructor
  virtual ~Process();

  /** send a signal to the process
    @param sig signal
  */
  int kill(int sig);

  /** send SIGTERM, if no reaction or on Error send SIGKILL
  */ 
  int kill();

  /** execute 
      @param cmdWithParam if path != 0 path+cmdWithParam will be executed; 
      @param path must not terminate with FileSys::PATH_CHAR!
      @return  >= 0, if OK; == -1 if exec() fails. Use getErrorString() for error description.
      @see getErrorString()
  */
  pid_t exec( const char * cmdWithParam, const char * path= 0);

  /** execute 
      @param cmdWithParam if path != 0 path+cmdWithParam will be executed; 
      @param path must not terminate with FileSys::PATH_CHAR!
      @param cwd current working directory
      @return  >= 0, if OK; == -1 if exec() fails. Use getErrorString() for error description.
      @see getErrorString()
  */
  pid_t exec( const char * cmdWithParam, const char * path, const char *cwd);

  /// called after fork and before execl in the child process
  virtual void childCleanup();

  /** redirect stdin; this function must be called BEFORE exec() is called!
      @note On Windows, if this function has been called, inheritance of handles for the
            process will always be enabled, regardless of other parameters or settings,
            because it is required for redirection.
      @param file input file
      @return TRUE ( != 0 ) on success.
  */
  int redirectStdIn(const char *file);

  /** redirect stdout AND stderr to the same file.
      ( this is not the same as calling redirectStdOut() and redirectStdErr()
      with the same file !! )
      This function must be called BEFORE exec() is called!
      @note On Windows, if this function has been called, inheritance of handles for the
            process will always be enabled, regardless of other parameters or settings,
            because it is required for redirection.
      @param file output file
      @param mode write mode
      @return TRUE ( != 0 ) on success.
  */
  int redirectStdOutAndErr(const char * file, const char *mode = "a");
  
  /** redirect stdout; this function must be called BEFORE exec() is called!
      @note On Windows, if this function has been called, inheritance of handles for the
            process will always be enabled, regardless of other parameters or settings,
            because it is required for redirection.
      @param file output file
      @param mode write mode
      @return TRUE ( != 0 ) on success.
  */
  int redirectStdOut(const char * file, const char *mode = "a");

  /** redirect stderr; this function must be called BEFORE exec() is called!
      @note On Windows, if this function has been called, inheritance of handles for the
            process will always be enabled, regardless of other parameters or settings,
            because it is required for redirection.
      @param file output file
      @param mode write mode
      @return TRUE ( != 0 ) on success.
  */
  int redirectStdErr(const char * file, const char *mode = "a");

  /// get the pid
  pid_t getPid()
  {
#ifdef _WIN32
    return processInfo.dwProcessId;
#else
    return processId;
#endif
  }

  /// set process visibility
  void setVisible(PVSSboolean v= PVSS_TRUE)
  {
    visible= v;
  }
  
  /// set process console
  void setNewConsole(PVSSboolean f = PVSS_TRUE)
  {
      newConsole = f;
  }

  /// set no kill on destruction
  void setNoKill(PVSSboolean f = PVSS_TRUE)
  {
      noKill = f;
  }

  /// set no inheritance of handles
  void setNoInherit(PVSSboolean f = PVSS_TRUE)
  {
     noInherit_ = f;
  }

  /// deprecated !! Use setNoInherit()
  pid_t exec3( const char * cmdWithParam, const char * path= 0, bool inherit = true);

  /// deprecated !! Use setNoInherit()
  pid_t exec4( const char * cmdWithParam, const char * path, bool inherit, const char *cwd);

  /** check, if process is running and return exitCode
      @param exitCode return code (lowest 8 bit) of exiting process
      @return true/false
  */
  int isRunning(int & exitCode);
 
  /// check if process is running
  int isRunning();

  /// wait for end of process
  // to wait for a process omits the defunct processes that would otherwise remain (Linux)
  pid_t wait();

  /** wait for end of process and store exitCode
      to wait for a process terminates the defunct process that would otherwise remain (Linux)
      @param exitCode return code (lowest 8 bit) of exiting process
             Linux: is valid only if caller doesn't ignore SIGCHLD; else -1 is returned
      @param timeOut
          0 - don't wait at all
          INFINITE - wait until process has terminated
          timeOut in ms, value of 0 (zero) is possible for immediate return
            timeout on Linux only in sec-steps (1000, 2000, 3000, etc.) possible!!
            is implemented by repeated calls to sleep( 1 )
      @return processId if exit code is valid (child has terminated)
              -1 in most other cases
  */
  pid_t wait(int &exitCode, unsigned long timeOut = (unsigned long) INFINITE);

  /** start a command in the background without receiving any SIGCHLD signals
      On Linux a terminating child process would send SIGCHLD to its parent to signal
      its exit status. However if the parent does not call wait() on its child process
      to retrieve the exit status, the child would become a zombie process,
      filling up the kernel process table.
      This call creates the child process in a way so that the current process will
      never receive a signal from the child.
      It is used to start independant daemon child processes.
      @param cmdWithParam contains the complete commandline including arguments
      @param stdOutErrFile filename to which stdout and stderr will be redirected
      @return true if the child could be started, false otherwise
  */
  static bool startDetached(const CharString &cmdWithParam, const char *stdOutErrFile = 0);

  /// build main-compatible char *argv[]
  static char **buildArgv(const char * cmdLine);
  /// get number of arguments from argv
  static int getArgc(const char **argv);
  /// free result of buildArgV
  static void freeArgv(char ** argv);
  
  /// get process error string
  const CharString & getErrorString() const
  { return errString; }

private:

  void closeProc();
  void closeFiles();
  void init();    // Initialisierung fuer alle Konstruktoren
  
  // Umleitung von stdin / stdout / stderr
# ifdef _WIN32
  int  redirectStdHandle(HANDLE &handle, const char *file, const char *mode);
# else
  int  redirectStdHandle(FILE *&handle, const char *file, const char *mode);
# endif

#ifdef _WIN32
  void makeBatchFileCmdLine(CharString & path);

  PROCESS_INFORMATION processInfo;
  STARTUPINFO startupInfo;
#else
  pid_t processId;
  FILE * hStdInput;
  FILE * hStdOutput;
  FILE * hStdError;
 
#endif

  CharString errString;
  int running;
  int exitCode_;
  PVSSboolean visible;
  PVSSboolean newConsole;
  PVSSboolean noKill;
  PVSSboolean noInherit_;
  
  // copy constructor
  Process(const Process &);
  // assignment operator
  const Process &operator=(const Process &);

  friend class UNIT_TEST_FRIEND_CLASS;
};


#endif /* _PROCESS_H_ */
 
 
