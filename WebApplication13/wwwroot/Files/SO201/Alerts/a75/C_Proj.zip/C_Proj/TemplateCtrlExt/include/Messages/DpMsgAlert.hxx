#ifndef _DPMSGALERT_H_
#define _DPMSGALERT_H_

// Vorwaerts-Deklaration der Eigenen Klasse
class DpMsgAlert;
class Msg;

// ========== DpMsgAlertPtr ============================================================

typedef DpMsgAlert* DpMsgAlertPtr;

#include <ostream>
#include <AlertList.hxx>
#include <DpMsg.hxx>
#include <ManagerIdentifier.hxx>

// ========== DpMsgAlert ============================================================

/// The alert message class
class DLLEXP_MESSAGES DpMsgAlert : public DpMsg 
{
  friend class UNIT_TEST_FRIEND_CLASS;    // ein Unit-Test braucht erweiterten zugriff auf diese Klasse

  public:
    
    /// constructor
    /// @param dest the ManagerIdentifier of destination
    DpMsgAlert(const ManagerIdentifier &dest = ManagerIdentifier());

    /// constructor for DP_MSG_ALERT_VC type
    /// @param origTime the time of origin
    /// @param origMan the ManagerIdentifier of origin
    /// @param origUser the user of origin
    /// @param dest the ManagerIdentifier of destination
    /// @param answer the answer flag
    /// @param alertTime the time used for alertSetTimed, default set to 0,0 which
    ///                  indicates a normal alertSet
    DpMsgAlert(const TimeVar &origTime, const ManagerIdentifier &origMan,
	       PVSSuserIdType origUser, const ManagerIdentifier &dest = ManagerIdentifier(), 
	       PVSSboolean answer = PVSS_TRUE, TimeVar alertTime = TimeVar(0,0));

    /// copy constructor
    /// @param msg the alert message to copy
    DpMsgAlert(const DpMsgAlert &msg);
    
    /// destructor
    ~DpMsgAlert();

    // Operatoren :

    /// operator << for itcNdrUbSend stream
    /// @param ndrStream the stream, which to send to
    /// @param msg the alert message
    friend DLLEXP_MESSAGES itcNdrUbSend &operator<<(itcNdrUbSend &ndrStream, const DpMsgAlert &msg);

    /// operator >> for itcNdrUbReceive stream
    /// @param ndrStream the stream, which to receive from
    /// @param msg the alert message
    friend DLLEXP_MESSAGES itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream, DpMsgAlert &msg);
    
    /// comparison operator ==
    /// @param rVal the message to compare with
    /// @return 0 if not equal else 1
    virtual int operator==(const Msg &rVal) const;
    
    /// assignment operator used for type conversion
    /// @param rVal the message to convert
    /// @return the resulting message
    virtual Msg &operator=(const Msg &rVal);
    
    /// assignment operator for DpMsgAlert
    /// @param rVal the alert message to assign
    /// @return the resulting DpMsgAlert
    virtual DpMsgAlert& operator=(const DpMsgAlert &rVal);

    // Spezielle Methoden :

    /// set iterator on the first group
    /// @return the first group
    AlertAttrList *getFirstGroup() const { return list.getFirstAttrList(); }

    /// set iterator to the next group
    /// @return the next group
    AlertAttrList *getNextGroup() const { return list.getNextAttrList(); }

    /// remove a group
    /// @param g the group to remove
    /// @return if g == lastAccessed then g.getNext() else lastAccessed
    AlertAttrList *removeGroup(AlertAttrList *g);

    /// allocate a new message
    Msg *allocate() const;

    /// get own DP message type
    virtual MsgType isA() const { return type; }
    
  	/// check if own DP message type matches other DP message type
    /// @param dpMsgType the MsgType to check
    /// @return DpMsgAlert type if argument is DpMsgAlert else a DP message type
    virtual MsgType isA(MsgType dpMsgType) const;

    /// get needs answer flag
    virtual PVSSboolean needsAnswer() const {return wantAnswer; } //WP0439 020603 bkoe: no Answer-Message 
    
    /// set needs answer flag
    /// @param answer the value to set
    void setWantAnswer(PVSSboolean answer) { wantAnswer = answer; }

    /// get needs answer flag
    PVSSboolean getWantAnswer() const      { return wantAnswer; }
    
    /// get number of groups
    virtual PVSSulong getNrOfGroups() const { return list.getNumberOfItems(); }
    
    /// get group ID
    /// @param groupIndex the group index
    virtual DpIdentifier getGroupId(PVSSulong groupIndex) const;

    /// get time of origin
    const TimeVar &getOriginTime() const { return originTime; }

    /// get manager of origin
    const ManagerIdentifier &getOriginManager() const { return originManager; }

    /// get user of origin
    PVSSuserIdType getOriginUser() const { return originUser; }

    /// get alert list
    const AlertList &getAlertList() const { return list; }

    /// insert attribute
    /// @param id the item to insert
    /// @param varPtr the pointer to a Variable object which holds the value
    /// @n The call takes ownership of this pointer.
    void insertAttr(const AlertIdentifier &id, VariablePtr varPtr = 0)
    { list.insertAttribute(id, varPtr, PVSS_FALSE); }

    /// insert attribute
    /// @param id the item to insert
    /// @param var the Variable object which holds the value
    void insertAttr(const AlertIdentifier &id, const Variable &var)
    { list.insertAttribute(id, var.clone(), PVSS_FALSE); }

    /// set attribute list
    /// @param newList the list to set
    void setList(const AlertList &newList) { list = newList; }

    /// send debug info to output stream
    /// @param to the output stream
    /// @param level the debug level
    virtual void debug(std::ostream &to, int level) const;

    /// set method for the useServerTime flag
    void setUseServerTimeFlag(PVSSboolean flag);

    /// get method for the useServerTime flag
    PVSSboolean getUseServerTimeFlag() { return useServerTime; }

    /// set the alertTime
    void setAlertTime(TimeVar newAlertTime) { alertTime = newAlertTime; }

    /// get the alertTime
    const TimeVar &getAlertTime() const { return alertTime; }
    
  private:
    void outNdrUb(itcNdrUbSend &ndrStream) const;
    void inNdrUb(itcNdrUbReceive &ndrStream);
    AlertList list;
    MsgType type;
    TimeVar originTime;
    ManagerIdentifier originManager;
    PVSSuserIdType originUser;
    PVSSboolean wantAnswer;
    TimeVar alertTime;
    PVSSboolean useServerTime;
};

//================ Inline-Funktionen =================================================

// konstruiert eine DP_MSG_ALERT_HL !!!
inline DpMsgAlert::DpMsgAlert(const ManagerIdentifier &dest)
  : DpMsg(dest),
  list(),
  type(DP_MSG_ALERT_HL),
  originTime(0, 0),
  originManager(),
  originUser(ROOT_USER),
  wantAnswer(PVSS_FALSE),
  useServerTime(PVSS_FALSE)
{
}

// konstruiert eine DP_MSG_ALERT_VC !!!
inline DpMsgAlert::DpMsgAlert(const TimeVar &origTime, const ManagerIdentifier
    &origMan, PVSSuserIdType origUser, const ManagerIdentifier &dest, PVSSboolean answer, TimeVar aTime)
: DpMsg(dest),
  list(),
  type(DP_MSG_ALERT_VC),
  originTime(origTime),
  originManager(origMan),
  originUser(origUser),
  wantAnswer(answer),
  alertTime(aTime),
  useServerTime(PVSS_FALSE)
{
}

// Copy-Konstruktor
inline DpMsgAlert::DpMsgAlert(const DpMsgAlert &msg)
{
  *this = msg;
}

// Destruktor
inline DpMsgAlert::~DpMsgAlert()
{
}


inline AlertAttrList *DpMsgAlert::removeGroup(AlertAttrList *g)
{
  list.remove(reinterpret_cast<PtrListItem *>(g));  
  return(reinterpret_cast<AlertAttrList *>(list.getLastAccessed()));
}

inline Msg *DpMsgAlert::allocate() const
{
  return new DpMsgAlert;
}


inline MsgType DpMsgAlert::isA(MsgType dpMsgType) const
{ 
  if (dpMsgType == type)
    return dpMsgType;    
  else if (dpMsgType == DP_MSG_ALERT)
    return dpMsgType;
  else
    return DpMsg::isA(dpMsgType);
}


inline Msg &DpMsgAlert::operator=(const Msg &rVal)
{
  if (rVal.isA(DP_MSG_ALERT) == DP_MSG_ALERT)
  {
    return operator=(static_cast<const DpMsgAlert &>(rVal));
  }

  return *this;
}

inline void  DpMsgAlert::setUseServerTimeFlag(PVSSboolean flag)
{
  useServerTime = flag;
}

#endif /* _DPMSGALERT_H_ */
