#ifndef _MAXACCU_H_
#define _MAXACCU_H_

#ifndef _SIMPLEACCU_H_
#include <SimpleAccu.hxx>
#endif

#ifndef _VARIABLE_H_
#include <Variable.hxx>
#endif

#ifndef _TIMEVAR_H_
#include <TimeVar.hxx>
#endif

/**
 * A statistical accumulator to determine the maximum of a series of values.
 *
 * @internal
 */
class DLLEXP_OABASICS MaxAccu: public SimpleAccu
{
  public:
    /**
     * Creates a new instance for the specified Variable type.
     * 
     * @param aVarType The variable type of the accumulator. Valid types are
     * INTEGER_VAR, UINTEGER_VAR and FLOAT_VAR. If you specify an invalid
     * type, FLOAT_VAR is used.
     */
    MaxAccu(const VariableType aVarType);

    /**
     * Destructor
     */
    virtual ~MaxAccu();
    
    /**
     * Sets a new value, if it is bigger than the current value.
     *
     * If the specified value is greater than the value of this instance,
     * it will become the new value of the instance. Otherwise, it will
     * be ignored.
     *
     * If a Variable of a different type than that of the accumulator is passed,
     * the conversion mechanism of the accumulator's type will be used.
     *
     * @param theValue The value to accumulate
     * @param atTime Not used
     */
    virtual void accumulate(const Variable &theValue, const TimeVar &atTime );

    /**
     * Returns the current value of the accumulator.
     *
     * @remarks The return value may be invalid, e.g. when no value was added
     * to a new instance. Use isValid() to check the validity of the value.
     *
     * @return The current maximum value of all accumulated values.
     */
    virtual const Variable &getResult();

    /**
     * Returns the current value if it is valid (isValid()), otherwise
     * the specified value parameter.
     *
     * @param theValue The return value if the current instance value is invalid.
     *
     * @return the current value if it is valid (isValid()), otherwise
     * the specified value parameter.
     */
    virtual const Variable &getIntermResult(  const Variable &theValue, const TimeVar &/*start*/, 
                                                     const TimeVar &/*stop*/, bool /*valid*/ );
    /**
     * Resets the accumulator.
     *
     * After reset, the value of the accumulator will be invalid (isValid()),
     * and the first added value will be the new maximum value.
     */
    virtual void reset();
    
  protected:
  
  private:
    /// Avoids copy
    MaxAccu(const MaxAccu &);

    /// Avoids assignment
    MaxAccu &operator=(const MaxAccu &);
  
    /// Current maximum value
    Variable *theMax;

    /// Intermediate value
    // does not seem to be used
    Variable *intMax;
};

#endif
