#ifndef _BASEACCU_H_
#define _BASEACCU_H_

// Author: Wolfram Klebel
// Date:   24. 10. 2002
// Purpose: pure virtual class for alternate calls of PeriodAccu vs. FloatingAccu
// working on Variables

// ******************************************************************************

#ifndef _VARIABLE_H_
#include <Variable.hxx>
#endif

#ifndef _TIMEVAR_H_
#include <TimeVar.hxx>
#endif

#ifndef _DYNVAR_H_
#include <DynVar.hxx>
#endif

/// This is a pure virtual class, serving as a base class for PeriodAccu and FloatingAccu accumulators
/// @classification ETM internal
class DLLEXP_OABASICS BaseAccu
{
  public:

    /// Constructor.
    BaseAccu();

    /// Virtual destructor.
    virtual ~BaseAccu() {}
    
    /// Add new value to the accumulator.
    /// @param theValue Value to be added.
    /// @param atTime Time stamp.
    virtual void addValue( const Variable &theValue, const TimeVar &atTime ) = 0;
    
    /// Add new invalid value to the accumulator.
    /// @param theValue Value to be added.
    /// @param atTime Time stamp.
    virtual void addInvalidValue( const Variable &theValue, const TimeVar &atTime ) = 0;

    /// Add new value to history.
    /// @param theValue Variable to add.
    /// @param atTime Time stamp.
    virtual void addHistory( const Variable &theValue, const TimeVar &atTime ) = 0;

    /// Add new invalid value to history.
    /// @param theValue Variable to add
    /// @param atTime Time stamt.
    virtual void addInvalidHistory(const Variable &theValue, const TimeVar &atTime) = 0;

    // diese Funktion wird jeweils nach der getResult()-Methode aufgerufen

    /// Advance to the subsequent period and process buffered values (if any).
    /// @param nextStop Next period time.
    virtual void workNextPeriod( const TimeVar & nextStop ) = 0;

    // wenn es keine History gibt, ist das die erste Funktion nach dem Konstruktor, 
    // die von StatFunc aus aufgerufen wird
    /// Process the buffered values.
    virtual void startWorking() = 0;

    // Auslesen des Wertes aus dem Accu
    /// Return the result kept in the accumulator.
    /// @param periodStop Time period.
    /// @param isIntermediate
    /// @return accumulated Variable.
    virtual const Variable &getResult(TimeVar* periodStop = 0, PVSSboolean isIntermediate = false ) = 0;

    // ist mein Wert (getResult()) bzw. Accu-Ergebnis valid?
    /// Check if the accumulator is in the valid state.
    /// @return PVSS_TRUE if valid, PVSS_FALSE otherwise.
    virtual PVSSboolean isValid() const = 0;
    
    // gibt die aktuellen Start/Stopzeiten zurueck
    /// Returns the start and stop time.
    /// @param start TimeVar where the start time will be returned.
    /// @param stop TimeVar where the stop time will be returned.
    virtual void getStartStop( TimeVar *start, TimeVar *stop) const = 0;

    /// Set the start and stop time.
    /// @param start TimeVar with the start time.
    /// @param stop TimeVar with the stop time.
    virtual void setStartStop( const TimeVar &start, const TimeVar &stop) = 0;

    /// Reset the start and stop time.
    /// @param start TimeVar with the start time.
    /// @param stop TimeVar with the start time.
    virtual void reset( const TimeVar &start, const TimeVar &stop) = 0;
    
  protected:
    
  private:

    /// prevents the copy constructor to be called.
    BaseAccu(const BaseAccu &);    
    
    /// prevents the assignment operator to be called.
    BaseAccu &operator=(const BaseAccu &);
    
};

// ****************************************************************************

inline  BaseAccu::BaseAccu()
{
}

#endif
