#ifndef _WAITFORANSWER_H_
#define _WAITFORANSWER_H_
// DATEIBESCHREIBUNG ==============================================================
// VERANTWORTUNG: Johannes Ertl
// BESCHREIBUNG:  Soll ein Call-back bei einer Antwort gemacht werden, so muss man von dieser
//                Klasse ableiten. Die virtuelle Methode callBack wird dann aufgerufen.
// ======================================Ende======================================
#include <Types.hxx>

class DpMsg;
class DpMsgAnswer;
class CallBackItem;
class Manager;

/** The answer handler class. This class is an abstract base class for answer handlers.
  It contains the callback function which is used to receive an answer message.
  @see DpMsgAnswer
  @classification public use, overload
 */


class DLLEXP_MANAGER WaitForAnswer 
{
  public:
    enum answerType
    {
      STANDARD_ANSWER,
      HOT_LINK_ANSWER,
      ALERT_HOT_LINK_ANSWER,
      FRAGMENT_ANSWER
    };

    /**
     * The value that getUserDefinedType() returns for default
     * WaitForAnswer objects.
     */
    static const PVSSulong NO_USER_DEFINED_TYPE = 0;

    /// constructor
    WaitForAnswer() {}

    /// destructor
    virtual ~WaitForAnswer() {}

    virtual answerType isA()  { return WaitForAnswer::STANDARD_ANSWER; };

    /**
     * This method will be called during a redundancy switch.
     * A derived class may override this method and react on the redundancy switch. 
     * The return value indicates whether the related request shall be refreshed.
     * @param msg the request message sent with this wait object
     * @return PVSS_TRUE  indicates that the request message should be re-sent (refreshed)
     *         PVSS_FALSE indicates that the request message should not be re-sent
     *                    No (more) answers will be received. The Manager-Framework
     *                    deletes the Waitobject if it is responsible for it.
     */
    virtual PVSSboolean needRefresh(DpMsg *msg) { return PVSS_TRUE; };

    // NECESSARY FOR SECURITY PLUGIN
    /**
     * This method can be overwritten by derived classes to disambiguate between
     * default PVSS WaitForAnswer objects, which return NO_USER_DEFINED_TYPE,
     * and custom WaitForAnswer objects, which might return any other value.
     */
    virtual PVSSulong getUserDefinedType() { return NO_USER_DEFINED_TYPE; }


    /** The callback function. This function is abstract since this is a base class.
      Use this function by overloading to receive answer messages. You need to overload
      this class whenever you want to handle answer messages. Objects of this type 
      are used by the manager to distribute answer messages.
      @param answer the answer message received
      @classification public use, overload
     */
    virtual void callBack(DpMsgAnswer &answer) = 0;
};

#endif /* _WAITFORANSWER_H_ */
