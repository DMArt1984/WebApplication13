#ifndef _DPSMOOTHMAIN_H_
#define _DPSMOOTHMAIN_H_

// Vorwaerts-Deklaration der Eigenen Klasse
class DpSmoothMain;

// System-Include-Files
#include <DpConvSmoothContainer.hxx>

// Vorwaerts-Deklarationen :
class DpConfig;

// ========== DpSmoothMain ============================================================

/** The class derived from the abstract DpConvSmoothContainer.
    This class enables to create an instance of DpConvSmoothContainer object.
    @classification ETM internal  
  */
class DLLEXP_CONFIGS DpSmoothMain : public DpConvSmoothContainer 
{

public:

  /// constructor, initialisation with zero values
  DpSmoothMain();

  /// destructor
  ~DpSmoothMain();

  /// non virtual assignment operator for DpSmoothMain
  /// @param rVal the DpSmoothMain to assign
  /// @return the resulting DpSmoothMain
  DpSmoothMain &operator=(const DpSmoothMain &rVal)
    { DpConvSmoothContainer::operator=((const DpConvSmoothContainer &) rVal); return *this; }

	/// check if own DP config type matches other DP config type
  /// @param conf the DpConfigType to check
  /// @return matching DpConfigType
  virtual DpConfigType isA(DpConfigType conf) const;

  /// return type of DP config
  virtual DpConfigNrType getDpConfigNrUncached() const;

  /// allocate new DpSmoothMain
  /// @return the new DpSmoothMain
  virtual DpConfig *allocate() const;

  // Generierte Methoden :
protected:
private:

// ............................Anfang User-Attribut-Definitionen...................
public:
  
  /// return type of DP config
	virtual DpConfigType isA() const;

  /// return size of DP config
  virtual unsigned long sizeOf() const;

  // .............................Ende User-Attribut-Definitionen....................
};

// ================================================================================
// Inline-Funktionen :

// ............................Anfang User-Inlines.................................
inline unsigned long DpSmoothMain::sizeOf() const
{
  return sizeof(DpSmoothMain);
}
// .............................Ende User-Inlines..................................

#endif /* _DPSMOOTHMAIN_H_ */
