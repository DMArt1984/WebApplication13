#ifndef _ALERTTIME_H_
#define _ALERTTIME_H_

#ifndef _PVSSTIME_H_
#include <PVSSTime.hxx>
#endif

/**
 * This class covers a simple PVSSTime plus a counter to distinguish
 * single alarms which have been triggered at the same time.
 * Therefore the AlertTime has the resolution of milli seconds
 * plus a counter up to MAX_UINT events per time tick.
 *
 */
class DLLEXP_BASICS AlertTime : public PVSSTime
{
public:
#ifndef NO_BCM // [
  /**
   * The message stream send operator. This operator is used to send an
   * instance through a BCM network streams.
   *
   * @internal
   */
  friend DLLEXP_BASICS itcNdrUbSend &operator<<(itcNdrUbSend &ndrStream, const AlertTime &aTime);

  /**
   * The message stream receive operator. This operator is used to receive
   * AlertTime objects from a BCM network streams.
   *
   * It must be the exact mirror function to the send operator.
   * 
   * @internal
   */
  friend DLLEXP_BASICS itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream, AlertTime &aTime);
#endif // NO_BCM ]

  /**
   * Default constructor. Initializes time and count with 0.
   */
  AlertTime() : PVSSTime(0, 0) { count_ = 0; }

  /**
   * Copy constructor
   */
  AlertTime(const AlertTime &rVal) : PVSSTime(rVal) { count_ = rVal.count_; }

  /**
   * Construct a time from a PVSSTime and a count.
   */
  AlertTime(const PVSSTime &rVal, PVSSushort c = 0) : PVSSTime(rVal)  { count_ = c; }

  /**
   * Checks whether the compared instances are equal.
   * Time and count are compared.
   */
  int operator==(const AlertTime &rVal) const;

  /**
   * Checks whether the compared instances are not equal.
   * Time and count are compared.
   */
  int operator!=(const AlertTime &rVal) const;

  /**
   * Checks whether the value of the first instance is less than the value
   * of the second instance.
   *
   * First the time values, then the count values are compared.
   */
  int operator<(const AlertTime &rVal) const;

  /**
   * Checks whether the value of the first instance is greater than the value
   * of the second instance.
   *
   * First the time values, then the count values are compared.
   */
  int operator>(const AlertTime &rVal) const;

  /**
   * Checks whether the value of the first instance is less than
   * or equal to the value of the second instance.
   *
   * First the time values, then the count values are compared.
   */
  int operator<=(const AlertTime &rVal) const;

  /**
   * Checks whether the value of the first instance is greater than
   * or equal to the value of the second instance.
   *
   * First the time values, then the count values are compared.
   */
  int operator>=(const AlertTime &rVal) const;

  /**
   * Copies the state from the specified instance
   * into the current instance.
   */
  AlertTime & operator=(const AlertTime &rVar);

  /**
   * Returns the PVSSTime part of this AlertTime.
   *
   * @return A copy of the PVSSTime part of this instance.
   */
  PVSSTime  getTime() const { return PVSSTime(time_, nano_); }
  
  /**
   * Returns the counter value of this AlertTime.
   *
   * @return The counter value of this instance.
   */
  PVSSushort getCount() const { return count_; }

  /**
   * Sets the time of this AlertTime.
   *
   * @param newTime A PVSSTime instance
   */
  void setTime(const PVSSTime &newTime) { PVSSTime::operator=(newTime); }
  
  /**
   * Sets the counter value of this instance.
   *
   * @param newCount
   */
  void setCount(PVSSushort newCount) { count_ = newCount; }

  /**
   * Increments the counter by one
   *
   * @return The new, incremented counter value
   */
  PVSSushort incCount() { count_++; return(count_); }
  
  /**
   * Sets new time and count values for this instance.
   *
   * @remarks All parameters are optional. If you do not specify a value for a parameter,
   * an empty value will be used instead. Thus, if you do not specify any parameters,
   * the instance will be reset to an empty AlertTime.
   *
   * @param newTime a BC_CTime object which holds the time in seconds
   * @param newMilli the milli second part
   * @param newCount the event counter
   */
  void set(const BC_CTime & newTime = 0, PVSSlong newMilli = 0, PVSSushort newCount = 0); 
  
  /**
   * Returns the time in standard PVSS format: "YYYY.MM.DD HH:MM:SS.mmm (<count>)".
   *
   * @param inUTC If given as false, represent the time in the local timezone,
   * otherwise represent the time in UTC timezone.
   *
   * @return A string containing the time and date in the format described above.
   */
  CharString toString(bool inUTC = false) const;

  
public:
  /**
   * An empty instance. Can be used for comparison or initialization.
   */
  static const AlertTime NullTime;   // Null-Zeit
};


// -----------------------------------------------------------------------------
// inline-methods:

inline  void  AlertTime::set(const BC_CTime & newTime, PVSSlong newMilli, PVSSushort newCount)
{
  setValue(newTime.ElapsedSeconds(), newMilli);
  count_ = newCount;
}


inline int AlertTime::operator==(const AlertTime &rVal) const
{
  return PVSSTime::operator==(rVal) && count_ == rVal.count_;
}


inline int AlertTime::operator!=(const AlertTime &rVal) const
{
  return !operator==(rVal);
}


inline int AlertTime::operator<(const AlertTime &rVal) const
{
  return PVSSTime::operator<(rVal) || (PVSSTime::operator==(rVal) && count_ < rVal.count_);
}


inline int AlertTime::operator>(const AlertTime &rVal) const
{
  return PVSSTime::operator>(rVal) || (PVSSTime::operator==(rVal) && count_ > rVal.count_);
}


inline int AlertTime::operator<=(const AlertTime &rVal) const
{
  return !operator>(rVal);
}


inline int AlertTime::operator>=(const AlertTime &rVal) const
{
  return !operator<(rVal);
}


inline AlertTime & AlertTime::operator=(const AlertTime &rVal)
{
  if (this != &rVal)
  {
    PVSSTime::operator=(rVal);
    count_ = rVal.count_;
  }

  return *this;
}

#endif /* _ALERTTIME_H_ */
