#ifndef _COUNTBITCHANGESACCU_H_
#define _COUNTBITCHANGESACCU_H_

// Author: Heinz MEISSL
// Date:   14.4.1997
// Purpose: implement a statistic Accumulator to determine the overall time, a BitVar
//          remained in a state ( 0 or 1 )

#ifndef _SIMPLEACCU_H_
#include <SimpleAccu.hxx>
#endif

#ifndef _TYPES_HXX_
#include <Types.hxx>
#endif

#ifndef _VARIABLE_H_
#include <Variable.hxx>
#endif

#ifndef _TIMEVAR_H_
#include <TimeVar.hxx>
#endif

#ifndef _BITVAR_H_
#include <BitVar.hxx>
#endif

#ifndef _UINTEGERVAR_H_
#include <UIntegerVar.hxx>
#endif

/// A value accumulator class. This class is used to determine how many times the accumulated 
/// value changed from true to false or back.
/// It can be specified that only transitions from 1 to 0 or 0 to 1 will be counted.
/// @classification ETM internal
class DLLEXP_OABASICS CountBitChangesAccu: public SimpleAccu
{
  public:
    /// Specifies which transitions will be counted
    enum ChangesToCount{ ANY, ONLY_01, ONLY_10 };
    
    /// Constructor.
    /// @param aType Specifies which value changes will be counted.
    /// <ul>
    /// <li>ANY - Any change of accumulated value (from true to false or back)
    /// will be counted.
    /// <li>ONLY_01 - The count will be increased only if accumulate() was called
    /// with false (0) value, followed with another call with true (non-zero) value.
    /// <li>ONLY_10 - The count will be increased only if accumulate() was called
    /// with true (non-zero) value, followed with another call with false (0) value.
    /// </ul>
    CountBitChangesAccu( ChangesToCount aType = ANY );
    
    /// This method will accumulate theValue. If the previous value from the accumulate
    /// call was different to this one (only true/false is taken into consideration),
    /// the internal count variable will be increased. Which changes are considered is
    /// specified in the contructor.
    /// @param theValue value to process.
    /// @param atTime Time stamp. This parameter is ignored.
    virtual void accumulate(const Variable &theValue, const TimeVar &atTime );
    
    /// Returns the bit changes count (see accumulate() for more info).
    /// @return const reference to the UIntegerVar variable holding the number of how many
    /// times the value passed in accumulate() was changed.
    virtual const Variable &getResult();

    /// Resets the internal counter to zero.
    virtual void reset();
    
  protected:
  
  private:
    /// prevents the copy constructor to be called.
    CountBitChangesAccu(const CountBitChangesAccu &);

    /// prevents the assignment operator to be called.
    CountBitChangesAccu &operator=(const CountBitChangesAccu &);
  
    /// type of the CountBitChangesAccu (see constructor for more info).
    ChangesToCount myType;

    /// remembers if the last value passed in accumulate() was true or false.
    BitVar lastState;

    /// number of true/false changes. This value will be returned by getResult().
    UIntegerVar count;
};

#endif

