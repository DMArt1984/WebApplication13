#ifndef _DPCONFIG_H_
#define _DPCONFIG_H_

// DATEIBESCHREIBUNG ==============================================================
// DATEINAME:     DpConfig.hxx
// VERANTWORTUNG: Johannes Ertl
// BESCHREIBUNG: Abstrakte Klasse fuer alle moeglichen Konfigurationen einer
//   Dp-Variablen (zB. DpValue). Jede Konfiguration hat Attribute (z.B.
//   ein Minimum und Maximum), die durchnummeriert sind. Welche Attribute
//   existieren ist bei der entsprechenden Konfiguration beschrieben.
//   Manche Attribute sind Verknuepfungen mehrerer Konfigurationen (z.B.
//   das Statusbit "Ersatzwert ungueltig" ist True, wenn es keinen
//   Ersatzwert gibt). Solche Attribute werden nicht von den Konfigurationen
//   sondern vom Datenpunktelement (DpElement) beantwortet.
//   Folgende Attributnummern haben eine definierte Bedeutung:
//   Alle Attributnummern sind bei den jeweiligen Konfigurationen (bzw beim
//   DpElement) als statische Konstante definiert. Die ersten 100 (0..99)
//   sind reserviertBis jetz wurde belegt:
//
//   TYPE_ATTR: Typ der Konfiguration
//   LOCKFLAG_ATTR: Ist die Konfiguration gelockt?
//   ORIGINTIME_ATTR: Quellzeit
//   ORIGINMANAGER_ATTR: Quellmanager
//   ORIGINUSER_ATTR: Quelluser
//
//         Die Konfigurationen koenen bei jedem Manager unterschiedlich sein, darum
//         gibt es einen statischen ConfigManager bei jedeM DpConfig, der automatisch
//         initialisiert wird, wenn ein Configmanager angelegt wird!
// ERWEITERUNGEN:
//         - Wird eine neue Konfiguration eingebaut, so muessen die Funktion
//   "allocate(DpConfiType)" und "checkConfigType" der Klasse DpConfigManager
//   (bzw alle seiner abgeleiteten Klassen) modifiziert werden!!!!! Ausserdem
//   muss beim enum DpConfigType der neue Typ eingetragen - NICHT EINGEFUEGT - werden.
//
//   Neue Attributnummern haben ein bestimmtes Format (siehe DpAttributeNrType).
//

// ========== DpConfigType ============================================================
// Aufzaehlung aller Configurationsarten.
// Die neue Enums duerfen nicht eingefuegt werden, sondern
// muessen angehaengt werden. In der Datenbank sind diese
// enums manchmal gespeichert!

enum DpConfigType
{
  DPCONFIG_NOCONFIG,
  DPCONFIG_CONFIG,
  DPCONFIG_VALUE,
  DPCONFIG_DEFAULTVALUE,
  DPCONFIG_CONNDISPATCH,
  DPCONFIG_DISPATCHINFOCONT,
  DPCONFIG_PVSS_RANGECHECK,
  DPCONFIG_MINMAX_PVSS_RANGECHECK,
  DPCONFIG_SET_PVSS_RANGECHECK,
  DPCONFIG_USER_RANGECHECK,
  DPCONFIG_ALERT_STATEBITS,
  DPCONFIG_ALERT_VALUE,
  DPCONFIG_ALERT_BINARYSIGNAL,
  DPCONFIG_ALERT_NONBINARYSIGNAL,
  DPCONFIG_ALERT_CLASS,
  DPCONFIG_PERIPH_ADDR,
  DPCONFIG_PERIPH_ADDR_MAIN,
  DPCONFIG_PERIPH_ADDR_AUX,
  DPCONFIG_SSI_PERIPH_ADDR,
  DPCONFIG_SSI_PERIPH_ADDR_MAIN,
  DPCONFIG_SSI_PERIPH_ADDR_AUX,
  DPCONFIG_PROFI_PERIPH_ADDR_old_dont_use,
  DPCONFIG_PROFI_PERIPH_ADDR_MAIN_old_dont_use,
  DPCONFIG_PROFI_PERIPH_ADDR_AUX_old_dont_use,
  DPCONFIG_PROFI_DRIVER,
  DPCONFIG_PROFI_KBLHDR,
  DPCONFIG_PROFI_KBL,
  DPCONFIG_PROFI_OVHDR,
  DPCONFIG_PROFI_OVSIMPLE,
  DPCONFIG_PROFI_OVARRAY,
  DPCONFIG_CONV_OR_SMOOTH,
  DPCONFIG_CONVERSION,
  DPCONFIG_CONVERSION_RAW_TO_ING,
  DPCONFIG_CONVERSION_RAW_TO_ING_MAIN,
  DPCONFIG_CONVERSION_RAW_TO_ING_AUX,
  DPCONFIG_CONVERSION_ING_TO_RAW,
  DPCONFIG_CONVERSION_ING_TO_RAW_MAIN,
  DPCONFIG_CONVERSION_ING_TO_RAW_AUX,
  DPCONFIG_SMOOTHING,
  DPCONFIG_SMOOTH_MAIN,
  DPCONFIG_SMOOTH_AUX,
  DPCONFIG_UIDISPATCHINFO,
  DPCONFIG_UIINTERN,
  DPCONFIG_MAN,
  DPCONFIG_INTERNAL,
  DPCONFIG_DB_ARCHIVEINFO,
  DPCONFIG_CONNECTION,
  DPCONFIG_CONNECTCOUNT,
  DPCONFIG_SMOOTH_MAIN_SIMPLE,
  DPCONFIG_SMOOTH_MAIN_DERIV,
  DPCONFIG_SMOOTH_MAIN_FLUTTER,
  DPCONFIG_SMOOTH_AUX_SIMPLE,
  DPCONFIG_SMOOTH_AUX_DERIV,
  DPCONFIG_SMOOTH_AUX_FLUTTER,
  DPCONFIG_FIRST_ARCHIVE,
  DPCONFIG_GENERAL_CONFIG,
  DPCONFIG_DISTRIBUTION_INFO,
  DPCONFIG_LOGGER_INFO,
  DPCONFIG_DB_ARCHIVECLASS,
  DPCONFIG_SUM_ALERT,
  DPCONFIG_DP_FUNCTION,
  DPCONFIG_DPLOCK,
  DPCONFIG_AUTH,
  DPCONFIG_STAT_FUNCTION,
  DPCONFIG_MATCH_PVSS_RANGECHECK
};

// -----------------------------------------------------------------------------------
// MAX_DP_CONFIG_NR musz bei Erweiterung des Enums berichtigt werden!!!
#define MAX_DP_CONFIG_NR  (unsigned long)DPCONFIG_MATCH_PVSS_RANGECHECK
// -----------------------------------------------------------------------------------

enum Statusbit
{
  STATUSBIT_DPVARIABLE_ACTIVE_BIT,       // 0
  STATUSBIT_DEFAULT_EXPLIZIT_BIT,        // 1
  STATUSBIT_DEFAULT_AUTOMATIC_BIT,       // 2
  STATUSBIT_OUT_OF_PVSSRANGE_BIT,        // 3
  STATUSBIT_OUT_OF_RANGE_BIT,            // 4
  STATUSBIT_EXPLIZIT_INVALID_BIT,        // 5
  STATUSBIT_AUTOMATIC_INVALID_BIT,       // 6
  STATUSBIT_SECOND_LINE_INVALID_BIT,     // 7

  STATUSBIT_DEFAULTVALUE_BAD_BIT,        // 8
  STATUSBIT_GENERAL_INTER_BIT,           // 9
  STATUSBIT_SINGLE_INTER_BIT,            //10
  STATUSBIT_PERIPHERY_ACTIVE_BIT,        //11
  STATUSBIT_MARK_OF_CORRECTION_BIT,      //12
  STATUSBIT_VALUE_IS_COMPRESSED_BIT,     //13
  STATUSBIT_COMP_BASED_ON_CORR_BIT,      //14
  STATUSBIT_ADDITIONAL_CORR_BIT,         //15

  STATUSBIT_COMP_BASED_ON_INVALID_BIT,   //16
  STATUSBIT_INVALID_TIME_BIT,            //17
  STATUSBIT_TRANSITION_BIT,              //18
  STATUSBIT_LAST_VALUE_STORAGE_OFF_BIT,  //19
  STATUSBIT_VALUE_CHANGED_BIT,           //20
  STATUSBIT_VALUE_UP_BIT,                //21
  STATUSBIT_VALUE_UNCERTAIN_BIT,         //22
  STATUSBIT_23_UNUSED_BIT,               //23
  
  // Benutzerdefinierte Bits
  STATUSBIT_USER_DEFINED_1_BIT,          //24
  STATUSBIT_USER_DEFINED_2_BIT,          //25
  STATUSBIT_USER_DEFINED_3_BIT,          //26
  STATUSBIT_USER_DEFINED_4_BIT,          //27
  STATUSBIT_USER_DEFINED_5_BIT,          //28
  STATUSBIT_USER_DEFINED_6_BIT,          //29
  STATUSBIT_USER_DEFINED_7_BIT,          //30
  STATUSBIT_USER_DEFINED_8_BIT,          //31

  STATUSBIT_USER_DEFINED_9_BIT,          //32
  STATUSBIT_USER_DEFINED_10_BIT,         //33
  STATUSBIT_USER_DEFINED_11_BIT,         //34
  STATUSBIT_USER_DEFINED_12_BIT,         //35
  STATUSBIT_USER_DEFINED_13_BIT,         //36
  STATUSBIT_USER_DEFINED_14_BIT,         //37
  STATUSBIT_USER_DEFINED_15_BIT,         //38
  STATUSBIT_USER_DEFINED_16_BIT,         //39
  
  STATUSBIT_USER_DEFINED_17_BIT,         //40
  STATUSBIT_USER_DEFINED_18_BIT,         //41
  STATUSBIT_USER_DEFINED_19_BIT,         //42    
  STATUSBIT_USER_DEFINED_20_BIT,         //43
  STATUSBIT_USER_DEFINED_21_BIT,         //44
  STATUSBIT_USER_DEFINED_22_BIT,         //45
  STATUSBIT_USER_DEFINED_23_BIT,         //46
  STATUSBIT_USER_DEFINED_24_BIT,         //47
  
  STATUSBIT_USER_DEFINED_25_BIT,         //48
  STATUSBIT_USER_DEFINED_26_BIT,         //49
  STATUSBIT_USER_DEFINED_27_BIT,         //50
  STATUSBIT_USER_DEFINED_28_BIT,         //51
  STATUSBIT_USER_DEFINED_29_BIT,         //52
  STATUSBIT_USER_DEFINED_30_BIT,         //53
  STATUSBIT_USER_DEFINED_31_BIT,         //54
  STATUSBIT_USER_DEFINED_32_BIT,         //55
  
  STATUSBIT_PA_QUALITY_1_BIT,            //56
  STATUSBIT_PA_QUALITY_2_BIT,            //57
  STATUSBIT_PA_QUALITY_3_BIT,            //58
  STATUSBIT_PA_QUALITY_4_BIT,            //59
  STATUSBIT_PA_QUALITY_5_BIT,            //60
  STATUSBIT_PA_QUALITY_6_BIT,            //61
  STATUSBIT_PA_QUALITY_7_BIT,            //62
  STATUSBIT_PA_QUALITY_8_BIT             //63
};

// System-Include-Files
#include <DpTypes.hxx>
#include <DpConfigNrType.hxx>
#include <DpElementType.hxx>
#include <Variable.hxx>
#include <DynPtrArray.hxx>

#include <iostream>

// following consts for performance (to avoid calling getStatusBitNr)
const PVSSulonglong BITMASK_DPVALUE_DPVARIABLE_ACTIVE_BIT_ATTR     = 1ULL << STATUSBIT_DPVARIABLE_ACTIVE_BIT;
const PVSSulonglong BITMASK_DPVALUE_DEFAULT_EXPLIZIT_BIT_ATTR      = 1ULL << STATUSBIT_DEFAULT_EXPLIZIT_BIT;
const PVSSulonglong BITMASK_DPVALUE_DEFAULT_AUTOMATIC_BIT_ATTR     = 1ULL << STATUSBIT_DEFAULT_AUTOMATIC_BIT;
const PVSSulonglong BITMASK_DPVALUE_OUT_OF_PVSSRANGE_BIT_ATTR      = 1ULL << STATUSBIT_OUT_OF_PVSSRANGE_BIT;
const PVSSulonglong BITMASK_DPVALUE_OUT_OF_RANGE_BIT_ATTR          = 1ULL << STATUSBIT_OUT_OF_RANGE_BIT;
const PVSSulonglong BITMASK_DPVALUE_EXPLIZIT_INVALID_BIT_ATTR      = 1ULL << STATUSBIT_EXPLIZIT_INVALID_BIT;
const PVSSulonglong BITMASK_DPVALUE_AUTOMATIC_INVALID_BIT_ATTR     = 1ULL << STATUSBIT_AUTOMATIC_INVALID_BIT;
const PVSSulonglong BITMASK_DPVALUE_DEFAULTVALUE_BAD_BIT_ATTR      = 1ULL << STATUSBIT_DEFAULTVALUE_BAD_BIT;    // _default_bad
const PVSSulonglong BITMASK_DPVALUE_GENERAL_INTER_BIT_ATTR         = 1ULL << STATUSBIT_GENERAL_INTER_BIT;
const PVSSulonglong BITMASK_DPVALUE_SINGLE_INTER_BIT_ATTR          = 1ULL << STATUSBIT_SINGLE_INTER_BIT;
const PVSSulonglong BITMASK_DPVALUE_MARK_OF_CORRECTION_BIT_ATTR    = 1ULL << STATUSBIT_MARK_OF_CORRECTION_BIT;    // _corr
const PVSSulonglong BITMASK_DPVALUE_VALUE_IS_COMPRESSED_BIT_ATTR   = 1ULL << STATUSBIT_VALUE_IS_COMPRESSED_BIT;    // _compr
const PVSSulonglong BITMASK_DPVALUE_COMP_BASED_ON_INVALID_BIT_ATTR = 1ULL << STATUSBIT_COMP_BASED_ON_INVALID_BIT;    // _comp_inv
const PVSSulonglong BITMASK_DPVALUE_INVALID_TIME_BIT_ATTR          = 1ULL << STATUSBIT_INVALID_TIME_BIT;
const PVSSulonglong BITMASK_DPVALUE_TRANSITION_BIT_ATTR            = 1ULL << STATUSBIT_TRANSITION_BIT;
const PVSSulonglong BITMASK_DPVALUE_LAST_VALUE_STORAGE_OFF_BIT_ATTR= 1ULL << STATUSBIT_LAST_VALUE_STORAGE_OFF_BIT;
const PVSSulonglong BITMASK_DPVALUE_VALUE_CHANGED_BIT_ATTR         = 1ULL << STATUSBIT_VALUE_CHANGED_BIT;    // _value_changed IM 92322 Indicate "up an down" of values within user bit 
const PVSSulonglong BITMASK_DPVALUE_VALUE_UP_BIT_ATTR              = 1ULL << STATUSBIT_VALUE_UP_BIT;    // _value_up      IM 92322 Indicate "up an down" of values within user bit 


const PVSSulonglong BITMASK_DPVALUE_INVALID_BIT_ATTR =
                  BITMASK_DPVALUE_EXPLIZIT_INVALID_BIT_ATTR |           // _exp_inv
                  BITMASK_DPVALUE_AUTOMATIC_INVALID_BIT_ATTR |          // _aut_inv
                  BITMASK_DPVALUE_INVALID_TIME_BIT_ATTR;                // _stime_inv

const int STATUS_BITS_UNKNOWN_USERBIT = 99;

// Vorwaerts-Deklarationen :
class Bit64Var;
class Bit32Var;
class DpConfigManager;
class DynVar;
class DpConfig;

// ========== DpConfigPtr ============================================================
typedef DpConfig* DpConfigPtr;

// ========== DpConfig ===============================================================

/** This is a abstract class - an interface used by every configuration implementation

    @classification public use
*/
class DLLEXP_CONFIGS DpConfig
{
friend class UNIT_TEST_FRIEND_CLASS; 

  friend class DpConfigManager;
  friend class DpElement;

  public:
    /// Type attribute number const
    static const DpAttributeNrType TYPE_ATTR;
    /// Systemtime attribute number const
    static const DpAttributeNrType SYSTEMTIME_ATTR;

    /// Constructor
    DpConfig();

    /// Destructor
    virtual ~DpConfig();

    /** Returns the type of the configuration.
       @return Always DPCONFIG_CONFIG type
    */
    virtual DpConfigType isA() const { return DPCONFIG_CONFIG; };

    /** Returns the size of the configuration object. ( This method should be implemented in the specific child class )
       @return size of the object obtained via sizeof operator
    */
    virtual unsigned long sizeOf() const = 0;

    /** Compares two instances of the configuration class.
       @return Always 1 is returned
    */
    virtual int operator==(const DpConfig &) const;

    /** Assigns an instance of the configuration class. A cachedConfigNr class member is copied.
       @param rVal A reference of the instance to be assigned to
       @return A reference to this pointer is returned
    */
    virtual DpConfig &operator=(const DpConfig &);

    /** Writes content of the configuration class to the output stream. A type and attribute are written to the stream.
        @param ndrStream Output stream.
        @param dpConfigPtr Reference to DpConfig pointer.
        @return itcNdrUbSend stream.
        @note  Throws a FATAL error in case of a nullpointer.
     */
    friend DLLEXP_CONFIGS itcNdrUbSend &operator<<(itcNdrUbSend &ndrStream, const DpConfigPtr &dpConfigPtr);

    /** Writes content of the configuration class to the output stream. Nothing is written to the stream!
        @param ndrStream Output stream.
        @param dpConfig Reference to DpConfig instance.
        @return itcNdrUbSend stream.
     */
    friend DLLEXP_CONFIGS itcNdrUbSend &operator<<(itcNdrUbSend &ndrStream, const DpConfig &dpConfig );

    /** Reads contents of the configuration class from the input stream. A type and attribute are read from the stream.
        @param ndrStream Input stream.
        @param dpConfigPtr A reference to DpConfig pointer.
        @return itcNdrUbSend stream.
        @note  Throws a FATAL error in case of a nullpointer.
    */
    friend DLLEXP_CONFIGS itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream, DpConfigPtr &dpConfigPtr);

   /** Reads contents of the configuration class from the input stream. Nothing is read from the stream!
        @param ndrStream Input stream.
        @param dpConfig A reference to DpConfig instance.
        @return itcNdrUbSend stream.
    */
     friend DLLEXP_CONFIGS itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream, DpConfig &dpConfig );

    // Spezielle Methoden :

   /** Method should set the specified attribute to a given value. As the base class provides only empty method.
       It is responsibility of the child class to override and implement this method.
        @param detailNr Detail number.
        @param attrNr Attribute number.
        @param var A variable
        @return Always PVSS_FALSE as it is the responsibility of the child class to implement that method.
    */
    virtual PVSSboolean setAttribut(DpDetailNrType detailNr, DpAttributeNrType attrNr, const Variable &var );

   /** Gets the actual value of the specified attribute. Only the TYPE_ATTR attribute is supported. Also detail has to be == 0 else 0 is returned.
        @param detailNr Detail number.
        @param attrNr Attribute number.
        @return var A value of the TYPE attribute or NULL in all other cases. The pointer is allocated by the method so it is
        up to the caller to release it then.
    */
    virtual Variable *getAttribut(DpDetailNrType detailNr, DpAttributeNrType attrNr) const;

   /** Returns the variable type of the specified attribute. The upper 2 bytes from the Attribute number are returned.
        @param attrNr Attribute number.
        @return VariableType A variable type
    */
    static VariableType getAttributType(DpAttributeNrType attrNr);

   /** It returns the DpConfigNrType of the DpConfigType.
        @param confType Configuration type.
        @return DpConfigNrType A configuration type number, or DPCONFIGNR_NOCONFIGNR if the DpConfigNrType is not valid.
    */
    static DpConfigNrType getConfigNrType(const DpConfigType confType);

   /** Checks if the configuration type references a proper element type.
        @param elType Element type.
        @param confType Configuration type.
        @return PVSSboolean PVSS_TRUE is returned if the configuration type references a valid element type, or PVSS_FALSE otherwise.
    */
    static PVSSboolean configFitsToElement(DpElementType elType, DpConfigType confType);

   /** Checks if the configuration number type references a proper element type.
        @param elType Element type.
        @param confNrType Configuration number type.
        @return PVSSboolean PVSS_TRUE is returned if thr configuration number type references a valid element type, or PVSS_FALSE otherwise.
    */
    static PVSSboolean configFitsToElement(DpElementType elType, DpConfigNrType confNrType);

     /** Checks if the configuration is consistent.
     *  @return PVSS_TRUE is always returned   
     */    
     virtual PVSSboolean isConsistent() const;

    // Liefert die Parametrierungsnummer der Konfiguration (siehe DpConfigNrType.hxx)
    /** Returns the parametrized configuration number.
     *  @return A DpConfigNrType ( @see DpConfigNrType.hxx )
     */
    DpConfigNrType getDpConfigNr() const;

    /** It returns the configuration number type of the instance. 
     *  @return DpConfigNrType an internal configuration number type is returned
     *  @note Override this method!
     */
    virtual DpConfigNrType getDpConfigNrUncached() const = 0;

    /**
     *  Allocates a new DpConfig instance. Every child class should overwrite & implement its own allocation method.
     *  @return A new instance of DpConfig, or NULL if the allocation has failed.
     */
    virtual DpConfig *allocate() const = 0;

    /**
     *  It allocates a new DpConfig of a given type and returns a pointer to that config.
     *  @param  configType a configuration type.
     *  @return A new instance of DpConfig, or NULL if the allocation has failed.
     */
    static DpConfigPtr allocate(DpConfigType configType);

    /**
     *  Returns its own configuration type. If the parameter is not equal to DPCONFIG_CONFIG, DPCONFIG_NOCONFIG type is returned.
     *  Otherwise the DPCONFIG_CONFIG type is returned.
     *  @param  configType a configuration type.
     *  @return A configuration type.
     */
    virtual DpConfigType isA(DpConfigType configType) const;

    /**
     *  Outputs debug information of the instance into the specified stream. 
     *  The method internally calls the debug method with the DpConfigType. (a isA() method is called).
     *  @param  to An output stream.
     *  @param  level A debug level.
     */
    virtual void debug(std::ostream &to, int level) const;

    /**
     *  Outputs debug information of the instance of a given type into the specified stream.
     *  @param  to An output stream.
     *  @param  level A debug level.
     *  @param  configType A configuration type.
     */
    static void debug(std::ostream &to, int level, DpConfigType configType);

  // die folgenden 2 Methoden gehoeren eigentlich DpValue, muessen aber allgemein
  // verfuegbar sein und befinden sich daher hier
    // Gibt fuer eine Attributnummer, die ein Statusbit adressiert, die Bitnummer in
    // der Statusbitleiste an (0 bis 63). Bei virtuellen Statusbits oder anderen nicht
    // aufloesbaren Attributnummern, ist der Rueckgabewert > 63.

    /**
     * It returns the bitnumber of the status byte array (from 0 to 63) for a specified attribute number.
     * For a virtual status bits or other not resolved attribut number, the returned value is STATUS_BITS_UNKNOWN_USERBIT.
     * @param   attrNr  An attribute number
     * @return  A status bit number
     */
    static int getStatusBitNr(DpAttributeNrType attrNr);

    /**
     * It returns the attribute number from the specified status bit.
     * @param   bitNr A status bit number
     * @return  An attribute number is returned ( from 0 to 63 ), or 0 is returned for invalid bit number.
     */
    static DpAttributeNrType getStatusBitAttribute(unsigned int bitNr);

    // Liest aus einer uebergebenen Statusbitleiste ein bestimmtes Statusbit aus (auch
    // virtuelle). Im Falle einer nicht interpretierbaren Attribut-Nr enthaelt der
    // Parameter error PVSS_TRUE.

    /**
     * Returns the specified bit of the status byte array (from 0 to 63) for a specified attribute number.
     * For a virtual status bits or other not resolved attribut number, the returned value is PVSS_TRUE.
     * It also works for virtual attributes. It is the same as for the bits 0-63, if it is set it returns true, else false. 
     * For invalid attribute numbers false is returned. 
     * @param   status  An 64bit status array
     * @param   attrNr  An attribute number
     * @param   error [out]   The error flag which is set to true in case of an invalid attribute number
     * @param   maxBits   defines the length of the status array (up to 64 bits)
     * @return  A status bit value
     */
    static PVSSboolean getStatus64Bit(const Bit64Var &status, DpAttributeNrType attrNr, PVSSboolean &error, int maxBits = 64);

    /**
     * Returns the specified bit of the status byte array (from 0 to 32) for a specified attribute number.
     * For a virtual status bits or other not resolved attribut number, the returned value is PVSS_TRUE.
     * It also works for virtual attributes. It is the same as for the bits 0-63, if it is set it returns true, else false. 
     * For invalid attribute numbers false is returned. 
     * @param   status  An 32bit status array
     * @param   attrNr  An attribute number
     * @param   error [out]   The error flag which is set to true in case of an invalid attribute number
     * @return  A status bit value
     * @note    This is 32-bit version of the method getStatus64Bit().
     */
    static PVSSboolean getStatusBit(const Bit32Var &status, DpAttributeNrType attrNr, PVSSboolean &error);

    

  protected:
    /// A configuration number type
    DpConfigNrType cachedConfigNr;

  private:

    // Ausgabefunktion auf den Stream
    virtual void outNdrUb(itcNdrUbSend &ndrStream) const = 0;

    // Einlesen vom Stream
    virtual void inNdrUb(itcNdrUbReceive &ndrStream) = 0;
    static DpConfigManager *configManager;

    static inline void setConfigManager(DpConfigManager *theConfigManager){configManager=theConfigManager;}
};

// ================================================================================
// Inline-Funktionen :
inline DpConfig::DpConfig()
 : cachedConfigNr(DPCONFIGNR_NOCONFIGNR)
{
}

inline DpConfigNrType DpConfig::getDpConfigNr() const
{
  // no mutable - do a dirty cast trick
  return (cachedConfigNr != DPCONFIGNR_NOCONFIGNR)
    ? cachedConfigNr
    : (((DpConfig*) this)->cachedConfigNr = getDpConfigNrUncached());
}

inline VariableType DpConfig::getAttributType(DpAttributeNrType attrNr)
{
  return (VariableType)(attrNr&0xFFFF0000);     // nur die oberen 2 Byte bezeichnen den Variablentyp
}


// ---------------------------------------------------------------------------------
#ifdef WIN32
#pragma warning ( disable: 4231 )
#endif

#ifdef LIBS_AS_DLL

#if !defined(WIN32) || _MSC_VER <= 1200
EXTERN_CONFIGS  template class  DLLEXP_CONFIGS  DynPtrArray<DpConfig>;
#endif

template <>
inline  DynPtrArrayIndex  DynPtrArray<DpConfig>::deepCopy(const DynPtrArray<DpConfig> &) {return 0;}

#if (_MSC_VER > 1200)
EXTERN_CONFIGS  template class  DLLEXP_CONFIGS  DynPtrArray<DpConfig>;
#endif

#endif

#ifdef WIN32
#pragma warning ( default: 4231 )
#endif

#endif /* _DPCONFIG_H_ */
