/////////////////////////////////////////////////////////////
// Inlines for class PtrList
/////////////////////////////////////////////////////////////

#ifdef NO_PTRLIST_INLINE
#  define PTRLIST_INLINE
#else
#  define PTRLIST_INLINE inline
#endif


PTRLIST_INLINE PtrList::PtrList()
  : numberOfItems(0),
    headPtr(0),
    tailPtr(0),
    lastAccessedPtr(0)
{
}

PTRLIST_INLINE void PtrList::clear()
{
  PtrListItem *p;
  
  // this is necessary since delete p calls the destructor of the object
  // the destructor could cause a deref or delete of lastAccessedPtr which would lead to a crash
  lastAccessedPtr = 0;
  
  while (headPtr)
  {
    p = headPtr;
    headPtr = headPtr->nextPtr;
    delete p;
  }

  numberOfItems = 0;
  headPtr = tailPtr = 0;
}

PTRLIST_INLINE PtrList::~PtrList()
{
  clear();
}

PTRLIST_INLINE PtrListItem* PtrList::cutFirst()
{
  PtrListItem *p = headPtr;

  if (headPtr)                      // wenn noch etwas in der liste ist...
  {
    headPtr = headPtr->nextPtr;     // verschiebe headPtr auf naechstes item
    if (lastAccessedPtr == p) lastAccessedPtr = lastAccessedPtr->nextPtr;
    if (p == tailPtr) tailPtr = 0;          // wenn letztes element - setze tailPtr auf NULL!
    numberOfItems--;
  }
  return p;
}

