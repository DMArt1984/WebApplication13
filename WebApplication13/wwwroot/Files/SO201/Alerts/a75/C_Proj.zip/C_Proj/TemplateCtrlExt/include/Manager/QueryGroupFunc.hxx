#ifndef _QUERYGROUPFUNC_H_
#define _QUERYGROUPFUNC_H_

/*
VERANTWORTUNG: Robert Trausmuth      
BESCHREIBUNG:
*/

#include <Variable.hxx>

/** the types of GROUP BY statement accumulators */
enum QueryGroupFuncType {
    /// (0). do nothing, hold the last valid value
          QGRP_NONE,
   /// (1). simply count occurences
          QGRP_COUNT,
   /// (2). determine the minimum value 
          QGRP_MIN,
   /// (3). determine the maximum value
          QGRP_MAX,
   /// (4). determine the sum of values
          QGRP_SUM,
   /// (5). determine the average of value
          QGRP_AVG,
   /// (6). calculate the variance of values
          QGRP_VARIANCE,
   /// (7). calculate the standard deviation of values
          QGRP_STDDEV,
          };
    
/** the GROUP BY statement accumulator class. objects of this class are used during evaluation of the GROUP BY statement in queries
    this class is type dependent. when initialized with variables of one type only others of the same type are taken. all other types are
    ignored, except for the QGRP_COUNT and QGRP_NONE types.
 */
class DLLEXP_MANAGER QueryGroupFunc
{
  friend class UNIT_TEST_FRIEND_CLASS;

  public:
    /// default constructor
    QueryGroupFunc(QueryGroupFuncType tp = QGRP_NONE);
    /// constructor, which takes the column text and determines his type from the text
    QueryGroupFunc(const char *text);
   /// destructor
    ~QueryGroupFunc();
    
    /// add a new value to the accumulator
    PVSSboolean addElement(Variable *var);
    /// evaluate the accumulator result
    Variable *getResult();

    /// get the identifier part of the string, snip away the SUM,AVG,... keywords
    const char *getIdString();

    /// reset values for new calculation
    void reset();
    // clear everything, including the text and type of the accumulator
    void clear();    
    
    /// check the accumulator type
    PVSSboolean hasType(QueryGroupFuncType tp) {return tp == type;}
    /// get the variable type if there are any (mean) results in the accumulator
    VariableType isA() {return vtype;}
    
    friend std::ostream &operator<<(std::ostream &, const QueryGroupFunc &); 

  protected:
  
    QueryGroupFuncType type;
    VariableType vtype;
  
    PVSSlong counter;
    PVSSlong avgCounter;
    Variable *minval;
    Variable *maxval;
    Variable *sumval;
    Variable *qsumval;
    Variable *lastval;
    
    char *colText;

  private:
    // so that the compiler does not define them itself !!

    // copy constructor
    QueryGroupFunc(const QueryGroupFunc &) {} //COVINFO LINE: defensive (AP: no copy allowed)
    // assignment operator
    QueryGroupFunc &operator=(const QueryGroupFunc &) { return *this; } //COVINFO LINE: defensive (AP: no operator= allowed)
};

#endif /* _QUERYGROUPFUNC_H_ */
