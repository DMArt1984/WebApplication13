#ifndef _WAITGETHOSTBYNAME_H_
#define _WAITGETHOSTBYNAME_H_

#include <WaitCond.hxx>
#include <CtrlThread.hxx>
#include <TextVar.hxx>
#include <TimeVar.hxx>
#include <Mutex.hxx>
#include <PVSSBcm.hxx>

#include <string>
#include <list>

class WaitGetHostByName : public WaitCond
{
  public:
    WaitGetHostByName(CtrlThread *thread, const TextVar &arg, DynVar *target);

   ~WaitGetHostByName();

    virtual const TimeVar & nextCheck() const;

    virtual int checkDone();

  private:
    static Mutex mutex_;  // protects ThreadStruct::waitCond_

    struct ThreadStruct
    {
      // Backpointer of wait condition for the thread.
      // End of thread sets this to 0.
      // Protected by WaitGetHostByAddr::mutex_
      WaitGetHostByName *waitCond_;  
      TextVar name_;
    };

    // Pointer to thread arguments. End of thread sets this to 0.
    ThreadStruct *threadStruct_;
    CtrlThread *thread_;
    TextVar name_;
    DynVar *target_;
    mutable TimeVar nextCheck_;
  
    std::string host_;
    std::list<std::string> list_;
    int error_;

#ifdef _WIN32
   static void __cdecl func(void *arg);
#else
   static void * func(void *arg);
#endif
};

#endif
