#ifndef _ALERTMSGITEM_H_
#define _ALERTMSGITEM_H_

// Vorwaerts-Deklaration der Eigenen Klasse
class AlertMsgItem;

// System-Include-Files
#ifndef _ALERTIDENTIFIER_H_
#include <AlertIdentifier.hxx>
#endif

#ifndef _PTRLISTITEM_H_
#include <PtrListItem.hxx>
#endif

#ifndef _VARIABLE_H_
#include <Variable.hxx>
#endif

#ifndef _ALLOCATOR_H_
#include <Allocator.hxx>
#endif

#include <iostream>


// Vorwaerts-Deklarationen:
class AlertMsgItem;

/**
 * A container for an AlertIdentifier and the corresponding Variable value.
 * Used in connection with alert messages.
 */
class DLLEXP_BASICS AlertMsgItem : public PtrListItem 
{

public:
  /**
   * Default constructor. Creates a new instance with an empty identifier
   * and no value (nullpointer).
   */
  AlertMsgItem();

  /**
   * Creates a new instance with the specified identifier and the specified value.
   *
   * @param anIdentifier The AlertIdentifier to be copied.
   * @param aValuePtr The Variable pointer to be used.
   * The call takes ownership of this pointer.
   */
  AlertMsgItem(const AlertIdentifier &anIdentifier, VariablePtr aValuePtr = 0);
  
  /**
   * Copy constructor.
   *
   * @remarks Does not copy the value pointer of the copied instance.
   * Instead it takes ownership of the pointer.
   */
  AlertMsgItem(const AlertMsgItem &item);
  
  /**
   * Destructor
   */
  ~AlertMsgItem();

  AllocatorDecl;

  /**
   * Assigns the state of the specified item to this item.
   *
   * @remarks Does not copy the value pointer of the specified instance.
   * Instead it takes ownership of the pointer.
   */
  AlertMsgItem &operator=(const AlertMsgItem &item);

  /**
   * Checks whether the specified items are equal.
   *
   * @remarks If the two items have the same identifier,
   * but only one of them has an empty value (null pointer),
   * they are still considered equal for legacy reasons.
   */
  int operator==(const AlertMsgItem &rVal) const;

  /**
   * The message stream send operator. This operator is used to send an
   * instance through a BCM network stream.
   *
   * @internal
   */
  friend DLLEXP_BASICS itcNdrUbSend &operator<<(itcNdrUbSend &ndrStream, const AlertMsgItem &item);

  /**
   * The message stream receive operator. This operator is used to receive
   * an instance from a BCM network stream.
   *
   * It must be the exact mirror function to the send operator.
   * 
   * @internal
   */
  friend DLLEXP_BASICS itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream, AlertMsgItem &item);

  /**
   * Returns the alert identifier of this message item.
   *
   * @return reference to the AlertIdentifier
   */ 
  const AlertIdentifier &getIdentifier() const;

  /**
   * Returns the value pointer. The AlertMsgItem still keeps ownership
   * of the value pointer.
   * If you want to take ownership of the pointer, use cutValuePtr() instead.
   */ 
  VariablePtr getValuePtr() const;
  
  /**
   * Sets the value to the specified pointer. The old value is deleted
   * and the call takes ownership of the specified pointer.
   */
  void setValuePtr(VariablePtr aValuePtr);

  /**
   * Returns the value pointer and removes it from this instance.
   * The internal pointer is set to 0 and the caller has to take
   * ownership of the returned pointer.
   */ 
  VariablePtr cutValuePtr();

  /**
   * Dumps the object contents to a file stream.
   *
   * @param to the target stream
   * @param level the detail level of information, should be > 0
   */
  virtual void debug(std::ostream &to, int level) const;
  
protected:
private:
  AlertIdentifier identifier;
  VariablePtr valuePtr;

};

// -----------------------------------------------------------------------------
// inline-methods:

inline int AlertMsgItem::operator==(const AlertMsgItem &rVal) const
{
    return ((valuePtr && rVal.valuePtr) ?
        (identifier == rVal.identifier && *valuePtr == *rVal.valuePtr) :
        (identifier == rVal.identifier));
}

inline const AlertIdentifier &AlertMsgItem::getIdentifier() const
{
	return identifier;
}

inline VariablePtr AlertMsgItem::getValuePtr() const
{
	return valuePtr;
}

#endif /* _ALERTMSGITEM_H_ */
