#ifndef _INTEGRAL_0_ACCU_H_
#define _INTEGRAL_0_ACCU_H_

// Author: Heinz MEISSL
// Date:   14.4.1997
// Purpose: implement a statistic Accumulator to integrate the values passed

#ifndef _SIMPLEACCU_H_
#include <SimpleAccu.hxx>
#endif

#ifndef _VARIABLE_H_
#include <Variable.hxx>
#endif

#ifndef _FLOATVAR_H_
#include <FloatVar.hxx>
#endif

#ifndef _TIMEVAR_H_
#include <TimeVar.hxx>
#endif

/** A zero order value accumulator class. 
    This class is used to determine the integral value of variables over time. 
    No value transition approximation is applied, i.e. values change in a stepwise mode.

    @classification ETM internal
*/
class DLLEXP_OABASICS Integral0Accu: public SimpleAccu
{
  public:
    /** Constructor.
        @param  aVarType The type identifier, for which the accumulatior is created.
    */
    Integral0Accu(const VariableType aVarType);
    
    /** Accumulate value/time pair.
        Call this function to add the value/time pair to accumulated value.
        @param  theValue The value to be added.
        @param  atTime Timestamp of the value.
    */
    virtual void accumulate(const Variable &theValue, const TimeVar &atTime );
    /** Accumulate invalid value/time pair.
        Call this function to add the value/time pair to accumulated value.
        @param  theValue The value to be added.
        @param  atTime Timestamp of the value.
    */
    virtual void accumulateInvalid(const Variable &theValue,  const TimeVar &atTime );
    /// Get the accumulated value.
    virtual const Variable &getResult();
    /** Get the intermediate accumulated value.
        @param  theValue The value to be added.
        @param  start Timestamp of the interval start.
        @param  stop Timestamp of the interval stop.
        @param  valid Validity flag.
    */
    virtual const Variable &getIntermResult( const Variable &theValue, const TimeVar &start, const TimeVar &stop, bool valid );
    /// Reset the accumulated value.
    virtual void reset();    
    /// Get the last added value
    const Variable &getLastValue();
  protected:
  
  private:
    Integral0Accu(const Integral0Accu &);
    Integral0Accu &operator=(const Integral0Accu &);
  
    double calcValue( const TimeVar &atTime );  // WOKL 2.2.01 TI 7411
    
    FloatVar theSum;
    FloatVar lastValue;
    TimeVar lastTime;
    FloatVar intermResult_;
};

#endif
