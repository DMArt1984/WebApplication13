#ifndef _IDEXPR_H_
#define _IDEXPR_H_

#include <CtrlExpr.hxx>
#include <CtrlVar.hxx>
#include <Allocator.hxx>

/*  author VERANTWORTUNG: Martin Koller                   */
/** Variablen-Ausdruck (Name einer var in einem Ausdruck) */
class DLLEXP_CTRL IdExpr : public CtrlExpr
{
  public:
    AllocatorDecl;

    /// Returns the type of the Expression
    virtual ExprType isA() const { return ID_EXPR; }

    // constructor called by Parser: captures given pointer
    IdExpr(int line, int file, CharString *newName)
      : CtrlExpr(line, file), name(newName), id(0) { }

    virtual ~IdExpr() { delete name; }

    /// name of the variable
    const CharString &getName() const { return *name; }

    CharString *cutName() { CharString *n = name; name = 0; return n; }

    /// expression-statement: Store simple values
    virtual const CtrlSment *execute(CtrlThread *) const;

    /// get variable
    virtual const Variable *evaluate(CtrlThread *thread) const;

    /// get NULL | the CtrlVar
    CtrlVar *getCtrlVar(CtrlThread *thread) const;

    /// Variable that can be written (L-Value)
    virtual Variable *getTarget(CtrlThread *thread) const;

    /// Variable that can be written (L-Value), even if it is a const-var
    Variable *getTargetNoConst(CtrlThread *thread) const;

    virtual void writeTrace(CtrlThread *thread, bool writeValue = true) const;

    virtual CharString toString() const;

    virtual bool checkIntegrity(const CharString &location, CtrlThread *) const;

    // synchronized access
    virtual bool lock(CtrlThread *t) const;
    virtual bool unlock(CtrlThread *t) const;
    virtual bool isLocked(CtrlThread *t) const;
    virtual CtrlThread *getCurrentThread(CtrlThread *t) const;

  private:
    IdExpr(const IdExpr &) = delete;

    CharString *name;
    mutable CtrlVarId id;
};

#endif /* _IDEXPR_H_ */
