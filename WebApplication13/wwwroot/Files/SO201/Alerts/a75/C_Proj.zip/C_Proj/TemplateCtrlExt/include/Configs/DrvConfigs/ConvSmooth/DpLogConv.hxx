// DATEIBESCHREIBUNG ==============================================================
// DATEINAME:     DpLogConv.hxx
// VERANTWORTUNG:  Stanislav Meduna
// 
// BESCHREIBUNG:  Logaritmische Umrechnung.
//
// AENDERUNGS-HISTORIE
// Ver.  | Datum      | Aenderungen                            | ModNr.| Autor
// ------+------------+-----------------Anfang-----------------+-------+-----------
//   1.0 |            | 1.Erstellung mit Westmount-OMT         |     0 |
// ======================================Ende======================================
#ifndef _DPLOGCONV_H_
#define _DPLOGCONV_H_

// Vorwaerts-Deklaration der Eigenen Klasse
class DpLogConv;

// System-Include-Files
#include <math.h>
#include <DpConversion.hxx>
#include <FloatVar.hxx>

// Vorwaerts-Deklarationen :
class DpConvSmooth;
class DpLogConv;
class Variable;

class BitVec;

// ========== DpLogConv ============================================================
/// Conversion class used for calculating the logarithm.
class DLLEXP_CONFIGS DpLogConv : public DpConversion 
{

  // Klassen-Enums:

// ..........................Anfang User-Klasseninterne-Definitionen..................
// ...........................Ende User-Klasseninterne-Definitionen...................
public:
  /// Friend class definition used for unit-tests.
  friend class UNIT_TEST_FRIEND_CLASS;

  /// Default construktor.
  DpLogConv();
  /// Destructor.
  ~DpLogConv();

  // Operatoren :
  /// Write the object into itcNdrUbSend stream.
  friend DLLEXP_CONFIGS itcNdrUbSend &operator<<(itcNdrUbSend &ndrStream, const DpLogConv &aConv);
  /// Read the object from itcNdrUbReceive stream.
  friend DLLEXP_CONFIGS itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream, DpLogConv &aConv);
  /// Assignment operator.
  /// @return Reference to the DpConvSmooth object reference with the assigned value.
  virtual DpConvSmooth &operator=(const DpConvSmooth &aConv);

  // Spezielle Methoden :
  /// Returns conversion type of this class.
  virtual DpConversionType convType() const;
  /// Convert method. 
  /// @param inpVar Input variable.
  /// @param outVarPtr Pointer to the newly allocated output Variable.
  /// @param unused Not used.
  /// @return 
  /// - DpConversionOK if the conversion was successfull.
  /// - DpConversionError if it was not possible to allocate the new output variable, or the attrBase is set to invalid value.
  /// - DpConversionInvValue if the input value is invalid.
  /// - DpConversionBadType if input variable is of not allowed type.
  virtual DpConversionResultType convert(const Variable &inpVar, Variable * & outVarPtr, const BitVec &unused);
  /// Allocates the new instance of DpLogConv.
  /// @return DpConvSmooth pointer to a newly allocated instance.  
  virtual DpConvSmooth *allocate() const;
  /// Set attribute.
  /// @param attrNr Attribute number.
  /// @param var Attribute value.
  virtual PVSSboolean setAttribut(DpAttributeNrType attrNr, const Variable &var);
  /// Get  attribute value.
  /// @param attrNr Attribute number.
  /// @return On success pointer to newly allocated variable is returned. On error, 0 is returned.
  virtual Variable *getAttribut(DpAttributeNrType attrNr) const;
  /// Check if the instance is correctly set-up.
  virtual PVSSboolean isConsistent() const;

  // Generierte Methoden :
  /// Get current value of internal parameter attrBase.
  const FloatVar &getAttrBase() const;
  /// Get current value of internal parameter attrBase.
  FloatVar &getAttrBase();
  /// Set new value for internal parameter attrBase.
  void setAttrBase(const FloatVar &newAttrBase);
protected:
private:
  const PVSSdouble &getLogBase() const;
  PVSSdouble &getLogBase();
  void setLogBase(const PVSSdouble &newLogBase);
  FloatVar attrBase;
  PVSSdouble logBase;

// ............................Anfang User-Attribut-Definitionen...................
// .............................Ende User-Attribut-Definitionen....................
};

// ================================================================================
// Inline-Funktionen :
inline const FloatVar &DpLogConv::getAttrBase() const
{
  return attrBase;
}

inline FloatVar &DpLogConv::getAttrBase()
{
  return attrBase;
}
inline void DpLogConv::setAttrBase(const FloatVar &newAttrBase)
{
  attrBase = (FloatVar &) newAttrBase;
}
inline const PVSSdouble &DpLogConv::getLogBase() const
{
  return logBase;
}

inline PVSSdouble &DpLogConv::getLogBase()
{
  return logBase;
}
inline void DpLogConv::setLogBase(const PVSSdouble &newLogBase)
{
  logBase = (PVSSdouble &) newLogBase;
}

// ............................Anfang User-Inlines.................................
// .............................Ende User-Inlines..................................

#endif /* _DPLOGCONV_H_ */
