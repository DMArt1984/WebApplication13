#ifndef _MAPTABLE_H_
#define _MAPTABLE_H_

// Authors: Stanislav Meduna, Martin Koller

/** Class which holds a mapping table between an id (ulong) and a name
    Ids _must_ be unique, names _may_ be unique - depending on allowDupNames flag
*/

#ifndef  _DPIDENTIFICATIONRESULTTYPE_H_
#include <DpIdentificationResultType.hxx>
#endif

#ifndef  _MAPTABLEITEM_H_
#include <MapTableItem.hxx>
#endif

#ifndef  _SIMPLEPTRARRAY_H_
#include <SimplePtrArray.hxx>
#endif

#ifndef _DYNPTRARRAY_H_
// needed for DynPtrArrayIndex and DYNPTRARRAY_INVALID
#include <DynPtrArray.hxx>
#endif


#ifdef WIN32
#pragma warning ( disable: 4231 )
#endif

#if defined(LIBS_AS_DLL)
  EXTERN_DATAPOINT template class DLLEXP_DATAPOINT SimplePtrArray<MapTableItem>;
#endif

#ifdef WIN32
#pragma warning ( default: 4231 )
#endif

class DataPointTable;

// ========== MapTable ============================================================

/// The map table class
/// Base class for DataPoint amd DataType mapping classes
class DLLEXP_DATAPOINT MapTable
{
  friend class UNIT_TEST_FRIEND_CLASS;    // ein Unit-Test braucht erweiterten zugriff auf diese Klasse

  public:
     
    /// constructor
    /// @param holdDpTabelItems the items flag: false = the table only holds LangauageTableItems, true = the table hodls only DpTableItems
    MapTable(bool holdDpTabelItems = false);
    
    /// destructor
    ~MapTable();

    /// operator << for itcNdrUbSend stream
    /// @param ndrStream the stream, which to send to
    /// @param table the MapTable
    friend DLLEXP_DATAPOINT itcNdrUbSend &operator<<(itcNdrUbSend &ndrStream, const MapTable &table);

    /// operator >> for itcNdrUbReceive stream
    /// @param ndrStream the stream, which to receive from
    /// @param table the MapTable
    friend DLLEXP_DATAPOINT itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream, MapTable &table);

    /// operator << for itcNdrUbSend stream
    /// @param ndrStream the stream, which to send to
    /// @param table the DataPointTable
    friend DLLEXP_DATAPOINT itcNdrUbSend &operator<<(itcNdrUbSend &ndrStream, const DataPointTable &table);

    /// operator >> for itcNdrUbReceive stream
    /// @param ndrStream the stream, which to receive from
    /// @param table the DataPointTable
    friend DLLEXP_DATAPOINT itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream, DataPointTable &table);

    /// get length
    DynPtrArrayIndex length() const;

    /// get item at given index
    /// @param index the index
    const MapTableItem *getAt(DynPtrArrayIndex index) const;

    /// get pointer to item corresponding to name
    /// @param name the name
    const MapTableItem *getItem(const char *name) const;

    /// get pointer to item corresponding to id
    /// @param id the ID
    const MapTableItem *getItem(MapTableItemId id) const;

    /// get pointer to name of item corresponding to id
    /// @param id the ID
    /// @return when the id exists in the table, the corresponding name, otherwise 0
    const char *getName(MapTableItemId id) const;

    /// add item
    /// WARNING: DEVELOPER IS RESPONSIBLE FOR CORRECT TYPE OF THE ITEM FOR DERIVED CLASS
    /// @n The class takes ownership of given object (even in case of errors).
    /// @param newItemPtr the item to add
    /// @return result
    DpIdentificationResult addItem(MapTableItem *newItemPtr);

    /// add item with specifid ID and name
    /// WARNING: FUNCTION IS FORBIDDEN FOR SOME DERIVED CLASSES
    /// @param id the item ID to add
    /// @param name the name
    /// @return result
    DpIdentificationResult addItem(MapTableItemId id, const char * name);

    /// remove item
    /// @param id the item ID
    /// @return result
    DpIdentificationResult removeItem(MapTableItemId id);

    /// check for duplicity
    /// @n The function checks duplicit IDs. If the "duplicate names flag" is set, it checks also duplicit names.
    /// @param id the item ID to check
    /// @param name the name
    /// @return result
    DpIdentificationResult checkForDuplicity(MapTableItemId id, const char * name) const;

    /// check for duplicity
    /// @n The function checks duplicit IDs. If the "duplicate names flag" is set, it checks also duplicit names.
    /// @param id the item ID to check
    /// @param name the name
    /// @param compareWithId the item ID to compare with, if id == compareWithId, the result of this check is positiv
    /// @return result
    DpIdentificationResult checkForDuplicity(MapTableItemId id, const char * name, MapTableItemId compareWithId) const;

    /// reset iterator
    /// @return result
    DpIdentificationResult iteratorReset() const;

    /// set iterator to the next name
    /// @param mask the mask
    /// @param namePtrRef the name
    /// @param idRef the ID
    /// @param fixPart the fix part
    /// @param itemRet the map table
    /// @return result
    DpIdentificationResult iteratorNextName(const char *mask, const char * & namePtrRef,
                                            MapTableItemId &idRef,
                                            const char *fixPart = 0, MapTableItem ** itemRet = 0) const;

    DpIdentificationResult iteratorNextNameIgnoreCase(const char *mask, const char * & namePtrRef,
                                                      MapTableItemId &idRef, MapTableItem ** itemRet = 0,
                                                      GlobalLanguageIdType langIdg = 0) const;

private:
    DpIdentificationResult iteratorNextNameCommon(const char *mask, const char * & namePtrRef,
                                                  MapTableItemId &idRef, const char *fixPart, MapTableItem ** itemRet,
                                                  GlobalLanguageIdType langIdg, bool ignoreCase) const;

public:
  /// set allow duplicate names flag
    /// @param newAllowDupNames the value to set
    void setAllowDupNames(bool newAllowDupNames) { allowDupNames = newAllowDupNames; }

    /// call given function for every element
    /// @param callback the callback
    PVSSboolean visitEveryElement(PVSSboolean (*callback)(const MapTableItem &langItem)) const;

    /// get the number of items, strings and bytes in this table
    /// @param items the number of items
    /// @param strings the number of strings
    /// @param bytes the number of bytes
    void summary(unsigned &items, unsigned &strings, unsigned &bytes);

    /// clear the table (only used in DpIdentification)
    /// @classification internal
    void clear();

  protected:

    /// size of the string
    size_t strSize;

    /// allow duplicate names flag
    bool allowDupNames;

    /// this class hold DpTableItems instead of MapTableItems
    bool isDpTable;            

    /// current index
    mutable DynPtrArrayIndex iteratorCurrentIndex;

    /// items sorted by ID
    SimplePtrArray<MapTableItem>  idTable;

    /// items sorted by name
    SimplePtrArray<MapTableItem>  nameTable;

    /// compare function by ID
    /// @param item1 the table item 1
    /// @param item2 the table item 2
    /// @return result of comparison
    static int compareById  (const MapTableItem *, const MapTableItem *);

    /// compare function by name
    /// @param item1 the table item 1
    /// @param item2 the table item 2
    /// @return result of comparison
    static int compareByName(const MapTableItem *, const MapTableItem *);

  private:
    // So the compiler doesn't define it
    MapTable(const MapTable &);
    MapTable & operator=(const MapTable &) {return *this;} // COVINFO LINE: defensive (defined private so no one can use it)
};

// ================================================================================
// Inline-Funktionen :

inline DynPtrArrayIndex MapTable::length() const
{
  return(idTable.getNumberOfItems());
}

inline const MapTableItem * MapTable::getAt(DynPtrArrayIndex index) const
{
   return idTable.getAt(index);
}

// sollte void sein TODO
inline DpIdentificationResult MapTable::iteratorReset() const
{
  iteratorCurrentIndex = DYNPTRARRAY_INVALID;

  return DpIdentOK;
}

// ========== DataPointTable ============================================================

/// The DataPoint mapping table class
/// This class holds DataPoints for mapping purposes.
class DLLEXP_DATAPOINT DataPointTable : public MapTable
{
  public:

    /// constructor, initialisation with zero values
    DataPointTable(): MapTable(true), bulkAddIndex(0) {}

    /// operator << for itcNdrUbSend stream
    /// @param ndrStream the stream, which to send to
    /// @param table the DataPointTable
    friend DLLEXP_DATAPOINT itcNdrUbSend &operator<<(itcNdrUbSend &ndrStream, const DataPointTable &table);

    /// operator >> for itcNdrUbReceive stream
    /// @param ndrStream the stream, which to receive from
    /// @param table the DataPointTable
    friend DLLEXP_DATAPOINT itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream, DataPointTable &table);

  public:

    /// set DpTypeId of given item ID
    /// @param id the item ID
    /// @param dpTypeId the DpTypeId to set
    /// @return result
    DpIdentificationResult setDpTypeId(MapTableItemId id, DpTypeId dpTypeId);

    /// set DpTypeId at given index
    /// @param index the item ID
    /// @param dpTypeId the DpTypeId to set
    /// @return result
    DpIdentificationResult setDpTypeIdAt(DynPtrArrayIndex index, DpTypeId dpTypeId);

    /// initialize bulk-loading of DPs
    void bulkInit();
    /// add a DP for bulk-loading
    void bulkAddDp(DpIdType id, DpTypeId typeId, const char *name);
    /// finalize bulk-loading of DPs
    void bulkFinalize();

  private:
    /// next insertion index for bulk-loading DPs
    unsigned int bulkAddIndex;
};

// ========== DataTypeTable ============================================================

/// The DataType mapping table class
/// This class holds DataTypes for mapping purposes.
class DLLEXP_DATAPOINT DataTypeTable : public MapTable
{
  public:

    /// constructor, initialisation with zero values
    DataTypeTable(): MapTable(false) {}

    /// operator << for itcNdrUbSend stream
    /// @param ndrStream the stream, which to send to
    /// @param table the DataTypeTable
    friend DLLEXP_DATAPOINT itcNdrUbSend &operator<<(itcNdrUbSend &ndrStream, const DataTypeTable &table);

    /// operator >> for itcNdrUbReceive stream
    /// @param ndrStream the stream, which to receive from
    /// @param table the DataTypeTable
    friend DLLEXP_DATAPOINT itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream, DataTypeTable &table);

  private:

    void writeFixedNumbersTableItem(itcNdrUbSend &ndrStream) const;

    void readFixedNumbersTables(itcNdrUbReceive &ndrStream, DynPtrArrayIndex _nofTables);

    void readDataTypeTable(itcNdrUbReceive &ndrStream);
};

#endif /* _MAPTABLE_H_ */
