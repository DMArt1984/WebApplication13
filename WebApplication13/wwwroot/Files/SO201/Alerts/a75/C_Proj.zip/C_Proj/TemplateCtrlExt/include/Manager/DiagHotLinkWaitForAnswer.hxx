#ifndef _DIAGHOTLINKWAITFORANSWER_H_
#define _DIAGHOTLINKWAITFORANSWER_H_

#include <HotLinkWaitForAnswer.hxx>
#include <DiagItcIOHandler.hxx>

/*
VERANTWORTUNG: Andreas Pfluegl
BESCHREIBUNG: 
*/


/** the DiagItcIOHandler class is a Timer-Object that writes some PVSS-Resource Counter
  * to a DP of the type _Statistics.
  * once the Timer is started by the Manager-Class it restarts itself periodically
  * 
  * @classification internal use
  */
class DiagHotLinkWaitForAnswer: public HotLinkWaitForAnswer
{
  public:

	DiagHotLinkWaitForAnswer(DiagItcIOHandler &itc) 
  : itc_(itc)
  {  }
	/// destructor
	virtual ~DiagHotLinkWaitForAnswer(){}

	virtual void hotLinkCallBack(DpMsgAnswer &answer);

	virtual void hotLinkCallBack(DpHLGroup &group);

  private:
     DiagItcIOHandler &itc_;
};

// ----------------------------------------------------------------------------
// --
// ----------------------------------------------------------------------------
inline void DiagHotLinkWaitForAnswer::hotLinkCallBack(DpMsgAnswer &answer)
{
  itc_.hotLinkCallBack(answer);
}

// ----------------------------------------------------------------------------
// --
// ----------------------------------------------------------------------------
inline void DiagHotLinkWaitForAnswer::hotLinkCallBack(DpHLGroup &group)
{
  itc_.hotLinkCallBack(group);
}


#endif /* _DIAGHOTLINKWAITFORANSWER_H_ */
