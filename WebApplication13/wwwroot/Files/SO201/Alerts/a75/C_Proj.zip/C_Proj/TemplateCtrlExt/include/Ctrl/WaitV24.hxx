#ifndef  WAITV24_H
#define  WAITV24_H

#include <WaitCond.hxx>
#include <TimeoutTimer.hxx>
#include <TimeVar.hxx>

#ifdef WIN32
#include <windows.h>
#endif

class CtrlThread;
class CtrlExpr;

// Waitobject zum lesen
class  WaitV24 : public WaitCond
{
  public:
    WaitV24(int handle, Variable *target, const TimeVar & timeout, CtrlThread *thread);

    /// Destructor not neccessary here

    /// when shall we call checkDone next
    virtual const TimeVar &nextCheck() const;

    /// checks if the wait condition has finished
    virtual int checkDone();

  private:    
    int  handle_;
    Variable *  target_;
    TimeoutTimer timer;
    CtrlThread *thread_;
    CtrlExpr *  fcall_;

# ifdef WIN32
    DWORD   bytes;
# else
    int     bytes;
# endif

    mutable TimeVar nextCheck_;     // IM 113703

    char    buffer[1024];
};


#endif
