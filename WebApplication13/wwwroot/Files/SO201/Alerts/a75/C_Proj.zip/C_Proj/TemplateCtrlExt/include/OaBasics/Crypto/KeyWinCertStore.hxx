// -----------------------------------------------------------------------------
// creator: Andras Horvath - 01.09.2017
// purpose: concrete implementation of Key class for windows cert store
// -----------------------------------------------------------------------------
#ifndef _KEYWINCERTSTORE_HXX_
#define _KEYWINCERTSTORE_HXX_

#include <Key.hxx>
#include <memory>
#include <string>

/**
  @class KeyWinCertStore
  @brief The KeyWinCertStore class
         implements a private and public Key stored in the Windows Certificate
         Store.
         This class implements the singing, verifying and checking of
         keys and signatures, as well as loading private keys, certificates
         and the serialization of an KeyWinCertStore object.
         The key has to be imported using the Microsoft Enhanced RSA and AES
         Cryptographic Provider.
         This Key type works only on Windows.
*/
class DLLEXP_OABASICS KeyWinCertStore : public Key
{
public:
  /// destructor
  ~KeyWinCertStore() override;

  /**
    @brief   Create a digital signature with a KeyWinCertStore.
    @details This function signs the given data with the private key.
             Can be used only with private keys.
    @param   data       Blob data to sign
    @param   signature  returning Signature object containing the signated data
    @return             0 if successful
  */
  int sign(const Blob& data, Signature& signature) const override;

  /**
    @brief   Verifies the validity of a KeyWinCertStore.
             Can be used only with public keys (certificates).
    @details This function verifies the public key against the crlFile and the
             caFile lists.
             The KeyWinCertStore must be a certificate signed by a trusted root
             or intermediate certificate and must not be revoked.
             The trusted root and the revocation lists are used automatically
             from the certificate store.
    @param   crlFiles     not used
    @param   caFiles      not used
    @param   chainPrefix  check if the certificate chain starts with this
                          prefix. Use the names of the certificates in the
                          trusted chain, separated by a semicolon (;)
    @param   verifyTime   check if the certificate is expired ( default = true )
    @return               0 if certificate is valid and not revoked,
                          else error code
  */
  int verify(const Key::CrlList& crlFiles,
             const Key::CaList& caFiles,
             const std::string& chainPrefix,
             bool verifyTime = true) const override;

  /**
    @brief  Checks a digital signature with the KeyWinCertStore.
            Can be used only with public keys (certificates).
    @param  data       Blob data that was signed
    @param  signature  the Signature object containing the digital signature
    @return            0 if signature is valid, else error code
  */
  int checkSignature(const Blob& data,
                     const Signature& signature) const override;

  /**
    @brief  Seals an envelope
            Can be used only with public keys.
    @param  inputData  Blob data that has to be encrypted
    @param  sealedData the output encrypted data
    @return            0 if successful, else error code
  */
  virtual int sealEnvelope(const Blob& inputData,
                           Blob& sealedData) const override;

  /**
    @brief  Opens an envelope
            Can be used only with private keys.
    @param  sealedData the input encrypted data
    @param  outputData  the decrypted output Blob data
    @return            0 if successful, else error code
  */
  virtual int openEnvelope(const Blob& sealedData,
                           Blob& outputData) const override;

  /**
    @brief  Gets the common name field (CN) of a certificate.
    @param  componentName  component name, if empty, returns the whole common
                           name string
    @return                common name of the certificate
  */
  std::string getCommonName(const std::string& componentName) const override;

  /**
    @brief   Construct a new instance of the KeyWinCertStore class.
    @details This function implements how to create a key based on a Key::Type
             and the resources.
    @param   keyType      type of the Key
    @param   loc          Selects the location of the Store to be used.
                          Possible Values: "USER" or "MACHINE"
    @param   store        The name of the store within location to be used.
    @param   storePath    Search criteria to find the certificate. It could be
                          the certificate name, or the SHA1 hash of the
                          certificate
    @param   verifyTime   if true, the function searches for the first not
                          expired certificate with the supplied name. If false,
                          the first certificate found is returned
    @return               created Key object based on parameters
  */
  static SmartKey create(Key::Type keyType,
                         const std::string& loc,
                         const std::string& store,
                         const std::string& storePath,
                         bool verifyTime = true);

  /**
    @brief   Construct a new instance of the KeyWinCertStore class.
    @details This function implements how to create a key based on a previously
             JSON serialized Key object.
             Only public keys can be created with this function.
    @param   jsonData    JSON serialized representation of Key subclass object
    @param   verifyTime  this parameter is not used
    @return              created Key object based on parameters
  */
  static SmartKey create(Key::Type keyType,
                         const QJsonObject& jsonData,
                         bool verifyTime = true);

private:
  /// constructor from config entry
  KeyWinCertStore(Key::Type keyType,
                  const std::string& loc,
                  const std::string& store,
                  const std::string& storePath,
                  bool verifyTime);

  /// constructor from json object
  KeyWinCertStore(Key::Type keyType,
                  const QJsonObject& jsonData,
                  bool verifyTime = true);

#ifdef _WIN32
  class Impl;

#  pragma warning(push)
#  pragma warning(disable : 4251)
  std::unique_ptr<Impl> m_impl;
#  pragma warning(pop)
#endif
};

#endif  // _KEYWINCERTSTORE_HXX_
