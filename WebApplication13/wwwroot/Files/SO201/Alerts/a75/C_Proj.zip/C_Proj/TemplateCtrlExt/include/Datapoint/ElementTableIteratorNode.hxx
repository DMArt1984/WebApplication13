// DATEIBESCHREIBUNG ==============================================================
// DATEINAME:     ElementTableIteratorNode.hxx
//
//
// AENDERUNGS-HISTORIE
// Ver.  | Datum      | Aenderungen                            | ModNr.| Autor
// ------+------------+-----------------Anfang-----------------+-------+-----------
//   1.0 |            | 1.Erstellung mit Westmount-OMT         |     0 |
// ======================================Ende======================================
#ifndef _ELEMENTTABLEITERATORNODE_H_
#define _ELEMENTTABLEITERATORNODE_H_

// Vorwaerts-Deklaration der Eigenen Klasse
class ElementTableIteratorNode;

#ifndef  _TYPES_H_
#include <Types.hxx>
#endif

#ifndef  _DPTYPENODE_H_
#include <DpTypeNode.hxx>
#endif

#ifndef  _DYNPTRARRAY_H_
#include <DynPtrArray.hxx>
#endif


// Vorwaerts-Deklarationen :
class ElementTableIteratorNode;

// ========== ElementTableIteratorNode ============================================================
/**
  node of the ElementTable iterator
*/
class DLLEXP_DATAPOINT ElementTableIteratorNode 
{
public:
  /// Constructor
  ElementTableIteratorNode();
  /// Destructor
  ~ElementTableIteratorNode();

  // Operatoren :
  /**operator ==
    @param item the item to compare to
    return nonzero when equal, zero otherwise
    */
  int operator==(const ElementTableIteratorNode &item) const;

  /**operator !=
    @param item the item to compare to
    return nonzero when unequal, zero otherwise
    */
  int operator!=(const ElementTableIteratorNode &item) const;

  /**getNodePtr() returns stored node pointer
    @return the stored node pointer, the caller must not delete it
    */
  const DpTypeNode *getNodePtr() const;

  /**setNodePtr() stores node ptr
    @param newNodePtr the new DpTypeNode, the method does not take ownership
    */
  void setNodePtr(const DpTypeNode *newNodePtr);
  
  /**getCurrentIndex() returns stored index
    @return DynPtrArrayIndex
    */
  DynPtrArrayIndex getCurrentIndex() const;

  /**getCurrentIndex() stores index
    @param newCurrentIndex DynPtrArrayIndex
    */
  void setCurrentIndex(DynPtrArrayIndex newCurrentIndex);

private:
  DpTypeNode *nodePtr;
  DynPtrArrayIndex currentIndex;
};

// ================================================================================
// Inline-Funktionen :

// Konstruktor
inline  ElementTableIteratorNode::ElementTableIteratorNode()
{
}


// Destruktor
inline  ElementTableIteratorNode::~ElementTableIteratorNode()
{
}


inline  int ElementTableIteratorNode::operator==(const ElementTableIteratorNode &item) const
{
	return (currentIndex == item.currentIndex) && (nodePtr == item.nodePtr);
}


inline  int ElementTableIteratorNode::operator!=(const ElementTableIteratorNode &item) const
{
	return ! (*this == item);
}


inline const DpTypeNode *ElementTableIteratorNode::getNodePtr() const
{
  return nodePtr;
}


inline void ElementTableIteratorNode::setNodePtr(const DpTypeNode *newNodePtr)
{
  nodePtr = (DpTypeNode *) newNodePtr;
}


inline DynPtrArrayIndex ElementTableIteratorNode::getCurrentIndex() const
{
  return currentIndex;
}


inline void ElementTableIteratorNode::setCurrentIndex(DynPtrArrayIndex newCurrentIndex)
{
  currentIndex = newCurrentIndex;
}

#endif /* _ELEMENTTABLEITERATORNODE_H_ */
