#ifndef _CONFIGS_MAPPER_H_
#define _CONFIGS_MAPPER_H_

// Author: Martin Koller, June 2004

//--------------------------------------------------------------------------------

#include <DpConfigNrType.hxx>
#include <DpTypes.hxx>
class CharString;
class DpSymIdentifier;
class DpIdentifier;
class DpIdentList;

//--------------------------------------------------------------------------------

/** This class is an interface to map config/detail/attribute name to their id and vice versa.
    It works with static hardcoded data, so every manager has this information
    @classification public use
    */

class DLLEXP_BASICS ConfigsMapper
{
  public:
    // the name -> id functions

    /** get the config id from its name.
        @param name the name of the config, e.g. "_online"
        @param id the result id if the name was valid
        @return true if the name was valid, else false
        @classification public use, call
    */
    static bool getConfigId(const CharString &name, DpConfigNrType &id);
    /** get the config id from its name.
        @param name the name of the config, e.g. "_online"
        @param id the result id if the name was valid
        @return true if the name was valid, else false
        @classification public use, call
    */
    static bool getConfigId(const char *name, DpConfigNrType &id);
    /** get the config id from its name.
        @param name the name of the config, e.g. "_online"
        @param len must be strlen(name), otherweise the result is undefined.
        @param id the result id if the name was valid
        @return true if the name was valid, else false
        @classification public use, call
    */
    static bool getConfigId(const char *name, size_t len, DpConfigNrType &id);

    /** get the detail id from its name.
        @param config the id of the config, e.g. DPCONFIGNR_AUTH
        @param name the name of the detail, e.g. "_pv_range" (only a few configs have named details) or "3"
        @param id the result id if the name was valid
        @return true if the name was valid, else false
        @classification public use, call
    */
    static bool getDetailId(DpConfigNrType config, const CharString &name, DpDetailNrType &id);
    /** get the detail id from its name.
        @param config the id of the config, e.g. DPCONFIGNR_AUTH
        @param name the name of the detail, e.g. "_pv_range" (only a few configs have named details) or "3"
        @param id the result id if the name was valid
        @return true if the name was valid, else false
        @classification public use, call
    */
    static bool getDetailId(DpConfigNrType config, const char *name, DpDetailNrType &id);
    /** get the detail id from its name.
        @param config the id of the config, e.g. DPCONFIGNR_AUTH
        @param name the name of the detail, e.g. "_pv_range" (only a few configs have named details) or "3"
        @param len must be strlen(name), otherweise the result is undefined.
        @param id the result id if the name was valid
        @return true if the name was valid, else false
        @classification public use, call
    */
    static bool getDetailId(DpConfigNrType config, const char *name, size_t len, DpDetailNrType &id);

    /** get the attribute id from its name.
        @param config the id of the config, e.g. DPCONFIGNR_ONLINEVALUE
        @param name the name of the attribute, e.g. "_value"
        @param id the result id if the name was valid
        @return true if the name was valid, else false
        @classification public use, call
    */
    static bool getAttributeId(DpConfigNrType config, const CharString &name, DpAttributeNrType &id);
    /** get the attribute id from its name.
        @param config the id of the config, e.g. DPCONFIGNR_ONLINEVALUE
        @param name the name of the attribute, e.g. "_value"
        @param id the result id if the name was valid
        @return true if the name was valid, else false
        @classification public use, call
    */
    static bool getAttributeId(DpConfigNrType config, const char *name, DpAttributeNrType &id);
    /** get the attribute id from its name.
        @param config the id of the config, e.g. DPCONFIGNR_ONLINEVALUE
        @param name the name of the attribute, e.g. "_value"
        @param len must be strlen(name), otherweise the result is undefined.
        @param id the result id if the name was valid
        @return true if the name was valid, else false
        @classification public use, call
    */
    static bool getAttributeId(DpConfigNrType config, const char *name, size_t len, DpAttributeNrType &id);

    // the id -> name functions

    /** get the config name from its id.
        @param config the id of the config, e.g. DPCONFIGNR_ONLINEVALUE
        @return a pointer to the name (in static area, so don't delete), or 0 if not found
        @classification public use, call
    */
    static const char *getConfigName(DpConfigNrType config);

    /** get the detail name from its id.
        @param config the id of the config, e.g. DPCONFIGNR_AUTH
        @param detail the id of the detail
        @param name this object passed is the memory to which we write a "calculated" detail
                    (the detail number represented in ASCII).
                    If the result is not "calculated", this object is not used.
        @return the pointer returned is the pointer to the given name CharString parameter if
                the result was calculated, otherwise it returns a pointer to static data if
                the detail is known, else it returns 0
                Never delete this pointer.
        @classification public use, call
    */
    static const char *getDetailName(DpConfigNrType config, DpDetailNrType detail, CharString &name);

    /** get the attribute name from its id.
        @param config the id of the config, e.g. DPCONFIGNR_ONLINEVALUE
        @param attrib the id of the attribute
        @return a pointer to the name (in static area, so don't delete), or 0 if not found
        @classification public use, call
    */
    static const char *getAttributeName(DpConfigNrType config, DpAttributeNrType attrib);

    //////////////////////////////////////////////////////////////////////

    /** get a DpIdentList for matching parts in the mask.

        If the given mask contains no config, an empty list is returned
        else it returns all configs which will also contain all details
        (if defined in mask) and all attributes (if defined in mask)
        @param mask contains either 0-pointers for config/detail/attr
            if these parts are not needed or a pointer != 0 (defining a
            pattern) if this part (matching that pattern) shall be gathered
        @param idList returned list
        @classification public use, call
    */
    static void getMatchingList(const DpSymIdentifier &mask, DpIdentList &idList);

    /** return pointer to configs (id array) and number of entries therein
        @param num returns the number of elements in the array
        @return a pointer to the list of attribute ids (in static area, so don't delete)
        @classification public use, call
    */
    static const DpConfigNrType *getConfigIds(size_t &num);

    /** return pointer to attributes of a config (id array) and number of entries therein
        @param config The configNr for which you like to know all attribueIds
        @param num returns the number of elements in the array
        @return a pointer to the list of attribute ids (in static area, so don't delete), or 0 if unknown config given
        @classification public use, call
    */
    static const DpAttributeNrType *getAttributeIds(DpConfigNrType config, size_t &num);

  private:
    ConfigsMapper() {} //COVINFO LINE: defensive (AP: no instance allowed)

    // add all attributes for the given config (set in id) to the idList
    static void getAttributes(const DpSymIdentifier &mask, DpIdentifier &id, DpIdentList &idList);
};

#endif
