// DATEIBESCHREIBUNG ==============================================================
// DATEINAME:     StartDpInitSysMsg.hxx
// Verantwortung : Stanislav Meduna
// Beschreibung : Wird vom initialisierenden Manager zu dem
//                DataManager geschickt und bestimmt, was
//                der Manager fuer seine Initialisierung braucht
//
// AENDERUNGS-HISTORIE
// Ver.  | Datum      | Aenderungen                            | ModNr.| Autor
// ------+------------+-----------------Anfang-----------------+-------+-----------
// ======================================Ende======================================
#ifndef _STARTDPINITSYSMSG_H_
#define _STARTDPINITSYSMSG_H_

class StartDpInitSysMsg;

#include <SysMsg.hxx>

#include <PtrList.hxx>
#include <PtrListItem.hxx>

#include <DpConfigNrType.hxx>

class MappingVar;

// ========== StartDpInitSysMsg ============================================================

/**  The datapoint initialization message system class. 
 *   The message is sent during initialization of the manager to the DataManager in order to obtain need information.
 *   There are two basic request types defined:
 *      - Type container
 *      - DpIdentification
 *
 *   The user can in the case of local system a "Own system" flag used along with those two request types. This flag is also 
 *   automatically set in the Manager::connectToData method during manager's initialization phase.
 *   
 *   The Data Manager answers with requested information then.
 */
class DLLEXP_MESSAGES StartDpInitSysMsg : public SysMsg
{
  friend class UNIT_TEST_FRIEND_CLASS;    // ein Unit-Test braucht erweiterten zugriff auf diese Klasse

   /** BCM output streaming operator.  
    *  
    *  @param [in,out] ndrStream the BCM output stream
    *  @param sysMsg the StartDpInitSysMsg object to stream over BCM
    *  @return ndrStream
    */
  friend DLLEXP_MESSAGES itcNdrUbSend &operator<<(itcNdrUbSend &ndrStream, const StartDpInitSysMsg &sysMsg);

  /** BCM input streaming operator. All properties found in the stream replace the
    *  corresponding properties in the StartDpInitSysMsg
    *
    *  @param [in,out] ndrStream the BCM input stream
    *  @param [out] sysMsg the StartDpInitSysMsg object to receive from BCM
    *  @return ndrStream
    */
  friend DLLEXP_MESSAGES itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream, StartDpInitSysMsg &sysMsg);

   /** Output streaming operator. 
    *  
    *  @param [in,out] ofStream the output stream
    *  @param sysMsg the StartDpInitSysMsg object to stream over BCM
    *  @return ndrStream
    */
  friend DLLEXP_MESSAGES std::ostream &operator<<(std::ostream &ofStream, const StartDpInitSysMsg &sysMsg);

  public:
    /// Enum, what to request
    enum
    {
      TYPE_CONTAINER = 0x1,
      DP_IDENTIFICATION = 0x2,
      OWN_SYSTEM = 0x4
    };
    
    // Diese Klasse kann auch der Anwender brauchen - public
  public:

    /**  The datapoint configuration number helper class. 
     *   The class provides an easy acces to the DpConfig numbers internal list.
     *   Use that class when adding the DpConfigs. 
     */
    class DpConfigNrItem : public PtrListItem
    {
      public:

        /** Default constructor
            @param newConfigNr a DpConfig number (by default a NOCONFIG is defined )
         */
        DpConfigNrItem(DpConfigNrType newConfigNr = DPCONFIGNR_NOCONFIGNR)
          : configNr(newConfigNr) {};

        /// A DpConfig number type
        DpConfigNrType  configNr;
    };

  public:
    /// Default constructor
    StartDpInitSysMsg();

     /** Constructor to request parametrization from this manager
        @param newDestination a destination identification 
        @param newatToSend indicates what to send ( container, dp identificator or own system) 
        @param configNrList a list of configuration numbers
     */
    StartDpInitSysMsg(const ManagerIdentifier &newDestination, unsigned newatToSend = 0, 
        const DpConfigNrType *configNrList = 0);

    /** Copy constructor
        @param newMsg an instance of the message to be copied from
     */
    StartDpInitSysMsg(const StartDpInitSysMsg &newMsg);

    /// Destructor
    ~StartDpInitSysMsg();

    // - TypKontainer, DpIdentification, ...
    /** Method specifies what kind of the configuration item will be returned from DataManager.
     *   @param what a request type. Can be one of the following values (Type container, DpIdentification or own system)
     */
    void addWhatToSend(unsigned what);

    // - DpConfigs
    /** Method adds a new DpConfig item number into the list of configuration numbers.
     *   @param what a DpConfig number type.
     */
    void addConfigNrToSend(DpConfigNrType what);

    /** Method returns information about what is requested from the DataManager. By default complete information is sent.
     *   @param what a request type. Can be one of the following values (Type container, DpIdentification, own system or null if the all request type should be checked)
     *   @return A Bit-And-ed value the specified request.
     */
    unsigned getWhatToSend(unsigned what = 0) const;

    /** Returns configuration number from the first position in the internal list of configuration numbers.
     *  @return DpConfigNrType, the helper class contains the configNr member variable. If the list is empty the DPCONFIGNR_NOCONFIGNR is returned instead.
     */
    DpConfigNrType  getFirstConfigNr(void) const;

    /** Returns all subsequent configuration numbers from the internal list of configuration numbers. One number is returned per a method call.
     *  @return DpConfigNrType, the helper class contains the configNr member variable. If the list is empty or the last number was retrieed the DPCONFIGNR_NOCONFIGNR is returned instead.
     */
    DpConfigNrType  getNextConfigNr(void) const;

    // Get / Set request time

    /** Method sets the timestamp of the datapoint initialization request.
     *   @param rt A new timestamp
     */
    void      setRequestTime(const PVSSTime &rt) {requestTime = rt;}

    /** Method returns the timestamp of the datapoint initialization request.
     *   @return PVSSTime, a timestamp
     */
    PVSSTime  getRequestTime() const             {return requestTime;}

    /** Set the request timestamps
     *  @param newTimestamps the new timestamps
     */
    void setTimestamps(const MappingVar &newTimstamps);

    /** Get the request timestamps
     * @return a pointer to the request timestamps or NULL if none were set or received
     */
    const MappingVar * getTimestamps() const;

    /** Get the timestamp for a specific system
     *  @param system the system id of the request
     *  @return the timestamp of the system of 0 if the system is not present
     */
    PVSSulonglong getTimestamp(SystemNumType system) const;

    /** Set the timestamp of a specific system
     *  @param system the system for which the timestamp to set
     *  @param timestamp the timestamp to set
     */
    void setTimestamp(SystemNumType system, PVSSulonglong timestamp);

    // Operators

   /** Equal operator. The operator compares the messages instances.
    *  
    *  @param rVal an instance of Msg to be compared to
    *  @return int 0, if instances are equal, or not 0 otherwise
    *
    */
     virtual int operator==(const Msg &rVal) const;
   
   /** Equal operator. The operator compares the start dp initialization system messages instances.
     *  
     *  @param rVal an instance of StartDpInitSysMsg to be compared to
     *  @return int 0, if instances are equal, or not 0 otherwise
     *
     */
    int operator==(const StartDpInitSysMsg &rVal) const;

    /** Assignment operator. The operator assigns the content of the specified system message instances.
     *  
     *  @param rVal an instance of Msg to assign from
     *  @return Msg, assigned Msg instance
     *
     */
    Msg &operator=(const Msg &rVal);

    /** Assignment operator. The operator assigns the content of the s start dp initialization system message instances.
     *  
     *  @param rVal an instance of StartDpInitSysMsg to assign from
     *  @return StartDpInitSysMsg, assigned initialization system message instance
     *
     */
    StartDpInitSysMsg &operator=(const StartDpInitSysMsg &rVal);

    // Spezielle Methoden :
   
    /** Method returns the type of the system message.
     *   @param  msgType a system message type 
     *   @return MsgType, a SYS_MSG_START_DPINIT type is returned for a StartDpInitSysMsg type, or NO_MSG otherwise
     */
    virtual MsgType isA(MsgType msgType) const;

    /** Method returns a system message type.
     *   @return MsgType, a SYS_MSG_START_DPINIT type is always returned
     */
    virtual MsgType isA() const;

    /** Receives from itcNdrUbReceive stream
     *   @param ist the stream, which to receive from
     */
    virtual void inNdrUb(itcNdrUbReceive &ist);

    /** Sends to itcNdrUbSend stream
     *   @param ost the stream, which to send to
     */
    virtual void outNdrUb(itcNdrUbSend &ost) const;

    /** Sends a formatted output about internal status of the instance to the specified stream.
     * (used for logging purpose)
     *  @param ofStream   output stream
     */
    virtual void outToFile(std::ostream &ofStream) const;

    /** Method creates a new StartDpInitSysMsg instance.
     *   @return Msg, a new StartDpInitSysMsg instance
     */
    virtual Msg *allocate() const;

    /** Sends a formatted output about internal status of the instance to the specified stream.
     * (used for debugging purpose)
     *  @param to   output stream
     *  @param level   debugging level
     */
    virtual void debug(std::ostream &to, int level) const;

    // Attribute
  private:
    unsigned   whatToSend;
    PtrList    configNrList;
    PVSSTime   requestTime;
    MappingVar *timestamps;

};


// Inline Funktionen
inline void StartDpInitSysMsg::addWhatToSend(unsigned what)
{
  whatToSend |= what;
}

inline void StartDpInitSysMsg::addConfigNrToSend(DpConfigNrType what)
{
  configNrList.append(new DpConfigNrItem(what));
}

inline unsigned StartDpInitSysMsg::getWhatToSend(unsigned what) const
{
  return what ? (whatToSend & what) : whatToSend;
}

inline DpConfigNrType StartDpInitSysMsg::getFirstConfigNr(void) const
{
  const DpConfigNrItem *ptr = (const DpConfigNrItem *) configNrList.getFirst();

  return ptr ? ptr->configNr : DPCONFIGNR_NOCONFIGNR;
}

inline DpConfigNrType StartDpInitSysMsg::getNextConfigNr(void) const
{
  const DpConfigNrItem *ptr = (const DpConfigNrItem *) configNrList.getNext();

  return ptr ? ptr->configNr : DPCONFIGNR_NOCONFIGNR;
}

inline int StartDpInitSysMsg::operator==(const Msg &rVal) const
{
  return (isA() == rVal.isA()) && operator==(static_cast<const StartDpInitSysMsg &>(rVal));
}

inline Msg &StartDpInitSysMsg::operator=(const Msg &rVal)
{
  if (isA() == rVal.isA())
  {
    return operator=(static_cast<const StartDpInitSysMsg &>(rVal));
  }

  return *this;
}

inline MsgType StartDpInitSysMsg::isA(MsgType msgType) const
{
  if(msgType == isA())
    return SYS_MSG_START_DPINIT;

  return SysMsg::isA(msgType);
}

inline MsgType StartDpInitSysMsg::isA() const
{
  return SYS_MSG_START_DPINIT;
}

inline Msg *StartDpInitSysMsg::allocate() const
{
  return new StartDpInitSysMsg;
}

#endif /* _STARTDPINITSYSMSG_H_ */
