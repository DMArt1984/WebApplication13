/*
VERANTWORTUNG: Stanislav Meduna
BESCHREIBUNG:
    An effective memory allocator for frequently used
    blocks of the same length.

    Usage:
        In public interface of an class
            AllocatorDecl;
        In implementation of the class
            AllocatorDef(ClassName);

    You can also instantiate the allocator directly
    with object length as the constructor parameter
    and then use alloc and dealloc methods.
*/

#ifndef _ALLOCATOR_HXX_
#define _ALLOCATOR_HXX_

#ifndef _TYPES_HXX_
#include <Types.hxx>
#endif

#ifndef _WIN32
#include <pthread.h>
#endif

#include <new>
#include <stdlib.h>

/** The PVSS-II internal memory management. Since it is very expensive to perform many
    new / delete operations on the operating system this memory management helps to decrease
    the allocation time.
    @classification ETM internal
*/
class DLLEXP_BASICS Allocator
{
  public:
    ///   Enables allocator functionality.
    ///   @param b enable/disable.
    static void  enableAllocator(bool b) {enable_ = b;}

    ///   Constructor.
    ///   @param newItemSize size of the items in the array.
    Allocator(size_t newItemSize);

    /// Destructor.
    ~Allocator();

    ///   Allocate an object.
    ///   If there is free pointer in the Allocator cache, it is returned. If not, new object is allocated from the heap.
    ///   @param objSize size of the allocated object.
    void *alloc(size_t objSize);

    ///   Releases an object.
    ///   Actually, the heap is not freed, but the object pointer is cached in the Allocator. There can be up to setMaxArraySize object pointers cached.
    ///   @param objPtr allocated object to be released.
    void dealloc(void *objPtr);

  private:
    static bool enable_;

#ifdef _WIN32
    static unsigned threadId_;
#else
    static pthread_t threadId_;
#endif

    // Size
    size_t itemSize_;
    size_t arraySize_;
    size_t nofItems_;

    void ** arrayPtr_;
};

//#ifndef _WIN32
#ifdef USE_OWN_ALLOCATOR
#define AllocatorDecl \
  static Allocator alc; \
  void *operator new(size_t sz) { return alc.alloc(sz); } \
  void operator delete(void *ptr) { alc.dealloc(ptr); } \
  void *operator new(size_t sz, void *ptr) { return ::operator new(sz, ptr); } \
  void operator delete(void *ptr1, void *ptr2) { ::operator delete(ptr1, ptr2); }

#define AllocatorDef(ClsName) \
  Allocator ClsName::alc(sizeof(ClsName))
#else
#define AllocatorDecl
#define AllocatorDef(ClsName)
#endif

#endif  // _ALLOCATOR_HXX_
