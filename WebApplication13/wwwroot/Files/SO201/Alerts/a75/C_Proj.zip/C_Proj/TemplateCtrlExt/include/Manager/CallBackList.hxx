#ifndef _CALLBACKLIST_HXX
#define _CALLBACKLIST_HXX

#include <CallBackItem.hxx>
#include <DpTypes.hxx>

#include <QMultiHash>
#include <QPair>

/** @brief Stores CallBackItems sorted according to CallBackItem::getSortKey()
 *
 * This class is used by the Manager class for storing its CallBackItems.
 * CallBackItems in the list are sorted according to their sort key.
 * @see CallBackItem::getSortKey()
 **/
class CallBackList
{
  typedef QMultiHash<DpIdType, CallBackItem *> CallBackHash;
  typedef CallBackHash::iterator CallBackIterator;

  CallBackHash hash;

  public:
    /// Construct an empty CallBackList
    CallBackList() { /* empty */ }

    /// Delete all CallBackItems contained in the CallBackList
    ~CallBackList() { clear(); }

    /// Class used for iterating over CallBackItems in a CallBackList
    class Iterator
    {
      friend class CallBackList;

      Iterator(CallBackIterator const & cbIt) : m_cbIt(cbIt) { /* empty */ }

      CallBackIterator m_cbIt;

      public:
        /** Increment the Iterator and returns a reference to itself.
         *
         * @return an Iterator pointing to the next CallBackItem
         *         end() if there is no further CallBackItem
         **/
        Iterator & operator ++()
        {
          ++m_cbIt;

          return *this;
        }

        /** Decrement the Iterator and returns a reference to itself.
         *
         * @return an Iterator pointing to the previous CallBackItem
         *         Calling this function on CallBackList::begin() leads to undefined results.
         **/
        Iterator & operator --()
        {
          --m_cbIt;

          return *this;
        }

        /** Compare an Iterator with another and check for equality.
         *
         * @return true of both Iterators point to the same CallBackItem
         *         false otherwise
         **/
        bool operator ==(Iterator const & rhs) const
        {
          return rhs.m_cbIt == m_cbIt;
        }

        /** Compare an Iterator with another and check for inequality.
         *
         * @return true of both Iterators point to different CallBackItems
         *         false otherwise
         **/
        bool operator !=(Iterator const & rhs) const
        {
          return !(*this == rhs);
        }

        /** Access the CallBackItem pointed to by the Iterator.
         *
         * @return A pointer to a CallBackItem if the Iterator is valid
         *         0 otherwise
         **/
        CallBackItem * data()
        {
          return m_cbIt.value();
        }
    };

    /** @typedef A pair of Iterators representing a range.
     *
     * Range.first is the first item in the range.
     * Range.second is the first item after the range.
     **/
    typedef QPair<Iterator, Iterator> Range;

    /// Return an Iterator to the first CallBackItem in the CallBackList.
    Iterator begin() { return Iterator(hash.begin()); };

    /// Return an Iterator to (invalid) position after the last CallBackItem in the CallBackList.
    Iterator end() { return Iterator(hash.end()); }

    /** Find the range of CallBackItems matching a specific sort key.
     *
     * @param key DpIdType the CallBackItems are sorted by.
     * @return A range pointing to all matching CallBackItems.
     *         Range.first is end() if no matching CallBackItems are found.
     **/
    Range find(DpIdType const & key)
    {
      // find the first item
      CallBackIterator const lowerBound = hash.find(key);
      if ( hash.end() == lowerBound )
        return Range(end(), end());

      // for upper bound iterate further until we're at end() or the key changes
      CallBackIterator upperBound = lowerBound;
      while ( key == upperBound.key() && hash.end() != upperBound )
        ++upperBound;

      return Range(Iterator(lowerBound), Iterator(upperBound));
    }

    /** Find one CallBackItem matching a specific sort key.
     *
     * @param key DpIdType the CallBackItems are sorted by.
     * @return An Iterator to the first matching CallBackItem.
     *         end() if no matching CallBackItem is found.
     **/
    Iterator findOne(DpIdType const & key)
    {
      return Iterator(hash.find(key));
    }

    /** Insert a new CallBackItem into the list.
     *
     * @param value The new CallBackItem added to the list.
     *              Make sure its sort key is corrected.
     *              The CallBackItem is captured by the CallBackList.
     * @return An Iterator to the newly inserted item.
     *         end() if the CallBackItem could not be inserted.
     **/
    Iterator insert(CallBackItem * const & value)
    {
      if ( !value )
        return end();

      DpIdType const key = value->getSortKey();
      return Iterator(hash.insert(key, value));
    }

    /** Remove a CallBackItem from the CallBackList.
     *
     * @param iter An Iterator pointing to the CallBackItem.
     *             The Iterator is modified so it points to the next valid CallBackItem.
     * @return The CallBackitem pointed to by the Iterator.
     **/
    CallBackItem * cut(Iterator & iter)
    {
      CallBackIterator const & cbIt = iter.m_cbIt;
      if ( hash.end() == cbIt )
        return 0;

      CallBackItem * cutItem = cbIt.value();
      iter = Iterator(hash.erase(cbIt));

      return cutItem;
    }

    /** Remove and delete a CallBackItem from the CallBackList.
     *
     * @see CallBackItem::cut()
     **/
    void erase(Iterator & iter) { delete cut(iter); }

    /// Remove and delete all CallBackItems from the CallBackList.
    void clear()
    {
      qDeleteAll(hash);
      hash.clear();
    }

    /// Retrieve the number of CallBackItems stored in the CallBackList.
    size_t size() const { return size_t(hash.size()); }
};

#endif /* _CALLBACKLIST_HXX */
