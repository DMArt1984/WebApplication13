// DATEIBESCHREIBUNG ==============================================================
// DATEINAME:     DpInvertConv.hxx
// VERANTWORTUNG:	Stanislav Meduna
// 
// BESCHREIBUNG:	Invertierung des Binaerwertes.
//
// AENDERUNGS-HISTORIE
// Ver.  | Datum      | Aenderungen                            | ModNr.| Autor
// ------+------------+-----------------Anfang-----------------+-------+-----------
//   1.0 |            | 1.Erstellung mit Westmount-OMT         |     0 |
//   1.1 | 09.09.2010 | Adding doxygen comments                |       | psedik
// ======================================Ende======================================

#ifndef _DPINVERTCONV_H_
#define _DPINVERTCONV_H_

// forward declarations and includes
class DpInvertConv;

#include <DpConversion.hxx>

class DpConvSmooth;
class DpInvertConv;
class Variable;
class BitVec;

// ========== DpInvertConv ========================================================
/// Conversion class used for converting the value by inverting all bits. The class
/// supports Variables of type BitVar and Bit32Var.
class DLLEXP_CONFIGS DpInvertConv : public DpConversion 
{
public:

  /// Constructor
  DpInvertConv();

  /// Destructor
  ~DpInvertConv();

  /// Outputs the instance to the itcNdrUbSend stream
  /// @param ndrStream Output stream
  /// @param unused Streamed DpInvertConv instance
  /// @return itcNdrUbSend stream
  friend DLLEXP_CONFIGS itcNdrUbSend &operator<<(itcNdrUbSend &ndrStream, const DpInvertConv &unused);

  /// Receives the instance from the itcNdrUbReceive stream
  /// @param ndrStream Input stream
  /// @param unused DpCounterConv instance receiving the value from the stream
  /// @return itcNdrUbReceive stream
  friend DLLEXP_CONFIGS itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream, DpInvertConv &unused);
  
  /// Assignment operator
  /// @param aConv assigned value
  /// @return DpConvSmooth reference with the assigned value 
  virtual DpConvSmooth &operator=(const DpConvSmooth &aConv);

  /// Returns conversion type of this class
  /// @return DpConvInvert
  virtual DpConversionType convType() const;

  /// Convert method. Does the binary invert of the input Variable
  /// @param inpVar Input Variable, which can be of type BitVar or Bit32Var
  /// @param outVarPtr Pointer to the newly allocated output Variable. If inpVar
  /// is BitVar, the value will be inverted, in case of Bit32Var (encapsulating
  /// 32-bit integer), all bits will be inverted.
  /// @param unused BitVec value, not used in the code
  /// @return 
  /// - DpConversionOK if the call was successfull
  /// - DpConversionError if it was not possible to allocate the new outVarPtr
  /// - DpConversionBadType if inpVar is not of type BitVar or Bit32Var
  virtual DpConversionResultType convert(const Variable &inpVar, Variable * & outVarPtr, const BitVec &unused);
  
  /// Allocates the new DpInvertConv instance with default constructor.
  /// @return DpConvSmooth pointer to a newly allocated instance.    
  virtual DpConvSmooth *allocate() const;

  /// Set the attribute (current implementation does nothing).
  /// @param attrNr Attribute number (not used)
  /// @param var Variable to be set (not used)
  /// @return PVSS_FALSE
  virtual PVSSboolean setAttribut(DpAttributeNrType attrNr, const Variable &var);

  /// Gets the attribute.
  /// @param attrNr Attribute number, supported value is DpConfig::TYPE_ATTR
  /// @return DpConvDateTime from DpConfig::TYPE_ATTR attribute, 0 otherwise 
  virtual Variable *getAttribut(DpAttributeNrType attrNr) const;

protected:
private:
};

// ================================================================================
// Inline methods :

#endif /* _DPINVERTCONV_H_ */
