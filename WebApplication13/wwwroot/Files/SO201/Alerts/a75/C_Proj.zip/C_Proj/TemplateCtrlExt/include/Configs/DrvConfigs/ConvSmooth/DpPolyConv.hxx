// DATEIBESCHREIBUNG ==============================================================
// DATEINAME:     DpPolyConv.hxx
// VERANTWORTUNG:	Stanislav Meduna
// 
// BESCHREIBUNG:	Polynomiale Umrechnung.
//
// AENDERUNGS-HISTORIE
// Ver.  | Datum      | Aenderungen                            | ModNr.| Autor
// ------+------------+-----------------Anfang-----------------+-------+-----------
//   1.0 |            | 1.Erstellung mit Westmount-OMT         |     0 |
// ======================================Ende======================================
#ifndef _DPPOLYCONV_H_
#define _DPPOLYCONV_H_

// Vorwaerts-Deklaration der Eigenen Klasse
class DpPolyConv;

// System-Include-Files
#include <DpConversion.hxx>
#include <FloatVar.hxx>
#include <IntegerVar.hxx>

// Makimale Anzahl der Koeffiziente
#define	MAX_POLY_GRADE	4

// Vorwaerts-Deklarationen :
class DpConvSmooth;
class DpPolyConv;
class Variable;

class BitVec;

// ========== DpPolyConv ============================================================
/** Polynomial conversion class. Defines a polynom of max. 4th grade and performs evaluations.
*/
class DLLEXP_CONFIGS DpPolyConv : public DpConversion 
{

  // Klassen-Enums:

// ..........................Anfang User-Klasseninterne-Definitionen..................
// ...........................Ende User-Klasseninterne-Definitionen...................
public:
  /// constructor
  DpPolyConv();
  /// Destructor
  ~DpPolyConv();


  // Operatoren :
  /**streaming send operator
    @param ndrStream itcNdrUbSend stream
    @param aConv DpPolyConv conversion object
    @return ndr stream
    */
  friend DLLEXP_CONFIGS itcNdrUbSend &operator<<(itcNdrUbSend &ndrStream, const DpPolyConv &aConv);
  /**streaming receive operator
    @param ndrStream itcNdrUbSend stream
    @param aConv DpPolyConv conversion object
    @return ndr stream
    */
  friend DLLEXP_CONFIGS itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream, DpPolyConv &aConv);
  /**assignment operator
    @param aConv DpConvSmooth conversion object
    @return DpConvSmooth object
    */
  virtual DpConvSmooth &operator=(const DpConvSmooth &aConv);

  // Spezielle Methoden :
  ///returns DpConvPoly conversion type
  virtual DpConversionType convType() const;
  /**An input variable is used to calculate a new floatvar using the defined polynom and the outVarPtr pointer is set to the floatvar. The caller is responsible for deletion. In case of an invalid variable a nullpointer is returned.
    @param inpVar input variable
    @param outVarPtr [out] points to the output, null if input variable was invalid
    @param unused BitVec value, not used in the code
    @return DpConversionResultType error code
    */
  virtual DpConversionResultType convert(const Variable &inpVar, Variable * & outVarPtr, const BitVec &unused);
  ///allocates instance of DpConvSmooth
  virtual DpConvSmooth *allocate() const;
  /**set attribute
    @param attrNr DpAttributeNrType attribute number
    @param var Variable& value
    @return PVSSboolean, PVSS_TRUE if successful, else PVSS_FALSE
    */
  virtual PVSSboolean setAttribut(DpAttributeNrType attrNr, const Variable &var);
  /**get attribute
    @param attrNr DpAttributeNrType attribute number
    @return Variable* attribute value
    */
  virtual Variable *getAttribut(DpAttributeNrType attrNr) const;
  ///informs about consistency
  virtual PVSSboolean isConsistent() const;
  /**debug output, prints out formatted values of all attributes
    @param to std::ostream to stream
    @param level int debug level
  */
  virtual void debug(std::ostream &to, int level) const;

  // Generierte Methoden :
  ///returns polynom grade(const)
  const IntegerVar &getAttrPolyGrade() const;
  ///returns polynom grade
  IntegerVar &getAttrPolyGrade();
  ///sets polynom grade
  void setAttrPolyGrade(const IntegerVar &newAttrPolyGrade);
  /**returns coefficient of polynome(const)
    @param idx integer id of coef
    @return value of the coefficient attribute
    */
  const FloatVar &getAttrCoef(int idx) const;
  /**returns required coefficient of polynome
    @param idx integer id of coef
    @return required coefficient
    */
  FloatVar &getAttrCoef(int idx);
  /**sets coefficient of polynome
    @param idx integer id of coef
    @param newAttrCoef new coefficient value
    @return required coefficient
    */
  void setAttrCoef(int idx,const FloatVar &newAttrCoef);
  ///returns count of coefficients
  int lengthAttrCoef();
protected:
private:
  IntegerVar attrPolyGrade;
  FloatVar attrCoef[MAX_POLY_GRADE+1];

// ............................Anfang User-Attribut-Definitionen...................
// .............................Ende User-Attribut-Definitionen....................
  friend class UNIT_TEST_FRIEND_CLASS;
};

// ================================================================================
// Inline-Funktionen :
inline const IntegerVar &DpPolyConv::getAttrPolyGrade() const
{
  return attrPolyGrade;
}

inline IntegerVar &DpPolyConv::getAttrPolyGrade()
{
  return attrPolyGrade;
}
inline void DpPolyConv::setAttrPolyGrade(const IntegerVar &newAttrPolyGrade)
{
  attrPolyGrade = (IntegerVar &) newAttrPolyGrade;
}
inline const FloatVar &DpPolyConv::getAttrCoef(int idx) const
{
  return attrCoef[idx];
}

inline FloatVar &DpPolyConv::getAttrCoef(int idx)
{
  return attrCoef[idx];
}
inline void DpPolyConv::setAttrCoef(int idx,const FloatVar &newAttrCoef)
{
  attrCoef[idx] = (FloatVar &) newAttrCoef;
}
inline int DpPolyConv::lengthAttrCoef()
{
  return MAX_POLY_GRADE+1;
}

// ............................Anfang User-Inlines.................................
// .............................Ende User-Inlines..................................

#endif /* _DPPOLYCONV_H_ */
