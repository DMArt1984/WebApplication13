//---------------------------------------------------------------------------- 
//  Copyright (C) Siemens AG 2013. All Rights Reserved. Confidential.
//----------------------------------------------------------------------------
//  Descr.: handle out of memory situation when allocating memory
//  new handler code moved from Basics/OaNoPosix/OaNoPosix.hxx
//----------------------------------------------------------------------------

#ifndef _NEWHANDLER_H_
#define _NEWHANDLER_H_

#include <new>
#include <cstddef>

#ifdef _WIN32
#  include <new.h>
#endif

/** the new handler class that handles out-of-memory situations when memory is allocated with
 *  operator new and NewHandler::reallocHandled. If the allocation fails the process is terminated
*/
class DLLEXP_BASICS NewHandler
{
  public:
    friend class UNIT_TEST_FRIEND_CLASS;

#ifdef _WIN32
    /// newHandler for WIN32
    static int newHandler(size_t size);
#else
    /// newHandler for other OS than WIN32
    static void newHandler();
#endif

    /**
     * Reallocates memory block by calling realloc() and calls new handler if reallocation
     * failed. The new handler takes care about handling reallocation failure, either
     * by freeing enough memory and this function call will return a pointer to the reallocated
     * memory block, or by terminating the process.
     * @param pointer to a memory block previously allocated with malloc, calloc, realloc,
     *        NewHandler::reallocHandled, or a null pointer (to allocate a new block)
     * @param size new size for the memory block, in bytes
     * @return a pointer to the reallocated memory block
     */
    static void * reallocHandled(void * ptr, size_t size);

  private:
#ifdef _WIN32
    static _PNH newHandlerSet;
#else
    static std::new_handler newHandlerSet;
#endif

    // special for UnitTest
    friend class AllocatorTest;
    // toolclass for internal tests needs to set _exitOnNoMem
    friend class Pufferfish;
    // Must be true, except for test. Details see implementation of newHandler.
    static bool _exitOnNoMem;
};

#endif // _NEWHANDLER_H_

//---------------------------------------------------------------------------- 
//  Copyright (C) Siemens AG 2013. All Rights Reserved. Confidential.
//----------------------------------------------------------------------------

