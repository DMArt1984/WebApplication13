#ifndef _POLLADDRITEM_H_
#define _POLLADDRITEM_H_

#ifndef _HWMAPPADP_H_
#include <HWMapDpPa.hxx>
#endif

#ifndef _TIMEVAR_H_
#include <TimeVar.hxx>
#endif


/** This class represents an entry in the PollGroup list.
  * It consists mainly of a HWMapDpPa object including some additional informations.
  * @classification ETM internal
  */
class PollAddrItem
{
  public:
    
    /** Constructor
      * @param rPtr pointer to HWMapDpPa instance
    * @param inactive active/inactive
    */
    PollAddrItem(HWMapDpPa *rPtr,  const bool inactive);

    /** Gets reference pointer to HWMapDpPa
      * @return reference pointer to HWMapDpPa
      */
    HWMapDpPa* getRefPtr() const  { return refPtr_; };

    /** Indicates if the poll address item is valid
      * @return a value of valid_, valid flag, if true, address item is valid
    */
    PVSSboolean isValid() {return valid_;}

    /** Sets a valid flag of the poll address item
      * @param state value of param valid_(a valid flag) to be set
    */
    void        setValid(PVSSboolean state) {valid_ = state;}

  /** Compare function
    * @param adr2 pointer to PollAddrItem
    * @return result of comparison
    */
    int compare ( const PollAddrItem *adr2) const;

  /** Gets a inactive flag 
      * @return a bolean value of flag inactive
    */
    bool isInactive () const {return inactive_;}

  /** Set the subscription count
    * @param count the new value
    * @return true if the pollgroup should be triggered at once
    */
    bool setSubscriptionCount(PVSSlong count, const TimeVar &nextPoll);
    
  /** Get the subscription count
    * @return the count value
    */
    PVSSlong getSubscriptionCount() const { return (subscriptionCount_ < 0) ? (subscriptionCount_ * -1) : subscriptionCount_; }

  /** Check if the item should be polled
   * @return true if we should poll
   */
    bool shouldPoll();

  /** Set the uncertain status bit
    */
    void updateUncertainState(int newCount, const TimeVar &nextPoll);

  private:
    HWMapDpPa* refPtr_;
    PVSSboolean valid_;
    bool inactive_;
    bool uncertain_;
    bool skipPollCycle_;
    PVSSlong subscriptionCount_;

    friend class UNIT_TEST_FRIEND_CLASS;
};


#endif
