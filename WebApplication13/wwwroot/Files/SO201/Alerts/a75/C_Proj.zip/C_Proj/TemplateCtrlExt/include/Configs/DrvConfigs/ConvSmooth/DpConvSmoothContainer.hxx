#ifndef _DPCONVSMOOTHCONTAINER_H_
#define _DPCONVSMOOTHCONTAINER_H_

// Vorwaerts-Deklaration der Eigenen Klasse
class DpConvSmoothContainer;

// System-Include-Files
#include <DpConfig.hxx>
#include <DpConvSmooth.hxx>
#include <DynPtrArray.hxx>

// Vorwaerts-Deklarationen :
class DpConvSmooth;
class DpConvSmoothContainer;
class IntegerVar;
class TimeVar;
class Variable;
class BitVec;
class itcIOHandler;

typedef DpConfig * (*GetConfigFuncPtrType)(SystemNumType, DpIdType, DpElementId, DpConfigNrType);
typedef itcIOHandler * (*AllocFlutterHdlFuncPtrType)(SystemNumType, DpIdType, DpElementId, DynPtrArrayIndex, const TimeVar &);
typedef void (*StartTimerFuncPtrType)(long, long, itcIOHandler *);
typedef void (*StopTimerFuncPtrType)(itcIOHandler *);
typedef void (*GetTimeFuncPtrType)(TimeVar &);

// ========== DpConvSmoothContainer ============================================================

/// The container containing sorted lists of calculations (in both directions) and smoothing
/// (only in direction Raw -> Ing).
///
/// When a Manager does not only store the Configs but also uses convert functions (rawToIng() and ingToRaw()
/// called from this class), it must set an association to its own data using initStatics(). This is because
/// the conversion uses sometimes timers and also needs access to DpConfig.
/// Function sets:
///    - a pointer to a function, which a DpConfig finds und returns
///    - a pointer to a function, which a DpFlutterHandler allocates (normally DpFlutterHdl::allocate())
///    - a pointer to a start- und stopTimer
class DLLEXP_CONFIGS DpConvSmoothContainer : public DpConfig 
{
public:
  friend class UNIT_TEST_FRIEND_CLASS;

  // Klassen-Enums:

  /// the number of details
  static const DpAttributeNrType NUMBER_OF_DETAILS_ATTR;
  /// the list of subconversions
  static const DpAttributeNrType LIST_OF_SUBCONVERSIONS_ATTR;
  /// the polynom grade
  static const DpAttributeNrType POLYNOM_GRADE_ATTR;
  /// the polynom coef 0
  static const DpAttributeNrType POLYNOM_COEF0_ATTR;
  /// the polynom coef 1
  static const DpAttributeNrType POLYNOM_COEF1_ATTR;
  /// the polynom coef 2
  static const DpAttributeNrType POLYNOM_COEF2_ATTR;
  /// the polynom coef 3
  static const DpAttributeNrType POLYNOM_COEF3_ATTR;
  /// the polynom coef 4
  static const DpAttributeNrType POLYNOM_COEF4_ATTR;
  /// the linear interpretation number of points
  static const DpAttributeNrType LIN_INTERP_NO_OF_POINTS_ATTR;
  /// the linear interpretation point 0 - X
  static const DpAttributeNrType LIN_INTERP_POINT0_X_ATTR;
  /// the linear interpretation point 0 - Y
  static const DpAttributeNrType LIN_INTERP_POINT0_Y_ATTR;
  /// the linear interpretation point 1 - X
  static const DpAttributeNrType LIN_INTERP_POINT1_X_ATTR;
  /// the linear interpretation point 1 - Y
  static const DpAttributeNrType LIN_INTERP_POINT1_Y_ATTR;
  /// the linear interpretation point 2 - X
  static const DpAttributeNrType LIN_INTERP_POINT2_X_ATTR;
  /// the linear interpretation point 2 - Y
  static const DpAttributeNrType LIN_INTERP_POINT2_Y_ATTR;
  /// the linear interpretation point 3 - X
  static const DpAttributeNrType LIN_INTERP_POINT3_X_ATTR;
  /// the linear interpretation point 3 - Y
  static const DpAttributeNrType LIN_INTERP_POINT3_Y_ATTR;
  /// the linear interpretation point 4 - X
  static const DpAttributeNrType LIN_INTERP_POINT4_X_ATTR;
  /// the linear interpretation point 4 - Y
  static const DpAttributeNrType LIN_INTERP_POINT4_Y_ATTR;
  /// the null support low
  static const DpAttributeNrType NULL_SUPP_LOW_ATTR;
  /// the null support high
  static const DpAttributeNrType NULL_SUPP_HIGH_ATTR;
  /// the null support value
  static const DpAttributeNrType NULL_SUPP_VALUE_ATTR;
  /// the log base
  static const DpAttributeNrType LOG_BASE_ATTR;
  /// the precision
  static const DpAttributeNrType PRECISION_PREC_ATTR;
  /// the inverse precision
  static const DpAttributeNrType PRECISION_INVERSE_ATTR;
  /// the trigger limit
  static const DpAttributeNrType TRIGGER_LIMIT_ATTR;
  /// the trigger invert
  static const DpAttributeNrType TRIGGER_INVERT_ATTR;
  /// the counter what to count
  static const DpAttributeNrType COUNTER_WHAT_TO_COUNT_ATTR;
  /// the counter reset
  static const DpAttributeNrType COUNTER_RESET_AT_ATTR;
  /// the simple smooth type
  static const DpAttributeNrType SIMPLE_SMOOTH_TYPE_ATTR;
  /// the simple smooth tolerance
  static const DpAttributeNrType SIMPLE_SMOOTH_TOLER_ATTR;
  /// the simple smooth time
  static const DpAttributeNrType SIMPLE_SMOOTH_TIME_ATTR;
  /// the derived smooth tolerance 1
  static const DpAttributeNrType DERIV_SMOOTH_TOLER1_ATTR;
  /// the derived smooth tolerance 2
  static const DpAttributeNrType DERIV_SMOOTH_TOLER2_ATTR;
  /// the derived smooth limit
  static const DpAttributeNrType DERIV_SMOOTH_LIMIT_ATTR;
  /// the derived smooth time
  static const DpAttributeNrType DERIV_SMOOTH_TIME_ATTR;
  /// the flutter smooth time
  static const DpAttributeNrType FLUTTER_SMOOTH_TIME_ATTR;
  /// the flutter smooth old new
  static const DpAttributeNrType FLUTTER_SMOOTH_OLDNEW_ATTR;

  /// constructor, initialisation with zero values
  DpConvSmoothContainer();

  /// destructor
  virtual ~DpConvSmoothContainer();

  /** operator << for itcNdrUbSend stream
      @param ndrStream the stream, which to send to
      @param aCont the DpConvSmoothContainer
    */
  friend DLLEXP_CONFIGS itcNdrUbSend &operator<<(itcNdrUbSend &ndrStream, const DpConvSmoothContainer &aCont);

  /** operator >> for itcNdrUbReceive stream
      @param ndrStream the stream, which to receive from
      @param aCont the DpConvSmoothContainer
    */
  friend DLLEXP_CONFIGS itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream, DpConvSmoothContainer &aCont);

  /** assignment operator used for type conversion
      @param aConv the DpConfig to convert
      @return the resulting DpConfig
    */
  virtual DpConfig &operator=(const DpConfig &aConv);

  /** non virtual assignment operator for DpConvSmoothContainer
      @param rVal the DpConvSmoothContainer to assign
      @return the resulting DpConvSmoothContainer
    */
  DpConvSmoothContainer &operator=(const DpConvSmoothContainer &rVal)
    { operator=((const DpConfig &) rVal); return *this; }

  /** comparison operator ==
      @param rval the DpConfig to compare with
      @return 0 if not equal else 1
    */
  virtual int operator==(const DpConfig &rval) const;

  /// insert a conversion
  /// @param aConversion the conversion
  /// @return PVSS_TRUE if OK else PVSS_FALSE
  PVSSboolean insert(const DpConvSmooth &aConversion);

  /// allocate and insert a conversion
  /// @param aType the type
  /// @param aDetailNr the number of detail
  /// @param atPosition the position
  /// @return PVSS_TRUE if OK else PVSS_FALSE
  PVSSboolean allocAndInsert(const DpConversionType &aType, DpDetailNrType &aDetailNr, DpDetailNrType atPosition = 0);

  /// remove a conversion
  /// @param aDetailNr the number of detail
  /// @return PVSS_TRUE if OK else PVSS_FALSE
  PVSSboolean remove(DpDetailNrType aDetailNr = 0);

  /// change type of a conversion
  /// @param atPosition the position
  /// @param newType the new type
  /// @return PVSS_TRUE if OK else PVSS_FALSE
  PVSSboolean changeType(DpDetailNrType atPosition, DpConversionType newType);
  
  /// conversion ing to raw
  /// @param inpVar the input Variable
  /// @param outVarPtr the output Variable
  /// @return the result type
  DpConversionResultType ingToRaw(const Variable &inpVar, Variable * & outVarPtr) const;

  /// conversion raw to ing
  /// @param inpVar the input Variable
  /// @param outVarPtr the output Variable
  /// @param ubits the u bits
  /// @return the result type
  DpConversionResultType rawToIng(const Variable &inpVar, Variable * & outVarPtr, const BitVec &ubits) const;

  /// conversion raw to ing
  /// @param inpVar the input Variable
  /// @param outVarPtr the output Variable
  /// @param timeVar the time
  /// @param timeFromPeriph the time from periph flag
  /// @param ubits the u bits
  /// @return the result type
  DpConversionResultType rawToIng(const Variable &inpVar, Variable * & outVarPtr, const TimeVar &timeVar, PVSSboolean timeFromPeriph, const BitVec &ubits) const;

  /// conversion raw to ing
  /// @param inpVar the input Variable
  /// @param outVarPtr the output Variable
  /// @param timeVar the time
  /// @param timeFromPeriph the time from periph flag
  /// @param ubits the u bits
  /// @param sysNum the system number
  /// @param dpId the dpId
  /// @param elNo the element number
  /// @param startIndex the start index
  /// @return the result type
  DpConversionResultType rawToIng(const Variable &inpVar, Variable * & outVarPtr, const TimeVar &timeVar, PVSSboolean timeFromPeriph, const BitVec &ubits,
                                  SystemNumType sysNum, DpIdType dpId, DpElementId elNo, DynPtrArrayIndex startIndex) const;

  /// reset the last value in the smoothing config
  /// @return the result type
  DpConversionResultType resetLastValue() const;
                      
  /// set the GetConfigFuncPtrType
  /// @param ptr the ptr to set
  static void setGetConfigFncPtr(GetConfigFuncPtrType ptr);

  /// get the GetConfigFuncPtrType
  static GetConfigFuncPtrType getGetConfigFncPtr();
  
  /// set attribut
  /// @param detailNr the number of detail
  /// @param attrNr the number of attribut
  /// @param var the Variable to set
  /// @return PVSS_TRUE if OK else PVSS_FALSE
  virtual PVSSboolean setAttribut(DpDetailNrType detailNr, DpAttributeNrType attrNr, const Variable &var);

  /// get attribut
  /// @param detailNr the number of detail
  /// @param attrNr the number of attribut
  /// @return the attribut
  virtual Variable *getAttribut(DpDetailNrType detailNr, DpAttributeNrType attrNr) const;
  
  /// check if the config settings are consistent
  virtual PVSSboolean isConsistent() const;
  
  /// allocate new DpConvSmoothContainer
  /// @param configNr the config type
  /// @param typeAttr the type of attribute
  /// @return the new DpConvSmoothContainer
  static DpConvSmoothContainer *allocate(DpConfigNrType configNr, const IntegerVar &typeAttr);
  
  /// send to itcNdrUbSend stream
  /// @param ndrStream the stream, which to send to
  virtual void outNdrUb(itcNdrUbSend &ndrStream) const;

  /// receive from itcNdrUbReceive stream
  /// @param ndrStream the stream, which to receive from
  virtual void inNdrUb(itcNdrUbReceive &ndrStream);
  
  /// send debug info to output stream
  /// @param to the output stream
  /// @param level the debug level
  virtual void debug(std::ostream &to, int level) const;

  /// get the master element ID 
  DpElementId getMasterElId() const;

  /// set the master element ID 
  /// @param newMasterElId the value to set
  void setMasterElId(DpElementId newMasterElId);
  
  // const ConvSmoothPtrTypeList & getDpConvSmoothPtrTypeList() const;
  // ConvSmoothPtrTypeList& getDpConvSmoothPtrTypeColl();
  // void setDpConvSmoothPtrTypeColl(CollDpConvSmoothPtrType &newdpConvSmoothPtrTypeColl);
  
  /// get number of items
  DynPtrArrayIndex length() const {return convSmoothList.getNumberOfItems();}

  /// clear
  void clear();
  
  /// get convertor
  /// @param at the index
  DpConvSmooth * getConvPtr(DynPtrArrayIndex at) const;
  // DpConvSmooth & getConvPtr(DynPtrArrayIndex at);
  
  /// insert a convertor
  /// @param newConvPtr the convertor to insert
  /// @classification internal
  void insertConvPtr(const DpConvSmooth *newConvPtr);

  /// insert a convertor
  /// @param newConvPtr the convertor to insert
  void insertConvPtr(const DpConvSmooth &newConvPtr);
  
  /// remove a convertor
  /// @param item the convertor to remove
  /// @classification internal
  void removeConvPtr(const DpConvSmooth *item);

  /// remove a convertor
  /// @param at the index
  void removeConvPtr(const DynPtrArrayIndex &at);
  
  /// initialisation
  /// @param newGetConfigPtr the new GetConfigFuncPtrType
  /// @param newAllocPtr the new AllocFlutterHdlFuncPtrType
  /// @param newStartPtr the new StartTimerFuncPtrType
  /// @param newStopPtr the new StopTimerFuncPtrType
  /// @param newGetTimePtr the new GetTimeFuncPtrType
  void initStatics(GetConfigFuncPtrType newGetConfigPtr, AllocFlutterHdlFuncPtrType newAllocPtr, 
                   StartTimerFuncPtrType newStartPtr, StopTimerFuncPtrType newStopPtr, 
                   GetTimeFuncPtrType newGetTimePtr);

  /// GetConfigFuncPtrType
  static GetConfigFuncPtrType getConfigFncPtr;

  /// AllocFlutterHdlFuncPtrType
  static AllocFlutterHdlFuncPtrType allocFlutterHdlFncPtr;

  /// StartTimerFuncPtrType
  static StartTimerFuncPtrType startTimerFncPtr;

  /// StopTimerFuncPtrType
  static StopTimerFuncPtrType stopTimerFncPtr;

  /// GetTimeFuncPtrType
  static GetTimeFuncPtrType getTimeFncPtr;

private:
  DpElementId masterElId;
  DynPtrArray<DpConvSmooth> convSmoothList;
};


// ================================================================================
// Inline-Funktionen :
inline DpElementId DpConvSmoothContainer::getMasterElId() const
{
  return masterElId;
}


inline void DpConvSmoothContainer::setMasterElId(DpElementId newMasterElId)
{
  masterElId = newMasterElId;
}


inline void DpConvSmoothContainer::initStatics(GetConfigFuncPtrType newGetConfigPtr, 
                                               AllocFlutterHdlFuncPtrType newAllocPtr, 
                                               StartTimerFuncPtrType newStartPtr, 
                                               StopTimerFuncPtrType newStopPtr, 
                                               GetTimeFuncPtrType newGetTimePtr)
{
	getConfigFncPtr = newGetConfigPtr;
	allocFlutterHdlFncPtr = newAllocPtr;
	startTimerFncPtr = newStartPtr;
	stopTimerFncPtr = newStopPtr;
	getTimeFncPtr = newGetTimePtr;
}


inline  void  DpConvSmoothContainer::insertConvPtr(const DpConvSmooth *newConvPtr)
{
  convSmoothList.append(newConvPtr);
}


inline  void DpConvSmoothContainer::insertConvPtr(const DpConvSmooth &newConv)
{
  DpConvSmooth *item = newConv.allocate();
  *item = newConv;
    
  convSmoothList.append(item);
}


inline  void DpConvSmoothContainer::removeConvPtr(const DpConvSmooth *item)
{
  DynPtrArrayIndex  idx;
  
  if ( (idx = convSmoothList.findPtr(item)) != DYNPTRARRAY_INVALID)
    convSmoothList.remove(idx);
}


inline  void DpConvSmoothContainer::removeConvPtr(const DynPtrArrayIndex &at)
{
  convSmoothList.remove(at);
}


inline  DpConvSmooth * DpConvSmoothContainer::getConvPtr(DynPtrArrayIndex at) const
{
  return(convSmoothList[at]);
}


#endif /* _DPCONVSMOOTHCONTAINER_H_ */
