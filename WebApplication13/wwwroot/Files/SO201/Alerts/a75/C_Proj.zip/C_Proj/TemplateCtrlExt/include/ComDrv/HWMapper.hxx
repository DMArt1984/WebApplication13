// DATEIBESCHREIBUNG ==============================================================
// DATEINAME:  HWMapper.hxx
//        Service-Modul fuer Mapping von Hardware-Adressen auf 
//              Datenpunkte.
//

#ifndef _HWMAPPER_H_
#define _HWMAPPER_H_

#include <algorithm>

#ifndef _HWMAPPADP_H_
#include <HWMapDpPa.hxx>
#endif

#ifndef _HWOBJECT_H_
#include <HWObject.hxx>
#endif

#ifndef _DPPERIPHADDR_H_
#include <PeriphAddr.hxx>
#endif

#ifndef _DPIDENTIFIER_H_
#include <DpIdentifier.hxx>
#endif

#include <AbstractHWMapper.hxx>


#define HWMAPBLOCKSIZE    4096

/** This class holds the connection between datapoints, configs and HWObjects.
  * The config represents the internal parametrisation whereas the HWObject represents the
  * connected hardware and available data. The purpose of this mapper is to combine the
  * incoming / outgoing data with the corresponding data objects (i.e. variables or HWObjects).
  *
  * <p> this class serves as base class for derived drivers. By overloading certain member functions, 
  * you enable the mapper to do his job, namely map HWObjects and PeriphAddr strings.
  * 
  * @classification public use, overload    
  */
class HWMapper : public AbstractHWMapper
{
friend class UNIT_TEST_FRIEND_CLASS;

 public:
  /** Constructor
    */
  HWMapper();
  
  /** Destructor
    */
  virtual ~HWMapper();

  /** Add new DpIdentifier with config. This is a sorted insert algorithm.
    * @param dpId the new dpIdentifier
    * @param confPtr the new config entry; this object is not captured by the list
    * @return PVSS_TRUE on success
    * @classification ETM internal
    */
  virtual  PVSSboolean  addDpPa(DpIdentifier& dpId, PeriphAddr *confPtr);
  
  /** Add new HWObject in a sorted manner.
    * @param objPtr an object derived from HWObject with all needed HW information;
  *        this object is captured by the list
    * @return PVSS_TRUE on success
    * @classification public use, overload
    */
  PVSSboolean          addHWObject(HWObject *objPtr);
  
  /** Remove a HWMapDpPa entry from the list.
    * @param dpId the dpIdentifier to search for
    * @param confPtr the config to search for
    * @return PVSS_TRUE if found and deleted, else PVSS_FALSE
    * @classification ETM internal
    */
  virtual  PVSSboolean  clrDpPa(DpIdentifier& dpId, PeriphAddr *confPtr);
  
  /** Find a HWObject and remove it from the list. 
    * The HWObject is not deleted since there is the possibility of external
  * reference to this object. the caller of this function is responsible 
  * for deleting the removed object.
    * @param objPtr the object which to search for - PeriphAddr and HW addr are compared
    * @return PVSS_TRUE if the object is found, otherwise PVSS_FALSE
    * @classification ETM internal
    */
  PVSSboolean          clrHWObject(HWObject *objPtr);
  
  /** Clear all registered HWObjects. the HWObjects are
    * deleted by this function.
    * @classification ETM internal
    */
  void                 delHWObjects();
  
  /** Searches all HWMapDpPa objects for a given HW address.
    * @param hwAdr HWObject containing a known PeriphAddr string
    * @return the index of the first DpPa object matching the PeriphAddr
    * @classification ETM internal
    */ 
  PVSSlong             getFirstIndex(HWObject* hwAdr);

  /** Searches all HWMapDpPa objects for a given HW address.
    * @param hwAdr HWObject containing a known PeriphAddr string
    * @return the pointer to the first DpPa object matching the PeriphAddr
    * @classification ETM internal
    */ 
  virtual HWMapDpPa * getFirstMatch(HWObject *hwAdr);

  /** Searches all HWMapDpPa objects for a given HW address.
    * @param hwAdr HWObject containing a known PeriphAddr string
    * @return the pointer to the next DpPa object matching the PeriphAddr
    * @classification ETM internal
    */ 
  virtual HWMapDpPa * getNextMatch(HWObject *hwAdr);
  
  /** Searches all HWMapDpPa objects for a given DpIdentifier.
    * @param dpId contains a DpIdentifier
    * @return the index of the first DpPa object matching the dpId
    * @classification ETM internal
    */ 
  PVSSlong             getFirstIndex(const DpIdentifier &dpId);

  /** Searches all HWMapDpPa objects for a given DpId.
    * @param dpId contains a DpIdentifier
    * @return the pointer to the first DpPa object matching the dpId
    * @classification ETM internal
    */ 
  virtual HWMapDpPa * getFirstMatch(const DpIdentifier &dpId);

  /** Searches all HWMapDpPa objects for a given DpIdentifier.
    * @param dpId contains a DpIdentifier
    * @return the pointer to the next DpPa object matching the dpId
    * @classification ETM internal
    */ 
  virtual HWMapDpPa * getNextMatch(const DpIdentifier &dpId);
  
  /** Gets the first HWMapDpPa objects
    * @return the pointer to the first HWMapDpPa object
    * @classification ETM internal
    */ 
  virtual HWMapDpPa *getFirstDpPa();

  /** Gets the next DpPa objects 
    * @return the pointer to the next DpPa objects
    * @classification ETM internal
    */ 
  virtual HWMapDpPa *getNextDpPa();

  /** This function searches for an entry in the HW list 
    * matching the given hardware address.
    * @param hwAdr derived HWObject which holds the hardware address for incoming data
    * @return HWObject from the mapper which holds the corresponding PeriphAddr
    * @classification public use, call 
    */
  HWObject*            findHWObject(HWObject* hwAdr);
  
  /** This functions returns a given entry in the HW list
    * sorted by hardware address.
    * @param idx is the array index as e.g. returned by getFirstIndex
    * @return the HWObject at the specified position in the HW list.
    */
  HWObject*            getHWObjPtr(PVSSlong idx) {return (idx < 0 || idx >= hwaCnt ? 0 : hwaObjPtr[idx]);}
  
  /** Searches for all HW objects for a given hwAdr.
    * @param hwAdr derived HWObject which holds the hardware address for incoming data
    * @return the pointer to the first HW object matching the hwAdr
    */
  virtual HWObject *             getFirstHWObjMatch(HWObject *hwAdr);

  /** Searches for all HW objects for a given hwAdr.
    * @param hwAdr derived HWObject which holds the hardware address for incoming data
    * @return the pointer to the next HW object matching the hwAdr
    */
  virtual HWObject *             getNextHWObjMatch(HWObject *hwAdr);

  /** Gets the first HW object
    * @return the pointer to the first HW object
    */
  virtual HWObject *             getFirstHWObj();

  /** Gets the next HW object
    * @return the pointer to the next HW object
    */
  virtual HWObject *             getNextHWObj();

  /** This function searches for an entry in the HW list matching the given periph address.
    * @param adrObj HWObject which holds the periph address for outgoing data
    * @return pointer to HWObject from the mapper which holds the corresponding HW address
  *         or 0, if object was not found   
    * @classification public use, call 
    */
  HWObject*            findHWAddr(HWObject* adrObj);
  
  /** This function returns a given entry in the HW list 
    * sorted by periph address.
    * @param idx is the array index as e.g. returnd by getFirstIndex
    * @return the HWObject at the specified position
    */
  HWObject*           getHWAddrPtr(PVSSlong idx) {return (idx < 0 || idx >= hwaCnt ? 0 : adrObjPtr[idx]);}
  
  /** Gets the first HWObject sorted by PeriphAddr
    * @param hwAdr HW object address 
  * @return pointer to first first HWObjects sorted by PeriphAddr
  */
  virtual HWObject *             getFirstHWAdrMatch(HWObject *hwAdr);

  /** Gets the next HWObject sorted by PeriphAddr
    * @param hwAdr HW object address 
  * @return pointer to the next HWObjects sorted by PeriphAddr
  */
  virtual HWObject *             getNextHWAdrMatch(HWObject *hwAdr);

  /** Search first index for hardware components according to given
    * hardware address. This function uses the compare_HWcomponent() function.
    * @param hwAdr derived HWObject containing a valid hardware address
    * @return index of first stored HWObject for this hardware component
    * @classification ETM internal
    */
  PVSSlong             getFirstComponentIndex(HWObject* hwAdr);

  /** Search HW object according to given hardware address.
    * @param hwAdr derived HWObject containing a valid hardware address
    * @return pointer to the first HW object according to given hardware address.
    */
  virtual HWObject *             getFirstComponentMatch(HWObject *hwAdr);

  /** Search HW object according to given hardware address.
    * @param hwAdr derived HWObject containing a valid hardware address
    * @return pointer to the next HW object according to given hardware address.
    */
  virtual HWObject *             getNextComponentMatch(HWObject *hwAdr);

  /** Search first index for hardware components according to given
    * hardware address. This function uses the compare_HWcomponent2() function.
    * @param hwAdr derived HWObject containing a valid hardware address
    * @return index of first stored HWObject for this hardware component
    * @classification ETM internal
    */
  PVSSlong             getFirstComponent2Index(HWObject* hwAdr);
  
  /** Gets the first HW object using compare_HWcomponent2() 
    * @param hwAdr HW object address 
  * @return pointer to the first HW object found by compare_HWcomponent2
  */
  virtual HWObject *             getFirstComponent2Match(HWObject *hwAdr);

  /** Gets the next HW object using compare_HWcomponent2() 
    * @param hwAdr HW object address 
  * @return pointer to the next HW object found by compare_HWcomponent2
  */
  virtual HWObject *             getNextComponent2Match(HWObject *hwAdr);

  /** Search first hardware components according to given connection id.
    * @param hwAdr derived HWObject containing a valid connection id
    * @return first stored HWObject for this hardware component
    * @classification ETM internal
    */
  virtual HWObject *             getFirstConnectionMatch(HWObject *hwAdr);

  /** Search next hardware components according to given connection id.
    * @param hwAdr derived HWObject containing a valid connection
    * @return next stored HWObject for this hardware component
    * @classification ETM internal
    */
  virtual HWObject *             getNextConnectionMatch(HWObject *hwAdr);

  /** Get the number of stored datapoints.
    * @return number of datapoints in mapper
    * @classification public use, call
    */
  PVSSlong             getNumberOfDpIds() const { return adrCnt; }

  /** Get the DpIdentifier for a specific index gotten by a call
    * to getFirstIndex()
    * @param idx a valid index for the DpPa list.
    * @return dpIdentifier on that index or 0 if index is wrong
    * @classification public use, call
    */
  DpIdentifier*        getDpIdPtr(PVSSlong idx);

  /** Get the DpIdentifier for a specific index gotten by a call to
    * getFirstIndex(const DpIdentifier &dpId). It accesses the DPID sorted array.
    * @param idx a valid index for the DpPa list.
    * @return dpIdentifier on that index or 0 if index is wrong
    * @classification public use, call
    */
  DpIdentifier*        getDpIdPtrFromDpIdSorted(PVSSlong idx);

  /** Get the config for a specific index gotten by a call to getFirstIndex()
    * @param idx a valid index for the DpPa list.
    * @return config on that index or 0 if index is wrong
    * @classification public use, call
    */
  PeriphAddr*          getConfigPtr(PVSSlong idx);

  /** Get the config for a specific DpIdentifier
    * @param dpId is a DpIdentifier.
    * @return config on that index or 0 if dpId was not found
    * @classification public use, call
    */
  PeriphAddr*          getConfigPtr(DpIdentifier const &dpId);

  /** The purpose of this function is the adjustment of the transformation
    * objects to match either the HWObject side or the pvss2 side type of the data to transform.
    * It is also used to check whether or not a specific periph address or hardware address
  * is known by the driver. 
  * The third purpose is to adjust a newly created HWObject with the preset values 
    * from the HWObject template in the mapper (i.e. datalen, nofElements, periphAddr,...)
    * @param dpId the datapoint concerned
    * @param confPtr pointer to the config with actual subix
    * @param hwaPtr pointer to HWObject which should contain the data
    * @param fConfPtr pointer to the config with subix 0
    * @return PVSS_TRUE if object is found and adjustment was succesful, otherwise PVSS_FALSE
    * @classification public use, overload
    */
  virtual PVSSboolean  actualize(DpIdentifier& dpId, PeriphAddr *confPtr, HWObject *hwaPtr, PeriphAddr *fConfPtr);

  /** When a datapoint is deleted, his config entries are removed, too.
    * @param dpNum the internal datapoint number
    * @classification ETM internal
    */
  void  deleteDpPaByDpNumber(const DpIdType &dpNum);

  /** Print all registered HWObjects
    * @classification public use, call
    */
  void  debugPrintHWObjects();
  
  /** Print all registered HWMapDpPa objects
    * @classification public use, call
    */
  void  debugPrintHWMapDpPa();

  /** Loop through existing names and compare them with mask.
    * @param pa mask for comparison
    */
  void reportDpPa(const CharString & pa);

  /** Loop through adrObjPtr and by using compare_HWMatch() compare them with mask
  * @param pa mask for comparison
    */
  void reportHWObjects(const CharString & pa);

  /** Sorts the Pa List and gets DpIdentifier by index 
  * @param hwAdr addres of HW object 
  * @param idx index 
    */
  DpIdentifier*        getDpIdPtr(HWObject* hwAdr, PVSSlong idx);
  
  /** This function is used to iterate over the config pointers
    * in the list sorted by name. The function returns the config pointer at
    * position idx, if it equal with hwAdr compared with compare_HWPa or 0.
    * @param hwAdr HWObject which is compared by compare_HWPa with the config
    *        at position idx.
    * @param idx Denotes the position of the config to be compared with hwAdr.
    * @return The config at position idx in the list sorted by name or 0.
    * @classification public use, call
    */
  PeriphAddr*          getConfigPtr(HWObject* hwAdr, PVSSlong idx);
  
  /** This function is used to iterate over HWObjects in the list
    * sorted by HW-address. The function returns the HWObject at position idx if
    * it belongs to the same component as the template hwAdr or 0. The HWObjects
    * are compared by the function compare_HWcomponent.
    * @param hwAdr The template which is compared by compare_HWcomponent with the
    *        HWObject at position idx.
    * @param idx Denotes the position of the HWObject to be compared with hwAdr.
    * @return The HWObject at position idx in the list sorted by HW-address or 0
    * @classification public use, call
  */
  HWObject*            get4Component(HWObject* hwAdr, PVSSlong idx);
  
  /** Version of get4Component
    * @param hwAdr The template which is compared by compare_HWcomponent with the
    *        HWObject at position idx.
    * @param idx Denotes the position of the HWObject to be compared with hwAdr.
    * @return The HWObject at position idx in the list sorted by HW-address or 0
    * @classification public use, call
    */
  HWObject*            get4Component2(HWObject* hwAdr, PVSSlong idx);

  /** Virtual function (to be done)
    * param objPtr
    */ 
   virtual void         prepare4Write(HWObject *objPtr);
   
    /** Get periph address matching the mask
      * @param mask for searching
      * @return the pointer to the first periph address matching the mask
    */

  PeriphAddr *getFirstHWMatch(const char *mask, DpIdType conn = 0);

    /** Get periph address matching the mask
      * @param mask for searching
      * @return the pointer to the next periph address matching the mask
    */
  PeriphAddr *getNextHWMatch (const char *mask, DpIdType conn = 0);

  /** Compares two HW objects according to address
    * @param obj1 first HW object 
  * @param obj2 second HW object 
    * @return -1 if obj1 < obj2, 0 if obj1 == obj2 or +1 if obj1 > obj2
    */
  virtual int compare_HWHW(const HWObject* obj1, const HWObject* obj2);

  /** Compares two HW components according to address
    * @param obj1 first HW object 
  * @param obj2 second HW object 
    * @return -1 if obj1 < obj2, 0 if obj1 == obj2 or +1 if obj1 > obj2
    */
  virtual int compare_HWcomponent(const HWObject* obj1, const HWObject* obj2);
 
  /** Versuion of compare_HWcomponent 
    * @param obj1 first HW object 
  * @param obj2 second HW object 
    * @return -1 if obj1 < obj2, 0 if obj1 == obj2 or +1 if obj1 > obj2
    */
  virtual int compare_HWcomponent2(const HWObject* obj1, const HWObject* obj2);

protected:

  /** Compare two HWMapDpPa objects; return -1 if p1 < p2, 
    * +1 if p2 > p2 or 0 if both are equal. the comparison looks at 
    * the connectionId, periphAddr string and subix. 
    * For performance reasons the base implementation uses a calculated 
    * hash value as sort condition.
    * If you overload this function make sure to be consistent with 
    * the compare_HWPa method, since this method also searches in the HWMapDpPa list.
    * @param p1 first DpPa object
    * @param p2 second DpPa object
    * @param useSubindex take care of the subix in the compare function
    * @return -1 if obj1 < obj2, 0 if obj1 == obj2 or +1 if obj1 > obj2
    * @classification ETM internal
    */
  virtual int compare_DpPa(HWMapDpPa *p1, HWMapDpPa *p2, PVSSboolean useSubindex = PVSS_FALSE);

  /** Compare two HWMapDpPa objects; return -1 if p1 < p2, 
    * +1 if p2 > p2 or 0 if both are equal. 
    * the comparison looks at the dpId.
    * @param p1 first DpPa object
    * @param p2 second DpPa object
    * @return -1 if p1 < p2, 0 if p1 == p2 or +1 if p1 > p2
    * @classification ETM internal
    */
  virtual int compare_DpDp(HWMapDpPa *p1, HWMapDpPa *p2);

  /** Compare a DpPa object with a HW object; 
    * the comparison looks at the connectionId and periphAddr string only.
    * For performance reasons the base implementation uses a calculated
    * hash value as sort condition.
    * If you overload this function make sure to be consistent with the compare_DpPa method,
    * since this method also searches in the HWMapDpPa list.
    * @param data HWObject object
    * @param ptr DpPa object
    * @return -1 if o1 < o2, 0 if o1 == o2 or +1 if o1 > o2
    * @classification ETM internal
    */
  virtual int compare_HWPa(HWObject* data, HWMapDpPa *ptr);

  /** Compare two HW objects; 
    * The comparison looks at the connectionId and periphAddr string only.
    * @param obj1 first HW object
    * @param obj2 second HW object
    * @return -1 if o1 < o2, 0 if o1 == o2 or +1 if o1 > o2
    * @classification ETM internal
    */
  virtual int compare_HWAS(HWObject* obj1, HWObject* obj2);

  /** Compare two HW objects; 
    * the comparison looks at the hardware address.
    * this function has to be overloaded for derived drivers.
    * @param obj1 first HW object
    * @param obj2 second HW object
    * @return -1 if o1 < o2, 0 if o1 == o2 or +1 if o1 > o2
    * @classification public use, overload
    */
  virtual int compare_HWHW(HWObject* obj1, HWObject* obj2);

  /** Compare two HW objects; 
    * The comparison looks at the component specific part of hardware address.
    * This function has to be overloaded for derived drivers.
    * @param obj1 first HW object
    * @param obj2 second HW object
    * @return -1 if o1 < o2, 0 if o1 == o2 or +1 if o1 > o2
    * @classification public use, overload
    */
  virtual int compare_HWcomponent(HWObject* obj1, HWObject* obj2);

  /** Version of compare_HWcomponent
    * @param obj1 first HW object
    * @param obj2 second HW object
    * @return -1 if o1 < o2, 0 if o1 == o2 or +1 if o1 > o2
    * @classification public use, overload
    */
  virtual int compare_HWcomponent2(HWObject* obj1, HWObject* obj2);
  
  /** Compare the periphAdr string against a pattern. The pattern is a string with wildcards.
    * This function is used in getFirstHWMatch and getNextHWMatch.
    * You may use PatternMatch::patternMatch to perform the actual match.
    * @param ptr The HWMapDpPa object with the PeriphAddr config
    * @param pattern The pattern to match against
    * @return PVSS_TRUE if the pattern matches, else PVSS_FALSE
    * @classification public use, overload
    */
  virtual PVSSboolean  compare_PaMatch(HWMapDpPa *ptr, const char *pattern);
  
  /** Compare the address string in a HWObject against a pattern. 
    * The pattern is a string with wildcards. This function is used in reportHWObjects.
    * You may use PatternMatch::patternMatch to perform the actual match.
    * @param ptr The HWObject to be compared
    * @param pattern The pattern to match against
    * @return PVSS_TRUE if the pattern matches, else PVSS_FALSE
    * @classification public use, overload
    */
  virtual PVSSboolean  compare_HWMatch(HWObject *ptr, const char *pattern);

  /** Get the number of address HWObjects in the HWMapper
    * @return the number of address HWObjects in the HWMapper
  */
  PVSSlong getHwaCnt() {return hwaCnt;}

private:

  /** Version of compare_HWcomponent
    * @param obj1 first HW object
    * @param obj2 second HW object
    * @return -1 if o1 < o2, 0 if o1 == o2 or +1 if o1 > o2
    * @classification public use, overload
    */
  int compare_connection(const HWObject* obj1, const HWObject* obj2);

  // -----------------------------------------------------------
  // internals
  /** Append inserted HWMapDpPa pointer to adrStrPtr array and sort it.
    * If manager running, mark it as unsorted
    * @param itmPtr pointer to HWMapDpPa object
  * @return PVSS_TRUE if it was successful  
    */
  PVSSboolean sortedInsert_HWMapDpPa(HWMapDpPa *itmPtr);

  /** Append inserted HWMapDpPa pointer to dpIdPtr array and sort it.
    * If manager running, mark it as unsorted
    * @param itmPtr pointer to HWMapDpPa object
  * @return PVSS_TRUE if it was successful  
    */
  PVSSboolean sortedInsert_DpDp(HWMapDpPa *itmPtr);

  /** Insert sorted HWObject pointer to hwaObjPtr array.
    * @param itmPtr pointer to HWObject object
  * @return PVSS_TRUE 
    */
  PVSSboolean sortedInsert_hwaObj(HWObject *itmPtr);

  /** Insert sorted HWObject pointer to adrObjPtr array.
    * @param itmPtr pointer to HWObject object
  * @return PVSS_TRUE 
    */
  PVSSboolean sortedInsert_adrObj(HWObject *itmPtr);

  /** Sort Pa list and find the first record in periph addresses 
    * @param itmPtr pointer to HWMapDpPa object
  * @return index of the record
    */
  PVSSlong    fidex_DpPa(HWMapDpPa *itmPtr);
 
  /** Sort Pa list and find the first periph address through HWObject
    * @param objPtr pointer to HWObject object
  * @return index of the first matching periph address 
    */
  PVSSlong    fidex_PaObj(HWObject *objPtr);

  /** Sort Pa list and find the first DpIdentifier through HWMapDpPa 
    * @param itmPtr pointer to HWMapDpPa object
    * @return index of the first match of DpIdentifier 
    */
  PVSSlong    fidex_DpDp(HWMapDpPa *itmPtr);

 /** Search for the first record in HWObjects sorted by HW address
   * @param objPtr pointer to HWObject object
   * @return index of the first found HW object 
   */
  PVSSlong    fidex_hwaObj(HWObject *objPtr);

  /** Search for the first record in HWObjects sorted by HW address string
   * @param objPtr pointer to HWObject object
   * @return index of the first found HW object 
   */
  PVSSlong    fidex_adrObj(HWObject *objPtr);

  /** Search for the first record in HWObjects sorted by HWcomponent
    * @param objPtr pointer to HWObject object
    * @return index of the first found HW object 
  */
  PVSSlong    fidex_component(HWObject *objPtr);

  /** Version of fidex_adrObj
    * @param objPtr pointer to HWObject object
    * @return index of the first found HW object 
  */
  PVSSlong    fidex_component2(HWObject *objPtr);

  PVSSlong    fidex_connection(HWObject *objPtr);

  // zaehler muessen vorzeichen haben (Schleifen mit >= 0!) - daher PVSSlong!!!
  PVSSlong    adrCnt;       // count of addresses
  PVSSlong    adrMax;       // max number of addresses
  HWMapDpPa **adrStrPtr;    // PeripherieAdress-Configs nach adress-string sortiert
  HWMapDpPa **dpIdPtr;      // PA-Configs nach dpId sortiert
  PVSSlong    hwaCnt;       // count of HWObjects
  PVSSlong    hwaMax;       // max amount of HWObjects
  HWObject  **hwaObjPtr;    // HWObjects nach hardware-adresse sortiert
  HWObject  **adrObjPtr;    // HWObject nach adress-string sortiert

  PVSSlong  lastHWSearchIndex;     //for  HWMapper::getFirstHWMatch(const char *mask)
 
  PVSSlong  lastPASearchIndex;     // for HWMapDpPa * getFirstMatch(HWObject *hwAdr);
  PVSSlong  lastDPSearchIndex;     // for HWMapDpPa * getFirstMatch(const DpIdentifier &dpId);
  PVSSlong  lastDPPAIndex;         // for HWMapDpPa * getFirstDpPa();

  PVSSlong  lastHWAdrSearch;       // for HWObject * getFirstHWObjMatch(HWObject *hwAdr);
  PVSSlong  lastHWAdrIndex;        // for HWObject * getFirstHWObj();
  PVSSlong  lastPeriphAdrSearch;   // for HWObject * getFirstHWAdrMatch(HWObject *hwAdr);
  PVSSlong  lastComponentSearch;   // for HWObject * getFirstComponentMatch(HWObject *hwAdr);
  PVSSlong  lastComponent2Search;  // for HWObject * getFirstComponent2Match(HWObject *hwAdr);

  PVSSlong  lastConnectionSearch;  // for HWObject * getFirstConnectionMatch()

  // dhoegerl 20091215: performance optimization
  PVSSboolean paListSorted;
  
  PVSSboolean sortPaLists();

  void HeapSortDpPa(HWMapDpPa **pF, HWMapDpPa **pL)
  { 
    for (intptr_t k = (pL-pF)/2; k >= 1; k--)
    {
      HeapifyDpPa(pF, pL, k);
    }

    for (; pF < --pL;)
    {
      std::iter_swap(pF, pL);
      HeapifyDpPa(pF, pL, 1);
    }
  };

  void HeapifyDpPa(HWMapDpPa **pF, HWMapDpPa **pL, intptr_t k)
  {
    HWMapDpPa* v = *(pF + k-1);
    intptr_t nChild;

    while (k <= (pL-pF)/2)
    {
      nChild = k<<1;

      if ((nChild < pL-pF) && (compare_DpPa(*(pF + nChild-1), *(pF + nChild), PVSS_TRUE) < 0)) {
        nChild++;
      }
      if (compare_DpPa(v, *(pF + nChild-1), PVSS_TRUE) >= 0) {
        break;
      }

      *(pF + k-1) = *(pF + nChild-1);
      k = nChild;
    }
    *(pF + k-1) = v;
  };
  
  void HeapSortDpDp(HWMapDpPa **pF, HWMapDpPa **pL)
  { 
    for (intptr_t k=(pL-pF)/2; k>=1; k--)
    {
      HeapifyDpDp(pF, pL, k);
    }

    for (; pF < --pL;)
    {
      std::iter_swap(pF, pL);
      HeapifyDpDp(pF, pL, 1);
    }
  };

  void HeapifyDpDp(HWMapDpPa **pF, HWMapDpPa **pL, intptr_t k)
  {
    HWMapDpPa* v = *(pF + k-1);
    intptr_t nChild;

    while (k <= (pL-pF)/2)
    {
      nChild = k<<1;

      if ((nChild < pL-pF) && (compare_DpDp(*(pF + nChild-1), *(pF + nChild)) < 0)) {
        nChild++;
      }
      if (compare_DpDp(v, *(pF + nChild-1)) >= 0) {
        break;
      }

      *(pF + k-1) = *(pF + nChild-1);
      k = nChild;
    }
    *(pF + k-1) = v;
  };
};

#endif
