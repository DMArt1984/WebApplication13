#ifndef _ALERT_OBJECT_HXX
#define _ALERT_OBJECT_HXX

#include <AlertIdentifier.hxx>
#include <TimeVar.hxx>
#include <BitVec.hxx>
#include <CharString.hxx>
#include <DynVar.hxx>
#include <AnyTypeVar.hxx>

class HWObject;
class AlertService;

#define SENDALLADDVALUES  0xFFFFFFFF

/** Class for handling of AlertObject's 
  * @classification public use
  */

class AlertObject
{
  friend class UNIT_TEST_FRIEND_CLASS;    

  friend class AlertService;

  public:
    
    /// the Alarm Event Type
    enum EventAction
    {
      EA_UNKNOWN,

      EA_CAME,    // alarm came
      EA_GONE,    // alarm gone
      EA_WENT = EA_GONE,
      EA_ACK,     // alarm got acknowledged
      EA_UPDATE,  // for changes on addValues

      EA_GONE_OBSOLETE,   // alarm is no longer existing in PLC, remove it from EV

      // ---------------------------------------------
      // internal actions

      EA_GONE_DELAYED,  // gone alarm event has been delayed due to noct ack of came
      EA_REMOVED, // alarm has been removed (either went invisible or DPE deleted)
      EA_FAILED,  // alarm was rejected by EV

                  // inofficial values to be used for compatibility checks
      EA_OLDSET = 100,
      EA_OLDACK,
    };

    /// Fixed Index for the first 4 add values
    enum AddValueIndex
    {
      AVI_VALUE,      // the value which generated the alarm
      AVI_ALARMTEXT,  // a description for the alarm
      AVI_PRIORITY,   // the priority of the alarm
      AVI_QUALITYCODE // the quality code
    };

    /** Constructor
      */
    AlertObject();
    
    /** Destructor
      */
    ~AlertObject();
    
    /** Copy constructor to be used for new CAME/GONE alerts.
    * @param ao alert operator
    */
    AlertObject(const AlertObject &ao);

    /** Copy operator.
    * @param ao alert operator
    * @return pointer to alert object
    */
    const AlertObject & operator =(const AlertObject &ao);
    
    /** Get the alert range. 
    * @return alert range
    */
    int getAlertRange() const {return alertRange_;}

    /** Set the alert range.
    * @param ar alert range
    */
    void setAlertRange(int ar) {alertRange_ = ar;}
  
    /** get the origin time
      * this is a direct access to the AlertIdentifier
    * @return the origin time
    */
    const TimeVar &getOrgTime() const;
    
    /** set the origin time
      * this is a direct access to the AlertIdentifier
    *  @param tm origin time to be set
    */
    void setOrgTime(const TimeVar &tm);

    /** set the timeOfPeriph bit to signal this time really comes from periphery
    * @param top flag for time of periphery
    */
    void setTimeOfPeriphFlag(PVSSboolean top = PVSS_TRUE) {timeOfPeriph_ = top;}

    /** check if this is driver time or periph time
        @return PVSS_TRUE if time is periphery time
    */
    PVSSboolean isTimeOfPeriph() { return timeOfPeriph_; }
 
    /** get the AlertIdentifier
      * @return alert identifier
      */
    const AlertIdentifier &getAlertIdentifier() const { return aid_; }

    /** set the AlertIdentifier
      * @param id alert identifier to be set
    */
    void setAlertIdentifier(const AlertIdentifier &id) { aid_ = id; }
        
    /** set a pointer to a comment.
      * the string is copied into the AlertObject
      * @param cmt pointer to a comment
      */
    //void setCommentPtr(const char * cmt);

    void setComment(const CharString &cmt) {comment_ = cmt; }


    /** get the comment
    * @return the comment
    */
    //const char *getCommentPtr() const {return (const char *)comment_;}

    const CharString &getComment() {return comment_; }

    /** set Variable pointer the pointer is captured by the object
    * @param var variable pointer to be set
    */
    void setVariablePtr(Variable * var) {value_ = var;}

    /** get the pointer to the variable
    * @return a pointer to the variable
    */
    const Variable * getVariablePtr() const {return value_;}

    /** cut out the variable pointer
    * @return a pointer to the variable    
    */
    Variable * cutVariablePtr();

    /** get the AlertID
    * @return alert identifier
    */
    const CharString &getAlertID() const {return AlertID_;}

    /** set the AlertID
    * @param str alert identifier
    */
    void setAlertID(const CharString &str) {AlertID_ = str;}

    /** set a user byte in the status.
      * @param userByteNo number of user byte range 0..3
      * @param val value to be set
      * @return PVSS_TRUE execution OK
      * PVSS_FALSE in case of error
      */
    PVSSboolean setUserByte (PVSSushort userByteNo, PVSSuchar val);
        
    /** reads a user byte from the status.
      * @param userByteNo number of user byte range 0..3
      * @return the requested user byte
      */
    PVSSuchar getUserByte (PVSSushort userByteNo) const;
    
    /** check validity of user byte.
      * @param userByteNo number of user byte range 0..3
      * @return PVSS_TRUE user byte is valid
      * PVSS_FALSE user byte is not valid
      */
    PVSSboolean isValidUserByte(PVSSushort userByteNo) const;

    /** return the status flags
    * @return the status flags
    */
    const BitVec& getStatus() const {return status_;}

    /** return eventAction
    * @return eventAction
    */
    const EventAction getEvent() const { return eventAction_; }

  /** Set eventAction
    * @param action eventAction to be set
    * @return eventAction
    */
    void setEvent(const EventAction action) { eventAction_ = action; }

    /** get all additional values for the alert
      * @return additional alert values
    */
    const DynVar &getAddValues() const {return addValues_;}

    /** Sets all additional values for the alert.
      * Since AddValues must be a DynAnytype, the given DynVar is checked and
      * silently converted to DynAnytype if necessary
      * @param addValues all additional values of alert to be set 
    */
    void setAddValues(const DynVar &addValues);

    /** gets the additional value for an index
    * @param id alert index
      * @return additional value for parameter index
    */
    const Variable *getAddValue(unsigned id) const { return addValues_.getAt(id);}

    /** Sets the additional value for an index.
      * The pointer is captured by DynVar, the caller must not delete it.
      * If the given variable is not an AnyType, it is silently converted
      * @param id alert index
      * @param valPtr pointer to the aditional value
      */
    void setAddValue(unsigned id, Variable *valPtr);

    /** get the addValue mask.
      * @return mask
      */
    PVSSulong getAddValueMask() const { return addValueMask_; }

    /** reset the addValue mask.
      */
    void resetAddValueMask() { addValueMask_ = 0; }

    /** get the alert class name
    * @return the alert class name
      */
    const CharString getAlertClassName() const { return alertClassName_; }

    /** set the alert class name
      * @param cameID alert class name to be set
    */
    void setCameAlertID(const CharString cameID) { cameAlertID_ = cameID; }

    /** get the alert class name
    * @return alert calss name
      */
    const CharString getCameAlertID() const { return cameAlertID_; }

    /** set the alert class name
    * @param alertClassName the alert class name to be set 
    */
    void setAlertClassName(const CharString alertClassName) { alertClassName_ = alertClassName; }

    /** gets the ackable state
    * @return PVSS_TRUE if the state is ackable
    */
    const PVSSboolean isAckable() const { return ackable_; }

    /** sets the ackable state
    * @param ackable flag for ACK
    */
    void setAckable(const PVSSboolean ackable = PVSS_TRUE) { ackable_ = ackable; }

    /** gets the visible state
      * @return PVSS_TRUE if the state is visible
    */
    const PVSSboolean isVisible() const { return visible_; }

    /** gets the visible state
    * @return PVSS_TRUE if the state is visible
    */
    IL_DEPRECATED("deprecated, use isVisible() instead")
    const PVSSboolean getVisible() const { return visible_; }

    /** sets the visible state
    * @param visible flag for visible state
    */
    void setVisible(const PVSSboolean visible = PVSS_TRUE) { visible_ = visible; }

    /** output debug info to std::cerr
    * @param shortForm do not print additional values if set to true
    */
    void debugPrint(bool shortForm = false) const;

    /** Gets alert identifier time and resets the count
    */
    void resetCount();

    /** check if this AlertObject already got a callback from EV
      * @return PVSS_TRUE if AlertObject is unconfirmed
    */
    PVSSboolean isUnconfirmed() { return (aid_.getAlertTime().getCount() == ((PVSSushort) (-1)) ? PVSS_TRUE : PVSS_FALSE); }

    /** add additional command for outstanding AlertObject request. Actual version of the method stores only last command. 
    *   The command is defined as goneCommand, ackCommand or modifyCommand. 
    *   The added command is then sent to the AlertService to be executed upon specified alert object by the sendCommand method.
    *   @param aoPtr pinter to AlertObject
    */
    void addCommand(AlertObject *aoPtr);

    /** send additional commands for outstanding AlertObject request to the AlertService (see addCommand method)
    *   send command or redu for ackCommand and modifyCommand
    *   @param hwPtr pointer to HWobject
    */
    void sendCommand(HWObject *hwPtr);

    /** This method is called to confirm outstanding command that was previoulsy sent to AlertService.
     *  The method itself clears the corresponding intermediate storage of command.
     *  @param action gone, ack or modify command
    */
    void confirmCommand(EventAction action);

  private :
    
    int alertRange_;
    AlertIdentifier aid_;   // alerttime plus dpidentifier

    TimeVar orgTime_;
    CharString AlertID_;    // the hardware specific AlertID

    CharString comment_; // a optional alert comment

    Variable *value_; // an optional value for the DPE
    BitVec status_; // status information 

    EventAction eventAction_; // the alarm event

    DynVar addValues_;        // additional alarm values
    PVSSulong addValueMask_;  // if bit is set the addValue has been changed

    CharString alertClassName_;
    CharString cameAlertID_;

    PVSSboolean ackable_;
    PVSSboolean visible_;

    PVSSboolean timeOfPeriph_;

    AlertObject *goneCommand;        // for intermediate storage of commands
    AlertObject *ackCommand;         // for intermediate storage of commands
    AlertObject *modifyCommand;      // for intermediate storage of commands
};

// -------------------------------------------------------------------------------
// wrapper classes for container
// object is not captured

#include <set>
using namespace std;

/** wrapper class for container
  * wrapper for sorting by AlertID
  */
class AlertObjectAIDPtr
{
private:
    AlertObject *ptr_;

public:
  /** Constructor
    * @param p pointer to alert object
    */
    AlertObjectAIDPtr(AlertObject *p) : ptr_(p) {}

    /** copy operator
    * @return pointer to alert object
    */
    const AlertObject * operator()() const {return ptr_; }

    /** copy operator
    * @return pointer to alert object
    */
    AlertObject * operator()() {return ptr_; }
};

inline int operator ==(const AlertObjectAIDPtr &ap1, const AlertObjectAIDPtr &ap2) 
{ 
    return ((ap1() && ap2()) ? (ap1()->getAlertID() == ap2()->getAlertID()) : false );
}

inline int operator < (const AlertObjectAIDPtr &ap1, const AlertObjectAIDPtr &ap2) 
{ 
    return ((ap1() && ap2()) ? (ap1()->getAlertID() < ap2()->getAlertID()) : false );
}


/** wrapper class for container
  * wrapper for sorting by AlertIdentifier
  */
class AlertObjectDPIDPtr
{
private:
    AlertObject *ptr_;

public:
  /** Constructor
    * @param p pointer to alert object
    */
    AlertObjectDPIDPtr(AlertObject *p) : ptr_(p) {}

    /** copy operator
    * @return pointer to alert object
    */
    const AlertObject * operator()() const {return ptr_; }
  
    /** copy operator
    * @return pointer to alert object
    */
    AlertObject * operator()() {return ptr_; }
};

bool operator ==(const AlertObjectDPIDPtr &ap1, const AlertObjectDPIDPtr &ap2); 
bool operator < (const AlertObjectDPIDPtr &ap1, const AlertObjectDPIDPtr &ap2); 

typedef std::set<AlertObjectAIDPtr>  AIDPtrSet;
typedef std::multiset<AlertObjectDPIDPtr> DPIDPtrSet;
typedef AIDPtrSet::iterator  AIDPtrSet_Iterator;
typedef DPIDPtrSet::iterator DPIDPtrSet_Iterator;

#endif
