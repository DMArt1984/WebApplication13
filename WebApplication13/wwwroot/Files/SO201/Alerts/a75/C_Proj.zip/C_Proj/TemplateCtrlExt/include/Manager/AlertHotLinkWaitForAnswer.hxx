#ifndef _ALERTHOTLINKWAITFORANSWER_H_
#define _ALERTHOTLINKWAITFORANSWER_H_

#include <WaitForAnswer.hxx>
#include <AlertAttrList.hxx>

class DpMsgAnswer;
class DpMsgAlert;
class DpMsg;

/** The hotlink callback class. This class is an abstract base class for 
  hotlink messages. It will also handle the answer message received as 
  response on the connect message. It contains callback functions for the
  answer message as well as for hotlink groups.
  @see DpMsgAnswer, DpMsgHotLink
  @classification public use, overload
 */
class DLLEXP_MANAGER AlertHotLinkWaitForAnswer: public WaitForAnswer
{
  public:
    /// constructor
    AlertHotLinkWaitForAnswer(){}
    /// destructor
    virtual ~AlertHotLinkWaitForAnswer(){}

    virtual answerType isA(){ return WaitForAnswer::ALERT_HOT_LINK_ANSWER; };

    /*  no need to overload this function, because it is never called.
	@classification public do not use
     */
    virtual void callBack(DpMsgAnswer &answer) { alertHotLinkCallBack(answer); } 

    /** The answer callback function. 
      This function is abstract since this is a base class.
      Use this function by overloading to handle the answer message. 
      You need to overload this class whenever you want to handle answer messages. 
      Objects of this type  are used by the manager to distribute answer messages.
      @param answer the answer message received
      @classification public use, overload
     */
    virtual void alertHotLinkCallBack(DpMsgAnswer &answer) = 0;

    // virtual void callBack(DpMsgAnswer &answer) { hotLinkCallBack (answer); }
    // Ueberladene Callback-Methode speziell fuer HotLinks nach der Suche im Manager
    virtual void alertHotLinkCallBack(const DpMsg & /* alMsg */, AlertAttrList &group)
    {
      alertHotLinkCallBack(group);
    }

  protected:

    // Ueberladene Callback-Methode speziell fuer HotLinks nach der Suche im Manager
    /** The hotlink callback function. This function is abstract since this is a
      base class. Use this function by overloading to handle hotlink messages.
      As hotlink messages may contain several groups they are split into groups 
      before this function is called. 
      @param group A hotlink group received
      @classification public use, overload
     */
    virtual void alertHotLinkCallBack(AlertAttrList &group) = 0;
};

#endif /* _ALERTHOTLINKWAITFORANSWER_H_ */
