#ifndef _WAITDELAY_H_
#define _WAITDELAY_H_

#include <WaitCond.hxx>
#include <TimeoutTimer.hxx>

/*  author VERANTWORTUNG: Martin Koller   */
/** class handles the wait on a timer-expiration (delay) in
  * seconds and milliseconds               */
class DLLEXP_CTRL WaitDelay : public WaitCond
{
  public:
    /// constructor
    WaitDelay(PVSSulong secs, PVSSshort milli);

    /// wann soll thread das naechste mal ausgefuehrt werden.
    virtual const TimeVar &nextCheckAt();

    /// returns TRUE wenn das delay abgelaufen ist
    virtual int checkDone();

  private:
    TimeoutTimer timer;  // uses a monotonic timer to be independant of system time changes
};

#endif /* _WAITDELAY_H_ */
