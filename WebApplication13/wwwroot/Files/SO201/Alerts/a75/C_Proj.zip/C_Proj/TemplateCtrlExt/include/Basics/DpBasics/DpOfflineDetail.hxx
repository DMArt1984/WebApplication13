// DATEIBESCHREIBUNG ==============================================================
// DATEINAME:     DpOfflineDetail.hxx
// VERANTWORTUNG: Rene Heissinger
// BESCHREIBUNG:  
// ======================================Ende======================================
#ifndef _DPOFFLINEDETAIL_H_
#define _DPOFFLINEDETAIL_H_

#include <CharString.hxx>
#include <Types.hxx>
#include <DpTypes.hxx>

#define OFFDETAILSTEPMINTEXT   "min"
#define OFFDETAILSTEPHOURTEXT  "hour"
#define OFFDETAILSTEPDAYTEXT   "day"
#define OFFDETAILSTEPWEEKTEXT  "week"
#define OFFDETAILSTEPMONTHTEXT "month"
#define OFFDETAILSTEPYEARTEXT  "year"

enum DpOfflineDetailStepId
{
  OFFDETAILSTEPERRORID = 0,
  OFFDETAILSTEPMINID,
  OFFDETAILSTEPHOURID,
  OFFDETAILSTEPDAYID,
  OFFDETAILSTEPWEEKID,
  OFFDETAILSTEPMONTHID,
  OFFDETAILSTEPYEARID
};

#define OFFDETAILFUNCSUMTEXT "sum"
#define OFFDETAILFUNCMINTEXT "min"
#define OFFDETAILFUNCMAXTEXT "max"
#define OFFDETAILFUNCAVGTEXT "avg"
#define OFFDETAILFUNCAVGINTTEXT "avg_integral"
#define OFFDETAILFUNCDIFFTEXT "diff"
#define OFFDETAILFUNCDIFFABSTEXT "diffabs"
#define OFFDETAILFUNCMINTSTEXT "min_time"
#define OFFDETAILFUNCMAXTSTEXT "max_time"

enum DpOfflineDetailFuncId
{
  OFFDETAILFUNCERRORID = 0,
  OFFDETAILFUNCSUMID,
  OFFDETAILFUNCMINID,
  OFFDETAILFUNCMAXID,
  OFFDETAILFUNCAVGID,
  OFFDETAILFUNCAVGINTID,
  OFFDETAILFUNCDIFFID,
  OFFDETAILFUNCDIFFABSID, 
  OFFDETAILFUNCMINTSID,
  OFFDETAILFUNCMAXTSID
};

/** DP offline detail.
    @classification ETM internal
*/
class DLLEXP_BASICS DpOfflineDetail
{
  public:
    
    /** Constructor.
       @param  name  DP offline detail string
    */
    DpOfflineDetail(const CharString &name);
    /** Constructor.
       @param  detail  DP offline detail number
    */
    DpOfflineDetail(DpDetailNrType detail);
    
    /// Return the detailId.
    DpDetailNrType getDetailId() const { return detailId_; } 
    /// Return the detailName string.
    CharString getDetailName() const; 
    /** Return functionName string.
        @param  functionId  Function ID
    */
    CharString getFunctionName(int functionId) const;
    /** Return functionId.
        @param  function  Function name string.
    */
    int getFunctionId(const CharString &function) const;
    /** Return stepName string
        @param  step  Step name ID.
    */
    CharString getStepName(int step) const;
    /** Return stepId.
        @param  step  Step name string.
    */
    int getStepId(const CharString &step) const;
    /// Return stepId.
    int getStepId() const;
    
  
  protected:
    /// Detail name string
    CharString detailName_;
    /// Detail number
    DpDetailNrType detailId_;
    
    /// Factor ID
    int faktor_;
    /// Step ID
    int stepId_;
    /// Function ID
    int functionId_;
};


#endif /* _DPVCITEM_H_ */
