#ifndef _LIMITDIFFACCU_H_
#define _LIMITDIFFACCU_H_

// Author: Wolfram Klebel
// Date:   21.9.2000
// Purpose: implement a statistic Accumulator to determine the difference of the limits of values

#ifndef _SIMPLEACCU_H_
#include <SimpleAccu.hxx>
#endif

#ifndef _SAMPLEACCU_H_
#include <SampleAccu.hxx>
#endif

#ifndef _ENDVALUEACCU_H_
#include <EndValueAccu.hxx>
#endif

#ifndef _DIFFACCU_H_
#include <DiffAccu.hxx>
#endif

#ifndef _VARIABLE_H_
#include <Variable.hxx>
#endif

#ifndef _FLOATVAR_H_
#include <FloatVar.hxx>
#endif

#ifndef _TIMEVAR_H_
#include <TimeVar.hxx>
#endif

/// The DiffAccu accumulator class. This class serves a difference between the first and last
/// accumulated values.
/// @classification ETM internal
class DLLEXP_OABASICS DiffAccu: public SimpleAccu
{
  public:
    friend class UNIT_TEST_FRIEND_CLASS;
    /// Constructor.
    /// @param aVarType VariableType of the accumulated values.
    /// @n Supported variable types are INTEGER_VAR, UINTEGER_VAR and FLOAT_VAR.
    /// If other variable type is specified, FLOAT_VAR will be used instead.
    DiffAccu(const VariableType aVarType);

    /// Destructor.
    virtual ~DiffAccu();
    
    /// This method will accumulate the value, which means that the getResult() method
    /// will return the difference between that values from first and last call of accumulate().
    /// @param theValue Variable which will be stored in the accumulator. 
    ///
    /// @n See constructor description for supported variable types. If variable of
    /// a different type as the one specified in the constructor will be passed here,
    /// it will be converted according to the specific rules implemented in that 
    /// particular Variable classes.
    ///
    /// @n The first value can be reset by calling method resetPeriodTime();
    /// @param atTime Time stamp. This variable doesn't have any effect.
    virtual void accumulate(const Variable &theValue, const TimeVar &atTime );

    /// This method returns the difference between the last and first accumulated variable.
    /// @return const reference to a Variable with difference between the last and first value.
    ///
    /// @n If accumulate() was called only once, that value will be returned.
    virtual const Variable &getResult();

    /// This method returns the same value as getResult(), the parameters are not used.
    /// @param theValue This parameter is ignored.
    /// @param start This parameter is ignored.
    /// @param stop This parameter is ignored.
    /// @param valid This parameter is ignored.
    /// @return See getResult().
    virtual const Variable &getIntermResult(  const Variable &theValue, const TimeVar &/*start*/, 
                                                     const TimeVar &/*stop*/, bool /*valid*/ );
    
    /// This method resets the value stored by first call of the accumulate();
    /// @param periodTime This parameter is ignored.
    virtual void resetPeriodTime(const TimeVar * const periodTime);
    
  protected:
  
    /// This method will calculate the difference between two Variables.
    /// @param s This first Variable.
    /// @param e This second Variable.
    /// @param valid PVSS_TRUE if the result is valid.
    /// @return The value difference: e - s.
    virtual const Variable &calcValue( const Variable &s, const Variable &e, PVSSboolean &valid );

  private:

    /// prevents the copy constructor to be called.
    DiffAccu(const DiffAccu &);

    /// prevents the assignment operator to be called.
    DiffAccu &operator=(const DiffAccu &);

    /// obsolete. does nothing.
    virtual void reset();		// should not be called from outer space!
  
    /// This accumulator will store the value from the first call of accumulate().
    /// The accumulator will be reset with the call of resetPeriodTime().
    SampleAccu sample;

    /// This accumulator will store the value from the last call of accumulate().
		EndValueAccu endValue;

    /// Storage for the returning diff value (endValue - sample).
    Variable *diff;					// difference value returned

    /// Type of the accumulator (see constructor description for valid types). 
		VariableType varType;		// has to be reserved
};

#endif
