#ifndef _CTRLFILEEXTDATA_H_
#define _CTRLFILEEXTDATA_H_

#include <ExternData.hxx>
#include <CharString.hxx>

/*  author VERANTWORTUNG: Martin Koller */
/** Holds only the location information (= filename) */
class DLLEXP_CTRL CtrlFileExtData : public ExternData
{
  public:
    /** Hold the Filename of the Script or the Lib
      * @param name Filename
      */
    CtrlFileExtData(const CharString &name);
    /// Destructor 
    virtual ~CtrlFileExtData();
    /** Determine the type of ExternData
      * @return this is a File
      */
    virtual int isA() const { return FILE_DATA; }

    /** location information which is used on runtime-error output
      * @return filename
      */
    virtual CharString getLocation(const CtrlThread *thread = 0) const;

    /** Filename of the script which is used on runtime-error output
      * @return filename of the Script we are executing
      */
    virtual CharString getFilename() const { return fileName; }
    virtual CharString getFilename(int lib) const { return getFilename(); }

  protected:

  private:
    /// Filename of the Scriptfile 
    CharString fileName;
};

#endif /* _CTRLFILEEXTDATA_H_ */
