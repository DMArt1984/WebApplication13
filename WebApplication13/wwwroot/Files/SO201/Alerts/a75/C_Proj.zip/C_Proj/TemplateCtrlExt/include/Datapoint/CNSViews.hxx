#ifndef _CNSVIEWS_H_
#define _CNSVIEWS_H_

#include <SimplePtrArray.hxx>
#include <CNSView.hxx>
#include <ViewId.hxx>

// forward declaration
class DpIdentificationProSystem;
class CNSTreeVisitor;

// explicit instantiation of template
#ifdef WIN32
#pragma warning ( disable: 4231 )
#endif

#if defined(LIBS_AS_DLL)
EXTERN_DATAPOINT template class DLLEXP_DATAPOINT SimplePtrArray<CNSView>;
#endif

#ifdef WIN32
#pragma warning ( default: 4231 )
#endif


/**
 * Container for all CNS views of a system.
 *
 * @see CNSView
 * @internal
 */
class DLLEXP_DATAPOINT CNSViews
{
public:
  /// BCM stream input operator
  friend DLLEXP_DATAPOINT itcNdrUbReceive &operator >>(itcNdrUbReceive &from, CNSViews &views);
  /// BCM stream output operator
  friend DLLEXP_DATAPOINT itcNdrUbSend &operator <<(itcNdrUbSend &to, const CNSViews &views);
  // needs to access setDpIdentProSystem()
  friend class DpIdentificationProSystem;

public:
  /**
   * Default constructor. Creates an empty instance without a link to
   * its containing DpIdenitifcationProSystem-object.
   * Use only for BCM streaming.
   */
  CNSViews() : dpIdent(0) { }

  /**
   * Creates a new views-collection with the specified system names
   * and a pointer to the DpIdentificationProSystem-object it is contained in.
   *
   * If you do not specify a DpIdentificationProSystem here,
   * be aware that the instance might not work correctly as long as you do not
   * supply a pointer to its containing DpIdentificationProSystem.
   *
   * @param systemNames The display names to be used for this system.
   *                    See CNSNodeNames for more about display names.
   */
  CNSViews(const LangText &systemNames)
    : names(systemNames), dpIdent(0)
  {
  }

  /**
   * Creates a new views-collection with the specified system names
   * and a pointer to the DpIdentificationProSystem-object it is contained in.
   *
   * If you do not specify a DpIdentificationProSystem here,
   * be aware that the instance might not work correctly as long as you do not
   * supply a pointer to its containing DpIdentificationProSystem.
   *
   * @param systemNames The display names to be used for this system.
   *                    See CNSNodeNames for more about display names.
   * @param parentDpIdent A pointer to the DpIdentificationProSystem which
   *                      contains this object.
   */
  CNSViews(const LangText &systemNames, DpIdentificationProSystem &parentDpIdent)
    : names(systemNames), dpIdent(&parentDpIdent)
  {
  }

  /// Destructor
  ~CNSViews() { }

  /**
   * Returns the view with the specified id, or null if no such view was found.
   * Do not delete the returned pointer.
   */
  CNSView *getView(const ViewId &id);

  /**
   * Returns the view with the specified id, or null if no such view was found.
   */
  const CNSView *getView(const ViewId &id) const;

  /**
   * Returns the view with the specified name, or null if no such view was found.
   * Do not delete the returned pointer.
   */
  CNSView *getView(const char *viewName);

  /**
   * Returns the view with the specified name, or null if no such view was found.
   */
  const CNSView *getView(const char *viewName) const;

  /**
   * Returns the display names to be used for this system.
   */
  const LangText &getSystemNames() const { return names; }

  /**
   * Changes the display names to be used for this system.
   */
  void setSystemNames(const LangText &newNames) { names = newNames; }

  /**
   * Returns a pointer to the DpIdentificationProSystem which contains
   * this object.
   * Do not delete the returned pointer.
   */
  DpIdentificationProSystem *getDpIdentProSystem() { return dpIdent; }

  /**
   * Returns a pointer to the DpIdentificationProSystem which contains
   * this object.
   */
  const DpIdentificationProSystem *getDpIdentProSystem() const { return dpIdent; }

  /**
   * Returns the number of views in this container.
   */
  unsigned int getNumberOfViews() const { return views.getNumberOfItems(); }

  /**
   * Returns the view at the specified index, or null if the index does not exist.
   * Do not delete the returned pointer.
   */
  CNSView *getViewAt(unsigned int index) { return views.getAt(index); }

  /**
   * Returns the view at the specified index, or null if the index does not exist.
   */
  const CNSView *getViewAt(unsigned int index) const { return views.getAt(index); }

  /**
   * Returns the descendant element with the specified relative path,
   * or null if no such element was found.
   *
   * If the given path does not contain a view separator,
   * this method will act like getChild().
   *
   * Filesystem-like path segments such as '.' (current node) and
   * '..' (parent node) are not supported.
   * Examples for valid relative paths are: 'View1', 'View1:Tree1',
   * 'View1:Tree1.Node1', and so on.
   *
   * This method will also take absolute paths, as long as they do not contain
   * a system (e.g. '.View1:Tree1.Node1').
   *
   * Do not delete the returned pointer.
   */
  CNSObject *getDescendant(const char *relativePath);

  /**
   * Returns the descendant element with the specified relative path,
   * or null if no such element was found.
   *
   * If the given path does not contain a view separator,
   * this method will act like getChild().
   *
   * Filesystem-like path segments such as '.' (current node) and
   * '..' (parent node) are not supported.
   * Examples for valid relative paths are: 'View1', 'View1:Tree1',
   * 'View1:Tree1.Node1', and so on.
   *
   * This method will also take absolute paths, as long as they do not contain
   * a system (e.g. '.View1:Tree1.Node1').
   */
  const CNSObject *getDescendant(const char *relativePath) const;

  /**
   * Adds an existing view to the views in this container.
   * If the view is successfully added, the container takes ownership of it.
   *
   * Empty pointers or views with existing names or viewIds will not be added.
   *
   * @return True if the view was added, otherwise false.
   */
  bool addView(CNSView *view);

  /**
   * Removes and deletes the specified view. Be aware that the specified pointer
   * cannot be used after a successful removal.
   *
   * @return False if the view was not found, otherwise true
   */
  bool removeView(const CNSView *view);

  /**
   * Removes the specified view, but does not delete it.
   *
   * @return False if the view was not found, otherwise true
   */
  bool cutView(const CNSView *view);

  /**
   * Deletes all views.
   */
  void clearViews() { views.clear(); }

  /**
   * Invokes the specified visitor for every node in every view
   * of this container.
   *
   * @return PVSS_TRUE if every invocation of the callback returned PVSS_TRUE,
   *         otherwise PVSS_FALSE
   */
  PVSSboolean visitEveryCNSNode(CNSTreeVisitor &visitor) const;

private:
  // avoid generated default methods
  CNSViews(const CNSViews &);
  CNSViews &operator=(const CNSViews &);

  /**
   * Changes the link to the DpIdentificationProSystem this object belongs to.
   * Note that this does not change the ownership of the object,
   * it is still owned by the DpIdentificationProSystem where it is stored.
   */
  void setDpIdentProSystem(DpIdentificationProSystem &newDpIdent) { dpIdent = &newDpIdent; }

  LangText names; // display names for this system
  SimplePtrArray<CNSView> views;
  DpIdentificationProSystem *dpIdent; // the DpIdent.. that contains this object
};

//------------------------------------------------------------------------------
// inline-methods:

inline bool CNSViews::addView(CNSView *view)
{
  if (view && // no nullpointer
      ( *(view->getNamePtr()) != '\0') && // no empty name
      ! getView(view->getNamePtr()) && // unique name
      ! getView(view->getViewId())) // unique id
  {
    views.appendOrInsertSorted(view, CNSView::compare);
    view->setViews(*this);

    return true;
  }

  return false;
}

//------------------------------------------------------------------------------

inline bool CNSViews::removeView(const CNSView *view)
{
  bool found = cutView(view);

  if (found)
  {
    delete view;
    return true;
  }

  return false;
}

//------------------------------------------------------------------------------

inline bool CNSViews::cutView(const CNSView *view)
{
  unsigned int index = views.findPtr(view);

  if (index == (unsigned int)(-1))
  {
    return false;
  }

  views.cutPtr(index);
  return true;
}


#endif // _CNSVIEWS_H_
