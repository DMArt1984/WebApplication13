#ifndef _STRUTIL_H_
#define _STRUTIL_H_

#include <Resources.hxx>

class CharString;
class DynVar;

/** An utility collection for strings. Currently contains two methods.
    @n catgets() to return a value for a key in the catalogue file.
    @n split() to split the CharString into the DynVar instance.
    @classification ETM internal
*/
class DLLEXP_BASICS StrUtil
{
  public:
      
    /** Find the value for a specified key in the catalogue file.
        @param catalogue Catalogue file name. Can be either absolute file path,
        or relative file name, which will be completed according to the 
        pvss standard environment.
        @param msgKey Key to look for in the catalogue file..
        @return CharString with the value associated with the key.
    */
    IL_DEPRECATED("deprecated, use OaStrUtil::catgets() instead")
    static CharString catgets(    // Sucht nach dem Text zum Schluessel <msgKey>
      const CharString &catalogue,// im (sprachabhaengigen) Katalog namens
      const CharString &msgKey
      );                          // <catalogue> und liefert ihn als Funktions-
                                  // wert zurueck. Im Fehlerfall wird eine
                                  // Fehlernachricht zurueckgegeben.
      
    /** Find the value for a specified key in the catalogue file.
        @param catalogue Catalogue file name. Can be either absolute file path,
        or relative file name, which will be completed according to the 
        pvss standard environment.
        @param msgKey Key to look for in the catalogue file.
        @param idx LanguageIdType.
        @return CharString with the value associated with the key.
    */
    IL_DEPRECATED("deprecated, prefer working with GlobalLanguageIdType, rework code to use OaStrUtil::catgets() instead")
    static CharString catgets(    // Sucht nach dem Text zum Schluessel <msgKey>
      const CharString &catalogue,// im (sprachabhaengigen) Katalog namens
      const CharString &msgKey,
      LanguageIdType idx
      );                          // <catalogue> und liefert ihn als Funktions-
                                  // wert zurueck. Im Fehlerfall wird eine
                                  // Fehlernachricht zurueckgegeben.

    /** Find the value for a specified key in the catalogue file.
        @param catalogue Catalogue file name. Can be either absolute file path,
        or relative file name, which will be completed according to the 
        pvss standard environment.
        @param msgKey Key to look for in the catalogue file.
        @param found True if the key exists in the catalogue, false otherwise.
        @param idx LanguageIdType.
        @return CharString with the value associated with the key.
    */
    IL_DEPRECATED("deprecated, use OaStrUtil::catgets() instead")
    static CharString catgets(    // Variante mit Fehlercode-Rueckgabe
      const CharString &catalogue,
      const CharString &msgKey,
      bool &found);

    /** Find the value for a specified key in the catalogue file.
    @param catalogue Catalogue file name. Can be either absolute file path,
    or relative file name, which will be completed according to the
    pvss standard environment.
    @param msgKey Key to look for in the catalogue file.
    @param found True if the key exists in the catalogue, false otherwise.
    @param idx LanguageIdType.
    @return CharString with the value associated with the key.
    */
    IL_DEPRECATED("deprecated, prefer working with GlobalLanguageIdType, rework code to use OaStrUtil::catgets() instead")
    static CharString catgets(    // Variante mit Fehlercode-Rueckgabe
      const CharString &catalogue,
      const CharString &msgKey,
      bool &found,
      LanguageIdType idx);

    /** Split the CharString using the delimiter and store the resulted substrings 
        in the DynVar variable, where each element is a VAR_TEXT.
        @param str CharString to be split.
        @param delim Delimiter string.
        @param strList DynVar where the resulting strings will be stored. The variable
               is reset and allocated a new after each call of the method.
    */
    IL_DEPRECATED("deprecated, use OaStrUtil::split() instead")
    static void split(            // Spaltet die Zeichenkette <str> an allen
      const CharString &str,      // Stellen wo ein in <delim> vorkommendes
      const CharString &delim,    // Trennzeichen steht in ein Array <strList>
      DynVar &strList);           // von Zeichenketten 

    /** Join each element of the DynVar variable into a single CharString
        using the delimiter.
        @param strList DynVar to join into a single CharString.
        @param delim Delimiter string.
        @param str resulting CharString.
    */
    IL_DEPRECATED("deprecated, use OaStrUtil::join() instead")
    static void join(             // Spaltet die Zeichenkette <str> an allen
      const DynVar &strList,      // Stellen wo ein in <delim> vorkommendes
      const CharString &delim,    // Trennzeichen steht in ein Array <strList>
      CharString &str);           // von Zeichenketten 

  protected:

  private:
    StrUtil() {}  //COVINFO LINE: defensive (AP: disallow ctor)
};

#endif /* _STRUTIL_H_ */
