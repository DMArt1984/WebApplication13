#ifndef _BLOBVAR_H_
#define _BLOBVAR_H_

/*
VERANTWORTUNG: Robert Trausmuth
BESCHREIBUNG:
*/

#ifndef _VARIABLE_H_
#include <Variable.hxx>
#endif

#ifndef _CHARSTRING_H_
#include <CharString.hxx>
#endif

#ifndef _BLOB_H_
#include <Blob.hxx>
#endif

/** The BlobVar class. This class represents binary large objects. These objects can hold raw data 
    (including bytes with value '\0') because the data are stored as a blob.
    @see Blob
*/
//author	Robert Trausmuth
class DLLEXP_BASICS BlobVar : public Variable
{
  public:
    /** Constructor.
    */ 
    BlobVar() { cachedIsA = BLOB_VAR; }

    /** Constructor.
        @param init Reference to a variable of type Blob.
   */    
    BlobVar(const Blob &init) : value(init) { cachedIsA = BLOB_VAR; }

    /** Constructor. Data is copied if cp is true.
        @param data Pointer to the data buffer. Keep in mind that data will be copied depending on the third parameter!
        @param len The length of the data pointed to.
        @param cp Set this to PVSS_TRUE when the blob object should copy the data buffer rather than capturing it.
    */
    BlobVar(PVSSuchar *data, PVSSulong len, PVSSboolean cp = PVSS_FALSE) : value(data,len,cp) { cachedIsA = BLOB_VAR; }

    /** Copy constructor.
        @param rVal Source BlobVar value to be copied.
    */  
    BlobVar(const BlobVar &rVal) : Variable(rVal),value(rVal.value) { cachedIsA = BLOB_VAR; }

    /** Declares new and delete operator.
    */
    AllocatorDecl;

    /** Outputs BlobVar value to the itcNdrUbSend stream.
        @param ndrStream Output stream.
        @param cVar Streamed BlobVar variable.
        @return itcNdrUbSend stream.
    */
    friend DLLEXP_BASICS itcNdrUbSend &operator<<(itcNdrUbSend &ndrStream, const BlobVar &cVar);

    /** Receives the BlobVar value from the itcNdrUbReceive stream.
        @param ndrStream Input stream.
        @param cVar BlobVar variable receiving the value from the stream.
        @return itcNdrUbReceive stream.
    */
    friend DLLEXP_BASICS itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream, BlobVar &cVar);

     /** Outputs BlobVar value to the std::ostream.
        @param ofStream Output stream.
        @param bVar Streamed BlobVar variable.
        @return std::ostream stream.
    */ 
    friend DLLEXP_BASICS std::ostream &operator<<(std::ostream &ofStream, const BlobVar &bVar);

    //  friend DLLEXP_BASICS std::ifstream &operator>>(std::ifstream &ifStream, BlobVar &bVar);

    /** Equality operator.
        @param rVal Compared value.
        @return int 1 if the values are equal, otherwise 0.
        @n Important: this operator checks the VariableType, so two objects are equal only if
        they also have the same class (no conversion is done; see other operators)
    */
    virtual int operator==(const Variable &rVal) const;

    /** The less than operator.
        @param rVal Compared value.
        @return int 1 if true, otherwise 0.
        @n Important: this operator also converts the given rVal to its own class-type if needed.
    */
    virtual int operator<(const Variable &rVal) const;

    /** The greater than operator.
        @param rVal Compared value.
        @return int 1 if true, otherwise 0.
        @n Important: this operator also converts the given rVal to its own class-type if needed.
    */
    virtual int operator>(const Variable &rVal) const;

    /** Overloaded assignment operator used for type conversions.
        @param rVal Assigned value.
        @return Variable with assigned value.
    */
    virtual Variable &operator=(const Variable &rVal);

    /** Check if variable is logically true (if value != 0).
        @return PVSS_TRUE or PVSS_FALSE.
    */
    virtual PVSSboolean isTrue() const {if (value.getLen()) return PVSS_TRUE; return PVSS_FALSE;}

    /** Clone the current variable object.
        @return Variable* pointer to a newly created BlobVar with the same value,
        created by the copy constructor.
    */
    virtual Variable *clone() const {return new BlobVar(value);}

    /** Creates a new BlobVar variable.
        @return Variable* pointer to a newly allocated BlobVar created with the
        default contructor (value is 0).
    */
    virtual Variable *allocate() const { return new BlobVar; }

    /** Overloaded function returning BLOB_VAR.
        @return VariableType.
    */
    virtual VariableType isAUncached() const { return BLOB_VAR; }
    
    /** Returns the VariableType for the specified type.
        @param varType VariableType.
        @return VariableType for this type.
    */    
    virtual VariableType isAUncached(VariableType varType) const;
    
    /** Write value to output stream.
        @param ofStream std::ostream to write to.
    */    
    virtual void outToFile(std::ostream &ofStream) const;

    /** Read value from the input stream.
        @param ifStream std::istream to read the value from.
    */
    virtual void inFromFile(std::istream &ifStream);

    /** Format the value acording to the format string
        @param  format  The format string. If the string is not empty it is
                used as an argument to the sprintf function.
                Else a default is used.
        @return The string representation of the value.
    */
    virtual CharString formatValue(const CharString &format) const;

    /** Format the value according to a format string.
        @param format The format string. If the string is not empty is is
               used as an argument to the sprintf function.
               Else a default is used.
        @param target This is a buffer with length len, which is directly written to.
               This method is more performant than the one which returns a CharString,
               because no alloc is done.
        @param len Size of the output buffer.
        @return Number of bytes written into target without 0-byte,
                or a negative value on error (like buffer too small).
    */
    virtual int formatValue(const CharString &format, char *target, size_t len) const;

    /** Get the value of the variable.
        @return Reference to the internally stored Blob value.
    */
    const Blob &getValue() const { return value; }

    /** Set the value of the variable.
        @param newValue Reference to the Blob which will be copied to the private member.
    */
    void setValue(const Blob &newValue) { value = newValue; }

    /** Set the value of the variable.
        @param data PVSSuchar* pointer which will be assigned to the internal Blob variable (shallow copy).
        @param len Length of the data.
    */
    void setValuePtr(PVSSuchar *data, PVSSulong len)
      { value.setData(data, len, PVSS_FALSE); }

    /** Cut the data pointer (set it to zero without deleting).
      @return Original pointer to the data buffer (before cut).
    */
    PVSSuchar *cutValuePtr() { return value.cutData(); }

    // versucht sich selbst in eine Variable "out" vom Typ "to" zu konvertieren
    // Returnwert:    OK: Konvertierung erfolgreich, "out" wurde neu allokiert
    //                OUT_OF_RANGE: Konvertierung grundsaetzlich moeglich, aber der
    //                Wert von "in" liegt ausserhalb des Wertebereichs des Typs "to",
    //                "out" wird trotzdem allokiert !!!! und enthaelt Min bzw. Max des
    //                moeglichen Wertebereichs
    //                CONV_NOT_DEFINED: Typumwandlung nicht moeglich, "out" wird auf 0
    //                gesetzt
    /** Converts the value to a Variable of another type.
        @param to VariableType of the variable converting to.
        @param out VariablePtr to a newly created Variable of the desired type.
        @return OK if correctly converted, OUT_OF_RANGE or CONV_NOT_DEFINED otherwise.
    */
    virtual ConvertResult convert(VariableType to, VariablePtr &out) const;

  private:
    void outNdrUb(itcNdrUbSend &ndrStream) const;
    void inNdrUb(itcNdrUbReceive &ndrStream);
    Blob value;
};

#endif /* _BLOBVAR_H_ */
