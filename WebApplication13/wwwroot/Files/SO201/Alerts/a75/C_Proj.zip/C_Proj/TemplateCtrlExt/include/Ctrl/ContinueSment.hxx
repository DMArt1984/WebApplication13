#ifndef _CONTINUESMENT_H_
#define _CONTINUESMENT_H_

#include <CtrlSment.hxx>
#include <LoopSment.hxx>

/*  author VERANTWORTUNG: Mark Probst   */
/** the continue statement */
class DLLEXP_CTRL ContinueSment : public CtrlSment
{
  public:
    /// Constructor
    ContinueSment(int line, int filenum) : CtrlSment(line, filenum), theLoop(0) {}

    /** Loop condition for this statement.
      * @param aLoop LoopSment for this statement
      */
    void setLoop(const LoopSment *aLoop) { theLoop = aLoop; }

    /** Execute a continue.
      * @return Ptr auf Loop. Shall always be NULL (end of block)
      * @param thread The thread executing this statement
      * @return Next CtrlSment to be executed (NULL equals end of block)
      */
    virtual const CtrlSment *execute(CtrlThread *thread) const;

    virtual void writeTrace(CtrlThread *thread, bool writeValue = true) const;

    /** Is the sment of the specified type ?
      * @param type given type
      * @return TRUE  Sment is of type "type"
      * @return FALSE Sment is not of type "type"
      */
    virtual int isA(SmentType type) const { return (type == SMENT_CONTINUE); }

  private:
    const LoopSment *theLoop;
};

#endif // _CONTINUESMENT_H_

