//
//  $RCSfile$
//  $Locker$
//  $State$
//  $Source$
//
// %Z%JESSI-COMMON-FRAMEWORK 2.0
// %Z%Copyright (C) by Siemens Nixdorf Informationssysteme AG 1992
// %Z%Copyright (C) by Universitaet GH Paderborn 1992
// %Z%Development of this software was partially funded by ESPRIT project 7364.
// %Z%BCM %M% %I% %E%

// This is a -*- C++ -*- file ! 

#ifndef ItcAddress_H
#define ItcAddress_H

//#ifdef __GNUG__
//#pragma interface
//#endif

#define USES_sockets
#define USES_netaddress

#include "ItcStatus.h"
#include "ItcTransport.def"
#include "ItcPrelude.h"

// some forward declarations
struct sockkaddr;

// if you want to use 'operator XX()', XX should/must be a single word !
typedef const char *CONST_CHAR_PTR;
typedef struct sockaddr *SOCKADDR_PTR;
typedef const struct sockaddr *CONST_SOCKADDR_PTR;

/** Address class
*/
class DLLEXP_BCM itcAddress : public itcStatus {
public:
  /// Default constructor.
  itcAddress() { memset(&address, 0, sizeof(address)); }
  /// Constructor.
  itcAddress(const struct sockaddr_storage &addr) { address = addr; }

public:
#ifdef OS_FREEBSD
  /// Returns the size of the address structure.
  int size() const { return address.ss_len; }
#else
  /// Returns the size of the address structure.
  int size() const; 
#endif
  /// Returns the family type of the address.
  int family() const { return address.ss_family; }

  /** Type cast operator.
      Conversion operator for stuffing it in bind, accept, connect calls
  */
  operator SOCKADDR_PTR() { return (SOCKADDR_PTR) &address; }
  /** Type cast operator.
      Conversion operator for stuffing it in bind, accept, connect calls
  */
  operator CONST_SOCKADDR_PTR() const { return (CONST_SOCKADDR_PTR) &address; }

protected:
  /// Internal address structure.
  struct sockaddr_storage address;
};

#ifndef OS_FREEBSD
inline int itcAddress::size() const
{
  switch (address.ss_family)
  {
  case AF_INET :
    return sizeof(struct sockaddr_in);
  case AF_INET6 :
    return sizeof(struct sockaddr_in6);
#ifndef IS_MSWIN__
  case AF_UNIX :
    return sizeof(struct sockaddr_un);
#endif
  default :
    return sizeof(struct sockaddr);
  }
}
#endif

/** Internet address class.
    This is a adress representation for a internet adress, i.e. a sock_addr_in.
    It provides you with constructors for client and server adresses and also 
    with access to the services-database.
    The conversion operators let you call bind, accept, connect just with
    an object of this class.
*/
class DLLEXP_BCM itcInetAddress : public itcAddress {
public:
  /** String constant representing any local host IPv4 address.
      Internally used constant.
  */
  static const char *Any;
  /** String constant representing any local host IPv6 address.
      Internally used constant.
  */
  static const char *Any6;
  /** String constant representing broadcast address (all hosts, for UDP/IP).
      Internally used constant.
  */
  static const char *Broadcast;
  /** String constant representing loopback IPv4 address (local host).
      Internally used constant.
  */
  static const char *Localhost;
  /** String constant representing loopback IPv6 address (local host).
      Internally used constant.
  */
  static const char *Localhost6;

  /** Default constructor.
      Address is initialzed to zero.
      */
  itcInetAddress();
  /** Constructor used for the client address.
      Protocol used is IPPROTO_IP.
      @param hostname Host name string.
      @param port Port number.
  */
  itcInetAddress(const char *hostname, int port);
  /** Constructor used for the the client address.
      @param hostname Host name string.
      @param port Port number.
      @param proto Protocol number. See IPPROTO enumeration for possible values.
  */
  itcInetAddress(const char *hostname, int port, int proto);
  /** Constructor used for the the client address.
      @param hostname Host name string.
      @param service Service name string (e.g. "ftp") or port numeric string (e.g. "4711").
      @param proto Protocol number. See IPPROTO enumeration for possible values.
  */
  itcInetAddress(const char *hostname, const char *service, int proto);
  /** Constructor used for the server address.
      IP address used is "0.0.0.0".
      Protocol used is IPPROTO_IP.
      @param port Port number.
  */
  itcInetAddress(int port);
  /** Constructor used for the server address.
      IP address used is "0.0.0.0".
      @param port Port number.
      @param proto Protocol number. See IPPROTO enumeration for possible values.
  */
  itcInetAddress(int port, int proto);

  /// Constructor which initialized the address according to the input parameter.
  itcInetAddress(const struct sockaddr_storage &addr);

  /** Translation from input parameters into an address.
      This method is used by constructors.
      @param hostname Host name string.
      @param port Port number.
      @param proto Protocol number. See IPPROTO enumeration for possible values.
      */
  int lookup(const char *hostname, int port, int proto);
  /** Translation from input parameters into an address.
      This method is used by constructors.
      @param hostname Host name string.
      @param service Service name string (e.g. "ftp") or port numeric string (e.g. "4711").
      @param proto Protocol number. See IPPROTO enumeration for possible values.
      */
  int lookup(const char *hostname, const char *service, int proto);

  // some access routines...
  /// Returns the hostname.
  const char *hostname() const;
  /// Returns the string representing IP address of the host.
  const char *numeric_hostname() const;
  /// Returns the port number.
  int port() const;
  /// Returns a string with IP address and port in a human readable format
  const char *format_numeric() const;
  /// Returns the any-flag.
  int isany() const { return any_flag; }
  /// Returns the broadcast-flag.
  int isbroadcast() const { return broadcast_flag; }
  /// Returns true if the address is a loopback address,
  /// i.e. one of ("127.0.0.1", "::1", "::ffff:127.0.0.1").
  int isloopback() const { return loopback_flag; }
  /// Returns true if the address family is IPv4 / AF_INET.
  int isipv4() const { return family() == AF_INET; }
  /// Returns true if the address family is IPv6 / AF_INET6.
  int isipv6() const { return family() == AF_INET6; }

  //implementation
  // struct sockaddr_in  address;
  // int      addrlen;

  /// Internal any-flag.
  int      any_flag;
  /// Internal loopback-flag.
  int loopback_flag;
  /// Internal broadcast-flag.
  int       broadcast_flag;
};

/** Unix address class.
    This is a address representation for a `local` adress, i.e. a pathname.
    For your convenience, there is a special method for templates, set_templ()
    and a conversion operator for char*, so that you can put an itcUnixAddress in 
    creat, open, ... call.
*/
#ifndef IS_MSWIN__
class DLLEXP_BCM itcUnixAddress : public itcAddress {
public:
  /// Any address (system defined pathname)
  static const char * const Temp;
  /** Default constructor, used only to set the path with set() or set_templ() later.
      The object status is set to state ItcWarning - Itc_Tp_No_Path_Given.
  */
  itcUnixAddress();
  /// Constructor.
  itcUnixAddress(const char *pathname);

// some access routines...
  /** Set path.
   * @param pathname: the path name
   * @returns 0 if path is too long.
  */
  int set(const char *pathname);
  /** Set path with a printf()-like format string.
      @param templ a format string that will use the following variable argument list to create a pathname.
      @return 0 if the path is too long.
      @see printf
  */
  int set_templ(const char *templ,...);
  /// Returns the path.
  const char *pathname() const;

  /** Max Unix path.
      The pathlength of a unix domain socket cannot exceed this const.
      */
  static const size_t Max_SockUnix_Pathlen;

  /** Type cast operator.
      Conversion operators for stuffing it in bind, accept, connect or mknod calls.
  */
  operator char*() { return (char*) pathname(); }
  /** Type cast operator.
      Conversion operators for stuffing it in bind, accept, connect or mknod calls.
  */
  operator CONST_CHAR_PTR() { return pathname(); }

// implementation
  // struct sockaddr_un  address;
  // int      addrlen;
};
#endif

#endif /* ItcAddress_H */
