#ifndef _VectorVar_H_
#define _VectorVar_H_

// Martin Koller, March 2019

#include <CtrlVariable.hxx>
#include <SimplePtrArray.hxx>
#include <TypeSpec.hxx>

#ifdef LIBS_AS_DLL
  template class DLLEXP_CTRL SimplePtrArray<Variable, CapacityStorage<Variable>>;
#endif

/**
  A dynamic size array; an alternative to the dyn_ types

  This type differs from the dyn_ types in the following ways:
  - it's index-0 based
  - its definition is like a template, passing the type it shall hold in <>, e.g. vector<int>
  - it's arbitrarily nestable, e.g. vector< vector< shared_ptr<MyClass> > >

  @classification ETM internal
*/
class DLLEXP_CTRL VectorVar : public CtrlVariable
{
  public:
    VectorVar(VariableType varType = NO_VAR) : typeSpec(varType) { cachedIsA = VECTOR_VAR; }
    VectorVar(const TypeSpec &spec, int fileNumber);
    VectorVar(const VectorVar &other) = delete;

    ~VectorVar() override;

    VariableType isAUncached() const override { return VECTOR_VAR; }
    VariableType isAUncached(VariableType varType) const override;

    AllocatorDecl;

    const TypeSpec &getTypeSpec() const { return typeSpec; }

    Variable *clone() const override;
    Variable *allocate() const override;

    PVSSboolean isTrue() const override;

    // assign given Variable if possible, else return false (and optionally set an exception into thread)
    bool assign(const Variable &rVal, CtrlThread *thread = 0) override;

    int operator==(const Variable &rVal) const override;
    Variable &operator=(const Variable &rVal) override;

    ConvertResult convert(VariableType to, VariablePtr &out) const override;

    //CharString formatValue(const CharString &format) const override;  // does not make sense. Use jsonEncode() instead

    unsigned int getNumberOfItems() const { return items.getNumberOfItems(); }
    void clear() { items.clear(); }
    void cutAll() { items.cutAll(); }

    Variable *getAt(unsigned int idx) const { return items[idx]; }
    Variable *takeFirst() { return items.cutFirst(); }
    Variable *takeLast() { return items.cutLast(); }
    Variable *takeAt(unsigned int idx) { return items.cutPtr(idx); }

    bool append(Variable *var);
    bool insert(unsigned int idx, Variable *var);
    bool replace(unsigned int idx, Variable *var);
    void remove(unsigned int idx) { items.remove(idx); }

    enum SortOrder { SORT_ASCENDING, SORT_DESCENDING };
    using Comparator = SimplePtrArray<Variable, CapacityStorage<Variable>>::Comparator;

    void sort(SortOrder sortOrder = SORT_ASCENDING);
    void sort(const Comparator &comp);

    void unique();
    void unique(const Comparator &comp);

  private:  // methods
    bool typeMatches(const Variable *var) const;

  private:  // members
    TypeSpec typeSpec;
    SimplePtrArray<Variable, CapacityStorage<Variable>> items;
    bool refCounting = false;
    bool isSorted = false;

    struct StdComparator : public Comparator
    {
      StdComparator(VectorVar::SortOrder order = SORT_ASCENDING) : sortOrder(order) { }
      int compare(const Variable *v1, const Variable *v2) const override;
      VectorVar::SortOrder sortOrder;
    };
};

#endif
