#ifndef _CONSTEXPR_H_
#define _CONSTEXPR_H_

#include <CtrlExpr.hxx>
#include <Variable.hxx>
#include <TextVar.hxx>
#include <Allocator.hxx>

/*  author VERANTWORTUNG: Martin Koller */
/** Beinhaltet einen konstanten Wert */
class DLLEXP_CTRL ConstExpr : public CtrlExpr
{
  public:
    AllocatorDecl;

    /// Returns the type of the Expression
    virtual ExprType isA() const { return CONST_EXPR; }

    /// Constructor
    ConstExpr(Variable *newVar, int line = -1, int file = -1)
      : CtrlExpr(line, file), var(newVar)
      {
        if (var && var->isA() == TEXT_VAR)
        {
          ((TextVar *) var)->getString().setHashValue();
          ((TextVar *) var)->getString().shareString();
        }
      }

    /// Destructor
    virtual ~ConstExpr();

    /** @return immer != NULL Ptr auf Konstante */
    virtual const Variable *evaluate(CtrlThread *) const { return var; }

    virtual void writeTrace(CtrlThread *thread, bool writeValue = true) const;

    /// cut stored variable and return it
    Variable *cutVar() { Variable *v = var; var = 0; return v; }

    virtual CharString toString() const;

  private:
    Variable *var;
};

#endif /* _CONSTEXPR_H_ */
