// DATEIBESCHREIBUNG ==============================================================
// DATEINAME:     DpConnectConfig.hxx
//
//
// AENDERUNGS-HISTORIE
// Ver.  | Datum      | Aenderungen                            | ModNr.| Autor
// ------+------------+-----------------Anfang-----------------+-------+-----------
//   1.0 |            | 1.Erstellung mit Westmount-OMT         |     0 |
// ======================================Ende======================================
#ifndef _DPCONNECTCONFIG_H_
#define _DPCONNECTCONFIG_H_

// Forward declaration
class DpConnectConfig;

#include <Types.hxx>
#include <DpConfig.hxx>
#include <PtrList.hxx>
#include <ConnDpIdCnt.hxx>
#include <DpIdentifier.hxx>

#include <set>
#include <ostream>

/// This class implements the functionality of the DpConfig of type
/// DPCONFIG_CONNECTION. Its core competence consists of maintaining
/// the list of DpIdentifiers, where DpIds can be added or removed.
/// The class also counts how many times they were added, which is
/// accomplished by the class ConnDpIdCnt, encapsulating DpId and its
/// count.
class DLLEXP_CONFIGS DpConnectConfig : public DpConfig 
{
private:
  // disable warning: 'std::set<_Ty>' needs to have dll-interface
# ifdef WIN32
#   pragma warning ( push )
#   pragma warning ( disable: 4251)
# endif

  static std::set<const DpConnectConfig *> configList;

# ifdef WIN32
#   pragma warning ( pop )
# endif

public:
  static void reportStatus(std::ostream &os, bool summary);

public:
  
  /// Constructor
  DpConnectConfig();
  
  /// Destructor
  ~DpConnectConfig();

  /// Equal-to operator
  /// @param rVal DpConfig this instance will be compared with
  /// @return This implementation does nothing and returns 0
  int operator==(const DpConfig &rVal) const;

  /// Assignment operator. It will copy the internal list of DpId's (connIdList)
  /// @param rVal Assigned value
  /// @return Reference to this containing the assigned value
  DpConfig &operator=(const DpConfig &rVal);

  /// Assignment operator. Just calls the second version of the operator.
  /// @param rVal Assigned value
  /// @return Reference to this containing the assigned value
  DpConnectConfig &operator=(const DpConnectConfig &rVal)
    { operator=((const DpConfig &) rVal); return *this; }

  /// Gets config type
  /// @return DPCONFIGNR_CONNECTIONINFO
  DpConfigNrType getDpConfigNrUncached() const;

  /// Allocate new instance with default constructor
  /// @return Pointer to an allocated instance
  DpConfig*      allocate() const;

  /// Gets own variable type
  /// @return DPCONFIG_CONNECTION
  DpConfigType   isA() const;

  /// Checks if the DpConfigType matches this instance
  /// @param configType DpConfigType to check
  /// @return DPCONFIG_CONNECTION or base class value DpConfig::isA()
  DpConfigType   isA(DpConfigType configType) const;

  /// Gets sizeof() of this class
  /// @return Size in bytes
  virtual unsigned long sizeOf() const;

  /// Outputs the instance to the stream. Note: The implementation does nothing,
  /// only sets ErrClass::ILLEGALFUNCALL error.
  /// @param ndrStream itcNdrUbSend output stream
  void           outNdrUb(itcNdrUbSend &ndrStream) const;

  /// Reads the instance from the stream. Note: The implementation does nothing,
  /// only sets ErrClass::ILLEGALFUNCALL error.
  /// @param ndrStream itcNdrUbReceive input stream
  void           inNdrUb(itcNdrUbReceive &ndrStream);

  /// Add DpIdentifier in the connIdList list. If the identifier already exist
  /// in the list, just increments its count.
  /// @param dpId DpIdentifier to be added to the list
  /// @return PVSS_TRUE
  PVSSboolean    addDpIdentifier(const DpIdentifier &dpId);

  /// Removes DpIdentifier from the connIdList list. If the identifier was added
  /// more than once, the method will only decrements the count by one and keep
  /// the dpId in the list
  /// @param dpId DpIdentifier to be removed from the list
  /// @return PVSS_TRUE if dpId was removed successfully, PVSS_FALSE if dpId wasn't
  /// in the list before calling this method.
  PVSSboolean    removeDpIdentifier(const DpIdentifier &dpId);

  /// Checks if DpIdentifier was inserted to the list
  /// @param dpId DpIdentifier to be checked
  /// @return Pointer to the ConnDpIdCnt class, which holds the dpId along with the
  /// counter for how many times it was added. Returns null pointer if dpId is not
  /// in the list.
  ConnDpIdCnt*   isInDpIdentifierList(const DpIdentifier &dpId);

  /// Checks if the DpIdentifier list is empty
  /// @return PVSS_TRUE if list is empty, PVSS_FALSE if it contains element(s)
  PVSSboolean    isEmpty() const;

  /// Gets the first DpIdentifier in the list
  /// @param lPtr Reference to the pointer to ConnDpIdCnt class. If the list is not
  /// empty, after this method call it will contain pointer to the ConnDpIdCnt class
  /// related to the first DpId. This reference can then by used in the subsequent
  /// calls to the getNextDpId() method, to get all stored DpIdentifiers.
  /// @return Pointer to the first DpIdentifier in the list, or 0 if list is empty.
  const DpIdentifier  *getFirstDpId(ConnDpIdCnt* &lPtr) const;

  /// Gets the next DpIdentifier in the list
  /// @param lPtr Reference to the pointer to ConnDpIdCnt class. Use the same reference
  /// as passed to the getFirstDpId() or to the previous call to getNextDpId() to get the
  /// next DpId.
  /// @return Pointer to the next DpIdentifier in the list, or 0 if there are no more
  /// elements.
  const DpIdentifier  *getNextDpId(ConnDpIdCnt* &lPtr) const;

  /// Get the number of connections hold by this config
  PVSSulong getConnectCount() const;

  /// Print debug info
  void reportStatus(std::ostream &os) const;

protected:
private:
  /// List of ConnDpIdCnt*, encapsulating the DpIds and their count
  PtrList    connIdList;
};

// ================================================================================
// Inline methods
// ================================================================================

inline PVSSboolean DpConnectConfig::isEmpty() const
{
	return (connIdList.getNumberOfItems()) ? PVSS_FALSE : PVSS_TRUE;
}

inline unsigned long DpConnectConfig::sizeOf() const
{
  return sizeof(DpConnectConfig);
}

#endif /* _DPCONNECTCONFIG_H_ */
