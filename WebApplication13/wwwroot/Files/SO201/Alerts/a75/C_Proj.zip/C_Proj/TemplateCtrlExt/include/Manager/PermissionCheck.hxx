#ifndef _PERMISSIONCHECK_H_
#define _PERMISSIONCHECK_H_

#include <ErrClass.hxx>
#include <DpIdentifier.hxx>
#include <AlertAttrList.hxx>
#include <ManagerIdentifier.hxx>
#include <Bit32.hxx>

class DpAuth;
class AlertClass;

class DLLEXP_MANAGER PermissionCheck
{
  public:
    enum What
    {
      // Create = 0x1,
      Read   = 0x2,
      Write  = 0x4,
      // Delete = 0x8
    };

  public:
    // Check if this DpId has to check separately from its config
    static bool needsSpecialPermission(const DpIdentifier &dpId);

  public:
    PermissionCheck() {}
    virtual ~PermissionCheck() {}

  public:
    ErrClass::ErrCode permitted(What what, const DpIdentifier &dpId, PVSSuserIdType user, const ManagerIdentifier &manId, Bit32 permissions = 0);

    ErrClass::ErrCode permitted(What what, const AlertAttrList &aal, PVSSuserIdType user, const ManagerIdentifier &manId, Bit32 permissions = 0);

  protected:
    // Check _auth permission. Return true if _auth was found
  bool checkConfigAuth(What what, const DpIdentifier &dpId, PVSSuserIdType user, const ManagerIdentifier &manId, Bit32 permissions, ErrClass::ErrCode &err);
    
    // Check _System.Auth.DpConfig permission. Return true if value was found
  bool checkGlobalAuth(What what, const DpIdentifier &dpId, PVSSuserIdType user, const ManagerIdentifier &manId, Bit32 permissions, ErrClass::ErrCode &err);

    // Compare ManagerIdentifiers
    bool sameManagers(const ManagerIdentifier &first, const ManagerIdentifier &second) const;

  protected:
    // Read permission level of _auth, recursing up if necessary. Return true if _auth was found
    virtual bool getConfigAuthValue(What what, const DpIdentifier &dpId, PVSSuchar &perm, PVSSulong &owner, PVSSuchar &operm) = 0;

    // Read permission level of _System.Auth.DpConfig. Return true if value was found
    virtual bool getSystemAuthValue(What what, int cfgNr, PVSSuchar &perm) = 0;
};
#endif