// DATEIBESCHREIBUNG ==============================================================
// DATEINAME:     ConnDpIdCnt.hxx
//
//

#ifndef _CONNDPIDCNT_H_
#define _CONNDPIDCNT_H_

#include <Types.hxx>
#include <PtrListItem.hxx>
#include <DpIdentifier.hxx>

/// This class encapsulates a DpIdentifier instance with the counter,
/// which can be incremented or decremented. List of the ConnDpIdCnt
/// instances is used in the DpConnectConfig class.
class DLLEXP_CONFIGS ConnDpIdCnt : public PtrListItem
{
public:

  /// Constructor
  ConnDpIdCnt();

  /// Constructor. The counter will be set to 1
  /// @param id DpIdentifier to be set in the dpId member
  ConnDpIdCnt(const DpIdentifier& id);

  /// Copy constructor
  ConnDpIdCnt(ConnDpIdCnt& obj);
  
  /// Sets the new DpIdentifier. The counter is not modified.
  /// @param id DpIdentifier to be set in the dpId member
  void            setDpIdentifier(DpIdentifier& id);

  /// Gets the internally stored DpIdentifier
  /// @return dpId member
  DpIdentifier&   getDpIdentifier()  { return dpId; }

  /// Increment the counter
  void            addConnection()    { connCnt++; }

  /// Decrement the counter (if it is higher than zero)
  void            subConnection()    { if (connCnt) connCnt--; }

  /// Gets the counter value
  /// @return connCnt member with the counter value
  PVSSushort        getConnCnt()       { return connCnt; }

private:
  
  /// Internally stored DpIdentifier
  DpIdentifier dpId;

  /// Counter
  PVSSushort     connCnt;
};


#endif
