#ifndef _CONTROLLER_H_
#define _CONTROLLER_H_

#include <time.h>
#include <string.h>
#include <Types.hxx>
#include <ScriptId.hxx>
#include <ExecReturn.hxx>
#include <CtrlVarList.hxx>
#include <TimeVar.hxx>
#include <SimplePtrArray.hxx>
#include <DynPtrArray.hxx>
#include <CtrlDbg.hxx>
#include <CtrlScript.hxx>
#include <ExternData.hxx>
#include <BaseExternHdl.hxx>
#include <ErrClass.hxx>
#include <DebugOutput.hxx>

#include <iostream>

class ExternHdl;
class CharString;
class CtrlThread;
class DpHLGroup;
class DoneCB;
class CtrlSment;
class CtrlFunc;
class Variable;
class AlertAttrList;
class DpMsgAnswer;
class SysMsg;
class TextVar;
class DynVar;
class DpIdentList;
class UserType;
class LangTextVar;
class ClassVar;

typedef struct
{
  const char *name;
  int      type;
  PVSSlong value;
} CtrlTokenOrConstStruct;

// scope-library (panel-global lib)
struct ScopeLib
{
  ScopeLib(ScopeId theId) : scope(theId), script(0) {}
  ~ScopeLib() { delete script; }

  static int compareScopeId(const ScopeLib *item1, const ScopeLib *item2);

  ScopeId scope;
  CtrlScript *script;
};

#ifdef WIN32
  #pragma warning ( push )
  #pragma warning ( disable: 4231 )
#endif

#if defined(LIBS_AS_DLL)
  EXTERN_CTRL template class DLLEXP_CTRL DynPtrArray<CtrlScript>;
#if PVSS_VERS < 400000
  inline DynPtrArrayIndex DynPtrArray<CtrlScript>::deepCopy(const DynPtrArray<CtrlScript> &) {return 0;}
#endif

  EXTERN_CTRL template class DLLEXP_CTRL DynPtrArray<ScopeLib>;
  EXTERN_CTRL template class DLLEXP_CTRL DynPtrArray<CtrlVarList>;
#endif

#ifdef WIN32
  #pragma warning ( pop )
#endif


/*  author Martin Koller */
/** This is the central CTRL object which manages all CTRL scripts.
    There is only one instance of this object in any manager, which
    is accessible via the static Controller::thisPtr
*/
class DLLEXP_CTRL Controller
{
  /// @internal Einsprungpunkt in Lex-Code
  friend int yylex();
  /// @internal Einsprungpunkt in Yacc-Code
  friend int yyparse();

  /// @internal
  friend void yyerror(const char *);

  /// @internal
  friend class CtrlDbg;   // for the CTRL-Debugger

  public:
    /** registers all supported report flags with Resources
      * Call this before you call Resources::printHelpReport() in your main program
      * There is no need to already have a Controller object
      */
    static void registerReportFlags();

    /** constructor
      * @param ext die Klasse ExternHdl kann abgeleitet und neu Implementiert werden.
      *            gemacht wird das z.B. vom UI
      */
    Controller(BaseExternHdl *manHdl, ExternHdl *stdExtHdl);

    /// destructor
    ~Controller();

    /// gets the Extern-Handler for non-user-defined functions
    BaseExternHdl *getExternHdl() const { return extHdl; }
    ExternHdl *getStdExternHdl() const;

    /** load and instantiate a CTRL extension from the given path
        @internal used in the script editor
    */
    void loadExtension(const CharString &path);

    /** if we have to re-read the libCTRL it does so; returns whether libs have been updated:
        -1 .. libs have to be updated, but currently not possible because libs are in use
         0 .. no update needed
         1 .. libs have been updated
     */
    int checkLib();

    /** @name Script Parsing */
    //@{
    /** Check the Syntax of a Script by calling parseScript()
      * @return PVSS_TRUE if syntax is correct, else PVSS_FALSE.
      * @param script IN : the script that is to check
      * @param errpos OUT: points to the char which produced the error
      */
    static PVSSboolean syntaxOK(const CharString &script, PVSSlong &errpos, CtrlThread *thread = 0);

    /** Check the Syntax of a Script by calling parseScript()
      * @return PVSS_TRUE if syntax is correct, else PVSS_FALSE.
      * @param script IN : the script that is to check
      * @param errpos OUT: points to the char which produced the error
      * @param filename IN : file name of file that contains script to check
      */
    static PVSSboolean syntaxOK(const CharString &script, PVSSlong &errpos, const CharString &filename);

    /// @internal used in the script editor
    static PVSSboolean syntaxOK(const CharString &script, PVSSlong &errpos, ExternData *clientData);

    /// values for the captureClientData parameter in checkIn()
    enum
    {
      /// do not capture given clientData pointer; you will need to delete the object
      DONT_CAPTURE_CLIENT_DATA = PVSS_FALSE,

      /// Controller captures the clientData pointer and takes over ownership
      CAPTURE_CLIENT_DATA = PVSS_TRUE
    };

    /// values for the startMain parameter in checkIn()
    enum
    {
      /// do not start the main() function; args is unused in this case
      DONT_START_MAIN = PVSS_FALSE,

      /// start the main() function, using args as function parameters
      START_MAIN = PVSS_TRUE
    };

    /// values for the delWhenDone parameter in checkIn()
    enum
    {
      /// the script will be kept in Controller for a later restart when it has finished
      KEEP_WHEN_DONE = PVSS_FALSE,

      /// the script will be deleted (checked out) when it has finished
      DEL_WHEN_DONE = PVSS_TRUE
    };

    /** parse and register a CTRL script given as sourcecode in a string.
        @return script-Id with which you can checkOut() the script again
          or -1 when the script could not be parsed (syntax error)
          or -2 when the script could not be executed (no main() found)
          or -3 when the script has already finished its execution during this function call,
          e.g. when the script only contains one statement and there were no connections
          (e.g. dpConnects(), ...) established.

        @param script     IN: Script sourcecode as string
        @param subst      IN: The $-Parameter for the script
        @param clientData IN: User data (Panel, Button...) behind the script
        @param args       IN: arguments to the main() function
        @param startMain  IN: if DONT_START_MAIN, the script will be parsed and stored for a later
          call to startFunc() and also this script does not need to have a "main()" function
          and the args-pointer can be 0, because it is not used
        @param captureClientData IN: if CAPTURE_CLIENT_DATA, the Controller will be responsible for this pointer
          and will delete it when it is no more used
        @param delWhenDone IN: if DEL_WHEN_DONE delete the script after it is finished
      */
    ScriptId checkIn(
      const CharString &script,
      const DynVar &subst,
      ExternData *clientData,
      const Variable *args = 0,
      PVSSboolean captureClientData = DONT_CAPTURE_CLIENT_DATA,
      PVSSboolean startMain = START_MAIN,
      PVSSboolean delWhenDone = KEEP_WHEN_DONE);

    // As checkIn() but never starts main and returns the CtrlScript pointer
    CtrlScript *checkInScript(
      const CharString &script,
      const DynVar &subst,
      ExternData *clientData,
      const Variable *args = 0,
      PVSSboolean captureClientData = DONT_CAPTURE_CLIENT_DATA,
      PVSSboolean delWhenDone = KEEP_WHEN_DONE);

    /** genau wie checkIn() nur wird hier ein Filename uebergeben. Das File muss in
      * Resources::scriptsDir stehen
      * Einziger Unterschied: Das script wird als "fire and forget" script eingecheckt,
      * d.h. es wird, wenn es vollstaending abgearbeitet wurde, automatisch ausgecheckt.
      * Ebenfalls wird clientData nach Beendigung deleted
      *return-value: <0 .. error oder schon fertig, >=0 .. OK
      */
    ScriptId checkInFile(const CharString &file, const DynVar &subst, ExternData *clientData,
                         const Variable *args = 0);

    /// syntax check
    bool checkIntegrity(DynVar &errors, const CharString &script, const DynVar &subst, ExternData *clientData);

    /** check-In for a scope-library. This is also searched for functions and variables
        from a script, which has the same scopeId as given in ExternData.
        Used for panel-global libs.
        @internal used for OO Panels
      */
    CtrlScript *checkInScopeLib(const CharString &lib, const DynVar &subst, ExternData &clientData,
                                CtrlVarList *specialVars = 0);

    /** run global script var initializers in a scope-library.
        Used for panel-global libs.
        @internal used for OO Panels
      */
    void initScopeLib(CtrlScript *script);

    /** check-out the scope-library with the given scope
       ATTENTION: Only check out this lib, AFTER all scripts with this scopeId have
       been checked out (the scripts store pointers to functions into this lib)
       @internal used for OO Panels
     */
    void checkOutScopeLib(ScopeId scope);
     //@}

    /** @name Script starten/ausfuehren */
    //@{
    /** Starten eines frueher eingechecktes Scripts.
      * d.h. es wird wieder die main() function exekutiert
      * @return
      *  EXEC_ERROR wenn es die id nicht gibt
      *   EXEC_DONE wenn das script vollstaendig abgearbeitet wurde
      *  und es keine Verbindungen zwischen functions und Dp's gibt
      *   EXEC_OK wenn entweder noch ein thread laeuft, oder es Verbindungen gibt
      */
    ExecReturn start(ScriptId id, const Variable *args = 0) const;

    /** start the named function in the given script. On exit of the function, execute the DoneCB
      * @param args arguments which will be made available to the called function.
                    This can either be a pointer to any Variable subclass if you pass only one
                    value or it can be a pointer to a RecVar holding more parameters for the function.
      * @param done an object created via "new" which will be executed when the given function
                    has completed. DoneCB::execute() will be called with the value the function returns
                    with the "return" statement.
                    Controller takes ownership of the DoneCB object and will delete it
      */
    ExecReturn startFunc(ScriptId id, const CharString &funcName,
                         const Variable *args = 0, DoneCB *done = 0) const;

    /**
      execute @func (as new thread in @script) synchronously from @thread and on finish
      set back the return value and reference parameters into given @argList
      @funcParamsToSkip when the caller passes more @args than refer to the @argList (generated/userData),
        this is the number to ignore as function parameters
      @internal used for OO Panels
    */
    ExecReturn execFunc(CtrlScript *script, CtrlFunc *func, const Variable *args, CtrlThread *thread,
                        ExprList *argList, CtrlExpr *firstArgInList, int funcParamsToSkip = 0, ClassVar *object = nullptr);
    /**
      Starts function in @scopeId scopeLib and adds a wait object to the given @thread waiting
      for the started function to finish and setting back reference parameters.
      @argList pointer to the expressions used as arguments to start the function (for reference parameters)
      @firstArgInList where to start in argList for the first argument to the started function
      @internal used for OO Panels
    */
    ExecReturn execPublicFunc(ScopeId scopeId,
                              const CharString &funcName, const Variable *args, CtrlThread *thread,
                              ExprList *argList, CtrlExpr *firstArgInList);

    /** Allow Controller to work a while on all scripts.
      * Every statement has a weight.
      * Resources::ctrlMaxWeight sets the maximum sum of all weights for one call
      */
    ExecReturn work();
     //@}

    /** remove a script from Controller.
      * Running threads will be stopped and deleted. All dpConnects() etc. will be disconnected.
      */
    void checkOut(ScriptId id);

    /** Check, if any threads or modules are active for the scripts.
      * Check scripts with ScriptIds within
      * the range [from, to] (ScriptId values "from" and "to" are included!)
      * check also [optional] for "connect" answers
      */
    PVSSboolean areScriptsActive(ScriptId from, ScriptId to, PVSSboolean ignoreAnswers = PVSS_FALSE) const;

    /// tells, when we have to call work() again
    TimeVar &nextWork();

    /** es wird jeder Wert einzeln aus der AnswerMsg dem angegebenen Script uebergeben.
      * (wie dpValueChanged, nur sind die Werte aus der AnswerMsg historische Daten)
      * ACHTUNG: es wird nur die erste gefundene connection mit den Werten beschickt
      * Der optionale DoneCB wird vom Controller selbst wieder deleted
      * ---- Toter Code!!!!:
      @internal
     */
    void splitPeriodAnswer(DpMsgAnswer &msg, const DpIdentList &dpList,
                           ScriptId id, DoneCB *doneCB = 0);


    /** @name LoopStack for the Parser
      * the Controller keeps a stack of statements which can be jumped out
      * by a break. the stack is used by the parser.
      @internal
      */
    //@{
    ///
    void pushLoop(CtrlSment *theLoop);
    ///
    CtrlSment *topLoop();
    ///
    void popLoop();
    //@}

    /** assigns value to target and eventually converts TextVar/DpIdentifierVar
      * @return PVSS_TRUE if it was successful, else PVSS_FALSE
      */
    static PVSSboolean assign(Variable *target, const Variable *value,
                              const ExternData *extData, const CharString &func,
                              CtrlThread *thread = 0);

    /** searches the given function.
      * @param which function name to look for
      * @param start look in the given script, but see below
      * @param filenum is used to check in which other libs we are allowed to search
      * Definition:
      * -1   ... script    (is allowed to search in own script, scope lib, libs)
      * -2   ... scope lib (is allowed to search in own scope lib and all other libs)
      * >= 0 ... CTRL lib  (is allowed to search only in own or other libs)
      */
    CtrlFunc *findFunc(const CharString &which, CtrlScript *start, int filenum = -1) const;
    /// @internal
    enum { SCOPELIB_FILENUM = -2 };

    /// @internal same as findFunc() but for user defined types
    UserType *findUserType(const CharString &which, CtrlScript *start, int filenum = -1) const;

    /// @internal same as findFunc() but for user defined type aliases
    TypeAlias *findTypeAlias(const CharString &which, CtrlScript *start, int filenum = -1) const;

    /** @name ScriptCounter
      * increase/decrease number of active CtrlScripts
      * ( scripts which need time in work() )
      @internal
      */
    //@{
    ///
    void incScriptCount() { scriptCount++; }
    ///
    void decScriptCount() { scriptCount--; }

    int getActiveScriptCount() const { return scriptCount; }
    //@}

     /** @name $-Parameter Handling */
    //@{
    /** Get the list of substitutional parameters.
      * Get ($x) as a DYNTEXT_VAR in dollars
      * The parsed parameters will be _appended_ to the given list
      * returns PVSS_TRUE if the syntax is ok, else PVSS_FALSE
      */
    static PVSSboolean getDollarList(const CharString &script, DynVar &dollars);

    /** parse string and return string with $-params substituted.
      * string can be of the form: "string"+$1  (or also:  string+$1 ... ignoring ")
      * @return PVSS_TRUE, PVSS_FALSE
      * @param target OUT: Ergebnis der Ersetzung
      * @param source IN:  zu ersetzender wert z.B. $name
      * @param dyn    IN:  liste aller Ersetzungen z.B. "$name:V1" "$pos:10" ...
      */
    static PVSSboolean substitute(  // Returns PVSS_TRUE, PVSS_FALSE
      CharString &target,           // out: Ergebnis der Ersetzung
      const char *source,           // in : zu ersetzender wert z.B. $name
      const DynVar &dyn,            // in : liste aller Ersetzungen z.B. "$name:V1" "$pos:10" ...
      SimplePtrArray<ErrClass> *errors = 0);

    /** find the given "$xxx" string in the DynVar (recursive).
      * do also a recursive search if
      * the DynVar holds again a "$xxx:$yyy"
      * bCheck controls the behaviour of the function
      *        0 - throw error and get the value
      *        true - silent mode, need no value (-> isDollarDefined())
      *        false - silent mode, need value   (-> getDollarValue())
      * return the value of the $xxx parameter (wird von substitute verwendet)
      */
    static const char *getSubstValue(const char * &source, const DynVar &dyn, int recurs = 0,
                                     PVSSboolean *bCheck = 0, SimplePtrArray<ErrClass> *errors = 0);

    /// parse string and return all $x parameters.
    static void getDollarsFromString(const char *source, DynVar &dollarList);
    //@}

    /// the access pointer to the Controller singleton instance
    static Controller *thisPtr;

    /** @name global variable handling
        @internal
     */
    //@{
    ///
    bool addGlobal(CtrlVar *var);    // captures CtrlVar!
    ///
    bool removeGlobal(const CharString &name);
    ///
    Variable *findGlobal(const CharString &name) const;
    ///
    CtrlVar *findGlobalCtrlVar(const CharString &name) const;
    ///
    CtrlVar *findGlobalCtrlVar(CtrlVarId id) const;

    const CtrlVarList &getGlobalVars() const { return globalVars; }

    // get the scope-lib with given scopeId, or 0 if not found
    CtrlScript *getScopeLib(ScopeId scope) const;

    // e.g. for mobile UI, avoid access to files outside the project
    void setSandboxed(bool on);
    bool isSandboxed() const;
    bool isAllowedPath(const CharString &path) const;

    // returns a clean absolute path (resolving also "." or "..")
    // When a relative path is given, it is created as being relative to the PROJ_PATH
    static CharString absolutePath(CharString path);
    //@}

    /// Get the CtrlScript from a ScriptId
    CtrlScript *getCtrlScript(ScriptId id);

    /// @internal
    void setNextWork(const TimeVar &nextWork) { nextWork_ = nextWork; }

    /// give me the keywords and constants
    static void getCtrlTokenOrConst(CtrlTokenOrConstStruct *& ctc, int &count);

    /// return the number of currently loaded CTRL libs
    int getLibCount() const;

    /** return the CtrlScript pointer to one of the currently loaded CtrlLibs
      * @param idx must be in range 0..getLibCount()-1
      */
    const CtrlScript *getLibScript(int idx) const;

    /** return the file name of one of the currently loaded CtrlLibs
      * @param idx must be in range 0..getLibCount()-1
      */
    CharString getLibFileName(int idx) const;

    /// @internal Read the library files. This function must be called before parsing any scripts
    void readLibs();

    /// @internal decrease library reference counter
    void incLibRefCount(int idx);

    /// @internal decrease library reference counter
    void decLibRefCount(int idx);

    /// @internal
    CtrlDbg &getDebugger() { return debugger; }

    /// @internal
    bool checkDebugger() const { return debugger.mightWait(); }

    /// @internal
    bool debugWait(CtrlThread *thread);

    /// @internal write an overview-report of the internal state to std::ostream (for -report option)
    static void writeReport(std::ostream &to);

    /// @internal
    struct ParseError
    {
      CharString text;
      CharString lastToken;
      int position;
      int line;
      int column;
    };

    /// @internal
    static const CharString &getParseErrorDescription() { return parseError.text; }

    /// @internal
    static const ParseError &getParseError() { return parseError; }

    /// parse control script
    static PVSSboolean parseScript(const CharString &source,
                                   CtrlScript *script,
                                   DynVar *dollars = 0,
                                   const DynVar *subst = 0,
                                   int filenum = -1);

    /// @internal (e.g. for script editor)
    static bool parseScriptRelaxed(const CharString &source, CtrlScript &script, DynVar *dollars = 0, int filenum = -1);

    /// @internal: store pointer to last thread where we wrote trace output
    void setLastTraceWritten(CtrlThread *thread) { lastTraceWritten = thread; }

    /// @internal
    CtrlThread *getLastTraceWritten() const { return lastTraceWritten; }

#ifdef WCCOA_STATIC_PLUGINS
    void registerStaticExtension(const CharString &pluginName, newBaseExternHdlFunction func);
#endif

    /// @internal
    static DbgFlagId repCtrlPerfResetFlag;

    /// @internal
    static DbgFlagId repCtrlCoverageFlag;

    /// @internal
    static DbgFlagId allowDebugBreakFlag;

    /// @internal
    static bool isDbgCtrlPerfActive() { return dbgCtrlPerfActive; }

    /// @internal
    static bool isDbgCtrlWorkActive() { return dbgCtrlWorkActive; }

    /// @internal
    static void setDebugFormat(const CharString &format) { debugFormat = format; }
    /// @internal
    static const CharString &getDebugFormat() { return debugFormat; }

    /// @internal
    //@{ sysConnect
    void startManagerExitPhase();
    void handleSystemEvent(const CharString &eventName, const Variable *args = nullptr);
    void handleDpCreated(const DpIdentifier &dpId);
    void handleDpDeleted(const DpIdentifier &dpId, const CharString &oldName);
    void handleDpRenamed(const DpIdentifier &dpId, const CharString &oldName);
    void handleDpAlias(const DpIdentifier &dpId, const CharString &oldName, const CharString &newName);
    void handleDpDescription(const DpIdentifier &dpId, const LangTextVar &oldText, const LangTextVar &newText);
    void handleDpFormatUnit(const DpIdentifier &dpId,
                            const CharString &oldFormat, const CharString &newFormat,
                            const CharString &oldUnit,   const CharString &newUnit);
    void handleDpTypeCreated(const DpTypeId &dpTypeId, const SystemNumType &sys);
    void handleDpTypeChanged(const DpTypeId &dpTypeId, const SystemNumType &sys, const CharString &oldName);
    void handleDpTypeDeleted(const DpTypeId &dpTypeId, const SystemNumType &sys, const CharString &oldName);
    void handleSysMsg(const SysMsg &msg);
    //@}

  private:
    ScriptId getNextScriptId() const;

    /// check script syntax
    static PVSSboolean syntaxOK(const CharString &script, PVSSlong &errpos, CtrlThread *thread, ExternData *clientData);

    void dumpCoverageReport(std::ostream &to) const;
    void createDotFile(const CtrlScript *script, int libNum = -1) const;

    // load a single lib; fileName holds full path of libfile
    void loadLib(const CharString &fileName);

    // called during parsing when a #uses is found. Recursively loads the used lib
    void loadUsedCtrlLib(CtrlScript *ctrlScript, const CharString &usedName);

    // allocate new extern handler
    bool newExternHdl(const char * libName, BaseExternHdl* &hdl);

    // find full path to given ctrl extension
    static CharString findExtension(const CharString &name);

  private:
    class ControllerPrivate *d;
    TimeVar nextWork_;

    class CtrlLib
    {
      public:
        CtrlLib() : script(0), fileTime(0), refCount(0) {}
        ~CtrlLib();

        CtrlScript *script;
        CharString fileName;
#ifdef __ANDROID__
        unsigned long fileTime;
#else
        time_t fileTime;
#endif
        int refCount;

      private:  // disable methods
        CtrlLib(const CtrlLib &);
        CtrlLib &operator=(const CtrlLib &);
    };

#ifdef _WIN32
# pragma warning(push)
# pragma warning(disable: 4251)
#endif
    // NOTE: NEVER cut anything from the middle, as e.g. FCall stores the index
    SimplePtrArray<CtrlLib> libs;
#ifdef _WIN32
# pragma warning(pop)
#endif

    DynPtrArray<CtrlScript> scriptList;

    BaseExternHdl *extHdl;  // pointer to first ExternHandler
    PVSSulong nextExternFuncNum;  // holds the next funcNum to be used for a loaded ExternHdl-shlib

    CtrlVarList globalVars;  // Manager-global variables
    CtrlVarList libVars;     // all global-variables from all libraries

    struct SmentStack
    {
      CtrlSment *sment;
      SmentStack *next;
    };

    SmentStack *loopStack;

    int scriptCount;

    CtrlDbg debugger;

    DynPtrArray<ScopeLib> scopeLibs;

    CtrlThread *lastTraceWritten;

    static DbgFlagId dbgCtrlPerfFlag;
    static DbgFlagId dbgCtrlWorkFlag;
    static bool dbgCtrlPerfActive;
    static bool dbgCtrlWorkActive;
    static CharString debugFormat;

    // --- members and functions for parsing ---

    static ParseError parseError;
};


#endif /* _CONTROLLER_H_ */
