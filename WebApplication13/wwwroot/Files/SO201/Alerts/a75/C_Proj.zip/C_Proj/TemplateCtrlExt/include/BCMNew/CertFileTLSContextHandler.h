#ifndef _CERTFILETLSCONTEXTHANDLER_H
#define _CERTFILETLSCONTEXTHANDLER_H
//---------------------------------------------------------------------------- 
// Copyright (C) Siemens AG 2011. All Rights Reserved. Confidential. 
//---------------------------------------------------------------------------- 
// Descr.: Class definition of CertFileTLSContextHandler
//---------------------------------------------------------------------------- 

#include "ItcPrelude.h"
#include <TLSContextHandler.h>

class CertFileTLSContextIntern;
      
/**  
    @n This class is responsible for the secure data handling using SSL. It is derived from ITLSContextHandler, the virtual function descriptions can be read there.
    @classification public use
  */

class DLLEXP_BCM CertFileTLSContextHandler : public TLSContextHandler
{

public:
    /// ERROR codes used at initiation of SSL library
    enum CfTlsErrorCodes
    {
      // Unspecified error has appeared
      ERR_UNKNOWN = -1,
      
      // no error
      ERR_SSL_NONE = 0,
      
      // The registering of the available SSL/TLS ciphers and digests is failed.
      ERR_SSL_LIBRARY_INIT = 1,
        
      // Checking of the consistency of a private key with the corresponding certificate loaded into ctx is failed.
      ERR_SSL_PRIVATE_KEY_CHECK = 2,

      // The loading of the certificates and private keys into the SSL_CTX or SSL object is failed. 
      ERR_SSL_PRIVATE_KEY_USE = 3,

      //  The loading of a certificate chain from file into ctx is failed.
      ERR_SSL_CERT_CHAIN_USE = 4,

      // The location for ctx, at which CA certificates for verification purposes (or the CAFile) are located is wrong.
      ERR_SSL_LOAD_VERIFY_LOCATIONS = 5,

      // CRL file loading is failed.
      ERR_SSL_CRL_LOAD = 6,

      // Certificate lookup is failed.
      ERR_SSL_STORE_LOAD = 7,

      // The cipher list cannot be set.
      ERR_SSL_CIPHER_LIST_LOAD_FAIL = 8,

      // Creating of a new SSL_CTX object is failed. 
      ERR_SSL_CTX_NEW = 9,
      
      // see: SslWrapper::InitStatus
      ERR_WRAPPER_VERSION_NOT_SUFFICIENT = 10,
      ERR_WRAPPER_FUNCTION_NOT_FOUND = 11,
      ERR_WRAPPER_LIBRARY_NOT_FOUND = 12,
      ERR_WRAPPER_NOT_INITIALIZED = 13,
      ERR_SSL_SET_TMP_DH = 14,
      ERR_SSL_SET_TMP_ECDH = 15
    };

  /// Simple constructor
  CertFileTLSContextHandler();
  
  /// Initiate CertFileTLSContextHandler object with SSL specific data
  /// @param cFile is the location of certificate file (public key)
  /// @param kFile is the location of private key file
  /// @param caFile is the location of root CA cetrificate file (public key)
  /// @param crlFile is the location of certification revocate list
  /// @param inVerifyTime is a flag. If inVerifyTime = 0 the outdated certificates will be accepted too.
  /// @param dhParamFile is the location of a PEM file from which DH params
  ///                    for ephemeral DH key exchange are read. If null or empty,
  ///                    default params will be used.
  /// @param ecdhCurveName is the name of the curve to use for ephemeral ECDH key exchange.
  ///                      If null or empty, a default curve will be used.
  /// @return failure code. return >= 0 means OK
  CfTlsErrorCodes create ( const char *cFile, const char *kFile, const char *caFile,
                           const char *crlFile, int inVerifyTime, const char *cipherSuite,
                           const char *caChainPrefix, const char *dhParamFile, const char *ecdhCurveName );

  /// Destructor
  virtual ~CertFileTLSContextHandler();
  
  virtual void doBeforeSslHandshake();
};

#endif
