// DATEIBESCHREIBUNG ==============================================================
// DATEINAME:     DpConversion.hxx
//
//
// AENDERUNGS-HISTORIE
// Ver.  | Datum      | Aenderungen                            | ModNr.| Autor
// ------+------------+-----------------Anfang-----------------+-------+-----------
//   1.0 |            | 1.Erstellung mit Westmount-OMT         |     0 |
// ======================================Ende======================================
#ifndef _DPCONVERSION_H_
#define _DPCONVERSION_H_

// System-Include-Files
#include <DpConvSmooth.hxx>

// ========== DpConversion ============================================================
class DLLEXP_CONFIGS DpConversion : public DpConvSmooth 
{

public:
  // Konstruktor
  DpConversion() : DpConvSmooth() {}
  // Destruktor
  virtual ~DpConversion() {}


  // Operatoren :

  // Spezielle Methoden :
  virtual PVSSboolean isConversion() const {return PVSS_TRUE;}
  virtual PVSSboolean isSmoothing() const {return PVSS_FALSE;}

  // Generierte Methoden :
protected:
private:

};

#endif /* _DPCONVERSION_H_ */
