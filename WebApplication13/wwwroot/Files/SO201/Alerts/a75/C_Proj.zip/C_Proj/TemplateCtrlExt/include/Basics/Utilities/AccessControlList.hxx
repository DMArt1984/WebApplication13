#ifndef _ACL_H_
#define _ACL_H_

//AUTHOR: Martin Koller
//SUBJECT: This is a base class for handling an access control list, e.g.
//         it can hold a list of IP addresses, and you can check if
//         a given address is in that list and therefore is valid for access.

#include <CharString.hxx>
#include <SimplePtrArray.hxx>

#include <fstream>


//-------------------------------------------------------------------------

class AclItem;

/// This is a base class for handling an access control list, for example
/// it can hold a list of IP addresses, and you can check if
/// a given address is in that list and therefore is valid for access.
/// @classification ETM internal
class DLLEXP_BASICS AccessControlList
{
  public:
    
    /// Constructor.
    /// @param keyword Sets the keyword for the config file. (see readConfig()
    /// for more info).
    AccessControlList(const char* keyword = 0) : keyword_(keyword) {}

    /// Destructor.
    virtual ~AccessControlList() {}

    /// Reads from the config file one value and add it to either allowed 
    /// or deny list. If the value is "-empty list-", that particular list
    /// will be cleared.
    /// @param keyword Can be in the form "keyword1_allow" or "keyword1_deny"
    /// to specify either allow or deny list. (while "keyword1" is the string
    /// passed to the constructor).
    /// @param istr Config file from which the values will be read.
    /// @return true if the value was successfully read, false if the keyword
    /// don't have the correct format.
    virtual bool readConfig(const CharString &keyword, std::ifstream &istr);

    /// Add a pattern to the list of allowed values.
    /// @param allow CharString with the pattern.
    void addAllow(const CharString &allow);

    /// Add a pattern to the list of denied values.
    /// @param deny CharString with the pattern.
    void addDeny(const CharString &deny);

    /* if given item matches pattern in allow list, access is allowed.
        if given item matches pattern in deny list, access is denied.
        otherwise, access is allowed
    */
    /// Check if the access is allowed for the item. The item is derived
    /// from the AclItem abstract class, which implements the method matches().
    /// @param toCheck AclItem to check access for.
    /// @return true, if access is allowed. Access is not allowed only when
    /// the pattern is in the deny list.
    bool accessAllowed(const AclItem &toCheck);

    /// Dump allow and deny lists to std::cerr.
    void debugDump() const;

    /// Checks if there is at least one pattern in either allow or deny list.
    /// @return true, if there is at least one item in either allow or deny list.
    bool havePatterns() const 
    {
      return allow_.getNumberOfItems() > 0 || deny_.getNumberOfItems() > 0;
    }

  private:
    /// Keyword specifying the config file. See readConfig() for more info.
    CharString keyword_;

    /// List of allowed patterns.
    SimplePtrArray<CharString> allow_;
    
    /// List of denied patterns.
    SimplePtrArray<CharString> deny_;
};

//-------------------------------------------------------------------------

/// Abstract base class which implements the matching function. Items of type
/// AclItem can be passed to the AccessControlList::accessAllowed method to
/// check if they have access.
/// @classification internal use
class DLLEXP_BASICS AclItem
{
  public:
    /// Desctructor.
    virtual ~AclItem() {}

    /// Check if the patter matches with this instance. Must be rewritten
    /// in each derived class.
    /// @param pattern Pattern to check.
    /// @return true, if there is a match, false otherwise.
    virtual bool matches(const CharString &pattern) const = 0;
};

#endif
