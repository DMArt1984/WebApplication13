#ifndef _DPIDENTIFICATIONPROSYSTEM_H_
#define _DPIDENTIFICATIONPROSYSTEM_H_

#ifndef _DPTYPES_H_
#include <DpTypes.hxx>
#endif

#include <MapTable.hxx>
#include <ElementTable.hxx>
#include <CNSViews.hxx>
#include <iostream>


class DpIdentificationProSystem;
class AliasTable;

class itcNdrUbSend;
class itcNdrUbReceive;

// ========== DpIdentificationProSystem ============================================================
/** The class represents a set of properties of the given system. It is used to hold all vital tables of a PVSS
 *  system, such is :
 *    - a table of DpElements
 *    - a table of aliases
 *    - a table of DpTypes
 *    - a table of CNS Views (new feature available in PVSS 3.10 and higher)
 *
 *  @classification public use
 */

class DLLEXP_DATAPOINT DpIdentificationProSystem
{
  public:
    friend class UNIT_TEST_FRIEND_CLASS;

  /** Constructor
   */
  DpIdentificationProSystem();
  /// Destructor
  ~DpIdentificationProSystem();

  /** Equal operator. The operator compares the system name identifiers of specified instances.
   *  
   *  @param anIdent an instance to be compared to
   *  @return int 0, if instances are equal, or not 0 otherwise
   *
   */
   int operator==(const DpIdentificationProSystem &anIdent) const;

  /** unequal operator. The operator compares the system name identifiers of specified instances.
   *  It calls internally an equal operator. The result is inverted then.
   *  
   *  @param anIdent an instance to be compared to
   *  @return int 0, if instances are not equal, or not 0 otherwise
   *
   */
   int operator!=(const DpIdentificationProSystem &anIdent) const;

  /** BCM output streaming operator. Depending on the message version, the configuration 
   *  attribute table is skipped ( for versions higher then PVSS 3.0.1 ) 
   *  Moreover the CNS views are also serialized ( feature is available for versions PVSS 3.10 and higher ) 
   *  
   *  @param [in,out] ndrStream the BCM output stream
   *  @param anIdent the DpIdentificationProSystem object to stream over BCM
   *  @return ndrStream
   *
   */
    friend DLLEXP_DATAPOINT itcNdrUbSend &operator<<(itcNdrUbSend &ndrStream, const DpIdentificationProSystem &anIdent);

  /** BCM input streaming operator. All systems found in the stream replace the
   *  corresponding systems in the DpIdentificationProSystem
   *
   *  @param [in,out] ndrStream the BCM input stream
   *  @param [out] anIdent the DpIdentificationProSystem object to receive from BCM
   *  @return ndrStream
   */
    friend DLLEXP_DATAPOINT itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream, DpIdentificationProSystem &anIdent);

   /** Returns a system name identifier.
    *
    *  @return SystemNumType name of the system

    *  @classification public use, call
    */
    SystemNumType getSysId() const;

    /** Sets a new system name.
     *
     *  @param newSysId a new name of the system

     *  @classification public use, call
     */
    void setSysId(SystemNumType newSysId);

   /** Returns the timestamp of this system
    *
    *  @return PVSSulonglong timestamp of the system

    *  @classification public use, call
    */
    PVSSulonglong getTimestamp() const {return timestamp;}

    /** Sets a new timestamp of this system.
     *
     *  @param newTimestamp a new timestamp of the system

     *  @classification public use, call
     */
    void setTimestamp(PVSSulonglong newTimestamp) {timestamp = newTimestamp;}

    /** Returns an DP elements' table. (const version)
     *
     *  @return ElementTable DpElements' table

     *  @classification public use, call
    */
    const ElementTable &getElTable() const { return elTable; }

    /** Returns an DP elements' table.
    *
    *  @return ElementTable DpElements' table

    *  @classification public use, call
    */
    ElementTable &getElTable() { return elTable; }

   /** Returns a table of DP aliases. (const version)
    *
    *  @return AliasTable  aliase's table

    *  @classification public use, call
    */
    const AliasTable *getAliasTbl() const;

   /** Returns a table of DP aliases.
    *
    *  @return AliasTable aliase's table

    *  @classification public use, call
    */
    AliasTable *getAliasTbl();

   /** Indicates if a table of DP aliases was created succesfully.
    *
    *  @return int PVSS_TRUE if aliase's table exists, otherwise PVSS_FALSE

    *  @classification public use, call
    */
    int isValidAliasTbl() const;

   /** Returns a table of DpTypes. (const version)
    *
    *  @return MapTable DpTypes's table

    *  @classification public use, call
    */
    const MapTable &getDpTypesTable() const { return dpTypesTable; }

   /** Returns a table of DpTypes.
    *
    *  @return MapTable DpTypes's table

    *  @classification public use, call
    */
    MapTable &getDpTypesTable() { return dpTypesTable; }

   /** Returns a table of datapoints. (const version)
    *
    *  @return MapTable datapoints' table

    *  @classification public use, call
    */
    const DataPointTable &getDpTable() const { return dpTable; }

       /** Returns a table of datapoints.
    *
    *  @return MapTable datapoints' table

    *  @classification public use, call
    */
    DataPointTable &getDpTable() { return dpTable; }

   /** Returns a list of CNS Views. (const version)
    *
    *  @return CNSViews

    *  @classification public use, call
    */
    const CNSViews &getViews() const { return views; }

   /** Returns a list of CNS Views.
    *
    *  @return CNSViews

    *  @classification public use, call
    */
    CNSViews &getViews() { return views; }

   /** Sends a formatted output about internal status of the instance to the specified stream.
     * (used for logging purpose)
     *
     *  @param os   output stream
     *  @param summary  indicates if the summary should be added to the stream (use false value!) 
     *  @param [out] bytes   length of the formatted output in bytes
     *  
     *  @classification public use, call
     */
    void reportStatus(std::ostream &os, bool summary, unsigned &bytes);

  private:
    void skipConfigAttrLITable(itcNdrUbReceive &ndrStream);

  private:
    SystemNumType    sysId;
    PVSSulonglong    timestamp;

    DataPointTable dpTable;
    ElementTable elTable;
    DataTypeTable dpTypesTable;
    AliasTable *alTblPtr;
    CNSViews views;

    DpIdentificationProSystem(const DpIdentificationProSystem &) {} // COVINFO LINE: defensive (defined private so no one can use it)
    DpIdentificationProSystem & operator=(const DpIdentificationProSystem &) {return *this;} // COVINFO LINE: defensive (defined private so no one can use it)
};

// ================================================================================
// Inline-Funktionen :
inline  SystemNumType DpIdentificationProSystem::getSysId() const
{
  return sysId;
}


inline const AliasTable *DpIdentificationProSystem::getAliasTbl() const
{
  return alTblPtr;
}


inline AliasTable *DpIdentificationProSystem::getAliasTbl()
{
  return alTblPtr;
}


inline int DpIdentificationProSystem::isValidAliasTbl() const
{
  return alTblPtr != 0;
}

#endif /* _DPIDENTIFICATIONPROSYSTEM_H_ */
