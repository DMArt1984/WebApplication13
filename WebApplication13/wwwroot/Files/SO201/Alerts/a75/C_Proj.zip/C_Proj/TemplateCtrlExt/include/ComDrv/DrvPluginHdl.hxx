// COVINFO FILE: obsolete (actually: not allowed for safety drivers, dhoegerl)
#ifndef DRVPLUGINHDL_H
#define DRVPLUGINHDL_H

#ifdef WIN32
#  define DRVEXT_EXPORT  __declspec(dllexport)
#  define DLLEXP_DRV     __declspec(dllexport)
#else
#  define DRVEXT_EXPORT
#  define DLLEXP_DRV
#endif

#define DRV_EXTENSION_VERSION extern "C" \
        DRVEXT_EXPORT const char *getVersionString() \
        { return PVSS_VERS_DLL; }

/// DrvPlugin API
//@{

/// Macro needed to create a function the ComDrv uses to create an instance of a DrvPlugin
#define DRV_EXTENSION(CLASS) extern "C" \
      { \
        DRVEXT_EXPORT DrvPluginHdl *newDrvPluginHdl() \
        { \
          return new CLASS(); \
        } \
        DRV_EXTENSION_VERSION \
      }

#define DRVPLUGINHDL_SETBIT DRV_USERBIT32
#define DRVPLUGINHDL_SETBITVALID DRV_VALID_USERBIT32

#include <DpIdentifier.hxx>
#include <BitVec.hxx>
#include <TimeVar.hxx>
#include <PtrList.hxx>
#include <PtrListItem.hxx>
#include <CharString.hxx>

/** instances of this class should be inserted for additional values into
    beforeValue or afterValue in DrvPluginHdl::processValue()
*/
class ExtraValue : public PtrListItem{
public:
  /// Datapoint identifier of an additional value.
  DpIdentifier dp;
  /// Time of an additional value.
  TimeVar time;
  /// Variable of an additional value.
  Variable *var;
  /// Flags of an additional value.
  BitVec flags;
};

/// This template class is used for future definitions of various driver plug-in's.
class DLLEXP_DRV DrvPluginHdl{
public:
  /// Default constructor.
  DrvPluginHdl( );
  /// Destructor
  virtual ~DrvPluginHdl();

  /** This method is called at the start of the initialization phase of the driver.
      The plugin can use it to:
      - Read configuration files
      - do a dpGet() to collect some data
      - do a dpConnect()
      This method works togerther with 'isReady'. 'isReady()' shall return TRUE when
      the pluginis ready and the driver should start its work.

      @param argc Number of arg of main procedure.
      @param argv Array of arg of main procedure.
  */
  virtual void init( int argc, char *argv[] ); 

  /** When your plugin needs datapoint names, then it should request 
      a 'Datapoint Identification table'.
      Note that this table could take alot of memory. When you do not need datapoints,
      then you should return FALSE

      @return TRUE when the plugin is going to use 'getName()' or 'getId()'
              FALSE is the default value
  */
  virtual bool needDpContainer();

  /** When your plugin gets Hotlinks, from for example dpConnects, you need to return
      if a value for a given DpId belongs to the Plugin.
      When you use dpConnects in the plugin and do not overload this function, you
      probably get empty Value Pointers in the callback function

      @param dpId dp identifier.

      @return TRUE when the DpId belongs to the plugin
              FALSE is the default value
  */
  virtual bool isPluginDpId(DpIdentifier& dpId);

  /** Allows the plugin to read additional config entries from the driver section of the config file.

      Example:
        [dynamiclogic]
        somePluginValue=1

      @param KeyWord Keyword.
      @param cfgStream Config stream.
      
      @return TRUE when it has recognised and read the keyword, otherwise FALSE.
  */
  virtual bool readConfig( CharString KeyWord, std::ifstream &cfgStream );

  /** A plugin may decide to dpConnect() to various values and 'isReady()' shall 
      return TRUE to indicate that the plugin has all it needs and the actual 
      communication part of the driver can begin.

      Note:
      It is important to realize that values start to 'flow' into the plugin as
      soon as 'isReady()' has returned TRUE. This means you should be 'ready'
      to receive and process the values!

      @return TRUE when you have initialized and want to allow the driver to really
              start communication.
              TRUE is the default value 
  */  
  virtual bool isReady();

  /** This is the real processing function of the plugin. It receives value, bits, 
      timestamp of the value that the driver is about to send to the Event manager.

      The function can set additional bits in the 'flags' parameters or the function
      could add additional values before or after the value ( ordered by timestamp ).

      Careful, Variable pointer can also be NULL.

      @param DpId dp identifier.
      @param Var Values to be processed.
      @param BitFlags Bits in flags that to be set.
      @param tm Timestamp value.
      @param beforeValue Before this item in list is added additional values if it is required.
      @param afterValue After this item in list is added additional values if it is required.

      Example:
      When you want to have an additional value  before(!) the value you just got then you do:

       ExtraValue *pExtra = new ExtraValue();
       pExtra->dp = dp;
       pExtra->time = timeStamp;
       pExtra->var = new FloatVar( 3.1 );
       pExtra->flags = flags;
       pExtra->time.setMilli( timeStamp.getMilli() - 1 );
       beforeValue.append( pExtra ); 
 */
  virtual void processValue(
    DpIdentifier &DpId, 
    Variable *Var, 
    BitVec &BitFlags, 
    TimeVar &tm,
    PtrList &beforeValue,
    PtrList &afterValue
  ) = 0;

};

typedef DrvPluginHdl *(*newDrvPluginHdlFunction)(DrvPluginHdl *);
//@}

#endif
