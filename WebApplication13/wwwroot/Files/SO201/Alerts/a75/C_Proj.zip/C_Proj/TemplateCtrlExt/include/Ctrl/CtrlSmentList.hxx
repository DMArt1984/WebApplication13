#ifndef _CTRLSMENTLIST_H_
#define _CTRLSMENTLIST_H_

#include <CtrlSment.hxx>
#include <CtrlExpr.hxx>

class CtrlVarList;

/*  author VERANTWORTUNG: Martin Koller */
/** represents a compound-statement (list of statements)
    @classification internal use
*/
class DLLEXP_CTRL CtrlSmentList : public CtrlSment
{
  public:
    CtrlSmentList(int line, int file);

    /// Destructor
    virtual ~CtrlSmentList();

    /** Is the sment of the specified type ?
      * @param type given type
      * @return TRUE:  Sment is of type "type"
      *         FALSE: Sment is not of type "type"
      */
    virtual int isA(SmentType type) const { return (type == SMENT_LIST); }

    /// creates local variables in thread-data space and returns first sment
    virtual const CtrlSment *execute(CtrlThread *) const;

    /// Parsen: anhaengen eines CtrlSment
    void append(CtrlSment *sment);

    void insertAsFirst(CtrlSment *sment);

    /// das Erste CtrlSment der Statement-Liste
    CtrlSment *getFirst() const { return first; }

    /// The last statement of the statement list
    CtrlSment *getLast() const { return last; }

    /// Parsen: Liste der lokalen Variablen des Block
    void setLocals(CtrlVarList *list) { locals = list; }

    ///
    const CtrlVarList *getLocals() const { return locals; }

    virtual void writeTrace(CtrlThread *thread, bool writeValue = true) const;

    virtual bool checkIntegrity(const CharString &location, CtrlThread *) const;

    /** @name Get/Set ZeilenNr in der } des Blocks steht */
    //@{
    ///
    void setEndLine(int end) { endLine = end; }
    ///
    int getEndLine() const   { return endLine; }
    //@}

    // synchronized access
    virtual void setSynchronized(CtrlExpr *expr)
    {
      syncExpr = expr;
    }

    virtual bool isSynchronized(CtrlThread *t) const
    {
      return syncExpr != nullptr;
    }

    virtual bool lock(CtrlThread *t) const
    {
      if ( !syncExpr )
        return true;

      return syncExpr->lock(t);
    }

    virtual bool unlock(CtrlThread *t) const
    {
      if ( !syncExpr )
        return true;

      return syncExpr->unlock(t);
    }

    virtual bool isLocked(CtrlThread *t) const
    {
      if ( !syncExpr )
        return false;

      return syncExpr->isLocked(t);
    }

    virtual CtrlThread *getCurrentThread(CtrlThread *t) const
    {
      if ( !syncExpr )
        return nullptr;

      return syncExpr->getCurrentThread(t);
    }

    /** dump the whole tree for code coverage analysis
        @param to output stream
      */
    virtual void dumpCoverageTree(std::ostream &to, CoverageAction action = DUMP) const;

  private:
    CtrlSment *first;       // First expression
    CtrlSment *last;
    CtrlVarList *locals;    // local variables
    int endLine;

    CtrlExpr *syncExpr;
};

#endif /* _CTRLSMENTLIST_H_ */
