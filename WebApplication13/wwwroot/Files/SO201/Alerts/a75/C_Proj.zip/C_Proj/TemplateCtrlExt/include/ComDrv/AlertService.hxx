// DATEIBESCHREIBUNG ==============================================================
// DATEINAME:       AlertService.hxx
// VERANTWORTUNG:  Andreas Lugbauer
// BESCHREIBUNG:   The class AlertService contains the interface between general
//                      driver and specific driver for the handling of alerts.

#ifndef _ALERTSERVICE_H_
#define _ALERTSERVICE_H_

#ifndef _HWOBJECT_H_
#include <HWObject.hxx>
#endif

#ifndef _DRVINTDP_H_
#include <DrvIntDp.hxx>
#endif

#ifndef _WAITFORANSWER_H_
#include <WaitForAnswer.hxx>
#endif

#ifndef _DPMSG_H_
#include <DpMsg.hxx>
#endif

class DpIdentifierVar;
class TextVar;
class DpMsgAnswer;
class PeriphAddr;

#ifndef _ALERTCLASS_OBJECT_HXX_
#include <AlertClassObject.hxx>
#endif

#ifndef _ALERT_OBJECT_HXX
#include <AlertObject.hxx>
#endif

#include <deque>
using namespace std;

/** The answer object is used as data container for the messages
  * and must react on errors of the messages
  * @classification public use
  */
class AlertServiceWaitForAnswer : public WaitForAnswer
{
public:
  /** Constructor
      * @param msgPtr pointer to message
      * @param AID alert identifier
      * @param r reason of alert
    */
    AlertServiceWaitForAnswer(DpMsg *msgPtr, const CharString &AID, AlertObject::EventAction r) : AlertID(AID), myMsg(msgPtr), reason(r) {}

  /** Destructor
    */
    ~AlertServiceWaitForAnswer() { delete myMsg; }

    /** Decreases count of messages, check for error
    * @param answer allert was OK or NOT
    */
    void callBack(DpMsgAnswer &answer);

    /** return copy of myMsg and erase myMsg
    * @return tmp  myMsg
      */
    DpMsg *cutMsg() {DpMsg *tmp = myMsg; myMsg = 0; return tmp;}

    /** Return reason of alert action
      * @return reason of alert action
      */
    AlertObject::EventAction getReason() {return reason;}

private:
    CharString AlertID;
    DpMsg *myMsg;
    AlertObject::EventAction reason;
};

// the alert send queue
typedef std::deque<AlertServiceWaitForAnswer *> AlertMsgQueue;

/** This class can be used for handling alerts in the driver.
    It provides an interface to PVSS alert mechanism for typical driver requirements.
    @classification public use, overload
*/
class AlertService
{
  friend class AlertObject;     // for redu deja vu

  public:

    /** Constructor
      */
    AlertService();

    /** Destructor
      */
    virtual  ~AlertService();

    /** Callback function. This function is called, when the driver should acknowledge the alert
      * related to the address given in the HWObject.
      * @param alertPtr pointer to alert data
      * @param objPtr address for which the alert should be acknowledged
      * @return PVSS_TRUE on success, PVSS_FALSE if the acknowledge fails
      * @classification public use, overload
      */
    virtual PVSSboolean ackAlertInHW(AlertObject *alertPtr, HWObject *objPtr);

    /** Callback function. This function is called, when all received acknowledge commands
      * have been passed on to ackAlertInHW.
      * @classification public use, overload
      */
    virtual void ackAlertsDone();

    /** This function can be used to acknowledgde an alert in PVSS.
      * DEPRECATED, is to be replaced by setAlert functionality
      * @param adrPtr pointer to reference HW object
      * @return PVSS_TRUE on success, PVSS_FALSE if the acknowledge fails
      * @classification public use, overload
      */
    PVSSboolean ackAlertInPVSS(HWObject *adrPtr);

    /** This function can be used to set an alert in PVSS.
      * @param alertPtr pointer to alert data, AlertObject is not captured
      * @param adrPtr pointer to reference HW object
      * @return PVSS_TRUE on success, PVSS_FALSE if setting of alert fails
      */
    PVSSboolean setAlert(AlertObject *alertPtr, HWObject *adrPtr);

    /** AlertObject iterators to go through all the objects
      * sorted by AlertID
      * these might be used during initialisation to sync the known/aktive alerts
    * @return first from begin alert object
    */
    AlertObject *getFirstAlertObject();

    /** AlertObject iterators to go through all the objects
      * sorted by AlertID
      * these might be used during initialisation to sync the known/aktive alerts
    * @return next alert object
    */
    AlertObject *getNextAlertObject();

    /** Callback function. This function is used to notify the driver about successful acknowledgement
      * of the alert in PVSS.
      * @param alertPtr pointer to alert data
      * @param adrPtr pointer to reference HW object
      * @classification public use, overload
      */
    virtual void ackConfirmCB(const AlertObject *alertPtr, const HWObject *adrPtr);

    /** Callback function. This function is used to notify the driver about alert changes in the _add_values.
      * The first call signals that EV has confirmed the new alert instance.
      * This can be seen by checking the AlertIdentifier counter which should be != (-1) then.
      * @param alertPtr pointer to alert data
      * @param adrPtr pointer to reference HW object
      * @classification public use, overload
    */
    virtual void changeNotificationCB(const AlertObject *alertPtr, const HWObject *adrPtr);

    /** Callback function. This function is used to notify the driver about the removal of the given alert.
      * This is the final callback before the alert is discarded from the active alert list.
      * This callback is also triggered when a PVSS datapoint element holding alerts is deleted.
      * @param alertPtr pointer to alert data
      * @param adrPtr pointer to reference HW object
      * @classification public use, overload
      */
    virtual void invisibleConfirmCB(const AlertObject *alertPtr, const HWObject *adrPtr);

    /** Callback function. This function is called every time a hotlink to the
      * disable command internal datapoint is received.
      * @param dc The actual state of the DC datapoint
      * @classification public use, overload, call base
      */
    virtual void notifyDisableCommands(PVSSboolean  dc );

    /** Callback function. This function is used to notify the driver about the activation/deactivation
      * of an AM_Alert config. The callback should be used to subscribe/unsubscribe for alarms in the PLC.
      * @param hwo the HWObject containing the periph address
      * @param active the new state of the config: subscribe if true, unsubscribe if false
      * classification public use, overload
      */
    virtual void notifyAlertActivation(HWObject *hwo, bool active);

    // --------------------------------------------------------------------
    // for internal use
    /** Callback function.  Inform about removal from alert classes and lists of DPID and AID
    * @param dp dp type that is checked
    */
    void notifyDpDelete(const DpIdType &dp);

    // AlertClassObject handling --------------------------------
    /** Check the consistency of the variables
    *   Deletes  the variables ackdps and ackdata
    *   @param ackdps acknowledge DP (of DYNDPIDENTIFIER_VAR type)
    *   @param ackdata  acknowledge data (of DYNTEXT_VAR type)
    */
    void ackAlerts(Variable * ackdps, Variable * ackdata);

    /** This function processed variable for AClassSet
      *  - check for right type of input variable pointer - type must be DYNTEXT_VAR
      *  - check the right order in dynamic input variable (input alert request) - sort it
      *  - extract name from variable and check whether this name is in the dp identificators, if not
      *    remove it from connected dp
      *  - find alert class by name, if not exist insert new alert class  adapt class name
      *  - set and send message to dp
      * @param varPtr pointer to alert variable
      */
    void handleAClassesHL(Variable *varPtr);

    /** Check for valid identifier & do dpConnect for alertclass prio
      * answer is handled by WaitObject
      * @param name name for searching in alert classes
    * @param dpId  DP identifier
    * @return PVSS_TRUE if DP Id is setting or DP Id is null
      */
    PVSSboolean setDpIdentifier(CharString& name, DpIdentifier& dpId);

    /** Search in alert classes and set appropriate prio after
    * prio value in varPtr
    * @param dpId  DP identifier
    * @param varPtr pointer to variable with prio value (of CHAR_VAR type)
    * @return PVSS_TRUE if prio setting was successful, PVSS_FALSE in case of inconsistence of data type
      */
    PVSSboolean setPrio(DpIdentifier& dpId, Variable *varPtr);

    /** Return DP identifier of alert class
    * @param acname alert name for searching
      * @param dpId Dp identifier
      * @return PVSS_TRUE if DP identifier was found
      */
    PVSSboolean getDpIdentifierForAClass(const CharString &acname, DpIdentifier &dpId) const;

  /** Get the priority of alert class AClassPrio_
    * @param acname alert name for searching
    * @return priority of alert, APRIO_INVALID if it is empty or not found
    */
    PVSSlong getPrioForAClass(const CharString &acname) const;

  /** Print list info sorted by AClassName
    * Name, DpId, Priority
    * @param os output stream for printing
      */
    void debugAClasses(ostream &os);

    // AlertObject handling --------------------------------------
    /** Print alert info sorted by AlertIdentifier
    * @param os output stream for printing
      */
    void debugAlertList(ostream &os);

    /** Find item in AlertList, return 0 if not found
      @param aid alert ID (CharString)
    @return alert object if found
      */
    AlertObject *findAlertObjectByAID(const CharString &aid);

    /** Find WENT item in AlertList for given CAME AlertID, return 0 if not found
      @param cameaid alert ID (CharString)
      @return alert object if found
      */
    AlertObject *findWentAlertObjectForCameAID(const CharString &cameaid);

    /** Find item in AlertList, return 0 if not found
    * @param aid alert ID
    * @return alert object if found
      */
    AlertObject *findAlertObjectByAlertIdentifier(const AlertIdentifier &aid);

    /** When the driver is connected for an alertHL, it gets all existing alerts as answer
      * If there are new alerts on periphaddr DPs, function creates the AlertObject and puts it into the list
      * This normally happens during startup of the driver
    * @param theObjPtr alert object
      * @return PVSS_TRUE if object has been captured otherwise, the caller should delete it and return PVSS_FALSE
    */
    PVSSboolean handleAlertConnectAnswer(AlertObject *theObjPtr);

    /** This function processed alertHL message and assemble the AlertObject
    *  - find input alert object in list of alert object by alert identifier
    *  - get and update aditional values
    *  - set actual ack and visible parameters
    *  - remove, update and reinsert item to container
    *  - find corresponding HW object and configuration name
    *  - by using HW mapper find the HW address
    *  - do callback functions for ack and visibility and synchronize the local list of AID and DPID
    * @param theObj alert object to be processed
    */
    void handleAlertHL(const AlertObject &theObj);

    /** Remove AlertObject if CAME/GONE action went wrong (answer callback)
    * remove item from both lists (AID and DPID)
    * @param alertID
      */
    void removeAlertObjectByAID(const CharString &alertID);

    /** Handle periph addr config activation. here we get the periphaddr config.
      * we look for the HWObject and do the notifyAlertActivation() call
      * @param theConfig this is the config object
      * @param activate if set we are called from addDpPa, else clrDpPa
      */
    void handlePeriphAddrActivation(const DpIdentifier &dpId, const PeriphAddr *theConfig, bool activate);

    /** This function is called to send messages in queue
    */
    void doSend();

    // redu deja vu confirmation stuff
    /** Function decreases count of unconfirmed alert messages
      */
    void decreaseOutstandingMsgCount();

    /** Find AlertObject by alertID and call confirmCommand()
      * @param alertID alert ID
    * @param r confirm command
    */
    void confirmMessage(const CharString &alertID, AlertObject::EventAction r);

    /** register driver internal alert class
      * @param alert class (DP) name
      */
    void registerAlertClass(const CharString &name);

    /** Reports status to stream.
    * @param os output stream
    */
    virtual void reportStatus(std::ostream &os) const;

  private:

    /** Abstract class
      */
    class AlertDrvIntDp : public DrvIntDp
    {
      public:
        enum {inAClasses,
              maxConnect,               // use standard mechanism
              inAckDps = maxConnect,    // the other two are done on our own
              inAckData,
              maxDp};
        /** Constructor
      */
        AlertDrvIntDp();

    /** Destructor
      */
    virtual ~AlertDrvIntDp();

    /** Creates string according to value of index
      * @param index (inAckDps,inAckData or inAClasses)
      * $return string according to value of index
      */
        virtual const CharString& getDpName4Query(int index);

    /** Select action according to indexCall.
      * if index is inAckDps or inAckData delete pointer to variable
      * if index is inAClasses call handleAClassesHL with varPtr as parameter
      *
      * @param index (inAckDps,inAckData or inAClasses)
      * @param varPtr pointer to alert class (of DYNTEXT_VAR type)
      */
    virtual void hotLink2Internal(int index, Variable* varPtr);

    /** Call handleAClassesHL if index is inAClasses
      * @param index (inAckDps,inAckData or inAClasses)
      * @param varPtr pointer to variable (of DYNTEXT_VAR type)
      */
        virtual void answer4DpId(int index, Variable* varPtr);

        /** Do a dpConnect
      */
        virtual void dpReady ();
    };

    /** Remove item pointer from AlertIdentifier multiset for update of AlertIdentifier ...
      * used internally by hotlink handler
    * @param aoPtr pointer to alert object
      * @return false if not found - should never happen!
    */
    bool removeAlertObjectFromDPIDPtrSet(const AlertObject *aoPtr);

    /** Acknowledge alert in HW for DP
    * @param dpidVarPtr variable with dp identifier
    * @param txtVarPtr variable with alert object identifier
    */
    void ackForDp (const DpIdentifierVar * dpidVarPtr, const TextVar * txtVarPtr);

    // setAlert helper functions
    /** Send CameAlert
    * @param aoPtr pointer to alert object
    * @param retry
    */
    void sendCameAlert(AlertObject *aoPtr, bool retry = false);

    /** Send GoneAlert
    * @param aoPtr pointer to alert object
    * @param retry
    */
    void sendGoneAlert(AlertObject *aoPtr, bool retry = false);

    /** Enqueue ack of alert if is not unconfirmed and is valid
    * @param aoPtr pointer to alert object
    */
    void sendAck(AlertObject *aoPtr);

    /** Send GoneObsoleteAlert. this command is not buffered. the alert instance must exist
    * otherwise nothing will happen.
    * @param aoPtr pointer to alert object
    */
    void sendGoneObsolete(AlertObject *aoPtr);

    /** Send GoneDuplicateAlert. this command is not buffered. Removes the duplicate alert instance 
    * by setting GONE OBSOLETE.
    * @param aoPtr pointer to alert object
    */
    void sendGoneDuplicate(const AlertObject *aoPtr);

    /** Enqueue update of alert if is not unconfirmed and is valid
    * @param aoPtr pointer to alert object
    */
    void sendUpdate(AlertObject *aoPtr);

    /** Enqueue msg for send, message is captured
    * @param AID alert ID
    * @param r action
    */
    void enqueue(DpMsg *msg, const CharString &AID, AlertObject::EventAction r);

    /** Clear alert classes
    */
    void clearAlertClasses();

    /** Go through wrappers, remove entries and delete AlertOjects
      */
    void clearAlertList();

    // the ComDrv AL branch
    AlertDrvIntDp alertIntDp_;

    // alert class name/dpId container
    AClassSet alertClasses_;

    AIDPtrSet  alertListByAID_;     // AlertObjects by AlertID
    DPIDPtrSet alertListByDPID_;    // AlertObjects by AlertIdentifier

    AIDPtrSet_Iterator lastAlertIndex;  // used by AlertObject iterator

    AlertMsgQueue theQueue;         // pending alert messages
    unsigned unconfirmedMsgCount;   // the unconfirmed message counter

    friend class UNIT_TEST_FRIEND_CLASS;
};

#endif
