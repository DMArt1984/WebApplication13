// DATEIBESCHREIBUNG ==============================================================
// DATEINAME:       PollList.hxx
// VERANTWORTUNG:  Thomas Koroschetz
// BESCHREIBUNG:   Die Klasse PollList beinhaltet dynamisches Array von Zeiger
//                  auf Klassen mit den zu pollenden Werten in der Form: 
//                  Pollzeitpunkt und Zeiger auf die Klasse HWMapDpPa -
//                  die wiederum einen DpIdentifier und einen Zeiger auf die 
//                  zugehoerige PeripherieAdresse. Die Liste ist nach Zeit 
//                  und Pointer (wegen Eindeutigkeit) sortiert.

#ifndef _POLLLIST_H_
#define _POLLLIST_H_

#ifndef _POLLITEM_H_
#include <PollItem.hxx>
#endif

#define    POLLLISTBLOCKSIZE    32

/** This class holds all the PollItem entries for the poll requests.
  * The poll list is sorted by time.
  */
class PollList
{
  public:
    
    /** Constructor
    */
    PollList();
    
  /** Destructor
    */
  virtual ~PollList();
    
  /** Adds new item and sets its time variable
    * @param tm time variable to be set
    * @param rPtr pointer to HWMapDpPa object to be added
    * @return PVSS_TRUE if addition was successful
    */
    virtual PVSSboolean addItem(const TimeVar& tm, HWMapDpPa* rPtr);

  /** Deletes pool item by index
    * @param idx index of item to be removed
    * @return PVSS_TRUE if the deletion was successful, PVSS_FALSE if the index is invalid
    */
    virtual PVSSboolean clrItem(PVSSlong idx);

  /** remove PollItem by HWMapDpPa ptr
    * this causes a linear search since items are sorted by time
    * but we do not know the next poll time
    * if item is found it is deleted
    * @param ptr pointer to the HWMapDpPa object
    * @return PVSS_TRUE if found and deleted
    */
    PVSSboolean removeItem(HWMapDpPa *ptr);

  /** Detects something to poll
    * @return PVSS_TRUE if exists something to poll
    */ 
    PVSSboolean something2poll() const { return (pllCnt) ? PVSS_TRUE : PVSS_FALSE;}

  /** If time variable is less than current sync time, method returns
    * configuration pointer. 
    * If the time variable is greater than or equal to current sync time 
    * method returns NULL. 
    * @param dpId dp identifier
    * @param when time variable
      * @return pointer to configuration or NULL
    */
    PeriphAddr* pollNow(DpIdentifier& dpId, TimeVar &when);

  /** Sets new pool time resorts poll items
    * @param idx index
    */
    void        setNewPollTime(PVSSlong idx);
    
  /** Returns param isValid for first item
    * @return PVSS_TRUE if first item is valid
    */
    PVSSboolean isFirstItemValid() const {return lstPtr[0]->isValid();}

  /** Sets param isValid for first item according to valid
    * @param valid value for setting of the first item
    */
    void        setFirstItemValid(PVSSboolean valid) {lstPtr[0]->setValid(valid);}

    /// sort the array
    void sort();
    
    /// reset the array
    void reset();

  private:
    static int qsortCompare(const void *, const void *);
    
  /** Inserts item to sorted list of items on right position 
    * @param ptr pointer to PollItem object
    * @return PVSS_TRUE
    */
    PVSSboolean sortedInsert_PollItem(PollItem* ptr);
    
  /** Compares two items according the pool time or ref pointer
    * @param p1 the first pool item object to be compared
      * @param p2 the second pool item object to be compared
    * @return result of comparison (PVSS_TRUE if the items are equal) 
    */
  virtual  int compare_PollItem(PollItem* p1, PollItem* p2);
  
    PVSSlong         pllMax;
    PVSSlong         pllCnt;
    PollItem       **lstPtr;

    friend class UNIT_TEST_FRIEND_CLASS;
};


#endif
