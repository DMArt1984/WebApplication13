// DATEIBESCHREIBUNG ==============================================================
// DATEINAME:     DpConvSmooth.hxx
// VERANTWORTUNG:	Stanislav Meduna
// 
// BESCHREIBUNG:	Abstrakte Klasse, die eine Umrechnung oder Glaettung
// 		definiert.
// 
// 		Diese Umrechnungen sind fuer Grundtypen definiert,
// 		also nicht fuer Array oder Record. Der DP-Konzept
// 		sagt, dass wenn die Umrechnung fuer solche Strukturen
// 		definiert wird, gilt sie fuer jedes Element der
// 		Strukture. Als die Glaettungen Zustaende haben (Zeit,
// 		letzte Werte usw.), muessen sie fuer jedes Element
// 		definiert werden. Der SatDpMsgHdl kuemmert um diese
// 		Transformierung (Strukturconfig -> Elementconfigs).
// 
//
// AENDERUNGS-HISTORIE
// Ver.  | Datum      | Aenderungen                            | ModNr.| Autor
// ------+------------+-----------------Anfang-----------------+-------+-----------
//   1.0 |            | 1.Erstellung mit Westmount-OMT         |     0 |
// ======================================Ende======================================
#ifndef _DPCONVSMOOTH_H_
#define _DPCONVSMOOTH_H_

// Vorwaerts-Deklaration der Eigenen Klasse
class DpConvSmooth;

// ========== DpConversionResultType ============================================================
// Resultat der Konvertierung oder Glaettung.
enum DpConversionResultType {
  DpConversionOK,
  DpConversionBadType,
  DpConversionInvValue,
  DpSmoothed,
  DpConversionError
};

// ========== DpConvSmoothPtrType ============================================================
typedef DpConvSmooth* DpConvSmoothPtrType;

// System-Include-Files
#include <DpConfig.hxx>
#include <ConfigTypes.hxx>

// Vorwaerts-Deklarationen :
class DpConvSmooth;
class CharVar;
class FloatVar;
class IntegerVar;
class TimeVar;
class UIntegerVar;
class Variable;

class BitVec;

// ========== DpConvSmooth ============================================================

/// Abstract class to define conversion or smoothing
/// 
/// The conversions are defined for basic types and not for array or record.
/// The DP concept says, that when the conversion is define for such structure, it is
/// also valid for each element of the structure. As the smoothing has states (time,
/// last values, etc.), they must be defined for every element. SatDpMsgHdl takes care about this
/// transformation (structure config -> element configs).
/// The derived class MUST overload at least one of the convert methods (the one with two parameters or the one with three),
/// because otherwise, convert() enters an indirect infinite recursion.
class DLLEXP_CONFIGS DpConvSmooth 
{
friend class UNIT_TEST_FRIEND_CLASS;    // ein Unit-Test braucht erweiterten zugriff auf diese Klasse

  // Klassen-Enums:

// ..........................Anfang User-Klasseninterne-Definitionen..................
// ...........................Ende User-Klasseninterne-Definitionen...................
public:

  /// constructor, initialisation with zero values
  DpConvSmooth();

  /// destructor
  virtual ~DpConvSmooth();

  /** operator << for itcNdrUbSend stream
      @param ndrStream the stream, which to send to
      @param aConv the DpConvSmooth
    */
  friend DLLEXP_CONFIGS itcNdrUbSend &operator<<(itcNdrUbSend &ndrStream, const DpConvSmooth &aConv);

  /** operator >> for itcNdrUbReceive stream
      @param ndrStream the stream, which to receive from
      @param aConvPtr the DpConvSmooth
    */
  friend DLLEXP_CONFIGS itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream, DpConvSmooth * & aConvPtr);

  /** assignment operator used for type conversion
      @return the resulting DpConvSmooth
    */
  virtual DpConvSmooth &operator=(const DpConvSmooth &rhs);

  /// return conversion type
  virtual DpConversionType convType() const = 0;

  /// conversion function
  /// @param inpVar the input Variable
  /// @param outVarPtr the output Variable
  /// @param ubits the user bits
  /// @return the result type
  virtual DpConversionResultType convert(const Variable &inpVar, Variable * & outVarPtr, const BitVec &);

  /// conversion function
  /// @param inpVar the input Variable
  /// @param outVarPtr the output Variable
  /// @param ubits the user bits
  /// @return the result type
  virtual DpConversionResultType convert(const Variable &inpVar, Variable * & outVarPtr, const TimeVar &, const BitVec &);

  /// conversion function
  /// @param inpVar the input Variable
  /// @param outVarPtr the output Variable
  /// @param timeVar the time
  /// @param ubits the user bits
  /// @return the result type
  virtual DpConversionResultType convert(const Variable &inpVar, Variable * & outVarPtr, const TimeVar &timeVar, const BitVec &,
                                         SystemNumType, DpIdType, DpElementId, DynPtrArrayIndex);

  /// reset the last value in the smoothing config
  /// @return the result type
  virtual DpConversionResultType resetLastValue();

  /// allocate new DpConvSmooth
  /// @return the new DpConvSmooth
  virtual DpConvSmooth *allocate() const = 0;

  /// allocate new DpConvSmooth
  /// @param type the config conversion type
  /// @return the new DpConvSmooth
  static DpConvSmooth *allocate(DpConversionType type);

  /// check if this class is conversion
  virtual PVSSboolean isConversion() const = 0;

  /// check if this class is smoothing
  virtual PVSSboolean isSmoothing() const = 0;

  /// set attribut
  /// @param attrNr the number of attribut
  /// @param var the Variable to set
  /// @return PVSS_TRUE if OK else PVSS_FALSE
  virtual PVSSboolean setAttribut(DpAttributeNrType attrNr, const Variable &var) = 0;

  /// get attribut
  /// @param attrNr the number of attribut
  /// @return the attribut
  virtual Variable *getAttribut(DpAttributeNrType attrNr) const = 0;

  /// check if the config settings are consistent
  virtual PVSSboolean isConsistent() const;

  /// send debug info to output stream
  virtual void debug(std::ostream &, int) const {};

protected:
  /// force change
  PVSSboolean forceChange_;

private:
};


#ifdef WIN32
#pragma warning ( disable: 4231 )
#endif


#ifdef LIBS_AS_DLL
EXTERN_CONFIGS  template  class  DLLEXP_CONFIGS  DynPtrArray<DpConvSmooth>;

/// deep copy
inline DynPtrArrayIndex DynPtrArray<DpConvSmooth>::deepCopy(const DynPtrArray<DpConvSmooth> &) {return 0;}
#endif

#ifdef WIN32
#pragma warning ( default: 4231 )
#endif


#endif /* _DPCONVSMOOTH_H_ */
