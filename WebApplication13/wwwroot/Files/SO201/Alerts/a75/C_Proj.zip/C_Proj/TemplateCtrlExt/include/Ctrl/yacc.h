// Aus irgendeinem unerdenklichen Grund will das file y.tab.c
// dieses file bei c++ includieren:
//#ifdef __cplusplus
//#  include <stdio.h>
//#  include <yacc.h>
//#endif  /* __cplusplus */
