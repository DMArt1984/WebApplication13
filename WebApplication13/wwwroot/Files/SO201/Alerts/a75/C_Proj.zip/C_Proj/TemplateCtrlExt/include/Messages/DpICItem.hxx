// DATEIBESCHREIBUNG ==============================================================
// DATEINAME:     DpICItem.hxx
// VERANTWORTUNG: Guenter Szolderits
// BESCHREIBUNG:  

#ifndef _DPICITEM_H_
#define _DPICITEM_H_

// System-Include-Files
#include <PtrListItem.hxx>
#include <DpConfig.hxx>
#include <Allocator.hxx>

// Vorwaerts-Deklarationen :
class DpICGroup;

// ========== DpIdValueList ============================================================
/** Init-config item class
*/
class DLLEXP_MESSAGES DpICItem : public PtrListItem
{
public:
  /** Constructor
   * @param config the configuration for this item, the instance takes ownership
   */
  DpICItem(DpConfig *config);

  /// Copy constructor
  DpICItem(const DpICItem &rVal);

  /// Destructor
  virtual ~DpICItem();

  /// Allocator class
  AllocatorDecl;

  // Operatoren :

  /** BCM output streaming operator
   * @param[in,out] ndrStream the BCM stream to write to
   * @param item the DpICItem instance to be written
   */
  friend DLLEXP_MESSAGES itcNdrUbSend &operator<<(itcNdrUbSend &ndrStream, const DpICItem &item);

  /** BCM input streaming operator
   * @param[in,out] ndrStream the BCM stream to read from
   * @param[out] item the DpICItem instance to be read
   */
  friend DLLEXP_MESSAGES itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream, DpICItem &item);
  
  /** Equality operator
   * @param rVal the DpICItem to compare with
   */
  int operator==(const DpICItem &rVal) const;

  /** Inequality operator
   * @param rVal the DpICItem to compare with
   */
  int operator!=(const DpICItem &rVal) const;

  /** Copy operator
   * @param rVal the DpIcItem to copy
   */
  DpICItem &operator=(const DpICItem &rVal);

  // Spezielle Methoden :
  /** Writes this item to the BCM stream
   * @param[out] ndrStream
   */
  void outNdrUb(itcNdrUbSend &ndrStream) const;

  /** Reads this item from the BCM stream
   * @param[in,out] ndrStream
   */
  void inNdrUb(itcNdrUbReceive &ndrStream);

  /** Debug output method
   * @param[out] to the stream to write to
   * @param level controlls the amount of debug information, the higher the more
   */
  void debug(std::ostream &to, int level) const;

  /** Returns the DpConfig stored in this item
   * @return the DpConfig stored in this item, the caller must not delete it
   */
  DpConfig *getConfigPtr() { return configPtr; }

  /** Removes and returns the DpConfig stored in this item
   * @return the DpConfig stored in this item, the caller takes responsibility
   */
  DpConfig *cutConfigPtr() { DpConfig *ptr = configPtr; configPtr = 0; return ptr; }

protected:
  ///internal config pointer
  DpConfig *configPtr;
private:
  /** BCM input streaming operator for DpICGroup. It needs access to this class's members,
   *  so it is friended here.
   * @param[in,out] ndrStream the BCM stream to read from
   * @param[out] item the DpICGroup instance to be read
   */
  friend DLLEXP_MESSAGES itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream, DpICGroup &item);

  /** Default constructor, only itcNdrUbReceive &operator>>(itcNdrUbReceive&, DpICGroup&)
   *  is allowed to use it
   */
  DpICItem(); // only operator>> above is allowed to use this constructor
  
  friend class UNIT_TEST_FRIEND_CLASS;
};

// ================================================================================

#endif /* _DPICITEM_H_ */

