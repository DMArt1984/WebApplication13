#ifndef _SWITCHSMENT_H_
#define _SWITCHSMENT_H_

#include <CtrlSment.hxx>
#include <Types.hxx>

class CtrlExpr;

/*  author VERANTWORTUNG: Mark Probst */
/** the switch statement */
class DLLEXP_CTRL SwitchSment : public CtrlSment
{
  public:
    /// wird vom YACC auf gerufen
    SwitchSment(int line, int filenum)
      :CtrlSment(line, filenum),
      expr(0),
      block(0),
      firstLabel(0),
      lastLabel(0),
      defaultLabel(0) {}

    /// delete aller private member
    virtual ~SwitchSment();

    /** Beim Parsen: Expression fuer switch
      * @param theExpr IN: wird vom Destuctor frei gegeben.
      */
    void setExpr(CtrlExpr *theExpr) { expr = theExpr; }
    /** Beim Parsen: Statements des switch
      * @param list IN: wird vom Destuctor frei gegeben.
      */
    void setBlock(CtrlSment *list) { block = list; }

    /** Legt einen Block am Stack an und testet expr.
      * @return erstes CtrlSment des passenden Labels
      *         wenn kein passender label gefunden wurde und kein default
      *         label vorhanden ist wird das CtrlSment nach dem switch
      *         zurueckgegeben.
      */
    virtual const CtrlSment *execute(CtrlThread *thread) const;

    virtual const CtrlExpr * getFirstExpr(CtrlThread *thread) const;

    /** Is the sment of the specified type ?
      * @param type given type
      * @return TRUE  Sment is of type "type"
      * @return FALSE Sment is not of type "type"
      */
    virtual int isA(SmentType type) const;
    /// Beim Parsen: neuer case label
    void appendCase(CtrlExpr *expr, CtrlSment *sment, int line);
    /// Beim Parsen: default label einfuegen
    void appendDefault(CtrlSment *sment, int line);

    virtual void writeTrace(CtrlThread *thread, bool writeValue = true) const;

    virtual bool checkIntegrity(const CharString &location, CtrlThread *thread) const;

    /// Zeilennummer von } vom switch
    int getEndLine();
    /// Zeilennummer von { vom switch
    int getStartLine();

    /** dump the whole tree for code coverage analysis
        This method also prints the execution counter
        @param to output stream
      */
    virtual void dumpCoverageTree(std::ostream &to, CoverageAction action = DUMP) const;

  private:
    struct SwitchLabel
    {
      SwitchLabel() : expr(0), sment(0), next(0), labelLine(-1) {}
      ~SwitchLabel();

      CtrlExpr *expr;          // valid ... case; 0 ... default
      CtrlSment *sment;
      SwitchLabel *next;
      int labelLine;
    };

    const CtrlSment *getNextSment(SwitchLabel *label) const;

    CtrlExpr    *expr;
    CtrlSment   *block;
    SwitchLabel *firstLabel;
    SwitchLabel *lastLabel;
    SwitchLabel *defaultLabel;

    friend class EditorWidget;
};

#endif // _SWITCHSMENT_H_

