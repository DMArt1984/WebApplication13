#pragma once

#include <DrvConfigContainer.hxx>

IL_DEPRECATED("deprecated, DrvDpCont renamed to DrvConfigContainer")
typedef DrvConfigContainer DrvDpCont;