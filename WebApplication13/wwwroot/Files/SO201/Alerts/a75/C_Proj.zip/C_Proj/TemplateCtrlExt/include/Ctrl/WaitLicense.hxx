#ifndef _WAITLICENSE_H_
#define _WAITLICENSE_H_

/*  author: Joshua Hercher*/
/** WaitCond-Object for script.
  This is the WaitCond-Object which blocks further execution of the CTRL-script
  until the new script (with given scriptId) is finished. The new script
  tells this object with setDone() when it is finished.
  This class also checks out the CTRL-script when this is destroyed.
*/
#include <WaitCond.hxx>
#include <CtrlThread.hxx>
#include <TimeVar.hxx>
#include <MappingVar.hxx>

///
class DLLEXP_CTRL WaitLicense : public WaitCond
{
  public:
    WaitLicense(CtrlThread *thread, const CharString& optionName, MappingVar* returnMapping = nullptr)
      : thread(thread)
      , optionName(optionName)
      , mappingVar(returnMapping)
    {}

    /// when shall we call checkDone next
    virtual const TimeVar &nextCheck() const;

    /// checks if the wait condition has finished
    virtual int checkDone();

    void callback(int count, bool error);

  private:
    bool isDone = false;
    bool error = false;
    mutable TimeVar nextCheckTime = TimeVar(0,0);
    int licenseCount = 0;
    CtrlThread *thread = nullptr;
    CharString optionName;
    MappingVar *mappingVar = nullptr;

    void setMappingResult();
};

#endif /* _WAITLICENSE_H_ */
