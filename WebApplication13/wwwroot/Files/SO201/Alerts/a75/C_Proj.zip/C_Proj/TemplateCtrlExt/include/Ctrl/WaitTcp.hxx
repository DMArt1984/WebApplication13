#ifndef _WAITTCP_H_
#define _WAITTCP_H_

/*  author: Martin Koller */
/** WaitCond-Object for tcp-socket.
  This is the WaitCond-Object which blocks further execution of the CTRL-script
  until the tcp-socket did receive data or the timeout is over.
*/

#include <WaitCond.hxx>
#include <TimeVar.hxx>
#include <TimeoutTimer.hxx>

class Socket;
class Variable;
class CtrlThread;
class CtrlExpr;
class WaitTcpItcIOHandler;

class DLLEXP_CTRL WaitTcp : public WaitCond
{
  public:
    /// ctor to wait for a pending tcp read()
    WaitTcp(Socket *sock, Variable *target, const TimeVar &timeout, CtrlThread *thread);

    /// ctor to wait for a pending udp read()
    WaitTcp(Socket *sock, Variable *target, Variable *host, Variable *port, const TimeVar &timeout, CtrlThread *thread);

    /// ctor to wait for a pending connect()
    WaitTcp(Socket *sock, const TimeVar &timeout, CtrlThread *thread);

    ~WaitTcp();

    /// when shall we call checkDone next
    virtual const TimeVar &nextCheckAt();

    /// checks if the wait condition has finished
    virtual int checkDone();

    int readData();  // called by WaitTcpItcIOHandler
    void setDone();  // called by WaitTcpItcIOHandler

  private:
    Socket *socket_;
    Variable *target_;
    Variable *host_;
    Variable *port_;
    TimeoutTimer timer;
    CtrlThread *thread_;
    CtrlExpr *fcall_;
    int done;
    WaitTcpItcIOHandler *ioHandler;
};

#endif /* _WAITTCP_H_ */
