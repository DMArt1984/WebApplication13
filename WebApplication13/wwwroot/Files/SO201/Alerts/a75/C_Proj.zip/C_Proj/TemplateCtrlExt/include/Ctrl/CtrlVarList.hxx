#ifndef _CTRLVARLIST_H_
#define _CTRLVARLIST_H_

#include <CtrlSment.hxx>
#include <CtrlVar.hxx>

#include <SimplePtrArray.hxx>

class Variable;
class CharString;


/*  author VERANTWORTUNG: Martin Koller */
/** Klasse zur Speicherung von mehreren Ctrl-Variablen in der Reihenfolge der
  * Aufrufe von append()
  @classification internal use
*/

class DLLEXP_CTRL CtrlVarList : public CtrlSment
{
  public:
    /// Constructor
    CtrlVarList(int line = -1, int file = -1)
      : CtrlSment(line, file), count(0), first(0), last(0), act(0) {}

    /// Constructor
    CtrlVarList(const CtrlVarList &list);

    /// Destructor
    ~CtrlVarList();

    /// Evaluate the type of this statement.
    virtual int isA(SmentType type) const {return type == SMENT_VARLIST;}

    unsigned getNumberOfItems() const {return count;}

    /// remove all elements from list and delete them
    void clear();

    /// inserts the var at the beginning of the list
    void insert(CtrlVar *var);

    /// removes the first var from the list and deletes the object
    void removeFirst();

    /// appends the var as last element in the list
    void append(CtrlVar *var);

    /// cuts the first CtrlVar* off the list (not deletes the CtrlVar)
    CtrlVar *cutFirstVar();

    /// cuts the last CtrlVar * off the list (not deletes the CtrlVar)
    CtrlVar *cutLastVar();

    /** finds a var in the list.
      * The search is done from first to last
      * var, so that the first occurance of a name in the list is found,
      * even if the name exists twice
      */
    Variable *findVar(const CharString &which) const;

    /** finds a CtrlVar in the list.
      * The search is done from first to last
      * var, so that the first occurance of a name in the list is found,
      * even if the name exists twice
      */
    CtrlVar *findCtrlVar(const CharString &which) const;

    /** Cuts a CtrlVar from the list.
      * The search is done from first to last
      * var, so that the first occurance of a name in the list is found,
      * even if the name exists twice
      */
    CtrlVar *cutCtrlVar(const CharString &which);

    CtrlVar *findCtrlVar(CtrlVarId id) const;
    CtrlVar *cutCtrlVar(CtrlVarId id);

    /// First CtrlVar in the List
    CtrlVar *getFirstVar() const { return (act = first); }
    ///
    CtrlVar *getNextVar() const { return (act = (act ? (CtrlVar *) act->getNext() : 0)); }
    ///
    CtrlVar *getLastVar() const { return last; }
    ///
    bool hasDuplicateEntries(CharString &whichName) const;
    ///
    bool hasCommonEntriesWith(const CtrlVarList *aList, CharString &whichName) const;

    virtual void writeTrace(CtrlThread *thread, bool writeValue = true) const;

    bool checkIntegrity(const CharString &location, CtrlThread *thread) const;

    ///
    const CtrlSment *execute(CtrlThread *thread) const;

    ///
    const CtrlExpr *getFirstExpr(CtrlThread *thread) const;

    /** dump the whole tree for code coverage analysis
        @param to output stream
      */
    virtual void dumpCoverageTree(std::ostream &to, CoverageAction action = DUMP) const;

  private:
    CtrlVar *buildHashTable(CtrlVarId id) const;

    unsigned count;
    CtrlVar *first;
    CtrlVar *last;
    mutable CtrlVar *act;

    mutable SimplePtrArray<CtrlVar> idHashTable;
};

//--------------------------------------------------------------------------------

// Inline because it is called _very_ often
inline CtrlVar *CtrlVarList::findCtrlVar(CtrlVarId id) const
{
  if (count == 0)
    return 0;
  else if (count < 16)
  {
    // Arbitrary cut off factor. Maintaining the hash table is
    // expensive and for small sizes the gain minimal.
    CtrlVar *ptr = first;

    while (ptr && ptr->getId() != id)
      ptr = ptr->getNextVar();

    return ptr;
  }
  else
  {
    // Use hash table
    if (idHashTable.getNumberOfItems() == 0)
      return buildHashTable(id);  // also searches for CtrlVar

    unsigned key = (unsigned) (id % idHashTable.getNumberOfItems());

    for (unsigned idx = 1; ; idx += 2)
    {
      CtrlVar *ptr = idHashTable[key];

      // Found if slot is empty (no such key) or we have the id
      if ( ptr == 0 || ptr->getId() == id)
        return ptr;

      // Quadratic probing:
      // key is key + 0, key + 1, key + 4, key + 9, ...
      // Or incremental written:
      // key, key += 1; key += 3, key += 5, ...
      key = (key + idx) % idHashTable.getNumberOfItems();
    }

    // never reached
    return 0;
  }
}

#endif /* _CTRLVARLIST_H_ */
