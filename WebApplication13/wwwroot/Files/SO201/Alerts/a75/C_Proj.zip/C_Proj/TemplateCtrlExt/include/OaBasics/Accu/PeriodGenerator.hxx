#ifndef _PERIODGENERATOR_H_
#define _PERIODGENERATOR_H_

#ifndef _TIMEVAR_H_
#include <TimeVar.hxx>
#endif

// ========== PeriodGenerator ============================================================

/** uniform interface for derivate classes of type PeriodGenerator
    @n A PeriodGenerator may be initialized with some conditions (depending on implementation).
    According to that conditions you can retrieve period information like:
    - if PeriodGenerator currently holds a legal period
    - time of period start
    - time of period end
    Moreover, you can switch to another (the subsequent) period.
    @classification ETM internal
  */
class DLLEXP_OABASICS PeriodGenerator
{
  public:
    /// constructor
    PeriodGenerator()
      : validFlag(PVSS_FALSE),
        periodCount(0),
        currentPeriodStart(TimeVar::NullTimeVar),
        currentPeriodStop(TimeVar::MaxTimeVar) {}

    /// virtual destructor
    virtual ~PeriodGenerator() {};
    
    /// abstract function to set internal values for the next period
    /// @n Implement this in derivate classes.
    virtual PVSSboolean goNextPeriod() = 0;
    
    /// return beginning of the current period
    const TimeVar getPeriodStart() const
      { return currentPeriodStart; }
      
    /// return end of the current period
    const TimeVar getPeriodEnd() const
      { return currentPeriodStop; }
      
    /// return if the current period is valid
    PVSSboolean isValidPeriod() const
      { return validFlag; }
      
    /// return count of elapsed periods
    PVSSulong getPeriodCount() const
      { return periodCount; }

  protected:
    /// member, where validity flag is stored
    PVSSboolean validFlag;

    /// member, where number of period is stored
    PVSSulong periodCount;

    /// member, where start time of current period is stored
    TimeVar currentPeriodStart;

    /// member, where end time of current period is stored
    TimeVar currentPeriodStop;
    
  private:
    // so that the compiler does not define them itself !!

    // copy constructor
    PeriodGenerator(const PeriodGenerator &) {} //COVINFO LINE: defensive (AP: disallow copy ctor)
    // assignment operator
    PeriodGenerator &operator=(const PeriodGenerator &) { return *this; } //COVINFO LINE: defensive (AP: disallow operator=)
    
};

#endif /* _PERIODGENERATOR_H_ */
