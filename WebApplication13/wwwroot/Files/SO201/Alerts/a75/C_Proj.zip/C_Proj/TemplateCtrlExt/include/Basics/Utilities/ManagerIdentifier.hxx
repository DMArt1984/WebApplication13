#ifndef _MANAGERIDENTIFIER_H_
#define _MANAGERIDENTIFIER_H_

// System-Include-Files
class itcNdrUbSend;
class itcNdrUbReceive;

#ifndef _TYPES_HXX_
#include <Types.hxx>
#endif

#ifndef _DPTYPES_HXX_
#include <DpTypes.hxx>
#endif

#ifndef _CHARSTRING_H_
#include <CharString.hxx>
#endif

#ifndef _ALLOCATOR_H_
#include <Allocator.hxx>
#endif

#include <fstream>


// Vorwaerts-Deklaration der Eigenen Klasse
class ManagerIdentifier;

// ========== ManagerType ============================================================
/// manager types known by PVSS-II
enum ManagerType {
  NO_MAN,
  /// (1).  event manager
  EVENT_MAN,
  /// (2). driver manager
  DRIVER_MAN,
  /// (3). database manager
  DB_MAN,
  /// (4). ui manager
  UI_MAN,
  /// (5). control manager
  CTRL_MAN,
  /// (6). ascii manager
  ASCII_MAN,
  /// (7). api manager
  API_MAN,
  /// (8). device manager
  DEVICE_MAN,
  /// (9). redundancy manager
  REDU_MAN,
  /// (10). report manager
  REPORT_MAN,
  /// (11). DDE manager - OBSOLETE
  DDE_MAN_OBSOLETE,
  /// (12). distribution manager
  DIST_MAN,
  MAX_MAN // This must always be the last one!
};

/// the valid manager numbers. not all manager numbers are available for public use
enum ManagerNumber
{
  // simple manager number range
  MNUM_MIN = 0,
  /// first valid manager number (1)
  MNUM_FIRST = 1,
#ifndef NO_NGA
  /// number of the next gen archiver frontend manager of type DB_MAN
  MNUM_NGA = 120,
#endif
  /// last valid manager number (255)
  MNUM_MAX = 255

  // diagnostic manager number range
  // IM 95368 WOKL 24.9.09 entfernt
  // DIAG_MNUM_MIN = 110,
  // DIAG_MNUM_MAX = 119
};

/// the manager subtype as used by some managers to activate extensions
enum ManagerSubType
{
  /// normal manager, the default subtype
  MSUB_BASIC     = 0x0,
  /// extended manager, enable extended manager mode
  MSUB_EXTENDED  = 0x1,
  // manager doesn't need a license
  MSUB_NO_LICENSE = 0x2,  // TI946
  /// Manager in second (redundant) connection to a different server (EV')
  MSUB_REDCONN = 0x4,
  /// Manager with redundant connection
  MSUB_REDUNDANT = 0x8,
  /// Manager in second lan connection to the same server
  MSUB_REDLAN = 0x10,
  /// extended manager 2, enable extended manager mode IM 118548
  MSUB_EXTENDED_2  = 0x20,
  /// extended manager 3, enable extended manager mode
  MSUB_EXTENDED_3  = 0x40
};


// defines fuer user root und default user
#define ROOT_USER     PVSSuserIdType(0)
#define DEFAULT_USER  PVSSuserIdType(-1)

/**
 * Used to identify a single manager instance.
 *
 * Each manager has a code of at least 2 numbers. The first number shows the manager type,
 * the second can be set on program invocation and is the "-num " argument.
 * The optional last parameter is the system number, 0 may be used for the own (default) system.
 */
class DLLEXP_BASICS ManagerIdentifier
{
  public:
    /**
     * Creates a new instance with the specified values.
     *
     * @param newManType The type of the manager
     * @param newManNum The number of the manager
     * @param newSystem The system number of the manager
     */
    ManagerIdentifier(PVSSuchar newManType, PVSSuchar newManNum, SystemNumType newSystem = 0);

    /**
     * Creates a new instance with the specified values.
     *
     * @param newManType The type of the manager
     * @param newManNum The number of the manager
     * @param newSystem The system number of the manager
     */
    ManagerIdentifier(ManagerType newManType, PVSSuchar newManNum, SystemNumType newSystem = 0);

    /**
     * Creates a new instance with the specified values.
     *
     * @param newManType The type of the manager
     * @param newManNum The number of the manager
     * @param newSubType Subtype flags to enable extensions
     * @param newSys The system number of the manager
     */
    ManagerIdentifier(ManagerType newManType, PVSSuchar newManNum, ManagerSubType newSubType, SystemNumType newSys = 0);

    /**
     * Creates an empty instance with type NO_MAN, manager number 0 and system number 0.
     */
    ManagerIdentifier();

    /**
     * Returns a string in the format "TYPE_NUM"
     */
    CharString toString() const;

    /**
     * Returns the long name of the specified manager type (e.g. "EVENT").
     */
    static const char * getTypeStringLong(ManagerType type);

    /**
     * Returns the short name of the specified manager type (e.g. "EV" for the
     * event manager).
     */
    static const char * getTypeStringShort(ManagerType type);

    /**
     * Returns a string in the format "(Sys TYPE num - Replica')"
     */
    CharString getLogString() const;

    /**
     * Returns the name of the manager type
     */
    CharString getManName() const;

    /**
     * Returns the manager type for the specified name (e.g. "event")
     *
     * @param manName The name of a manager type, in the same format that getManName() returns.
     */
    static ManagerType getManTypeFromName(const char *manName);

    // Operatoren :
    friend DLLEXP_BASICS itcNdrUbSend &operator<<(itcNdrUbSend &ndrStream, const ManagerIdentifier &manAdd);
    friend DLLEXP_BASICS itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream, ManagerIdentifier &manAdd);

    friend DLLEXP_BASICS std::ostream &operator<<(std::ostream &strStream, const ManagerIdentifier &manAdd);
#if 0
    friend DLLEXP_BASICS std::ifstream &operator>>(std::ifstream &strStream, ManagerIdentifier &manAdd);
    friend DLLEXP_BASICS std::ofstream &operator<<(std::ofstream &ofStream, const ManagerIdentifier &manAdd);
#endif
    /**
     * Compares two manager identifiers.
     *
     * If one of the two identifiers has the system number 0, the system numbers
     * are considered equal.
     * Manager type and number are directly compared.
     * If the identifiers match in system number, manager type and manager number,
     * and one of them has the MSUB_REDUNDANT flag set, they are considered equal.
     * Lastly, the replica values are directly compared.
     * All other properties are ignored.
     */
    int operator==(const ManagerIdentifier &rval) const;

    /**
     * The opposite of operator==()
     */
    int operator!=(const ManagerIdentifier &rval) const;

    ManagerIdentifier &operator=(const ManagerIdentifier &rVal);

    /// Check for an empty ManagerIdentifier (e.g. equal with ManagerIdentifier())
    bool isNull() const;

    /**
     * Converts the identifier to a number with the format
     * ssssssRR ssssssss tttttttt nnnnnnnn
     * (from most to least significant bit).
     *
     * s...System Number
     * R...Replica
     * t...Manager Type
     * n...Manager Number
     */
    int convToInt() const;

    /**
     * Reads an identifier from the specified number
     * (see convToInt() for the format).
     */
    void convFromInt(int intVar);

    /// Get the system number
    SystemNumType  getSystem() const;
    /// Set the system number
    void  setSystem(SystemNumType newManSys);

    /**
     * Returns the replica number.
     *
     * This is 0 if only MSUB_REDUNDANT is set,
     * 1 if neither MSUB_REDCONN nor MSUB_REDUNDANT are set,
     * 2 if only MSUB_REDCONN is set,
     * or 255 if both MSUB_REDCONN and MSUB_REDUNDANT are set.
     */
    PVSSuchar getReplica() const;

    /**
     * Sets the replica number.
     *
     * This is 0 if only MSUB_REDUNDANT should be set,
     * 1 if neither MSUB_REDCONN nor MSUB_REDUNDANT should be set,
     * 2 if only MSUB_REDCONN should be set,
     * or 255 if both MSUB_REDCONN and MSUB_REDUNDANT should be set.
     */
    void setReplica(PVSSuchar replica);

    /**
     * Toggles the MSUB_REDCONN flag.
     */
    void toggleReplica();

    /**
     * Get the connection number (for the MsgItcDispatcher).
     *
     * Will return 1 for replica 0 and 1, and 2 for replica 2 and 255.
     */
    PVSSuchar getConnection() const;

    /// Get the manager type
    PVSSuchar getManType() const;
    /// Set the manager type
    void setManType(PVSSuchar newManType);

    /// Get the manager number
    PVSSuchar getManNum() const;
    /// Set the manager number
    void setManNum(PVSSuchar newManNum);

    /// Get manager number flagged with MSUB_REDCONN
    unsigned  getReplicaManNum() const;

    /// Check extended flag
    PVSSboolean  getExtendedFlag() const   {return (manSubType & MSUB_EXTENDED) ? PVSS_TRUE : PVSS_FALSE;}
    /// Set extended flag
    void         setExtendedFlag()         {manSubType |= MSUB_EXTENDED;}
    /// Clear extended flag
    void         clearExtendedFlag()       {manSubType &= ~MSUB_EXTENDED;}

    /// Check extended-2 flag
    PVSSboolean  getExtended2Flag() const   {return (manSubType & MSUB_EXTENDED_2) ? PVSS_TRUE : PVSS_FALSE;}
    /// Set extended flag
    void         setExtended2Flag()         {manSubType |= MSUB_EXTENDED_2;}
    /// Clear extended flag
    void         clearExtended2Flag()       {manSubType &= ~MSUB_EXTENDED_2;}

    /// Check extended-3 flag
    PVSSboolean  getExtended3Flag() const   {return (manSubType & MSUB_EXTENDED_3) ? PVSS_TRUE : PVSS_FALSE;}
    /// Set extended flag
    void         setExtended3Flag()         {manSubType |= MSUB_EXTENDED_3;}
    /// Clear extended flag
    void         clearExtended3Flag()       {manSubType &= ~MSUB_EXTENDED_3;}

    /// Check flag for redundant manager (will connect to 2 Data / Event)
    PVSSboolean  getRedundantFlag() const  {return (manSubType & MSUB_REDUNDANT) ? PVSS_TRUE : PVSS_FALSE;}
    /// Set flag for redundant manager (will connect to 2 Data / Event)
    void         setRedundantFlag()        {manSubType |= MSUB_REDUNDANT;}
    /// Clear flag for redundant manager (will connect to 2 Data / Event)
    void         clearRedundantFlag()      {manSubType &= ~MSUB_REDUNDANT;}

    /// Get redlan flag (comes over a 2nd lan card)
    PVSSboolean  getRedLanFlag() const     {return (manSubType & MSUB_REDLAN) ? PVSS_TRUE : PVSS_FALSE;}

    /// Set flag for redundant lan connection (comes over a 2nd lan card)
    void         setRedLanFlag()           {manSubType |= MSUB_REDLAN;}
    /// Clear flag for redundant lan connection (comes over a 2nd lan card)
    void         clearRedLanFlag()         {manSubType &= ~MSUB_REDLAN;}

    /// Get the manager subtype flags
    PVSSuchar    getManSubType() const;
    /// Set the manager subtype flags
    void         setManSubType(PVSSuchar newManSubType);
    AllocatorDecl;

  protected:
    /**
     * Long manager names (e.g. "EVENT").
     */
    static const char *mannames[];

    /**
     * Short manager names (e.g. "EV").
     */
    static const char *shortnames[];

  private:
    SystemNumType  manSystem;
    PVSSuchar      manType;
    PVSSuchar      manNum;
    PVSSuchar      manSubType;
};

// -----------------------------------------------------------------------------
// inline-methods:

inline  SystemNumType ManagerIdentifier::getSystem() const
{
  return manSystem;
}


inline  void ManagerIdentifier::setSystem(SystemNumType newManSys)
{
  manSystem = newManSys;
}


inline  PVSSuchar ManagerIdentifier::getManType() const
{
  return manType;
}


inline  void ManagerIdentifier::setManType(PVSSuchar newManType)
{
  manType = newManType;
}


inline  PVSSuchar ManagerIdentifier::getManNum() const
{
  return manNum;
}


inline void ManagerIdentifier::setManNum(PVSSuchar newManNum)
{
  manNum = newManNum;
}


inline  unsigned ManagerIdentifier::getReplicaManNum() const
{
  if (getReplica())
    return manNum + MNUM_MAX + 1;
  else
    return manNum;
}


inline  PVSSuchar ManagerIdentifier::getManSubType() const
{
  return manSubType;
}


inline void ManagerIdentifier::setManSubType(PVSSuchar newManSubType)
{
  manSubType = newManSubType;
}


inline ManagerIdentifier::ManagerIdentifier(PVSSuchar newManType, PVSSuchar newManNum, SystemNumType newManSys)
  : manSystem(newManSys), manType(newManType), manNum(newManNum), manSubType((char)MSUB_BASIC)
{
}

inline ManagerIdentifier::ManagerIdentifier(ManagerType newManType, PVSSuchar newManNum, SystemNumType newManSys)
   : manSystem(newManSys), manType((char)newManType), manNum(newManNum), manSubType((char)MSUB_BASIC)
{
}

inline ManagerIdentifier::ManagerIdentifier(ManagerType newManType, PVSSuchar newManNum,
    ManagerSubType newSubType, SystemNumType newManSys)
  : manSystem(newManSys), manType((char)newManType), manNum(newManNum), manSubType(newSubType)
{
}


inline ManagerIdentifier::ManagerIdentifier()
  : manSystem(0), manType((char)NO_MAN), manNum(0), manSubType((char)MSUB_BASIC)
{
}

inline bool ManagerIdentifier::isNull() const
{
  return manSystem.isNull() && (manType == (char)NO_MAN) &&
         (manNum == 0) && (manSubType == (char)MSUB_BASIC);
}

inline int ManagerIdentifier::operator==(const ManagerIdentifier &rVal) const
{
  // System number '0' means "any system"
  if (manSystem && rVal.manSystem && manSystem != rVal.manSystem)
    return 0;

  if (manType != rVal.manType || manNum != rVal.manNum)
    return 0;

  // Check replica. Redundant manager belong to all replica
  if (getRedundantFlag() || rVal.getRedundantFlag())
    return 1;

  if (getReplica() == rVal.getReplica())
    return 1;

  return 0;
}


inline int ManagerIdentifier::operator!=(const ManagerIdentifier &rVal) const
{
  return !(operator==(rVal));
}


inline ManagerIdentifier &ManagerIdentifier::operator=(const ManagerIdentifier &rVal)
{
  manSystem = rVal.manSystem;
  manType = rVal.manType;
  manNum  = rVal.manNum;
  manSubType = rVal.manSubType;
  return *this;
}

#endif /* _MANAGERIDENTIFIER_H_ */
