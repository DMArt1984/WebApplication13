#ifndef _EXTTIMEVAR_H_
#define _EXTTIMEVAR_H_

#ifndef _TIMEVAR_H_
#include <TimeVar.hxx>
#endif

#ifndef _CHARSTRING_H_
#include <CharString.hxx>
#endif
 
#ifndef _ALERTIDENTIFIER_H_
#include <AlertIdentifier.hxx>
#endif

// ========== ExtTimeVar ============================================================

/** Variable class derived from TimeVar and accesses an additional counter
    to distiguish different alerts triggered at the same time
    @n An additional DpIdentifier holds the datapoint element of the alert.
    @see AlertTime
  */
//author Robert Trausmuth
class DLLEXP_BASICS ExtTimeVar : public TimeVar
{
  public:
  
    /** constructor, initialisation with zero values
      */
    ExtTimeVar() : TimeVar() { setCount(0); cachedIsA = EXTTIME_VAR; }

    /** constructor, initialisation with the given time
        @param tv the TimeVar to inirialise the base class
        @param ct the value to set alarm counter
      */
    ExtTimeVar(const TimeVar &tv, PVSSushort ct = 0) 
        : TimeVar(tv) { setCount(ct); cachedIsA = EXTTIME_VAR; }

    /** constructor, initialisation with the given alert time
        @param at the AlertTime to set
      */
    ExtTimeVar(const AlertTime &at)
        : TimeVar(at) { setCount(at.getCount()); cachedIsA = EXTTIME_VAR; }

    /** copy constructor
        @param rVal the ExtTimeVar, which shall be copied from
      */
    ExtTimeVar(const ExtTimeVar &rVal) 
        : TimeVar(rVal), dpId_(rVal.dpId_) { setCount(rVal.getCount()); cachedIsA = EXTTIME_VAR; }
    
    /** allocator deallocator class
      */
    AllocatorDecl;

    /** clone the current ExtTimeVar object
        @return the Variable as clone of this object
      */
    virtual Variable *clone() const {return new ExtTimeVar(*this); }

    /** try to convert
        @param to the VariableType, to convert to
        @param out the VariablePtr, to convert from
        @return OK: conversion successful, "out" will be allocated
             @n OUT_OF_RANGE: conversion basically possible, but the value of "out" lies
                out of range "to", "out" wll be alocated in spite of this (!!!) and gets
                Min or Max of possible range
             @n CONV_NOT_DEFINED: type changing not possible, "out" will be set to 0
      */
    virtual ConvertResult convert(VariableType to, VariablePtr &out) const;

    /** comparison operator ==
    @param rVal the Variable to compare with
    @n Important: this operator checks the VariableType, so two objects are only equal, if
    they also have the same class (no conversion is done; see other operators)
    @return 0 if not equal else 1
    */
    virtual int operator==(const Variable &rVal) const;

    /** assignment operator used for type conversions
        @param rVal the Variable to assign 
        @return the resulting Variable
      */
    virtual Variable &operator=(const Variable &);

    /** assignment operator used for type conversions
        @param rVal the Variable to assign 
        @return the resulting Variable
      */
    ExtTimeVar &operator=(const ExtTimeVar &rVal) { time_ = rVal.time_; dpId_ = rVal.dpId_; return *this; }
    
    /** non virtual comparision operator == (to spare virtual call)
        @param rVal the ExtTimeVar to compare with
        @return 0 if not equal else 1
      */
    int operator==(const ExtTimeVar &rVal) const { return time_ == rVal.time_; }
    
    /** non virtual comparision operator != (to spare virtual call)
        @param rVal the ExtTimeVar to compare with
        @return 0 if equal else 1
      */
    int operator!=(const ExtTimeVar &rVal) const { return !operator==(rVal); }

    /** non virtual comparision operator < (to spare virtual call)
        @param rVal the ExtTimeVar to compare with
        @return 0 if the ExtTimeVar to compare with is smaller else 1
      */
    int operator<(const ExtTimeVar &rVal) const  { return time_ < rVal.time_; }

    /** non virtual comparision operator > (to spare virtual call)
        @param rVal the ExtTimeVar to compare with
        @return 0 if the ExtTimeVar to compare with is bigger else 1
      */
    int operator>(const ExtTimeVar &rVal) const  { return time_ > rVal.time_; }

    /** non virtual comparision operator <= (to spare virtual call)
        @param rVal the ExtTimeVar to compare with
        @return 0 if the ExtTimeVar to compare with is smaller or equal else 1
      */
    int operator<=(const ExtTimeVar &rVal) const {return !operator>(rVal);}

    /** non virtual comparision operator >= (to spare virtual call)
        @param rVal the ExtTimeVar to compare with
        @return 0 if the ExtTimeVar to compare with is bigger or equal else 1
      */
    int operator>=(const ExtTimeVar &rVal) const {return !operator<(rVal);}

    /** cast to const AlertTime &
        @return the resulting AlertTime
      */
    operator const AlertTime ()  const       { return time_; }

   /** operator << for itcNdrUbSend stream
       @param ndrStream the stream, which to send to
       @param eTime the ExtTimeVar
     */
    friend DLLEXP_BASICS itcNdrUbSend &operator<<(itcNdrUbSend &ndrStream, const ExtTimeVar &eTime);

    /** operator >> for itcNdrUbReceive stream
       @param ndrStream the stream, which to receive from
       @param eTime the ExtTimeVar
     */
    friend DLLEXP_BASICS itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream, ExtTimeVar &eTime);

   /** operator << for std stream
       @param ofStream the stream, which to send to
       @param tVar the ExtTimeVar
     */
    friend DLLEXP_BASICS std::ostream &operator<<(std::ostream &ofStream, const ExtTimeVar &tVar);

    /** get the alert counter
        @return value of alert counter
      */
    PVSSushort getCount() const  {return time_.getCount();}

    /** set the alert counter
        @param ct the PVSSushort to set
      */
    void setCount(PVSSushort ct) {time_.setCount(ct);}

    /** get DP identifier
        @return the DP identifier
      */
    const DpIdentifier &getDpId() const {return dpId_;}

    /** set DP identifier
        @param dpid the DpIdentifier to set
      */
    void setDpId(const DpIdentifier &dpid) {dpId_ = dpid;}

    /** set all members
        @param nTime the number of seconds to set
        @param nMilli the number of milli seconds to set
        @param ct the value of alert counter to set
      */
    void set(time_t nTime = 0, PVSSshort nMilli = 0, PVSSushort ct = 0)
      {setValue(nTime, (PVSSlong)nMilli); setCount(ct);}

    /** set alert time
        @param time the AlertTime to set
      */
    void set(const AlertTime &time) { time_ = time; }

    /** get alert time
        @return the AlertTime
      */
    const AlertTime & getAlertTime() const { return time_; }

    /** set alert time via AlertIdentifier
        @param alId the AlertIdentifier to set
      */
    void set(const AlertIdentifier &alId)
      {time_ = alId.getAlertTime(); dpId_ = alId;}

    /** get AlertIdentifier
        @return the AlertIdentifier
      */
    AlertIdentifier getAlertIdentifier() const { return AlertIdentifier(dpId_, time_); }

    /** allocate new ExtTimeVar
        @return the new ExtTimeVar
      */
    virtual Variable *allocate() const;

    /** return type of variable
        @return EXTTIME_VAR
      */
    virtual VariableType isAUncached() const { return EXTTIME_VAR; }
    
	/** return type of variable
      @param varType the VariableType to check
	    @return EXTTIME_VAR if ExtTimeVar else return other VariableType
    */
    virtual VariableType isAUncached(VariableType varType) const;

	  /** send to output stream
        @param ofStream the stream, which to send to
      */
    void outToFile(std::ostream &ofStream) const;
 
    /** format the value according to the format string
        @return the string representation of the value
        @param format the format string
            @n If the string is not empty, it is used as an argument to the strftime function. <br>
               Else the time is printed as YYYY.MM.DD HH:MM:SS.mmm.
    */
    virtual CharString formatValue(const CharString &format) const;

    /** format the value according to a format string
        @param format the format string
            @n If the string is not empty it is used as an argument to the sprintf function (if useful). <br>
               Else a default is used.
        @param target the CharString as buffer, which is directly written to
        @param len the length of the buffer
        @return the int as number of bytes written into target without 0-byte,
                or a negative value on error (like buffer too small)
    */
    virtual int formatValue(const CharString &format, char *target, size_t len) const;

    /** print the content to an output stream
        @param to the stream to print to
        @param level the int to control the amount of debug information, nothing is printed if level = 0
      */
    virtual void debug(std::ostream &to, int level) const;

  private:
  
    void outNdrUb(itcNdrUbSend &ndrStream) const;
    void inNdrUb(itcNdrUbReceive &ndrStream);

    // this is used as container for query purposes, has no direct impact on ExtTimeVar behavior
    DpIdentifier dpId_;
};

#endif /* _EXTTIMEVAR_H_ */
