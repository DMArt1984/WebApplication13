#ifndef _COMPONENTNAMES_H_
#define _COMPONENTNAMES_H_

#include <ManagerIdentifier.hxx>

/// The maximum length of a component name without the terminating '\0'.
#define MAX_COMPONENT_NAME_LENGTH 19
  // Do not make it smaller than 19. This may lead to errors.
  // Be careful increasing the value. It is used in fixed size table
  // entries and for formating, which will give truncated or ugly
  // formated names for manager.

/// The collection of the names of all manager and tools.
///
/// For future extensions and to avoid the propagation of a generated
/// .hxx-file the constants are wrapped by static methods.
///
/// The class has only static methods.

namespace ComponentNames
{
    /// All known components
    /// @warn Do not renumber entries, only append new items at the end
    /// of each section. Deleting entries causes a renumbering.
    enum ComponentID {
      /// A Null Value.
      NO_COMPONENT = 0,
      /// The event manager
      EVENT_COMPONENT = EVENT_MAN,
      /// A driver manager
      DRIVER_COMPONENT = DRIVER_MAN,
      /// The data manager
      DATA_COMPONENT = DB_MAN,
      /// The user interface manager
      UI_COMPONENT = UI_MAN,
      /// The control manager
      CTRL_COMPONENT = CTRL_MAN,
      /// The ASCII manager
      ASCII_COMPONENT = ASCII_MAN,
      /// An API manager
      API_COMPONENT = API_MAN,
      /// A devive manager
      DEVICE_COMPONENT = DEVICE_MAN,
      /// The redundancy manager
      REDU_COMPONENT = REDU_MAN,
      /// The report manager
      REPORT_COMPONENT = REPORT_MAN,
      /// The distribution manager
      DIST_COMPONENT = DIST_MAN,

      /// A dummy entry to have a fixed number to start specific managers.
      FIRST_SPECIFIC_MANAGER_COMPONENT = 1000,
      /// The APC manager
      APC_COMPONENT,
      /// The atchive manager
      ARCHIV_COMPONENT,
      /// The BACNET driver manager
      BACNET_COMPONENT,
      /// The CERB manager
      CERB_COMPONENT,
      /// The CHMGR manager
      CHMGR_COMPONENT,
      /// The data background manager
      DATABG_COMPONENT,
      /// The DL manager
      DL_COMPONENT,
      /// the DNP3 driver manager
      DNP3_COMPONENT,
      /// The IEC driver manager
      IEC_COMPONENT,
      /// The MOD-Bus dirver manager
      MOD_COMPONENT,
      /// The OLEDB manager
      OLEDB_COMPONENT,
      /// The OPC manager
      OPC_COMPONENT,
      /// The OPCAE manager
      OPCAE_COMPONENT,
      /// The OPCSVR manager
      OPCSRV_COMPONENT,
      /// The OPCSVRAE manager
      OPCSRVAE_COMPONENT,
      /// The OPCUA manager
      OPCUA_COMPONENT,
      /// The OPCUASVR manager
      OPCUASRV_COMPONENT,
      /// The PID manager
      PID_COMPONENT,
      /// The process monitor
      PMON_COMPONENT,
      /// The RDB manager
      RDB_COMPONENT,
      /// The RK512 manager
      RK512_COMPONENT,
      /// The S7 driver manager
      S7_COMPONENT,
      /// The simulation driver manager
      SIM_COMPONENT,
      /// The SINAUT manager
      SINAUT_COMPONENT,
      /// The SNMP manager
      SNMP_COMPONENT,
      /// The SNMPA manager
      SNMPA_COMPONENT,
      /// The split manager
      SPLIT_COMPONENT,
      /// The SSI manager
      SSI_COMPONENT,
      /// The TPL manager
      TLP_COMPONENT,
      /// The TLS manager
      TLS_COMPONENT,
      /// The value archive manager
      VALARCH_COMPONENT,
      /// The video manager
      VIDEO_COMPONENT,
      /// The VRMPRX manager
      VRMPRX_COMPONENT,
      /// The multiplexing proxy
      MXPROXY_COMPONENT,

      /// A dummy entry to have a fixed number to start with the tools.
      FIRST_TOOL_COMPONENT = 2000,
      /// The tool buildidlist
      BUILDIDLIST_COMPONENT,
      /// The tool chtrans
      CHTRANS_COMPONENT,
      /// The tool convertdb
      CONVERTDB_COMPONENT,
      /// The tool createdb
      CREATEDB_COMPONENT,
      /// The tool encryptctrl
      ENCRYPTCTRL_COMPONENT,
      /// The tool gethw
      GETHW_COMPONENT,
      /// The tool license
      LICENSE_COMPONENT,
      /// The tool logviewer
      LOGVIEWER_COMPONENT,
      /// The tool media
      MEDIA_COMPONENT,
      /// The tool nametoid
      NAMETOID_COMPONENT,
      /// The tool parse
      PARSE_COMPONENT,
      /// The tool repairdb
      REPAIRDB_COMPONENT,
      /// The tool revise
      REVISE_COMPONENT,
      /// The tool synctypes
      SYNCTYPES_COMPONENT,
      /// The tool sysnames
      SYSNAMES_COMPONENT,
      /// The tool trans
      TRANS_COMPONENT,
      /// The tool tunnel
      TUNNEL_COMPONENT,
      /// A dummy entry to get the last value.
      MAX_COMPONENT  // This must always be the last one!
    };

    /// Get the filename of a component.
    /// @return A pointer to a static area which must not be deleted.
    ///
    DLLEXP_BASICS const char * getName(ComponentID component);


    /// Checks if name is equal to any of the names the getName-method
    /// return.
    ///
    /// @param name the name to be checked.
    ///
    /// @return true when the name is equal to any name we know.
    ///   false otherwise.
    ///
    DLLEXP_BASICS bool isWellKnownComponent(const char * name);

};
#endif /* _COMPONENTNAMES_H_ */
