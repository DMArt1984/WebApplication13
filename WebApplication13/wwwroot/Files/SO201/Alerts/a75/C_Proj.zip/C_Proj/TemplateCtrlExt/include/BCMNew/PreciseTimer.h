#ifndef _PRECISETIMER_H_
#define _PRECISETIMER_H_

#include <time.h>

#if defined (OS_FREEBSD) || defined (_WIN32)
#include <sys/timespec.h>
#else
#include <time.h>
#endif

/**
 * @reentrant
 */
class DLLEXP_BCM PreciseTimer
{
  public:
    /// Constructor
    PreciseTimer() : startTime_(0), endTime_(0) {}

  public:
    /**
      Start the timer, that is start a completly new measurement.
      start time is set to current time and end time is set to 0.
     */
    void start();

    /**
      Resume the timer, that is continue the measurement but ignore
      the time the timer was stopped or paused.
      start time is set to current time minus elapsed time and
      end time is set to 0.
     */
    void resume();

    /**
      Pause the timer that is save the current elapsed time.
      If the timer is currently stopped or paused nothing happens,
      else start time is left as is and end time is set to the current time.
      If the timer was not yet started this is the same as calling start.
      */
    void pause();

    /**
      Stop the timer that is set end time unconditionaly to the current time.
      Elapsed time is the time since the timer was started.
      You may call stop several times to get "lap times".
      */
    void stop();

    /**
      Reset the timer to its initial state. start and end time are set to 0.
      */
    void reset();

    /**
      Get the elapsed time. If the timer is running this is the difference
      between the current time and the start time. If the timer is stopped
      or paused this is the difference betwen end time (the time when the
      timer was stopped or paused) and the start time.
      */
    double elapsedTime() const;

    /**
      Returns true if the timer is running.
      */
    bool isRunning() const;

  private:
    double timeNanos() const;

  private:
    double startTime_;
    double endTime_;
	
    friend class UNIT_TEST_FRIEND_CLASS;

};


inline double PreciseTimer::timeNanos() const
{
  struct timespec ts;

  if (OS_gettimer(&ts) < 0)
    return 0.;

  return ts.tv_sec + (ts.tv_nsec / 1000000000.);
}


inline void PreciseTimer::start()
{
  startTime_ = timeNanos();
  endTime_ = 0;
}


inline void PreciseTimer::resume()
{
  startTime_ = timeNanos() - elapsedTime();
  endTime_ = 0;
}


inline void PreciseTimer::pause()
{
  if (endTime_ == 0)
    endTime_ = timeNanos();
}


inline void PreciseTimer::stop()
{
  endTime_ = timeNanos();
}


inline void PreciseTimer::reset()
{
  startTime_ = endTime_ = 0;
}


inline double PreciseTimer::elapsedTime() const
{
  if (startTime_ == 0)
    return 0.;

  return (endTime_ ? endTime_ : timeNanos()) - startTime_;
}


inline bool PreciseTimer::isRunning() const
{
  return startTime_ != 0 && endTime_ == 0;
}


#endif
