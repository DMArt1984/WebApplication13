#ifndef _CNSVISITOR_H_
#define _CNSVISITOR_H_

#include <SystemNumType.hxx>
#include <ViewId.hxx>
#include <LangText.hxx>
#include <CharString.hxx>

#include <CNSDataIdentifier.hxx>
#include <CNSNode.hxx>

// forward declaration
class CommonNameService;

/**
 * Pure abstract base class, which allows application specific actions
 * (collecting, counting, calculating) on CNSNodes.
 * A CNSVisitor can be passed to CommonNameService::getNodes(). For each node
 * matching the search criteria given to CommonNameService::getNodes(), visit()
 * will be called with the matching node as argument.
 *
 * This class is a pure abstract base class. Override visit() to implement your
 * visitor logic.
 */
class DLLEXP_DATAPOINT CNSVisitor
{
public:

  /// Return type of visit(), controls the tree traversal.
  enum NavigationHints
  {
    /// Continue traversal.
    CONTINUE = 0,
    /// Do not visit the descendants of the current node.
    STOP_DESCENT,
    /// Abort traversal. No further nodes will be visited.
    ABORT
  };

  /**
   * Used for searches to define which names should be used for search.
   * For searching in names and display names, use ALL_NAMES.
   * It is possible to combine modes.
   */
  enum SearchMode
  {
    NAME = 1,
    DISPLAY_NAME = 2,
    ALL_NAMES = NAME | DISPLAY_NAME,
    CASE_INSENSITIVE = 4
  };

  /// Used for searches to define that all views are to be searched.
  static const ViewId ALL_VIEWS;
  /// Used for searches to define that all systems are to be searched.
  static const SystemNumType ALL_SYSTEMS;
  /// Used for searches to define that all data identifiers should be matched.
  static const CNSDataIdentifierType ALL_TYPES;
  /// Used for searches to define that all display name languages should be matched.
  static const LanguageIdType ALL_LANGUAGES;

public:
  /// Destructor
  virtual ~CNSVisitor() { }

public:
  /**
   * Override this method to implement your visitor logic.
   *
   * @param sys         The system id of node
   * @param view        The ViewId of node
   * @param node        The CNSNode that matches at least the basic criteria.
   *                    all additional criterias are checked by this method.
   * @param path        The CNS path of node (e.g. System1.securityView:EITC.entranceCam)
   * @param displayPath The CNS path of all displayNames of node
   *                    (e.g. System1.�berwachungsansicht:Firma.Eingangskamera)
   *
   * @retval CONTINUE Continue tree traversal.
   * @retval STOP_DESCENT Do not visit the descendants of the current node.
   * @retval ABORT Abort tree traversal. No further nodes will be visited.
   */
  virtual NavigationHints visit(const SystemNumType &sys,
                                const ViewId &view,
                                const CNSNode &node,
                                const CharString &path,
                                const LangText &displayPaths) = 0;

};

#endif // _CNSVISITOR_H_
