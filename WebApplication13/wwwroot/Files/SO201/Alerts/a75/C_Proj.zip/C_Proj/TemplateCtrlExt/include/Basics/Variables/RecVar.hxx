#ifndef _RECVAR_H_
#define _RECVAR_H_

#ifndef _VARIABLE_H_
#include <Variable.hxx>
#endif

#ifndef _DYNPTRARRAY_H_
#include <DynPtrArray.hxx>
#endif
 
#ifndef _CHARSTRING_H_
#include <CharString.hxx>
#endif

// ========== RecVar ============================================================

/** Variable class, which can contain an arbitrary number of pointers to any Variable derived class
    @n This variable is not for being sent through a message. it has only locally restricted purposes.
   */
//author Johannes Ertl
class DLLEXP_BASICS RecVar : public Variable
{
  public:

    /** constructor, initialisation with zero values
       */
    RecVar() { cachedIsA = REC_VAR; }

    /** copy constructor
        @param recVar the RecVar, which shall be copied from
      */
    RecVar(const RecVar &recVar) : Variable(recVar) { cachedIsA = REC_VAR; operator=(recVar); }

    /** destructor
      */
    ~RecVar() {}

    /** allocator deallocator class
      */
    AllocatorDecl;

  /** operator << for itcNdrUbSend stream
      @param ndrStream the stream, which to send to
      @param record the RecVar
    */
    friend DLLEXP_BASICS itcNdrUbSend &operator<<(itcNdrUbSend &ndrStream, const RecVar &record);

  /** operator >> for itcNdrUbReceive stream
      @param ndrStream the stream, which to receive from
      @param record the RecVar
    */
    friend DLLEXP_BASICS itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream, RecVar &record);

    /** overloaded comparison operator ==
        @param rVal the Variable to compare with
            @n Important: this operator checks the VariableType, so two objects are only equal, if
               they also have the same class (no conversion is done; see other operators).
        @return 0 if not equal else 1
      */
    int operator==(const Variable &rVal) const;

    /** overloaded assignment operator used for type conversion
        @param rVal the Variable to convert
        @return the resulting Variable
      */
    Variable &operator=(const Variable &rVal);

    /** non virtual assignment operator
        @param rVal the RecVar to assign
        @return the resulting RecVar
      */
    RecVar &operator=(const RecVar &rVal) { operator=((const Variable&)rVal); return *this; }

    /** tool function, append a new Variable to the list
        @param newVar the Variable to append (the variable is cloned)
        @return PVSS_TRUE if success, PVSS_FALSE if resizing the array failed (e.g. no more memory)
        @classification public use, call
      */
    PVSSboolean append(const Variable &newVar);

    /** tool function, append a new Variable to the list
        @param newVarPtr the VariablePtr to append
        @return PVSS_TRUE if success, PVSS_FALSE if resizing the array failed (e.g. no more memory)
        @classification public use, call
      */
    PVSSboolean append(VariablePtr newVarPtr);

    /** tool function, remove a Variable from the list at a specific location
        @param index the location for the Variable (the variable is deleted)
        @return PVSS_TRUE if success, PVSS_FALSE if Variable does not exist or other error
        @classification public use, call
    */
    IL_DEPRECATED("deprecated, use removeAt() instead")
    PVSSboolean remove(DynPtrArrayIndex index);

    /** just a rename of remove, which will be deprecated
    @classification public use, call
    */
    PVSSboolean removeAt(DynPtrArrayIndex index);

    /** tool function, cut a Variable out of the list at a specific location
        @param index the location for the Variable
        @return a pointer to the Variable object, caller is responsible for deleting it
        @classification public use, call
    */
    Variable *cut(DynPtrArrayIndex index);

    /** insert given pointer and capture it
        @param index the location for the Variable
        @return PVSS_TRUE on success, PVSS_FALSE if insertion failed (e.g. no more memory)
        @classification public use, call
    */
    PVSSboolean insertAt(DynPtrArrayIndex index, Variable *var);

    /** insert given pointer as first and capture it
        @return PVSS_TRUE on success, PVSS_FALSE if insertion failed (e.g. no more memory)
        @classification public use, call
    */
    PVSSboolean insertAsFirst(Variable *var) { return insertAt(0, var); }

    /** tool function, exchange a Variable in the list at a specific location
        @param index the location for the Variable
        @param changeTo the new Variable, which is captured
        @return a pointer to the old Variable, caller is responsible for deleting it
        @classification public use, call
    */
    Variable *exchange(DynPtrArrayIndex index, Variable *changeTo);
    
    /** empty the RecVar, delete all contained variables
      */
    void clear() { value.clear(); }

    /** get number of items
        @return the number of items
      */
    unsigned int getNumberOfItems() const {return value.getNumberOfItems(); }

    /** get record length, the same as number of items
        @return the number of items
      */
    unsigned int getRecLength() const { return getNumberOfItems(); }

    /** get the first Variable
        @return the first Variable or 0 if no items in list
      */
    Variable *getFirstVar() const;

    /** get the current Variable
        @return the current Variable or 0 if beyond the last item
      */
    IL_DEPRECATED("deprecated, use getAt() instead")
    Variable *getCurrentVar() const;

    /** get the next Variable
        @return the next Variable or 0 if no more items in list
      */
    IL_DEPRECATED("deprecated, use getAt() instead")
    Variable *getNextVar() const;

    /** get variable at given position
        @param idx the given position (starting with 0)
        @return the Variable at given position
      */
    Variable *getAt(DynPtrArrayIndex idx) const;
    
    /** allocate new RecVar
        @return the new RecVar
      */
    Variable *allocate() const { return new RecVar; }

    /** return type of variable
        @return REC_VAR
      */
    VariableType isAUncached() const { return REC_VAR; }

	/** return type of variable
        @param varType the VariableType to check
	    @return REC_VAR if RecVar else return other VariableType
      */
    VariableType isAUncached(VariableType varType) const;

    /** clone the current RecVar object
        @return the Variable as deep copy of this object
      */
    virtual Variable *clone() const {return new RecVar(*this);}

    /** Print the content of the Variable to the output stream.
        @param to Specifies the output stream.
        @param level Level controls the amount of debug information 
        printed. Nothing is printed if level == 0.
    */
    virtual void debug(std::ostream &to, int level) const;

  private:
    void outNdrUb(itcNdrUbSend &ndrStream) const;
    void inNdrUb(itcNdrUbReceive &ndrStream);
    DynPtrArray<Variable> value;
    
    virtual CharString formatValue(const CharString &format) const;

    /** Format the value according to a format string.
        @param format The format string. If the string is not empty is is
               used as an argument to the sprintf function (if useful).
               Else a default is used
        @param target This is a buffer with length len, which is directly written to.
               This method is more performant than the one which returns a CharString,
               because no alloc is done.
        @return Number of bytes written into target without 0-byte,
                or a negative value on error (like buffer too small)
     */
    virtual int formatValue(const CharString &format, char *target, size_t len) const;
};

#endif /* _RECVAR_H_ */
