#ifndef _TRANSLATELIST_H_
#define _TRANSLATELIST_H_

/*
VERANTWORTUNG: Christoph Theis       
BESCHREIBUNG:  Verwaltet die Items einer Uebersetungstabelle
  03/97 (ChT)
*/

#include  <stdlib.h>

#ifndef _CHARSTRING_H_
#include  <CharString.hxx>
#endif

#ifndef _DYNVAR_H_
#include  <DynVar.hxx>
#endif

#ifndef _RESOURCES_H_
#include  <Resources.hxx>
#endif

// Nur eine forward dekl. fuer die Eintraege. Mehr muss man an dieser Stelle
// noch nicht wissen.
class  TranslateItem;

/** The translation list class manages a list of string translations. This translation 
    list is initialised by a text file. The first line of the text contains the list
    of languages, delimited by '\t' sign.
    
    The following lines contains the translation of words for those languages, one
    word per line. Words are delimited by '\t' sign, while the translations are in the
    same order as the languages in the first line.
    @classification CoreTest
*/
class DLLEXP_BASICS TranslateList 
{
  public:
    friend class UNIT_TEST_FRIEND_CLASS;
    /**
    Default constructor. 
    */
    TranslateList();

   /**
   Destructor.
   */
   ~TranslateList();    

    /**
    Reads a dictionary from the file. 

    @param  dictFile The dictionary file. 
    
    @return PVSS_TRUE if the dictionary was read succesfully, otherwise PVSS_FALSE. 
    */
    PVSSboolean  readDictionary(const CharString &dictFile);

    /**
    Writes a dictionary to a new file. 

    @param  dictFile The file where the dictionary will be written. 
    
    @return PVSS_TRUE if the dictionary was written succesfully, otherwise PVSS_FALSE. 
    */
    PVSSboolean  writeDictionary(const CharString &dictFile);

    /**
    Gets a dictionary. 
    
    @param  langs           DynVar of type VarText. Each VarText contains a language name. 
    @param [in,out] dict    DynVar of type VarText. Each VarText element contains a tab-delimited
    string with translations of one particular word into each language specified in langs parameter.
        
    @return PVSS_TRUE if the dictionary was retrieved successfully, otherwise PVSS_FALSE. 
    */
    PVSSboolean getDictionary(const DynVar & langs, DynVar &dict);

    // Aendern der Uebersetzungstabelle. langs ist ein DYN_DYN_UINTEGER
    // und gibt die Spalten an. dict ist eine Tabelle mit MetaLang an
    // erster Stelle und in den folgenden Spalten die Sprachen aus langs    
    /**
    Merges a dictionary. 
    
    @param  langs           DynVar with VarTexts specifying the languages which will be merged. 
    @param  dict            DynVar with the resulting dictionary. 
    
    @return PVSS_TRUE if the merge was successfull, otherwise PVSS_FALSE. 
    */
    PVSSboolean mergeDictionary(const DynVar &langs, const DynVar &dict);

    // Die Spalten sind durch die Sprache definiert, erste is default meta
    /**
    Define languages by a string with language names. The 1st column is a default language. 
    
    @param  str The string with the language names delimited by a separator. 
    @param  sep The separator character. 
    
    @return PVSS_TRUE (or PVSS_FALSE if the langs has incorrect format). 
    */
    PVSSboolean defineLangs(const CharString &str, char sep);

    /**
    Adds n new entry defined by the 'str' string array delimited by 'sep'.
    First element is the Token, then translations to each language follows.
    
    @param  str The string with translations for a certain word. 
    @param  sep The seperator. 
    */
    void addEntry(const CharString &str, char sep);      

    /**
    Translate string 'in' array delimited by the 'del' delimiter in the language defined by 'lang'.
    The resulting string is returned in the 'out' parameter.
    
    @param  in          The input string array. 
    @param [in,out] out The output string array. 
    @param  del         The delimiter of input string array. 
    @param  lang        The language index. 
    */
    void translateString(const CharString &in, CharString &out, char del, LanguageIdType lang);  

    /**
    Sorts the list. 
    */
    void  sortTheList();

  protected:

  private:

    /**
    Translates the token. 
    This is an internal translation method that returns a translation for a given input string 'in' for the language
    identified by 'lang'.
    
    @param  in          The input string. 
    @param [in,out] out The output translation. 
    @param  lang        The language index. 
    
    @return True, if the translation was found. Otherwise false. 
    */
    PVSSboolean translateToken(const CharString &in, CharString &out, LanguageIdType lang);   

    /// method for sorting two TranslateItems
    static  int  sortList(const void *, const void *);

    /// finds a token inside a string
    static  int  findToken(const void *, const void *);
    
    /// returns the token
    TranslateItem * getToken(const CharString &token);
    
    // Die Liste ist ein einfaches lineares Array von Pointern auf TranslateItem,
    // die mit qsort sortiert und mit bsearch durchsucht wird. 
    /// List of TranslateItems
    TranslateItem **list;    // Die Liste der Items
    
    /// array of language names
    int     *langIdx;        // Die Liste der Sprachen
    
    /// number of languages
    int     numOfLangs;      // Anzahl der Sprachen in langId
    
    /// number of items in the dictionary
    size_t  nItems;          // Zahl der Items in der Liste
    
    /// size of the dictionary (will be expanded by 256 items if necessary)
    size_t  listSize;        // Die Groesse der Liste
    
    /// sorted flag
    int  unsorted;           // Flag, Liste muss noch sortiert werden
    
    // language names
    DynVar  title;
   
    // so that the compiler does not define them itself !!

    // copy constructor
    TranslateList(const TranslateList &) {} //COVINFO LINE: defensive (AP: disallow copy ctor)
    // assignment operator
    TranslateList &operator=(const TranslateList &) { return *this; } //COVINFO LINE: defensive (AP: disallow operator=)
};

#endif /* _TRANSLATELIST_H_ */
