// DATEIBESCHREIBUNG ==============================================================
// DATEINAME:     DpMsgDrvAnswer.hxx
// 
// BESCHREIBUNG:	DpMsgDrvAnswer ist von der DpMsgAnswer abgeleitet
//                die komplette Funktionalitaet wird uebernommen
//                es kommt ein Counter Element dazu, ueber welches die
//                Anzahl der noch zu bestaetigenden Gruppen gezaehlt wird
//                erst wenn alle Gruppne bestaetigt sind, soll die Message versendet werden

#ifndef _DPMSGDRVANSWER_H_
#define _DPMSGDRVANSWER_H_

// Vorwaerts-Deklarationen :
class DpMsgDrvAnswer;

// ========== DpMsgAnswerPtr ============================================================

typedef DpMsgDrvAnswer* DpMsgDrvAnswerPtr;

#include <DpMsgAnswer.hxx>

class DLLEXP_MESSAGES DpMsgDrvAnswer : public DpMsgAnswer
{
  friend class UNIT_TEST_FRIEND_CLASS;    // ein Unit-Test braucht erweiterten zugriff auf diese Klasse

  public:

    /// constructor, initialisation with zero values
    DpMsgDrvAnswer() : DpMsgAnswer(), counter_(0) {}

    /// destructor
    ~DpMsgDrvAnswer() {}

     /// param constructor
    /// @param requestMsg the request message
    DpMsgDrvAnswer(const DpMsg &requestMsg) : DpMsgAnswer(requestMsg), counter_(0) {}

    // Operatoren :

    /// operator << for itcNdrUbSend stream
    /// @param ndrStream the stream, which to send to
    /// @param dpMsgAnswer the answer message
    friend DLLEXP_MESSAGES itcNdrUbSend &operator<<(itcNdrUbSend &ndrStream, const DpMsgDrvAnswer &dpMsgDrvAnswer);

    /// operator >> for itcNdrUbReceive stream
    /// @param ndrStream the stream, which to receive from
    /// @param dpMsgAnswer the answer message
    friend DLLEXP_MESSAGES itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream, DpMsgDrvAnswer &dpMsgDrvAnswer);

    /// allocate a new message
    virtual Msg *allocate() const { return new DpMsgDrvAnswer; }

    /// special method
    /// increase counter
    int increaseCounter() {return ++counter_;}

    /// special method
    /// decrease counter
    int decreaseCounter() {return ((counter_ > 0) ? --counter_ : 0);}

    /// special method
    /// get counter value
    int getCounterValue() const { return counter_; }

    /// get answer group by position
    /// or zero if position invalid
    AnswerGroup *getGroupByPosition(int pos) const;

  protected:

    /// send to itcNdrUbSend stream
    /// @param ndrStream the stream, which to send to
    virtual void outNdrUb(itcNdrUbSend &ndrStream) const;

    /// receive from itcNdrUbReceive stream
    /// @param ndrStream the stream, which to receive from
    virtual void inNdrUb(itcNdrUbReceive &ndrStream);

private:
    int counter_;

// --------------------------------------------------
// these are not used - make them private!

    /// copy constructor
    /// @param newMsg the answer message to copy
    DpMsgDrvAnswer(const DpMsgDrvAnswer &newMsg) {}


};

#endif /* _DPMSGANSWER_H_ */
