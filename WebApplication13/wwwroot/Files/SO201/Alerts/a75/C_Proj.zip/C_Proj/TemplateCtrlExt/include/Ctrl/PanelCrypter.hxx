#ifndef _PanelCrypter_H_
#define _PanelCrypter_H_

// Author: Martin Koller, Nov. 2013
// Class to encrypt/decrypt a panel file
// @classification ETM internal

#include <QObject>

class DLLEXP_HIDDEN PanelCrypter : public QObject
{
  Q_OBJECT // COVINFO LINE: defensive (no Qt test here, tstrass)

  public:
    // return a hash value from given password
    static QByteArray getPasswordHash(const QString &password);

    // encrypt a given panel file
    // return an empty string on success, else a (translated) error message
    // @editPasswordHash when given, the panel stores also a hashed password to allow edit in gedi
    QString encrypt(const QString &absoluteFileName, const QString &licenseKey, bool makeBackup,
                    const QByteArray *editPasswordHash = nullptr);

    QString encrypt(const QString &absoluteFileName,
                    const QString &targetFilePath,
                    QString licenseKey = QString(), bool makeBackup = false,
                    const QByteArray *editPasswordHash = nullptr);

    // after calling encrypt, this tells if encryption failed due to the file being already encrypted
    bool wasAlreadyEncrypted() const { return wasEncrypted; }

    // low level method to encrypt given byte array (with internal key)
    static QByteArray encrypt(const QByteArray &source, const QByteArray &cryptoVersion, bool doEncrypt = true);

    // low level method to decrypt given byte array (with internal key)
    static QByteArray decrypt(const QByteArray &source, const QByteArray &cryptoVersion);

  signals:
    // emitted during encrypt() when a .bak file is created and when the encrypted panel is created
    void fileAdded(const QString &absolutePath);

  private:
    bool wasEncrypted = false;
};

#endif
