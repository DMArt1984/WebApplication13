#ifndef _DPVCGROUP_H_
#define _DPVCGROUP_H_

#include <ostream>
#include <DpIdValueList.hxx>
#include <ManagerIdentifier.hxx>
#include <PtrList.hxx>
#include <PtrListItem.hxx>
#include <TimeVar.hxx>
#include <Allocator.hxx>

class DpVCItem;

// ========== DpVCGroup ============================================================

/** This class contains a list of DpIdentifier / value pairs.
  It also contains information about the manager, user etc. which caused the 
  value change.
 */
class DLLEXP_MESSAGES DpVCGroup : public DpIdValueList
{
  /// operator << for itcNdrUbSend stream
  /// @param ndrStream the stream, which to send to
  /// @param msg the DpMsgDriverVC
  friend DLLEXP_MESSAGES itcNdrUbSend &operator<<(itcNdrUbSend &ndrStream, const DpMsgDriverVC &msg);

  /// operator >> for itcNdrUbReceive stream
  /// @param ndrStream the stream, which to receive from
  /// @param msg the DpMsgDriverVC
  friend DLLEXP_MESSAGES itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream, DpMsgDriverVC &msg);

  /// operator << for itcNdrUbSend stream
  /// @param ndrStream the stream, which to send to
  /// @param item the DpVCGroup
  friend DLLEXP_MESSAGES itcNdrUbSend &operator<<(itcNdrUbSend &ndrStream, const DpVCGroup &item);

  /// operator >> for itcNdrUbReceive stream
  /// @param ndrStream the stream, which to receive from
  /// @param item the DpVCGroup
  friend DLLEXP_MESSAGES itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream, DpVCGroup &item);

  public:

  /// constructor
  /// @param manager the manager ID
  /// @param user the user
  /// @param time the time stamp
  DpVCGroup(const ManagerIdentifier &manager, PVSSuserIdType user, const TimeVar &time);

  /// copy constructor
  /// @param group the DpVCGroup to copy
  DpVCGroup(const DpVCGroup &group);

  /// default constructor, initialisation with zero values
  DpVCGroup() : originUser(0), originTime(0, 0) {}

  /// destructor
  ~DpVCGroup();

  /// AllocatorDecl
  AllocatorDecl;

  // Spezielle Methoden :

  /// send debug info to output stream
  /// @param to the output stream
  /// @param level the debug level
  virtual void debug(std::ostream &to, int level) const;

  /// get the manager which caused the value change
  const ManagerIdentifier &getOriginManager() const      {return originManager;}

  /// set the manager which caused the value change
  /// @param manId the manager ID to set
  void  setOriginManager(const ManagerIdentifier &manId) {originManager = manId;}
  
  /// get the ID of the user, who caused the value change, e.g. operating the vision module
  PVSSuserIdType getOriginUser() const     { return originUser; }

  /// set the ID of the user, who caused the value change, e.g. operating the vision module
  /// @param user the user ID to set
  void  setOriginUser(PVSSuserIdType user) { originUser = user; }
  
  /// get the time when the value change occured
  const TimeVar &getOriginTime() const     { return originTime; }

  /// set the time when the value change occured
  /// @param time the value to set
  void setOriginTime(const TimeVar &time)  { originTime = time; }

  /// insert a new item 
  /// @n This method checks if all attributes in this group are unique and 
  /// sort type attributes to a front.
  /// @param dpId the DpIdentifier
  /// @param varPtr the value
  /// @n The class takes responsibility for this pointer.
  /// @return PVSS_TRUE if success else PVSS_FALSE
  PVSSboolean insertValueChange(const DpIdentifier &dpId, VariablePtr varPtr);
  
  /// comparison operator ==
  /// @param rVal the DpVCGroup to compare with
  /// @return 0 if not equal else 1
  int operator==(const DpVCGroup &rVal) const;

  /// append a DpVCItem to the group without any checks
  /// @param itemPtr the pointer to DpVCItem to append
  /// @n The class takes responsibility for the pointer.
  void  append(DpVCItem *itemPtr) {itemList.append(itemPtr);}

  /// get the config from the first item in this group
  /// @n Currently, all values are for the same config.
  /// @param configNrType the config number
  /// @return PVSS_TRUE if success else PVSS_FALSE
  PVSSboolean getConfig(DpConfigNrType &configNrType) const;

  private:
  ManagerIdentifier originManager;
  PVSSuserIdType originUser;
  TimeVar originTime;
};


#endif /* _DPVCGROUP_H_ */
