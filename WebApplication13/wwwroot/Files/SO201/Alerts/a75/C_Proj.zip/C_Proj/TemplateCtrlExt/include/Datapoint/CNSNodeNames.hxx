#ifndef _CNSNODENAMES_H_
#define _CNSNODENAMES_H_

#include <CharString.hxx>
#include <LangText.hxx>
#include <iostream>

class itcNdrUbReceive;
class itcNdrUbSend;


/**
 * A container for the names of a CNS element.
 *
 * It stores a name (restricted 7bit ASCII character set)
 * which is used for addressing, and for each project language
 * a meaningful translation (display name).
 *
 * The characters '.' ':' ';' ',' '[' ']' '*' '?' '{' '}' '@' '$',
 * whitespaces and characters below blank are not allowed for name.
 * For display names only ':', '*' and '?' are forbidden.
 *
 * It is never used for the whole path, it only holds one node's names.
 */
class DLLEXP_DATAPOINT CNSNodeNames
{
public:
// friends
  /// BCM stream output operator
  friend DLLEXP_DATAPOINT itcNdrUbSend &operator<<(itcNdrUbSend &ndrStream, const CNSNodeNames &rval);

  /// BCM stream input operator
  friend DLLEXP_DATAPOINT itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream, CNSNodeNames &rval);

  /// Standard stream output operator. Useful for Unit Tests (CUAssertEQ).
  friend DLLEXP_DATAPOINT std::ostream &operator<<(std::ostream &strStream, const CNSNodeNames &rval);

// constants
  /**
   * Contains the characters that are not allowed in a display name.
   */
  static const char *ILLEGAL_DISPNAME_CHARS;

  /**
   * Contains the characters that are not allowed in a display name separator.
   */
  static const char *ILLEGAL_DISPNAME_SEPARATOR_CHARS;

// other methods
  /**
   * Creates a new instance with all names empty.
   */
  CNSNodeNames();

  /**
   * Creates a new instance with the technical name and all display names
   * initialized to the specified text.
   */
  CNSNodeNames(const CharString &name);

  /**
   * Creates a new instance with the specified technical name and display names.
   */
  CNSNodeNames(const CharString &name, const LangText &displayNames);

  /// Copy constructor
  CNSNodeNames(const CNSNodeNames &rval);

  /// Destructor
  virtual ~CNSNodeNames();

  /// Assignment operator
  CNSNodeNames &operator=(const CNSNodeNames &rval);

  /// Equality operator
  bool operator==(const CNSNodeNames &rval) const;

  /// Inequality operator
  bool operator!=(const CNSNodeNames &rval) const;

  /// Returns the display names
  LangText getDisplayNames() const;

  /// Returns a pointer to the display name for the given language
  const char *getDisplayNamePtr(LanguageIdType lang) const;
  
  /// Returns a pointer to the array of display names
  const char * const *getDisplayNamePtrArray() const;

  /// Returns the name
  CharString getName() const;

  /// Returns a pointer to the name
  const char *getNamePtr() const;

  /// Sets the display names
  void setDisplayNames(const LangText &displayNames);

  /// Sets the name
  void setName(const CharString &name);

  /**
   * Returns true if both name and display names contain only empty strings.
   */
  bool isEmpty() const;

  /**
   * Returns true if neither the name nor the display names contain
   * illegal characters.
   *
   * @see CNSNodeNames
   */
  bool isValid() const;

  /**
   * In addition to the checks done by isValid(), this method further checks
   * that the displayNames do not contain the passed separators in their
   * respective languages.
   *
   * @see isValid()
   * @see CNSNodeNames
   */
  bool isValid(const LangText &separators) const;

  /**
   * Returns true if the specified name contains no illegal characters.
   * For display names use isLegalDisplayName().
   *
   * @see CNSNodeNames
   */
  static bool isLegalName(const char *name);

  /**
   * Returns true if the specified display name contains no illegal characters.
   * Only a reduced set of the illegal characters checked by isLegalName() is
   * used.
   *
   * @see CNSNodeNames
   */
  static bool isLegalDisplayName(const char *displayName);

  /**
   * In addition to the checks done by isLegalDisplayName(const char *displayName),
   * this method further checks that the specified separator is legal and is
   * not contained in the specified display name.
   *
   * @see isLegalDisplayName(const char *displayName)
   * @see CNSNodeNames
   */
  static bool isLegalDisplayName(const char *displayName, const char separator);

  /**
   * Returns true if none of the display names in the specified LangText contain
   * illegal characters. Only a reduced set of the illegal characters checked by
   * isLegalName() is used.
   *
   * @see CNSNodeNames
   */
  static bool isLegalDisplayName(const LangText &displayNames);

  /**
   * In addition to the checks done by isLegalDisplayName(const LangText &displayNames),
   * this method further checks that the displayNames do not contain the passed
   * separators in their respective languages.
   *
   * @see isLegalDisplayName(const LangText &displayNames)
   * @see CNSNodeNames
   */
  static bool isLegalDisplayName(const LangText &displayNames, const LangText &separators);

  /**
   * Returns true if the specified character can be used as separator for
   * display names.
   * The characters ':', '*' and '?' are not allowed as separators.
   */
  static bool isLegalDisplayNameSeparator(char separator);

  /**
   * Returns true if all strings in the specified LangText can be used
   * as separator for display names.
   * All single characters except for ':', '*' and '?' are allowed as separators.
   */
  static bool isLegalDisplayNameSeparator(const LangText &separators);
  
private:
  char *name_;
  char **displayNames_;

  /// Makes a copy of the specified string
  /// (like strdup, which is in POSIX and thus not really portable)
  char *copyStr(const char *str);

  /// (Re-)allocates the array for the display names
  bool initDispNames();

  void getDisplayNames(LangText &result) const;
  void getName(CharString &result) const;
};

//------------------------------------------------------------------------------
// inline methods:

inline CNSNodeNames::CNSNodeNames()
  : name_(0), displayNames_(0)
{
}

//------------------------------------------------------------------------------

inline CNSNodeNames::CNSNodeNames(const CharString &name, const LangText &displayNames)
  : name_(0), displayNames_(0)
{
  setName(name);
  setDisplayNames(displayNames);
}

//------------------------------------------------------------------------------

inline CNSNodeNames::CNSNodeNames(const CNSNodeNames &rval)
  : name_(0), displayNames_(0)
{
  *this = rval;
}

//------------------------------------------------------------------------------

inline LangText CNSNodeNames::getDisplayNames() const
{
  LangText result;
  getDisplayNames(result);
  return result;
}


inline void CNSNodeNames::getDisplayNames(LangText &result) const
{
  if (displayNames_)
    result.setText(displayNames_);
  else
    result = LangText();
}

//------------------------------------------------------------------------------

inline CharString CNSNodeNames::getName() const
{
  CharString result;
  getName(result);
  return result;
}

inline void CNSNodeNames::getName(CharString &result) const
{
  if (name_) 
    result = name_;
  else
    result = "";
}

//------------------------------------------------------------------------------

inline const char *CNSNodeNames::getNamePtr() const
{
  if (name_) return name_;
  return "";
}

//------------------------------------------------------------------------------

inline void CNSNodeNames::setName(const CharString &name)
{
  delete[] name_;
  name_ = copyStr(name.c_str());
}

//------------------------------------------------------------------------------

inline bool CNSNodeNames::operator!=(const CNSNodeNames &rval) const
{
  return ! (*this == rval);
}

#endif // _CNSNODENAMES_H_
