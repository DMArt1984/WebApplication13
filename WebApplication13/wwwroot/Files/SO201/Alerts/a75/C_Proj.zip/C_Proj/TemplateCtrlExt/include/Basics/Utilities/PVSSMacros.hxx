#ifndef _PVSSMACROS_H_
#define _PVSSMACROS_H_

#include <Resources.hxx>
#include <DebugOutput.hxx>
#include <BreakPoint.hxx>
#include <StringStream.hxx>
#include <ErrHdl.hxx>

#ifdef __ANDROID__
#include <android/log.h>
#endif

  /// Performance Counter
  #if defined(_WIN32)

    extern "C" PVSSlonglong *getPerfCounterAddress(const char *ctrName);
    #define GET_PERF_COUNTER_ADDR(ctrName)        getPerfCounterAddress(ctrName)

  #else

    #define GET_PERF_COUNTER_ADDR(ctrName)        0

  #endif

  #define I2B(__expr__)     ((__expr__)? true : false)

  #define ERR_IMPL_SEVERE_UNEXPECTED(__note__)      ERR_HDL__ERROR(ErrClass::ERR_IMPL,   ErrClass::PRIO_SEVERE, ErrClass::UNEXPECTEDSTATE, __note__)
  #define ERR_IMPL_SEVERE(__errCode__, __note__)    ERR_HDL__ERROR(ErrClass::ERR_IMPL,   ErrClass::PRIO_SEVERE, __errCode__, __note__)
  
  #define ERR_SYSTEM_SEVERE(__errCode__, __note__)  ERR_HDL__ERROR(ErrClass::ERR_SYSTEM, ErrClass::PRIO_SEVERE, __errCode__, __note__)  
  #define ERR_SYSTEM_WARNING(__errCode__, __note__) ERR_HDL__ERROR(ErrClass::ERR_SYSTEM, ErrClass::PRIO_WARNING, __errCode__, __note__)  
  #define ERR_SYSTEM_SEVERE_UNEXPECTED(__note__)    ERR_HDL__ERROR(ErrClass::ERR_SYSTEM, ErrClass::PRIO_SEVERE, ErrClass::UNEXPECTEDSTATE, __note__)

  #if defined(_ASSERT_ENABLED_)

    #define DBG_ASSERT(__expr__)          do { if (!(__expr__)) DBG_BREAK; } while(false)


    #define ERR_HDL__ERROR(__type__, __prio__, __code__, __note__)                          \
      do {  StringStream __msg__;                                                   \
            __msg__ << __note__ << " at:" << __LINE__  << " file:" << __FILE__;     \
            ErrHdl::error(__prio__, __type__, 0, __code__, __msg__.str());\
            DBG_BREAK;                                  \
      } while(false)

  #else

    #define DBG_ASSERT(__expr__)         

    #define ERR_HDL__ERROR(__type__, __prio__, __code__, __note__)                          \
      do {  StringStream __msg__;                                                   \
            __msg__ << __note__ << " at:" << __LINE__  << " file:" << __FILE__;     \
            ErrHdl::error(__prio__, __type__, 0, __code__, __msg__.str());\
      } while(false)

  #endif


#ifdef __ANDROID__
  #define DEBUG_CERR(__dbgFlagName__, __msg__)   \
    { \
      std::ostringstream cerr_str; \
      cerr_str << Resources::getProgNameAndTime().c_str() << ",\t" << __dbgFlagName__ << ",\t" << __msg__ << std::endl; \
      __android_log_write(ANDROID_LOG_DEBUG, "WinCC_OA", cerr_str.str().c_str()); \
    }
#else
  #define DEBUG_CERR(__dbgFlagName__, __msg__)   \
    std::cerr << Resources::getProgNameAndTime().c_str() << ",\t" << __dbgFlagName__ << ",\t" << __msg__ << std::endl;
#endif

  /// Print a debug msg without a debug flag.
  #define DEBUG_MSG(__msg__)               \
  {                                        \
    if (DebugOutput::isLogFlagCerr()) { DEBUG_CERR("DBG", __msg__) } \
  }

  /// Print a debug msg, if debug flag is set
  #define DEBUG_PRINT(flag, __msg__) {     \
    if (DebugOutput::isDbgFlag(flag)) {      \
      if (DebugOutput::isLogFlagCerr()) { DEBUG_CERR(DebugOutput::getDbgFlagName(flag).c_str(), __msg__) }  \
    }                                        \
  }

  /// Print a debug msg, if one of two debug flags is set
  #define DEBUG_PRINT2(flag, flag2, __msg__) {                         \
    if (DebugOutput::isDbgFlag(flag) || DebugOutput::isDbgFlag(flag2)) {   \
      if (DebugOutput::isLogFlagCerr()) { DEBUG_CERR(DebugOutput::getDbgFlagName(flag).c_str(), __msg__) }     \
    }                                                                   \
  }


  /** -dbg work.*/
  #define DEBUG_WORK(__msg__)          DEBUG_PRINT(DebugOutput::DBG_WORK, __msg__)

  /** -dbg extbuffer. Give warning when send buffer is extended */
  #define DEBUG_EXTBUFFER(__msg__)     DEBUG_PRINT(DebugOutput::DBG_EXTBUFFER, __msg__)

  /** -dbg inputready. Check sockets if input is ready */
  #define DEBUG_INPUTREADY(__msg__)    DEBUG_PRINT(DebugOutput::DBG_INPUTREADY, __msg__)  
      
  /** -dbg outputready. Check sockets if output is ready */
  #define DEBUG_OUTPUTREADY(__msg__)   DEBUG_PRINT(DebugOutput::DBG_OUTPUTREADY, __msg__)

  //
  #define DEBUG_SNDSTAMP(__msg__)      DEBUG_PRINT(DebugOutput::DBG_SNDSTAMP, __msg__)

  //
  #define DEBUG_RCVSTAMP(__msg__)      DEBUG_PRINT(DebugOutput::DBG_RCVSTAMP, __msg__)

  /** -dbg query. debug query actions */
  #define DEBUG_QUERY(__msg__)         DEBUG_PRINT(DebugOutput::DBG_QUERY, __msg__)

  /** -dbg dispatch. show manager connections */
  #define DEBUG_DISPATCH(__msg__)      DEBUG_PRINT(DebugOutput::DBG_DISPATCH, __msg__)

  /** -dbg api_usr1. first available API debug flag - use at your will */
  #define DEBUG_API_USR1(__msg__)      DEBUG_PRINT(DebugOutput::DBG_API_USR1, __msg__)

  /** -dbg api_usr2. second available API debug flag - use at your will */
  #define DEBUG_API_USR2(__msg__)      DEBUG_PRINT(DebugOutput::DBG_API_USR2, __msg__)

  /** -dbg api_usr3. third available API debug flag - use at your will */
  #define DEBUG_API_USR3(__msg__)      DEBUG_PRINT(DebugOutput::DBG_API_USR3,__msg__)

  //
  #define DEBUG_DM_TIME(__msg__)       DEBUG_PRINT(DebugOutput::DBG_DM_TIME,__msg__)

  //
  #define DEBUG_DM_SETEMPTYSLOT(__msg__)  DEBUG_PRINT(DebugOutput::DBG_DM_SETEMPTYSLOT,__msg__)

  //
  #define DEBUG_DM_SERVICEMODE(__msg__)   DEBUG_PRINT(DebugOutput::DBG_DM_SERVICEMODE, __msg__)

  //
  #define DEBUG_EV_WORK(__msg__)       DEBUG_PRINT(DebugOutput::DBG_EV_WORK, __msg__) 

  //
  #define DEBUG_EV_TIME100(__msg__)    DEBUG_PRINT(DebugOutput::DBG_EV_TIME100, __msg__)

  //
  #define DEBUG_EV_SOURCETIME(__msg__) DEBUG_PRINT(DebugOutput::DBG_EV_SOUCETIME, __msg__)

  //
  #define DEBUG_EV_EVENTFILE(__msg__)  DEBUG_PRINT(DebugOutput::DBG_EV_EVENTFILE, __msg__)

  //
  #define DEBUG_EV_ALERTFILE(__msg__)  DEBUG_PRINT(DebugOutput::DBG_EV_ALERTFILE, __msg__)

  //
  #define DEBUG_EV_EVMAIN(__msg__)     DEBUG_PRINT(DebugOutput::DBG_EV_EVMAIN, __msg__)

  //
  #define DEBUG_UI_PANELTIME(__msg__)  DEBUG_PRINT(DebugOutput::DBG_UI_PANELTIME, __msg__)

  /** -dbg ui_rent. show query performance */
  #define DEBUG_UI_RENT(__msg__)       DEBUG_PRINT(DebugOutput::DBG_UI_RENT, __msg__)

  /** -dbg drv_work. common DRV heartbeat - use */
  #define DEBUG_DRV_WORK(__msg__)      DEBUG_PRINT(DebugOutput::DBG_DRV_WORK, __msg__)

  /** -dbg drv_usr1. first available DRV debug flag - use at your will */
  #define DEBUG_DRV_USR1(__msg__)      DEBUG_PRINT(DebugOutput::DBG_DRV_USR1, __msg__)

  /** -dbg drv_usr2. second available API debug flag - use at your will */
  #define DEBUG_DRV_USR2(__msg__)      DEBUG_PRINT(DebugOutput::DBG_DRV_USR2, __msg__)

  /** -dbg drv_usr3. third available API debug flag - use at your will */
  #define DEBUG_DRV_USR3(__msg__)      DEBUG_PRINT(DebugOutput::DBG_DRV_USR3, __msg__)

  /** -dgb redu. show redundancy messages */
  #define DEBUG_REDUNDANCY(__msg__)    DEBUG_PRINT(DebugOutput::DBG_REDUNDANCY, __msg__)
  #define DEBUG_REDU(__msg__)          DEBUG_PRINT(DebugOutput::DBG_REDUNDANCY, __msg__)

  /** -dbg ctrl_trace. show ctrl trace */
  #define DEBUG_CTRL_TRACE(__msg__)    DEBUG_PRINT(DebugOutput::DBG_CTRL_TRACE, __msg__)

  /** -dbg msg_statistic. show every n sec a snd/rcv statistic */
  #define DEBUG_MSG_STATISTIC(__msg__) DEBUG_PRINT(DebugOutput::DBG_MSG_STATISTIC, __msg__)

  /** -dbg ext_warning, extended Warnings */
  #define DEBUG_EXT_WARNING(__msg__)   DEBUG_PRINT(DebugOutput::DBG_EXT_WARNING, __msg__)

  /** -dbg STATUS32, extended Warnings */
  #define DEBUG_STATUS32(__msg__)   DEBUG_PRINT(DebugOutput::DBG_STATUS32, __msg__)
  
  template <typename DestinationType, typename SourceType> DestinationType PVSSsafe_cast(SourceType const& x)   // SrcT can be deduced,
  {                                                                                                             // but DstT cannot
    PVSSulonglong destTypeMaxValue = (1 << (sizeof(DestinationType) * 8));
    if (x >= destTypeMaxValue)
    {
      ERR_IMPL_SEVERE_UNEXPECTED("loss of data, because of casting " << x << "!");
    }
    return(static_cast<DestinationType>(x));
  }

#endif
