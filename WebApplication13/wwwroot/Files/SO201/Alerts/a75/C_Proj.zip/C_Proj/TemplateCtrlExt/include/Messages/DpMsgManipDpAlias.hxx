#ifndef _DPMSGMANIPDPALIAS_H_
#define _DPMSGMANIPDPALIAS_H_

/*
VERANTWORTUNG: Stanislav Meduna      
BESCHREIBUNG:
*/

#include <DpMsg.hxx>
#include <DpIdentifier.hxx>
#include <LangText.hxx>

/** Create or delete a Datapoint alias. 
    This message is used to request the creation or deletion of a Datapoint alias 
    and also to notify the manager of a new or deleted Datapoint alias.    
*/
class DLLEXP_MESSAGES DpMsgManipDpAlias : public DpMsg
{
  /// Friend class definition.
  friend class DistNewDelBuffer;
  /// Write the instance into the itcNdrUbSend stream.
  friend DLLEXP_MESSAGES itcNdrUbSend &operator<<(itcNdrUbSend &ndrStream, const DpMsgManipDpAlias &msg);
  /// Read the instance from the itcNdrUbReceive stream.
  friend DLLEXP_MESSAGES itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream, DpMsgManipDpAlias &msg);
 
  public:
    /// Action type.
    enum DpAliasActionType
    {
        NO_ALIAS,
        NEW_ALIAS,
        CHANGE_ALIAS,
        DELETE_ALIAS,
        NEW_COMMENT,
        CHANGE_COMMENT,
        DELETE_COMMENT
    };

    /** Constructor.
        @param t Message type. Valid types are DP_MSG_MANIP_DPALIAS and DP_MSG_DPALIAS_REQ.
    */
    DpMsgManipDpAlias(MsgType t);
    /** Constructor.
        For new/change.  
        @param t Message type. Valid types are DP_MSG_MANIP_DPALIAS and DP_MSG_DPALIAS_REQ.
        @param newActType Action type. For possible values see DpAliasActionType.
        @param newDpId DpIdentifier for which the alias is to be manipulated.
        @param newNames Alias texts.
        */
    DpMsgManipDpAlias(MsgType t, DpAliasActionType newActType, 
        const DpIdentifier &newDpId, const LangText &newNames);
    /** Constructor.
        For delete.
        @param t Message type. Valid types are DP_MSG_MANIP_DPALIAS and DP_MSG_DPALIAS_REQ.
        @param newActType Action type. For possible values see DpAliasActionType.
        @param newDpId DpIdentifier for which the alias is to be manipulated.
        */
    DpMsgManipDpAlias(MsgType t, DpAliasActionType newActType, 
        const DpIdentifier &newDpId);
    /// Copy constructor.
    DpMsgManipDpAlias(const DpMsgManipDpAlias &rVal);
    /// Destructor.
    ~DpMsgManipDpAlias();

    /// Comparison operator.
    int operator==(const DpMsgManipDpAlias &rVal);
    /// Comparison operator.
    int operator==(const Msg &rVal);
    /// Assignment operator.
    DpMsgManipDpAlias &operator=(const DpMsgManipDpAlias &rVal);
    /// Assignment operator.
    Msg &operator=(const Msg &rVal);

    /// Get own type.
    MsgType isA() const { return type; }
    /// Check if own type matches other type.
    MsgType isA(MsgType dpMsgType) const
        { return (type == dpMsgType ? type : DpMsg::isA(dpMsgType)); }

    /// Get flag indicating whether answer is required.
    PVSSboolean needsAnswer() const { return (type == DP_MSG_DPALIAS_REQ); }

    /// Create new instance.
    virtual Msg *allocate() const { return new DpMsgManipDpAlias(type); }

    /** Get number of groups.
        This always returns 1.
        */
    virtual PVSSulong getNrOfGroups() const {return 1;};
    /// Get GroupId.
    virtual DpIdentifier getGroupId(PVSSulong) const { return dpId; }

    /// Get system number.
    SystemNumType  getSystem() const {return dpId.getSystem();}

    /** Print the contents of the list to an output stream.   
      Level controls the amount of debug information printed and shall be > 0.
    */
    virtual void debug(std::ostream &to, int level) const;
    
    /// Get action type.
    DpAliasActionType    getActType() const { return actType; }
    /// Set action type.
    void setActType(DpAliasActionType newActType) { actType = newActType; }

    /// Get DpId type.
    const DpIdentifier &getDpId() const { return dpId; }
    /// Set DpId type.
    void setDpId(const DpIdentifier &newDpId) { dpId = newDpId; }
    
    /// Get localized names.
    const LangText &getNames() const { return names; }
    /// Set localized names.
    void setNames(const LangText &newNames) { names = newNames; }

    /// Get UserID.
    PVSSuserIdType getUserId() const { return userId; }
    /// Set UserID.
    void setUserId(PVSSuserIdType uId) { userId= uId; }

    /// Write the instance into the itcNdrUbSend stream.
    virtual void outNdrUb(itcNdrUbSend &ndrStream) const;
    /// Read the instance from the itcNdrUbReceive stream.
    virtual void inNdrUb(itcNdrUbReceive &ndrStream);

  private:
    PVSSuserIdType  userId;
    MsgType         type;
    DpAliasActionType    actType;
    DpIdentifier         dpId;
    LangText             names;
};

#endif /* _DPMSGMANIPDPALIAS_H_ */
