#ifndef  _BIT32_H_  // [
#define  _BIT32_H_

#ifndef _TYPES_HXX_
#include <Types.hxx>
#endif

#include <iostream>


#ifndef NO_BCM
class  itcNdrUbSend;
class  itcNdrUbReceive;
#endif

/**
 * A set of 32 bits which can be separately set and unset.
 */
class DLLEXP_BASICS  Bit32
{
  public:
    /**
     * Creates a new instance with no bit set.
     */
    Bit32() : value_(0) {}

    /**
     * Creates a new instance from the specified unsigned 32bit value.
     */
    Bit32(PVSSulong val) : value_(val) {}

    /**
     * Returns the state of the specified bit.
     *
     * Invalid indices will always return false.
     *
     * @param nr An index between 0 and 31
     * @return True if the bit is set, otherwise false.
     */
    PVSSboolean  getBit(unsigned nr) const;

    /**
     * Sets the specified bit to the specified state.
     *
     * If state is true, the bit will be set, otherwise
     * it will be cleared.
     *
     * @param nr An index between 0 and 31
     * @param state The intended state of the bit.
     */
    void  setBit(unsigned nr, PVSSboolean state);

    /**
     * Sets the specified bit.
     *
     * @param nr An index between 0 and 31
     */
    void  setBit(unsigned nr);

    /**
     * Clears the specified bit.
     *
     * @param nr An index between 0 and 31
     */
    void  clearBit(unsigned nr);
    
    /**
     * Clears all bits.
     *
     * The value will be set to 0.
     */
    void  clearAll()  { value_ = 0; }

    /**
     * Cast to PVSSulonglong.
     */
    operator PVSSulong () const  { return value_; }

    /**
     * binary AND assignment operator.
     */
    Bit32 & operator &= (PVSSulong mask) { value_ &= mask; return *this; }

    /**
     * binary OR assignment operator.
     */
    Bit32 & operator |= (PVSSulong mask) { value_ |= mask;  return *this; }

    /**
     * binary OR operator.
     */
    Bit32 operator | (PVSSulong mask) const { return Bit32(value_ | mask); }

    /**
     * binary AND operator.
     */
    Bit32 operator & (PVSSulong mask) const { return Bit32(value_ & mask); }

    /**
     * Returns the value as unsigned 32bit number.
     */
    PVSSulong getValue() const   { return value_; }

    /**
     * Sets the value to the specified unsigned 32bit number.
     */
    void  setValue(PVSSulong ul) { value_ = ul; }

    /**
     * Writes the specified instance to an output stream.
     */
    friend  std::ostream & operator<<(std::ostream &os, const Bit32 &val) {os << val.value_; return os;}

    /**
     * Reads an instance from an input stream.
     */
    friend  std::istream & operator>>(std::istream &is, Bit32 &val)       {is >> val.value_; return is;}

#ifndef NO_BCM
    /**
     * Writes the specified instance to a network output stream.
     */
    friend  DLLEXP_BASICS itcNdrUbSend & operator<<(itcNdrUbSend &, const Bit32 &);

    /**
     * Reads an instance from a network input stream.
     */
    friend  DLLEXP_BASICS itcNdrUbReceive & operator>>(itcNdrUbReceive &, Bit32 &);
#endif

  private:
    PVSSulong  value_;
};


inline  PVSSboolean  Bit32::getBit(unsigned nr) const
{
  if (nr > 31)
    return PVSS_FALSE;

  return ((value_ & (1 << nr)) ? PVSS_TRUE : PVSS_FALSE);
}


inline void  Bit32::setBit(unsigned nr)
{
  if (nr < 32)
    value_ |= (1 << nr);
}


inline void  Bit32::clearBit(unsigned nr)
{
  if (nr < 32)
    value_ &= ~(1 << nr);
}


inline void  Bit32::setBit(unsigned nr, PVSSboolean state)
{
  (state ? setBit(nr) : clearBit(nr));
}


#endif // ]
