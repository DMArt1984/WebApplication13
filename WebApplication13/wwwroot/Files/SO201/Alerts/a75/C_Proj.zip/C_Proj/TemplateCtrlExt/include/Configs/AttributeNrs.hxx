#ifndef _ATRRIBUTENRS_H_
#define _ATRRIBUTENRS_H_

// DATEIBESCHREIBUNG ==============================================================
// DATEINAME:		AttributeNrs.hxx
// VERANTWORTUNG:	Thomas Exner
// BESCHREIBUNG:	Dieses File wurde geschaffen, um zu verhindern, das wegen
//					dieser paar Konstanten alle die EvConfigs mitlinken muessen.
//					Diese Konstanten werden naemlich von der DpMsgDriverVC
//					benoetigt.

#include <DpTypes.hxx>
#include <Variable.hxx>

const DpAttributeNrType CONFIG_TYPE_ATTR = (DpAttributeNrType)INTEGER_VAR;

const DpAttributeNrType DPVALUE_VALUE_ATTR = (DpAttributeNrType)VARIABLE+101;
const DpAttributeNrType DPVALUE_ORIGINTIME_ATTR = (DpAttributeNrType)TIME_VAR+102;
const DpAttributeNrType DPVALUE_STATE_ATTR = (DpAttributeNrType)BIT32_VAR+103;
const DpAttributeNrType DPVALUE_STATUS64_ATTR = (DpAttributeNrType)BIT64_VAR+103;              // IM 87586: new _original, _online, _offline attribute _status64

const DpAttributeNrType DPVALUE_DPVARIABLE_ACTIVE_BIT_ATTR = (DpAttributeNrType)BIT_VAR+104;
const DpAttributeNrType DPVALUE_DEFAULT_EXPLIZIT_BIT_ATTR = (DpAttributeNrType)BIT_VAR+105;
const DpAttributeNrType DPVALUE_DEFAULT_AUTOMATIC_BIT_ATTR = (DpAttributeNrType)BIT_VAR+106;
const DpAttributeNrType DPVALUE_DEFAULT_BIT_ATTR = (DpAttributeNrType)BIT_VAR+107;                  // virtuelles bit _default
const DpAttributeNrType DPVALUE_OUT_OF_PVSSRANGE_BIT_ATTR = (DpAttributeNrType)BIT_VAR+108;
const DpAttributeNrType DPVALUE_OUT_OF_RANGE_BIT_ATTR = (DpAttributeNrType)BIT_VAR+109;
const DpAttributeNrType DPVALUE_EXPLIZIT_INVALID_BIT_ATTR = (DpAttributeNrType)BIT_VAR+110;
const DpAttributeNrType DPVALUE_AUTOMATIC_INVALID_BIT_ATTR = (DpAttributeNrType)BIT_VAR+111;
const DpAttributeNrType DPVALUE_SECOND_LINE_INVALID_BIT_ATTR = (DpAttributeNrType)BIT_VAR+112;
const DpAttributeNrType DPVALUE_INVALID_BIT_ATTR = (DpAttributeNrType)BIT_VAR+113;                  // virtuelles bit _invalid
const DpAttributeNrType DPVALUE_ORIGINALVALUE_BAD_BIT_ATTR = (DpAttributeNrType)BIT_VAR+114;        // virtuelles bit _bad
const DpAttributeNrType DPVALUE_DEFAULTVALUE_BAD_BIT_ATTR = (DpAttributeNrType)BIT_VAR+115;         // _default_bad
const DpAttributeNrType DPVALUE_ONLINEVALUE_BAD_BIT_ATTR = (DpAttributeNrType)BIT_VAR+116;          // virtuelles bit _online_bad
const DpAttributeNrType DPVALUE_OFFLINEVALUE_BAD_BIT_ATTR = (DpAttributeNrType)BIT_VAR+117;         // virtuelles bit _offline_bad
const DpAttributeNrType DPVALUE_GENERAL_INTER_BIT_ATTR = (DpAttributeNrType)BIT_VAR+118;
const DpAttributeNrType DPVALUE_SINGLE_INTER_BIT_ATTR = (DpAttributeNrType)BIT_VAR+119;
const DpAttributeNrType DPVALUE_PERIPHERY_ACTIVE_BIT_ATTR = (DpAttributeNrType)BIT_VAR+120;
const DpAttributeNrType DPVALUE_OUT_OF_SERVICE_BIT_ATTR = (DpAttributeNrType)BIT_VAR+120;           // _out_of_service
const DpAttributeNrType DPVALUE_MARK_OF_CORRECTION_BIT_ATTR = (DpAttributeNrType)BIT_VAR+121;       // _corr
const DpAttributeNrType DPVALUE_VALUE_IS_COMPRESSED_BIT_ATTR = (DpAttributeNrType)BIT_VAR+122;      // _compr
const DpAttributeNrType DPVALUE_COMP_BASED_ON_CORR_BIT_ATTR = (DpAttributeNrType)BIT_VAR+123;       // _comp_corr
const DpAttributeNrType DPVALUE_ADDITIONAL_CORR_BIT_ATTR = (DpAttributeNrType)BIT_VAR+124;          // _corr_add
const DpAttributeNrType DPVALUE_COMP_BASED_ON_INVALID_BIT_ATTR = (DpAttributeNrType)BIT_VAR+125;    // _comp_inv
const DpAttributeNrType DPVALUE_INVALID_TIME_BIT_ATTR = (DpAttributeNrType)BIT_VAR+126;             // _stime_inv
const DpAttributeNrType DPVALUE_TRANSITION_BIT_ATTR = (DpAttributeNrType)BIT_VAR+127;
const DpAttributeNrType DPVALUE_LAST_VALUE_STORAGE_OFF_BIT_ATTR = (DpAttributeNrType)BIT_VAR+128;

// IM 92322 Indicate "up an down" of values within user bit 
const DpAttributeNrType DPVALUE_VALUE_CHANGED_BIT_ATTR = (DpAttributeNrType)BIT_VAR+129;            // _value_changed
const DpAttributeNrType DPVALUE_VALUE_UP_BIT_ATTR = (DpAttributeNrType)BIT_VAR+130;                 // _value_up

const DpAttributeNrType DPVALUE_USER_DEFINED_1_BIT_ATTR = (DpAttributeNrType)BIT_VAR+133;
const DpAttributeNrType DPVALUE_USER_DEFINED_2_BIT_ATTR = (DpAttributeNrType)BIT_VAR+134;
const DpAttributeNrType DPVALUE_USER_DEFINED_3_BIT_ATTR = (DpAttributeNrType)BIT_VAR+135;
const DpAttributeNrType DPVALUE_USER_DEFINED_4_BIT_ATTR = (DpAttributeNrType)BIT_VAR+136;
const DpAttributeNrType DPVALUE_USER_DEFINED_5_BIT_ATTR = (DpAttributeNrType)BIT_VAR+137;
const DpAttributeNrType DPVALUE_USER_DEFINED_6_BIT_ATTR = (DpAttributeNrType)BIT_VAR+138;
const DpAttributeNrType DPVALUE_USER_DEFINED_7_BIT_ATTR = (DpAttributeNrType)BIT_VAR+139;
const DpAttributeNrType DPVALUE_USER_DEFINED_8_BIT_ATTR = (DpAttributeNrType)BIT_VAR+140;

// IM 87586: new _original, _online, _offline attribute _status64
const DpAttributeNrType DPVALUE_USER_DEFINED_9_BIT_ATTR = (DpAttributeNrType)BIT_VAR+210;
const DpAttributeNrType DPVALUE_USER_DEFINED_10_BIT_ATTR = (DpAttributeNrType)BIT_VAR+211;
const DpAttributeNrType DPVALUE_USER_DEFINED_11_BIT_ATTR = (DpAttributeNrType)BIT_VAR+212;
const DpAttributeNrType DPVALUE_USER_DEFINED_12_BIT_ATTR = (DpAttributeNrType)BIT_VAR+213;
const DpAttributeNrType DPVALUE_USER_DEFINED_13_BIT_ATTR = (DpAttributeNrType)BIT_VAR+214;
const DpAttributeNrType DPVALUE_USER_DEFINED_14_BIT_ATTR = (DpAttributeNrType)BIT_VAR+215;
const DpAttributeNrType DPVALUE_USER_DEFINED_15_BIT_ATTR = (DpAttributeNrType)BIT_VAR+216;
const DpAttributeNrType DPVALUE_USER_DEFINED_16_BIT_ATTR = (DpAttributeNrType)BIT_VAR+217;

const DpAttributeNrType DPVALUE_USER_DEFINED_17_BIT_ATTR = (DpAttributeNrType)BIT_VAR+218;
const DpAttributeNrType DPVALUE_USER_DEFINED_18_BIT_ATTR = (DpAttributeNrType)BIT_VAR+219;
const DpAttributeNrType DPVALUE_USER_DEFINED_19_BIT_ATTR = (DpAttributeNrType)BIT_VAR+220;
const DpAttributeNrType DPVALUE_USER_DEFINED_20_BIT_ATTR = (DpAttributeNrType)BIT_VAR+221;
const DpAttributeNrType DPVALUE_USER_DEFINED_21_BIT_ATTR = (DpAttributeNrType)BIT_VAR+222;
const DpAttributeNrType DPVALUE_USER_DEFINED_22_BIT_ATTR = (DpAttributeNrType)BIT_VAR+223;
const DpAttributeNrType DPVALUE_USER_DEFINED_23_BIT_ATTR = (DpAttributeNrType)BIT_VAR+224;
const DpAttributeNrType DPVALUE_USER_DEFINED_24_BIT_ATTR = (DpAttributeNrType)BIT_VAR+225;

const DpAttributeNrType DPVALUE_USER_DEFINED_25_BIT_ATTR = (DpAttributeNrType)BIT_VAR+226;
const DpAttributeNrType DPVALUE_USER_DEFINED_26_BIT_ATTR = (DpAttributeNrType)BIT_VAR+227;
const DpAttributeNrType DPVALUE_USER_DEFINED_27_BIT_ATTR = (DpAttributeNrType)BIT_VAR+228;
const DpAttributeNrType DPVALUE_USER_DEFINED_28_BIT_ATTR = (DpAttributeNrType)BIT_VAR+229;
const DpAttributeNrType DPVALUE_USER_DEFINED_29_BIT_ATTR = (DpAttributeNrType)BIT_VAR+230;
const DpAttributeNrType DPVALUE_USER_DEFINED_30_BIT_ATTR = (DpAttributeNrType)BIT_VAR+231;
const DpAttributeNrType DPVALUE_USER_DEFINED_31_BIT_ATTR = (DpAttributeNrType)BIT_VAR+232;
const DpAttributeNrType DPVALUE_USER_DEFINED_32_BIT_ATTR = (DpAttributeNrType)BIT_VAR+233;

const DpAttributeNrType DPVALUE_USER_DEFINED_1_BYTE_ATTR = (DpAttributeNrType)CHAR_VAR+234;       /* _userbyte1 - _userbyte4 */
const DpAttributeNrType DPVALUE_USER_DEFINED_2_BYTE_ATTR = (DpAttributeNrType)CHAR_VAR+235;     
const DpAttributeNrType DPVALUE_USER_DEFINED_3_BYTE_ATTR = (DpAttributeNrType)CHAR_VAR+236;
const DpAttributeNrType DPVALUE_USER_DEFINED_4_BYTE_ATTR = (DpAttributeNrType)CHAR_VAR+237;

const DpAttributeNrType DPVALUE_USER_DEFINED_1_WORD_ATTR = (DpAttributeNrType)UINTEGER_VAR+238;   /* _userword1 - _userword2 */
const DpAttributeNrType DPVALUE_USER_DEFINED_2_WORD_ATTR = (DpAttributeNrType)UINTEGER_VAR+239;

const DpAttributeNrType DPVALUE_USER_DEFINED_BITS_ATTR = (DpAttributeNrType)BIT32_VAR+240;        /* _userbits    ] IM 87586 */

const DpAttributeNrType DPVALUE_TEXT_ATTR = (DpAttributeNrType) LANGTEXT_VAR+141;
const DpAttributeNrType DPVALUE_MANID_ATTR = (DpAttributeNrType) UINTEGER_VAR+142;
const DpAttributeNrType DPVALUE_USERID_ATTR = (DpAttributeNrType) UINTEGER_VAR+143;
const DpAttributeNrType DPVALUE_ALERT_RANGE_ATTR = (DpAttributeNrType) UINTEGER_VAR + 144;
const DpAttributeNrType DPVALUE_ONLINETIME_ATTR = (DpAttributeNrType)TIME_VAR+200;
// Nur in Msgs vom Treiber
const DpAttributeNrType DPVALUE_TIME_OF_PERIPH_BIT_ATTR = (DpAttributeNrType) BIT_VAR+300;  
const DpAttributeNrType DPVALUE_VALUE_UNCERTAIN_BIT_ATTR = (DpAttributeNrType) BIT_VAR+250;  

const DpAttributeNrType DBFIRSTARCHIVE_FIRST_ARCHIVE_TIME_ATTR = (DpAttributeNrType) TIME_VAR + 100;
const DpAttributeNrType DBFIRSTARCHIVE_FIRST_ONLINE_TIME_ATTR = (DpAttributeNrType) TIME_VAR + 101;
const DpAttributeNrType DBFIRSTARCHIVE_FIRST_OFFLINE_TIME_ATTR = (DpAttributeNrType) TIME_VAR + 102;

// AlertTypes.hxx
const DpAttributeNrType  DPALERT_ALERT_ACTIVE_ATTR = (DpAttributeNrType) BIT_VAR + 400;
const DpAttributeNrType  DPALERT_ALERT_STATE_ATTR = (DpAttributeNrType) BIT32_VAR + 620;
const DpAttributeNrType  DPALERT_VISIBLE_BIT_ATTR = (DpAttributeNrType) BIT_VAR + 608;
const DpAttributeNrType  DPALERT_ACK_ATTR = (DpAttributeNrType) INTEGER_VAR + 600;
const DpAttributeNrType  DPALERT_ACK_POSSIBLE_BIT_ATTR = (DpAttributeNrType) BIT_VAR + 609;
const DpAttributeNrType  DPALERT_ELDEST_ACK_BIT_ATTR = (DpAttributeNrType) BIT_VAR + 611;
const DpAttributeNrType  DPALERT_ACK_OBLIGATION_BIT_ATTR = (DpAttributeNrType) BIT_VAR + 610;
const DpAttributeNrType  DPALERT_DIRECTION_BIT_ATTR = (DpAttributeNrType) BIT_VAR + 604;
const DpAttributeNrType  DPALERT_COLOR_ATTR = (DpAttributeNrType) TEXT_VAR + 626;
const DpAttributeNrType  DPALERT_PARTNER_ATTR = (DpAttributeNrType) TIME_VAR + 602;
const DpAttributeNrType  DPALERT_DEST_RANGE_ATTR = (DpAttributeNrType) INTEGER_VAR + 621;
const DpAttributeNrType  DPALERT_PRIORITY_ATTR = (DpAttributeNrType) CHAR_VAR + 502;
const DpAttributeNrType  DPALERT_COMMENT_ATTR = (DpAttributeNrType) TEXT_VAR + 623;
const DpAttributeNrType  DPALERT_FOREGROUND_COLOR_ATTR = (DpAttributeNrType) TEXT_VAR + 630;
const DpAttributeNrType  DPALERT_FONTSTYLE_COLOR_ATTR = (DpAttributeNrType) TEXT_VAR + 631;
// multiinstance alerts
const DpAttributeNrType  DPALERT_ALERTID_ATTR = (DpAttributeNrType) TEXT_VAR + 459;
const DpAttributeNrType  DPALERT_EVENT_ATTR = (DpAttributeNrType) INTEGER_VAR + 458;
const DpAttributeNrType  DPALERT_ADD_VALUES_ATTR   = (DpAttributeNrType) DYNANYTYPE_VAR + 4000;
const DpAttributeNrType  DPALERT_ADD_VALUE_1_ATTR  = (DpAttributeNrType) ANYTYPE_VAR + 4001;
const DpAttributeNrType  DPALERT_ADD_VALUE_2_ATTR  = (DpAttributeNrType) ANYTYPE_VAR + 4002;
const DpAttributeNrType  DPALERT_ADD_VALUE_3_ATTR  = (DpAttributeNrType) ANYTYPE_VAR + 4003;
const DpAttributeNrType  DPALERT_ADD_VALUE_4_ATTR  = (DpAttributeNrType) ANYTYPE_VAR + 4004;
const DpAttributeNrType  DPALERT_ADD_VALUE_5_ATTR  = (DpAttributeNrType) ANYTYPE_VAR + 4005;
const DpAttributeNrType  DPALERT_ADD_VALUE_6_ATTR  = (DpAttributeNrType) ANYTYPE_VAR + 4006;
const DpAttributeNrType  DPALERT_ADD_VALUE_7_ATTR  = (DpAttributeNrType) ANYTYPE_VAR + 4007;
const DpAttributeNrType  DPALERT_ADD_VALUE_8_ATTR  = (DpAttributeNrType) ANYTYPE_VAR + 4008;
const DpAttributeNrType  DPALERT_ADD_VALUE_9_ATTR  = (DpAttributeNrType) ANYTYPE_VAR + 4009;
const DpAttributeNrType  DPALERT_ADD_VALUE_10_ATTR = (DpAttributeNrType) ANYTYPE_VAR + 4010;
const DpAttributeNrType  DPALERT_ADD_VALUE_11_ATTR = (DpAttributeNrType) ANYTYPE_VAR + 4011;
const DpAttributeNrType  DPALERT_ADD_VALUE_12_ATTR = (DpAttributeNrType) ANYTYPE_VAR + 4012;
const DpAttributeNrType  DPALERT_ADD_VALUE_13_ATTR = (DpAttributeNrType) ANYTYPE_VAR + 4013;
const DpAttributeNrType  DPALERT_ADD_VALUE_14_ATTR = (DpAttributeNrType) ANYTYPE_VAR + 4014;
const DpAttributeNrType  DPALERT_ADD_VALUE_15_ATTR = (DpAttributeNrType) ANYTYPE_VAR + 4015;
const DpAttributeNrType  DPALERT_ADD_VALUE_16_ATTR = (DpAttributeNrType) ANYTYPE_VAR + 4016;
const DpAttributeNrType  DPALERT_ADD_VALUE_17_ATTR = (DpAttributeNrType) ANYTYPE_VAR + 4017;
const DpAttributeNrType  DPALERT_ADD_VALUE_18_ATTR = (DpAttributeNrType) ANYTYPE_VAR + 4018;
const DpAttributeNrType  DPALERT_ADD_VALUE_19_ATTR = (DpAttributeNrType) ANYTYPE_VAR + 4019;
const DpAttributeNrType  DPALERT_ADD_VALUE_20_ATTR = (DpAttributeNrType) ANYTYPE_VAR + 4020;
const DpAttributeNrType  DPALERT_ADD_VALUE_21_ATTR = (DpAttributeNrType) ANYTYPE_VAR + 4021;
const DpAttributeNrType  DPALERT_ADD_VALUE_22_ATTR = (DpAttributeNrType) ANYTYPE_VAR + 4022;
const DpAttributeNrType  DPALERT_ADD_VALUE_23_ATTR = (DpAttributeNrType) ANYTYPE_VAR + 4023;
const DpAttributeNrType  DPALERT_ADD_VALUE_24_ATTR = (DpAttributeNrType) ANYTYPE_VAR + 4024;
const DpAttributeNrType  DPALERT_ADD_VALUE_25_ATTR = (DpAttributeNrType) ANYTYPE_VAR + 4025;
const DpAttributeNrType  DPALERT_ADD_VALUE_26_ATTR = (DpAttributeNrType) ANYTYPE_VAR + 4026;
const DpAttributeNrType  DPALERT_ADD_VALUE_27_ATTR = (DpAttributeNrType) ANYTYPE_VAR + 4027;
const DpAttributeNrType  DPALERT_ADD_VALUE_28_ATTR = (DpAttributeNrType) ANYTYPE_VAR + 4028;
const DpAttributeNrType  DPALERT_ADD_VALUE_29_ATTR = (DpAttributeNrType) ANYTYPE_VAR + 4029;
const DpAttributeNrType  DPALERT_ADD_VALUE_30_ATTR = (DpAttributeNrType) ANYTYPE_VAR + 4030;
const DpAttributeNrType  DPALERT_ADD_VALUE_31_ATTR = (DpAttributeNrType) ANYTYPE_VAR + 4031;
const DpAttributeNrType  DPALERT_ADD_VALUE_32_ATTR = (DpAttributeNrType) ANYTYPE_VAR + 4032;

// connection attributes
// DPCONFIGNR_CONNDISPATCHINFO
const DpAttributeNrType  CONNECT_TOTAL_ATTR =  (DpAttributeNrType) UINTEGER_VAR + 104;

// RDB-Verdichtung
const DpAttributeNrType OFFLINE_COMPRESSIONS_ATTR  = (DpAttributeNrType) DYNULONG_VAR+241;        /* RDB-Verdichtung */

const DpAttributeNrType DPVALUE_QUALITY_CODE_ATTR  = (DpAttributeNrType) UINTEGER_VAR+145;       // _original, _online, _offline for attribute _status64
const DpAttributeNrType DPVALUE_PA_QUALITY_ATTR    = (DpAttributeNrType) UINTEGER_VAR+146;       // _original, _online, _offline for attribute _status64
const DpAttributeNrType DPVALUE_PROCESS_VALUE_ATTR = (DpAttributeNrType) REC_VAR+147;            // _online
#endif /* _ATRRIBUTENRS_H_ */

