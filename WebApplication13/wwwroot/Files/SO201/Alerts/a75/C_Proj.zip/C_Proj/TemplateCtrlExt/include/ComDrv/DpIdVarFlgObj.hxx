#ifndef _DPIDVARFLGOBJ_H_
#define _DPIDVARFLGOBJ_H_

#include <DpIdentifier.hxx>
#include <HWMapDpPa.hxx>
#include <Resources.hxx>

class Variable;

/** Container class.
 * This class serves as container entry for already processed incoming HWObjects before they are
 * bundeled for transmission to EV
 *
 * @classification internal
 **/
class DpIdVarFlgObj
{
  friend class UNIT_TEST_FRIEND_CLASS;

  public:
    // varPtr is NOT deleted by this class
    // we expect DrvManager::insertValueChange to take care of it!
    DpIdVarFlgObj(DpIdentifier const & dpId, Variable * varPtr,
                  BitVec const & flags, TimeVar const & orgTime, PVSSulong hwoId)
      : m_dpId(dpId), m_type(dpId.getDpType()), m_varPtr(varPtr),
        m_flags(flags), m_orgTime(orgTime), m_hwoId(hwoId) { /* empty */ }

    Variable * getVarPtr() const { return m_varPtr; }
    BitVec const & getFlags() const { return m_flags; }
    TimeVar const & getOrgTime() const { return m_orgTime; }
    PVSSulong getHwoId() const { return m_hwoId; }
    DpIdShort const & getDpIdShort() const { return m_dpId; }

    void getDpId(DpIdentifier & dpId) const
    {
      dpId.setSystem(Resources::getSystem());
      dpId.setDp(m_dpId.dpId_);
      dpId.setEl(m_dpId.elId_);
      dpId.setDpType(m_type);
      dpId.setConfig(DPCONFIGNR_PERIPH_ADDR_MAIN);
      dpId.setAttr(0);
      dpId.setDetail(0);
    }

    int compareDpId(DpIdVarFlgObj const & theOther) const
    {
      int cmp = 0;

      cmp = int(m_dpId.dpId_) - int(theOther.m_dpId.dpId_);
      if ( cmp )
        return cmp;

      cmp = int(m_dpId.elId_) - int(theOther.m_dpId.elId_);

      return cmp;
    }

  private:
    DpIdShort  m_dpId;
    DpTypeId   m_type;
    Variable * m_varPtr;
    BitVec     m_flags;
    TimeVar    m_orgTime;
    PVSSulong  m_hwoId;
};

#endif
