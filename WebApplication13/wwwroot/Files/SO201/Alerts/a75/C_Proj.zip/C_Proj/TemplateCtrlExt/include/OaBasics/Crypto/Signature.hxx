// -----------------------------------------------------------------------------
// creator: Andras Horvath - 01.09.2017
// purpose: Have Signature operations of crypto lib in a seperate class
// -----------------------------------------------------------------------------
#ifndef _SIGNATURE_HXX_
#define _SIGNATURE_HXX_

#include <Blob.hxx>
#include <string>

class QJsonObject;

/**
  @class Signature
  @brief The Signature class
         stores a digital signature that was created by a Key object
*/
class DLLEXP_OABASICS Signature
{
public:
  /**
    @brief Constructor to create new empty Signature
  */
  Signature() = default;

  /**
    @brief Constructor to create new Signature
    @param hashType  the used hash type
    @param bytes     raw buffer containing the signature data.
                     The data will be copied.
    @param size      size of the buffer containing the signature data
  */
  Signature(std::string hashType, const unsigned char* bytes, size_t size);

  /**
    @brief Constructor to create new Signature
    @param json  JSON object containing signature data
  */
  explicit Signature(const QJsonObject& json);

  /**
    @brief Copy assignment operator for a Signature
    @param other  the Signature to copy from
  */
  Signature& operator= (const Signature& other) = default;

  /// destructor
  ~Signature();

  /**
    @brief Read the internal data of a Signature.
    @return the data stored in the Signature
  */
  Blob getData() const;

  /**
    @brief Get the hash type of a Signature.
    @return the hash type of the Signature
  */
  std::string getHashType() const;

  /**
    @brief Creates a JSON document from a Signature.
    @param json  the returning JSON document
    @return      0 if no error, otherwise error code
  */
  int serialize(QJsonObject& json) const;

  /**
    @brief Get the stored signature as a string.
    @return the string representation of the Signature
  */
  std::string getDataStr() const;

  /**
    @brief Set the stored signature as a string.
    @param strData  the new Signature content as a string
  */
  void setDataStr(const std::string& strData);

private:
  Blob m_data;

#ifdef _WIN32
#  pragma warning(push)
#  pragma warning(disable : 4251)
#endif
  std::string m_hashType;
#ifdef _WIN32
#  pragma warning(pop)
#endif
};

#endif  // _SIGNATURE_HXX_
