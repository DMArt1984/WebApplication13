// DATEIBESCHREIBUNG ==============================================================
// DATEINAME:     DpMsgConnection.hxx
// VERANTWORTLICHER: Peter Pentek
// BESCHREIBUNG : DpMsgConnection ist eine Message, in welche man Items
//        einhaengen kann, die eine An-/Abmeldung von einem oder
//        mehreren Attributen beim Event-Manager ermoeglichen.
//
//        Es koennen nur DpMsgConnectItems eingehaengt werden, welche
//        folgende Funktionen zur Verfuegung stellen.
//
//        Es gibt 2 Arten von Anmeldungen:
//          - DPMSGITEM_CONNECT  - Anmelden fuer Attribute beim EV
//          - DPMSGITEM_CONNECT_RET - Anmelden mit sofortigen
//                        DPMGS_HOTLINK
//
//        Abmelden :
//          - DPMSGITEM_DISCONNECT - Abmelden von Attributen beim
//                       Event-Manager
//
//        Man kann selbst bestimmen, ob diese Meldung eine Antwort
//
// ======================================Ende======================================

#ifndef _DPMSGCONNECTION_H_
#define _DPMSGCONNECTION_H_

// Vorwaerts-Deklaration der Eigenen Klasse
class DpMsgConnection;

// ========== DpMsgConnectionPtr ============================================================
typedef DpMsgConnection* DpMsgConnectionPtr;

#include <ostream>
#include <DpIdentListItem.hxx>
#include <DpMsg.hxx>
#include <PtrList.hxx>

/** DpMsgConnection is a class used for registering of attributes in EventManager. Therefore that class contains several connection items.
    These are the items that manage a connection to attributes of the EventManager. 
    Message can contain following items:
    - Connect()
      - DPMSGITEM_CONNECT     - Registers for an attribute in EventManager
      - DPMSGITEM_CONNECT_RET - Registers for an attribute in EventManager with immediate DPMSG_HOTLINK callback

    - Disconnect()
      - DPMSGITEM_DISCONNECT  - Releases the registration of attribute in EventManager
*/
class DLLEXP_MESSAGES DpMsgConnection : public DpMsg
{
  public:
    /// Default Constructor.
    DpMsgConnection(MsgType type = DP_MSG_CONNECT);
    /// Constructor.
    DpMsgConnection(MsgType type, const ManagerIdentifier &newDestination, PVSSboolean answer);
    /// Copy constructor.
    DpMsgConnection(const DpMsgConnection &newMsg) : connectionType(newMsg.isA())  { operator=(newMsg); }
    /// Destructor.
    ~DpMsgConnection() {};

    /// Write the instance into the itcNdrUbSend stream.
    friend DLLEXP_MESSAGES itcNdrUbSend &operator<<(itcNdrUbSend &ndrStream, const DpMsgConnection &dpMsg);
    /// Read the instance from the itcNdrUbReceive stream.
    friend DLLEXP_MESSAGES itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream, DpMsgConnection &dpMsg);

    /// Comparison operator.
    virtual int operator==(const Msg &rVal) const;
    /// Assignment operator.
    virtual Msg &operator=(const Msg &rVal);
    /// Assignment operator.
    DpMsgConnection &operator= (const DpMsgConnection &rVal) { operator=((const DpMsg&)rVal); return *this; }

    // Spezielle Methoden :
    /// Create new instance.
    virtual Msg *allocate() const {return new DpMsgConnection(connectionType);};
    /// Get own type.
    virtual MsgType isA() const {return connectionType;};
    /// Check if own type matches other type.
    virtual MsgType isA(MsgType dpMsgType) const;

    /** Get flag indicating whether answer is required.
        We always want an answer message, except DP_MSG_DISCONNECT_ALL.
        */
    virtual PVSSboolean needsAnswer() const; 

    /// Get the flag indicating whether the values in the answer message are required.
    PVSSboolean  getWantAnswer() const {return wantAnswer;}
    /// Set the flag indicating whether the values in the answer message are required.
    void setWantAnswer(PVSSboolean b) { wantAnswer = b; }
    /** Print the contents of the list to an output stream.   
      @param to the outputstream where debug info is written to
      @param level controls the amount of debug information printed and shall be > 0.
    */
    virtual void debug(std::ostream &to, int level) const;

    /// Get the first DpIdentifier.
    const DpIdentifier *getFirstId() const;
    /// Get next DpIdentifier.
    const DpIdentifier *getNextId() const;
    /// Get the first DpIdentifier.
    const DpIdentifier *getFirstId(DpIdentListItem *& item) const;
    /// Get next DpIdentifier.
    const DpIdentifier *getNextId(DpIdentListItem *& item) const;
    /// Append the DpIdentifier into the list.
    PVSSboolean appendId(const DpIdentifier &id);
    /// Get number of DpIdentifiers in the list.
    PVSSulong getNrOfItems(PVSSulong groupIndex = 0) const  { return groupIndex ? 0 : list.getNumberOfItems(); }
    /// Get number of DpIdentifiers in the list.
    PVSSulong getNumberOfItems() const {return list.getNumberOfItems();}
    /// Clear DpIdentifiers list.
    void clearIds() {list.clear();};

    /** Get number of groups.
        This always returns 1.
        */
    virtual PVSSulong getNrOfGroups() const {return 1;};
    /** Get the DpIdentifier from the first group.
        The getGroupId method is called by the AnswerHandler::sendMsgWaitingForAnswer() to return the DpIdentifier from the first group.
        */
    virtual DpIdentifier getGroupId(PVSSulong) const  { return getFirstId() ? *getFirstId() : DpIdentifier(); }

    /** Get the connection ID. 
        The method name rembers the equivilant name in DpMsgFilterRequest.
        */
    PVSSulong getIdentifier() const; 
    /// Set the connection ID.
    void setIdentifier(PVSSulong newId) {connectionId = newId;}

  protected:
    /// Write the instance into the itcNdrUbSend stream.
    virtual void outNdrUb(itcNdrUbSend &ndrStream) const;
    /// Read the instance from the itcNdrUbReceive stream.
    virtual void inNdrUb(itcNdrUbReceive &ndrStream);

  private:
    PVSSboolean wantAnswer;
    MsgType connectionType;
    PVSSulong connectionId;
    PtrList list;

    friend class UNIT_TEST_FRIEND_CLASS;
};


inline PVSSulong  DpMsgConnection::getIdentifier() const
{
  return connectionId;
}

#endif /* _DPMSGCONNECTION_H_ */
