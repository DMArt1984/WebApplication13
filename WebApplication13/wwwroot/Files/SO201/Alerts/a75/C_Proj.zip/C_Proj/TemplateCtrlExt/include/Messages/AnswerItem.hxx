// DATEIBESCHREIBUNG ==============================================================
// DATEINAME:		AnswerItem.hxx
// VERANTWORTUNG:	Thomas Exner
// 
// BESCHREIBUNG:	AnswerItem ist von DpVCItem abgeleitet und kann daher wie ein
//					solches verwendet werden, wenn die dort enthaltene Information
//					ausreichend ist. Fuer die Antwort auf einen PeriodRequest muss
//					aber zusaetzlich noch ein Zeitattribut zur Verfuegung gestellt
//					werden.

#ifndef _ANSWERITEM_H_
#define _ANSWERITEM_H_

// Vorwaerts-Deklaration der Eigenen Klasse
class AnswerItem;

// ========== AnswerItemPtr ============================================================

typedef AnswerItem* AnswerItemPtr;

#include <ostream>
#include <DpVCItem.hxx>
#include <TimeVar.hxx>

// Vorwaerts-Deklarationen :
class AnswerItem;
class AnswerGroup;

// ========== AnswerItem ============================================================

/** The AnswerItem class. This class is used by the AnswerGroup class and therefore
    by the DpMsgAnswer to transport DpIdentifier / value pairs.
  */

class DLLEXP_MESSAGES AnswerItem : public DpVCItem
{
  friend DLLEXP_MESSAGES itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream, AnswerGroup &group);

  public:

  /// AnswerItem type enumerator
  enum ItemType
  {
    EVENT,
    INTERVAL_START,
    BREAK_START,
    INTERVAL_AND_BREAK_START
  };

  /// param constructor
  /// @param newId the DpIdentifier
  /// @param newValue the Variable holding the value
  /// @param newTime the time stamp
  /// @param newType the AnswerItem type
  /// @param newSerial the serial number
  AnswerItem(const DpIdentifier &newId, Variable *newValue = 0, const TimeVar &newTime = TimeVar(0, 0), 
      ItemType newType = EVENT, unsigned long newSerial = 0);

  /// param constructor
  /// @param newId the DpIdentifier
  /// @param newValue the Variable holding the value
  /// @param newTime the time stamp
  /// @param newType the AnswerItem type
  /// @param newSerial the serial number
  AnswerItem(const DpIdentifier &newId, const Variable &newValue, const TimeVar &newTime = TimeVar(0, 0), 
      ItemType newType = EVENT, unsigned long newSerial = 0);

  /// copy constructor
  /// @param item the AnswerItem to copy
  AnswerItem(const AnswerItem &item);

  /// default constructor, initialisation with zero values
  AnswerItem();

  /// destructor
  virtual ~AnswerItem();

  /// AllocatorDecl
  AllocatorDecl;

  // Operatoren :

  /// operator << for itcNdrUbSend stream
  /// @param ndrStream the stream, which to send to
  /// @param item the AnswerItem
  friend DLLEXP_MESSAGES itcNdrUbSend &operator<<(itcNdrUbSend &ndrStream, const AnswerItem &item);

  /// operator >> for itcNdrUbReceive stream
  /// @param ndrStream the stream, which to receive from
  /// @param item the AnswerItem
  friend DLLEXP_MESSAGES itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream, AnswerItem &item);
  
  /// comparison operator ==
  /// @param rVal the AnswerItem to compare with
  /// @return 0 if not equal else 1
  int operator==(const AnswerItem &rVal) const;

  /// comparison operator !=
  /// @param rVal the AnswerItem to compare with
  /// @return 1 if not equal else 0
  int operator!=(const AnswerItem &rVal) const {return !operator==(rVal);}

  /// assignment operator for AnswerItem
  /// @param rVal the AnswerItem to assign
  /// @return the resulting AnswerItem
  AnswerItem &operator=(const AnswerItem &rVal);

  // Spezielle Methoden :

  /// get the source time if it was the answer on a dpGetPeriod request
  const TimeVar &getTime() const {return time;};
  
  /// get the type of AnswerItem
  ItemType getType() const {return type;};
  
  /// send debug info to output stream
  /// @param to the output stream
  /// @param level the debug level
  void debug(std::ostream &to, int level) const;

  /// compare two AnswerItems, compare time stamps and serial numbers
  /// @param i1 the AnswerItem 1
  /// @param i2 the AnswerItem 2
  /// @return -1 if i1 < i2, 1 if i1 > i2, 0 if equals
  static int cmp(const AnswerItem *i1, const AnswerItem *i2);

  private:
  TimeVar time;
  ItemType type;
  unsigned long serial; // DynPtr doesn't save the order
};

// ========== inline-functions ============================================================
inline AnswerItem::AnswerItem(const DpIdentifier &newId, Variable *newValue, 
    const TimeVar &newTime, ItemType newType, unsigned long newSerial)
: DpVCItem(newId, newValue),
  time(newTime),
  type(newType),
serial(newSerial)
{
}

inline AnswerItem::AnswerItem(const DpIdentifier &newId, const Variable &newValue, 
    const TimeVar &newTime, ItemType newType, unsigned long newSerial)
: DpVCItem(newId, newValue),
  time(newTime),
  type(newType),
serial(newSerial)
{
}

inline AnswerItem::AnswerItem(const AnswerItem &item)
  : DpVCItem(),
  time(item.time),
  type(item.type),
serial(item.serial)
{
  operator=(item);
}


inline AnswerItem::AnswerItem()
  : DpVCItem(), time(0, 0), type(EVENT), serial(0)
{
}

inline AnswerItem::~AnswerItem()
{
}

#endif /* _ANSWERITEM_H_ */

