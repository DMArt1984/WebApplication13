#ifndef _MAPTABLEITEM_H_
#define _MAPTABLEITEM_H_

// Autoren:  Martin Koller, Juli 2004

/** A class which holds one pair of (id, name)

*/

#include <DpTypes.hxx>

class itcNdrUbSend;
class itcNdrUbReceive;

// the type of id
typedef PVSSulong MapTableItemId;

// ========== TableItem ============================================================

/// The table item class
/// Abstract class to derive table items.
class DLLEXP_DATAPOINT TableItem 
{
  public:
  
    /// constructor, initialisation with zero values
    TableItem() {}

    /// destructor
    virtual ~TableItem() {}

  public:

    /// write to itcNdrUbSend stream
    /// @param _snd the stream, which to send to
    virtual void writeTo(itcNdrUbSend &_snd) const = 0;

    /// read from itcNdrUbReceive stream
    /// @param _rcv the stream, which to read from
    virtual void readFrom(itcNdrUbReceive &_rcv) = 0;
};

// ========== MapTableItem ============================================================

/// The map table item class
class DLLEXP_DATAPOINT MapTableItem : public TableItem
{
  public:

    /// constructor, initialisation with zero values
    MapTableItem();

    /// parameter constructor
    /// @param theId the ID
    /// @param theName the name
    MapTableItem(MapTableItemId theId, const char *theName);

    /// destructor
    ~MapTableItem();

    /// operator << for itcNdrUbSend stream
    /// @param ndrStream the stream, which to send to
    /// @param item the MapTableItem
    friend DLLEXP_DATAPOINT  itcNdrUbSend &operator<<(itcNdrUbSend &ndrStream, const MapTableItem &item);

    /// operator >> for itcNdrUbReceive stream
    /// @param ndrStream the stream, which to receive from
    /// @param item the MapTableItem
    friend DLLEXP_DATAPOINT  itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream, MapTableItem &item);

    /// set the new name
    /// @n The class will not take ownership of the given pointer.
    /// @param newName the name to set
    void setName(const char *newName);

    /// get the name
    const char *getName() const { return name; }

    /// get the ID
    MapTableItemId getId() const { return id; }

    /// set the new ID
    /// @param newId the ID to set
    void setId(MapTableItemId newId) { id = newId; }

    /// get size of the string
    size_t strSize() const;

    /// set a new name
    /// @n The class will take ownership of the given pointer.
    /// @param newName the new name pointer
    /// @classification internal
    void setNamePtr(char *newName) {name = newName;}

    /// cut the name
    /// @n The class releases ownership of the name pointer.
    /// @return the name pointer
    /// @classification internal
    char * cutNamePtr() {char *tmp = name; name = 0; return tmp;}

  public:

    /// write to itcNdrUbSend stream
    /// @param _snd the stream, which to send to
    virtual void writeTo(itcNdrUbSend &_snd) const;

    /// read from itcNdrUbReceive stream
    /// @param _rcv the stream, which to read from
    virtual void readFrom(itcNdrUbReceive &_rcv);

  protected:
    /// the name
    char *name;

    /// the ID
    MapTableItemId id;

  private:
    MapTableItem(const MapTableItem &) {} // COVINFO LINE: defensive (defined private so no one can use it)
    MapTableItem & operator=(const MapTableItem &) {return *this;} // COVINFO LINE: defensive (defined private so no one can use it)
};

// ========== DpTableItem ============================================================

/// The DataPoint map table item class
class DLLEXP_DATAPOINT DpTableItem : public MapTableItem
{
  public:

    /// constructor, initialisation with zero values
    DpTableItem();

    /// parameter constructor
    /// @param id the ID
    /// @param name the name
    /// @param typeId the type ID
    DpTableItem(DpIdType id, const char *name, DpTypeId typeId);

    /// operator << for itcNdrUbSend stream
    /// @param ndrStream the stream, which to send to
    /// @param item the DpTableItem
    friend DLLEXP_DATAPOINT  itcNdrUbSend &operator<<(itcNdrUbSend &ndrStream, const DpTableItem &item);

    /// operator >> for itcNdrUbReceive stream
    /// @param ndrStream the stream, which to receive from
    /// @param item the DpTableItem
    friend DLLEXP_DATAPOINT  itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream, DpTableItem &item);

    /// get the DP type
    DpTypeId getDpTypeId() const { return dpTypeId; }

    /// set the DP type
    /// @param _t the type ID to set
    void setDpTypeId(DpTypeId _t) { dpTypeId = _t; }

  public:

    /// write to itcNdrUbSend stream
    /// @param _snd the stream, which to send to
    virtual void writeTo(itcNdrUbSend &_snd) const;

    /// read from itcNdrUbReceive stream
    /// @param _rcv the stream, which to read from
    virtual void readFrom(itcNdrUbReceive &_rcv);

  private:
    DpTypeId dpTypeId;
};


//--------------------------------------------------------------------------------

#endif /* _MAPTABLEITEM_H_ */
