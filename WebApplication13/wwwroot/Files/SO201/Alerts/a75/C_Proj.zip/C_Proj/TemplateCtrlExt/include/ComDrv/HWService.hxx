// DATEIBESCHREIBUNG ==============================================================
// DATEINAME:       HWService.hxx
// VERANTWORTUNG:  Thomas Koroschetz
// BESCHREIBUNG:   Die Klasse HWService beinhaltet das Interface
//                  zwischen allgemeinen Treiber und Hardware-spezifischer
//                  Schicht.

#ifndef _HWSERVICE_H_
#define _HWSERVICE_H_

#ifndef _HWOBJECT_H_
#include <HWObject.hxx>
#endif

#ifndef _VARIABLE_H_
#include <Variable.hxx>
#endif

#ifndef _DPIDENTIFIER_H_
#include <DpIdentifier.hxx>
#endif

class PollGroup;

/** The hardware service handler. This class covers the interface to the hardware and is also responsible
  * for talking the right protocol to the periphery. This class contains mainly empy functions and is intended 
  * to be overloaded by a derived driver.
  *  @classification public use, overload
  */
class HWService
{
  public:
    /** Destructor
    */
    virtual  ~HWService();
    
    /** This is the first function called for the HW interface. It is intended to check the
      * availability of your hardware here and do any initialisations.
      * @param argc the argument counter from main() - to get any command line params
      * @param argv the command line arguments
      * @return PVSS_TRUE on success, PVSS_FALSE when the driver should end
      * @classification public use, overload
      */
    virtual PVSSboolean initialize(int argc, char *argv[]);

    /** This function is called when the driver is connected to the event manager
      * and ready for processing data. Use this function to start your hardware activity.
      * @return PVSS_TRUE on success
      * @classification public use, overload
      */
    virtual PVSSboolean start();

    /** Stop all hardware activity here. The driver is going to die. 
      * @classification public use, overload
      */
    virtual void        stop();
    
    /** Split the timeout in miliseconds into two values,
    * timeout in second and rest of timeout in miliseconds
    * @param expire expiration time
    * @param sec secods of timeout
    * @param usec miliceonds of timeout
    */
    // virtual void        workProc(long & /* expire */, long & secs, long & usecs); 
    virtual void        workProc(TimeVar &expire, long &sec, long &usec);
                            
    /** Working procedure. This function is called repeatedly by the DrvManager mainLoop() to check the
      * hardware for any incoming data. when data is ready for accepting you should pack the data into a HWObject and
      * use the DrvManager toDp() function to transmit the data to the pvss2 system.
      * @warning beware of staying inside this function too long because no messages can go in and
      * out of the driver as long as you keep control!
      * @classification public use, overload
      */ 
    virtual void        workProc();
    
    /** Whenever a message is transformed and sent to the hw service layer completely,
      * this function is called to signal to the hw layer that the message has been fully processed.
      * You can use this function if you want to transmit larger blocks to the hardware at once.
      * @classification public use, overload
      */
    virtual void        flushHW();
    
    /** This function is called for each fully converted HWObject. The data inside it has
      * been processed according to the choosen transformation. All you have to do is to determine the
      * corresponding hardware address and to transmit the data packet. The objPtr must not be deleted.
      * @param objPtr pointer to HW object
      * @return PVSS_TRUE if successfully written
      * @classification public use, overload
      */
    virtual PVSSboolean writeData(HWObject *objPtr);

    /** This function is called when a general query request is issued on the
      * driver datapoint. It contains the contents of the hotlink message received from the
      * event manager. The varPtr must not be deleted.
      * @param dpId the dp identifier
      * @param varPtr the data of the original variable field.
      * @classification public use, overload
      */
    virtual void        generalQuery(DpIdentifier& dpId, VariablePtr varPtr);

    /** This function is called for a single data request or when polling data.
      * The HWObject contains the PeriphAddress string. Find the corresponding hardware address, ask
      * for the data. The objPtr must not be deleted.
      * @param objPtr the HWObject to fill with data
      * @classification public use, overload
      */
    virtual void        singleQuery(HWObject *objPtr);

    /** This function is called by the ComDrv whenever a hotlink for a derived driver
      * internal dpId is catched. The params contain the data of the hotlink message. You are responsible for deleting the
      * varPtr after use.
      * @param dpId the dp identifier
      * @param varPtr the data for the internal dp
      * @classification public use, overload
      */
    virtual void        hotLink2Internal(DpIdentifier& dpId, VariablePtr varPtr);
    
    /** This function is called every time a hotlink to the
      * disable command internal datapoint is received.
      * @param dc The actual state of the DC datapoint
      * @classification public use, overload
      */
    virtual void notifyDisableCommands(PVSSboolean /* dc */);

    /** This function is called when a pollgroup triggers. It can be used
      * to implement a special polling mechanism instead of ComDrv calling 
      * singleQuery.
      * @param pg poolgroup 
      * @return PVSS_FALSE no special polling is done
      *         PVSS_TRUE special polling has been done
      */
    virtual bool groupQuery (PollGroup * pg) {return false;}

    /** This function is called if a value change has been answered by the event manager. 
    * @param hwoId the HW object identifer given in the toDp call
      * @classification public use, overload
      */
    virtual void answerOnValueChange(PVSSulong hwoId);

    // TR100629
    /** callback function. this function is called if a message with more than one item in a group or more than one group is received.
       processing can be grouped by specific driver if the protocol supports it.
       Grouping is used for single queries and PVSSGQ.
       If there is only one item in the group this function is not called.
       Normal write operations signal end of message via flushHW().
       @classification public use, overload
    */
    virtual void startGroup();
    
    // TR100629
    /** callback function. this function is called if a message with more than one item in a group or more than one group is received.
       processing can be grouped by specific driver if the protocol supports it.
       Grouping is used for single queries and PVSSGQ.
       If there is only one item in the group this function is not called.
       Normal write operations signal end of message via flushHW().
       @classification public use, overload
    */
    virtual void endGroup();

    /** This function is called for each fully converted HWObject. The data inside it has
      * been processed according to the choosen transformation. All you have to do is to determine the
      * corresponding hardware address and to transmit the data packet. The objPtr must not be deleted.
      * This function dispatches the request according to the HmiConnection set in the HWObject.
      * @param objPtr pointer to HW object
      * @return PVSS_TRUE if successfully written
      * @classification internal
      */
    virtual PVSSboolean preWriteData(HWObject *objPtr);

    /**  Whenever a message is transformed and sent to the hw service layer completely,
      * this function is called to signal to the hw layer that the message has been fully processed.
      * You can use this function if you want to transmit larger blocks to the hardware at once.
      * @classification internal
      */
    virtual void preFlushHW();

    /** This function is called for a single data request or when polling data.
      * The HWObject contains the PeriphAddress string. Find the corresponding hardware address, ask
      * for the data. The objPtr must not be deleted.
      * This function dispatches the request according to the HmiConnection set in the HWObject.
      * @param objPtr the HWObject to fill with data
      * @classification internal
      */
    virtual void preSingleQuery(HWObject *objPtr);

    /** This function is called for a update notification on subscription count if the acquistition mode SpontaneousOnDemand is chosen.
      * The HWObject contains the PeriphAddress string. Find the corresponding hardware address and do anything needed to get data.
      * if (subscriptionCount - offset) > 0 the data retrieval should be started, otherwise be stopped. 
      * The objPtr must not be deleted.
      * @param objPtr the HWObject providing the address for the item to retrieve
      * @param startAcquisition if true the HWService should start getting data, otherwise stop
      * @classification public use, overload
      */
    virtual void notifyOnUseChange(HWObject *obj, bool startAcquisition);

    /** This function is called for a update notification on subscription count if the acquistition mode SpontaneousOnDemand is chosen.
      * The HWObject contains the PeriphAddress string. Find the corresponding hardware address and do anything needed to get data.
      * if (subscriptionCount - offset) > 0 the data retrieval should be started, otherwise be stopped. 
      * The objPtr must not be deleted.
      * This function dispatches the request according to the HmiConnection set in the HWObject.
      * @param objPtr the HWObject providing the address for the item to retrieve
      * @param startAcquisition if true the HWService should start getting data, otherwise stop
      * @classification internal
      */
    virtual void preNotifyOnUseChange(HWObject *obj, bool startAcquisition);


    /** This function is called every time a hotlink to the
      * disable command internal datapoint is received.
      * @param dc The actual state of the DC datapoint
      * @classification public use, overload
      */
    virtual void preNotifyDisableCommands(PVSSboolean /* dc */);

    /** This function is called when a general query request is issued on the
      * driver datapoint. It contains the contents of the hotlink message received from the
      * event manager. The varPtr must not be deleted.
      * @param dpId the dp identifier
      * @param varPtr the data of the original variable field.
      * @classification public use, overload
      */
    virtual void preGeneralQuery(DpIdentifier& dpId, VariablePtr varPtr);

    /** Report relevant data of objects used by the HWService
      * @classification public use, overload
      */
    //virtual void reportStatus(std::ostream &os);
};

#endif
