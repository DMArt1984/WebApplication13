// Administration of FileTransfer requests

#ifndef  FILETRANSFERLIST_H
#define  FILETRANSFERLIST_H

#include  <PtrList.hxx>

class  FileTransferItem;
class  FileTransferSysMsg;
class  ManagerIdentifier;
class  CharString;
class  TextVar;
class  RecVar;

class  DLLEXP_MANAGER FileTransferList
{
  /// <summary>
  /// Declare test class as a friended class, having access to private/protected methods
  /// </summary>    
  friend class UNIT_TEST_FRIEND_CLASS;

  public:
    FileTransferList();
    
  public:
    // Request new File. Optional argument are file stats from remote system
    PVSSboolean  requestFileTransfer(const ManagerIdentifier &target, const CharString &file, const RecVar *fileStat = 0);
    // Abort one file transfer
    PVSSboolean  abortFileTransfer(const ManagerIdentifier &target, const CharString &file);
    // Abort all file transfers
    PVSSboolean  abortAllFileTransfers(const ManagerIdentifier &target);
    
    // Handle one msg
    PVSSboolean  handleFileTransferMsg(FileTransferSysMsg &msg);
    
    // Create and send next messages
    void  workProc();
    
    // Number of pending send / recv transfers
    unsigned int  nofPendingSend() const {return sendFileList.getNumberOfItems();}
    unsigned int  nofPendingRecv() const {return recvFileList.getNumberOfItems();}
    unsigned int  nofPendingList() const {return listFileList.getNumberOfItems();}

    // Reset error flag
    void resetErrorState() {errorState = PVSS_FALSE;}
    // Check error flag
    PVSSboolean isInErrorState() const {return errorState;}
    
  protected: 
    PVSSboolean  handleFileTransferListMsg(FileTransferSysMsg &msg);
    PVSSboolean  handleFileTransferRequestMsg(FileTransferSysMsg &msg);
    PVSSboolean  handleFileTransferDataMsg(FileTransferSysMsg &msg);
    PVSSboolean  handleFileTransferEndMsg(FileTransferSysMsg &msg);
    PVSSboolean  handleFileTransferFailMsg(FileTransferSysMsg &msg);
    PVSSboolean  handleFileTransferAbortMsg(FileTransferSysMsg &msg);
    
    FileTransferItem * findSendItem(const ManagerIdentifier &manId, const CharString &file);
    FileTransferItem * findRecvItem(const ManagerIdentifier &manId, const CharString &file);
    
  private:
    PtrList  sendFileList;
    PtrList  recvFileList;
    PtrList  listFileList;
    PVSSboolean errorState;
};

#endif
