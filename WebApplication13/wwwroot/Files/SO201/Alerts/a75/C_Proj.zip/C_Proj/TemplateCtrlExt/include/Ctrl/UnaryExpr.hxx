#ifndef _UNARYEXPR_H_
#define _UNARYEXPR_H_

#include <CtrlExpr.hxx>


/*  author VERANTWORTUNG: Martin Koller */
class DLLEXP_CTRL UnaryExpr : public CtrlExpr
{
  public:
    /// Returns the type of the Expression
    virtual ExprType isA() const { return UNARY_EXPR; }

    /// unary operator
    enum OpType
    {
      /// +
      PLUS,
      // -
      MINUS,
      // !
      NOT,
      // ~
      NEG,
      // post++
      POSTINC,
      // post--
      POSTDEC,
      // ++prae
      PRAEINC,
      // --prae
      PRAEDEC
    };

    /** Constructor: Wird beim Parsen aufgerufen.
      * @param type     unary operator
      * @param line     In welcher Zeile des Sourcefiles steht diese Zuweisung?
      * @param filenum  Wenn es ein Library-File war die Nr. der Library
      *                 Damit kann der Name ermittelt werden.
      */
    UnaryExpr(OpType type, int line, int filenum)
      : CtrlExpr(line, filenum), opType(type), expr(0) {}

    /// Destructor
    virtual ~UnaryExpr();

    void setExpr(CtrlExpr *e) { expr = e; }

    /** Ist die Expr ein eigenes Statement, wird sie mit execute
      * ausgefuehrt. Ist sie Teil einer komplexen Expr wird sie mit
      * evaluate ausgewertet.
      * @return NULL | Ptr auf naechstes CtrlSment. NULL bedeutet das aktuelle Sment
      *        ist das letzte Sment einer CtrlSmentList.
      * @param thread der Thread der dieses Statement ausfuehrt
      * @see evaluate
      */
    virtual const CtrlSment *execute (CtrlThread *thread) const;

    /** Ist die Expr teil einer Komplexen Expr wird sie mit evaluate
      * ausgewertet.
      * @return Ptr auf Variable die das Ergebnis zugewiesen bekommt
      *         tritt ein Fehler auf wird ein Ptr auf eine dummy IntegerVar
      *         zurueckgegeben -> immer != NULL
      * @param thread der Thread der dieses Statement ausfuehrt
      * @see execute
      */
    virtual const Variable *evaluate(CtrlThread *thread) const;

    virtual const CtrlExpr * getFirstExpr(CtrlThread *thread) const;

    /// Gewichtung des CtrlSment
    virtual SmentWeight getWeight() const { return SM_WT_Low; }

    virtual void writeTrace(CtrlThread *thread, bool writeValue = true) const;

    virtual bool checkIntegrity(const CharString &location, CtrlThread *thread) const;

    static CtrlExpr *getOptimized(UnaryExpr *l, CtrlExpr *r);

  private:
    OpType opType;
    CtrlExpr *expr;
};

#endif /* _UNARYEXPR_H_ */
