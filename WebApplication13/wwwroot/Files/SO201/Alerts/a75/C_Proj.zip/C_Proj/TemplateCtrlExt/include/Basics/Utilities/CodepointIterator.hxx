#ifndef _CODEPOINT_ITERATOR_H_
#define _CODEPOINT_ITERATOR_H_

class CharString;

#ifndef _CODEPOINT_H_
#include <Codepoint.hxx>
#endif

/// Iterates over the individual UTF-8 encoded code points of a string
class DLLEXP_BASICS CodepointIterator
{
  public:
    /** Use this static method instead of the constructor when
     *  C++-/STL-style iteration will be used.
     * @param str the string to iterate over
     * @return a CodepointIterator instance that is already at the first
     *         position
     */
    static CodepointIterator stlStyle(const char* str);

    /** Constructor. The position after initialisation is "before" the first
     *  codepoint in the string, so next() must be invoked before get().
     *  When using the getFirst()/getNext() idiom, this is handled automatically.
     * @param str the string to iterate over
     */
    CodepointIterator(const char* str)
      : theString(reinterpret_cast<const unsigned char*>(str ? str : ""))
      , position(0)
      , cache(-1)
    {}

    /// Copy constructor
    CodepointIterator(const CodepointIterator& it)
      : theString(it.theString)
      , position(it.position)
      , cache(it.cache)
    {}

    /// copy operator
    CodepointIterator& operator=(const CodepointIterator& it)
    {
      theString = it.theString;
      position = it.position;
      cache = it.cache;
      return *this;
    }

    /** Fetches the code point at the current location
     * @return the code point at the current location or 0 if the
     *         current location is not valid
     */
    Codepoint get() const;

    /** Fetches the code point at the current location
     * @return the code point at the current location or 0 if the
     *         current location is not valid
     */
    Codepoint operator*() {return get();}

    /** Fetches the code point at the current location
     * @return the code point at the current location or 0 if the
     *         current location is not valid
     */
    operator Codepoint() const {return get();}

    /// Allows using string operations upon CodepointIterator objects
    operator const char*() const {return reinterpret_cast<const char*>(theString + position);}

    /** Moves to the next position
     * @return <tt>true</tt> if there is a valid next position,
     *         <tt>false</tt> if not
     */
    bool next();

    /// Moves to the next position
    CodepointIterator& operator++() {next(); return *this;}

    /** Moves to the previous position
     * @return <tt>true</tt> if there is a valid previous position,
     *         <tt>false</tt> if not
     */
    bool prev();

    /** Starts iteration at the first position
     * @return the first code point in the string or 0 if the string
     *         is empty
     */
    Codepoint getFirst() {goTo(0); return get();}

    /** returns the next code point in the string
     * @return the next code point in the string or 0 if end of the
     *         string is reached
     */
    Codepoint getNext() {next(); return get();}

    /// Moves to the previous position
    CodepointIterator& operator--() {prev(); return *this;}

    /** Moves to the given position. The caller must ensure that
     *  the position is still within the string over which this
     *  CodepointIterator iterates.
     * @param index the position to go to, when it is inside of a UTF-8 encoded
     *              code point, it is aligned to the start of that code point
     */
    void goTo(size_t index);

    /** Returns the current byte offset in the UTF-8 encoded string.
     * @return always the index of either a US-ASCII character or a
     *         UTF-8 leading byte.
     */
    size_t byteIndex() const {return position;}

    /** Returns the current byte offset in the UTF-8 encoded string.
     * @return always the index of either a US-ASCII character or a
     *         UTF-8 leading byte.
     */
    operator size_t() const {return position;}
  private:
    const unsigned char* theString;
    size_t position;
    mutable long cache;
};

inline CodepointIterator CodepointIterator::stlStyle(const char* str)
{
  CodepointIterator it(str);
  it.cache = 0;
  return it;
}

#endif /* _CODEPOINT_ITERATOR_H_ */
