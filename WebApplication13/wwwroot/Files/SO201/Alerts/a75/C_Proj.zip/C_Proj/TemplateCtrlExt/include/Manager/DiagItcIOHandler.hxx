#ifndef _DIAGITCIOHANDLER_H_
#define _DIAGITCIOHANDLER_H_

#include <ItcIOHandler.h>

#include <Types.hxx>
#include <CharString.hxx>
#include <DpIdentifier.hxx>


class DpHLGroup;
class DpMsgAnswer;
class HotLinkWaitForAnswer;
class ResourceDiag;
/*
VERANTWORTUNG: Andreas Pfluegl
BESCHREIBUNG:
*/


/** the DiagItcIOHandler class is a Timer-Object that writes some PVSS-Resource Counter
  * to a DP of the type _Statistics.
  * once the Timer is started by the Manager-Class it restarts itself periodically
  *
  * @classification internal use
  */
class DLLEXP_MANAGER DiagItcIOHandler : public itcIOHandler
{
    /// <summary>
    /// Declare test class as a friended class, having access to private/protected methods
    /// </summary>    
    friend class UNIT_TEST_FRIEND_CLASS;
	
  public:
    DiagItcIOHandler();

    void init(ResourceDiag &diag, PVSSlong tmoInSec, const CharString &dpName);

    void hotLinkCallBack(DpMsgAnswer &answer);

    void hotLinkCallBack(DpHLGroup &group);

    PVSSboolean setDpId(CharString dpName, DpIdentifier dpId);

    void setTmo(PVSSlong tmoInSec);

    void startTimer();

    virtual ~DiagItcIOHandler() {}

    virtual void timerExpired(long sec, long usec) = 0;

  protected:
    ResourceDiag *diag_;
    PVSSlong tmoInSec_;
    DpIdentifier secsToRefreshId_;

  private:
    CharString secsToRefreshName_;
    HotLinkWaitForAnswer *wait_;
};


#endif /* _RESOURCEDIAG_H_ */
