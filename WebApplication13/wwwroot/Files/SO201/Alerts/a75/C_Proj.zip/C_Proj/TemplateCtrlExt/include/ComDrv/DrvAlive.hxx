#pragma once

#include <DrvTimer.hxx>

IL_DEPRECATED("deprecated, DrvAlive renamed to DrvTimer")
typedef DrvTimer DrvAlive;