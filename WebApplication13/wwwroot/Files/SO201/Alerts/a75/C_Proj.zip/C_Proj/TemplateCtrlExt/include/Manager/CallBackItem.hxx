// Class for managing Answer- and Hotlink-Callbacks

#ifndef  _CALLBACKITEM_H_
#define  _CALLBACKITEM_H_

#ifndef _PTRLISTITEM_H_
#include <PtrListItem.hxx>
#endif

#ifndef _DPIDENTLIST_H_
#include <DpIdentList.hxx>
#endif

#ifndef _DPMSG_H_
#include <DpMsg.hxx>
#endif

#ifndef _DPMSGANSWER_H_
#include <DpMsgAnswer.hxx>
#endif

#ifndef _DPMSGHOTLINK_H_
#include <DpMsgHotLink.hxx>
#endif

#ifndef _DPMSGCONNECTION_H_
#include <DpMsgConnection.hxx>
#endif

#ifndef _DPMSGFILTERREQUEST_H_
#include <DpMsgFilterRequest.hxx>
#endif

#ifndef _DPMSGALERT_H_
#include <DpMsgAlert.hxx>
#endif

#ifndef  _DYNPTRARRAY_H_
#include <DynPtrArray.hxx>
#endif

class  WaitForAnswer;

class  CallBackItemData;


class DLLEXP_MANAGER CallBackItem : public PtrListItem
{
  friend class Manager;
  
  /// <summary>
  /// Declare test class as a friended class, having access to private/protected methods
  /// </summary>    
  friend class UNIT_TEST_FRIEND_CLASS;

  public:
    /// Compare two CallBackItem 
    static int compare(const CallBackItem *, const CallBackItem *);

    /// Alocate a new CallBackItem according to the msg type
    static CallBackItem * allocate(const DpMsg &, WaitForAnswer *, PVSSboolean, PVSSuserIdType);

  protected:  
    /// Constructor. Use CallBackItem::allocate to create a new callback item
    CallBackItem(const DpMsg &msg, WaitForAnswer *callBack, PVSSboolean delFlag, PVSSuserIdType userId);
   
    /// Constructors to search in the lists. Used in the manager class only
    CallBackItem(DpMsgHotLink *msgPtr, DpHLGroup *grpPtr);
    CallBackItem(DpMsgConnection *msgPtr);
    CallBackItem(DpMsgFilterRequest *msgPtr);
    CallBackItem(DpMsgAnswer *msgPtr);
    
  public:
    /// Destructor
    ~CallBackItem();

    /// Check if this object waits for the spezified DpMsgAnswer
    PVSSboolean  isAnswerOn(const DpMsgAnswer *);

    /// Check if this object handles the spezified DpHLGroup of a dpConnect hotlink
    PVSSboolean  isHotLinkOn(const DpHLGroup *);

    /// Check if this object handles the spezified AlertAttrList of a alertConnect HL
    PVSSboolean  isHotLinkOn(const AlertAttrList *);

    /// Check, if the Msg is a connect msg for this DpId
    PVSSboolean  isConnectOn(const DpIdentifier &dpId);

    /// Check if the Msg is a connect msg for this DpId and WaitForAnswer object
    PVSSboolean  isConnectOn(const DpIdentifier &dpId, const WaitForAnswer *ptr);

    /// Check, if the Msg is a connect msg for this DpIdList
    PVSSboolean  isConnectOn(const DpIdentList &dpIdList);

    /// Check, if the Msg is a connect msg for this DpIdList and WaitForAnswer object
    PVSSboolean  isConnectOn(const DpIdentList &dpIdList, const WaitForAnswer *ptr);

    /// Check if the Msg is a (query-)connect msg for this (query-)id
    PVSSboolean  isConnectOn(PVSSulong id);

    /// Check if the Msg is a query where multiple answers are allowed ("message splitting")
    PVSSboolean  isMultipleAnswersAllowed();

    /// make sure the sortKey is correct
    void updateSortKey();

    DpIdType getSortKey() const { return sortKey_; }

    /** Call the callback class. If the class is not a hotlinke callback object,
      clear the pointer to this object.
     */
    void callBack(DpMsgAnswer *answer);
    void callBack(DpMsgHotLink *hlMsg, DpHLGroup *hlGroup);
    void callBack(DpMsgAlert *alMsg, AlertAttrList *alGroup);

    /// Check if this message needs a refresh
    PVSSboolean needRefresh(const ManagerIdentifier &manId);

    /** Refresh the message, if it's for this manager. 
      Return PVSS_FALSE, if the CallBackItem may now be deleted
    */
    PVSSboolean doRefresh(const ManagerIdentifier &manId);

    /** Connection to System was lost, create error message, if possible.
      Return PVSS_FALSE, if the CallBackItem may now be deleted
    */
    PVSSboolean  doSystemDisconnect(SystemNumType sys);

    /// Access the callback class
    WaitForAnswer * getCallBackPtr(); 

    /// Clear the callback ptr, if it is the same as the argument
    void  clearCallBack(const WaitForAnswer *ptr);

    /// Get the answer flag
    PVSSboolean getAnswerFlag() const {return (answerFlag_ ? PVSS_TRUE : PVSS_FALSE); }

    /// Create an error message
    DpMsgAnswer * createErrorMsg(
        ErrClass::ErrPrio prio, ErrClass::ErrType type,
	      ErrClass::ErrCode code, const char *txt) const;

    /// Dump debug info
    void  reportStatus(std::ostream &to);

    /// Returns the user that created this callback
    PVSSuserIdType getUserId() const {return userId_;}

    /// Get the message type
    MsgType getMsgType() const; 

    /// Get the message destination
    const ManagerIdentifier getDestination() const;

    /// Check if this is a connect on all DP
    PVSSboolean isGlobalConnect() const;

    /// Get the original message identifier (return 0 if callback item data is not a message)
    PVSSulong getOrigMsgId() const;

    /// Get the request id (a handle for aborting the request)
    PVSSulong getRequestId() const { return reqId_; }

  protected:

    CallBackItemData *data_;

    DpIdType sortKey_;             // For sorting in array
    PVSSulong       reqId_;        // For aborting a request
    PVSSuserIdType userId_;        // The user that created this callback
    
    short  delCBFlag_   : 1;       // Delete the callback object
    short  delMsgFlag_  : 1;       // Delete the msg pointer
    short  answerFlag_  : 1;       // Got first answer

  private:
    /**
     * Passes a DpMsgAnswer to the wait object.
     *
     * If a SecurityPlugin is active, the plugin will check the message
     * before passing it to the wait object.
     */
    void handleAnswer(DpMsgAnswer &msg, WaitForAnswer &wait);

    /**
     * Passes the given message to the SecurityPlugin, if the message belongs
     * to an operation that should be covered by the plugin.
     *
     * @return An ErrClass if the whole message should be discarded, otherwise null.
     */
    ErrClass *securityPluginCheck(DpMsgAnswer &msg);

};

inline  PVSSboolean  CallBackItem::isConnectOn(const DpIdentifier &dpId, const WaitForAnswer *ptr)
{
  return (getCallBackPtr() == ptr) && isConnectOn(dpId);
}


inline  PVSSboolean  CallBackItem::isConnectOn(const DpIdentList &dpIdList, const WaitForAnswer *ptr)
{
  return (getCallBackPtr() == ptr) && isConnectOn(dpIdList);
}

#endif

