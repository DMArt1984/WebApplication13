#ifndef _TIMEVAR_H_
#define _TIMEVAR_H_

#include <Variable.hxx>
#include <CharString.hxx>
#include <AlertTime.hxx>

class itcNdrUbSend;
class itcNdrUbReceive;

// ========== TimeVar ============================================================

/** Variable class representing a date and time
    @n The time is precise to milli seconds.
    Date and time are stored as seconds since 1.1.1970 00:00 (unix time) and milli seconds.
    This class may also used to represent a time interval.
   */
//author	Johannes Ertl
class DLLEXP_BASICS TimeVar : public Variable
{
  public:
    /** @name Useful Constants
    */
    //@{

    /// null time, i.e. the 1.1.1970 00:00 or a time interval of 0
    static const TimeVar NullTimeVar;

    /// maximal time of seconds
    static const time_t MaxTimeVarSec;

    /// maximal time of miliseconds
    static const PVSSshort MaxTimeVarMSec;

    /// the latest time we can store (somewhere in 2038)
    static const TimeVar MaxTimeVar;

    /// minimal time, which we can differentiate
    static const TimeVar EpsTimeVar;
    //@}

    /** constructor, initialisation with the current time
        Note, that this is an expensive call, so use TimeVar(0, 0) if you don't want the
        current time right now.
     */
    TimeVar();

    /** constructor, initialisation with the given time
        @param newTime the seconds since 1.1.1970 00:00 of the new time
            @n You may give the seconds directly or construct a temporary PVSSTime object.
        @param newMilli the milliseconds of the new time
            @n Values > 999 will increment the seconds so the new milli seconds are always < 1000.
    */
    TimeVar(const time_t newTime, PVSSshort newMilli);

    /** constructor, initialisation with the given time
        @param newTime the seconds since 1.1.1970 00:00 of the new time
            @n You may give the seconds directly or construct a temporary PVSSTime object.
        @param newNano the nanoseconds of the new time
    */
    TimeVar(const time_t newTime, NanoSeconds newNano);

    /** constructor, initialisation with the given time
        @param newTime the seconds since 1.1.1970 00:00 of the new time
            @n You may give the seconds directly or construct a temporary BC_CTime object.
        @param newMilli the milliseconds of the new time
            @n Values > 999 will increment the seconds so the new milli seconds are always < 1000.
    */
    IL_DEPRECATED("deprecated, use constructor with time_t instead of BC_CTime instead")
    TimeVar(const BC_CTime &newTime, PVSSshort newMilli);

    /** constructor, initialisation with the given time
        @param newTime the seconds since 1.1.1970 00:00 of the new time
            @n You may give the seconds directly or construct a temporary BC_CTime object.
        @param newNano the nanoseconds of the new time
    */
    IL_DEPRECATED("deprecated, use constructor with time_t instead of BC_CTime instead")
    TimeVar(const BC_CTime &newTime, NanoSeconds newNano);

    /** constructor, initialisation with the given time
        @param newTime the PVSSTime to set
    */
    TimeVar(const PVSSTime &newTime);

    /** copy constructor
        @param rVal the TimeVar, which shall be copied from
      */
    TimeVar(const TimeVar &rVal) : Variable(rVal), time_(rVal.time_, 0) { cachedIsA = TIME_VAR; }

    /// allocator deallocator class
    AllocatorDecl;

   /** operator << for itcNdrUbSend stream
       @param ndrStream the stream, which to send to
       @param tVar the TimeVar
     */
    friend DLLEXP_BASICS itcNdrUbSend &operator<<(itcNdrUbSend &ndrStream, const TimeVar &tVar);

   /** operator >> for itcNdrUbReceive stream
       @param ndrStream the stream, which to receive from
       @param tVar the TimeVar
     */
    friend DLLEXP_BASICS itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream, TimeVar &tVar);

   /** operator << for std stream
       @param oStream the stream, which to send to
       @param tVar the TimeVar
     */
    friend DLLEXP_BASICS std::ostream &operator<<(std::ostream &oStream, const TimeVar &tVar);

   /** operator >> for std stream
       @param iStream the stream, which to receive from
       @param tVar the TimeVar
     */
    friend DLLEXP_BASICS std::istream &operator>>(std::istream &iStream, TimeVar &tVar);

   /** send to itcNdrUbSend stream
       @param ndrStream the stream, which to send to
     */
    void  outNdrUb(itcNdrUbSend &ndrStream) const;

   /** receive from itcNdrUbReceive stream
       @param ndrStream the stream, which to receive from
     */
    void  inNdrUb(itcNdrUbReceive &ndrStream);

    /** get the time in seconds.milliseconds format
        @n Use this to represent the time as a time interval.
      */
    PVSSdouble getDouble() const { return (PVSSdouble) (time_.getSeconds() + (time_.getMilliseconds() / 1000.0)); }

    /** obsolete method
      */
    IL_DEPRECATED("deprecated, use getValue() instead and use PVSSTime instead of BC_CTime")
    const  BC_CTime  getTime()  const   { return BC_CTime(time_.getSeconds()); }

    /** get the time in seconds, milli seconds will be discarded
        @return time in seconds
      */
    time_t    getSeconds() const {return time_.getSeconds(); }

    /** get the milli seconds part of the time.
        @return time in milli seconds
      */
    IL_DEPRECATED("deprecated, use getMilliSeconds() instead")
    PVSSshort getMilli() const { return time_.getMilliseconds(); }

    /** get the milli seconds part of the time
        @return time in milli seconds
      */
    PVSSulong getMilliSeconds() const { return(time_.getMilliseconds()); }

    /** get the micro seconds part of the time
        @return time in micro seconds
      */
    PVSSulong getMicroSeconds() const { return(time_.getMicroseconds()); }

    /** get the nano seconds part of the time
        @return time in nano seconds
      */
    PVSSulong getNanoSeconds() const { return time_.getNanoseconds(); }


    /** get seconds and milli seconds of the time.
        This method is obsoleted by PVSSTime getValue() const.
        @param theTime the seconds part of the time
        @param theMilli the milli seconds part of the time
    */
    IL_DEPRECATED("deprecated, use getValue() without parameters instead")
    void getValue(time_t& theTime, PVSSshort& theMilli) const { theTime = time_.getSeconds(); theMilli = time_.getMilliseconds(); }

    /** get seconds and milli seconds of the time.
        This method is obsoleted by PVSSTime getValue() const.
        @param theTime the BC_CTime object that holds the seconds part of the time
             @n Use theTime.ElapsedSeconds() to get the seconds as an integer.
        @param theMilli the milli seconds part of the time
    */
    IL_DEPRECATED("deprecated, use getValue(time_t, PVSSshort) instead")
    void getValue(BC_CTime &theTime, PVSSshort &theMilli) const
      { theTime = time_.getSeconds(); theMilli = time_.getMilliseconds(); }

    /** get value as PVSSTime
        @return the resulting PVSSTime
    */
    const  PVSSTime &getValue() const  { return time_; }

    /** set the seconds and milli seconds of the time.
        @param newTime the seconds part of the new time as a PVSSTime object
             @n You can use an explicitly constructed object or an integer value.
               In the latter case a temporary object will be constructed automaticly.
        @param newMilli the milli seconds part of the new time
             @n If the value is outside the range 0..999 the seconds are adjusted accordingly.
    */
    void setValue(time_t newTime, PVSSlong newMilli) { time_ = PVSSTime(newTime, newMilli); }

    /** set the seconds and milli seconds of the time.
        This method is obsoleted by setValue(const PVSSTime &).
        @param newTime the seconds part of the new time as a BC_CTime object
             @n You can use an explicitly constructed object or an integer value.
               In the latter case a temporary object will be constructed automaticly.
        @param newMilli the milli seconds part of the new time
             @n If the value is outside the range 0..999 the seconds are adjusted accordingly.
    */
    IL_DEPRECATED("deprecated, use setValue(time_t, PVSSlong) instead")
    void setValue(const BC_CTime &newTime, PVSSshort newMilli) { time_.setValue(newTime.ElapsedSeconds(), newMilli); }

    /** set value by PVSSTime
        @param newTime the PVSSTime to set
      */
    void setValue(const PVSSTime &newTime) { time_ = newTime; }

    /** set value as double
        @param newTime the time as a double to set
      */
    void setValue(double newTime) { time_.setDouble(newTime); }

    /** obsolete method
      */
    IL_DEPRECATED("deprecated, use setValue() instead")
    void setTime(const BC_CTime &newTime)  { time_.setSeconds(newTime.ElapsedSeconds()); }

    /** set the seconds of the time without changing the milli seconds
        @param newTime the time_t as a seconds part of the new time
            @n You can use an explicitly constructed object or an integer value.
               In the later case a temporary object will be constructed automaticaly.
    */
    void setSeconds(time_t newTime) { time_.setSeconds(newTime); }

    /** set the milli seconds part of the time
        @param newMilli the number of mili seconds of the new time
            @n If the value is outside the range 0..999 the seconds are adjusted accordingly.
    */
    void setMilli(PVSSshort newMilli)     { time_.setMilliseconds(newMilli); }

    /** take and set current time
      */
    void setCurrentTime() { time_ = PVSSTime::getSystemTime(); }

    /** try to convert
        @param to the VariableType, to convert to
        @param out the VariablePtr, to convert from
        @return OK: conversion successful, "out" will be allocated
             @n OUT_OF_RANGE: conversion basically possible, but the value of "out" lies
                out of range "to", "out" wll be alocated in spite of this (!!!) and gets
                Min or Max of possible range
             @n CONV_NOT_DEFINED: type changing not possible, "out" will be set to 0
      */
    virtual ConvertResult convert(VariableType to, VariablePtr &out) const;

    /** comparison operator ==
        @param rVal the Variable to compare with
            @n Important: this operator checks the VariableType, so two objects are only equal, if
               they also have the same class (no conversion is done; see other operators)
        @return 0 if not equal else 1
    */
    virtual int operator==(const Variable &rVal) const;

    /** comparison operator <
        @param rVal the Variable to compare with
            @n Important: this operator also converts the given rVal to its own class-type if needed.
        @return 0 if the Variable to compare with is smaller else 1
      */
    virtual int operator<(const Variable &rVal) const;

    /** comparison operator >
        @param rVal the Variable to compare with
            @n Important: this operator also converts the given rVal to its own class-type if needed.
        @return 0 if the Variable to compare with is bigger else 1
    */
    virtual int operator>(const Variable &rVal) const;

    /** non virtual comparision operator == (to spare virtual call)
        @param rVal the TimeVar to compare with
        @return 0 if not equal else 1
      */
    int operator==(const TimeVar &rVal) const { return time_ == rVal.time_; }

    /** non virtual comparision operator == (to spare virtual call)
        @param rVal the PVSSTime to compare with
        @return 0 if not equal else 1
      */
    int operator==(const PVSSTime &rVal) const { return time_ == rVal; }

    /** non virtual comparision operator != (to spare virtual call)
        @param rVal the TimeVar to compare with
        @return 0 if equal else 1
      */
    int operator!=(const TimeVar &rVal) const { return !(time_ == rVal.time_); }

    /** non virtual comparision operator < (to spare virtual call)
        @param rVal the TimeVar to compare with
        @return 0 if the TimeVar to compare with is smaller else 1
      */
    int operator<(const TimeVar &rVal) const  { return time_ < rVal.time_; }

    /** non virtual comparision operator > (to spare virtual call)
        @param rVal the TimeVar to compare with
        @return 0 if the TimeVar to compare with is bigger else 1
      */
    int operator>(const TimeVar &rVal) const  { return time_ > rVal.time_; }

    /** non virtual comparision operator <= (to spare virtual call)
        @param rVal the TimeVar to compare with
        @return 0 if the TimeVar to compare with is smaller or equal else 1
      */
    int operator<=(const TimeVar &rVal) const {return !operator>(rVal);}

    /** non virtual comparision operator >= (to spare virtual call)
        @param rVal the TimeVar to compare with
        @return 0 if the TimeVar to compare with is bigger or equal else 1
      */
    int operator>=(const TimeVar &rVal) const {return !operator<(rVal);}

    /** assignment operator used for type conversions
        @param rVal the Variable to assign
        @return the resulting Variable
      */
    virtual Variable &operator=(const Variable &rVal);

    /** assignment operator used just for assignment
        @param rVal the Variable to assign
        @return the resulting TimeVar
      */
    TimeVar& operator= (const TimeVar &rVal) { time_ = rVal.time_; return *this; }

    /** add a time (difference) to the current time
        @param rVal the TimeVar to add
        @return the resulting TimeVar
      */
    TimeVar operator+(const TimeVar &rVal) const;

    /** subtract a time (difference) to the current time
        @param rVal the TimeVar to subtract
        @return the resulting TimeVar
      */
    TimeVar operator-(const TimeVar &rVal) const;

    /** add a time (difference) to the left TimaVar
        @param rVal the TimeVar to add
        @return the resulting TimeVar
      */
    TimeVar &operator+=(const TimeVar &rVal);

    /** subtract a time (difference) from the left TimaVar
        @param rVal the TimeVar to subtract
        @return the resulting TimeVar
      */
    TimeVar operator-=(const TimeVar &rVal);

    /** divide the left TimaVar, only seconds of right TimeVar are taken
        @param rVal the TimeVar to devide by
        @return the resulting int
      */
    time_t operator/(const TimeVar &rVal);

    /** multiply the left TimaVar
        @param i the int to multiply
        @return the resulting TimeVar
      */
    TimeVar operator*(const int i);

    /** cast to const PVSSTime &
        @return the resulting PVSSTime
      */
    operator const PVSSTime () const   { return time_; }

    /** check if this TimeVar object is logically true, i.e. if there is a time stored in it
        @return PVSS_FALSE if this TimeVar object is empty or "false" or "FALSE" else PVSS_TRUE
      */
    virtual PVSSboolean isTrue() const {return (*this != NullTimeVar);}

    /** clone the current TimeVar object
        @return the Variable as clone of this object
      */
    virtual Variable *clone() const;

    /** allocate new TimeVar
        @return the new TimeVar
      */
    virtual Variable *allocate() const;

    /** return type of variable
        @return TIME_VAR
      */
    virtual VariableType isAUncached() const { return TIME_VAR; }

    /** return type of variable
        @param varType the VariableType to check
      @return TIME_VAR if TimeVar else return other VariableType
      */
    virtual VariableType isAUncached(VariableType varType) const;

# if 0
    /** return own variable type
        @return TIME_VAR
      */
    VariableType  isA() const;

    /** check if own variable type matches other variable type
        @param varType the VariableType to check
        @return TIME_VAR, if argument is TimeVar, else NOTYPE_VAR.
      */
    VariableType  isA(VariableType varType) const;
# endif

    /** send to output stream
        @param ofStream the stream, which to send to
            @n Format is YYYY.MM.DD;HH:MM:SS,mmm.
      */
    virtual void outToFile(std::ostream &ofStream) const;

    /** get from input stream
        @n Format is YYYY.MM.DD;HH:MM:SS,mmm, but any other seperator except white space may be used.
      */
    virtual void inFromFile(std::istream &);

    /** format the value according to the format string
            @n This method internally calls the overloaded formatValue method which writes to a char* buffer.
               A buffer length of 1024 is used. Therefore, the result must not exceed 1023 characters.
        @param format the format string
            @n For the semantics, see the overloaded formatValue method which writes to a char* buffer.
        @return the string representation of the value
    */
    virtual CharString formatValue(const CharString &format) const;

    /** format the value according to a format string
            @n This method is more performant than the overloaded formatValue method which returns a CharString
               because no alloc is done.
        @param format the format string
            @n YYYY.MM.DD hh:mm:ss.mmm       (milliseconds) if the format string is empty
            @n YYYY.MM.DD hh:mm:ss.uuuuuu    (microseconds) if the format string is "U" or "u"
            @n YYYY.MM.DD hh:mm:ss.nnnnnnnnn (nanoseconds)  if the format string is "N" or "n"
            @n any other format string of length 1 is invalid
            @n a format string with a length > 1 has the semantics of the strftime function
               respectively the wcsftime function on Windows for UTF8-encoding.
            @n CAUTION: date and time formatting for different locales may differ at different platforms!
        @param target the char* buffer, which is directly written to
        @param len the length of the buffer
        @return the int as number of bytes written into target without 0-byte,
                or a non-positive value on error (like buffer too small)
    */
    virtual int formatValue(const CharString &format, char *target, size_t len) const;

    /** print the content to an output stream
        @param to the stream to print to
        @param level the int to control the amount of debug information, nothing is printed if level = 0
      */
    virtual void debug(std::ostream &to, int level) const;

// ------------------------------------------------------------------------------
  private:

    /** format the value according to a format string.
        This method is only used on Windows platform for UTF8 encoding.
        @param format the format string
            @n the format string has the semantics of the wcsftime function on Windows for UTF8-encoding.
        @param target the char* buffer, which is directly written to
        @param len the length of the buffer
        @return Number of bytes written into target without 0-byte,
                or a non-positive value on error (like buffer too small)
    */
    int formatValuePosix(const CharString &format, char *target, size_t len) const;

#if defined (_WIN32) && !defined(WINCE)
    /** format the value according to a format string.
        This method is used on non-Windows platforms and on Windows platform for non-UTF8 encoding.
        @param format the format string
            @n the format string has the semantics of the strftime function
        @param target the char* buffer, which is directly written to
        @param len the length of the buffer
        @return Number of bytes written into target without 0-byte,
                or a non-positive value on error (like buffer too small)
    */
    int formatValueUtf8(const CharString &format, char *target, size_t len) const;
#endif


  protected:
    /** member containing time information
      */
    AlertTime  time_;  // Same size as PVSSTime. The counter is never accessed
};

// ================================================================================
// inline functions

inline TimeVar::TimeVar(const time_t newTime, PVSSshort newMilli)
  : time_(PVSSTime(newTime, newMilli), 0)
{
  cachedIsA = TIME_VAR;
}

inline TimeVar::TimeVar(const time_t newTime, NanoSeconds newNano)
  : time_(PVSSTime(newTime, newNano), 0)
{
  cachedIsA = TIME_VAR;
}

inline TimeVar::TimeVar(const BC_CTime &newTime, PVSSshort newMilli)
              : time_(PVSSTime(newTime.ElapsedSeconds(), newMilli), 0)
{
  cachedIsA = TIME_VAR;
}

inline TimeVar::TimeVar(const BC_CTime &newTime, NanoSeconds newNano)
              : time_(PVSSTime(newTime.ElapsedSeconds(), newNano), 0)
{
  cachedIsA = TIME_VAR;
}

inline TimeVar::TimeVar(const PVSSTime &newTime)
              : time_(newTime, 0)
{
  cachedIsA = TIME_VAR;
}

inline TimeVar TimeVar::operator+(const TimeVar &rVal) const
{
    // Constructor normalizes
    return TimeVar(time_ + rVal.time_);
}

inline TimeVar TimeVar::operator-(const TimeVar &rVal) const
{
  if (rVal < *this)    // No negative times
    return TimeVar(time_ - rVal.time_);
  else
    return TimeVar(0, 0);
}

inline TimeVar &TimeVar::operator+=(const TimeVar &rVal)
{
    return (TimeVar &) ((*this) = (*this) + rVal);
}

inline TimeVar TimeVar::operator-=(const TimeVar &rVal)
{
    return (TimeVar &) ((*this) = (*this) - rVal);
}

inline time_t TimeVar::operator/(const TimeVar& rVal)    // on seconds calculated only!!!
{
  return (rVal.getSeconds()) ? (getSeconds() / rVal.getSeconds()) : 0;
}

inline TimeVar TimeVar::operator*(const int i)
{
  return TimeVar(getSeconds() * i, 0);
}

//--------------------------------------------------------------------------------

#endif /* _TIMEVAR_H_ */
