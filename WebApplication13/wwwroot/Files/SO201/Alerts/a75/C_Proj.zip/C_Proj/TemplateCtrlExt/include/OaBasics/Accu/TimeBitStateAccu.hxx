#ifndef _TIMEBITSTATEACCU_H_
#define _TIMEBITSTATEACCU_H_

#ifndef _SIMPLEACCU_H_
#include <SimpleAccu.hxx>
#endif

#ifndef _VARIABLE_H_
#include <Variable.hxx>
#endif

#ifndef _TIMEVAR_H_
#include <TimeVar.hxx>
#endif

#ifndef _BITVAR_H_
#include <BitVar.hxx>
#endif

// ========== TimeBitStateAccu ============================================================

/** the time bit state accumulator class
    @n This class implements a statistic accumulator to determine the overall time while a BitVar
    remained in a state ( 0 or 1 ).
    @classification ETM internal
*/
class DLLEXP_OABASICS TimeBitStateAccu: public SimpleAccu
{
  public:

    /// constructor
    /// @param aState the state to check
    TimeBitStateAccu( PVSSboolean aState = PVSS_FALSE );
    
    /// process a new value
    /// @param theValue the value to process
    /// @param atTime the time of the processing
    virtual void accumulate(const Variable &theValue, const TimeVar &atTime );

    /// ignore value for a given time
    /// @param theValue the value to ignore
    /// @param atTime the time of the processing
    virtual void accumulateInvalid( const Variable &theValue, const TimeVar &atTime );

    /// get result
    /// @return the result
    virtual const Variable &getResult();

    /// get intermediate result
    /// @param theValue the value to process
    /// @param start the start time of the processing
    /// @param stop the stop time of the processing
    /// @param valid the validity flag
    /// @return the intermediate result
    virtual const Variable &getIntermResult( const Variable &theValue, const TimeVar &start, const TimeVar &stop, bool valid );

    /// reset internal values
    virtual void reset();
    
  protected:
  
  private:
    TimeBitStateAccu(const TimeBitStateAccu &);
    TimeBitStateAccu &operator=(const TimeBitStateAccu &);
  
    BitVar stateToCheck;
    BitVar lastState;
    TimeVar lastTime;
    TimeVar duration;
    TimeVar intermResult_;      // WOKL 2.2.01 TI 7411
};

#endif

