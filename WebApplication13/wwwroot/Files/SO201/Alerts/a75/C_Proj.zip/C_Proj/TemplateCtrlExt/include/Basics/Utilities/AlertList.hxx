#ifndef _ALERTLIST_H_
#define _ALERTLIST_H_

// Vorwaerts-Deklaration der eigenen Klasse
class AlertList;

// System-Include-Files
#ifndef _ALERTATTRLIST_H_
#include <AlertAttrList.hxx>
#endif

#ifndef _PTRLIST_H_
#include <PtrList.hxx>
#endif

// Vorwaerts-Deklarationen:
class AlertIdentifier;
class AlertList;
class Variable;

/**
 * A PtrList for AlertAttrLists. It is used inside alert messages to
 * transmit alert attributes and value.
 */
class DLLEXP_BASICS AlertList : public PtrList 
{
  friend class AlertPair;

public:
  /**
   * Default constructor. Creates an empty list.
   */
  AlertList();
  
  /**
   * Copy constructor. Creates a deep copy of the specified list.
   */
  AlertList(const AlertList &chAlerts);

  /**
   * Destructor.
   */
  ~AlertList();

  // Operatoren:

  /**
   * Used to send an alert list through the BCM message connection.
   *
   * @internal
   */
  friend DLLEXP_BASICS itcNdrUbSend &operator<<(itcNdrUbSend &ndrStream, const AlertList &list);

  /**
   * Used to receive an alert list through the BCM message connection.
   *
   * @internal
   */
  friend DLLEXP_BASICS itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream, AlertList &list);

  /**
   * Checks whether the two specified AlertLists are equal.
   *
   * Two lists are equal if they contain an equal number of equal items in the
   * same order.
   */
  int operator==(const AlertList &rVal) const;
  
  /**
   * Copies all items from the specified list to this list,
   * so that this list is equal to the specified list.
   */
  AlertList &operator=(const AlertList &chAlerts);

  /**
   * Inserts a new attribute into the list.
   *
   * If the attribute is already in the list, only the value is updated.
   * Otherwise, if there is a valid AlertAttrList item for the attribute,
   * it is inserted into that AlertAttrList.
   * If there is no valid AlertAttrList in the AlertList,
   * a new AlertAttrList is created and the item is inserted there.
   *
   * @param identifier the attribute to insert
   * @param valuePtr a pointer to a Variable object which holds the value.
   * The call takes ownership of this pointer.
   * @param search If false, the specified attribute will be appended,
   * even if the same attribute is already in the list.
   *
   * @return PVSS_TRUE on success
   *
   * @see AlertAttrList::insertAttribute()
  */
  PVSSboolean insertAttribute(const AlertIdentifier &identifier,
                              Variable *valuePtr = 0,
                              PVSSboolean search = PVSS_TRUE);
  
  /**
   * Update the value for an attribute in the list.
   *
   * @param identifier the attribute to search for
   * @param valuePtr a pointer to a Variable object which holds the value.
   * The call takes owner ship of this pointer.
   *
   * @return PVSS_FALSE if the specified attribute cannot be found,
   * otherwise PVSS_TRUE.
   *
   * @see AlertAttrList::setValuePtr()
   */
  PVSSboolean setValuePtr(const AlertIdentifier &identifier, Variable *valuePtr);

  /**
   * Merges the specified list into this list.
   *
   * New attributes are inserted with the respective values from @p list,
   * existing attributes are updated with their new value from @p list.
   *
   * After this call, the specified list is empty, all new attributes
   * have been copied and all Variable objects have been moved to this list.
   *
   * @param list The AlertList to be merged into this AlertList.
   */
  void mix(AlertList &list);

  /** 
   * Resets the interal pointer of the list to the first entry
   * and returns a pointer to this entry.
   * The list contains AlertAttrList objects.
   *
   * @return A pointer to the first item or 0 if the list is empty
   */
  AlertAttrList *getFirstAttrList() const { return (AlertAttrList *) getFirst(); }

  /**
   * Moves the internal pointer of the list to the next entry
   * and returns a pointer to this entry.
   * The list holds AlertAttrlist objects.
   * 
   * @return A pointer to the next item or 0 if there are no more items
   */
  AlertAttrList *getNextAttrList() const { return (AlertAttrList *) getNext(); }

  /** 
   * Clears the list. All items in the list are deleted.
   */
  virtual void clear();
  
  /**
   * Dumps a debug output of the list to an output stream.
   *
   * @param to the target stream
   * @param level the detail level of information, should be > 0
   */
  virtual void debug(std::ostream &to, int level) const;
  
protected:
private:
  /**
   * Pointer to the last accessed entry.
   */
  AlertAttrList *cacheList;

  // siehe AlertAttrList.hxx, Definition von allAttributes.
  // Kein toter Code; wird verwendet von AlertPair!
  void insertAllAttrList(const AlertIdentifier &identifier);
};

#endif /* _ALERTLIST_H_ */
