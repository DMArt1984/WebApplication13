#ifndef _IOSUTIL_H_
#define _IOSUTIL_H_

/*
  DESCRIPTION:    see class description below
  RESPONSIBILITY: pkass, theis 
  Do not use PVSS2-specific functions (e.g. from Resources(!) and nothing from variables
  to keep it lean !
  Use standard data types wherever possible !
*/

#include <iostream>
#include <fstream>

/** 
    @class IOSUtil
    The IOS wrapper. Since old and new iostreams or even new iostreams (STL) on different
    platforms/compilers have slightly different semantics we need 
    this abstraction layer.
*/

class DLLEXP_OABASICS IOSUtil
{
  public:

  /** wrapper for istream& get (char* buf, streamsize bufLen, char delim ); 
      Difference: if next char == delim, fail-bit is NOT set (as it is since gcc 3.2)
      and buf is set to empty string.
      @param inpStream    ... the istream or ifstream or any derived type.
      @param buf       ... parameter for => istream& get (char* buf, streamsize bufLen, char delim );  
      @param bufLen    ... parameter for => istream& get (char* buf, streamsize bufLen, char delim );  
      @param delim     ... parameter for => istream& get (char* buf, streamsize bufLen, char delim );  
      @return inpStream, if next char == delim, or return value if inpStream.get( ... )
  */
  static std::istream& istreamGet( std::istream& inpStream, char* buf, int bufLen, char delim );

  /** wrapper for istream& get (char* buf, streamsize bufLen) with the delimter set to \n.
      @see istreamGet( istream& inpStream, char* buf, int bufLen, char delim ). 
      @param inpStream    ... the istream or ifstream or any derived type.
      @param buf       ... parameter for => istream& get (char* buf, streamsize bufLen, char delim );  
      @param bufLen    ... parameter for => istream& get (char* buf, streamsize bufLen, char delim );  
      @return inpStream, if next char == delim (\n), or return value if inpStream.get( ... )      
   */
  static std::istream& istreamGet( std::istream& inpStream, char* buf, int bufLen )
    { return istreamGet( inpStream, buf, bufLen, '\n'); };

};

#endif /* _IOSUTIL_H_ */

