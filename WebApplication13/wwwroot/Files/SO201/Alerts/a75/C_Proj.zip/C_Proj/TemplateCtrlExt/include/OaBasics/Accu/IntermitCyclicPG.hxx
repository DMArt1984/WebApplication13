#ifndef _INTERMITCYCLICPG_H_
#define _INTERMITCYCLICPG_H_

// 22.8.2006 WOKL: IM 75854  Modifizierung von SyncedCyclicPG, um Listen von Tag/Zeitpaaren mit Start/Endezeiten zu bedienen

#include <PeriodGenerator.hxx>
#include <NextValidIntermitTime.hxx>

// ========== IntermitCyclicPG ============================================================

/** intermittently active cyclic period generator
    @n This class generates cyclic periods of given time interval within
    certain validity period of given validity time interval.
    An intermittently day/week schedule can be specified.

    Example:

    x____0____x____1____x____2____x____3____x____4____x____#____x

    __________F______________________________________________U___________

    symbols:
    @n x__n__x  period with number n = 0, 1, 2...   x marks start and end
    @n x__#__x  the last period, considered invalid
    @n ___F___  validity period from
    @n ___U___  validity period until
 
    @classification ETM internal
*/
class DLLEXP_OABASICS IntermitCyclicPG : public PeriodGenerator
{
  public:
    friend class UNIT_TEST_FRIEND_CLASS;
    /// constructor, initialisation with zero values
    IntermitCyclicPG();
    
    /** set conditions of the intermittently active period generator
        @param aStartTime the starting time of generation
        @param aWeekDayList the generator activity schedule within a week
        @param aDayTimeList the generator activity schedule within a day
            @n These two lists contain pairs of week day - time. The particular pairs specify
               end and start of intermission. It means, that the first pair specifies the start
               of activity of the generator the second one specifies the end of the activity.
            @n The number of items in the both lists must be the same, must be > 2 and must be even.
            @n Valid values for week day are:
            @n 1..7 corresponds to a day from monday to sunday
            @n -2 means all days from monday to friday (mo, th, we, th, fr)
            @n -3 means saturday/sunday (weekend)
            @n Valid value range for time is 0-86399.
        @param aInterval the time interval of cyclic periods in seconds
        @param aValidFrom the starting time of validity period
            @n If NullTimeVar, then the first period ends at aStartTime.
        @param aValidUntil the ending time of validity period
            @n If NullTimeVar, then periods never get invalid (may work forever).
        @return PVSS_TRUE if everything is OK, else PVSS_FALSE 
      */
    PVSSboolean setConditions( const TimeVar &aStartTime,
                               const DynVar &aWeekDayList,
                               const DynVar &aDayTimeList,
                               // const PVSSulong aSyncTime,
                               const PVSSulong aInterval,
                               const TimeVar &aValidFrom = TimeVar::NullTimeVar,
                               const TimeVar &aValidUntil = TimeVar::NullTimeVar );
    
    /** go to the next period
        @return PVSS_TRUE if within given validity period, else PVSS_FALSE 
      */
    virtual PVSSboolean goNextPeriod();

    /** return status of the intermittently active period generator
        @return PVSS_TRUE if the generator is on, else PVSS_FALSE 
      */
    PVSSboolean getStatus() { return isOn_; }

  protected:

  private:
    // so that the compiler does not define them itself !!
    // copy constructor
    IntermitCyclicPG(const IntermitCyclicPG &) {}
    // assignment operator
    IntermitCyclicPG &operator=(const IntermitCyclicPG &) { return *this; }

    void initialize( const TimeVar &aStartTime );
    
    NextValidIntermitTime myNextTrigger_;     // calculates the intervals
    TimeVar validFrom_;
    TimeVar validUntil_;
    
    TimeVar     nextSync_;                    // next interval start
    PVSSulong   interval_;
    // PVSSulong   syncTime_;
    PVSSboolean isOn_;                        // acual period is inside an interval
    TimeVar     lastStartSync_;               // last start interval 
};

#endif /* _INTERMITCYCLICPG_H_ */
