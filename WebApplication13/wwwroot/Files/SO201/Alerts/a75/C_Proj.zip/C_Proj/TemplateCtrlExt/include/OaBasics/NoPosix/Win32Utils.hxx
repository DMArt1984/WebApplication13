// -----------------------------------------------------------------
// <Win32Utils.hxx>
// creator: pkass at 2001-11-06
// purpose: Interfaces to win32 - Shell and other special
//          functionalities
// -----------------------------------------------------------------
// history:
// 2001-11-06:  pkass N            ( B O C X )
// -----------------------------------------------------------------

#if !defined(_WIN32UTILS_HXX_)
#define _WIN32UTILS_HXX_

#ifdef _WIN32

#ifndef _WINDEF_

  typedef unsigned long       DWORD;

#endif


/******************************************************************/
/** @class Win32Utils
 *  @osdiff The methode regServer() is not defined for _WIN32_WCE.
 *  @osdiff Serveral methodes give different results for _WIN32_WCE.
 *  @brief Interfaces to win32 - Shell and other special functionalities
    the Win32Utils class.
    Interfaces to win32 - Shell
 *  @classification public use */
//author pkass 

class DLLEXP_OABASICS Win32Utils 
{
public: //AUTO_INSERT
  
  enum 
  {
    W32Ut_E_SetPath                  = 110002,
    W32Ut_E_SetArgs                  = 110003,
    W32Ut_E_SetDesc                  = 110004,
    W32Ut_E_Save                     = 110005,
    W32Ut_E_SetIconLoc               = 110006,
    W32Ut_E_SaveIconLoc              = 110007,
    W32Ut_E_QueryIPersistFile        = 110008,
    W32Ut_E_CerrOpen                 = 110009,
    W32Ut_E_ShellLinkInitClassNotReg = 110010,
    W32Ut_E_ShellLinkInitClassNoAggr = 110011,
    W32Ut_E_ShellLinkInitNoInterface = 110012,
    W32Ut_E_UnRegFailed              = 110013,
    W32Ut_E_RegFailed                = 110014,
    W32Ut_E_RegLoadLib               = 110015,
    W32Ut_E_SecSidInit               = 110016,
    W32Ut_E_FileOpen                 = 110017,
    W32Ut_E_GetSecurityInfo          = 110018,
    W32Ut_E_SetEntriesInAcl          = 110019,
    W32Ut_E_SetSecurityInfo          = 110020,
    W32Ut_E_AccessDenied             = 110021
  };

    /** get profile specific pathes
          @param nFolder ... kind of folder. See SHGetSpecialFolderLocation().
          @param folderPath 
          @return bool true = success
     *  @see SHGetSpecialFolderLocation().
     *  @osdiff For _WIN32_WCE The parameters are not evalueted and
     *          the result is alway true, with a fixed value in folderPath.
                                             */
  static bool GetSpecialFolderPath(int nFolder, CharString & folderPath);

      /** get the user specific path for application data
          @param folderPath 
          @return bool true = success
     *  @see GetSpecialFolderPath().
                                             */
  static bool GetUserApplicationDataPath(CharString & folderPath);

      /** get the common start menu programs path
          @param folderPath 
          @return bool true = success
     *  @see GetSpecialFolderPath().
                                             */
  static bool GetCommonStartMenuProgramsPath(CharString & folderPath);

       /** get the errortext for WIN32 specific system errors as defined in WINERROR.H
          @param rc          ... return value of a call to GetLastError()
          @param sysErrorText ... the system error text
          @param notFoundText ... text for "not found" to ignore return value (optional)
          @return int 0 = success, else: error text could not be retrieved
                                             */
  static int sysErrorTextRc(int rc, CharString &sysErrorText, const char *notFoundText=0);


         /** get the errortext for WIN32 specific system errors as defined in WINERROR.H
          @param rc          ... return value of a call to GetLastError()
          @param sysErrorText ... the system error text
          @param notFoundText ... text for "not found" to ignore return value (optional)
          @return const char * a pointer to the sysErrorText - buffer.
     *  @see sysErrorTextRc(). 
                                             */
  static const char *sysErrorText(int rc, CharString &sysErrorText, const char *notFoundText=0);


  
      /** gets the last WIN32 specific error code as defined in WINERROR.H
          It does not reset the error code.
          @return int last WIN32 erro code.
                                             */
  static int getLastError();


    /** gets an error text for a Win32Utils error number
          @param errNo error number from this class' methods
          @return const char * error text, or "" on error
     *    @return const char * error text. If the text is not found
     *            a text giving the error number.
                                             */
  static const char * getErrorText(int errNo);

  /** get the path name of my executable file
          @param withoutPath  ... just filename
          @param withoutExt   ... without extension .exe
          @return bool true = success
   *      @return The path of the programm as requested,
   *              an empty string on error.
                                             */

  static CharString GetMyModuleFileName( bool withoutPath = false, bool withoutExt = false );


    /** redirect std::cerr to file in win32 applications
          @param filePath is created, if not existing, std::cerr is appended, if existing
          @return int 0 on success, or W32Ut_E_CerrOpen
                                             */
  static int redirectCerr(const char * filePath);


      /** test, if user language OS setting is german (of any region) or not
          @param langShort if not NULL, will contain the short text form of
                  the language, or the language number code (only the most 
                  important languages are coverted to text form, else the
                  primary language identifier number is converted)
          @return bool true, if german
                                             */
  static bool isUserLangGerman(CharString * langShort=0);

  /** (un-)registration of a (COM-) dll.
    *     @param dllFilePath the path to the dll, which should
    *                        be (de-)registert.
    *     @param bUnreg true to deregister the dll.
    *
     *  @see regsevr32 /? for details.
                                             */

  static int regServer(const char * dllFilePath, bool bUnreg=false);

  
    /** set read/write/execute permission for file or directory
          @param *fileOrDir file or directory name (absolute path)
          @return int 0 = success
     *  @osdiff For _WIN32_WCE The parameters are not evalueted and
     *          the result is alway 0.
                                             */
  static int chmod777(const char *fileOrDir);

    /** Grant read/write/execute- or read/execute-access for predefined 
        (SECURITY_BUILTIN_DOMAIN_RID) user group .
        Permission is inherited to files and subdirectories, if fileOrDir is a directory.
        Access permission cannot be granted, if it has been already explicitely denied before. 
          @param builtinRID security identifier relative to SECURITY_NT_AUTHORITY
          @param *fileOrdir name of file or directory to change permissions
          @param writeAccess if false => grant only read/execute access
          @return int 0 = success or W32Ut_E_SecSidInit, W32Ut_E_AccessDenied or
                           W32Ut_E_FileOpen => get last Windows error coder from getLastError()
          @see getLastError()
     *  @osdiff For _WIN32_WCE The parameters are not evalueted and
     *          the result is always sucess.
                                             */
  static int chmodRWX4BuiltinRIDs(DWORD builtinRID, const char *fileOrDir, bool writeAccess);


    /** Grant read/write/execute- or read/execute-access for predefined user group "Power Users".
        Calls chmodRWX4BuiltinRIDs( DOMAIN_ALIAS_RID_POWER_USERS ,...).
          @param *fileOrdir name of file or directory to change permissions
          @param writeAccess if false => grant only read/execute access
          @return int 0 = success or from chmodRWX4BuiltinRIDs()
          @see chmodRWX4BuiltinRIDs()
          @see getLastError()
     *  @osdiff For _WIN32_WCE The parameters are not evalueted and
     *          the result is always sucess.
                                             */
  static int chmodRWX4PowerUsers(const char *fileOrDir, bool writeAccess=true);


    /** Grant read/write/execute- or read/execute-access for predefined user group "Power Users".
        Calls chmodRWX4BuiltinRIDs(DOMAIN_ALIAS_RID_ADMINS ,...).
          @param *fileOrdir name of file or directory to change permissions
          @param writeAccess if false => grant only read/execute access
          @return int 0 = success or from chmodRWX4BuiltinRIDs()
          @see chmodRWX4BuiltinRIDs()
          @see getLastError()
     *  @osdiff For _WIN32_WCE The parameters are not evalueted and
     *          the result is always sucess.
                                             */
  static int chmodRWX4Administrators(const char *fileOrDir, bool writeAccess=true);

};


#endif

#endif // !defined(_WIN32UTILS_HXX_)
