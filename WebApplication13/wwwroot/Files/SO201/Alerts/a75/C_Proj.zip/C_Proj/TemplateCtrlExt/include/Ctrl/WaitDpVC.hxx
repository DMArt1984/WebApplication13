#ifndef _WAITDPVC_H_
#define _WAITDPVC_H_

#include <WaitCond.hxx>
#include <DpHLGroup.hxx>

class WaitForAnswer;


/*  author VERANTWORTUNG: Heinz Meissl         */
/** Virtuelle Basisklasse                              */
class DLLEXP_CTRL WaitDpVC : public WaitCond
{
  public:
    /// wird beim Eintreffen eines Hotlinks aufgerufen
    virtual void dpValueChanged(const DpHLGroup &group) = 0;

    virtual WaitForAnswer * getWaitForAnswer() const = 0;
};

#endif /* _WAITDPVC_H_ */
