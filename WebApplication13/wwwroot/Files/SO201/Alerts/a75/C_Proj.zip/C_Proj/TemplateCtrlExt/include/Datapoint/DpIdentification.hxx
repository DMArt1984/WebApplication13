#ifndef _DPIDENTIFICATION_H_
#define _DPIDENTIFICATION_H_

// VERANTWORTUNG:  Stanislav Meduna
//                 Anpassungen fuer 3.5 Martin Koller
//
// BESCHREIBUNG:  Die zentrale Schnittstelle fuer externe <-> interne
//     Adressierungskonvertierung.
//
// VERWENDUNG:  Jeder Manager, der diese Konvertierung braucht, wird
//     ein Objekt dieser Klasse erzeugen. Folgende
//     Parametrierungen sind notwendig:
//
//     - Anzahl der Sprachen (setNoOfLanguages)
//     - Assoziation zum TypKontainer (setTypeContainer)
//       (je System)
//
//     - Die Namen <-> interne Bezeichner Zuweisungen
//       (add*Names, remove*Names)
//       - Systeme
//       - Datenpunkte (je System)
//       - Elemente (je System und Datenpunkt-Typ)
//       - Datenpunkttypen (je System)
//
//       - Configs, Details, Attribute sind fix hardcoded und kommen aus ConfigsMapper
//
//     - Default-Systemnummer (setDefaultSystem)
//
//     Die Namen koennen erst nach dem Anzahl der Sprachen
//     Parametriert werden.
//
//     Als die Namen nur in einem System eindeutig sind,
//     muss man alle Namen (mit die Ausnahme der Systemnamen)
//     pro-System parametrieren. Das gilt auch fuer
//     Typ-Kontainers. Systemnummer ist in meisten Funktionen
//     ein default-Argument (als default gilt default-
//     Systemnummer);
//
//     Bei Uebertragung des ganzes Systems werden die
//     TypKontainers _nicht_ automatisch uebertragen
//     und die Assoziations muss man neu parametrieren.
//     Ebenso ist die Konsistenz zwischen DpIdentification
//     und DpTypeContainer nicht automatisch.
//
//     Die Typ-Kontainers werden nur fuer Umwandlungen
//     benutzt (um die Baumstruktur des Typs zu wissen),
//     fuer die Parametrierung sind sie nicht notwendig.
//
//
//     Fuer die aktuelle Konvertierung werden die Funktionen
//     getId, getIdSet, getTypeId (Name->Id) und getName,
//     getTypeName (Id->Name) verwendet.

#include <DpIdentificationResultType.hxx>
#include <Resources.hxx>
#include <DpConfigNrType.hxx>
#include <DpElementType.hxx>
#include <DpTypes.hxx>
#include <Variable.hxx>
#include <DpIdentifier.hxx>
#include <LangText.hxx>
#include <DpIdentificationProSystem.hxx>
#include <DpSymIdentifier.hxx>
#include <CNSContainer.hxx>

class DpIdentification;
class AliasTableItem;
class DpTypeContainer;
class MapTableItem;
class DpIdentList;


#ifdef WIN32
#pragma warning ( disable: 4231 )
#endif

#if defined(LIBS_AS_DLL)
  EXTERN_DATAPOINT template class DLLEXP_DATAPOINT SimplePtrArray<DpIdentificationProSystem>;
#endif

#ifdef WIN32
#pragma warning ( default: 4231 )
#endif

/** The interface for DP name to DpIdentifier conversion. A manager must request
 *  the DpIdentification information on startup, it is not in each manager by default
 *  because a DpIdentification can be quite big.
 *
 *  The following (partially environmental) parameters are necessary for working with
 *  a DpIdentification (in this order)
 *   - the number of languages must be defined (via Resources::setNumOfLangs())
 *   - every system must be associated to a DpTypeContainer (via
 *     DpIdentification::setTypeContainer())
 *   - a default system must be set (via DpIdentification::setDefaultSystem())
 *   - names for the DP types must be defined per system (via
 *     DpIdentification::addTypeName())
 *   - names for DPs and DP elements must be defined per system and DP type(via
 *     DpIdentification::addDatapointName() and DpIdentification::addElementName())
 *
 *  @classification public use
 */
class DLLEXP_DATAPOINT DpIdentification
{
  /// To provide extended access for UnitTests
  friend class UNIT_TEST_FRIEND_CLASS;

  /// Privileged access for CNS and DBCommonNew
  friend class CNSContainer;
  friend class PersDpIdentification;

private:
  // Wird auch als default-Argument verwendet und muss deshalb am Anfang
  // der Klasse stehen
  static SystemNumType defaultSystem;

  // Temporaere private Klassen
  class DLLEXP_DATAPOINT DpIdPtrListItem : public PtrListItem
  {
    public:
      DpIdType id;
      DpIdPtrListItem(DpIdType newId = 0) : id(newId) {}
  };

public:
  // Die Schnittstelle fuer Id mit zugehoerigen LangTexten
  /// A pair of DpIdentifier and LangText name(s)
  class DLLEXP_DATAPOINT DpIdNamePair
  {
    public:
        /// The DpIdentifier
        DpIdentifier    id;

        /** The corresponding names. Note that this is a LangText for compatibility
         *  reasons, we don't have language-specific names anymore.
         */
        LangText        text;

        /** Compare method for sorting.
         *
         * @return equal to <tt>strcmp(item1Ptr->text[0], item2Ptr->text[0])</tt>
         */
        static int cmp(const void *item1Ptr, const void *item2Ptr);
  };

  /// A pair of DpIdType and LangText name(s)
  class DLLEXP_DATAPOINT TypeIdNamePair
  {
    public:
        /// The DP id
        PVSSulong        id; //has to be PVSSulong, as we store also e.g. MapTableItemsIds in it

        /** The corresponding names. Note that this is a LangText for compatibility
         *  reasons, we don't have language-specific names anymore.
         */
        LangText        text;

        /** Compare method for sorting.
         *
         * @return equal to <tt>strcmp(item1Ptr->text[0], item2Ptr->text[0])</tt>
         */
        static int cmp(const void *item1Ptr, const void *item2Ptr);
  };

public:
  /** Constructor
   * @param syncNameServer If true, we don't store all systems locally in memory but use
   *        synchronous calls to a nameserver and cache the results
   */
  DpIdentification(bool syncNameServer = false);

  /// Destructor
  ~DpIdentification();

  /** BCM output streaming operator. Depending on the property @e sendOnlyOwnSys,
   *  the DpIdentification either transfers all systems known to it or only a
   *  specific one.
   *
   *  @param [in,out] ndrStream the BCM output stream
   *  @param table the DpIdentification object to stream over BCM
   *  @return ndrStream
   *
   *  @see setSendOnlyOwnSys()
   */
  friend DLLEXP_DATAPOINT itcNdrUbSend &operator<<(itcNdrUbSend &ndrStream, const DpIdentification &table);

  /** BCM input streaming operator. All systems found in the stream replace the
   *  corresponding systems in the DpIdentification
   *
   *  @param [in,out] ndrStream the BCM input stream
   *  @param [out] table the DpIdentification object to receive from BCM
   *  @return ndrStream
   */
  friend DLLEXP_DATAPOINT itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream, DpIdentification &table);

  /** Move a system from a foreign DpIdentification to this one.
   *  The foreign system identification will be cut from foreignIdPtr
   *
   *  @param foreignIdPtr the other DpIdentification
   *  @param mergedSys    the system to move, it must exist in the other DpIdentification
   */
  DpIdentificationResult mergeSystem(DpIdentification *foreignIdPtr, SystemNumType mergedSys);

  /** Check if this is a legal character for a DP name
   *
   *  @param c the character to check, must not be 0
   *  @return PVSS_TRUE for a legal DP name character, PVSS_FALSE otherwise
   */
  static PVSSboolean isLegalChar(char c);

  /** Check if this is a legal DP name
   *  @note All illegale characters are single-byte ASCII-characters. In singlebyte encoded strings, the string
   *        can be traversed byte by byte. In multibyte encoded strings, it depends on the special encoding.
   *        Traversing byte by byte is preferred since the platform locale need not be changed. Changing the locale may
   *        heavily influence the performance (refer IM100258).
   *  @note When multibyte encoded strings are traversed bytewise (e.g. utf8), illegal multibyte sequences are NOT detected.
   *
   *  @param name the name to check, must not be 0
   *  @param traverseBytewise If true, the active locale may be singlebyte OR multibyte encoded.
   *                          At any rate, the string will be traversed byte by byte.
   *                          In case of multibyte encoding, it is assumed that single bytes of
   *                          multibyte-sequences never clash with ASCII-characters in this encoding.
   *                          If true, the active locale is assumed to be multibyte encoded,
   *                          and the string will be traversed multibyte-sequence by multibyte-sequence.
   *  @return PVSS_TRUE for a legal DP name, PVSS_FALSE otherwise
   */
  static PVSSboolean isLegalName(const char *name, bool traverseBytewise = false);

  /** Check if this is a legal multilanguage DP name
   *
   *  @param namePtrs an array of size Resources::getNumOfLangs(), must not be 0,
   *                  must not have items that are 0
   *  @return PVSS_TRUE if all names are legal DP names, PVSS_FALSE otherwise
   *
   *  @deprecated obsolete as we don't have a different DP name per language
   */
  IL_DEPRECATED("deprecated, use isLegalName(const char *name) instead")
  static PVSSboolean isLegalName(const char * const * namePtrs);

  /** Check if this is a legal DP name
   *
   *  @param name the names to check
   *  @return PVSS_TRUE if all names are legal DP names, PVSS_FALSE otherwise
   *
   *  @deprecated obsolete as we don't have a different DP name per language
   */
  IL_DEPRECATED("deprecated, use isLegalName(const char *name) instead")
  static PVSSboolean isLegalName(const LangText &name);

  /** Conversion of a DP name to the corresponding DpIdentifier.
   *  The DP name must fulfill the DP name rules (i.e. isLegalName(const char*) must
   *  return PVSS_TRUE). However, it does not need to be a fully qualified attribute
   *  name. The function tries to fill the dp identifier as full as possible.
   *
   *  @param name the name to translate, must not be 0
   *  @param [out] id the DpIdentifier to receive the id
   *  @param sys the system id, if not spezified in the dpname
   *  @return DpIdentOK on success, another value on error
   *
   *  @see DpIdentificationResult
   *  @classification public use, call
   */
  DpIdentificationResult getId(const char *name, DpIdentifier &id,
      SystemNumType sys = DpIdentification::defaultSystem ) const;
      
  /** Conversion of a DP name to the corresponding DpIdentifier.
   *  The DP name must fulfill the DP name rules (i.e. isLegalName(const char*) must
   *  return PVSS_TRUE). However, it does not need to be a fully qualified attribute
   *  name. The function tries to fill the dp identifier as full as possible.
   *
   *  @param name the name to translate, must not be 0
   *  @param [out] id the DpIdentifier to receive the id
   *  @param langIdx the requested language - obsolete
   *  @param sys the system id, if not spezified in the dpname
   *  @return DpIdentOK on success, another value on error
   *
   *  @see DpIdentificationResult
   *  @warning The LanguageIdType is obsolete and no longer used
   *  @classification public use, call
   */
  IL_DEPRECATED("deprecated, use getId(const char *, DpIdentifier &, SystemNumType) instead")
  DpIdentificationResult getId(const char *name, DpIdentifier &id,
      LanguageIdType langIdx,
      SystemNumType sys = DpIdentification::defaultSystem ) const;

  /** The DP name pattern matching, array version.
   *  This method can cope with wildcards and returns an undordered list of
   *  DpIdentifier objects fulfilling the requests. The DpIdentifier array is allocated
   *  in this method, the caller must call delete[] after using it. This method is less
   *  performant than getIdSet(const char*, DpIdentList&, DpTypeId, DpElementType,
   *  LanguageIdType, PVSSboolean, const char*), so it is recommended not to use it anymore
   *  in new code.
   *
   *  @param wildName the wildcard name to translate, must not be 0
   *  @param [out] idArr the DpIdentifier array to receive the ids
   *  @param [out] howMany a counter to receive the number of items in returned array
   *  @param typeId a further criterium to get only the dp identifiers of a specific dp type
   *  @param elType a further criterium to get only dp identifier for a specific element type
   *  @param langIdx the requested language - obsolete
   *  @param typeName specify a requested type by name (overrides typeId)
   *  @return DpIdentOK on success, another value on error
   *
   *  @see DpIdentificationResult
   *  @warning The LanguageIdType is obsolete and no longer used
   *  @classification public use, call
   */
  IL_DEPRECATED("use getIdSet() with DpIdentList out param instead")
  DpIdentificationResult getIdSet(const char *wildName, DpIdentifier * & idArr, PVSSlong &howMany,
                                  DpTypeId typeId = 0, DpElementType elType = (DpElementType)0,
                                  LanguageIdType langIdx = 0, const char *typeName = 0);

  IL_DEPRECATED("use getIdSet() with DpIdentList out param instead")
  DpIdentificationResult getIdSetIgnoreCase(const char *wildName, DpIdentifier * & idArr, PVSSlong &howMany,
                                            DpTypeId typeId = 0, DpElementType elType = (DpElementType)0,
                                            GlobalLanguageIdType langIdg = 0, const char *typeName = 0);

  private:
    DpIdentificationResult getIdSetCommon(const char *wildName, DpIdentifier * & idArr, PVSSlong &howMany,
                                          DpTypeId typeId, DpElementType elType,
                                          LanguageIdType langIdx, const char *typeName, bool ignoreCase);

  public:
  // fuer runtime info -dbg 25 angeben!
  /** The DP name pattern matching.
   *  This method can cope with wildcards and returns an undordered list of
   *  DpIdentifier objects fulfilling the requests.
   *
   *  @param wildName the wildcard name to translate, must not be 0
   *  @param [out] idList the DpIdentifier list to receive the ids
   *  @param typeId a further criterium to get only the dp identifiers of a specific dp type
   *  @param elType a further criterium to get only dp identifier for a specific element type
   *  @param clearList when PVSS_TRUE, the list is cleared before performing any operations
   *  @param typeName specify a requested type by name (overrides typeId)
   *  @return DpIdentOK on success, another value on error
   *
   *  @see DpIdentificationResult
   *  @classification public use, call
   */
  DpIdentificationResult getIdSet(const char *wildName, DpIdentList & idList,
                                  DpTypeId typeId = 0, DpElementType elType = (DpElementType)0,
                                  PVSSboolean clearList = PVSS_TRUE,
                                  const char *typeName = 0);

  /** The DP name pattern matching.
   *  This method can cope with wildcards and returns an undordered list of
   *  DpIdentifier objects fulfilling the requests.
   *
   *  @param wildName the wildcard name to translate, must not be 0
   *  @param [out] idList the DpIdentifier list to receive the ids
   *  @param typeId a further criterium to get only the dp identifiers of a specific dp type
   *  @param elType a further criterium to get only dp identifier for a specific element type
   *  @param langIdx the requested language - obsolete
   *  @param clearList when PVSS_TRUE, the list is cleared before performing any operations
   *  @param typeName specify a requested type by name (overrides typeId)
   *  @return DpIdentOK on success, another value on error
   *
   *  @see DpIdentificationResult
   *  @warning The LanguageIdType is obsolete and no longer used
   *  @classification public use, call
   */
    IL_DEPRECATED("deprecated, use getIdSet() without LanguageIdType instead")
    DpIdentificationResult getIdSet(const char *wildName, DpIdentList & idList,
                                    DpTypeId typeId, DpElementType elType,
                                    LanguageIdType langIdx, PVSSboolean clearList = PVSS_TRUE,
                                    const char *typeName = 0);

    DpIdentificationResult getIdSetIgnoreCase(const char *wildName, DpIdentList & idList,
                                              DpTypeId typeId = 0, DpElementType elType = (DpElementType)0,
                                              PVSSboolean clearList = PVSS_TRUE,
                                              const char *typeName = 0);

    IL_DEPRECATED("deprecated, use getIdSetIgnoreCase() without GlobalLanguageIdType instead")
    DpIdentificationResult getIdSetIgnoreCase(const char *wildName, DpIdentList & idList,
                                              DpTypeId typeId, DpElementType elType,
                                              GlobalLanguageIdType langIdg, PVSSboolean clearList = PVSS_TRUE,
                                              const char *typeName = 0);

  private:
    DpIdentificationResult getIdSetCommon(const char *wildName, DpIdentList & idList,
                                          DpTypeId typeId, DpElementType elType,
                                          LanguageIdType langIdx, PVSSboolean clearList,
                                          const char *typeName, bool ignoreCase);

  public:
  // fuer runtime info -dbg 25 angeben!
  /** The DP name pattern matching for a single DP only. This is an internal method for queries
   *  and should not be called from the outside. getIdSet(const char*, DpIdentList&, DpTypeId,
   *  DpElementType, LanguageIdType, PVSSboolean, const char*) provides the same functionality
   *  and can include multiple DPs in the result.
   *
   *  @param wildName the wildcard name to translate, must not be 0. The DP part must match
   *                  the name of the given DP id or the result set will be empty.
   *  @param [out] idList the DpIdentifier list to receive the ids
   *  @param typeId a further criterium to get only the dp identifiers of a specific dp type
   *  @param elType a further criterium to get only dp identifier for a specific element type
   *  @param system a param used in combination with the dpoint param
   *  @param dpoint a further criterium to get idset for only one dp, used internally for
   *                updating lists when creating / deleting new dps
   *  @param clearList when PVSS_TRUE, the list is cleared before performing any operations
   *  @return DpIdentOK on success, another value on error
   *
   *  @see DpIdentificationResult
   *  @classification public use, call
   */
  DpIdentificationResult getIdSetOneDp(const char *wildName, DpIdentList & idList,
        DpTypeId typeId = 0, DpElementType elType = (DpElementType)0, SystemNumType system = 0, DpIdType dpoint = 0,
        PVSSboolean clearList = PVSS_TRUE );

  /** The DP name pattern matching for a single DP only. This is an internal method for queries
   *  and should not be called from the outside. getIdSet(const char*, DpIdentList&, DpTypeId,
   *  DpElementType, LanguageIdType, PVSSboolean, const char*) provides the same functionality
   *  and can include multiple DPs in the result.
   *
   *  @param wildName the wildcard name to translate, must not be 0. The DP part must match
   *                  the name of the given DP id or the result set will be empty.
   *  @param [out] idList the DpIdentifier list to receive the ids
   *  @param typeId a further criterium to get only the dp identifiers of a specific dp type
   *  @param elType a further criterium to get only dp identifier for a specific element type
   *  @param system a param used in combination with the dpoint param
   *  @param dpoint a further criterium to get idset for only one dp, used internally for
   *                updating lists when creating / deleting new dps
   *  @param langIdx the requested language - obsolete
   *  @param clearList when PVSS_TRUE, the list is cleared before performing any operations
   *  @return DpIdentOK on success, another value on error
   *
   *  @see DpIdentificationResult
   *  @warning The LanguageIdType is obsolete and no longer used
   *  @classification public use, call
   */
  IL_DEPRECATED("deprecated, use getIdSetOneDp() without LanguageIdType instead")
  DpIdentificationResult getIdSetOneDp(const char *wildName, DpIdentList & idList,
        DpTypeId typeId, DpElementType elType, SystemNumType system, DpIdType dpoint,
        LanguageIdType langIdx, PVSSboolean clearList = PVSS_TRUE );

  /** The DP name pattern matching for queries.
   *
   *  @param wildName the wildcard name to translate, must not be 0. The DP part must match
   *                  the name of the given DP id or the result set will be empty.
   *  @param attrib secondary match string for additional matching capabilities
   *  @param bottomUp defines where the match shall happen
   *  @param leaf if PVSS_TRUE, only leaf elements are matched
   *  @param [out] idList the DpIdentifier list to receive the ids
   *  @param typeId a further criterium to get only the dp identifiers of a specific dp type
   *  @param elType a further criterium to get only dp identifier for a specific element type
   *  @param sys a param used in combination with the dpoint param
   *  @param dpId a further criterium to get idset for only one dp, used internally for
   *              updating lists when creating / deleting new dps
   *  @param clearList when PVSS_TRUE, the list is cleared before performing any operations
   *  @return DpIdentOK on success, another value on error
   *
   *  @see DpIdentificationResult
   *  @classification internal
   */
  DpIdentificationResult getIdSetForQuery(const char *wildName, const char *attrib, DpSymIdLevel bottomUp,
      PVSSboolean leaf, DpIdentList & idList, DpTypeId typeId = 0, DpElementType elType = (DpElementType)0,
      SystemNumType sys = 0, DpIdType dpId = 0, bool clearList = true);

  // fuer runtime info -dbg 25 angeben!
  /** The DP name pattern matching.
   *  This method can cope with wildcards and returns an undordered list of
   *  DpIdentifier objects fulfilling the requests. This method also allows
   *  braces <tt>{}</tt> in the request, which contain a list of wildcard strings.
   *  Every item in the list may contain braces itself, empty items are
   *  allowed too.
   *
   *  Examples
   *   - <tt>"DP{A,B}"</tt> matches DPA and DPB
   *   - <tt>"DP{A,}"</tt> matches DPA and DP
   *   - <tt>"DP{A,B{1,2{,x,y}}}"</tt> matches DPA, DPB1, DPB2, DPB2x and DPB2y
   *
   *  @param wildName the wildcard name to translate
   *  @param [out] idList the dp identifier list to receive the ids
   *  @param typeId a further criterium to get only the dp identifiers of a specific dp type
   *  @param elType a further criterium to get only dp identifier for a specific element type
   *  @param clearList wether idList should be cleared before or add additional entries
   *  @param typeName specify a requested type by name (overrides typeId)
   *  @return DpIdentOK on success, another value on error
   *
   *  @see DpIdentificationResult
   *  @classification public use, call
   */
  DpIdentificationResult getIdSetWithBraces(const char *wildName, DpIdentList & idList,
                                            DpTypeId typeId = 0, DpElementType elType = (DpElementType)0,
                                            PVSSboolean clearList = PVSS_TRUE,
                                            const char *typeName = 0);
  
  /** The DP name pattern matching.
   *  This method can cope with wildcards and returns an undordered list of
   *  DpIdentifier objects fulfilling the requests. This method also allows
   *  braces <tt>{}</tt> in the request, which contain a list of wildcard strings.
   *  Every item in the list may contain braces itself, empty items are
   *  allowed too.
   *
   *  Examples
   *   - <tt>"DP{A,B}"</tt> matches DPA and DPB
   *   - <tt>"DP{A,}"</tt> matches DPA and DP
   *   - <tt>"DP{A,B{1,2{,x,y}}}"</tt> matches DPA, DPB1, DPB2, DPB2x and DPB2y
   *
   *  @param wildName the wildcard name to translate
   *  @param [out] idList the dp identifier list to receive the ids
   *  @param typeId a further criterium to get only the dp identifiers of a specific dp type
   *  @param elType a further criterium to get only dp identifier for a specific element type
   *  @param langIdx the requested language - obsolete
   *  @param clearList wether idList should be cleared before or add additional entries
   *  @param typeName specify a requested type by name (overrides typeId)
   *  @return DpIdentOK on success, another value on error
   *
   *  @see DpIdentificationResult
   *  @warning The LanguageIdType is obsolete and no longer used
   *  @classification public use, call
   */
  IL_DEPRECATED("deprecated, use getIdSetWithBraces() without LanguageIdType instead")
  DpIdentificationResult getIdSetWithBraces(const char *wildName, DpIdentList & idList,
                                            DpTypeId typeId, DpElementType elType,
                                            LanguageIdType langIdx, PVSSboolean clearList = PVSS_TRUE,
                                            const char *typeName = 0);

  DpIdentificationResult getIdSetWithBracesIgnoreCase(const char *wildName, DpIdentList & idList,
                                                      DpTypeId typeId = 0, DpElementType elType = (DpElementType)0,
                                                      PVSSboolean clearList = PVSS_TRUE,
                                                      const char *typeName = 0);

  IL_DEPRECATED("deprecated, use getIdSetWithBracesIgnoreCase() without GlobalLanguageIdType instead")
  DpIdentificationResult getIdSetWithBracesIgnoreCase(const char *wildName, DpIdentList & idList,
                                                      DpTypeId typeId, DpElementType elType,
                                                      GlobalLanguageIdType langIdg, PVSSboolean clearList = PVSS_TRUE,
                                                      const char *typeName = 0);

  private:
    DpIdentificationResult getIdSetWithBracesCommon(const char *wildName, DpIdentList & idList,
                                                    DpTypeId typeId, DpElementType elType, LanguageIdType langIdx, PVSSboolean clearList,
                                                    const char *typeName, bool ignoreCase);

  public:
  /** The DP type name to DpTypeId conversion.
   *
   *  @param name the DP type name to search for
   *  @param [out] id the DpTypeId object to get the answer
   *  @param sysNum the system number where to search, default is the default system
   *  @param langIdx the requested language - obsolete
   *  @return DpIdentOK on success, another value on error
   *
   *  @see DpIdentificationResult
   *  @warning The LanguageIdType is obsolete and no longer used
   *  @classification public use, call
   */
  DpIdentificationResult getTypeId(const char *name, DpTypeId &id, SystemNumType sysNum = defaultSystem) const;

  /** The DP type name to DpTypeId conversion.
   *
   *  @param name the DP type name to search for
   *  @param [out] id the DpTypeId object to get the answer
   *  @param sysNum the system number where to search, default is the default system
   *  @param langIdx the requested language - obsolete
   *  @return DpIdentOK on success, another value on error
   *
   *  @see DpIdentificationResult
   *  @warning The LanguageIdType is obsolete and no longer used
   *  @classification public use, call
   */
  IL_DEPRECATED("deprecated, use getTypeId(const char *, DpTypeId &, SystemNumType) instead")
  DpIdentificationResult getTypeId(const char *name, DpTypeId &id, SystemNumType sysNum,
                                   LanguageIdType langIdx) const;

  /** Converts a system name to the corresponding system id.
   *
   *  @param name the requested system name, must not be 0
   *  @param [out] sysNum if found, the system number
   *  @classification public use, call
   */
  DpIdentificationResult getSystemId(const char *name, SystemNumType &sysNum) const;

  /** Converts a system name to the corresponding system id.
   *
   *  @param name the requested system name, must not be 0
   *  @param [out] sysNum if found, the system number
   *  @param langIdx the requested language - obsolete
   *
   *  @warning The LanguageIdType is obsolete and no longer used
   *  @classification public use, call
   */
  IL_DEPRECATED("deprecated, use getSystemId(const char *, SystemNumType &) instead")
  DpIdentificationResult getSystemId(const char *name, SystemNumType &sysNum, LanguageIdType langIdx) const;

  /** Converts a system id to the corresponding system name.
   *
   *  @param sysNum the requested system id
   *  @param [out] name if the system exists, the system name
   *
   *  @classification public use, call
   */
  DpIdentificationResult getSystemName(SystemNumType sysNum, CharString &name) const;

  /** Converts a system id to the corresponding system name.
   *
   *  @param sysNum the requested system id
   *  @param [out] name if the system exists, the system name. The caller must delete[] it.
   *  @param langIdx the requested language - obsolete
   *
   *  @deprecated use getSystemName(SystemNumType, CharString&) instead
   *  @warning The LanguageIdType is obsolete and no longer used
   *  @classification public use, call
   */
  IL_DEPRECATED("deprecated, use getSystemName(SystemNumType, CharString &) instead")
  DpIdentificationResult getSystemName(SystemNumType sysNum, char *&name, LanguageIdType langIdx = 0) const;

  /** Get all known system names and ids.
   *
   *  @param [out] sysIds an array of all system ids. The caller must delete[] it.
   *                      Every id corresponds with the name at the same index.
   *  @param [out] sysNames an array of all system names. The caller must delete[] it.
   *                        Every name corresponds with the id at the same index.
   *  @param [out] count the number of items in each of the arrays
   *
   *  @classification public use, call
   */
  void getAllSystems(SystemNumType *&sysIds, CharString *&sysNames, size_t &count) const;

  /** Returns the number of currently known systems
   *
   *  @return the number of currently known systems
   *
   *  @classification public use, call
   */
  size_t getNumberOfSystems() const;

  /** Gets the system name by index. Returns empty string on illegal index
   *
   *  @param index the index in the internal system array, valid in
   *               [0..getNumberOfSystems()-1]. Note that this index is neither equal
   *               nor related to the system number
   *  @return the name of the system at @e index or an empty string for an illegal index.
   *
   *  @classification public use, call
   */
  CharString getSystemName(size_t index) const;


  /** Gets the system id by index. Returns 0 on illegal index
    * 
   *  @param index the index in the internal system array, valid in
   *               [0..getNumberOfSystems()-1]. Note that this index is neither equal
   *               nor related to the system number
   *  @return the id of the system at @e index or 0 for an illegal index.
   *
   *  @classification public use, call
   */
  SystemNumType getSystemId(size_t index) const;

  /** Set the timestamp value of a system
   *  @param sysNum the requested system id 
   *  @param timestamp the timestamp value
   *  @return DpIdentOK on success, another value on error
   *
   *  @see DpIdentificationResult
   *  @classification public use, call
   */
  DpIdentificationResult setTimestamp(SystemNumType sysNum, PVSSulonglong timestamp);

  /** Get the timesetamp value of a system
   *  @param sysNum the requested system id
   *  @return the timestamp value or 0 if the system is not present
   *
   *  @classification public use, call
   */
  PVSSulonglong getTimestamp(SystemNumType sysNum) const;

  /** Get the VariableType for a specific DP element attribute.
   *
   *  @param id the attribute DpIdentifier to search for, all items must be set
   *  @param [out] varTypeRef the object to receive the answer
   *  @return DpIdentOK on success, another value on error
   *
   *  @see DpIdentificationResult
   *  @classification public use, call
   */
  DpIdentificationResult getAttributeType(const DpIdentifier &id, VariableType &varTypeRef) const;

  /** Get the VariableType for a specific DP element attribute.
   *
   *  @param name the name of the DP element attribute, must not be 0, must
   *              include DP, element, config, detail and attribute
   *  @param [out] varTypeRef the object to receive the answer
   *  @return DpIdentOK on success, another value on error
   *
   *  @see DpIdentificationResult
   *  @classification public use, call
   */
  DpIdentificationResult getAttributeType(const char *name, VariableType &varTypeRef) const;

  /** Get the VariableType for a specific DP element attribute.
   *
   *  @param name the name of the DP element attribute, must not be 0, must
   *              include DP, element, config, detail and attribute
   *  @param [out] varTypeRef the object to receive the answer
   *  @param langIdx the requested language - obsolete
   *  @return DpIdentOK on success, another value on error
   *
   *  @see DpIdentificationResult
   *  @warning The LanguageIdType is obsolete and no longer used
   *  @classification public use, call
   */
  IL_DEPRECATED("deprecated, use getAttributeType(const char *, VariableType &) instead")
  DpIdentificationResult getAttributeType(const char *name, VariableType &varTypeRef, LanguageIdType langIdx) const;

  /** Get the DpElementType for a specific DP element.
   *
   *  @param id the attribute DpIdentifier to search for, System, DP and element
   *            must be set
   *  @param [out] elTypeRef the object to receive the answer
   *  @return DpIdentOK on success, another value on error
   *
   *  @see DpIdentificationResult
   *  @classification public use, call
   */
  DpIdentificationResult getElementType(const DpIdentifier &id, DpElementType &elTypeRef) const;

  /** Get the DpElementType for a specific DP element.
   *
   *  @param name the name of the DP element attribute, must not be 0, must
   *              include DP and element
   *  @param [out] elTypeRef the object to receive the answer
   *  @return DpIdentOK on success, another value on error
   *
   *  @see DpIdentificationResult
   *  @classification public use, call
   */
  DpIdentificationResult getElementType(const char *name, DpElementType &elTypeRef) const;

  /** Get the DpElementType for a specific DP element.
   *
   *  @param name the name of the DP element attribute, must not be 0, must
   *              include DP and element
   *  @param [out] elTypeRef the object to receive the answer
   *  @param langIdx the requested language - obsolete
   *  @return DpIdentOK on success, another value on error
   *
   *  @see DpIdentificationResult
   *  @warning The LanguageIdType is obsolete and no longer used
   *  @classification public use, call
   */
  IL_DEPRECATED("deprecated, use getElementType(const char *, DpElementType &) instead")
  DpIdentificationResult getElementType(const char *name, DpElementType &elTypeRef, LanguageIdType langIdx) const;

  /** Get the DP name for a given DpIdentifier. When the system part of the
   *  DpIdentifier is empty (0), the resulting name will not contain a system.
   *
   *  @param id a (partly filled) DpIdentifier, processing will stop at the first
   *            empty part (except for the system)
   *  @param [out] name the CharString which will hold the resulting DP name
   *  @return DpIdentOK on success, another value on error
   *
   *  @see DpIdentificationResult
   *  @classification public use, call
   */
  DpIdentificationResult getName(const DpIdentifier &id, CharString &name) const;

  /** Get the DP name for a given DpIdentifier. When the system part of the
   *  DpIdentifier is empty (0), the resulting name will not contain a system.
   *
   *  @param id a (partly filled) DpIdentifier, processing will stop at the first
   *            empty part (except for the system)
   *  @param [out] name the pointer to receive the resulting DP name, the caller
   *                    must delete[] it after use
   *  @param langIdx the language to return - obsolete
   *  @return DpIdentOK on success, another value on error
   *
   *  @see DpIdentificationResult
   *  @warning The LanguageIdType is obsolete and no longer used
   *  @classification public use, call
   */
  IL_DEPRECATED("deprecated, use getName(const DpIdentifier, CharString&) instead")
  DpIdentificationResult getName(const DpIdentifier &id, char *& name, LanguageIdType langIdx = 0) const;

  /** Get the DP name for a given DpIdentifier. The resulting name will always
   *  contain a system part (for an existing DpIdentifier).
   *
   *  @param id a (partly filled) DpIdentifier, processing will stop at the first
   *            empty part. When the system part is empty, @e sys will be used instead
   *  @param [out] name the pointer to receive the resulting DP name, the caller
   *                    must delete[] it after use
   *  @param sys this system will be used if the system part of the DpIdentifier is
   *             empty, it will be ignored otherwise
   *  @return DpIdentOK on success, another value on error
   *
   *  @see DpIdentificationResult
   */
  DpIdentificationResult getName(const DpIdentifier &id, CharString &name, SystemNumType sys) const;
  
  /** Get the DP name for a given DpIdentifier. The resulting name will always
   *  contain a system part (for an existing DpIdentifier).
   *
   *  @param id a (partly filled) DpIdentifier, processing will stop at the first
   *            empty part. When the system part is empty, @e sys will be used instead
   *  @param [out] name the pointer to receive the resulting DP name, the caller
   *                    must delete[] it after use
   *  @param sys this system will be used if the system part of the DpIdentifier is
   *             empty, it will be ignored otherwise
   *  @param langIdx the language to return - obsolete
   *  @return DpIdentOK on success, another value on error
   *
   *  @see DpIdentificationResult
   *  @warning The LanguageIdType is obsolete and no longer used
   *  @classification public use, call
   */
  IL_DEPRECATED("deprecated, use getName(const DpIdentifier, CharString&, SystemNumType) instead")
  DpIdentificationResult getName(const DpIdentifier &id, char *& name, SystemNumType sys,
                                 LanguageIdType langIdx = 0) const;

  /** Get the language independent DP name for a given DpIdentifier. When the system part
   *  of the DpIdentifier is empty (0), the resulting name will not contain a system.
   *
   *  @param id a (partly filled) DpIdentifier, processing will stop at the first
   *            empty part (except for the system)
   *  @param [out] name the CharString which will hold the resulting DP name
   *  @param langIdx the language to return - obsolete
   *  @return DpIdentOK on success, another value on error
   *
   *  @see DpIdentificationResult
   *  @deprecated This method is equivalent to getName(const DpIdentifier&, CharString &)
   *              because we no longer have configs etc. in different languages
   *  @warning The LanguageIdType is obsolete and no longer used
   *  @classification public use, call
   */
  IL_DEPRECATED("deprecated, use getName(const DpIdentifier, CharString&) instead")
  DpIdentificationResult getLIName(const DpIdentifier &id, CharString &name,
                                   LanguageIdType langIdx = 0) const;

  /** Get the language independent DP name for a given DpIdentifier. The resulting name
   *  will always contain a system part (for an existing DpIdentifier).
   *
   *  @param id a (partly filled) DpIdentifier, processing will stop at the first
   *            empty part. When the system part is empty, @e sys will be used instead
   *  @param [out] name the pointer to receive the resulting DP name, the caller
   *                    must delete[] it after use
   *  @param sys this system will be used if the system part of the DpIdentifier is
   *             empty, it will be ignored otherwise
   *  @param langIdx the language to return - obsolete
   *  @return DpIdentOK on success, another value on error
   *
   *  @see DpIdentificationResult
   *  @deprecated This method is equivalent to getName(const DpIdentifier&, CharString &,
   *              SystemNumType) because we no longer have configs etc. in different languages
   *  @warning The LanguageIdType is obsolete and no longer used
   *  @classification public use, call
   */
  IL_DEPRECATED("deprecated, use getName(const DpIdentifier, CharString&, SystemNumType) instead")
  DpIdentificationResult getLIName(const DpIdentifier &id, CharString &name, SystemNumType  sys,
                                   LanguageIdType langIdx = 0) const;

  /** Get all language-specific DP names for a given DpIdentifier. When the system part
   *  of the DpIdentifier is empty (0), the resulting names will not contain a system.
   *
   *  @param id a (partly filled) DpIdentifier, processing will stop at the first
   *            empty part (except for the system)
   *  @param [out] namesRef the LangText to receive the resulting DP names
   *  @return DpIdentOK on success, another value on error
   *
   *  @see DpIdentificationResult
   *  @deprecated This method is obsolete because we no longer have configs etc. in
   *              different languages, it will be removed in the next version
   *  @classification public use, call
   */
  IL_DEPRECATED("deprecated, use getName() instead")
  DpIdentificationResult getNames(const DpIdentifier &id, LangText &namesRef) const;

  /** Get the DP name for a given DP alias.
   *
   *  @param alias an alias name known by the system, mut not be 0, must only contain
   *               the alias name itself without the starting '@'
   *  @param [out] name the pointer to receive the resulting DP name
   *  @return DpIdentOK on success, another value on error
   *
   *  @see DpIdentificationResult
   *  @classification public use, call
   */
  DpIdentificationResult getName(const char *alias, CharString& name) const;
  
  /** Get the DP name for a given DP alias.
   *
   *  @param alias an alias name known by the system, mut not be 0, must only contain
   *               the alias name itself without the starting '@'
   *  @param [out] name the pointer to receive the resulting DP name, the caller
   *                    must delete[] it after use
   *  @param langIdx the language to return - obsolete
   *  @return DpIdentOK on success, another value on error
   *
   *  @see DpIdentificationResult
   *  @warning The LanguageIdType is obsolete and no longer used
   *  @classification public use, call
   */
  IL_DEPRECATED("deprecated, use getName(const char *, CharString&) instead")
  DpIdentificationResult getName(const char *alias, char *& name, LanguageIdType langIdx = 0) const;

  /** Get the DP type name for a given DP type.
   *
   *  @param id a DP type that exists in the given system
   *  @param [out] name the CharString to receive the resulting DP type name
   *  @param sysNum the system to look in the DP type
   *  @return DpIdentOK on success, another value on error
   *
   *  @see DpIdentificationResult
   *  @classification public use, call
   */
  DpIdentificationResult getTypeName(DpTypeId id, CharString &name, SystemNumType sysNum = defaultSystem) const;

  /** Get the DP type name for a given DP type. It is recommended to use getTypeName(DpTypeId,
   *  CharString&, SystemNumType, LanguageIdType) instead, since a CharString handles memory
   *  allocation/deallocation itself.
   *
   *  @param id a DP type that exists in the given system
   *  @param [out] name the pointer to receive the resulting DP type name, the
   *                    caller must delete[] it after use
   *  @param sysNum the system to look in
   *  @param langIdx the language to return - obsolete
   *  @return DpIdentOK on success, another value on error
   *
   *  @see DpIdentificationResult
   *  @warning The LanguageIdType is obsolete and no longer used
   *  @classification public use, call
   */
  IL_DEPRECATED("deprecated, use getTypeName(DpTypeId, CharString &, SystemNumType) instead")
  DpIdentificationResult getTypeName(DpTypeId id, char *& name, SystemNumType sysNum = defaultSystem,
                                     LanguageIdType langIdx = 0) const;

  /** Get the DP type name for a given DP type.
   *
   *  @param id a DP type that exists in the given system
   *  @param [out] name the CharString to receive the resulting DP type name
   *  @param sysNum the system to look in the DP type
   *  @param langIdx the language to return - obsolete
   *  @return DpIdentOK on success, another value on error
   *
   *  @see DpIdentificationResult
   *  @warning The LanguageIdType is obsolete and no longer used
   *  @classification public use, call
   */
  IL_DEPRECATED("deprecated, use getTypeName(DpTypeId, CharString &, SystemNumType) instead")
  DpIdentificationResult getTypeName(DpTypeId id, CharString &name, SystemNumType sysNum,
                                     LanguageIdType langIdx) const;

  /** Get the multilingual DP type names for a given DP type.
  *
   *  @param id a DP type that exists in the given system
   *  @param [out] namesRef the LangText object to receive the answer
   *  @param sysNum the system to look in
   *  @return DpIdentOK on success, another value on error
   *
   *  @see DpIdentificationResult
   *  @deprecated This method is obsolete because we no longer have configs etc. in
   *              different languages, it will be removed in the next version
   *  @classification public use, call
   */
  IL_DEPRECATED("deprecated, use getTypeName(DpTypeId, CharString &, SystemNumType) instead")
  DpIdentificationResult getTypeNames(DpTypeId id, LangText &namesRef, SystemNumType sysNum = defaultSystem) const;

  /** Get the datapoint id for a given DP name.
   *
   *  @param name the datapoint name, must not be 0
   *  @param [out] dp the DpIdType object to receive the answer
   *  @param sysNum the system to look in
   *  @return DpIdentOK on success, another value on error
   *
   *  @see DpIdentificationResult
   *  @classification public use, call
   */
  DpIdentificationResult getDpId(const char *name, DpIdType &dp, SystemNumType sysNum = defaultSystem) const;

  /** Get the datapoint id for a given DP name.
   *
   *  @param name the datapoint name, must not be 0
   *  @param [out] dp the DpIdType object to receive the answer
   *  @param sysNum the system to look in
   *  @param langIdx the language for the datapoint name - obsolete
   *  @return DpIdentOK on success, another value on error
   *
   *  @see DpIdentificationResult
   *  @warning The LanguageIdType is obsolete and no longer used
   *  @classification public use, call
   */
  IL_DEPRECATED("deprecated, use getDpId(const char *, DpIdType &, SystemNumType) instead")
  DpIdentificationResult getDpId(const char *name, DpIdType &dp, SystemNumType sysNum,
      LanguageIdType langIdx) const;

  /** Get the datapoint name for a given DP id.
   *
   *  @param dp the datapoint id
   *  @param [out] name the CharString object to receive the answer
   *  @param sysNum the system to look in
   *  @return DpIdentOK on success, another value on error
   *
   *  @see DpIdentificationResult
   */
  DpIdentificationResult getDpName(DpIdType dp, CharString &name, SystemNumType sysNum = defaultSystem) const;

  /** Get the multilingual datapoint name for a given DP id, array version.
   *
   *  @param dp the datapoint id
   *  @param [out] names the LangText object to receive the answer
   *  @param sysNum the system to look in
   *
   *  @deprecated This method is obsolete because we no longer have configs etc. in
   *              different languages, it will be removed in the next version
   *  @classification public use, call
   */
  IL_DEPRECATED("deprecated, use getDpName(DpIdType, CharString&, SystemNumType) instead")
  DpIdentificationResult getDpNames(DpIdType dp, LangText &names, SystemNumType sysNum = defaultSystem) const;

  /** Get the datapoint name for a given DP id, array version
   *
   *  @param dp the datapoint id
   *  @param [out] name the pointer to receive the answer, the caller must
   *               delete[] it after use
   *  @param sysNum the system to look in
   *  @param langIdx the language to return - obsolete
   *  @return DpIdentOK on success, another value on error
   *
   *  @see DpIdentificationResult
   *  @warning The LanguageIdType is obsolete and no longer used
   *  @deprecated Use getDpName(DpIdType, CharString&, SystemNumType) instead
   *  @classification public use, call
   */
  IL_DEPRECATED("deprecated, use getDpName(DpIdType, CharString&, SystemNumType) instead")
  DpIdentificationResult getDpName(DpIdType dp, char *&name, SystemNumType sysNum = defaultSystem,
      LanguageIdType langIdx = 0) const;

  /** Get the element id for a given DP type and element name.
   *
   *  @param typeId a DP type identifier
   *  @param name the element name
   *  @param [out] elId the DpElementId object to receive the element id
   *  @param sysNum the system to look in
   *  @return DpIdentOK on success, another value on error
   *
   *  @see DpIdentificationResult
   *  @classification public use, call
   */
  DpIdentificationResult getElementId(DpTypeId typeId, const char *name, DpElementId &elId,
      SystemNumType sysNum = defaultSystem) const;

  /** Get the element id for a given DP type and element name.
   *
   *  @param typeId a DP type identifier
   *  @param name the element name
   *  @param [out] elId the DpElementId object to receive the element id
   *  @param sysNum the system to look in
   *  @param langIdx the language to return - obsolete
   *  @return DpIdentOK on success, another value on error
   *
   *  @see DpIdentificationResult
   *  @warning The LanguageIdType is obsolete and no longer used
   *  @classification public use, call
   */
  IL_DEPRECATED("deprecated, use getElementId(DpTypeId, const char*, DpElementId&, SystemNumType) instead")
  DpIdentificationResult getElementId(DpTypeId typeId, const char *name, DpElementId &elId,
      SystemNumType sysNum, LanguageIdType langIdx) const;

  /** Get the element name for a given DP type and element id.
   *
   *  @param id a dp type identifier
   *  @param elId the element to search for
   *  @param name the string to receive the answer
   *  @param sysNum the system to look in
   *  @return DpIdentOK on success, another value on error
   *
   *  @see DpIdentificationResult
   *  @classification public use, call
   */
  DpIdentificationResult getElementName(DpTypeId id, DpElementId elId, CharString& name,
                                        SystemNumType sysNum = defaultSystem) const;

  /** Get the element name for a given DP type and element id.
   *
   *  @param id a dp type identifier
   *  @param elId the element to search for
   *  @param name the char pointer to receive the answer, the caller must
   *              delete[] it after use
   *  @param sysNum the system to look in
   *  @param langIdx the language to return - obsolete
   *  @return DpIdentOK on success, another value on error
   *
   *  @see DpIdentificationResult
   *  @warning The LanguageIdType is obsolete and no longer used
   *  @classification public use, call
   */
  IL_DEPRECATED("deprecated, use getElementName(DpTypeId, DpElementId, CharString&, SystemNumType) instead")
  DpIdentificationResult getElementName(DpTypeId id, DpElementId elId, char *& name, SystemNumType sysNum = defaultSystem,
                                        LanguageIdType langIdx = 0) const;

  /** Get the multilingual element name for a given DP type and element id.
   *
   *  @param id a dp type identifier
   *  @param elId the element to search for
   *  @param namesRef the LangText object to receive the answer
   *  @param sysNum the system to look in
   *  @return DpIdentOK on success, another value on error
   *
   *  @see DpIdentificationResult
   *  @deprecated This method is obsolete because we no longer have configs etc. in
   *              different languages, it will be removed in the next version
   *  @classification public use, call
   */
  IL_DEPRECATED("deprecated, use getElementName(DpTypeId, DpElementId, CharString&, SystemNumType) instead")
  DpIdentificationResult getElementNames(DpTypeId id, DpElementId elId, LangText &namesRef, SystemNumType sysNum = defaultSystem) const;

  /** The sorted DP name pattern matching. This method can cope with wildcards
   *  and returns a list of pairs of DpIdentifier and name objects fulfilling
   *  the requests. The list is sorted by the names.
   *  Note that the names are technically sorted and not locale aware.
   *
   *  @param wildName the wildcard name to translate
   *  @param [out] pairArrRef the DpIdNamePair array to receive the pairs, the caller
   *               must delete[] it after use
   *  @param [out] howManyRef the variable to receive the number of items in the
   *                          array
   *  @param includeInternals if PVSS_TRUE, internal DPs matching @e wildName will also
   *                          be in the array
   *  @param typeFilter a further criterium to get only the dp identifiers of a specific dp type
   *  @param elType a further criterium to get only dp identifier for a specific element type
   *  @return DpIdentOK on success, another value on error
   *
   *  @see DpIdentificationResult
   *  @classification public use, call
   */
  DpIdentificationResult getSortedDpIdNames(const char *wildName, DpIdNamePair * &pairArrRef, PVSSlong &howManyRef,
                                            PVSSboolean includeInternals = PVSS_TRUE,
                                            DpTypeId typeFilter = 0, DpElementType elType = (DpElementType)0);

  /** The sorted DP name pattern matching. This method can cope with wildcards
   *  and returns a list of pairs of DpIdentifier and name objects fulfilling
   *  the requests. The list is sorted by the names.
   *  Note that the names are technically sorted and not locale aware.
   *
   *  @param wildName the wildcard name to translate
   *  @param [out] pairArrRef the DpIdNamePair array to receive the pairs, the caller
   *               must delete[] it after use
   *  @param [out] howManyRef the variable to receive the number of items in the
   *                          array
   *  @param includeInternals if PVSS_TRUE, internal DPs matching @e wildName will also
   *                          be in the array
   *  @param typeFilter a further criterium to get only the dp identifiers of a specific dp type
   *  @param elType a further criterium to get only dp identifier for a specific element type
   *  @param langIdx the requested language - obsolete
   *  @return DpIdentOK on success, another value on error
   *
   *  @see DpIdentificationResult
   *  @warning The LanguageIdType is obsolete and no longer used
   *  @classification public use, call
   */
  IL_DEPRECATED("deprecated, use getSortedDpIdNames() without LanguageIdType instead")
  DpIdentificationResult getSortedDpIdNames(const char *wildName, DpIdNamePair * &pairArrRef, PVSSlong &howManyRef,
                                            PVSSboolean includeInternals,
                                            DpTypeId typeFilter, DpElementType elType,
                                            LanguageIdType langIdx);

  DpIdentificationResult getSortedDpIdNamesIgnoreCase(const char *wildName, DpIdNamePair * &pairArrRef, PVSSlong &howManyRef,
                                                      PVSSboolean includeInternals = PVSS_TRUE,
                                                      DpTypeId typeFilter = 0, DpElementType elType = (DpElementType)0);

  IL_DEPRECATED("deprecated, use getSortedDpIdNamesIgnoreCase() without GlobalLanguageIdType instead")
  DpIdentificationResult getSortedDpIdNamesIgnoreCase(const char *wildName, DpIdNamePair * &pairArrRef, PVSSlong &howManyRef,
                                                      PVSSboolean includeInternals,
                                                      DpTypeId typeFilter, DpElementType elType,
                                                      GlobalLanguageIdType langIdg);

  private:
    DpIdentificationResult getSortedDpIdNamesCommon(const char *wildName, DpIdNamePair * &pairArrRef, PVSSlong &howManyRef,
                                                    PVSSboolean includeInternals, DpTypeId typeFilter, DpElementType elType,
                                                    LanguageIdType langIdx, bool ignoreCase);

  public:
  /** The sorted DP type name pattern matching. This method can cope with wildcards
   *  and returns a list of pairs of DpTypeId and name objects fulfilling
   *  the requests. The list is sorted by the names.
   *  Note that the names are technically sorted and not locale aware.
   *
   *  @param wildName the wildcard name to translate
   *  @param [out] pairArrRef the TypeIdNamePair array to receive the pairs, the caller
   *                          must delete[] it after use
   *  @param [out] howManyRef the variable to receive the number of items in the
   *                          array
   *  @param includeInternals if PVSS_TRUE, internal DP types matching @e wildName will also
   *                          be in the array
   *  @param sysNum the system to look in
   *  @return DpIdentOK on success, another value on error
   *
   *  @see DpIdentificationResult
   *  @classification public use, call
   */
  DpIdentificationResult getSortedTypeNames(const char *wildName, TypeIdNamePair * &pairArrRef, PVSSlong &howManyRef,
                                            PVSSboolean includeInternals = PVSS_TRUE, SystemNumType sysNum = defaultSystem);

  /** Get the DP type for a given DpIdentifier.
   *
   *  @param [in,out] idRef the requested DpIdentifier, the system and DP parts
   *                        must be set to get the DP type. Since the DP type is
   *                        included in the DpIdentifier we need only one parameter
   *  @return DpIdentOK on success, another value on error
   *
   *  @see DpIdentificationResult
   *  @classification public use, call
   */
  DpIdentificationResult fillInTypeId(DpIdentifier &idRef) const;

  /** Get all DP ids for a specific DP type.
   *
   *  @param typeId the requested DP type
   *  @param [out] idArrRef the DpIdType array to receive the DPs, the caller
   *                        must delete[] it after use
   *  @param [out] howManyRef the variable to receive the number of items in the
   *                          array
   *  @param sysNum the system to look in
   *  @return DpIdentOK on success, another value on error
   *
   *  @see DpIdentificationResult
   *  @classification public use, call
   */
  DpIdentificationResult getAllDpOfType(DpTypeId typeId, DpIdType * & idArrRef, PVSSlong &howManyRef, SystemNumType sysNum = defaultSystem);

  /** Set the default system. The system number is not checked, since the default
   *  system does not belong to a specific DpIdentification.
   *
   *  @param newSys the new default system
   *  @return always PVSS_TRUE
   *
   *  @classification public use, call
   */
  static PVSSboolean setDefaultSystem(SystemNumType newSys);

  /** Get the default system
   *
   *  @return the default system
   *
   *  @classification public use, call
   */
  static SystemNumType getDefaultSystem();

  /** Defines a system with its number and name and sets it as the default system.
   *  Used only by PersDpIdentification.
   *
   *  @param sys the system number, must not already exist
   *  @param name the system name, must be a legal name
   *
   *  @see setDefaultSystem()
   *  @classification internal
   */
  void setOwnSystem(SystemNumType sys, const char *name);

  /** Queries which system(s) shall be sent to other managers.
   *
   *  @return When non-0, the system that shall be sent to other managers.
   *          When 0, all system shall be sent.
   *
   *  @classification internal
   */
  SystemNumType getSendOnlyOwnSys() { return sendOnlyOwnSys; }

  /** Defines which system(s) shall be sent to other managers.
   *
   *  @param x When non-0, the system that shall be sent to other managers.
   *           When 0, all system shall be sent.
   *
   *  @classification internal
   */
  void setSendOnlyOwnSys(SystemNumType x) { sendOnlyOwnSys = x; }

  /** Check if the given DpIdentifier points to a leaf element.
   *
   *  @param idRef the requested DpIdentifier, the system, DP and element parts
   *               must be set to decide it that element is a leaf
   *  @return PVSS_TRUE if all necessary parts are set and the element is a
   *          leaf, PVSS_FALSE otherwise
   *
   *  @classification public use, call
   */
  PVSSboolean isLeaf(DpIdentifier &idRef);

  /** Associates a system with a DpTypeContainer. When the DpIdentification
   *  is transfered to another manager, the DpTypeContainer is not transfered
   *  with it.
   *
   *  @param typeCont the container, the pointer is not captured and must be
   *                  valid until either the DpIdentification is destroyed or
   *                  the DpTypeContainer is replaced with another one using
   *                  this method
   *  @param sysNum the system, for which an association shall be established
   *  @return DpIdentOK on success, another value on error
   *
   *  @see DpIdentificationResult
   *  @classification internal
   */
  DpIdentificationResult setTypeContainer(DpTypeContainer *typeCont, SystemNumType sysNum = defaultSystem);

  /** Gets the DpTypeContainer associated with the given system.
   *
   *  @param [out] typeContPtrRef the container pointer "as is", the caller must not
   *                              delete it as long as it is associated with this
   *                              DpIdentification
   *  @param sysNum the system, for which the associated DpTypeContainer shall
   *                be retrieved
   *  @return DpIdentOK on success, another value on error
   *
   *  @see DpIdentificationResult
   *  @classification internal
   */
  DpIdentificationResult getTypeContainer(DpTypeContainer * & typeContPtrRef, SystemNumType sysNum = defaultSystem) const;

  /** Get the CNSContainer
   *
   *  @return the CNSContainer
   *
   *  @classification public use, call
   */
  CNSContainer &getCNSContainer();

  /** Adds a name for a datapoint.
   *
   *  @param id the datapoint id
   *  @param typeId the DP type
   *  @param name the name for the datapoint, must be a legal name
   *  @param sysNum the system where the datapoint name shall be set,
   *                if the system does not exist, it is created
   *  @param nameCheck define if a multilingual name check shall be made - obsolete
   *  @return DpIdentOK on success, another value on error
   *
   *  @see DpIdentificationResult
   *  @see isLegalName(const char*)
   *  @warning The nameCheck parameter is obsolete and no longer used
   *  @classification public use, call
   */
  DpIdentificationResult addDatapointName(DpIdType id, DpTypeId typeId, const char *name, SystemNumType sysNum = defaultSystem, PVSSboolean nameCheck = PVSS_TRUE);

  /** Rename a datapoint
      @param id the datapoint id
      @param typeId the DP type
      @param name the new name, must be a legal name
      @param sysNum the system in which the dastapoint shall be renamed
      @return DpIDentOK on success, another value on error
      @classification public use, call
   */

  DpIdentificationResult renameDatapointName(DpIdType id, DpTypeId typeId, const char *name, SystemNumType sysNum = defaultSystem);

  /** Adds a name for a DP element.
   *
   *  @param typeId the DP type of the DP element
   *  @param elementId the DP element id
   *  @param name the name for the DP element, must be a legal name
   *  @param sysNum the system where the datapoint name shall be set,
   *                if the system does not exist, it is created
   *  @param nameCheck define if a multilingual name check shall be made - obsolete
   *  @return DpIdentOK on success, another value on error
   *
   *  @see DpIdentificationResult
   *  @see isLegalName(const char*)
   *  @warning The nameCheck parameter is obsolete and no longer used
   *  @classification public use, call
   */
  DpIdentificationResult addElementName(DpTypeId typeId, DpElementId elementId, const char *name, SystemNumType sysNum = defaultSystem, PVSSboolean nameCheck = PVSS_TRUE);

  /** Adds a name for a DP type.
   *
   *  @param id the DP type id
   *  @param name the name for the DP type, must be a legal name
   *  @param sysNum the system where the datapoint name shall be set,
   *                if the system does not exist, it is created
   *  @param nameCheck define if a multilingual name check shall be made - obsolete
   *  @return DpIdentOK on success, another value on error
   *
   *  @see DpIdentificationResult
   *  @see isLegalName(const char*)
   *  @warning The nameCheck parameter is obsolete and no longer used
   *  @classification public use, call
   */
  DpIdentificationResult addTypeName(DpTypeId id, const char *name, SystemNumType sysNum = defaultSystem, PVSSboolean nameCheck = PVSS_TRUE);

  /** Removes a datapoint name. This does not remove the datapoint itself.
   *
   *  @param id the datapoint
   *  @param sysNum the system that contains the datapoint
   *  @return DpIdentOK on success, another value on error
   *
   *  @see DpIdentificationResult
   *  @classification public use, call
   */
  DpIdentificationResult removeDatapointName(DpIdType id, SystemNumType sysNum = defaultSystem);

  /** Removes a DP element name. This does not remove the DP element itself.
   *
   *  @param typeId the DP type of the element
   *  @param elementId the DP element
   *  @param sysNum the system that contains the DP element
   *  @return DpIdentOK on success, another value on error
   *
   *  @see DpIdentificationResult
   *  @classification public use, call
   */
  DpIdentificationResult removeElementName(DpTypeId typeId, DpElementId elementId, SystemNumType sysNum = defaultSystem);

  /** Removes a DP type name. This does not remove the DP type itself.
   *
   *  @param id the DP type
   *  @param sysNum the system that contains the DP type
   *  @return DpIdentOK on success, another value on error
   *
   *  @see DpIdentificationResult
   *  @classification public use, call
   */
  DpIdentificationResult removeTypeName(DpTypeId id, SystemNumType sysNum = defaultSystem);

  /** Calls the callback exaxtly once for every system known to the DpIdentification.
   *
   *  @param callback a function pointer to a callback function, this function is called
   *                  with a MapTableItem where the property @e id is the system id and
   *                  the property @e name is the system name. The order in which the
   *                  systems are given to the callback function is not defined.
   *  @return PVSS_TRUE if the callback function returned PVSS_TRUE for every system,
   *          PVSS_FALSE otherwise
   *
   *  @classification public use, call
   */
  PVSSboolean visitEverySystem(PVSSboolean (*callback)(const MapTableItem &langItem));

  /** Calls the callback exaxtly once for every datapoint in the given system.
   *
   *  @param callback a function pointer to a callback function, this function is called
   *                  with a MapTableItem where the property @e id is the DP id and
   *                  the property @e name is the DP name, the DP type is given as a
   *                  separate parameter. The order in which the DPs are given to the
   *                  callback function is not defined.
   *  @param sysNum the system where every datapoint shall be visited
   *  @return PVSS_TRUE if the callback function returned PVSS_TRUE for every datapoint,
   *          PVSS_FALSE otherwise
   *
   *  @classification public use, call
   */
  PVSSboolean visitEveryDatapoint(PVSSboolean (*callback)(const MapTableItem &langItem, DpTypeId typeId), SystemNumType sysNum = defaultSystem);

  /** Calls the callback exaxtly once for every DP type in the given system.
   *
   *  @param callback a function pointer to a callback function, this function is called
   *                  with a MapTableItem where the property @e id is the DP type id and
   *                  the property @e name is the DP type name. The order in which the DP
   *                  types are given to the callback function is not defined.
   *  @param sysNum the system where every DP type shall be visited
   *  @return PVSS_TRUE if the callback function returned PVSS_TRUE for every DP type,
   *          PVSS_FALSE otherwise
   *
   *  @classification public use, call
   */
  PVSSboolean visitEveryType(PVSSboolean (*callback)(const MapTableItem &langItem), SystemNumType sysNum = defaultSystem);

  /** Calls the callback exaxtly once for every DP element of the given DP type in
   *  the given system.
   *
   *  @param callback a function pointer to a callback function, this function is called
   *                  with a MapTableItem where the property @e id is the DP element id
   *                  and the property @e name is the DP element name. The order in which
   *                  the DP elements are given to the callback function is not defined.
   *  @param typeId the DP type, for which all elements shall be visited
   *  @param sysNum the system containing the DP type
   *  @return PVSS_TRUE if the callback function returned PVSS_TRUE for every DP element,
   *          PVSS_FALSE otherwise
   *
   *  @classification public use, call
   */
  PVSSboolean visitEveryElement(PVSSboolean (*callback)(const MapTableItem &langItem), DpTypeId typeId, SystemNumType sysNum = defaultSystem);

  /** Calls the callback exaxtly once for every alias in the given system.
   *
   *  @param callback a function pointer to a callback function, this function is called
   *                  with an AliasTableItem. The order in which the aliases are given
   *                  to the callback function is not defined.
   *  @param sysNum the system where every alias shall be visited
   *  @return PVSS_TRUE if the callback function returned PVSS_TRUE for every alias,
   *          PVSS_FALSE otherwise
   *
   *  @classification public use, call
   */
  PVSSboolean visitEveryAlias(PVSSboolean (*callback)(const AliasTableItem &tItem), SystemNumType sysNum = defaultSystem);

  /** Calls the callback exaxtly once for every CNS node in the given system.
   *
   *  @param callback a function pointer to a callback function, this function is called
   *                  with a CNSTreeNode. The order in which the CNS nodes are given to
   *                  the callback function is not defined.
   *  @param sysNum the system where every CNS node shall be visited
   *  @return PVSS_TRUE if the callback function returned PVSS_TRUE for every CNS node,
   *          PVSS_FALSE otherwise
   *
   *  @classification public use, call
   */
  PVSSboolean visitEveryCNSNode(PVSSboolean (*callback)(const CNSTreeNode &cnsNode), SystemNumType sysNum = defaultSystem);

  /** Get the name of a config.
   *
   *  @param id the config id
   *  @param [out] nameRef the variable to receive the name
   *  @param sysNum the system to search for
   *  @return DpIdentOK on success, another value on error
   *
   *  @see DpIdentificationResult
   *  @deprecated use ConfigsMapper::getConfigName() instead
   *  @classification public use, call
   */
  IL_DEPRECATED("deprecated, use ConfigsMapper::getConfigName() instead")
  DpIdentificationResult getLIConfigName(DpConfigNrType id, CharString &nameRef, SystemNumType sysNum = 0 /*obsolete*/) const;

  /** Get the name of an attribute.
   *
   *  @param confType the config id where the attribute exists
   *  @param id the attribute id
   *  @param [out] nameRef the variable to receive the name
   *  @param sysNum the system to search for
   *  @return DpIdentOK on success, another value on error
   *
   *  @see DpIdentificationResult
   *  @deprecated use ConfigsMapper::getAttributeName() instead
   *  @classification public use, call
   */
  IL_DEPRECATED("deprecated, use ConfigsMapper::getAttributeName() instead")
  DpIdentificationResult getLIAttrName(DpConfigNrType confType, DpAttributeNrType id, CharString &nameRef, SystemNumType sysNum = 0/*obsolete*/) const;

  /** Get the name of a detail.
   *
   *  @param confType the config id where the detail exists
   *  @param id the detail id
   *  @param [out] nameRef the variable to receive the name
   *  @param sysNum the system to search for
   *  @return DpIdentOK on success, another value on error
   *
   *  @see DpIdentificationResult
   *  @deprecated use ConfigsMapper::getDetailName() instead
   *  @classification public use, call
   */
  IL_DEPRECATED("deprecated, use ConfigsMapper::getDetailName() instead")
  DpIdentificationResult getLIDetailName(DpConfigNrType confType, DpDetailNrType id, CharString &nameRef,
                                         SystemNumType sysNum = 0/*obsolete*/) const;

  /** Get the alias of a DP (element) by name.
   *
   *  @param dp the DP (element) name, must be a legal existing name
   *  @param [out] text the variable to receive the alias
   *  @return DpIdentOK on success, another value on error
   *
   *  @see DpIdentificationResult
   *  @classification public use, call
   */
  DpIdentificationResult getDpAlias(const char *dp, CharString &text) const;

  /** Get the alias of a DP (element) by name.
   *
   *  @param dp the DP (element) name, must be a legal existing name
   *  @param [out] alias the variable to receive the alias
   *  @param langIdx the language of the DP (element) - obsolete
   *  @return DpIdentOK on success, another value on error
   *
   *  @see DpIdentificationResult
   *  @warning The LanguageIdType is obsolete and no longer used
   *  @classification public use, call
   */
  IL_DEPRECATED("deprecated, use getDpAlias(const char *, CharString&) instead")
  DpIdentificationResult getDpAlias(const char *dp, CharString & alias, LanguageIdType langIdx) const;

  /** Get the alias of a DP (element) by id.
   *
   *  @param id the DP (element) id
   *  @param [out] text the variable to receive the alias
   *  @return DpIdentOK on success, another value on error
   *
   *  @see DpIdentificationResult
   *  @classification public use, call
   */
  DpIdentificationResult getDpAlias(const DpIdentifier &id, CharString &text) const;

  /** Get the alias of a DP (element) by id.
   *
   *  @param id the DP (element) id
   *  @param [out] alias the variable to receive the alias
   *  @param langIdx the language of the DP (element) - obsolete
   *  @return DpIdentOK on success, another value on error
   *
   *  @see DpIdentificationResult
   *  @warning The LanguageIdType is obsolete and no longer used
   *  @classification public use, call
   */
  IL_DEPRECATED("deprecated, use getDpAlias(const DpIdentifier&, CharString&) instead")
  DpIdentificationResult getDpAlias(const DpIdentifier &id, CharString & alias, LanguageIdType langIdx) const;

  /** Get the multilingual alias of a DP (element) by name.
   *
   *  @param dp the DP (element) name, must be a legal existing name
   *  @param [out] text the variable to receive the alias
   *  @param langIdx the language of the DP (element) - obsolete
   *  @return DpIdentOK on success, another value on error
   *
   *  @see DpIdentificationResult
   *  @warning The LanguageIdType is obsolete and no longer used
   *  @deprecated obsolete as we don't have a different alias per language
   *  @classification public use, call
   */
  IL_DEPRECATED("deprecated, use getDpAlias(const char*, CharString&) instead")
  DpIdentificationResult getDpAlias(const char *dp, LangText &text, LanguageIdType langIdx = 0) const;

  /** Get the multilingual alias of a DP (element) by id.
   *
   *  @param id the DP (element) id
   *  @param [out] text the variable to receive the alias
   *  @return DpIdentOK on success, another value on error
   *
   *  @see DpIdentificationResult
   *  @deprecated obsolete as we don't have a different alias per language
   *  @classification public use, call
   */
  IL_DEPRECATED("deprecated, use getDpAlias(const DpIdentifier&, CharString&) instead")
  DpIdentificationResult getDpAlias(const DpIdentifier &id, LangText &text) const;

  /** Get the comment of a DP (element) by name.
   *
   *  @param dpal the DP (element) name, must be a legal existing name
   *  @param [out] comment the variable to receive the comment
   *  @param langIdx the language, for which the comment is requested
   *  @return DpIdentOK on success, another value on error
   *
   *  @see DpIdentificationResult
   *  @classification public use, call
   */
  DpIdentificationResult getDpComment(const char *dpal, CharString & comment, LanguageIdType langIdx ) const;

  /** Get the comment of a DP (element) by name, by use of param language.
  *
  *  @param dpal the DP (element) name, must be a legal existing name
  *  @param [out] comment the variable to receive the comment
  *  @return DpIdentOK on success, another value on error
  *
  *  @see DpIdentificationResult
  *  @classification public use, call
  */
  DpIdentificationResult getDpComment(const char *dpal, CharString & comment) const;

  /** Get the comment of a DP (element) by id.
   *
   *  @param id the DP (element) id
   *  @param [out] comment the variable to receive the comment
   *  @param langIdx the language, for which the comment is requested
   *  @return DpIdentOK on success, another value on error
   *
   *  @see DpIdentificationResult
   *  @classification public use, call
   */
  DpIdentificationResult getDpComment(const DpIdentifier &id, CharString & comment, LanguageIdType langIdx ) const;

  /** Get the comment of a DP (element) by id, by use of param language.
  *
  *  @param id the DP (element) id
  *  @param [out] comment the variable to receive the comment
  *  @return DpIdentOK on success, another value on error
  *
  *  @see DpIdentificationResult
  *  @classification public use, call
  */
  DpIdentificationResult getDpComment(const DpIdentifier &id, CharString & comment) const;

  /** Get the comment of a DP (element) by name.
   *
   *  @param dpal the DP (element) name, must be a legal existing name
   *  @param langIdx the language of the DP (element) - obsolete
   *  @param [out] text the variable to receive the comment
   *  @return DpIdentOK on success, another value on error
   *
   *  @see DpIdentificationResult
   *  @warning The LanguageIdType is obsolete and no longer used
   *  @classification public use, call
   */
  IL_DEPRECATED("deprecated, use getDpComment(const char*, LangText&) instead")
  DpIdentificationResult getDpComment(const char *dpal, LangText &text, LanguageIdType langIdx) const;

  /** Get the comment of a DP (element) by name, by use of param language.
  *
  *  @param dpal the DP (element) name, must be a legal existing name
  *  @param langIdx the language of the DP (element) - obsolete
  *  @param [out] text the variable to receive the comment
  *  @return DpIdentOK on success, another value on error
  *
  *  @see DpIdentificationResult
  *  @warning The LanguageIdType is obsolete and no longer used
  *  @classification public use, call
  */
  DpIdentificationResult getDpComment(const char *dpal, LangText &text) const;

  /** Get the comment of a DP (element) by id.
   *
   *  @param id the DP (element) id
   *  @param [out] text the variable to receive the comment
   *  @return DpIdentOK on success, another value on error
   *
   *  @see DpIdentificationResult
   *  @classification public use, call
   */
  DpIdentificationResult getDpComment(const DpIdentifier &id, LangText &text) const;

  /** Set the alias of a DP (element) by name.
   *
   *  @param dp the DP (element) name, must be a legal existing name
   *  @param text the new alias value
   *  @return DpIdentOK on success, another value on error
   *
   *  @see DpIdentificationResult
   *  @classification public use, call
   */
  DpIdentificationResult setDpAlias(const char *dp, const char *text);

  /** Set the alias of a DP (element) by name.
   *
   *  @param dp the DP (element) name, must be a legal existing name
   *  @param alias the new alias value
   *  @param langIdx the language of the DP (element) - obsolete
   *  @return DpIdentOK on success, another value on error
   *
   *  @see DpIdentificationResult
   *  @warning The LanguageIdType is obsolete and no longer used
   *  @classification public use, call
   */
  IL_DEPRECATED("deprecated, use setDpAlias(const char*, const char*) instead")
  DpIdentificationResult setDpAlias(const char *dp, const char * alias, LanguageIdType langIdx);

  /** Set the alias of a DP (element) by id.
   *
   *  @param id the DP (element) id
   *  @param text the new alias value
   *  @return DpIdentOK on success, another value on error
   *
   *  @see DpIdentificationResult
   *  @classification public use, call
   */
  DpIdentificationResult setDpAlias(const DpIdentifier &id, const char *text);

  /** Set the alias of a DP (element) by id.
   *
   *  @param id the DP (element) id
   *  @param text the new alias value
   *  @param langIdx the language of the DP (element) - obsolete
   *  @return DpIdentOK on success, another value on error
   *
   *  @see DpIdentificationResult
   *  @warning The LanguageIdType is obsolete and no longer used
   *  @classification public use, call
   */
  IL_DEPRECATED("deprecated, use setDpAlias(const DpIdentifier&, const char*) instead")
  DpIdentificationResult setDpAlias(const DpIdentifier &id, const char *text, LanguageIdType langIdx);

  /** Set the multilingual alias of a DP (element) by name.
   *
   *  @param dp the DP (element) name, must be a legal existing name
   *  @param text the new multilingual alias value
   *  @param langIdx the language of the DP (element) - obsolete
   *  @return DpIdentOK on success, another value on error
   *
   *  @see DpIdentificationResult
   *  @warning The LanguageIdType is obsolete and no longer used
   *  @deprecated obsolete as we don't have a different alias per language
   *  @classification public use, call
   */
  IL_DEPRECATED("deprecated, use setDpAlias(const char*, const char*) instead")
  DpIdentificationResult setDpAlias(const char *dp, const LangText &text, LanguageIdType langIdx = 0);

  /** Set the multilingual alias of a DP (element) by id.
   *
   *  @param id the DP (element) id
   *  @param text the new multilingual alias value
   *  @return DpIdentOK on success, another value on error
   *
   *  @see DpIdentificationResult
   *  @deprecated obsolete as we don't have a different alias per language
   *  @classification public use, call
   */
  IL_DEPRECATED("deprecated, use setDpAlias(const char*, const char*) instead")
  DpIdentificationResult setDpAlias(const DpIdentifier &id, const LangText &text);

  /** Set the comment of a DP (element) by name.
   *
   *  @param dpal the DP (element) name, must be a legal existing name
   *  @param comment the new comment value for the given language
   *  @param langIdx the language of the given comment
   *  @return DpIdentOK on success, another value on error
   *
   *  @see DpIdentificationResult
   *  @classification public use, call
   */
  DpIdentificationResult setDpComment(const char *dpal, const char * comment, LanguageIdType langIdx);

  /** Set the comment of a DP (element) by name, by use of param language.
   *
   *  @param dpal the DP (element) name, must be a legal existing name
   *  @param comment the new comment value for the given language
   *  @return DpIdentOK on success, another value on error
   *
   *  @see DpIdentificationResult
   *  @classification public use, call
   */
  DpIdentificationResult setDpComment(const char *dpal, const char * comment);

  /** Set the comment of a DP (element) by id.
   *
   *  @param id the DP (element) id
   *  @param comment the new comment value for the given language
   *  @param langIdx the language of the given comment
   *  @return DpIdentOK on success, another value on error
   *
   *  @see DpIdentificationResult
   *  @classification public use, call
   */
  DpIdentificationResult setDpComment(const DpIdentifier &id, const char * comment, LanguageIdType langIdx);

  /** Set the comment of a DP (element) by id, by use of param language.
   *
   *  @param id the DP (element) id
   *  @param comment the new comment value for the given language
   *  @return DpIdentOK on success, another value on error
   *
   *  @see DpIdentificationResult
   *  @classification public use, call
   */
  DpIdentificationResult setDpComment(const DpIdentifier &id, const char * comment);

  /** Set the comment of a DP (element) by name.
   *
   *  @param dpal the DP (element) name, must be a legal existing name
   *  @param text the new comment value
   *  @param langIdx the language of the DP (element) - obsolete
   *  @return DpIdentOK on success, another value on error
   *
   *  @see DpIdentificationResult
   *  @warning The LanguageIdType is obsolete and no longer used
   *  @classification public use, call
   */
  IL_DEPRECATED("deprecated, use setDpComment(const char*, const LangText &) instead")
  DpIdentificationResult setDpComment(const char *dpal, const LangText &text, LanguageIdType langIdx);

  /** Set the comment of a DP (element) by name, by use of param language.
   *
   *  @param dpal the DP (element) name, must be a legal existing name
   *  @param text the new comment value
   *  @param langIdx the language of the DP (element) - obsolete
   *  @return DpIdentOK on success, another value on error
   *
   *  @see DpIdentificationResult
   *  @warning The LanguageIdType is obsolete and no longer used
   *  @classification public use, call
  */
  DpIdentificationResult setDpComment(const char *dpal, const LangText &text);

  /** Set the comment of a DP (element) by id.
   *
   *  @param id the DP (element) id
   *  @param text the new comment value
   *  @return DpIdentOK on success, another value on error
   *
   *  @see DpIdentificationResult
   *  @classification public use, call
   */
  DpIdentificationResult setDpComment(const DpIdentifier &id, const LangText &text);

  /// Internal use only
  DpIdentificationResult setDpAliasAndComment(const DpIdentifier &id, const LangText &alias, const LangText &comment, int idx);

  /// Internal use only
  void sortAliasTable();

  /** Delete the alias of a DP (element) by id.
   *
   *  @param id the DP (element) id
   *  @return DpIdentOK on success, another value on error
   *
   *  @see DpIdentificationResult
   *  @classification public use, call
   */
  DpIdentificationResult deleteDpAlias(const DpIdentifier &id);

  /** Delete the alias of a DP (element) by name.
   *
   *  @param dpal the DP (element) name, must be a legal existing name
   *  @return DpIdentOK on success, another value on error
   *
   *  @see DpIdentificationResult
   *  @classification public use, call
   */
  DpIdentificationResult deleteDpAlias(const char *dpal);

  /** Delete the alias of a DP (element) by name.
   *
   *  @param dpal the DP (element) name, must be a legal existing name
   *  @param langIdx the language of the DP (element) - obsolete
   *  @return DpIdentOK on success, another value on error
   *
   *  @see DpIdentificationResult
   *  @warning The LanguageIdType is obsolete and no longer used
   *  @classification public use, call
   */
  IL_DEPRECATED("deprecated, use deleteDpAlias(const char*) instead")
  DpIdentificationResult deleteDpAlias(const char *dpal, LanguageIdType langIdx);

  /** Delete the comment of a DP (element) by id.
   *
   *  @param id the DP (element) id
   *  @return DpIdentOK on success, another value on error
   *
   *  @see DpIdentificationResult
   *  @classification public use, call
   */
  DpIdentificationResult deleteDpComment(const DpIdentifier &id);

  /** Delete the comment of a DP (element) by name.
   *
   *  @param dpal the DP (element) name, must be a legal existing name
   *  @param langIdx the language of the DP (element) - obsolete
   *  @return DpIdentOK on success, another value on error
   *
   *  @see DpIdentificationResult
   *  @warning The LanguageIdType is obsolete and no longer used
   *  @classification public use, call
   */
  IL_DEPRECATED("deprecated, use deleteDpComment(const char*) instead")
  DpIdentificationResult deleteDpComment(const char *dpal, LanguageIdType langIdx);

  /** Delete the comment of a DP (element) by name, by use of param language.
   *
   *  @param dpal the DP (element) name, must be a legal existing name
   *  @return DpIdentOK on success, another value on error
   *
   *  @see DpIdentificationResult
   *  @classification public use, call
   */
  DpIdentificationResult deleteDpComment(const char *dpal);

  /** Deletes all aliases and comments of the given datapoint.
   *
   *  @param id the datapoint
   *  @param sysNum the system where the datapoint exists
   *  @return DpIdentOK on success, another value on error
   *
   *  @see DpIdentificationResult
   *  @classification public use, call
   */
  DpIdentificationResult deleteAllAlAndComm(DpIdType id, SystemNumType sysNum = defaultSystem);

  /** Get all aliases that match a given pattern together with their corresponding
   *  DPs (or DP elements).
   *
   *  @param [out] dps a DynVar of type TEXT_VAR containting all DPs (or DP elements),
   *                   whose aliases match the pattern. Each DP (element) belongs to
   *                   the alias in @e aliases at the same index.
   *  @param [out] aliases a DynVar of type TEXT_VAR (or LANGTEXT_VAR) containting all
   *                       aliases that match the pattern
   *  @param mask the pattern, can be 0, which matches all aliases
   *  @param sysNum the system to look in
   *  @return DpIdentOK on success, another value on error
   *
   *  @see DpIdentificationResult
   *  @classification public use, call
   */
  DpIdentificationResult getAllAliases(DynVar &dps, DynVar &aliases, const char *mask, SystemNumType sysNum = defaultSystem);

  /** Get all aliases that match a given pattern together with their corresponding
   *  DPs (or DP elements).
   *
   *  @param [out] dps a DynVar of type TEXT_VAR containting all DPs (or DP elements),
   *                   whose aliases match the pattern. Each DP (element) belongs to
   *                   the alias in @e aliases at the same index.
   *  @param [out] aliases a DynVar of type TEXT_VAR (or LANGTEXT_VAR) containting all
   *                       aliases that match the pattern
   *  @param mask the pattern, can be 0, which matches all aliases
   *  @param oneLang When PVSS_TRUE, only the alias of language @e langIdx is compared
   *                 to the pattern and @e aliases is a DynVar of type TEXT_VAR.
   *                 Otherwise @e aliases is a DynVar of type LANGTEXT_VAR and will
   *                 contain all aliases that match the pattern in at least one language.
   *                 Since we no longer allow multilingual aliases, this parameter should
   *                 always be PVSS_TRUE.
   *  @param langIdx The language in which the pattern shall be compared with the alias.
   *                 Only relevant if @e oneLang is PVSS_TRUE.
   *  @param sysNum the system to look in
   *  @return DpIdentOK on success, another value on error
   *
   *  @see DpIdentificationResult
   *  @warning We don't have multilungual aliases anymore, so the default values for
   *           @e oneLang and @e langIdx should not be modified
   *  @classification public use, call
   */
  IL_DEPRECATED("deprecated, use getAllAliases(DynVar&, DynVar&, const char*, SystemNumType) instead")
  DpIdentificationResult getAllAliases(DynVar &dps, DynVar &aliases, const char *mask, PVSSboolean oneLang /*= PVSS_TRUE*/,
                                       LanguageIdType langIdx = 0, SystemNumType sysNum = defaultSystem);

  /** Get all aliases together with their corresponding DPs (or DP elements).
   *
   *  @param [out] dps a DynVar of type TEXT_VAR containting all DPs (or DP elements).
   *                   Each DP (element) belongs to the alias in @e aliases at the
   *                   same index.
   *  @param [out] aliases a DynVar of type TEXT_VAR (or LANGTEXT_VAR) containting all
   *                       aliases
   *  @param sysNum the system to look in
   *  @return DpIdentOK on success, another value on error
   *
   *  @see DpIdentificationResult
   *  @classification public use, call
   */
  DpIdentificationResult getAllAliases(DynVar &dps, DynVar &aliases, SystemNumType sysNum = defaultSystem)
  { return getAllAliases(dps, aliases, 0, sysNum);}

  /** Get all aliases together with their corresponding DPs (or DP elements).
   *
   *  @param [out] dps a DynVar of type TEXT_VAR containting all DPs (or DP elements).
   *                   Each DP (element) belongs to the alias in @e aliases at the
   *                   same index.
   *  @param [out] aliases a DynVar of type TEXT_VAR (or LANGTEXT_VAR) containting all
   *                       aliases
   *  @param oneLang When PVSS_TRUE, only the alias of language @e langIdx is put into
   *                 @e aliases and @e aliases is a DynVar of type TEXT_VAR.
   *                 Otherwise @e aliases is a DynVar of type LANGTEXT_VAR and will
   *                 contain all aliases. Since we no longer allow multilingual aliases,
   *                 this parameter should always be PVSS_TRUE.
   *  @param langIdx The language in which the aliases shall be retrieved. Only relevant
   *                 if @e oneLang is PVSS_TRUE
   *  @param sysNum the system to look in
   *  @return DpIdentOK on success, another value on error
   *
   *  @see DpIdentificationResult
   *  @warning We don't have multilungual aliases anymore, so the default values for
   *           @e oneLang and @e langIdx should not be modified
   *  @classification public use, call
   */
  IL_DEPRECATED("deprecated, use getAllAliases(DynVar&, DynVar&, SystemNumType) instead")
  DpIdentificationResult getAllAliases(DynVar &dps, DynVar &aliases, PVSSboolean oneLang /*= PVSS_TRUE*/,
                                       LanguageIdType langIdx = 0, SystemNumType sysNum = defaultSystem)
  { return getAllAliases(dps, aliases, 0, sysNum);}


  /** Get all comments that match a given pattern in the active language together with their corresponding
   *  DPs (or DP elements) for the default system
   *
   *  @param [out] dps a DynVar of type TEXT_VAR containting all DPs (or DP elements),
   *                   whose comments match the pattern. Each DP (element) belongs to
   *                   the comment in @e comments at the same index.
   *  @param [out] comments a DynVar of type TEXT_VAR (or LANGTEXT_VAR) containting all
   *                       comments that match the pattern
   *  @param mask the pattern, can be 0, which matches all comments
   *  @param commentPart When PVSS_TRUE, only the first part of the comment is compared
   *                     with the pattern. Parts are separated by a single @@
   *  @param oneLang When PVSS_TRUE, only the comment of language active language is compared
   *                 to the pattern and @e comments is a DynVar of type TEXT_VAR.
   *                 Otherwise @e comments is a DynVar of type LANGTEXT_VAR and will
   *                 contain all comments that match the pattern in at least one language.
   *  @return DpIdentOK on success, another value on error
   *
   *  @see DpIdentificationResult
   *  @classification public use, call
   */
  DpIdentificationResult getAllComments(DynVar &dps, DynVar &comments, const char *mask,
                                        PVSSboolean commentPart = PVSS_FALSE, PVSSboolean oneLang = PVSS_TRUE);
  
  /** Get all comments that match a given pattern together with their corresponding
   *  DPs (or DP elements).
   *
   *  @param [out] dps a DynVar of type TEXT_VAR containting all DPs (or DP elements),
   *                   whose comments match the pattern. Each DP (element) belongs to
   *                   the comment in @e comments at the same index.
   *  @param [out] comments a DynVar of type TEXT_VAR (or LANGTEXT_VAR) containting all
   *                       comments that match the pattern
   *  @param mask the pattern, can be 0, which matches all comments
   *  @param commentPart When PVSS_TRUE, only the first part of the comment is compared
   *                     with the pattern. Parts are separated by a single @@
   *  @param oneLang When PVSS_TRUE, only the comment of language @e langIdx is compared
   *                 to the pattern and @e comments is a DynVar of type TEXT_VAR.
   *                 Otherwise @e comments is a DynVar of type LANGTEXT_VAR and will
   *                 contain all comments that match the pattern in at least one language.
   *  @param langIdx The language in which the pattern shall be compared with the comment.
   *                 Only relevant if @e oneLang is PVSS_TRUE.
   *  @param sysNum the system to look in
   *  @return DpIdentOK on success, another value on error
   *
   *  @see DpIdentificationResult
   *  @classification public use, call
   */
  DpIdentificationResult getAllComments(DynVar &dps, DynVar &comments, const char *mask,
                                        PVSSboolean commentPart /*= PVSS_FALSE*/, PVSSboolean oneLang /*= PVSS_TRUE*/,
                                        LanguageIdType langIdx /*= activeLang*/, SystemNumType sysNum = defaultSystem);

  /** Translates the DpIdentificationResult to a textual representation (english only)
   *
   *  @param code a result code
   *  @return the corresponding textual representation, will never be 0, not even
   *          for nonexistent result codes
   *  @classification public use, call
   */
  static const char *getErrorMsg(DpIdentificationResult code);

  /** Checks if a DP element exists.
   *
   *  @param id the DP element to check, the system, DP and element parts
   *            must be set
   *  @return DpIdentOK if the DP (element) exists, another value if not
   *
   *  @see DpIdentificationResult
   *  @classification public use, call
   */
  DpIdentificationResult dpeExists(const DpIdentifier &id) const;
  
  /** Checks if a DP element exists.
   *
   *  @param id the DP element to check, the system, DP and element parts
   *            must be set
   *  @return DpIdentOK if the DP (element) exists, another value if not
   *
   *  @see DpIdentificationResult
   *  @classification public use, call
   */
  IL_DEPRECATED("deprecated, use dpeExists() instead")
  DpIdentificationResult idExists(const DpIdentifier &id) const;

  /** Counts the number of datapoints in the given system.
   *
   *  @param [out] dpCnt variable that receives the number of datapoints
   *  @param sysNum the system to look in
   *  @return <tt>true</tt> if the system is known to the DpIdentification,
   *          <tt>false</tt> if not
   *
   *  @classification internal
   */
  bool CountDatapoint(unsigned long &dpCnt, SystemNumType sysNum = defaultSystem);

  /** Returns if the duplicity check is enabled.
   *
   *  @return PVSS_TRUE if the check is enabled, PVSS_FALSE if not
   *
   *  @classification internal
   */
  static PVSSboolean &getCheckDuplicity();

  /** Enables or disables the duplicity check. When creating a lot of DPs or DP
   *  elements (e.g. while BCM streaming), the duplicity check can be disabled
   *  to speed the creation up.
   *
   *  @param newCheckDuplicity PVSS_TRUE if the check shall be enabled,
   *                           PVSS_FALSE if it shall be disabled
   *
   *  @warning make sure that this check is enabled most of the time and that
   *           it is only disabled in special circumstances
   *  @classification internal
   */
  static void setCheckDuplicity(PVSSboolean newCheckDuplicity);

  /** Provides some textual status information about this DpIdentification object.
   *
   *  @param [in,out] os the open text stream where the status report shall be
   *                  written
   *  @param summary <tt>true</tt> if only a summary shall be given, <tt>false</tt>
   *                 for a detailed report
   *
   *  @classification internal
   */
  void  reportStatus(std::ostream &os, bool summary);

  /** Cleares most of the information from this DpIdentification, should only be
   *  used for loading from the DB.
   *
   *  @classification internal
   */
  void clear();

  /** Get the DpIdentificationProSystem at the given index, only relevant in
   *  combination with numberOfDpIdentifications().
   *
   *  @param _idx the index in the internal array, valid in the range
   *              [0..numberOfDpIdentifications()] <strong>only</strong>,
   *              other values induce invalid memory accesses. This index
   *              is neither equal nor related to the system number.
   *  @return a reference to the requested DpIdentificationProSystem
   *
   *  @warning make sure that the index you use is in the valid range
   *  @classification internal
   */
  DpIdentificationProSystem &getAt(DynPtrArrayIndex _idx);

  /** Get the DpIdentificationProSystem at the given index, only relevant in
   *  combination with numberOfDpIdentifications().
   *
   *  @param _idx the index in the internal array, valid in the range
   *              [0..numberOfDpIdentifications()] <strong>only</strong>,
   *              other values induce invalid memory accesses. This index
   *              is neither equal nor related to the system number.
   *  @return a const reference to the requested DpIdentificationProSystem
   *
   *  @warning make sure that the index you use is in the valid range
   *  @classification internal
   */
  const DpIdentificationProSystem &getAt(DynPtrArrayIndex _idx) const;

  /** Returns the number of systems known to this DpIdentification object
   *
   *  @return the number of systems
   */
  unsigned long numberOfDpIdentifications();

  /** Remove the DpIdentificationProSystem at the given index, only relevant in
   *  combination with numberOfDpIdentifications().
   *
   *  @param _idx the index in the internal array, valid in the range
   *              [0..numberOfDpIdentifications()]. This index is neither
   *              equal nor related to the system number.
   *  @return <tt>true</tt> if the index was in the valid range,
   *          <tt>false</tt> if not
   *
   *  @classification internal
   */
  bool remove(DynPtrArrayIndex _idx);

  /** Get a pointer to the internal datapoint identification container.
   * The Manager class which holds the DpIdentification container sets the
   * static member returnde by this function once it has created a DpIdentification container.
   * @return a pointer to the DpIdentification
   */
  static DpIdentification *getDpIdentificationPtr();

  /** Set a pointer to the internal datapoint identification container.
   * The Manager class which holds the DpIdentification container calls
   * this function once it has created a DpIdentification container.
   * @param identification the DpIdentification container of the Manager
   *
   * @internal
   */
  static void setDpIdentificationPtr(DpIdentification *identification);

  /** Cut the pointer to the internal datapoint identification container.
    @return a pointer to the datapoint identification
   */
  static DpIdentification * cutDpIdentificationPtr();

  // security plugin callbacks (cannot be caught in libManager)
  static void setSecurityPluginGetDpAliasFct(bool (*fct)(const DpIdentifier &dpId));
  static void setSecurityPluginGetIdSetFct(bool (*fct)(DpIdentList &list));

protected:

  /** The DP name pattern matching.
   *  This method can cope with wildcards and returns an undordered list of
   *  DpIdentifier objects fulfilling the requests, in contrast with getIdSet() and
   *  getIdSetWithBraces(), this method cannot cope with braces
   *
   *  @param wildName the wildcard name to translate, must not be 0
   *  @param [out] idList the DpIdentifier list to receive the ids
   *  @param typeId a further criterium to get only the dp identifiers of a specific dp type
   *  @param elType a further criterium to get only dp identifier for a specific element type
   *  @param langIdx the requested language - obsolete
   *  @param clearList when PVSS_TRUE, the list is cleared before performing any operations
   *  @param typeName specify a requested type by name (overrides typeId)
   *  @return DpIdentOK on success, another value on error
   *
   *  @see DpIdentificationResult
   *  @warning The LanguageIdType is obsolete and no longer used
   *  @classification internal
   */
  DpIdentificationResult getIdSetLoc(const char *wildName, DpIdentList & idList,
                                     DpTypeId typeId = 0, DpElementType elType = (DpElementType)0,
                                     LanguageIdType langIdx = 0,
                                     PVSSboolean clearList = PVSS_TRUE, const char *typeName = 0);

  DpIdentificationResult getIdSetLocIgnoreCase(const char *wildName, DpIdentList & idList,
                                               DpTypeId typeId = 0, DpElementType elType = (DpElementType)0,
                                               GlobalLanguageIdType langIdg = 0,
                                               PVSSboolean clearList = PVSS_TRUE, const char *typeName = 0);

private:
  DpIdentificationResult getIdSetLocCommon(const char *wildName, DpIdentList & idList,
                                           DpTypeId typeId, DpElementType elType,
                                           LanguageIdType langIdx,
                                           PVSSboolean clearList, const char *typeName, bool ignoreCase);

  DpIdentificationResult extendConfigPart(DpIdentList &mask, DpIdentList &idList, DpIdentifier &actId);

  static PVSSboolean checkDuplicity;  // masterswitch used to disable dup-check when we know we don't need it to speed up
  SystemNumType sendOnlyOwnSys;
  MapTable systemTable;

  // HACK: CNSContainer needs to be declared before systemArray,
  // so that it will be destroyed after it,
  // because it needs to be intact for the CNSTree dtor to work.
  CNSContainer cns;

  SimplePtrArray<DpIdentificationProSystem> systemArray;

  bool useSyncNameServer;

  // security plugin callbacks (cannot be caught in libManager)
  static bool (*securityPluginGetDpAliasFct)(const DpIdentifier &dpId);
  static bool (*securityPluginGetIdSetFct)(DpIdentList &list);

  DpIdentificationProSystem *getIdProSysPtr(SystemNumType sysNum);
  const DpIdentificationProSystem *getIdProSysPtr(SystemNumType sysNum) const;
  DpIdentificationProSystem * cutIdProSysPtr(SystemNumType sysNum);

  DpIdentificationResult makeIdProSys(SystemNumType sysNum);

  DpIdentification(const DpIdentification &) {} // COVINFO LINE: defensive (defined private so no one can use it)
  DpIdentification & operator=(const DpIdentification &) {return *this;} // COVINFO LINE: defensive (defined private so no one can use it)

  static DpIdentification *dpIdentificationPtr;
};

// ================================================================================
// Inline-Funktionen :
inline PVSSboolean &DpIdentification::getCheckDuplicity()
{
  return checkDuplicity;
}
inline void DpIdentification::setCheckDuplicity(PVSSboolean newCheckDuplicity)
{
  checkDuplicity = (PVSSboolean &) newCheckDuplicity;
}

//------------------------------------------------------------------------------

inline void DpIdentification::setSecurityPluginGetDpAliasFct(bool (*fct)(const DpIdentifier &dpId))
{
  securityPluginGetDpAliasFct = fct;
}

//------------------------------------------------------------------------------

inline void DpIdentification::setSecurityPluginGetIdSetFct(bool (*fct)(DpIdentList &list))
{
  securityPluginGetIdSetFct = fct;
}


#endif /* _DPIDENTIFICATION_H_ */
