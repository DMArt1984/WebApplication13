#ifndef _DrvConfigContainer_H_
#define _DrvConfigContainer_H_

// Vorwaerts-Deklaration der Eigenen Klasse
class DrvConfigContainer;

// System-Include-Files

#ifndef _HWOBJECT_H_
#include <HWObject.hxx>
#endif

#ifndef _DPMSG_H_
#include <DpMsg.hxx>
#endif

#ifndef _DPCONTAINER_H_
#include <DpContainer.hxx>
#endif

#ifndef _DPCONFIG_H_
#include <DpConfig.hxx>
#endif

#ifndef _DPPERIPHADDR_H_
#include <PeriphAddr.hxx>
#endif

#ifndef _VARIABLE_H_
#include <Variable.hxx>
#endif

#ifndef _DPCONFIGNRTYPE_H_
#include <DpConfigNrType.hxx>
#endif

// Vorwaerts-Deklarationen :
class DpMsg;
class Datapoint;
class DpConfig;
class DpIdentifier;
class DrvConfigContainer;
class DpTypeContainer;
class Variable;
class DrvTimer;

/** This class stores the configs of type PeriphAddr and is partially responsible for 
  * conversion between HW-data and PVSS2-data
  * @classification ETM internal
  */
class DrvConfigContainer : public DpContainer 
{

  friend class DrvManager;
  
public:
  /** Constructor
    */
  DrvConfigContainer();

  /** Destructor
    */
  virtual ~DrvConfigContainer();

  // Spezielle Methoden :
  /** Add DP configuration and update count of IOs
    * @param dpId dp identifier
  * @param conf a reference to a dp configuration
  * @return pointer to dp configuration
    */
  DpConfig*                addConfig(const DpIdentifier& dpId, DpConfig& conf);

  /** Add DP configuration and update count of IOs
    * @param dpId dp identifier
  * @param conf a pointer to a dp configuration
  * @return pointer to dp configuration
  */
  DpConfig*                addConfig(const DpIdentifier& dpId, DpConfig* conf);

  /// Internal use only
  DpConfig*                addConfig(const DpIdentifier& dpId, DpConfig* conf, Datapoint*& dp, DpElement*& el);

  /** Get DP configuration 
    * @param dpId dp identifier
  * @param configType  dp configuration type
  * @return a pointer to a dp configuration
  */  
  DpConfig*                getConfig(const DpIdentifier& dpId, DpConfigNrType configType) const;

  /** Remove DP configuration 
    * @param dpId dp identifier
  * @param configType  dp configuration type
  * @return TRUE if dp config was removed
  */ 
  PVSSboolean              removeConfig(const DpIdentifier& dpId, DpConfigNrType configType);

  /** Change DP configuration 
    * @param dpId dp identifier
  * @param var includes parameters for configuration change
  * @return TRUE after dp config was succesfully changed
  */ 
  PVSSboolean              changeConfig(const DpIdentifier& dpId, const Variable& var);

  /** Method executes a conversion of raw data to engineering units and casts to specified type.
    * The smoothing is also performed if it is needed.
    * @param dpId dp identifier
  * @param periphConfPtr a pointer to periphery config
  * @param dataPtr a pointer to HW object
  * @param convRes a result of type conversion
  * @param invalid result of transformation to to engineering units
  * @return pointer to variable 
  */
  virtual VariablePtr              convert2Ing(const DpIdentifier& dpId, const PeriphAddr *periphConfPtr, 
                                       HWObject* dataPtr, Variable::ConvertResult& convRes, PVSSboolean &invalid);


  /** Method executes a conversion from  engineering units to raw data and casts to specified HW type.
    * @param adrObj a refernce to HW object
  * @param dpId dp identifier
  * @param varPtr a pointer to  a variable to be converted
  * @param confPtr a pointer to periphery config
  * @param subix subindex, can be modified inside the method 
    * @param moreVals array of additional values
  * @return result of conversion
  */
  virtual Variable::ConvertResult  convert2Raw(HWObject& adrObj, const DpIdentifier& dpId, 
                                       Variable *&varPtr, PeriphAddr *confPtr, 
                                       PVSSushort subix, const RecVar &moreVals);

  /** Return count of son types
  * @param dpId dp identifier
  * @param confPtr pointer to configuration
  * @param start start subindex  
    * @param cnt count of son types
  */
  void                     getPABounds(const DpIdentifier& dpId, const PeriphAddr *confPtr, PVSSushort &start, PVSSushort &cnt);

  /** Get dp type
    * @param dpId dp identifier
  * @return dp type
    */
  const DpType*             getDpTypePtr(const DpIdentifier& dpId);
  
  /** Get number of IOs
  * @return number of current IOs
    */
  static  int  getNumberOfIOs();

  /** Get number of licenced IOs
  * @return number of allowed IOs
    */
  static  int  getNumberOfAllowedIOs();

  /** Check licence, the number of current IOs must
    * not be greater than the number of licenced IOs. 
    * Driver will shutdown after some time period
    */
  static  void checkAllowedIOs();

  /** Check licence counter or driver is allowed only for some time period
    * @param option licence option
  * @param retForDemo
  * @return count of demo starts
    */
  static  int  isDriverAllowed (const char * option, int retForDemo=1);

protected:
  /** Casts type to right DP type
    * @param dpId dp identifier
  * @param varPtr pointer to variable
  * @param convRes conversion result
  * @return pointer to variable
    */
  VariablePtr  cast2Dp(const DpIdentifier& dpId, VariablePtr &varPtr, Variable::ConvertResult& convRes);

  /** Casts type to right HW type
    * @param trafoPtr pointer to transformation
  * @param varPtr pointer to variable
  * @param convRes conversion result
  * @return pointer to variable
    */
  VariablePtr  cast2HW(Transformation *trafoPtr, VariablePtr &varPtr, Variable::ConvertResult& convRes);

private:
  /** Get datapoint and datapoint element
    * @param dpId dp identifier
  * @param dp datapoint
  * @param el DP element
  * @return 1 if type and element are found and datapoint is allocated
    */
  int          getDpAndEl(const DpIdentifier &dpId, Datapoint *&dp, DpElement *&el);

  /** Get node configuration
    * @param dpId dp identifier
    * @return pointer to config
    */
  DpConfig*    getNodeConfig(const DpIdentifier& dpId) const;

  /** Get type of node configuration
    * @param dpId dp identifier
  * @param configType type of configuration
  * @return pointer to config
    */
  DpConfig*    getNodeConfig(const DpIdentifier& dpId, DpConfigNrType configType) const;

  /** Remove configuration recursive (remove all sons of element)
    * @param dp datapoint
  * @param el dpelement
  * @param masterEl element Id
  * @param configType type of configuration
  * @return TRUE after successful remove
    */
  PVSSboolean  removeConv(Datapoint &dp, const DpElementId &el, const DpElementId &masterEl, DpConfigType configType);

  /** Remove node configuration
    * @param dpId dp identifier
  * @return TRUE if removal was successful
    */
  PVSSboolean  removeNodeConfig(const DpIdentifier& dpId);

  /** Remove node configuration
    * @param dpId dp identifier
  * @param configType type of configuration
  * @return TRUE if removal was successful
    */
  PVSSboolean  removeNodeConfig(const DpIdentifier& dpId, DpConfigNrType configType);

  /** Change node configuration after var, recursive also for sons
    * @param dpId dp identifier
    * @param masterDpId 
    * @param var data for change 
  * @return TRUE if change was successful
   */
  PVSSboolean  changeNode(const DpIdentifier& dpId, const DpIdentifier& masterDpId, const Variable& var);

  /** Checks if event manager is registered for this DP Id
    * if config is in identifier list send hotlink
    * @param dpId dp identifier
    * @param var variable
    */
  void         doHLprocessing(const DpIdentifier& dpId, const Variable& var);
  
  /** tool function. used internally.
    * @param dpId the dp identifier
    * @param configType the configType
    */
  void         incIOCount(const DpIdentifier &dpId, DpConfigNrType configType);

  /** tool function. used internally.
    * @param dpId the dp identifier
    * @param configType the configType
    */
  void         decIOCount(const DpIdentifier &dpId, DpConfigNrType configType);

  static  int  currentIOs;
  static  int  allowedIOs;
  static  DrvTimer  *demoTimer;

friend class UNIT_TEST_FRIEND_CLASS;
};

// ================================================================================
#endif /* _DrvConfigContainer_H_ */
