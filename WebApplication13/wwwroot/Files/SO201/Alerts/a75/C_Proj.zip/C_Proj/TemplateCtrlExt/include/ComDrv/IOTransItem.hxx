#ifndef _IOTRANSITEM_H_
#define _IOTRANSITEM_H_

#include <Variable.hxx>
#include <DpIdentifier.hxx>
#include <BitVec.hxx>
#include <Allocator.hxx>

// for DpIdShort
#include <HWMapDpPa.hxx>

class DpMsgDrvAnswer;

/** This class represents the information, which must be stored for processing an IO transaction.
  * @classification ETM internal
  */
class IOTransItem
{
  public:
    /** Constructor
    */ 
    IOTransItem();

    /** Sets the parameter remainingSec_. 
    * @param rs remaining second of transaction to be set
    */
    void setRemainingSec (const double rs) { remainingSec_ = rs; }
  
    /// Own allocations depending on USE_OWN_ALLOCATOR
    AllocatorDecl;

    /** Gets the parameter remainingSec_.
    * @return remainingSec parameter
    */
    double getRemainingSec () const { return remainingSec_; }

    /** Sets the running flag 
    * @param r boolean value of running flag to be set, transaction is running
    */
    void setRunning (const PVSSboolean r) {running_ = (r == PVSS_TRUE) ? 0xFF : 0x00;}

    /** Gets the running flag 
    * @return value of running_ (running flag)
    */
    PVSSboolean getRunning () const {return (running_) ? PVSS_TRUE : PVSS_FALSE;}

    /** set the answer group number for this DPID
      * @param pos the position
      */
    void setAnswerGroupPos(PVSSshort pos) { running_ = pos; }

    /** get the answer group number for this DPID
      * @return the position for the answer group
      */
    PVSSshort getAnswerGroupPosition() { return running_; }

  private:
    
    PVSSshort running_;      // running flag (or group number for write)
    double remainingSec_;    // remaining second of transaction 
};

class InTransItem : public IOTransItem
{
public:

      /** Constructor
    */
    InTransItem();

    /// Own allocations depending on USE_OWN_ALLOCATOR
    AllocatorDecl;

    /** Deletes and than sets the parameter varOld_ according to input var
    * @param var input parameter for setting
    */
    void setVarOld (VariablePtr var);

    /** Gets the varOld_ parameter
      * @return varOld_ parameter
    */
    const VariablePtr getVarOldPtr() const {return varOld_;}

    /** Sets varOld_ parameter to NULL
    * @return previous value of varOld_ before cutting
    */
    const VariablePtr cutVarOldPtr();

    /** Sets the flags for the variable object.
    * @param flags the flags to set
    */
    void setOldFlags (const BitVec &flags) { flagsOld_ = flags; }

    /** Gets the parameter flagsOld_.
    * @return flagsOld_ parameter
    */
    const BitVec & getOldFlags () const { return flagsOld_; }

private:
    VariablePtr varOld_;     // old value of object variable
    BitVec flagsOld_;        // the status flags of the object variable
};


class OutTransItem : public IOTransItem
{
public:
    /** Constructor
    */
    OutTransItem();

    /// Own allocations depending on USE_OWN_ALLOCATOR
    AllocatorDecl;

    /** Sets the actual DpIdentifier
    * @param dpId dp identifier to be set (internal patrameter)
    */
    void setDpIdentifier (const DpIdentifier &dpId) { myDp_.dpId_ = dpId.getDp(); myDp_.elId_ = dpId.getEl(); }

    /** Gets the actual DP for DpIdentifier
    * @return dp identifier dpId_
    */
    DpIdType getDp() const {return myDp_.dpId_;}

    /** Gets the actual EL for DpIdentifier
    * @return dp identifier elId_
    */
    DpElementId getEl() const {return myDp_.elId_;}


    /** Sets the answer message pointer.
    * @param ansPtr the answer message to set
    */
    void setAnswerPtr (DpMsgDrvAnswer * ansPtr) { ansPtr_ = ansPtr; }

    /** Gets the answer message pointer.
    * @return remainingSec parameter
    */
    DpMsgDrvAnswer *getAnswerPtr() const { return ansPtr_; }

    /** Compares dp identifier of my instance with dp identifier of input item.
    * Method compares only sys dp element of dp identifiers and Alert Time
    * @param tr2 item to be compared to
    * @return result of comparison
    */
    int compare (const OutTransItem * tr2) const;

    /** Compares dp identifier of my instance with dp identifier of input item.
    * Method compares only sys dp element of dp identifiers and Alert Time
    * Method also compares the answer message id
    * @param tr2 item to be compared to
    * @return result of comparison
    */
    int compare2 (const OutTransItem * tr2) const;


private:
    DpIdShort myDp_;         // short version of identifier
    AlertTime instance_;     // the alert instance time
    DpMsgDrvAnswer *ansPtr_; // the delayed write answer message
};
#endif
