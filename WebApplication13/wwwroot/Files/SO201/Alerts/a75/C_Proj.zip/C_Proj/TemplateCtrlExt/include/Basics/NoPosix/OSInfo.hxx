#ifndef _USERINFO_H_
#define _USERINFO_H_

#include <CharString.hxx>

#include <PtrListItem.hxx>
#include <PtrList.hxx>
#include <memory>
#include <forward_list>

class DynVar;
class MappingVar;

/** Class OSInfo - used for retrieving domain user and group info
*/

class DLLEXP_BASICS OSInfo
{
  public:
    
    /**GroupInfoItem - info of 1 group
    */
    class GroupInfoItem : public PtrListItem
    {
      public:
        GroupInfoItem() {}

        CharString groupName;
        CharString comment;
        CharString osGroupId;
    };


    /**UserInfoItem - info of 1 user
    */
    class UserInfoItem : public PtrListItem
    {
      public:
        UserInfoItem() : disabled(false) {}

        CharString userName;
        CharString fullName;
        CharString comment;
        CharString osUserId;
        bool       disabled;
        CharString primaryGroupId;
        CharString primaryGroupName;
    };


    /**OSGroupItem - info of 1 group - new format
    */
    struct DLLEXP_BASICS OSGroupItem
    {
      ///constructor
      OSGroupItem()
        : isLocal{ false }
      {}

      /** Converts to new MappingVar, as used in Ctrl functions */
      std::unique_ptr<MappingVar> convertToMap() const;

      CharString groupName; /// Name of the group
      CharString comment;   /// Comment for group
      CharString osGroupId; /// OS ID of the group
      bool isLocal;         /// The group is local in AD
    };

    /// Group of lists, return type of list functions
    using GroupList = std::forward_list<std::unique_ptr<OSGroupItem>>;

    /// Return type of list functions
    struct GroupListResult
    {
      ///constructor
      GroupListResult()
        : errCode(0)
      {}

      GroupList groupList;  /// The group list
      int errCode;          /// Returning error code
    };

    /// Return type of list functions
    struct GroupListPartialResult
    {
      ///constructor
      GroupListPartialResult(int reqId)
        : errCode(0)
        , groupCount(0)
        , requestId(reqId)
        , moreData(false)
      {}

      ///constructor
      GroupListPartialResult()
        : GroupListPartialResult(0)
      {}

      GroupList groupList;  /// The group list
      int errCode;          /// Returning error code
      int groupCount;       /// Estimated group count
      int requestId;        /// Generated request Id
      bool moreData;        /// Data left for query
    };

  public:
    ///constructor
    OSInfo(); 

    ///constructor
    OSInfo(const CharString &domain);

  public:
    // -------------------------------------------------------------------
    // Domain infos

    /** Get the domain name
      @param domainName returns domain name
    */
    bool getDomainName(CharString &domainName);

    /** Get the domain name as DNS domain name
      @param dnsDomainName returns domain name
      @param flatDomainName the flat domain name to convert to DNS style
    */
    bool getDNSDomainName(CharString &dnsDomainName, const CharString &flatDomainName);

    /** Get name of domain controller
     @param dcName returs domain controller
    */
    bool getDCName(CharString &dcName);

    // -------------------------------------------------------------------
    // User infos and group memberships

    /** Get list of all users
      @param returns list of users
    */
    bool getUsers(PtrList &userList);

    /** Get info about given user
      @param grName user name
      @param itemPtr returns user info data
    */
    bool getUserInfo(const CharString &usName, UserInfoItem *itemPtr);

    /** Get list of group membership for given user
      @param userName
      @param groupList return list of groups
    */
    bool getUserGroups(const char *userName, PtrList &groupList);

    /** Get list of group membership for given user as a list
      @param userName
      @param details  fill the OSId and Comment fields of the result list
      @return GroupListResult  result list
    */
    GroupListResult getUserGroupsAsList(const char* userName, bool details);

    /** Get the subset of groups the user is member of.
    This is a more performant way to get the group membership if only some groups are relevant, e.g. for authorization
      @param userName the username
      @param groupOSIDs the group ids which should be considered
      @param groupList return list of groups
    */
    bool getUserGroupsMembership(const char *userName, const DynVar &groupOSIDs, PtrList &groupList);

    // -------------------------------------------------------------------
    // Group infos

    /** Get list of all (global or universal) groups
      @param groupList list return
    */

    bool getGroups(PtrList &groupList);
    /** Get list of all groups
      @param requestId 0 for new requests, the returned requestId for the following requests
      @param useLocalGroups use local groups too (global groups are always queried)
      @param partialResult return only a part of the list (and call the function in a loop)
      @return GroupListPartialResult the result type
    */
    GroupListPartialResult getGroupsAsList(int requestId, bool useLocalGroups = true, bool partialResult = false);

    /** Get info about given group
      @param grName group name
      @param itemPtr returns group info data
    */
    bool getGroupInfo(const CharString &grName, GroupInfoItem *itemPtr);
    
    // -------------------------------------------------------------------
    // Interface to OS

    /** Get list of users for given group
      @param groupName
      @param userList returns list of users according to groupName
    */
    bool getGroupUsers(const char *groupName, PtrList &userList);

    /** Get os-specific id for given group
      @param name group name
      @param itemPtr returns sid for group
    */
    bool getGroupOSID(const CharString &name, CharString &osid);

    /** Get os-specific id for given user
      @param name user name
      @param osid returns sid for user
    */
    bool getUserOSID(const CharString &name, CharString &osid);

    /** Get group name for given os-specific id
      @param osid group name
      @param name returns group name for sid
    */
    bool getGroupName(const CharString &osid, CharString &name);

    /** Get user name for given os-specific id
      @param osid user name
      @param name returns user name for sid
    */
    bool getUserName(const CharString &osid, CharString &name);

    // -------------------------------------------------------------------
    // Utilities

    /**  Check password for given user
      @param user the username
      @param pwd the password
    */
    bool checkPassword(const CharString &user, const CharString &pwd);

    /** Get the last error
    */
    CharString getLastError(const char *fun = 0) const;

    friend class UNIT_TEST_FRIEND_CLASS;
    
#ifdef WIN32
    /// Convert SID to user/group name
    bool getSID(const CharString &name, CharString &sid);
    /// Convert user/group name to SID
    bool getName(const CharString &sid, CharString &name);
#endif

  private:
    /** Get info about given group
      @param grName group name
      @param itemPtr returns group info data
      @param local group is local group in AD
    */
    bool getGroupInfo(const CharString &grName, OSGroupItem *itemPtr, bool local);

#ifdef WIN32
    /** Get list of global AD groups
      @param blockCount number queried block in AD, -1 means all blocks
      @param wDCName domain controller
      @param totalentries returns the number of entries
      @param resumeIndex used for partial results
      @return GroupList the returning list
    */
    GroupList getGlobalGroupsAsList(
      int blockCount, wchar_t *wDCName, unsigned long &totalEntries, void *resumeIndexPtr);
    
    /** Get list of local AD groups
      @param bufferSize the size of buffer that holds the groups, MAX_PREFERRED_LENGTH means all groups
      @param wDCName domain controller
      @param totalentries returns the number of entries
      @param resumeHandle used for partial results
      @return GroupList the returning list
    */
    GroupList getLocalGroupsAsList(
      unsigned long bufferSize, wchar_t *wDCName, unsigned long &totalEntries, void *resumeHandlePtr);

    unsigned rc_;
#else
    int  rc_;
#endif

    CharString domain_; 
};

#endif
