#ifndef _LICENSESYSMSG_H_
#define _LICENSESYSMSG_H_

/*
VERANTWORTUNG: Laszlo Szakony        
BESCHREIBUNG:
*/

#include <SysMsg.hxx>

/**  The license message system class. 
 *   
 *   This system message is used to get the actual license in the PVSS system. The message is originally created as a license request.
 *   When a Manager wants to request a license it needs to do the following:
 *       - create a LicenseSysMsg
 *       - use setLicenseChallenge() to set a random challenge value
 *       - sent it to the Event Manager.
 *   The Event Manager response to this request with a LicenseSysMsg where getLicenseResponse() returns a nonempty value.
 */
class DLLEXP_MESSAGES LicenseSysMsg : public SysMsg 
{
  public:
    /// Default constructor
    LicenseSysMsg();

    /** Copy constructor
        @param newMsg an instance of the message to be copied from
     */
    LicenseSysMsg(LicenseSysMsg &newMsg);

    /// Destructor
    ~LicenseSysMsg();

    // Operatoren :

   /** BCM output streaming operator.  
    *  
    *  @param [in,out] ndrStream the BCM output stream
    *  @param sysMsg the LicenseSysMsg object to stream over BCM
    *  @return ndrStream
    *
    */
    friend DLLEXP_MESSAGES itcNdrUbSend &operator<<(itcNdrUbSend &ndrStream, const LicenseSysMsg &sysMsg);
    
   /** BCM input streaming operator. All properties found in the stream replace the
    *  corresponding properties in the LicenseSysMsg
    *
    *  @param [in,out] ndrStream the BCM input stream
    *  @param [out] sysMsg the LicenseSysMsg object to receive from BCM
    *  @return ndrStream
    */
    friend DLLEXP_MESSAGES itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream, LicenseSysMsg &sysMsg);

   /** Output streaming operator. 
    *  
    *  @param [in,out] ofStream the output stream
    *  @param sysMsg the LicenseSysMsg object to stream over BCM
    *  @return ndrStream
    *
    */
    friend DLLEXP_MESSAGES std::ostream &operator<<(std::ostream &ofStream, const LicenseSysMsg &sysMsg);
    
    
   /** Equal operator. The operator compares the messages instances.
    *  
    *  @param rVal an instance of Msg to be compared to
    *  @return int 0, if instances are equal, or not 0 otherwise
    *
    */
    virtual int operator==(const Msg &rVal) const;

    /** Equal operator. The operator compares the license system messages instances.
     *  
     *  @param rVal an instance of LicenseSysMsg to be compared to
     *  @return int 0, if instances are equal, or not 0 otherwise
     *
     */
    int operator==(const LicenseSysMsg &rVal) const;

    /** Assignment operator. The operator assigns the content of the specified system message instances.
     *  
     *  @param rVal an instance of Msg to assign from
     *  @return Msg, assigned Msg instance
     *
     */
    Msg &operator=(const Msg &rVal);

    /** Assignment operator. The operator assigns the content of the specified license system message instances.
     *  
     *  @param rVal an instance of LicenseSysMsg to assign from
     *  @return LicenseSysMsg, assigned license system message instance
     *
     */
    LicenseSysMsg &operator=(const LicenseSysMsg &rVal);

    // Spezielle Methoden :

    /** Method returns the type of the system message.
     *   @param  msgType a system message type 
     *   @return MsgType, a SYS_MSG_LICENSE type is returned for a LicenseSysMsg type, or NO_MSG otherwise
     */
    virtual MsgType isA(MsgType msgType) const;

    /** Method returns a system message type.
     *   @return MsgType, a SYS_MSG_LICENSE type is always returned
     */
    virtual MsgType isA() const;

    /** Receives from itcNdrUbReceive stream
     *   @param ist the stream, which to receive from
     */
    virtual void inNdrUb(itcNdrUbReceive &ist);

    /** Sends to itcNdrUbSend stream
     *   @param ost the stream, which to send to
     */
    virtual void outNdrUb(itcNdrUbSend &ost) const;

    /** Sends a formatted output about internal status of the instance to the specified stream.
     * (used for logging purpose)
     *  @param ofStream   output stream
     */
    virtual void outToFile(std::ostream &ofStream) const;

    /** Method creates a new LicenseSysMsg instance.
     *   @return Msg, a new LicenseSysMsg instance
     */
    virtual Msg *allocate() const;

    /** Sends a formatted output about internal status of the instance to the specified stream.
     * (used for debugging purpose)
     *  @param to   output stream
     *  @param level   debugging level
     */
    virtual void debug(std::ostream &to, int level) const;
    
    // License query

    /** Sets a new license challenge (defined as a random string) and resets the instance into license request mode.
     *  @param challenge   a license string
     */
    void  setLicenseChallenge(const CharString &challenge);

    /** Gets an actual license request challenge.
     *  @return CharString   a license request challenge. Can be empty if the message is already in response mode.
     */
    CharString getLicenseChallenge() const;
    
    /** Method converts the actual request message into the new response message. The message obtains new message id. 
     *  The license string is copied to the response buffer.
     *  @param license   a license string
     *  @return PVSSboolean   PVSS_FALSE if the mode is already set to RESPONSE, or PVSS_TRUE otherwise.
     */
    PVSSboolean  convertToResponse(const CharString &license);

    /** Gets an actual license response string.
     *  @return CharString   a license response string. Can be empty if the message is still in request mode.
     */
    CharString   getLicenseResponse() const;

  private:
    CharString   licenseData;  
};


inline  void  LicenseSysMsg::setLicenseChallenge(const CharString &challenge)
{
  sysMsgSubType = LICENSE_OPTION_REQUEST;
  licenseData = challenge;
}


inline   CharString LicenseSysMsg::getLicenseChallenge() const
{
  if (sysMsgSubType == LICENSE_OPTION_REQUEST)
    return licenseData;
  return "";
}


inline  CharString  LicenseSysMsg::getLicenseResponse() const
{
  if (sysMsgSubType == LICENSE_OPTION_RESPONSE)
    return licenseData;
  return "";
}

#endif /* _LICENSESYSMSG_H_ */
