#ifndef _UTIL_H_
#define _UTIL_H_

/*
VERANTWORTUNG: Thomas Exner
BESCHREIBUNG:  collection of goodies
*/

#include <Types.hxx>
#include <PatternMatch.hxx>

#include <TextVar.hxx>
#include <TimeVar.hxx>
#include <BitVar.hxx>
#include <DynVar.hxx>
#include <RecVar.hxx>
#include <FileSysSlim.hxx>



/** An utility collection.
    @classification ETM internal
*/
class DLLEXP_BASICS Util
{
  public:
    friend class UNIT_TEST_FRIEND_CLASS;
    /** Checks if the given number matches the pattern.
        The function always returns false if the pattern cannot be evaluated.
        This happens if:
          * a number in the pattern has more than 32 digits (or '-'/'+' and 31 digits)
          * after the '-' or '+' is no digit (except the '-' after a digit (range))
        @param pattern Pattern to match. It is a string with numeric intervals
        and/or concrete numbers, delimited by a comma, for example "1-5,8,10,15-20".
        @param number Matched number.
        @return PVSS_TRUE, if the number is listed in the pattern string or belongs
        to an interval specified in the pattern string or false if not,
        or the pattern cannot be evaluated.
    */
    IL_DEPRECATED("deprecated, use PatternMatch instead")
    static PVSSboolean numberMatch(const char *pattern, PVSSlonglong number) { return PatternMatch::numberMatch(pattern, number) ? PVSS_TRUE : PVSS_FALSE; }

    /** Checks if Bit32 matches pattern from right to left.
        @param pattern can contain '1' and '0' for positions that should match exactly
               or other characters like 'x' to ignore that position in Bit32.
               If pattern is shorter than 32 characters only the positions available are relevant for the matching.
        @param var Bit32 to check.
        @return PVSS_TRUE, if Bit32 matches pattern.
    */
    IL_DEPRECATED("deprecated, use PatternMatch instead")
    static PVSSboolean bit32Match(const char *pattern, const Bit32 &var) { return PatternMatch::bit32Match(pattern, var) ? PVSS_TRUE : PVSS_FALSE; }

    /** checks If Bit64 matches pattern from right to left.
        @param pattern Pattern can contain '1' and '0' for positions that should match exactly
               or other characters like 'x' to ignore that position in Bit64.
               If pattern is shorter than 64 characters only the positions available are relevant for matching.
        @param var Bit64 to check.
        @return PVSS_TRUE, if Bit64 matches pattern
    */
    IL_DEPRECATED("deprecated, use PatternMatch instead")
    static PVSSboolean bit64Match(const char *pattern, const Bit64 &var) { return PatternMatch::bit64Match(pattern, var) ? PVSS_TRUE : PVSS_FALSE; }

    /** Pattern matching. Same as above but the parameters are of type const char*.
        @param pattern Pattern to match.
        @param dpName String which will be compared agains a pattern.
        @return PVSS_TRUE if the string matches the pattern.
    */
    IL_DEPRECATED("deprecated, use PatternMatch instead")
    static PVSSboolean dpMatch(const char *pattern, const char *dpName) { return PatternMatch::dpMatch(pattern, dpName) ? PVSS_TRUE : PVSS_FALSE; }

    /** Pattern matching. Handles * and ? characters. This method calls fnmatch
        (like fileNameMatch), but the slash character is not handled specifically.

        @note Be aware that this function uses a very inconsistent escaping behaviour
              in the pattern string. Before the first * character, escaping is disabled,
              and after it, escaping is enabled. In between '[' and ']', escaping
              is disabled.

        @param pattern Pattern to match.
        @param string String which will be compared agains a pattern.
        @return PVSS_TRUE if the string matches the pattern.
    */
    IL_DEPRECATED("deprecated, use PatternMatch instead")
    static PVSSboolean patternMatch(const char *pattern, const char *string) { return PatternMatch::patternMatch(pattern, string) ? PVSS_TRUE : PVSS_FALSE; }

    /** Almost the same as ::patternMatch above, but without case sensitivity
    */
    IL_DEPRECATED("deprecated, use PatternMatch instead")
    static PVSSboolean patternMatchCaseInsensitive(const char *pattern, const char *string) { return PatternMatch::patternMatchCaseInsensitive(pattern, string) ? PVSS_TRUE : PVSS_FALSE; };

    /** Pattern matching. This method calls fnmatch (like patternMatch()), but the
        slash characters are handled specifically, as if they represent a file name.

        @note This function will only recognize the platform specific path separator,
              other path separators will be matched like any other character.

        @note Be aware that this function uses a very inconsistent escaping behaviour
              in the pattern string. Before the first * character, escaping is disabled,
              and after it, escaping is enabled. In between '[' and ']', escaping
              is disabled.

        @param pattern Pattern to match.
        @param string String which will be compared agains a pattern.
        @return PVSS_TRUE if the string matches the pattern.
    */
    IL_DEPRECATED("deprecated, use PatternMatch instead")
    static PVSSboolean fileNameMatch(const char *pattern, const char *string) { return PatternMatch::fileNameMatch(pattern, string) ? PVSS_TRUE : PVSS_FALSE; }

  public:

    /** Rename or move a file (even across filesystems).
        @see FileSysSlim::moveFile()
        @param from Path to file which will be moved.
        @param to Destination directory or a new file name.
        @return PVSS_TRUE if successful, PVSS_FALSE otherwise.
        */
    IL_DEPRECATED("deprecated, use FileSysSlim::moveFile(const char *, const char *) instead")
    static PVSSboolean moveFile(const char *from, const char *to);

    /** Copy a file, optionally preserving original time.
        @see FileSysSlim::copyFile()
        @param from Path to file being copied.
        @param to Destination directory.
        @param preserve PVSSboolean value specifying whether the original time
        should be preserved.
        @param makeDir PVSSboolean value specifying whether the destination directory
        should be created if it doesn't exist.
        */
    IL_DEPRECATED("deprecated, use FileSysSlim::copyFile(const char *, const char *, bool, bool) instead. Attention: parameters preserve and makeDir have to be provided to ensure same behaviour")
    static PVSSboolean copyFile(const char *from, const char *to,
                                PVSSboolean preserve = PVSS_FALSE, PVSSboolean makeDir = PVSS_FALSE);

    /** Copy all files in the directory, optionally at least as young as the given time.
        Does not recurse subdirectories.
        @param dirFrom Source directory.
        @param dirTo Destination directory.
        @param preserve Preserving the original time.
        @param fromTime Copy files at least as young as fromTime.
        @param makeDir Specify whether the destination directory should be created.
        @return PVSS_TRUE if successful.
    */
    static PVSSboolean copyAllFiles(const char *dirFrom, const char *dirTo,
                                PVSSboolean preserve = PVSS_FALSE, const TimeVar &fromTime = TimeVar::NullTimeVar,
                                PVSSboolean makeDir = PVSS_FALSE);

    /** copyAllFiles with directory recursion. Missing directories will be created.
        @param dirFrom Source directory.
        @param dirTo Destination directory.
        @param preserve Preserving the original time.
        @param fromTime Copy files at least as young as fromTime.
        @return PVSS_TRUE if successful.
    */
    static PVSSboolean copyAllFilesRecursive(const char *dirFrom, const char *dirTo,
                                PVSSboolean preserve = PVSS_FALSE, const TimeVar &fromTime = TimeVar::NullTimeVar);

    /** Remove directory including all files inside (but do not remove subdirectories).
        @see FileSysSlim::removeDir().
        @param dirname Directory to be removed
        @param recursive PVSS_TRUE if the files in subdirectories should also be removed.
        @return PVSS_TRUE if successful.
    */
    IL_DEPRECATED("deprecated, use FileSysSlim::removeDir(const char *, bool) instead. Attention: recursive parameter has to be provided to ensure same behaviour")
    static PVSSboolean removeDir(const char *dirname, PVSSboolean recursive = PVSS_FALSE);

    /** Make directory including all parent directories when necessary
        @see FileSysSlim::makePath()
        @param directory Directory to create.
        @param mode Access mode.
        @return PVSS_TRUE if successful.
    */
    IL_DEPRECATED("deprecated, use FileSysSlim::makePath() instead")
    static PVSSboolean makeDir(const char *directory, mode_t mode);

    /** Compare the content of the two files.
       @param fname1 Path to the first file.
       @param fName2 Path to the second file.
       @param offset1 Offset in the first file where the comparison starts.
       @param offset2 Offset in the second file where the comparison starts.
       @param length if 0, the files will be compared upto the end of the files,
        otherwise only length bytes will be compared.
       @param textMode if PVSS_TRUE, any "\r\n" combination in one file
        or only "\n" or only "\r" matches to any "\r\n" or "\r" or \"n"
        combination in the other file. (NOT implemented yet).
       @return 0, if the two files are the same, <0, if fname1 < fname2 or
        >0, if fname1 > fname2.
    */
    static int compareFile(const char *fname1, const char *fName2,
                  unsigned long offset1=0L, unsigned long offset2=0L,
                  unsigned long length=0L,
                  PVSSboolean textMode = PVSS_FALSE);


    /** Get all files younger than certain time from several directories at once.
        @param searchPathes List of directories to search.
        @param fromTime Only files younger than this time will be returned.
        @param fileList List of found files.
        @return PVSS_TRUE if successful.
    */
    static PVSSboolean getAllFilesYounger( const DynVar &searchPathes, const TimeVar &fromTime,  DynVar &fileList);

    /// structure specifying which files to look for
    /// @see getFileList.
    struct  FileListOptions
    {
      /// constructor
      FileListOptions() : excludeDirs(TEXT_VAR), includeFiles(TEXT_VAR), fromTime(0, 0), recurseDir(PVSS_TRUE) {};

      /// list of directories which should be excluded during the search.
      DynVar   excludeDirs;

      /// list of files which should be included. An empty list means "include all".
      DynVar   includeFiles;

      /// only files younger than fromTime will be considered.
      TimeVar  fromTime;

      /// specify whether recursive search should be used.
      BitVar   recurseDir;

      /// if true, all files will be returned when one is younger than fromTime.
      BitVar   allIfOneYounger;

      /// Initialize this form RecVar.
      /// @param var RecVar used to initialize this.
      void  fromRecVar(const RecVar &var);

      /// Write this to RecVar variable.
      /// @param var RecVar to write this to.
      void  toRecVar(RecVar &var) const;
    };

    /** Get all files from specified directory based on the FileListOptions.
        @param searchPath Directory to search.
        @param options Structure specifying which files will be omited.
        @param fileList List of returned files.
        @return PVSS_TRUE if successful.
    */
    static PVSSboolean getFileList(const TextVar &searchPath, const Util::FileListOptions &options, DynVar &fileList);

  protected:

  private:
    /// private constructor (so that nobody can construct the Util object)
    Util() {}

    /// Convert directory path to the OS format, ending with the correct separator
    static CharString cleanDirectoryName(CharString dirName);
};


inline void Util::FileListOptions::fromRecVar(const RecVar &var)
{
  if (var.getAt(0))
    excludeDirs = *var.getAt(0);

  if (var.getAt(1))
    fromTime = *var.getAt(1);

  if (var.getAt(2))
    recurseDir = *var.getAt(2);

  if (var.getAt(3))
    allIfOneYounger = *var.getAt(3);

  if (var.getAt(4))
    includeFiles = *var.getAt(4);
}


inline void Util::FileListOptions::toRecVar(RecVar &var) const
{
  var.clear();
  var.append(excludeDirs);
  var.append(fromTime);
  var.append(recurseDir);
  var.append(allIfOneYounger);
  var.append(includeFiles);
}

#endif /* _UTIL_H_ */
