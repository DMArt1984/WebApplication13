#ifndef _DYNVAR_H_
#define _DYNVAR_H_

#ifndef _SIMPLEPTRARRAY_H_
  #include <SimplePtrArray.hxx>
#endif

#ifndef _VARIABLE_H_
#include <Variable.hxx>
#endif

#ifndef _CHARSTRING_H_
#include <CharString.hxx>
#endif
 
// ========== DynVar ============================================================

/** Variable class holding an array of values of identical type
    @n The type of the DynVar is set when the first element is added to the list. <br>
    After this only variables of the same type can be added to the list, thus guaranting
    the type consitence inside the DynVar.
    @n By default this array is not sorted and may contain duplicates, but tool functions
    to sort it and / or to remove duplicates. 
  */
//author Johannes Ertl, Martin Koller
class DLLEXP_BASICS DynVar : public Variable
{
  friend class UNIT_TEST_FRIEND_CLASS;

  public:
    /** values for the sort order parameter in sort and dynSort
      */
    enum SortOrder {SORT_ASCENDING, SORT_DESCENDING};

  public:
    /** default constructor
        @param varType the type of DynVar
        @n The default type is NOTYPE_VAR, that means not set.
      */
    DynVar(VariableType varType = NOTYPE_VAR) 
        : type(varType), lastAccessed((unsigned int) -1), isSorted(0), isAscending(1) {}
    
    /** copy constructor, perform deep copy
        @param var the DynVar, which shall be copied from
      */
    DynVar(const DynVar & var) 
        : Variable(var), type(NOTYPE_VAR), isSorted(0), isAscending(1) {*this = var;}

    /** destructor
      */
    ~DynVar() {}

    /** allocator deallocator class
      */
    AllocatorDecl;

    /** operator []
        @n Get the Variable at a specific position, starting with 1.
        @param index the position index, the first element has the index 1
        @return the pointer to the stored variable or 0 if there is nothing valid
        @classification public use, call
    */
    IL_DEPRECATED("deprecated, use 0-based getAt() instead")
    Variable *operator[](DynPtrArrayIndex index) const;

    /** operator << for itcNdrUbSend stream
        @param ndrStream the stream, which to send to
        @param array the DynVar
      */
    friend DLLEXP_BASICS itcNdrUbSend &operator<<(itcNdrUbSend &ndrStream, const DynVar &array);

    /** operator >> for itcNdrUbReceive stream
        @param ndrStream the stream, which to receive from
        @param array the DynVar
      */
    friend DLLEXP_BASICS itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream, DynVar &array);

    /** comparison operator ==
        @param rVal the Variable to compare with
        @return 0 if not equal else 1
      */
    virtual int operator==(const Variable &rVal) const ;

    /** assignment operator used for type conversion
        @param rVal the Variable to convert
        @return the resulting Variable
      */
    virtual Variable &operator=(const Variable &rVal);

    /** assignment operator for DynVar
        @param rVal the DynVar to assign
        @return the resulting DynVar
      */
    virtual DynVar &operator= (const DynVar &rVal) { operator=((const Variable&)rVal); return *this; }

    /** append a new Variable to the list
        @n Only variables with matching type are appended.
        @param newVar the Variable to append, the Variable is cloned
        @return PVSS_TRUE on success else PVSS_FALSE if type does not match or an error occured.
        @classification public use, call
    */
    PVSSboolean append(const Variable &newVar);

    /** merge a DynVar to the list
        @n Only if both DynVar are of matching type the elements of the 
        second DynVar are appended to this one. 
        @param newVar the DynVar to merge, deep copy is performed
        @return PVSS_TRUE on success else PVSS_FALSE if type does not match or any other error occured.
        @classification public use, call
    */
    PVSSboolean merge(const DynVar &newVar);

    /** insert a new Variable to the list at the first position
        @n Only if both DynVar are of matching type the elements of the 
        second DynVar are inserted into this one. 
        @param newVar the Variable to insert, the Variable is cloned
        @return PVSS_TRUE on success else PVSS_FALSE if type does not fit or other error
        @classification public use, call
    */
    PVSSboolean insertAsFirst(const Variable &newVar);

    /** insert a new Variable to the list at a specific location
        @n Only if both DynVar are of matching type the elements of the 
        second DynVar are inserted into this one. 
        @param idx the location for the variable, starting with 0
        NOTE: if the given index is bigger than the array length, an append is performed.
        @param newVar the Variable to insert, the Variable is cloned
        @return PVSS_TRUE on success else PVSS_FALSE if type does not match or any other error occured.
        @classification public use, call
    */
    PVSSboolean insertAt(const DynPtrArrayIndex idx, const Variable &newVar);

    /** append a new Variable to the list
        @n Only variables with matching type are appended.
        @param newVarPtr the VariablePtr to capture by the list
        @return PVSS_TRUE on success else PVSS_FALSE if type does not match or an error occured.
        @classification public use, call
    */
    PVSSboolean append(VariablePtr newVarPtr);

    /** insert a new Variable to the list at the first position
        @n Only if both DynVar are of matching type the elements of the 
        second DynVar are inserted into this one. 
        @param newVarPtr the VariablePtr to capture by the list
        @return PVSS_TRUE on success else PVSS_FALSE if type does not fit or other error
        @classification public use, call
    */
    PVSSboolean insertAsFirst(VariablePtr newVarPtr);

    /** insert a new Variable to the list at a specific location
        @n Only if both DynVar are of matching type the elements of the 
        second DynVar are inserted into this one. 
        @param idx the location for the variable, starting with 0
        @param newVarPtr the VariablePtr to capture by the list
        @return PVSS_TRUE on success else PVSS_FALSE if type does not match or any other error occured.
        @classification public use, call
    */
    PVSSboolean insertAt(DynPtrArrayIndex idx, VariablePtr newVarPtr);

    /** set a new Variable at the specified position
        the ptr in the list is replaced and not deleted!
        @n The variable type must match.
        @param idx the location for the variable, starting with 0
        @param newVarPtr the VariablePtr to capture by the list
        @return PVSS_TRUE on success else PVSS_FALSE if the type does not fit or other error
    */
    PVSSboolean setAt(DynPtrArrayIndex idx, VariablePtr newVarPtr);    

    /** insert a new Variable to the list at a location according to sorting.
        Note that LangTextVar texts are technically sorted and not locale aware.
        @n Duplicate items are allowed.
        @param newVarPtr the VariablePtr to capture by the list
        @return PVSS_TRUE on success else PVSS_FALSE if the type does not fit or other error
      */
    PVSSboolean insertSorted(VariablePtr newVarPtr);

    /** insert a new Variable to the list at a location according to sorting
        Note that LangTextVar texts are technically sorted and not locale aware.
        @n Duplicate items are allowed.
        @param newVar the Variable to insert, the Variable is cloned
        @return PVSS_TRUE on success else PVSS_FALSE if the type does not fit or other error
      */
    PVSSboolean insertSorted(const Variable &newVar);

    /** Remove a Variable from the list at a specific location starting with 1 and delete it
        @param index The location for the variable, starting with 1
        @return PVSS_TRUE on success else PVSS_FALSE if variable does not exist or other error
        @classification public use, call
    */
    IL_DEPRECATED("deprecated, use 0-based removeAt() instead")
    PVSSboolean remove(DynPtrArrayIndex index);

    /** Remove a Variable from the list at a specific location starting with 0 and delete it
    @param index The location for the variable, starting with 0
    @return PVSS_TRUE on success else PVSS_FALSE if variable does not exist or other error
    @classification public use, call
    */
    PVSSboolean removeAt(DynPtrArrayIndex index);

    /** remove all elements from list, the DynVar type is not changed
        @n Note: if you want to add variables of another type you must call 'clearType()'.
    */
    void clear() { value.clear(); }

    /**
    Resize array with new 0-pointers.
    If the memory could not be allocated, execution of the process is terminated.
    If you shrink the size, the objects removed are properly deleted.
    
    @param  newSize       Size of the new array. 
    @return unsigned int  Method returns the new size
    */
    unsigned int resize(unsigned int newsize) { return value.resize(newsize); }

    /** reset the DynVar type to NOTYPE_VAR
        @n This function has no effect, if the list is not empty.
      */
    void clearType() { if ( value.nofItems() == 0 ) { type = NOTYPE_VAR; cachedIsA = NO_VAR; } }

    /** remove all elements from list and set the DynVar type
        @param varType the VariableType to set
    */
    void reset(VariableType varType = NOTYPE_VAR) { clear(); type = varType; cachedIsA = NO_VAR; }

    /** get the DynVar type
        @return the VariableType as type of the DynVar
    */
    VariableType getType() const { return type; }

    /** set the DynVar type
        @param t the VariableType as type to set
    */
    void setType(VariableType t) { if (value.nofItems() == 0) { type = t; cachedIsA = NO_VAR; } }
    
    /** clone the current DynVar object
        @n Makes a deep copy.
        @return the Variable as clone of this object
      */
    virtual Variable *clone() const {return new DynVar(*this);}

    /** get number of items in the list
        @return the number of items in the list
      */
    unsigned int getArrayLength() const { return value.nofItems(); }

    /** get the first variable in the list or 0 if no element in list
        @return the first variable in the list or 0 if no element in list
      */
    Variable *getFirstVar() const;

    /** get the next variable in the list or 0 if no more elements
        @return the next variable in the list or 0 if no more elements
      */
    IL_DEPRECATED("deprecated, use getAt() instead")
    Variable *getNextVar() const;

    /** get the previous variable in the list or 0 if beyond the first element
        @return the previous variable in the list or 0 if beyond the first element
      */
    IL_DEPRECATED("deprecated, use getAt() instead")
    Variable *getPrevVar() const;

    /** get the last variable in the list or 0 if no element in list
        @return the last variable in the list or 0 if no element in list
      */
    Variable *getLastVar() const;

    /** get number of items in the list
        @return the number of items in the list
      */
    unsigned int getNumberOfItems() const {return getArrayLength();}

    /** get the first variable in the list or 0 if no element in list
        @return the first variable in the list or 0 if no element in list
      */
    Variable *getFirst() const {return getFirstVar();}

    /** get the next variable in the list or 0 if no more elements
        @return the next variable in the list or 0 if no more elements
      */
    IL_DEPRECATED("deprecated, use getAt() instead")
    Variable *getNext() const;

    /** get the previous variable in the list or 0 if beyond the first element
        @return the previous variable in the list or 0 if beyond the first element
      */
    IL_DEPRECATED("deprecated, use getAt() instead")
    Variable *getPrev() const;

    /** get the last variable in the list or 0 if no element in list
        @return the last variable in the list or 0 if no element in list
      */
    Variable *getLast() const {return getLastVar();}

    /** get variable at a specific position
        @param idx the index of the specific position starting with 0
        @return the variable at a specific position
      */
    Variable *getAt(DynPtrArrayIndex idx) const { return value.getAt(idx); }

    /** cut the first variable out of the list
        @return the variable at the first position, the caller must delete the variable
      */
    Variable *cutFirstVar();

    /** cut the last variable out of the list
        @return the variable at the last position, the caller must delete the variable
      */
    Variable *cutLastVar();

    /** cut out a variable at a specific position
        All elements behind will be moved 1 index to the front of the array.
        @param idx the index of the specific position starting with 0
        @return the variable at a specific position, the caller must delete the variable
    */
    Variable *cutAt(DynPtrArrayIndex idx) { return value.cutPtr(idx); }

    /** cut all variables out of the list without deleting them
    */
    void cutAll() { value.cutAll(); }

    /** replace a variable at a specific position
        the ptr from the list is returned but not deleted
        if no ptr exists on the idx the function will not work
        you can use replaceOrSetAt instead
        @param idx the index of the specific position starting with 0
        @param varPtr the Variable to replace with
        @return the variable at a specific position, the caller must delete the variable
    */
    VariablePtr replaceAt(DynPtrArrayIndex idx, VariablePtr varPtr = 0); 

    /** replaces or sets a variable at a specific position
        the ptr from the list is returned but not deleted
        if no ptr exists here the function will return 0, but the new ptr will be set
        @param idx the index of the specific position starting with 0
        @param varPtr the Variable to replace with
        @return the variable at a specific position, the caller must delete the variable
    */
    VariablePtr replaceOrSetAt(DynPtrArrayIndex idx, VariablePtr varPtr = 0); 

    /** clear the target and move all items to it, afterwards this list is empty
        @param target the target DynVar, which to move to
        @classification public use, call
    */
    void moveAllItems(DynVar &target);

    /** check if the given variable is already within the list
        @param val the value searched for
        @return PVSS_TRUE if value is found within the list else PVSS_FALSE else
        @classification public use, call
    */
    PVSSboolean isIn(const Variable &val) const;

    /** lookup the index of a given variable in the list
        @n If there are duplicate values in the list only the first one is found.
        @param val the value searched for
        @param index the index where the variable was found, starting with 1
                     @n If the variable was not found, the index is set to 0.
        @return PVSS_TRUE if value is found in list else PVSS_FALSE
        @classification public use, call
    */
    IL_DEPRECATED("deprecated, use 0-based find() instead")
    PVSSboolean isIn(const Variable &val, DynPtrArrayIndex &index) const;
    
    /** lookup the index of a given variable in the list
    @n If there are duplicate values in the list only the first one is found.
    @param val the value searched for
    @param index the index where the variable was found, starting with 0
    @n If the variable was not found, the index is undefined
    @return PVSS_TRUE if value is found in list else PVSS_FALSE
    @classification public use, call
    */
    PVSSboolean find(const Variable &val, DynPtrArrayIndex &index) const;

    /** count the occurences of a given variable in the list
        @param val the value searched for
        @return the number of occurences of val in the list
        @classification public use, call
    */
    PVSSulong count(const Variable &val) const;
    
    /** check if the given DynVar is contained in our list, i.e. if all values of rVal are subset
        of all values of this DynVar
        @n Note: any value may be contained more than once in any list
        and that the numbers of elements of both lists may be different.
        @param rVal the DynVar we should search for
        @return PVSS_TRUE if all members of rVal are found in our list else PVSS_FALSE
        @classification public use, call
    */
    PVSSboolean isEqualSet(const DynVar &rVal) const;

    /** check if this variable is a DynVar, always returns PVSS_TRUE
        @return PVSS_TRUE
    */
    virtual PVSSboolean isDynVar() const {return PVSS_TRUE;}

    /** check if this variable is a DynDynVar, i.e. a multi-diensional array
        @return PVSS_TRUE if DynDynVar else PVSS_FALSE
    */
    virtual PVSSboolean isDynDynVar() const;

    /** allocate new DynVar
        @return the new DynVar
      */
    virtual Variable *allocate() const { return new DynVar; }
    
    /** return type of variable
        @return DYN_VAR
      */
    virtual VariableType isAUncached() const;

  	/** return type of variable
        @param varType the VariableType to check
	      @return DYN_VAR if DynVar else return other VariableType
      */
    virtual VariableType isAUncached(VariableType varType) const;

# if 0
    /** return own variable type
        @return DYN_VAR
      */
    VariableType  isA() const.

	/** check if own variable type matches other variable type
      @param varType the VariableType to check
      @return DYN_VAR, if argument is DynVar, else NOTYPE_VAR.
    */
    VariableType  isA(VariableType varType) const;
# endif
 
    /** send to itcNdrUbSend stream
        @param ndrStream the stream, which to send to
      */
    virtual void outNdrUb(itcNdrUbSend &ndrStream) const;

    /** receive from itcNdrUbReceive stream
        @param ndrStream the stream, which to receive from
      */
    virtual void inNdrUb(itcNdrUbReceive &ndrStream);

	  /** send to output stream
        @param to the stream, which to send to
      */
    virtual void outToFile(std::ostream &) const;

    /** get from input stream
        @param from the stream, which to get from
     */
    virtual void inFromFile(std::istream &);


    /** Print the contents to an output stream. level controls the amount of debug information 
        printed. Nothing is printed if level == 0.
        @param [in,out] to the outputstream
        @param level <=0 nothing is printed, >0 content is printed
    */
    virtual void debug(std::ostream &to, int level) const;


      /** format the values according to the format string
        @param format the format string
            @n If the string is empty all variables are printed
               as their default string representation and are seperated by " | "
               else an empty string is returned.
        @return the string representing the values
      */
    virtual CharString formatValue(const CharString &format) const;
 
    /** format the value according to a format string.
        @param format the format string
            @n If the string is not empty ii is used as an argument to the sprintf function
               else "%lu" is used as a default.
        @param target the buffer, which is directly written to
               This method is more performant than the one which returns a CharString,
               because no alloc is done.
        @param len the size of the buffer
        @return the number of bytes written into target without 0-byte 
                or a negative value on error (like buffer too small)
             @n Special case: if no format is given, and the value is larger than the buffer,
                the result is a truncated value, ending in " ...", returnvalue is then -2.
    */
    virtual int formatValue(const CharString &format, char *target, size_t len) const;

    /** try to convert
        @param to the VariableType, to convert to
        @param out the VariablePtr, to convert from
        @return OK: conversion successful, "out" will be allocated
             @n OUT_OF_RANGE: conversion basically possible, but the value of "out" lies
                out of range "to", "out" wll be alocated in spite of this (!!!) and gets
                Min or Max of possible range
             @n CONV_NOT_DEFINED: type changing not possible, "out" will be set to 0
      */
    virtual ConvertResult convert(VariableType to, VariablePtr &out) const;

    /** set the contents to the intersection between two DynVar
        This function removes all elements, that are not in the given DynVar.
        @param val the DynVar to search in for our variables
      */
    void intersect(const DynVar &val);

    /** call this function to remove all duplicates from the list
      */
    void unique();

    /** sort the array ascending or descending according to their comparision operator
        A descending array is not marked as sorted as access functions expect the array
        is sorted ascending. 
        Note that LangTextVar texts are technically sorted and not locale aware.
        @param sortOrder the sort order (SORT_DESCENDING or SORT_ASCENDING)
    */
    void sort(SortOrder sortOrder = SORT_ASCENDING); 
    
    /** sort a 2-dimensional array according to the values of a column in ascending or 
        descending order according to their comparision operator
        dynSort uses a stable sorting algorithm, that means equal items maintain their
        relative order. <br>In this way a sorting order by several columns can be achieved by
        sorting by the least signifant column first and the most significant column last.
        dynSort does not set the isSorted flag.
        Note that LangTextVar texts are technically sorted and not locale aware.
        @param col the 0-based column index
        @param sortOrder the sort order (SORT_DESCENDING or SORT_ASCENDING)
      */  
    void dynSort(int col, SortOrder sortOrder = SORT_ASCENDING);
   
    /** reset the sorted flag
      */
    void invalidateSort();

    /** get the item type from the DynVar type, e.g. return FLOAT_VAR for DYNFLOAT_VAR
        @param dynVarType the DynVar type
        @return the corresponding item type or NOTYPE_VAR, if dynVarType is DYN_VAR or not a DynVar type
      */  
    static VariableType getItemType(VariableType dynVarType);

    /** get the DynVar type for the item type, e.g. return DYNFLOAT_VAR for FLOAT_VAR
        @param varType the item type
        @return the corresponding DynVar type or DYN_VAR if the item is NOTYPE_VAR 
        or NOTYPE_VAR if there is no DynVar type defined for that item type
      */  
    static VariableType getDynType(VariableType varType);

  private:
    // PtrList value;
    SimplePtrArray<Variable> value;
    VariableType type;
    
    mutable unsigned int lastAccessed;
    unsigned int isSorted : 1;
    unsigned int isAscending : 1;

    static int compare(const Variable *p1, const Variable *p2);

    struct DynComparator : public SimplePtrArray<Variable>::Comparator
    {
      DynComparator(bool asc) {sign_ = asc ? +1 : -1;}
     
      virtual int compare(const Variable *var1, const Variable *var2) const
      {
        if (!var1)
          return (var2 ? +1 : 0);
        else if (!var2)
          return (var1 ? -1 : 0);
        else
          return sign_ * DynVar::compare(var1, var2);
      }

      int sign_;
    };

    struct DynDynComparator : public DynComparator
    {
      DynDynComparator(DynPtrArrayIndex col, bool asc) : DynComparator(asc) {col_ = col;}
     
      virtual int compare(const Variable *var1, const Variable *var2) const
      {
        var1 = var1 && var1->isDynVar() ? ((const DynVar *) var1)->getAt(col_) : 0;
        var2 = var2 && var2->isDynVar() ? ((const DynVar *) var2)->getAt(col_) : 0;

        return DynComparator::compare(var1, var2);
      } 

      DynPtrArrayIndex col_;
    };

};

// -----------------------------------------------------------------------------------------------
#endif /* _DYNVAR_H_ */
