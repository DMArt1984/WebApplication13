// Handler for alive messages

#ifndef _ALIVEITCIOHANDLER_H_
#define _ALIVEITCIOHANDLER_H_

// System-Include-Files
#ifndef _TYPES_HXX_
#include <Types.hxx>
#endif

#ifndef _MANAGERIDENTIFIER_H_
#include <ManagerIdentifier.hxx>
#endif

#ifndef _INITSYSMSG_H_
#include <InitSysMsg.hxx>
#endif

// Forward declarations
class AliveItcIOHandler;
class itcInetSockDgram;
class MsgItcDispatcher;


// ========== AliveItcIOHandler ============================================================
class DLLEXP_MANAGER AliveItcIOHandler : public itcIOHandler,
                                         public ICBBcmReady
{
  friend class UNIT_TEST_FRIEND_CLASS;

  public:
    // Konstruktor
    AliveItcIOHandler(const CharString &connectString, bool sendCyclic, const ManagerIdentifier &dest, const ManagerIdentifier &host);
    AliveItcIOHandler(itcInetSockStream *connPtr, bool sendCyclic, const ManagerIdentifier &dest, const ManagerIdentifier &host);
    AliveItcIOHandler(itcInetSockDgram *conn, const ManagerIdentifier &target, const ManagerIdentifier &source);    
    
    // Destruktor
    virtual ~AliveItcIOHandler();

    // inputReady des Basissocket ruft accept, um einen neuen Socketdeskriptor 
    // (itcConnection *conn) f�r den Peer zu erhalten. Die Callback-Funktion wird
    // ausgeloest, da ein Connect-Aufruf eines Client erfolgte. Der Socketdeskriptor
    // wird mit einem PeerItcIOHandler im Dispatcher verknuepft.
    virtual int inputReady(itcConnection *conn, char *data);
    // Not used
    virtual int outputReady(itcConnection *conn, char *data);
    // Not used
    virtual int exeptionRaised(itcConnection *conn, char *data);
    // Not used
    virtual void timerExpired(long sec, long usec) override;
    
    const itcConnection *getConnect() const;
    itcConnection *getConnect();
    
    void  setSource(const ManagerIdentifier &newSource);
    void  setTarget(const ManagerIdentifier &newTarget);
    
    // Alive msg verschicken
    void  sendAliveMsg();

    // Realize ICBBcmReady interface
    virtual void bcmReady(int result, void *params);

    bool isConnectThreadRunning() const {return asyncConnectRunning;}

    // Returns PVSS_TRUE, if connectPtr is a valid pointer
    PVSSboolean  isValid() const;

  private:
    void rmAlivePeer();
  
    itcConnection    *connectPtr;
    itcNdrUbReceive    receiver;
    
    itcInetAddress  inetAddress_;
    SysMsg  initSysMsg;
        
    bool tcpBasedAlive;
    bool isAliveSender;
    
    ManagerIdentifier target;

    // status for 
    bool aliveStatus;
    
    // store the original hostname and portNr
    CharString origHostname;
    unsigned short origPortNr;
    
    bool inputReadyForMXProxy(itcConnection *conn);
    
    CharString myProxyReceiveBuffer_; // buffer used for receiving the proxy response
  
    bool asyncConnectRunning;
};


inline const itcConnection * AliveItcIOHandler::getConnect() const
{
  return connectPtr;
}


inline itcConnection * AliveItcIOHandler::getConnect()
{
  return connectPtr;
}


inline PVSSboolean AliveItcIOHandler::isValid() const
{
  if (connectPtr && ((connectPtr->Descriptor() >= 0) || asyncConnectRunning))
    return PVSS_TRUE;

  return PVSS_FALSE; //COVINFO LINE: defensive (impl error, AP)
}

#endif /* _SERVERITCIOHANDLER_H_ */
