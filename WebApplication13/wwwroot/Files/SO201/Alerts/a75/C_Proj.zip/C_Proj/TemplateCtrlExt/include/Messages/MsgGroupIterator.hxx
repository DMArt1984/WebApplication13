#ifndef _MSGGROUPITERATOR_H_
#define _MSGGROUPITERATOR_H_

#include <ErrClass.hxx>

// forward declaration
class DpIdentifier;
class Variable;


/**
 * An interface that allows iterating through the groups of a message,
 * removing groups, reading the items of a group as DpIdentifiers and
 * Variables, and manipulating the values of items.
 *
 * Part of the SecurityPlugin interface.
 */
class DLLEXP_MESSAGES MsgGroupIterator
{
public:
  /// Destructor. Necessary for derived classes.
  virtual ~MsgGroupIterator() {}

  /**
   * Sets the iterator to the first group of the message.
   *
   * @return False if the message does not have any groups
   *         otherwise true.
   */
  virtual bool getFirstGroup() const = 0;

  /**
   * Sets the iterator to the next group of the message.
   *
   * @return False if there is no next group, otherwise true.
   */
  virtual bool getNextGroup() const = 0;

  /**
   * Returns the first DpIdentifier of the current group, or null if
   * the group is empty or there are no more groups.
   */
  virtual const DpIdentifier *getFirst() const = 0;

  /**
   * Returns the next DpIdentifier in the group, or null if there are no
   * more DpIdentifiers or no more groups.
   * Use getFirst() to reset the iterator to the beginning of the group.
   */
  virtual const DpIdentifier *getNext() const = 0;

  /**
   * Returns the DpIdentifier at the current position, or null if there
   * is no item at the current position (e.g. at the end of a group).
   */
  virtual const DpIdentifier *getCurrent() const = 0;

  /**
   * Removes the group at the current position and jumps to the
   * next group.
   *
   * @param errorPtr The error message that will be used in the
   *                 "removed" group. If null is given, a default
   *                 error message will be used.
   *                 The method will take ownership of the given pointer.
   *                 In some implementations of the iterator, the given
   *                 error will not actually be used, just deleted.
   *
   * @return False if there is no next group, otherwise true.
   */
  virtual bool removeCurrentGroup(ErrClass *errorPtr = 0) = 0;

  /**
   * Returns a pointer to the value of the current item, or null
   * if there is no current item or the item has no value.
   */
  virtual const Variable *getCurrentValue() const = 0;

  /**
   * Returns a pointer to the value of the current item, or null
   * if there is no current item or the item has no value.
   *
   * The value can be manipulated in place, but cannot be deleted.
   *
   * @note Implementations of the MsgGroupIterator are allowed to create
   *       a copy of the internal message when this method is called,
   *       because changing the value might otherwise have side effects
   *       for other users.
   *       If you don't intend to change the value, please use the const
   *       version of this method, as it will never create a copy.
   */
  virtual Variable *getCurrentValue() = 0;

  /**
   * Replaces the value of the current item with the given new value.
   *
   * The old value will be deleted and ownership of the new value will be
   * taken. If the old and new values are of the same type, it might be
   * better to change them through getCurrentValue(), as this does not
   * require a new allocation.
   *
   * @param newValue The new value with which the old one will be
   *                 replaced. The call takes ownership of the pointer.
   *                 If a null pointer is given, the method will use a
   *                 default constructed AnyTypeVar for replacement.
   *
   * @return False if the value has not been replaced (e.g. if there is
   *         no current item), otherwise true.
   *
   * @note Implementations of the MsgGroupIterator are allowed to create
   *       a copy of the internal message when this method is called,
   *       because changing the value might otherwise have side effects
   *       for other users.
   */
  virtual bool replaceCurrentValue(Variable *newValue) = 0;

  /**
   * Returns true if all items of a group will belong to the same DPE.
   */
  virtual bool hasSameDpePerGroup() const = 0;

protected:

  /**
   * Creates a default error message that is used in removeCurrentGroup()
   * when no error message is given but we need one.
   */
  static ErrClass *createDefaultError();

};

//------------------------------------------------------------------------------
// inline methods:

inline ErrClass *MsgGroupIterator::createDefaultError()
{
  return new ErrClass(ErrClass::PRIO_SEVERE, ErrClass::ERR_PARAM, ErrClass::AUTH_ERROR,
                      "Denied by Security Plugin");
}

#endif // _MSGGROUPITERATOR_H_
