#include <ErrClass.hxx>

/** Baseclass for error handling in a plugin.
  <p>
  This is the base class for the handling of ErrClass objects loaded
  dynamically from a shared lib/dll and used in addition to the std. ErrHdl.
  </p>
  <p>
  The shared lib must have a function for creating an ExternErrHdl object in
  the following way:
  </p>

  <pre>
  extern "C"
  {
    ExternErrHdl *createExternErrHdl();
  }
  </pre>
*/
class DLLEXP_BASICS ExternErrHdl
{
  public:
    /** Virtual destructor.
    */
    virtual ~ExternErrHdl() {}

    /** The error handling function called from the standard error handler.
        @param errorClass ErrClass to handle.
    */
    virtual void handleError(const ErrClass &errorClass) = 0;
};
