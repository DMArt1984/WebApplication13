// DATEIBESCHREIBUNG ==============================================================
// DATEINAME:     DpSimpleSmoothConv.hxx
// VERANTWORTUNG:	Stanislav Meduna
//
// BESCHREIBUNG:	Einfache Glaettung (Zeit, Wert oder beides).
//
// AENDERUNGS-HISTORIE
// Ver.  | Datum      | Aenderungen                            | ModNr.| Autor
// ------+------------+-----------------Anfang-----------------+-------+-----------
//   1.0 |            | 1.Erstellung mit Westmount-OMT         |     0 |
// ======================================Ende======================================
#ifndef _DPSIMPLESMOOTHCONV_H_
#define _DPSIMPLESMOOTHCONV_H_

// Vorwaerts-Deklaration der Eigenen Klasse
class DpSimpleSmoothConv;

// System-Include-Files
#include <ConfigTypes.hxx>
#include <DpSmoothing.hxx>
#include <FloatVar.hxx>
#include <IntegerVar.hxx>
#include <TimeVar.hxx>
#include <Variable.hxx>

// Vorwaerts-Deklarationen :
class DpConvSmooth;
class DpSimpleSmoothConv;

class BitVec;

// ========== DpSimpleSmoothConv ============================================================
/** This is a basic smoothing class. It supports natively following types : INTEGER_VAR, UINTEGER_VAR, CHAR_VAR and FLOAT_VAR types.
    Other basics types are smoothed only by means of comparing the old value to a new one.
    The class can be configured using following attributes:
        - smoothing type
        - smoothing tolerance (deadband)
        - smoothing time

    Smoothing tolerance, once configured (should be greater the 0), defines a dead-band for a input value. If the new value is
    is within that limit the last valid value is returned. In addition to that tolerance, the smoothing time can be configured.
    Any value changes are ignored within that time and the last valid value is returned.

    @classification public use
*/
class DLLEXP_CONFIGS DpSimpleSmoothConv : public DpSmoothing
{
    friend class UNIT_TEST_FRIEND_CLASS;

  // Klassen-Enums:

// ..........................Anfang User-Klasseninterne-Definitionen..................
// ...........................Ende User-Klasseninterne-Definitionen...................
public:
  /** Default constructor.
   */
  DpSimpleSmoothConv();

  /** Copy constructor.
   */
  DpSimpleSmoothConv(const DpSimpleSmoothConv & copy);

  /** Default destructor.
   */
  ~DpSimpleSmoothConv();

  // Operators :

  /** Writes content of the smoothing class to the output stream.
        @param ndrStream Output stream.
        @param aConv Reference to DpSimpleSmoothConv instance.
        @return itcNdrUbSend stream.
    */
  friend DLLEXP_CONFIGS itcNdrUbSend &operator<<(itcNdrUbSend &ndrStream, const DpSimpleSmoothConv &aConv);

  /** Reads contents of the smoothing from the input stream.
        @param ndrStream Input stream.
        @param aConv Reference to DpSimpleSmoothConv instance.
        @return itcNdrUbSend stream.
   */
  friend DLLEXP_CONFIGS itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream, DpSimpleSmoothConv &aConv);

  /** Assignment operator used for type conversions (*x)=(*y).
      @param aConv Reference to DpSimpleSmoothConv instance.
      @return DpConvSmooth reference.
    */
  virtual DpConvSmooth &operator=(const DpConvSmooth &aConv);

  /** Copy assignment operator
    *
    * @param aConv Reference to DpSimpleSmoothConv instance.
    * @return DpSimpleSmoothConv reference.
    */
  DpSimpleSmoothConv & operator=(const DpSimpleSmoothConv &aConv);

  // Spezielle Methoden :

  /** Returns the class smoothing type.
      @return always DpConvSimpleSmooth type
   */
  virtual DpConversionType convType() const;

  /** Performs smoothing for a given input variable. This is a wrapper class that does not return the timeSmoothed
   *  and lastUnsmoothedValue parameters. (see next 'convert' method)
      @param inpVar value of the variable.
      @param outVarPtr smoothed output value.
      @param aTime timestamp of the variable.
      @param ubits user defined bytes.
      @return DpConversionOK on success and DpSmoothed if value was smoothed. In the case of an error a DpConversionError value is returned.
   */
  virtual DpConversionResultType convert(const Variable &inpVar,
                                         Variable * & outVarPtr,
                                         const TimeVar &aTime,
                                         const BitVec &ubits);

  // 07.02.07 ahofer IM74249: Wenn keine Zeitgl�ttung stattfindet bleibt
  // <lastUnsmoothedValue> unver�ndert. <lastUnsmooothedValue> wird dynamisch allokiert
  /** Performs smoothing for a given input variable.
      @param inpVar value of the variable.
      @param outVarPtr smoothed output value.
      @param aTime timestamp of the variable.
      @param ubits user defined bytes.
      @param timeSmoothed indicates if the value was time-smoothed.
      @param lastUnsmoothedValue returns last unsmoothed value.
      @return DpConversionOK on success and DpSmoothed if value was smoothed. In the case of an error a DpConversionError value is returned.
   */
  DpConversionResultType convert(const Variable &inpVar,
                                 Variable * & outVarPtr,
                                 const TimeVar &aTime,
                                 const BitVec &ubits,
                                 PVSSboolean &timeSmoothed,
                                 Variable *&lastUnsmoothedValue);

  /** Allocates a new DpSimpleSmoothConv object.
      @return A pointer to a newly created object, or NULL.
   */
  virtual DpConvSmooth *allocate() const;

  /** Sets a new value of specified smoothing attribute.
      @param attrNr specified attribute number.  Following attributes are supported by this class : SIMPLE_SMOOTH_TYPE_ATTR, SIMPLE_SMOOTH_TOLER_ATTR and SIMPLE_SMOOTH_TIME_ATTR.
      @param var a Variable object that holds specified attribute.
      @return PVSS_TRUE if the attribute's value was succesfully updated or PVSS_FALSE otherwise.
   */
  virtual PVSSboolean setAttribut(DpAttributeNrType attrNr, const Variable &var);

  /** Returns specified smoothing attribute value.
      @param attrNr specified attribute number.  Following attributes are supported by this class : TYPE_ATTR, SIMPLE_SMOOTH_TYPE_ATTR, SIMPLE_SMOOTH_TOLER_ATTR and SIMPLE_SMOOTH_TIME_ATTR.
      @return A pointer to a Variable objects that holds specified attribute.
   */
  virtual Variable *getAttribut(DpAttributeNrType attrNr) const;

  /** Indicates if the instance is properly configured, so the 'smoothing type' is correct and the 'toler' is a positive number.
      @return PVSS_TRUE if the instance is properly configured or PVSS_FALSE otherwise.
   */
  virtual PVSSboolean isConsistent() const;

  // Generierte Methoden :

  /** Returns actual smoothing type attribute. (const version)
      @return A reference to a IntegerVar value that holds smoothing type.
   */
  const IntegerVar &getAttrType() const;

  /** Returns actual smoothing type attribute.
      @return A reference to a IntegerVar value that holds smoothing type.
   */
  IntegerVar &getAttrType();

  /** Sets a new smoothing type attribute.
      @param newAttrType A reference to a IntegerVar value that holds smoothing type.
   */
  void setAttrType(const IntegerVar &newAttrType);

  /** Returns actual smoothing tolerance attribute. (const version)
      @return A reference to a FloatVar value that holds smoothing tolerance.
   */
  const FloatVar &getAttrToler() const;

  /** Returns actual smoothing tolerance attribute.
      @return A reference to a FloatVar value that holds smoothing tolerance.
   */
  FloatVar &getAttrToler();

  /** Sets a new smoothing tolerance attribute.
      @param newAttrToler A reference to a FloatVar value that holds smoothing tolerance.
   */
  void setAttrToler(const FloatVar &newAttrToler);

  /** Returns actual smoothing time attribute. (const version)
      @return A reference to a TimeVar value that holds smoothing time.
   */
  const TimeVar &getAttrTime() const;

  /** Returns actual smoothing time attribute.
      @return A reference to a TimeVar value that holds smoothing time.
   */
  TimeVar &getAttrTime();

  /** Sets a new smoothing time attribute.
      @param newAttrTime A reference to a TimeVar value that holds smoothing time.
   */
  void setAttrTime(const TimeVar &newAttrTime);

protected:
private:
  const Variable *getLastValue() const;
  Variable *getLastValue();
  void setLastValue(const Variable *newLastValue);
  const TimeVar &getLastTime() const;
  TimeVar &getLastTime();
  void setLastTime(const TimeVar &newLastTime);
  IntegerVar attrType;
  FloatVar attrToler;
  TimeVar attrTime;
  Variable *lastValue;
  TimeVar lastTime;
  BitVec *lastBitsPtr;

// ............................Anfang User-Attribut-Definitionen...................
  Variable *passValue(const Variable &inpVar, const TimeVar &aTime, const BitVec &ubits);
// .............................Ende User-Attribut-Definitionen....................
};

// ================================================================================
// Inline-Funktionen :
inline const IntegerVar &DpSimpleSmoothConv::getAttrType() const
{
  return attrType;
}

inline IntegerVar &DpSimpleSmoothConv::getAttrType()
{
  return attrType;
}
inline void DpSimpleSmoothConv::setAttrType(const IntegerVar &newAttrType)
{
  attrType = (IntegerVar &) newAttrType;
}
inline const FloatVar &DpSimpleSmoothConv::getAttrToler() const
{
  return attrToler;
}

inline FloatVar &DpSimpleSmoothConv::getAttrToler()
{
  return attrToler;
}
inline void DpSimpleSmoothConv::setAttrToler(const FloatVar &newAttrToler)
{
  attrToler = (FloatVar &) newAttrToler;
}
inline const TimeVar &DpSimpleSmoothConv::getAttrTime() const
{
  return attrTime;
}

inline TimeVar &DpSimpleSmoothConv::getAttrTime()
{
  return attrTime;
}
inline void DpSimpleSmoothConv::setAttrTime(const TimeVar &newAttrTime)
{
  attrTime = (TimeVar &) newAttrTime;
}
inline const Variable *DpSimpleSmoothConv::getLastValue() const
{
  return lastValue;
}

inline Variable *DpSimpleSmoothConv::getLastValue()
{
  return lastValue;
}
inline void DpSimpleSmoothConv::setLastValue(const Variable *newLastValue)
{
  lastValue = (Variable *) newLastValue;
}
inline const TimeVar &DpSimpleSmoothConv::getLastTime() const
{
  return lastTime;
}

inline TimeVar &DpSimpleSmoothConv::getLastTime()
{
  return lastTime;
}
inline void DpSimpleSmoothConv::setLastTime(const TimeVar &newLastTime)
{
  lastTime = (TimeVar &) newLastTime;
}

// ............................Anfang User-Inlines.................................
// .............................Ende User-Inlines..................................

// ................................OMT-Regeneration................................

#endif /* _DPSIMPLESMOOTHCONV_H_ */
