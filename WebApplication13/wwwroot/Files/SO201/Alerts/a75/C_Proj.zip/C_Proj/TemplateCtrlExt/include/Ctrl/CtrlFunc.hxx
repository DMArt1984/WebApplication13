#ifndef _CTRLFUNC_H_
#define _CTRLFUNC_H_

#include <PTreeNode.hxx>
#include <CharString.hxx>
#include <CtrlVarList.hxx>
#include <CtrlSmentList.hxx>
#include <TypeSpec.hxx>
#include <Variable.hxx>

class CtrlVar;
class CtrlScript;
class CtrlFuncTrackable;
class UserType;
class CtrlClass;

/*  author VERANTWORTUNG: Martin Koller */
/** Beinhaltet eine Function im CTRL Implementiert.
    @classification internal use
*/

class DLLEXP_CTRL CtrlFunc : public PTreeNode
{
  public:
    // constructor called by Parser: captures given pointer
    CtrlFunc(CharString *newName, int line, int lib);

    /// destructor
    virtual ~CtrlFunc();

    /** @return name of the function */
    const CharString &getName() const { return *name; }

    /// allow to change the name (e.g. to hide an already existing func via some CtrlExt)
    void setName(const CharString &newName) { *name = newName; }

    /** all functions are in a linked ist
      * @return pointer to next function
      */
    CtrlFunc *getNext() const { return next; }

    /** Beim Parsen werden die Funktionen miteinander
      * zu einer Liste verbunden
      * @param theNext next function in list
      */
    void setNext(CtrlFunc *theNext) { next = theNext; }

    void setReturnTypeSpec(const TypeSpec &typeSpec) { returnTypeSpec = typeSpec; }
    const TypeSpec &getReturnTypeSpec() const { return returnTypeSpec; }

    VariableType getReturnType() const { return returnTypeSpec.varType; }  // obsolete
    const UserType *getReturnUserType() const { return returnTypeSpec.userType; }  // obsolete

    /// Parameter die an die Funktion uebergeben werden
    void setParamList(CtrlVarList *list) { param = list; }

    /// Liste aller CtrlSment aus denen die Funktion besteht
    void setSmentList(CtrlSmentList *list) { sments = list; }

    CtrlSmentList *getSmentList() const { return sments; }

    /** @return das Erste CtrlSment der Funktion */
    const CtrlSment *getFirstSment() const { return sments; }

    /// returns a pointer to the function-parameter List
    const CtrlVarList *getParam() const { return param; }
    const CtrlVarList *getParamList() const { return param; }

    // COVINFO BLOCK: engineering (syntaxcheck not performed at runtime, mkoller)
    /** @return PVSS_TRUE Script syntax ok, PVSS_FALSE script not ok */
    bool checkIntegrity(const CharString &location, CtrlThread *thread) const
    { return checkIntegrity(location, thread, false); }

    bool checkIntegrity(const CharString &location, CtrlThread *thread, bool strict) const;
    // COVINFO BLOCKEND

    int  getLastLine() const { return lastLine; }
    void setLastLine(int scriptLineNumber) {lastLine = scriptLineNumber;}

    // synchronized and restricted access
    void setPrivate()   { accessMode = PRIVATE; }
    void setProtected() { accessMode = PROTECTED; }
    void setPublic()    { accessMode = PUBLIC; }
    void setStatic()    { staticFunc = true; }

    bool isPrivate()   const { return accessMode == PRIVATE; }
    bool isProtected() const { return accessMode == PROTECTED; }
    bool isPublic()    const { return accessMode == PUBLIC; }
    bool isStatic()    const { return staticFunc; }

    virtual void setSynchronized(CtrlExpr *) { synchronized = true; }
    virtual bool isSynchronized(CtrlThread *) const { return synchronized; }

    virtual CtrlThread *getCurrentThread(CtrlThread *t) const { return currentThread; }
    virtual bool lock(CtrlThread *t) const;
    virtual bool unlock(CtrlThread *t) const;
    virtual bool isLocked(CtrlThread *t) const;

    // For statistics
    // COVINFO BLOCK: engineering (performance info for engineering only, mkoller)
    void incrementCallCount() const {++callCount_;}
    
    void incrementCallTime(PVSSulong t, PVSSboolean dependentOnly) const
    {
      if (bPerfMark)
        return;

      if (!dependentOnly)
        interpreterTime_ += t;
      interpreterTimeDependent_ += t;

      bPerfMark = 1;
    }
    void incrementBlockedTime(PVSSulong t, PVSSboolean dependentOnly) const
    {
      if (!dependentOnly)
        blockedTime_ += t;
      blockedTimeDependent_ += t;
    }
    int  getCallCount() const {return callCount_;}

    void resetPerfMark() const {bPerfMark = 0;}
    // COVINFO BLOCKEND

    void reportStatus(std::ostream &os) const;

    /** dump the whole tree for code coverage analysis
        @param to output stream
      */
    virtual void dumpCoverageTree(std::ostream &to, CoverageAction action = DUMP) const;

    // return the function signature generated from the declaration
    CharString signature() const;

    CtrlScript *getScript() const { return script; }
    void setScript(CtrlScript *s) { script = s; }

    CtrlClass *getClass() const { return ctrlClass; }
    void setClass(CtrlClass *theClass) { ctrlClass = theClass; }

    // get a trackable object which will be deleted whenever this CtrlFunc is deleted
    // @internal
    CtrlFuncTrackable *getTrackableObject() const;

  private:
    CtrlFunc();  // disable
    CtrlFunc(const CtrlFunc &);  // disable

    class CtrlFuncPrivate *d;

    CtrlScript *script;  // owner (optional, since it can be inside a class)
    CtrlClass *ctrlClass;  // if this is a class method, pointer to class

    TypeSpec returnTypeSpec;

    CharString *name;
    CtrlVarList *param;
    CtrlSmentList *sments;
    CtrlFunc *next;

    int lastLine; // last line of function in source

    mutable int bPerfMark:1;

    enum AccessMode { PRIVATE, PROTECTED, PUBLIC };
    AccessMode accessMode:3; // Wincrap does not follow C++ Standard and uses "signed int" needing a bit more

    bool synchronized;
    bool staticFunc;

    mutable CtrlThread *currentThread;
    mutable unsigned lockCount;

    // Performance Statistics (only used when CTRL_PERF dbg flag is activated)
    mutable int callCount_;                       // Number of calls
    mutable PVSSulong interpreterTime_;           // micros spent in interpreter (without block time)
    mutable PVSSulong interpreterTimeDependent_;  // micros spent in interpreter including dependent function
    mutable PVSSulong blockedTime_;               // Blocked time in function
    mutable PVSSulong blockedTimeDependent_;      // Blocked time in function including dependent
};

#endif /* _CTRLFUNC_H_ */
