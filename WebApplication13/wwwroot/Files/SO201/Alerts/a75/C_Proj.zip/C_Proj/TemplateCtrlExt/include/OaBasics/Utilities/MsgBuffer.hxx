#ifndef _MSGBUFFER_H_
#define _MSGBUFFER_H_

#include <Types.hxx>


/** The MsgBuffer class can be used to store messages in a buffer.
    It performs reallocation when more size is required or when the buffer
    usage is very small. It provides also some functions to search in the
    buffer.
    @classification public use
    
*/

class DLLEXP_OABASICS MsgBuffer
{
  friend class UNIT_TEST_FRIEND_CLASS;
  public:
  /// Constructor
  MsgBuffer(int size = 1024);

  /// Destructor
  ~MsgBuffer ();

  /// returns the number of data bytes in the buffer
  unsigned size() const;

  /// returns the number of free space in the buffer
  unsigned freeSize() const;

  /** This function returns a pointer to the data contained in the buffer.
      If there are no data in the buffer NULL ist returned.
  */
  const char * getData() const;

  /** This function returns the pointer to the data. The caller has to delete
      the pointer.
  */
  char * cutDataPtr();

  /** This function copies the data into the user buffer.
      @param buf pointer to the user buffer
      @param len length of user buffer
      @return the number of bytes copied
  */
  int getData (char * buf, unsigned int len);

  /** This function searches for the separation character and returns
      the position of the first separation character + 1 = length of the 
      search string including separation character.
  */
  unsigned indexOf(const char sep) const ;

  /** This function searches for a separation string and returns
      the position of the first separation string + length of separation string
      (without 0) = length of the search string including separation string.
  */
  unsigned indexOf(const char *sep, int sepLen) const ;

  /** The call to this function makes sure that there is at least newLen character
      space in the buffer. If the movement of the data to the beginning of the 
      buffer is not sufficient a reallocation is done.
      @param newLen required free space
      @return PVSS_TRUE everything OK
              PVSS_FALSE in the case of error
  */
  PVSSboolean extendBuffer (unsigned newLen);

  /** With this function data are appended to the buffer by copiing from a user
      buffer.
      @param buf pointer to user buffer
      @param len length of the user buffer
  */
  PVSSboolean append (const char * data, int len);

  /** With this function data are cut out of the buffer. If the size of the data  
      is below the half of the buffer size the buffer size is reduced. The minimum is 
      the initial size.
      @param len number of bytes to be cut out
  */
  void cutData(int len);

  /** This function returns a pointer to the free space.
      If the free space requested by the 'len' parameter could not be provided
      a NULL pointer is returned.
      @param len this parameter is in/out. As input it gives the required length
           and as output it returns the actual free space.
      @return a pointer to the free space or NULL in case that the requested len could not
              be provided.
  */   
  char * getFreePtr (unsigned &len);

  /** Finalises append by direct writing into the buffer.
      @param len number of bytes to append.
   */
  void append(int len);

  /** Resets the Buffer and releases memory */
  void clear();

  private:

  void moveMem (unsigned lsize);
  PVSSboolean reAlloc (unsigned lsize, unsigned newDataLen);
  unsigned initialSize_;
  unsigned dataLen_;

  char * dataPtr_;
  char * endPtr_;
  char * startPtr_;

};

#endif /* _MSGBUFFER_H_ */
