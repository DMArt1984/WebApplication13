//COVINFO FILE: nosfunc (EWOs excluded from use in safety projects -> simple UIs, tbraidt)
#ifndef _BASE_EXTERN_WIDGET_H_
#define _BASE_EXTERN_WIDGET_H_

#include <QWidget>
#include <QStringList>
#include <QVariant>
#include <QList>

#ifdef EWO_MAKE_DLL
#  define EWO_EXPORT_BASE Q_DECL_EXPORT
#else
#  define EWO_EXPORT_BASE Q_DECL_IMPORT
#  define EWO_EXPORT      Q_DECL_EXPORT
#endif

#define EWO_VERSION "4"

#ifndef WCCOA_STATIC_PLUGINS

#define EWO_PLUGIN(CLASS) extern "C" \
        { \
          EWO_EXPORT BaseExternWidget *createExternWidget(QWidget *parent)\
          { return new CLASS(parent); } \
          EWO_EXPORT const char *getVersionString() \
          { return EWO_VERSION; } \
        }

#else

#define EWO_PLUGIN(CLASS) \
          BaseExternWidget *CLASS##_createExternWidget(QWidget *parent) \
          { return new CLASS(parent); }

#endif

//--------------------------------------------------------------------------------
/** This class is the base class for External Widget Object (EWO) plugins

    Derive from it and implement at least the pure virtual method.

    Your class must be declared like this:

    class EWO_EXPORT MyNewClass : public BaseExternWidget
    {
      Q_OBJECT

      ...
    };

    Make sure to include in your implementation file a statement like this:

    EWO_PLUGIN( MyNewClass )
*/

class EWO_EXPORT_BASE BaseExternWidget : public QObject
{
  Q_OBJECT

  public:
    /// constructor
    BaseExternWidget(QWidget *parent) : QObject(parent) {}

    /// destructor
    virtual ~BaseExternWidget();

    /// returns the widget which really displays things
    virtual QWidget *widget() const = 0;

    /** Signatures of signals.
        Return a list of all signal signatures which will be emitted
        via the generic "signal" signal.
        The signature must contain only CTRL specific datatypes, e.g.
        "string" instead of "QString"
        E.g.: "clicked()", "timeChanged(time t)", "textChanged(string text)"
    */
    virtual QStringList signalList() const;

    /** Retrieve the interface of a signal with real datatypes
        This is an optional functionality, as usually automatic type conversion is done.
        However it might be needed to know the datatype when special values are passed
        in converted datatypes, e.g. a color is passed as a string.
        If a signal does not provide its interface details with this method, the method returns false.
        (The default implementation always returns false)
    */
    virtual bool signalInterface(const QString &name, QList<QVariant::Type> &args) const;

    /** Signatures of callable methods.
        Return a list of all method signatures which can be called
        via the generic "invokeMethod" slot.
        The signature must contain only CTRL specific datatypes, e.g.
        "string" instead of "QString" and must have the format:
        "returnType methodName(arguments...)"
        e.g.:  "string getName()", "void reset(int x, int y)"
    */
    virtual QStringList methodList() const;

    /** Retrieve the interface of a method with real datatypes
        This is an optional functionality, as usually automatic type conversion is done.
        However it might be needed to know the datatype when special values are passed
        in converted datatypes, e.g. a color is passed as a string.
        If a method does not provide its interface details with this method, the method returns false.
        (The default implementation always returns false)
    */
    virtual bool methodInterface(const QString &name, QVariant::Type &retVal, QList<QVariant::Type> &args) const;

  public slots:
    /** The generic method invoke entry point
        The QVariant objects in values are updated when the method has out-parameters.
        Call this baseclass implementation as the last resort, as it sets an appropriate
        error message, so that the user knows he has called an unknown method.
        E.g.
        return BaseExternWidget::invokeMethod(name, values, error);
    */
    virtual QVariant invokeMethod(const QString &name, QList<QVariant> &values, QString &error);

  signals:
    /** The generic signal.
        Whenever you implement a new signal, make sure that you also emit
        this signal (or the one with the QList argument),
        passing the parameter as the argument.
        This (and the next) is the only signal which the WinCC_OA-Ui knows of and it will be
        used to distribute all your signals to the CTRL scripts.
        @param sigName the name of the signal. It is used to find a CTRL-script
               function with the same name.
        @param value allows to pass a single value to the CTRL script
    */
    void signal(const QString &sigName, const QVariant &value = QVariant());

    /** The generic signal.
        Same as above but allow for a list of parameters
        @param sigName the name of the signal. It is used to find a CTRL-script
               function with the same name.
        @param values List of values which will be passed to the CTRL-script in
               the same order
    */
    void signal(const QString &sigName, const QList<QVariant> &values);

  protected:
    /** checks if the given argument array has at least 'num' entries
        @param name the name of the invoked method (the name argument in invokeMethod())
        @param values the argument array passed to invokeMethod()
        @param num the number of required arguments
        @param error on error, it returns an error message
        @return true if enough arguments are given, else false
    */
    bool hasNumArgs(const QString &name,
                    const QList<QVariant> &values, int num, QString &error);
};

//------------------------------------------------------------------------------

#endif
