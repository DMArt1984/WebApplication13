#ifndef _WaitThread_H_
#define _WaitThread_H_

#include <WaitCond.hxx>
#include <TimeVar.hxx>
#include <DoneCB.hxx>

class ThreadDoneCB;
class ExprList;
class CtrlFunc;
class CtrlThread;
class CtrlExpr;

// wait on another thread and pass result over (needed for OO-panels)

class WaitThread : public WaitCond
{
  public:
    WaitThread(ThreadDoneCB *done) : doneCB(done) { }

    virtual ~WaitThread();

    virtual const TimeVar &nextCheck() const { return TimeVar::MaxTimeVar; }

    virtual int checkDone() { return doneCB == 0; }

    void itsDone() { doneCB = 0; }

  private:
    ThreadDoneCB *doneCB;
};

//--------------------------------------------------------------------------------

class ThreadDoneCB : public DoneCB
{
  public:
    // @origin the thread which started the new thread and receives the result
    ThreadDoneCB(CtrlThread *origin, const CtrlFunc *f, ExprList *a, CtrlExpr *first, int toSkip)
      : originThread(origin), myThread(0), func(f), wait(0), gotResult(false),
        args(a), firstArg(first), funcParamsToSkip(toSkip)
    { }

    virtual ~ThreadDoneCB();

    virtual DoneCB *clone() const;

    virtual void execute(const Variable *result = 0);

    // the owner thread of this DoneCB
    void setThread(CtrlThread *t) { myThread = t; }

    void setWaitCond(WaitThread *w);

  private:
    CtrlThread *originThread, *myThread;
    const CtrlFunc *func;
    WaitThread *wait;
    bool gotResult;
    ExprList *args;
    CtrlExpr *firstArg;
    int funcParamsToSkip;  // needed when additional first argument(s) were internally generated/passed (userData)
};

//--------------------------------------------------------------------------------

#endif
