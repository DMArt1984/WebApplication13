#ifndef _MANAGER_H_
#define _MANAGER_H_

// DATEIBESCHREIBUNG ==============================================================
// VERANTWORTUNG: Martin Koller
// BESCHREIBUNG:  Das ist eine Klasse, die alle Bausteine eines PVSS-II Managers
//                enthaelt. Diese Bausteine sind alle statische Pointer, damit man
//                global auf sie zugreifen kann. Wenn ein Manager einen Baustein
//                nicht braucht, so wird der entsprechende Pointer einfach nicht
//                initialisiert.
//
//                ACHTUNG: (TI 3267 - WOKL 20.9.99)
//                Das WaitForAnswer-Object, das bei den meisten Sende-Funktionen
//                mitgegeben wird (nebst einem Flag, ob es geloescht werden soll),
//                wird auch im Fehlerfall (Returncode) dem Flag entsprechend
//                bedient (geloescht oder auch nicht)

#include <ManagerIdentifier.hxx>
#include <MsgVersion.hxx>
#include <DpConfigNrType.hxx>
#include <ErrHdl.hxx>
#include <DpTypes.hxx>
#include <DpIdValueList.hxx>
#include <DpIdentification.hxx>
#include <TimeVar.hxx>
#include <LangTextVar.hxx>
#include <Bit32Var.hxx>
#include <CharString.hxx>
#include <DpICGroup.hxx>
#include <UserTable.hxx>
#include <DiagHotLinkWaitForAnswer.hxx>
#include <DiagMsgItcIOHandler.hxx>
#include <DiagConfigAndDpItcIOHandler.hxx>
#include <DpTypeContainer.hxx>
#include <FileTransferList.hxx>
#include <Util.hxx>
#include <CallBackItem.hxx>
#include <CNSObserver.hxx>
#include <DpMsgComplexVC.hxx>
#include <functional>
#include <map>
#include <PermissionCheck.hxx>
#include <LicenseExtTypes.hxx>

class RunningState;
class PmonTable;

class MsgItcDispatcher;

class Msg;
class DpMsg;
class SysMsg;
class InitSysMsg;
class DpMsgAnswer;
class DpMsgManipDpType;
class DpMsgManipCNS;
class DpMsgManipDp;
class DpMsgManipDpName;
class DpIdentifierItem;
class DpType;
class DpMsgInitConfig;

class CNSContainer;
class ManagerTable;
class NameServerSysMsg;
class FileTransferSysMsg;

class AlertList;
class DpHLGroup;
class DpVCGroup;
class TimeVar;
class WaitForAnswer;
class HotLinkWaitForAnswer;
class AlertHotLinkWaitForAnswer;
class DpMsgFilterRequest;

class DpContainer;
class DpIdentList;
class Controller;
class ErrHdl;

class itcConnection;
class itcIOHandler;

class License;
class LicenseOptions;
class LicenseSysMsg;

class CommonNameService;
class SecurityPlugin;

class DpTypeDefinition;

class CallBackList;

class MappingVar;


/** The (API) manager class. This class cover the API interface functionality.
  Each PVSS-II manager must contain anything up to the manager level to be able
  to participate in the PVSS-II data exchange.

  <p> Each manager has a manager type (this is hard coded) and a manager number
  which can be set when starting (-num xx option). This duple of numbers identifies the
  manager and therefore there must not be two managers with the same combination
  in one running PVSS-II system.

  @classification public use, overload
 */
class DLLEXP_MANAGER Manager
{
  friend class UNIT_TEST_FRIEND_CLASS;    // ein Unit-Test braucht erweiterten zugriff auf diese Klasse
  friend class SECURITY_PLUGIN_FRIEND_CLASS;

  friend class PeerItcIOHandler;
  friend class MsgItcDispatcher;
  friend class DrvConfigManager;
  friend class CallBackItem;
  friend class MsgQueueContainer;
  friend class EvManager;

  public:

  /** Internal running state. The running state of the manager.
    This is set by internal functions to keep track of activity.
   */
  enum ManagerState
  {
    /** (0). The manager has been started and is trying to connect to DM */
    STATE_JUST_STARTED,
    /** (1). The manager has connection to DM and is receiving init data */
    STATE_INIT,
    /** (2). Init from database finished. Manager is now ready to finish
      manager specific initialisation and to connect to event.
     */
    STATE_ADJUST,
    /** (3). Connection to EM established. The manager is now ready for operation
     */
    STATE_RUNNING
  };

  using LicenseCallback = std::function<void(int value, bool error)>;

  /// Shortcut to event manager ID
  static ManagerIdentifier eventId;
  /// Shortcut to data manager ID
  static ManagerIdentifier dataId;
  /// Redundant data manager id
  static ManagerIdentifier novoteDataId;
  ///  Redundant event manager id
  static ManagerIdentifier novoteEventId;
  /// Dist manager id
  static ManagerIdentifier distId;
#ifndef NO_NGA
  static ManagerIdentifier ngaId;
#endif


  /**
   * Constructor for a manager with the specified id.
   *
   * @param manId The manager id, a duple of manager type and number
   */
  Manager(const ManagerIdentifier &manId);

  /**
   * Constructor for a manager with the specified id and a (possibly derived)
   * instance of the CommonNameService-class.
   * If you just need a default instance of the CommonNameService,
   * please use the other constructor.
   *
   * @param manId The manager id, a duple of manager type and number
   * @param customCns Pointer to an instance of CommonNameService.
   *                  Can be used to bring a custom derived instance of the
   *                  CommonNameService-class into the Manager.
   *                  The Manager takes ownership of the instance.
   */
  Manager(const ManagerIdentifier &manId, CommonNameService *customCns);

  /// Destructor
  virtual ~Manager();

  /** Terminates the manager. It has a special
    mechanism to prevent multiple exit() calls on a manager which is already
    exiting. You should always use this function to exit your manager!
    @param exitCode The code passed to the operating system
    @classification public use, call
   */
  static void exit(int exitCode);

  /** Requests to exit the manager during the next dispatch() call
    In contrast to Manager::exit(), this method does not terminate the manager
    immediately but just stores the request to exit with the given exitCode
    and will call Manager::exit() only on the next dispatch() call.
    This allows a Manager to intercept the exit request before calling dispatch()
    and probably doing some cleanup or cancel the request completely.
    @param exitCode The code passed to the operating system on ::exit
  */
  static void requestExit(int exitCode = 0);

  /// Cancels the requested exit call. The manager will not terminate in the next dispatch()
  static void cancelExitRequest();

  /** Check if there is a pending exit request.
    @return true if ther is a pending exit request, false otherwise
  */
  static bool exitRequested();

  /// Returns the requested exit code set with requestExit()
  static int getRequestedExitCode();

  /** The static signal handler. The only purpose of this signal handler
    is to call the manager signal handler signalHandler.
    Since we cannot register a member
    function as global signal handler, we use this static wrapper. You can
    use a static function in the (operating system dependent) signal() call
    @param sig the signal
    @classification public use, call
   */
  static void sigHdl(int sig);

  static void setLicenseOption(const char* option) { licenseOption_ = option; }

  /** Get your own ManagerIdentifier.
    @return a reference to the internal manager id which consists of the manager
    type and the manager number.
    @classification public use, call
   */
  static const ManagerIdentifier &getMyManagerId() { return Resources::getManId(); }

  /** Get the locking code for given manager.
    used by the function getMyDMLockingCode - currently only databg manager!
    do not use.
    @return the lockingcode of the manager which matches to the manId.
    @param manId the manager identifier
    @classification ETM internal
   */
  static PVSSushort getDMLockingCode(const ManagerIdentifier& manId);
  /** Get the locking code of your own manager.
    used to lock the raima db by the databg manager.
    should not be used by other managers than the databg
    @return the locking code of our own manager.
    @classification ETM internal
   */
  static PVSSushort getMyDMLockingCode() { return getDMLockingCode(getMyManagerId()); }

  /** Get a pointer to the internal datapoint type container.
    The type container contains the description of all datapoint types.
    The type names however are stored in the DpIdentification.
    We need this container whenever we want to handle datapoints.
    @param sys The system number of the requested type container.
    @return a pointer to the dp-type container
    @classification public use, call
   */
  static DpTypeContainer *getTypeContainerPtr(SystemNumType sys = DpIdentification::getDefaultSystem());

  /** Cut the pointer to the internal datapoint type container.
    The internal storage is set to NULL and the caller is now responsible for the pointer.
    The type container contains the descriptions of all datapoint types.
    The type names however are stored in the DpIdentification.
    We need this container whenever we want to handle datapoints.
    @param sys The system number of the requested type container.
    @return a pointer to the dp-type container
    @classification public use, call
   */
  static DpTypeContainer * cutTypeContainerPtr(SystemNumType sys = DpIdentification::getDefaultSystem());

  /** Set the pointer to the internal datapoint type container.
    @param newTypeContainerPtr a pointer to the new dp-type container. This argument may not be NULL.
    @classification ETM internal
   */
  static void setTypeContainerPtr(DpTypeContainer *newTypeContainerPtr);

  /** Get a pointer to the internal datapoint container.
    The datapoint container holds all configs, i.e. the values associated
    with the datapoint elements. This function returns NULL, if the connection
    to data manager has not been opened with StartDpInitSysMsg::DP_IDENTIFICATION
    flag. Which means, that the manager does not request to have the DP identification.
    This is for instance the case for all managers derived from DrvManager class
    (i.e. drivers).
    @return a pointer to the datapoint container
    @classification public use, call
   */
  static DpContainer *getDpContainerPtr() { return dpContainerPtr; }
  /** Set the pointer to the datapoint container.
    @param newDpContainerPtr a pointer to the new datapoint container
    @classification ETM internal
   */
  static void setDpContainerPtr(DpContainer *newDpContainerPtr)
  { dpContainerPtr = newDpContainerPtr; }

  /** Get a pointer to the internal datapoint identification container.
    The datapoint identification holds all names and their respective ids.
    To convert a name to an id and v.v. you may call the respective functions
    getName and getId / getIdSet of the manager class instead of dealing with
    the dp-identification itself.
    @return a pointer to the dp-identification
    @classification public use, call
   */
  static DpIdentification *getDpIdentificationPtr() { return dpIdentificationPtr; }
  /** Set the pointer to the dp-identification container.
    @param newDpIdentificationPtr a pointer to the new dp-idnetification
    @classification ETM internal
   */
  static void setDpIdentificationPtr(DpIdentification *newDpIdentificationPtr);

  /** Cut the pointer to the dp-identification
    @return a pointer to the dp-identification
    @classification ETM internal
   */
  static DpIdentification * cutDpIdentificationPtr();

  /** Get the internal CNSContainer.
    CNSContainer holds CNS data of all Systems this manager is configured to hold.
    @see CommonNameService. This is the public interface of CNS
    @return the CNSContainer
    @classification ETM internal
   */
  static CNSContainer &getCNSContainer();

  /** Get the current running state of our manager.
    @return the current runnint state
    @classification public use, call
   */
  static ManagerState getManagerState() { return managerState; }
  /** Set the current running state of our manager.
    @param newState the new running state
    @classification ETM internal
   */
  static void setManagerState(ManagerState newState) { managerState = newState; }

  /** Get a pointer to the Ctrl-handler of the manager.
    Only a few managers like the Ctrl manager or the User Interface have a
    ctrl-handler. Dealing with the ctrl-handler is not part of the API.
    @return a pointer to the ctrl-handler
    @classification ETM internal
   */
  static Controller *getCtrlPtr() { return ctrlPtr; }

  /** Set the function which will be called for the Controller-report
   *  Necessary, because the CTRL-Lib is in a higher level than Manager
   *  @ param fct the function pointer to our ctrl function
   *  @classification ETM internal
   */
  static void setCtrlReportFct(void (*fct)(std::ostream &to)) { ctrlReportFct = fct; }

  /** Initialize the manager table.
    Whenever user & permission management is needed, the internal
    permission table(s) must be initialized. This function is used to init the
    manager table.
    @classification public use, call
   */
  static void initManagerTable();

  /** Initialize the user table. Whenever user & permission management is needed,
    the internal permission table(s) must be initialized.
    This function is used to init the
    user table which allows username <-> userid conversion and passwd checks.
    @classification public use, call
   */
  static void initUserTable();   // initialize the name/id conversion functionality

  /** Get the status of the user table
    @return PVSS_TRUE if the user table is initialized
    @classification ETM internal
  */
  static PVSSboolean isUserTableInitialized();

  /** Get the current user id.
    @return the current user id
    @classification  public use, call
   */
  static PVSSuserIdType getUserId() { return userId; }

  /** Convert the userName to the userId.
    @param userName the user to search for
    @return the respective user id or -1 if userName does not exist
    @classification public use, call
   */
  static PVSSuserIdType getUserId(const char* userName);

  /** API function. get the current user name
    @return returns 0 if conversion fails, userName otherwise
    @classification public use, call
   */
  static const char* getUserName();

  /** API function. convert the userId to the userName
    @param id the user id to search for
    @return 0 if userId does not exist
    @classification public use, call
   */
  static const char* getUserName(PVSSuserIdType id);

  /** Sets the current userId.
    A new user id is set when (id matches passwd) or
    (currentId is ROOT_USER and newUserId exists) or
    (newUserId is DEFAULT_USER).
    @param newUserId the new user id to change to
    @param passwd the passwd string for the new user id (when needed)
    @return PVSS_TRUE if the user id has changed, PVSS_FALSE otherwise
    @classification public use, call
   */
  static PVSSboolean setUserId(PVSSuserIdType newUserId, const char *passwd = 0 );

  /** Trigger a new Challenge / Response handshake to bind the currently authenticated user to the TCP session.
    the Manager-Framework gets the new userId and the response to prove the identity of the user via the
    Challenge / Response handshake from the SecurityPlugin
    It is not posssible to send any MSG while the Challenge / Response handshake is in progess.
    If you try to send any MSG before the  callBack() method of your wait object is invoked, send will fail!
  @param wait a WaitForAnswer object to handle the answer (maybe error!). The object is deleted by the framework.
  @return PVSS_TRUE if message has been sent - to recognize an error you must use the answer handler
  @classification public use, call
  */
  static PVSSboolean ssaReLogin(WaitForAnswer *wait);

  /** Sets the current user.
    A new user is set when the name of the user currently logged onto the system
    match the newUserName and newUserName is not the DEFAULT_USER.
    @param newUserName the new user id to change to
    @return PVSS_TRUE if the user id has changed, PVSS_FALSE otherwise
    @classification public use, call
   */
  static PVSSboolean setUserIdSSO(const CharString &newUserName);

  /** Get the status of the specified user
    @param id the user to be checked
    @return PVSS_TRUE if the user is enabled, else false
    @classification public use, call
  */
  static PVSSboolean isUserEnabled(PVSSuserIdType id);

  /** Check if the connection is secured by kerberos authentication
   * @param manId the manager id of the manager we want to check
   * @return PVSS_TRUE if the manager has Kerberos security, or PVSS_FALSE else
   * @classification public use, call
   */
  static PVSSboolean hasKerberosSecurity(const ManagerIdentifier &manId);

  /** Get the security level
   * -1: error no connection to the given manager
   *  0: none
   *  1: authentication
   *  2: integrity
   *  3: encryption
   *  for further information see the PVSS help
   * @param manId the manager id of the manager we want to check
   * @return the securitylevel of the manager
   * @classification public use, call
   */
  static int getKerberosSecurity(const ManagerIdentifier &manId);

  /** Check if the connection is secured by SSA
    @param manId the manager id of the manager we want to check
    @return PVSS_TRUE if the manager is secured by SSA, or PVSS_FALSE else
    @classification public use, call
  */
  static PVSSboolean isSsaSecured(const ManagerIdentifier &manId);

  /** Get the user id related to that connection
   * @param peerId the manager id of the connection
   * @return the user related to the connection
   * @classification public use, call
   */
  static PVSSuserIdType getPeerUserId(const ManagerIdentifier &peerId);

  /** Verfiy password. Check if the given passwd is valid for the requested user id
    @param id the user id
    @param passwd the password to check
    @return PVSS_TRUE on success
    @classification public use, call
   */
  static PVSSboolean checkPassword(PVSSuserIdType id, const char* passwd);

  /** Get the list of group IDs, where the user belongs to.
    @param id the user id
    @return pointer to a DynVar (DYNUINTEGER_VAR) containing the list of group IDs
            0 in case of error (no user table or user does not exist)
    @classification public use, call
   */
  static const DynVar *getGroupIds(PVSSuserIdType id);

  /** returns user permissions of own user and manager
   * @return the set user permission
   * @classification ETM internal
   */
  static PVSSulong getUserPermissionSet()
  { return getUserPermissionSet(userId, getMyManagerId()); }

  /** returns user permissions of given user id and manager id
   * @param userId the user id
   * @param manId the manager id
   * @return the set user permission
   * @classification ETM internal
   */
  static PVSSulong getUserPermissionSet(PVSSuserIdType userId,
      const ManagerIdentifier & manId);

  /** Returns manager permissions of given manager id
   * @param manid the manager id
   * @return the set manager permission
   * @classification ETM internal
   */
  static PVSSulong getManagerPermissionSet(const ManagerIdentifier &manid);

  /**
    checks if the password is identical with the one given for a previous
    cryptHashPBKDF2() call to generate a PKCS#5 2.0 complient password hash
    @see cryptHashPBKDF2()
    Note!
    the salt and the iterations information needed to recalculate the hash
    are taken from the string passwordHash which has the format
    #PBKDF2#<salt>#<iterations>#<passhash>

    @param  passwd the password to be checked
    @param  passwordHash a hash generated with cryptHashPBKDF2
    @return PVSS_TRUE if the password is identical, else PVSS_FALSE is returned.
    @classification public use, call
    */
  static PVSSboolean checkPassword(const char *passwd, const CharString &passwordHash);

  /** get the force permission set of my user
    @return the force permission set
    @classification ETM internal
    */
  static const Bit32Var *getUserForceSet()
  { return getUserForceSet(userId); }

  /** get the force permission set of the given user
   * @param id the user id
   * @return the force permission set
   * @classification ETM internal
   */
  static const Bit32Var *getUserForceSet(PVSSuserIdType id)
  { return ( userTable ? userTable->getUserForceSet(id) : 0 ); }

  // returns effective set of user/manager permissions

  /** Check if given permission set includes permission leven
      @param level the permission level to check
      @param permission a Bit32 variable with the permission bits
      @return PVSS_TRUE if the permission set includes this level
      @classification public use, call
  */
  static PVSSboolean hasPermission(PVSSuchar level, Bit32 permissions);

  /** Check permission level for current user.
    @param level the permission level to check
    @return PVSS_TRUE if user has permission for this level
    @classification public use, call
   */
  static PVSSboolean hasPermission(PVSSuchar level);

  /** Check permission level for a wellknown user on a specific manager.
    @param level the permission level to check
    @param userId the user to check
    @param manId the manager to check for
    @return PVSS_TRUE if user has permission for this level and manager
    @classification public use, call
   */
  static PVSSboolean hasUserPermission(PVSSuchar level, PVSSuserIdType userId,
      const ManagerIdentifier & manId);

  /** Check permission level for a wellknown user and the local manager.
    @param level the permission level to check
    @param userId the user to check
    @return PVSS_TRUE if user has permission for this level
    @classification public use, call
   */
  static PVSSboolean hasPermission(PVSSuchar level, PVSSuserIdType userId);

  /** sets the switch useAnswerHandler to PVSS_FALSE. Depricated!!
   * @classification ETM internal
   */
  static void dontUseAnswerHandler() { useAnswerHandler = PVSS_FALSE; }
  /** Get the switch useAnswerHandler. Depricated!!
   * @return PVSS_TRUE if set, else PVSS_FALSE
   * @classification ETM internal
   */
  static PVSSboolean getUseAnswerHandler() { return useAnswerHandler; }

  /** Get pointer to the single instance of the manager class.
    @return pointer to the manager
    @classification public use, call
   */
  static Manager *getManPtr() { return manPtr; }

  /** Get Access to the PmonTable
    @classification ETM internal
   */
  const PmonTable *getPmonTable() const;

  /** @name Datapoint type manipulation functions
   * @{
   */
  /** Create a new datapoint type. You need a type definition. A new DpTypeId will be
   * allocated by the DataManager. The newly created type and its ID will be notified
   * via the dpTypeCreate() callback
   *
   * @param dptDef the definition of the new datapoint type
   * @param wait a WaitForAnswer object to handle the answer (maybe error!). The object is deleted by the framework.a
   * @param del determines whether the WaitForAnswer object is deleted by the framework. Default is PVSS_TRUE
   * @param system the system to create the datapoint type on. Defaults to the default system.
   * @return PVSS_TRUE if message has been sent - to recognize an error you must use the answer handler
   */
  static PVSSboolean dpTypeCreate(const DpTypeDefinition & dptDef, WaitForAnswer *wait = 0,
      PVSSboolean del = PVSS_TRUE, SystemNumType system = DpIdentification::getDefaultSystem());

  /** Modify a datapoint type.
   *
   * The new type definition either replaces the old type or is added as
   * a subtree to the old type's root node. The caller must make sure
   * to use the same internal structure as the type to be modified.
   * Types with non-continuous or unordered element IDs can only
   * be modified with the append flag set to PVSS_TRUE.
   *
   * @param dptId the number of the datapoint type to modify
   * @param dptDef the definition of the modified datapoint type
   * @param append if PVSS_TRUE (default) the definition is added as a new node beneath the root element
   *        if PVSS_FALSE the definition replaces the datapoint type
   * @param wait a WaitForAnswer object to handle the answer (maybe error!). The object is deleted by the framework.
   * @param del determines whether the WaitForAnswer object is deleted by the framework. Default is PVSS_TRUE
   * @param system the system to change the datapoint type on. Defaults to the default system.
   * @return PVSS_TRUE if message has been sent - to recognize an error you must use the answer handler
   */
  static PVSSboolean dpTypeChange(DpTypeId dptId, const DpTypeDefinition & dptDef, PVSSboolean append = 1,
      WaitForAnswer *wait = 0, PVSSboolean del = PVSS_TRUE,
      SystemNumType system = DpIdentification::getDefaultSystem());

  /** Modify a datapoint type.
  *
  * The new type definition either replaces the old type or is added as
  * a subtree to an old type's node. The caller must make sure
  * to use the same internal structure as the type to be modified.
  * Types with non-continuous or unordered element IDs can only
  * be modified with the append flag set to PVSS_TRUE.
  *
  * @param dptId the number of the datapoint type to modify
  * @param dptDef the definition of the modified datapoint type
  * @param fatherNode where to append the new child. If fatherNode is NULL then the type will be replaced, else the new type will be put under the father
  * @param wait a WaitForAnswer object to handle the answer (maybe error!). The object is deleted by the framework.
  * @param del determines whether the WaitForAnswer object is deleted by the framework. Default is PVSS_TRUE
  * @param system the system to change the datapoint type on. Defaults to the default system.
  * @return PVSS_TRUE if message has been sent - to recognize an error you must use the answer handler
  */
  static PVSSboolean dpTypeChange(DpTypeId dptId, const DpTypeDefinition & dptDef, const DpTypeNode *fatherNode,
    WaitForAnswer *wait = 0, PVSSboolean del = PVSS_TRUE,
    SystemNumType system = DpIdentification::getDefaultSystem());

  /** Delete a datapoint type.
   * @param dptId the number of the datapoint type to delete
   * @param wait a WaitForAnswer object to handle the answer (maybe error!). The object is deleted by the framework.
   * @param del determines whether the WaitForAnswer object is deleted by the framework. Default is PVSS_TRUE
   * @param system the system to delete the datapoint type on. Defaults to the default system.
   * @return PVSS_TRUE if message has been sent - to recognize an error you must use the answer handler
   */
  static PVSSboolean dpTypeDelete(DpTypeId dptId, WaitForAnswer *wait = 0, PVSSboolean del = PVSS_TRUE,
    SystemNumType system = DpIdentification::getDefaultSystem());

  /** Construct a DpTypeDefinition for an existing datapoint type.
    * @deprecated, use dpTypeGet(dptId, PVSS_TRUE, system) instead
    */
  static DpTypeDefinition * dpTypeGet(DpTypeId dptId, SystemNumType system = DpIdentification::getDefaultSystem());

  /** Construct a DpTypeDefinition for an existing datapoint type.
   * @param dptId the number of the datapoint type to delete.
   * @param includeTypeRef whther to include elements of references types
   * @param system the system containing the datapoint type.
   * @return a pointer to the DpTypeDefinition object corresponding to the
   *         datapoint type. Returns a 0 pointer if
   *         - the type does not exist
   *         - the manager does not have a DpTypeContainer
   *         - the manager does not have a DpIdentification
   *         - building the DpTypeDefinition fails
   *         The Manager yields possession of the object.
   */
  static DpTypeDefinition * dpTypeGet(DpTypeId dptId, PVSSboolean includeTypeRef, SystemNumType system = DpIdentification::getDefaultSystem());
  /// @}

  /** Create a new datapoint. You need a name and a dp-type to create a new datapoint.
    @param dpName the name of the new datapoint
    @param typeId a valid datapoint type id
    @param wait a WaitForAnswer object to handle the answer (maybe error!). The object is deleted by the framework.
    @param system the PVSS-II system to create the datapoint for. this param defaults to the default system
    @return PVSS_TRUE if message has been sent - to recognize an error you must use the answer handler
    @classification public use, call
   */
  static PVSSboolean dpCreate(const CharString &dpName, DpTypeId typeId, WaitForAnswer *wait,
      SystemNumType system = DpIdentification::getDefaultSystem());

  /** Create a new datapoint. You need a name and a dp-type to create a new datapoint. Depricated!!
    @param dpName the name of the new datapoint (the paramLang is used)
    @param typeId a valid datapoint type id
    @param wait a WaitForAnswer object to handle the answer (maybe error!). The object is deleted by the framework.
    @param system the PVSS-II system to create the datapoint for. this param defaults to the default system
    @return PVSS_TRUE if message has been sent - to recognize an error you must use the answer handler
    @classification public use, call
   */
  static PVSSboolean dpCreate(const LangText &dpName, DpTypeId typeId, WaitForAnswer *wait,
      SystemNumType system = DpIdentification::getDefaultSystem());

  /** Create a new datapoint. You need a name and a dp-type and you can specify a dpId to create a new datapoint.
    if the dpId is not free, the dp is created with the next free dpId
    @param dpName the name of the new datapoint
    @param typeId a valid datapoint type id
    @param wait a WaitForAnswer object to handle the answer (maybe error!). The object is deleted by the framework.
    @param system the PVSS-II system to create the datapoint for. this param defaults to the default system
    @param dpNo the number that should be given to the dp
    @return PVSS_TRUE if message has been sent - to recognize an error you must use the answer handler
    @classification public use, call
   */
  static PVSSboolean dpCreate(const CharString &dpName, DpTypeId typeId, WaitForAnswer *wait, SystemNumType system, DpIdType dpNo);

  /** Create a new datapoint. You need a name and a dp-type and you can specify a dpId to create a new datapoint. Depricated!!
    if the dpId is not free, the dp is created with the next free dpId
    @param dpName the name of the new datapoint (the paramLang is used)
    @param typeId a valid datapoint type id
    @param wait a WaitForAnswer object to handle the answer (maybe error!). The object is deleted by the framework.
    @param system the PVSS-II system to create the datapoint for. this param defaults to the default system
    @param dpNo the number that should be given to the dp
    @return PVSS_TRUE if message has been sent - to recognize an error you must use the answer handler
    @classification public use, call
   */
  static PVSSboolean dpCreate(const LangText &dpName, DpTypeId typeId, WaitForAnswer *wait, SystemNumType system, DpIdType dpNo);

  /** Delete an existing datapoint.
    Only the system and datapoint fields of the dpIdentifier are used.
    @param dpId the system/datapoint to delete
    @param wait the answer handler to report any error. The object is deleted by the framework.
    @return PVSS_TRUE if message has been sent
    @classification public use, call
   */
  static PVSSboolean dpDelete(const DpIdentifier &dpId, WaitForAnswer *wait);


  /** Rename an existing datapoint.
    Only the system and datapoint id fields of the DpIdentifier are used.
    @param dpId the system and datapoint id to rename
    @param name the new datapoint name
    @param wait the answer handler to report success or any error. The object is deleted by the framework.
    @return PVSS_TRUE if the message has been sent
    @classificastion public use, call
   */
  static PVSSboolean dpRename(const DpIdentifier &dpId, const CharString &name, WaitForAnswer *wait);

  /** @name dpSet functions
    These functions are used to set the value of a datapoint element.
   */

  //@{
  /** Set the value of one datapoint element.
    The value change message goes to the event manager by default.
    @param dpId the fully specified dp identifier (fields from system to attribute are used)
    @param value the variable containing the new value - the type of variable must match the attribute type
    @param target the manager to send the message to, default is event
    @return PVSS_TRUE if the message has been sent
    @classification public use, call
   */
  static PVSSboolean dpSet(const DpIdentifier &dpId, const Variable &value,
      const ManagerIdentifier &target = eventId);

  /** Set the value of one datapoint element and request an answer.
    The answer requested holds the new value or an error.
    The message is sent to the event
    @param dpId the fully specified dp identifier (fields from system to attribute are used)
    @param value the variable containing the new value - the type of variable must match the attribute type
    @param wait the WaitForAnswer object to handle the new value / error
    @param del the answer handler should be deleted when the message has been received (default).
    on setting this param to PVSS_FALSE the caller is responsible for deleting the answer handler.
    @return PVSS_TRUE if the message has been sent
    @classification public use, call
   */
  static PVSSboolean dpSet(const DpIdentifier &dpId, const Variable &value,
      WaitForAnswer *wait, PVSSboolean del = PVSS_TRUE);
  /** Set the value of one datapoint element and request an answer.
    The answer requested holds the new value or an error.
    The message could be sent to any manager.
    @param dpId the fully specified dp identifier (fields from system to attribute are used)
    @param value the variable containing the new value - the type of variable must match the attribute type
    @param target the manager to send the message to
    @param wait the WaitForAnswer object tho handle the new value / error
    @param del the answer handler should be deleted when the message has been received (default).
    on setting this param to PVSS_FALSE the caller is responsible for deleting the answer handler.
    @return PVSS_TRUE if the message has been sent
    @classification public use, call
   */
  static PVSSboolean dpSet(const DpIdentifier &dpId, const Variable &value,
      const ManagerIdentifier &target, WaitForAnswer *wait,
      PVSSboolean del = PVSS_TRUE);
  /** Set the values of several datapoint elements.
    For this you need a list of dpidentifier - value pairs.
    The value change message goes to the event manager by default.
    All changes are handled by one message which contains a group for each item in the list.
    This function is a shortcut for multiply calling the dpSet single functions.
    @param dpIdList a list containing dpid - value pairs
    @param target the manager to send the message to, default is event
    @return PVSS_TRUE if the message has been sent
    @classification public use, call
   */
  static PVSSboolean dpSet(const DpIdValueList &dpIdList, const ManagerIdentifier &target = eventId);
  /** Set the values of several datapoint elements and request an answer.
    Tor this you need a list of dpidentifier - value pairs.
    The value change message goes to the event manager by default.
    An answer is requested which holds the new value or an error.
    All changes are handled by one message which contains one group for each item in the list.
    This applies to the answer as well.
    This function is a shortcut for multiply calling the dpSet single functions.
    The message is sent to the event
    @param dpIdList a list containing dpid - value pairs
    @param wait the answer handler which should handle the new values
    @param del determines whether the answer handler should be deleted after processing the answer
    (default, PVSS_TRUE) or the caller is responsible for deleting it (PVSS_FALSE)
    @return PVSS_TRUE if the message has been sent
    @classification public use, call
   */
  static PVSSboolean dpSet(const DpIdValueList &dpIdList,
      WaitForAnswer *wait, PVSSboolean del = PVSS_TRUE);
  /** Set the values of several datapoint elements and request an answer.
    For this you need a list of dpidentifier - value pairs.
    The value change message goes to a specified manager.
    An answer is requested which holds the new value or an error.
    all changes are handled by one message which contains one group for each item in the list.
    This applies to the answer as well.
    This function is a shortcut for multiply calling the dpSet single functions.
    @param dpIdList a list containing dpid - value pairs
    @param target the manager to send the message to
    @param wait the answer handler which should handle the new values
    @param del determines whether the answer handler should be deleted after processing the answer
    (default, PVSS_TRUE) or the caller is responsible for deleting it (PVSS_FALSE)
    @return PVSS_TRUE if the message has been sent
    @classification public use, call
   */
  static PVSSboolean dpSet(const DpIdValueList &dpIdList,
      const ManagerIdentifier &target, WaitForAnswer *wait,
      PVSSboolean del = PVSS_TRUE);

  /** Set the value of one datapoint element with a given source time.
    The value change message goes to the event manager by default.
    @param originTime the source time for the value change.
    @param dpId the fully specified dp identifier (fields from system to attribute are used)
    @param value the variable containing the new value - the type of variable must match the attribute type
    @param target the manager to send the message to, default is event
    @return PVSS_TRUE if the message has been sent
    @classification public use, call
   */
  static PVSSboolean dpSetTimed(const TimeVar &originTime, const DpIdentifier &dpId,
      const Variable &value, const ManagerIdentifier &target = eventId);

  /** Set the value of one datapoint element with a given source time and request an answer.
    The answer requested holds the new value or an error.
    The message is sent to the event
    @param originTime the source time for the value change.
    @param dpId the fully specified dp identifier (fields from system to attribute are used)
    @param value the variable containing the new value - the type of variable must match the attribute type
    @param wait the WaitForAnswer object tho handle the new value / error
    @param del the answer handler should be deleted when the message has been received (default).
    on setting this param to PVSS_FALSE the caller is responsible for deleting the answer handler.
    @return PVSS_TRUE if the message has been sent
    @classification public use, call
   */
  static PVSSboolean dpSetTimed(const TimeVar &originTime, const DpIdentifier &dpId,
      const Variable &value, WaitForAnswer *wait,
      PVSSboolean del = PVSS_TRUE);

  /** Set the value of one datapoint element with a given source time and request an answer.
    The answer requested holds the new value or an error.
    @param originTime the source time for the value change.
    @param dpId the fully specified dp identifier (fields from system to attribute are used)
    @param value the variable containing the new value - the type of variable must match the attribute type
    @param target the manager to send the message to
    @param wait the WaitForAnswer object tho handle the new value / error
    @param del the answer handler should be deleted when the message has been received (default).
    on setting this param to PVSS_FALSE the caller is responsible for deleting the answer handler.
    @return PVSS_TRUE if the message has been sent
    @classification public use, call
   */
  static PVSSboolean dpSetTimed(const TimeVar &originTime, const DpIdentifier &dpId,
      const Variable &value, const ManagerIdentifier &target,
      WaitForAnswer *wait, PVSSboolean del = PVSS_TRUE);

  /** Set the values of several datapoint elements with a given source time.
    For this you need a list of dpidentifier - value pairs.
    The value change message goes to the event manager by default.
    All changes are handled by one message which contains a group for each item in the list.
    This function is a shortcut for multiply calling the dpSet single functions.
    @param originTime the source time for the value change.
    @param dpIdList a list containing dpid - value pairs
    @param target the manager to send the message to, default is event
    @return PVSS_TRUE if the message has been sent
    @classification public use, call
   */
  static PVSSboolean dpSetTimed(const TimeVar &originTime, const DpIdValueList &dpIdList,
      const ManagerIdentifier &target = eventId);

  /** Set the values of several datapoint elements with a given source time and request an answer.
    Tor this you need a list of dpidentifier - value pairs.
    The value change message goes to the event manager by default.
    An answer is requested which holds the new value or an error.
    All changes are handled by one message which contains one group for each item in the list.
    This applies to the answer as well.
    This function is a shortcut for multiply calling the dpSet single functions.
    The message is sent to the event
    @param originTime the source time for the value change.
    @param dpIdList a list containing dpid - value pairs
    @param wait the answer handler which should handle the new values
    @param del determines whether the answer handler should be deleted after processing the answer
    (default, PVSS_TRUE) or the caller is responsible for deleting it (PVSS_FALSE)
    @return PVSS_TRUE if the message has been sent
    @classification public use, call
   */
  static PVSSboolean dpSetTimed(const TimeVar &originTime, const DpIdValueList &dpIdList,
      WaitForAnswer *wait, PVSSboolean del = PVSS_TRUE);

  /** Set the values of several datapoint elements with a given source time and request an answer.
    For this you need a list of dpidentifier - value pairs.
    The value change message goes to a specified manager.
    An answer is requested which holds the new value or an error.
    all changes are handled by one message which contains one group for each item in the list.
    This applies to the answer as well.
    This function is a shortcut for multiply calling the dpSet single functions.
    @param originTime the source time for the value change.
    @param dpIdList a list containing dpid - value pairs
    @param target the manager to send the message to
    @param wait the answer handler which should handle the new values
    @param del determines whether the answer handler should be deleted after processing the answer
    (default, PVSS_TRUE) or the caller is responsible for deleting it (PVSS_FALSE)
    @return PVSS_TRUE if the message has been sent
    @classification public use, call
   */
  static PVSSboolean dpSetTimed(const TimeVar &originTime, const DpIdValueList &dpIdList,
      const ManagerIdentifier &target, WaitForAnswer *wait, PVSSboolean del = PVSS_TRUE);
  //@}

  /** @name The dpGet family
   */

  //@{
  /** Get the current value of one datapoint element
    The request goes to the event manager per default.
    An answer is requested which holds the value or an error.
    The message is sent to the event
    @param dpId the dp identifier to get the value for. The dp identifier may not be empty
    @param wait the answer handler which should handle the values
    @param del determines whether the answer handler should be deleted after processing the answer
    (default, PVSS_TRUE) or the caller is responsible for deleting it (PVSS_FALSE)
    @return PVSS_TRUE if the message has been sent
    @classification public use, call
   */
  static PVSSboolean dpGet(const DpIdentifier &dpId,
      WaitForAnswer *wait, PVSSboolean del = PVSS_TRUE);

  /** Get the current value of one datapoint element.
    An answer is requested which holds the value or an error.
    @param dpId the dp identifier to get the value for. The dp identifier may not be empty
    @param target the manager to send the message to
    @param wait the answer handler which should handle the values
    @param del determines whether the answer handler should be deleted after processing the answer
    (default, PVSS_TRUE) or the caller is responsible for deleting it (PVSS_FALSE)
    @return PVSS_TRUE if the message has been sent
    @classification public use, call
   */
  static PVSSboolean dpGet(const DpIdentifier &dpId, const ManagerIdentifier &target,
      WaitForAnswer *wait, PVSSboolean del = PVSS_TRUE);

  /** Get the current values of several datapoint elements.
    The request goes to the event manager per default.
    An answer is requested which holds the value or an error.
    Each request is placed in a separate group. this applies for the answer, too.
    The message is sent to the event
    @param dpIdList a list containing the dp identifiers to get the values for. The dp identifiers may not be empty
    @param wait the answer handler which should handle the values
    @param del determines whether the answer handler should be deleted after processing the answer
    (default, PVSS_TRUE) or the caller is responsible for deleting it (PVSS_FALSE)
    @return PVSS_TRUE if the message has been sent
    @classification public use, call
   */
  static PVSSboolean dpGet(const DpIdentList &dpIdList,
      WaitForAnswer *wait, PVSSboolean del = PVSS_TRUE);

  /** Get the current values of several datapoint elements.
    The request goes to the event manager per default.
    An answer is requested which holds the value or an error.
    Each request is placed in a separate group. this applies for the answer, too.
    @param dpIdList a list containing the dp identifiers to get the values for. The dp identifiers may not be empty
    @param target the manager to send the message to
    @param wait the answer handler which should handle the values
    @param del determines whether the answer handler should be deleted after processing the answer
    (default, PVSS_TRUE) or the caller is responsible for deleting it (PVSS_FALSE)
    @return PVSS_TRUE if the message has been sent
    @classification public use, call
   */
  static PVSSboolean dpGet(const DpIdentList &dpIdList, const ManagerIdentifier &target,
      WaitForAnswer *wait, PVSSboolean del = PVSS_TRUE);

  /** @name The dpGetMaxAge family
   */

  //@{
  /** Get the current value of one datapoint element
    The request goes to the event manager per default.
    If the value requested is older than a given timespan the
    value is updated before the answer holding either the value
    or an error is created.
    The message is sent to the event
    @param maxAge the maximum age of the value in milliseconds, if this timespan is exceeded
                  the values are updated before the answer is created
    @param dpId   the dp identifier to get the value for. The dp identifier may not be empty
    @param wait   the answer handler which should handle the values
    @param del    determines whether the answer handler should be deleted after processing the answer
    (default, PVSS_TRUE) or the caller is responsible for deleting it (PVSS_FALSE)
    @return PVSS_TRUE if the message has been sent
    @classification public use, call
   */
  static PVSSboolean dpGetMaxAge(PVSSulong maxAge, const DpIdentifier &dpId,
      WaitForAnswer *wait, PVSSboolean del = PVSS_TRUE);

  /** Get the current value of one datapoint element.
    If the value requested is older than a given timespan the
    value is updated before the answer holding either the value
    or an error is created.
    @param maxAge the maximum age of the value in milliseconds, if this timespan is exceeded
                  the values are updated before the answer is created
    @param dpId the dp identifier to get the value for. The dp identifier may not be empty
    @param target the manager to send the message to
    @param wait the answer handler which should handle the values
    @param del determines whether the answer handler should be deleted after processing the answer
    (default, PVSS_TRUE) or the caller is responsible for deleting it (PVSS_FALSE)
    @return PVSS_TRUE if the message has been sent
    @classification public use, call
   */
  static PVSSboolean dpGetMaxAge(PVSSulong maxAge, const DpIdentifier &dpId, const ManagerIdentifier &target,
      WaitForAnswer *wait, PVSSboolean del = PVSS_TRUE);

  /** Get the current values of several datapoint elements.
    The request goes to the event manager per default.
    If the value requested is older than a given timespan the
    value is updated before the answer holding either the value
    or an error is created.
    Each request is placed in a separate group. this applies for the answer, too.
    The message is sent to the event
    @param maxAge the maximum age of the value in milliseconds, if this timespan is exceeded
                  the values are updated before the answer is created
    @param dpIdList a list containing the dp identifiers to get the values for. The dp identifiers may not be empty
    @param wait the answer handler which should handle the values
    @param del determines whether the answer handler should be deleted after processing the answer
    (default, PVSS_TRUE) or the caller is responsible for deleting it (PVSS_FALSE)
    @return PVSS_TRUE if the message has been sent
    @classification public use, call
   */
  static PVSSboolean dpGetMaxAge(PVSSulong maxAge, const DpIdentList &dpIdList,
      WaitForAnswer *wait, PVSSboolean del = PVSS_TRUE);

  /** Get the current values of several datapoint elements.
    The request goes to the event manager per default.
    If the value requested is older than a given timespan the
    value is updated before the answer holding either the value
    or an error is created.
    Each request is placed in a separate group. this applies for the answer, too.
    @param maxAge the maximum age of the value in milliseconds, if this timespan is exceeded
                  the values are updated before the answer is created
    @param dpIdList a list containing the dp identifiers to get the values for. The dp identifiers may not be empty
    @param target the manager to send the message to
    @param wait the answer handler which should handle the values
    @param del determines whether the answer handler should be deleted after processing the answer
    (default, PVSS_TRUE) or the caller is responsible for deleting it (PVSS_FALSE)
    @return PVSS_TRUE if the message has been sent
    @classification public use, call
   */
  static PVSSboolean dpGetMaxAge(PVSSulong maxAge, const DpIdentList &dpIdList, const ManagerIdentifier &target,
      WaitForAnswer *wait, PVSSboolean del = PVSS_TRUE);

 /** Check whether a DpIdentList can be used for a dpGetMaxAge request.
   *
   * The function checks if all DpIdentifiers in the list refer to the
   * proper config (_original or _online) and at least one refers to a
   * value attribute (either _value or _process_value).
   *
   * @param dpIdList a list containing the DpIdentifiers to get the values for
   * @return true if the DpIdentList can be used in a MaxAge Request
   *         false otherwise
   * @classification public use, call
   */
  static bool isValidMaxAgeRequest(const DpIdentList & dpIdList);

 /** Check whether a DpIdentifier can be used for a dpGetMaxAge request
   *
   * The function checks if the DpIdentifier refers to the proper
   * config (_original or _online) and to the proper attribute (_value
   * or  _process_value).
   *
   * @param dpId the DpIdentifier to get the value for
   * @return true if the DpIdentifier can be used in a MaxAge Request
   *         false otherwise
   * @classification public use, call
   */
  static bool isValidMaxAgeRequest(const DpIdentifier & dpId);

  /** Get the value of one datapoint element at a given time.
    The request goes to the event manager per default.
    An answer is requested which holds the value or an error.
    The message is sent to the event
    @param forTime the time the request is for
    @param dpId the dp identifier to get the value for
    @param wait the answer handler which should handle the values
    @param del determines whether the answer handler should be deleted after processing the answer
    (default, PVSS_TRUE) or the caller is responsible for deleting it (PVSS_FALSE)
    @return PVSS_TRUE if the message has been sent
    @classification public use, call
   */
  static PVSSboolean dpGetAsynch(const TimeVar &forTime, const DpIdentifier &dpId,
      WaitForAnswer *wait, PVSSboolean del = PVSS_TRUE);

  /** Get the value of one datapoint element at a given time.
    An answer is requested which holds the value or an error.
    @param forTime the time the request is for
    @param dpId the dp identifier to get the value for
    @param target the manager to send the message to
    @param wait the answer handler which should handle the values
    @param del determines whether the answer handler should be deleted after processing the answer
    (default, PVSS_TRUE) or the caller is responsible for deleting it (PVSS_FALSE)
    @return PVSS_TRUE if the message has been sent
    @classification public use, call
   */
  static PVSSboolean dpGetAsynch(const TimeVar &forTime, const DpIdentifier &dpId,
      const ManagerIdentifier &target, WaitForAnswer *wait, PVSSboolean del = PVSS_TRUE);

  /** Get the values of several datapoint elements at a given time.
    The request goes to the event manager per default.
    An answer is requested which holds the value or an error.
    Each request is placed in a separate group. this applies for the answer, too.
    The message is sent to the event
    @param forTime the time the request is for
    @param dpIdList a list containing the dp identifiers to get the values for
    @param wait the answer handler which should handle the values
    @param del determines whether the answer handler should be deleted after processing the answer
    (default, PVSS_TRUE) or the caller is responsible for deleting it (PVSS_FALSE)
    @return PVSS_TRUE if the message has been sent
    @classification public use, call
   */
  static PVSSboolean dpGetAsynch(const TimeVar &forTime, const DpIdentList &dpIdList,
      WaitForAnswer *wait, PVSSboolean del = PVSS_TRUE);

  /** Get the values of several datapoint elements at a given time.
    The request goes to the event manager per default.
    An answer is requested which holds the value or an error.
    Each request is placed in a separate group. this applies for the answer, too.
    @param forTime the time the request is for
    @param dpIdList a list containing the dp identifiers to get the values for
    @param target the manager to send the message to
    @param wait the answer handler which should handle the values
    @param del determines whether the answer handler should be deleted after processing the answer
    (default, PVSS_TRUE) or the caller is responsible for deleting it (PVSS_FALSE)
    @return PVSS_TRUE if the message has been sent
    @classification public use, call
   */
  static PVSSboolean dpGetAsynch(const TimeVar &forTime, const DpIdentList &dpIdList,
      const ManagerIdentifier &target, WaitForAnswer *wait, PVSSboolean del = PVSS_TRUE);

  /** Get all values of one datapoint element of a time period.
    The request goes to the event manager.
    An answer is requested which holds the value or an error.
    @param start the start time of the request period
    @param stop the end time of the request period
    @param number request number additional values outside the request period.
    @param dpId the dp identifier to get the value for
    @param wait the answer handler which should handle the values
    @param del determines whether the answer handler should be deleted after processing the answer
    (default, PVSS_TRUE) or the caller is responsible for deleting it (PVSS_FALSE)
    @return PVSS_TRUE if the message has been sent
    @classification public use, call
   */
  static PVSSboolean dpGetPeriod(const TimeVar &start, const TimeVar &stop, PVSSushort number,
      const DpIdentifier &dpId, WaitForAnswer *wait, PVSSboolean del = PVSS_TRUE);

  /** Get all value of one datapoint element of a time period.
    An answer is requested which holds the value or an error.
    @param start the start time of the request period
    @param stop the end time of the request period
    @param number request number additional values outside the request period.
    @param dpId the dp identifier to get the value for
    @param target the manager to send the message to
    @param wait the answer handler which should handle the values
    @param del determines whether the answer handler should be deleted after processing the answer
    (default, PVSS_TRUE) or the caller is responsible for deleting it (PVSS_FALSE)
    @return PVSS_TRUE if the message has been sent
    @classification public use, call
   */
  static PVSSboolean dpGetPeriod(const TimeVar &start, const TimeVar &stop, PVSSushort number,
      const DpIdentifier &dpId, const ManagerIdentifier &target,
      WaitForAnswer *wait, PVSSboolean del = PVSS_TRUE);

  /** Get all values of several datapoint elements of a time period.
    The request goes to the event manager.
    An answer is requested which holds the value or an error.
    Each request is placed in a separate group. this applies for the answer, too.
    @param start the start time of the request period
    @param stop the end time of the request period
    @param number request number additional values outside the request period.
    @param dpIdList a list containing the dp identifiers to get the values for
    @param wait the answer handler which should handle the values
    @param del determines whether the answer handler should be deleted after processing the answer
    (default, PVSS_TRUE) or the caller is responsible for deleting it (PVSS_FALSE)
    @return PVSS_TRUE if the message has been sent
    @classification public use, call
   */
  static PVSSboolean dpGetPeriod(const TimeVar &start, const TimeVar &stop, PVSSushort number,
      const DpIdentList &dpIdList, WaitForAnswer *wait, PVSSboolean del = PVSS_TRUE);

  /** Get all values of several datapoint elements of a time period.
    An answer is requested which holds the value or an error.
    Each request is placed in a separate group. this applies for the answer, too.
    @param start the start time of the request period
    @param stop the end time of the request period
    @param number request number additional values outside the request period.
    @param dpIdList a list containing the dp identifiers to get the values for
    @param target the manager to send the message to
    @param wait the answer handler which should handle the values
    @param del determines whether the answer handler should be deleted after processing the answer
    (default, PVSS_TRUE) or the caller is responsible for deleting it (PVSS_FALSE)
    @return PVSS_TRUE if the message has been sent
    @classification public use, call
   */
  static PVSSboolean dpGetPeriod(const TimeVar &start, const TimeVar &stop, PVSSushort number,
      const DpIdentList &dpIdList, const ManagerIdentifier &target,
      WaitForAnswer *wait, PVSSboolean del = PVSS_TRUE);

  /** Get all values of several datapoint elements of a time period.
    An answer is requested which holds the value or an error.
    Each request is placed in a separate group. this applies for the answer, too.
    Allow multiple answers. Yield a handle to support request aborting.
    @param start  [IN] The start time of the request period.
    @param stop   [IN] The end time of the request period.
    @param number [IN] Request number of additional values outside the request period.
    @param dpIdList [IN] A list containing the DP identifiers to get the values for.
    @param reqId  [OUT] A handle identifying this request.
    @param wait   [IN] A callback object to receive the answer of the message.
    @param del    [IN] If PVSS_TRUE the manager class will delete the wait object,
                  after all answer messages are processed, or the request is aborted.
                  Otherwise, the calling function is responsible to do this.
   */
  static PVSSboolean dpGetPeriod(
    const TimeVar &start,
    const TimeVar &stop,
    PVSSushort number,
    const DpIdentList &dpIdList,
    PVSSulong &reqId,
    WaitForAnswer *wait,
    PVSSboolean del = PVSS_TRUE);

  /** Get all values of several datapoint elements of a time period.
    An answer is requested which holds the value or an error.
    Each request is placed in a separate group. this applies for the answer, too.
    Allow multiple answers. Yield a handle to support request aborting.
    @param start  [IN] The start time of the request period.
    @param stop   [IN] The end time of the request period.
    @param number [IN] Request number of additional values outside the request period.
    @param dpIdList [IN] A list containing the DP identifiers to get the values for.
    @param reqId  [OUT] A handle identifying this request.
    @param target [IN] The manager to send the message to.
    @param wait   [IN] A callback object to receive the answer of the message.
    @param del    [IN] If PVSS_TRUE the manager class will delete the wait object,
                  after all answer messages are processed, or the request is aborted.
                  Otherwise, the calling function is responsible to do this.
   */
  static PVSSboolean dpGetPeriod(
    const TimeVar &start,
    const TimeVar &stop,
    PVSSushort number,
    const DpIdentList &dpIdList,
    PVSSulong &reqId,
    const ManagerIdentifier &target,
    WaitForAnswer *wait,
    PVSSboolean del = PVSS_TRUE);


  //@}

  /** @name the dpConnect family
   */

  //@{
  /** Connect to one datapoint.
    If you don't use a HotLinkWaitForAnswer object
    you have to catch the hotlink messages and handle them by yourself.
    An answer is requested which holds the current value or an error.
    The message is sent to the event
    @param dpId the Datapoint to connect to
    @param wait an answer object to receive the answer (if you pass a HotLinkWaitForAnswer object
      it will also handle all future HotLink messages)
    @param del determines whether the Wait object should be deleted by the Manager
    (default, PVSS_TRUE) or the caller is responsible for deleting it (PVSS_FALSE)
    @classification public use, call
   */
  static PVSSboolean dpConnect(const DpIdentifier &dpId,
      WaitForAnswer *wait, PVSSboolean del = PVSS_TRUE);
  /** Connect to one datapoint but no hotlink if this manager changed the values.
    If you don't use a HotLinkWaitForAnswer object
    you have to catch the hotlink messages and handle them by yourself.
    An answer is requested which holds the current value or an error.
    The message is sent to the event
    @param dpId the Datapoint to connect to
    @param wait an answer object to receive the answer (if you pass a HotLinkWaitForAnswer object
      it will also handle all future HotLink messages)
    @param del determines whether the Wait object should be deleted by the Manager
    (default, PVSS_TRUE) or the caller is responsible for deleting it (PVSS_FALSE)
    @classification public use, call
   */
  static PVSSboolean dpConnectNoSource(const DpIdentifier &dpId,
      WaitForAnswer *wait, PVSSboolean del = PVSS_TRUE);

  /** Connect to one datapoint. You have to catch the holink messages and handle them
    by yourself. The message can be sent to any manager.
    @param dpId the Datapoint to connect to
    @param target the manager to send the message to, default is event
    @classification public use, call
   */
  static PVSSboolean dpConnect(const DpIdentifier &dpId,
      const ManagerIdentifier &target = eventId);
   /** Connect to one datapoint. You have to catch the holink messages and handle them
    by yourself. The message can be sent to any manager. No hotlink if this manager changed the values.
    @param dpId the Datapoint to connect to
    @param target the manager to send the message to, default is event
    @classification public use, call
   */
  static PVSSboolean dpConnectNoSource(const DpIdentifier &dpId,
      const ManagerIdentifier &target = eventId);

  /** Connect to one datapoint. You have to catch the holink messages and handle them
    by yourself. Prefere to use the respective function with a HotLinkWaitForAnswer object.
    An answer is requested which holds the current value or an error.
    The message can be sent to any manager.
    @param dpId the datapoint to connect to
    @param target the manager to send the message to
    @param wait an answer object to receive the answer.
    @param del determines whether the answer handler should be deleted after processing the answer
    (default, PVSS_TRUE) or the caller is responsible for deleting it (PVSS_FALSE)
    @classification public use, call
   */
  static PVSSboolean dpConnect(const DpIdentifier &dpId,
      const ManagerIdentifier &target, WaitForAnswer *wait,
      PVSSboolean del = PVSS_TRUE);
  /** Connect to one datapoint. You have to catch the holink messages and handle them
    by yourself. Prefere to use the respective function with a HotLinkWaitForAnswer object.
    An answer is requested which holds the current value or an error.
    The message can be sent to any manager. No hotlink if this manager changed the values.
    @param dpId the datapoint to connect to
    @param target the manager to send the message to
    @param wait an answer object to receive the answer.
    @param del determines whether the answer handler should be deleted after processing the answer
    (default, PVSS_TRUE) or the caller is responsible for deleting it (PVSS_FALSE)
    @classification public use, call
   */
  static PVSSboolean dpConnectNoSource(const DpIdentifier &dpId,
      const ManagerIdentifier &target, WaitForAnswer *wait,
      PVSSboolean del = PVSS_TRUE);

  /** Connect to several datapoints. You have to catch the holink messages and handle them
    by yourself. Prefere to use the respective function with a HotLinkWaitForAnswer object.
    An answer is requested which holds the current value or an error.
    The message is sent to the event.
    If the dpIdList has more than Resources::maxConnectMessageSize_ (default 100) an error
    will be created and false returned.
    @param dpIdList the datapoints to connect to
    @param wait an answer object to receive the answer.
    @param del determines whether the answer handler should be deleted after processing the answer
    (default, PVSS_TRUE) or the caller is responsible for deleting it (PVSS_FALSE)
    @classification public use, call
   */
  static PVSSboolean dpConnect(const DpIdentList &dpIdList,
      WaitForAnswer *wait, PVSSboolean del = PVSS_TRUE);
  /** Connect to several datapoints. You have to catch the holink messages and handle them
    by yourself. Prefere to use the respective function with a HotLinkWaitForAnswer object.
    An answer is requested which holds the current value or an error.
    No hotlink if this manager changed the values.
    The message is sent to the event.
    If the dpIdList has more than Resources::maxConnectMessageSize_ (default 100) an error
    will be created and false returned.
    @param dpIdList the datapoints to connect to
    @param wait an answer object to receive the answer.
    @param del determines whether the answer handler should be deleted after processing the answer
    (default, PVSS_TRUE) or the caller is responsible for deleting it (PVSS_FALSE)
    @classification public use, call
   */
  static PVSSboolean dpConnectNoSource(const DpIdentList &dpIdList,
      WaitForAnswer *wait, PVSSboolean del = PVSS_TRUE);

  /** Connect to several datapoints. You have to catch the holink messages and handle them
    by yourself. Prefere to use the respective function with a HotLinkWaitForAnswer object.
    The message can be sent to any manager.
    If the dpIdList has more than Resources::maxConnectMessageSize_ (default 100) an error
    will be created and false returned.
    @param dpIdList the datapoints to connect to
    @param target the manager to send the message to, default is event
    @classification public use, call
   */
  static PVSSboolean dpConnect(const DpIdentList &dpIdList,
      const ManagerIdentifier &target = eventId);
  /** Connect to several datapoints. You have to catch the holink messages and handle them
    by yourself. Prefere to use the respective function with a HotLinkWaitForAnswer object.
    The message can be sent to any manager.
    No hotlink if this manager changed the values.
    If the dpIdList has more than Resources::maxConnectMessageSize_ (default 100) an error
    will be created and false returned.
    @param dpIdList the datapoints to connect to
    @param target the manager to send the message to, default is event
    @classification public use, call
   */
  static PVSSboolean dpConnectNoSource(const DpIdentList &dpIdList,
      const ManagerIdentifier &target = eventId);

  /** Connect to several datapoints. You have to catch the holink messages and handle them
    by yourself. Prefere to use the respective function with a HotLinkWaitForAnswer object.
    An answer is requested which holds the current value or an error.
    The message can be sent to any manager.
    If the dpIdList has more than Resources::maxConnectMessageSize_ (default 100) an error
    will be created and false returned.
    @param dpIdList the datapoints to connect to
    @param target the manager to send the message to.
    @param wait a callback object to receive the answer. If wait is a HotLinkWaitForAnswer object
    you must call dpDisConnect with the same object.
    @param del determines whether this class shall delete the wait object
    (default, PVSS_TRUE) or the caller is responsible for deleting it (PVSS_FALSE)
    @classification public use, call
   */
  static PVSSboolean dpConnect(const DpIdentList &dpIdList,
      const ManagerIdentifier &target, WaitForAnswer *wait,
      PVSSboolean del = PVSS_TRUE);
  /** Connect to several datapoints. You have to catch the holink messages and handle them
    by yourself. Prefere to use the respective function with a HotLinkWaitForAnswer object.
    An answer is requested which holds the current value or an error.
    The message can be sent to any manager.
    No hotlink if this manager changed the values.
    If the dpIdList has more than Resources::maxConnectMessageSize_ (default 100) an error
    will be created and false returned.
    @param dpIdList the datapoints to connect to
    @param target the manager to send the message to.
    @param wait a callback object to receive the answer. If wait is a HotLinkWaitForAnswer object
    you must call dpDisConnect with the same object.
    @param del determines whether this class shall delete the wait object
    (default, PVSS_TRUE) or the caller is responsible for deleting it (PVSS_FALSE)
    @classification public use, call
   */
  static PVSSboolean dpConnectNoSource(const DpIdentList &dpIdList,
      const ManagerIdentifier &target, WaitForAnswer *wait,
      PVSSboolean del = PVSS_TRUE);

  // zugefuegt fuer die Verwaltung der corr..values (stat Fkt, event-lokal) TI 6467 26.9.00 WOKL
  /** Internal function for stat. Funcs. corr.._values called by event locally.
    The message is sent to the event
    @param dpIdList the datapoints to connect to
    @param wait a callback object to receive the answer. If wait is a HotLinkWaitForAnswer object
    you must call dpDisConnect with the same object.
    @param del determines whether this class shall delete the wait object
    @classification ETM internal
   */
  static PVSSboolean dpCorrConnect(const DpIdentList &dpIdList,
      HotLinkWaitForAnswer *wait, PVSSboolean del = PVSS_TRUE);


  /** Disconnect from one datapoint.
    The message can be sent to any manager.
    Only for dpConnects without an waitForAnswerObject, as the entries are not deleted in the connectionmanagement.
    @param dpId the datapoint to disconnect from
    @param target the manager to send the message to, default is event
    @classification public use, call
   */
  static PVSSboolean dpDisconnect(const DpIdentifier &dpId,
      const ManagerIdentifier &target = eventId);

  /** Disconnect from several datapoints.
    The datapoints must be listed in the same order as in the respective dpConnect call.
    The message can be sent to any manager.
    Only for dpConnects without an waitForAnswerObject, as the entries are not deleted in the connectionmanagement.
    @param dpIdList the datapoints to disconnect from
    @param target the manager to send the message to, default is event
    @classification public use, call
   */
  static PVSSboolean dpDisconnect(const DpIdentList &dpIdList,
      const ManagerIdentifier &target = eventId);

  /** Disconnect from one datapoint.
     The callback object must be the same as in the previous dpConnect call.
     @param dpId the datapoint to disconnect from
     @param wait the callback object to identify the dpConnect. The object is deleted by the framework.
     @param target the manager to send the message to, default is event
     @classification public use, call
   */
  static PVSSboolean dpDisconnect(const DpIdentifier &dpId,
      const HotLinkWaitForAnswer *wait, const ManagerIdentifier &target = eventId);

  /** Disconnect from several datapoints
    The datapoints must be listed in the same order as in the respective dpConnect call.
    This is the preferred function if you connected with a callback object.
    The message can be sent to any manager.
    @param dpIdList the datapoints to disconnect from
    @param wait the callback object to identify the dpConnect. The object is deleted by the framework.
    @param target the manager to send the message to, default is event
    @classification public use, call
   */
  static PVSSboolean dpDisconnect(const DpIdentList &dpIdList,
      const HotLinkWaitForAnswer *wait,
      const ManagerIdentifier &target = eventId);

  // fuer die statistischen Funktionen (stat Fkt, event-lokal) 26.9.00 WOKL
  /** Internal function for stat. Funcs. called by event locally.
    The message is sent to the event
    @param dpIdList the dpIdentifierList
    @param wait a callback object to receive the answer. If wait is a HotLinkWaitForAnswer object
    you must call dpDisConnect with the same object. The object is deleted by the framework.
    @classification ETM internal
   */
  static PVSSboolean dpCorrDisconnect(const DpIdentList &dpIdList,
      const HotLinkWaitForAnswer *wait);
  //@}

  // verschickt den Korrekturwert als Hotlink (stat Fkt, event-lokal) 26.9.00 WOKL
  /** Internal function for stat. Funcs. corr.._values called by event locally.
    The message is sent to the event
    @param group the DpVcGroup pointer
    @classification ETM internal
   */
  static void sendCorrHotLink( DpVCGroup *group );


  /** @name The alertConnect family
   */
  //@{
  /** Connect to given attribute of all datapoint elements. The datapoint and element
    part of the dpId-argument is ignored.
    The message is sent to the event
    @param dpId  The attribute to connect to
    @param wait  The answerhandler. When the answer to the connect message arrives
    the callback function wait->callBack will be called. If the answerHandler is of
    the type AlertHotLinkCallBack wait->alertHotLinkCallBack will be called for the
    answer and for the following hotlinks. To disconnect you must then call alertDisconnect
    with this answerhandler as the callback object.
    This argument may be a NULL pointer if you are not interested in the
    answer.
    @param del   If set to PVSS_TRUE the manager class will delete the answerhandler
    object wait, after the answer is precessed. Otherwise the calling function
    is responsible to do this.
    @return PVSS_TRUE if the connect message was sent, else PVSS_FALSE. A return value of
    PVSS_TRUE does not mean that the connect itself was successfull. You have still
    to check the answer message for any errors.
    @classification public use, call
   */
  static PVSSboolean alertConnect(const DpIdentifier &dpId,
      WaitForAnswer *wait, PVSSboolean del = PVSS_TRUE);

  /** Connect to given attribute of all datapoint elements. The datapoint and element
    part of the dpId-argument is ignored.
    @param dpId  The attribute to connect to
    @param target the manager to send the message to, default is event
    @return PVSS_TRUE if the connect message was sent, else PVSS_FALSE. A return value of
    PVSS_TRUE does not mean that the connect itself was successfull. You have still
    to check the answer message for any errors.
    @classification public use, call
   */
  static PVSSboolean alertConnect(const DpIdentifier &dpId,
      const ManagerIdentifier &target = eventId);

  /** Connect to given attribute of all datapoint elements. The datapoint and element
    part of the dpId-argument is ignored.
    @param dpId  The attribute to connect to
    @param target the manager to send the message to
    @param wait  The answerhandler. When the answer to the connect message arrives
    the callback function wait->callBack will be called. If the answerHandler is of
    the type AlertHotLinkCallBack wait->alertHotLinkCallBack will be called for the
    answer and for the following hotlinks. To disconnect you must then call alertDisconnect
    with this answerhandler as the callback object.
    This argument may be a NULL pointer if you are not interested in the
    answer.
    @param del   If set to PVSS_TRUE the manager class will delete the answerhandler
    object wait, after the answer is precessed. Otherwise the calling function
    is responsible to do this.
    @return PVSS_TRUE if the connect message was sent, else PVSS_FALSE. A return value of
    PVSS_TRUE does not mean that the connect itself was successfull. You have still
    to check the answer message for any errors.
    @classification public use, call
   */
  static PVSSboolean alertConnect(const DpIdentifier &dpId,
      const ManagerIdentifier &target, WaitForAnswer *wait,
      PVSSboolean del = PVSS_TRUE);

  /** Connect to given attributes of all datapoint elements. The datapoint and element parts
    of the DpIdentifier in the dpIdList-argument are ignored.
    The message is sent to the event

    @param dpIdList  A list of attributes to connect to
    @param wait  The answerhandler. When the answer to the connect message arrives
    the callback function wait->callBack will be called. If the answerHandler is of
    the type AlertHotLinkCallBack wait->alertHotLinkCallBack will be called for the
    answer and for the following hotlinks. To disconnect you must then call alertDisconnect
    with this answerhandler as the callback object.
    This argument may be a NULL pointer if you are not interested in the
    answer.
    @param del   If set to PVSS_TRUE the manager class will delete the answerhandler
    object wait, after the answer is precessed. Otherwise the calling function
    is responsible to do this.
    @return PVSS_TRUE if the connect message was sent, else PVSS_FALSE. A return value of
    PVSS_TRUE does not mean that the connect itself was successfull. You have still
    to check the answer message for any errors.
    @classification public use, call
   */
  static PVSSboolean alertConnect(const DpIdentList &dpIdList,
      WaitForAnswer *wait, PVSSboolean del = PVSS_TRUE);

  /** Connect to given attributes of all datapoint elements. The datapoint and element parts
    of the DpIdentifier in the dpIdList-argument are ignored.

    @param dpIdList  A list of attributes to connect to
    @param target the manager to send the message to, default is event
    @return PVSS_TRUE if the connect message was sent, else PVSS_FALSE. A return value of
    PVSS_TRUE does not mean that the connect itself was successfull. You have still
    to check the answer message for any errors.
    @classification public use, call
   */
  static PVSSboolean alertConnect(const DpIdentList &dpIdList,
      const ManagerIdentifier &target = eventId);

   /** Connect to given attributes of all datapoint elements. The datapoint and element parts
    of the DpIdentifier in the dpIdList-argument are ignored.

    @param dpIdList  A list of attributes to connect to
    @param target the manager to send the message to
    @param wait  The answerhandler. When the answer to the connect message arrives
    the callback function wait->callBack will be called. If the answerHandler is of
    the type AlertHotLinkCallBack wait->alertHotLinkCallBack will be called for the
    answer and for the following hotlinks. To disconnect you must then call alertDisconnect
    with this answerhandler as the callback object.
    This argument may be a NULL pointer if you are not interested in the
    answer.
    @param del   If set to PVSS_TRUE the manager class will delete the answerhandler
    object wait, after the answer is precessed. Otherwise the calling function
    is responsible to do this.
    @return PVSS_TRUE if the connect message was sent, else PVSS_FALSE. A return value of
    PVSS_TRUE does not mean that the connect itself was successfull. You have still
    to check the answer message for any errors.
    @classification public use, call
   */
  static PVSSboolean alertConnect(const DpIdentList &dpIdList,
      const ManagerIdentifier &target, WaitForAnswer *wait,
      PVSSboolean del = PVSS_TRUE);

  // alertConnectRetVisible (with return of visible alerts) family of functions

  /** Connect to given attribute of all datapoint elements.
    Only visible alarms will trigger a hotlink message.
    The message is sent to the event
    @param dpId  The attribute to connect to
    @param wait  The answerhandler. When the answer to the connect message arrives
    the callback functin wait->callBack will be called. This argument may
    be a NULL pointer if you are not interested in the answer.
    @param del   If set to PVSS_TRUE the manager class will delete the answerhandler
    object wait, after the answer is precessed. Otherwise the calling function
    is responsible to do this.
    @return PVSS_TRUE if the connect message was sent, else PVSS_FALSE. A return value of
    PVSS_TRUE does not mean that the connect itself was successfull. You have still
    to check the answer message for any errors.
    @classification public use, call
   */
  static PVSSboolean alertConnectRetVisible(const DpIdentifier &dpId,
      WaitForAnswer *wait, PVSSboolean del = PVSS_TRUE);

  /** Connect to given attribute of all datapoint elements.
    Only visible alarms will trigger a hotlink message.
    @param dpId  The attribute to connect to
    @param target the manager to send the message to, default is event
    @param wait  The answerhandler. When the answer to the connect message arrives
    the callback functin wait->callBack will be called. This argument may
    be a NULL pointer if you are not interested in the answer.
    @param del   If set to PVSS_TRUE the manager class will delete the answerhandler
    object wait, after the answer is precessed. Otherwise the calling function
    is responsible to do this.
    @return PVSS_TRUE if the connect message was sent, else PVSS_FALSE. A return value of
    PVSS_TRUE does not mean that the connect itself was successfull. You have still
    to check the answer message for any errors.
    @classification public use, call
   */
  static PVSSboolean alertConnectRetVisible(const DpIdentifier &dpId,
      const ManagerIdentifier &target, WaitForAnswer *wait,
      PVSSboolean del = PVSS_TRUE);

  /** Connect to given attribute of all datapoint elements.
    Only visible alerts will trigger a hotlink message.
    The message is sent to the event
    @param dpIdList  The list of attributes to connect to. The datapoint and element parts
    of the DpIdentifier in this list are ignored.
    @param wait  The answerhandler. When the answer to the connect message arrives
    the callback functin wait->callBack will be called. This argument may be
    a NULL pointer if you are not interested in the answer.
    @param del   If set to PVSS_TRUE the manager class will delete the answerhandler
    object wait, after the answer is precessed. Otherwise the calling function
    is responsible to do this.
    @return PVSS_TRUE if the connect message was sent, else PVSS_FALSE. A return value of
    PVSS_TRUE does not mean that the connect itself was successfull. You have still
    to check the answer message for any errors.
    @classification public use, call
   */
  static PVSSboolean alertConnectRetVisible(const DpIdentList &dpIdList,
      WaitForAnswer *wait, PVSSboolean del = PVSS_TRUE);

  /** Connect to given attribute of all datapoint elements.
    Only visible alerts will trigger a hotlink message.
    @param dpIdList  The list of attributes to connect to. The datapoint and element parts
    of the DpIdentifier in this list are ignored.
    @param target the manager to send the message to
    @param wait  The answerhandler. When the answer to the connect message arrives
    the callback functin wait->callBack will be called. This argument may be
    a NULL pointer if you are not interested in the answer.
    @param del   If set to PVSS_TRUE the manager class will delete the answerhandler
    object wait, after the answer is precessed. Otherwise the calling function
    is responsible to do this.
    @return PVSS_TRUE if the connect message was sent, else PVSS_FALSE. A return value of
    PVSS_TRUE does not mean that the connect itself was successfull. You have still
    to check the answer message for any errors.
    @classification public use, call
   */
  static PVSSboolean alertConnectRetVisible(const DpIdentList &dpIdList,
      const ManagerIdentifier &target, WaitForAnswer *wait,
      PVSSboolean del = PVSS_TRUE);

  // alertDisconnect family of functions

  /** Disconnect from given attribute of all datapoint elements.
    @param dpId  The attribute to disconnect from
    @param wait The callback object to identify the alertConnect or alertConnectRetVisible call.
    The object is deleted by the framework.
    @param target the manager to send the message to, default is event
    @return PVSS_TRUE if the disconnect message was sent, else PVSS_FALSE. A return value of
    PVSS_TRUE does not mean that the disconnect itself was successfull. You have still
    to check the answer message for any errors.
    @classification public use, call
   */
  static PVSSboolean alertDisconnect(const DpIdentifier &dpId,
      const AlertHotLinkWaitForAnswer *wait = 0, const ManagerIdentifier &target = eventId);

  /** Disconnect from a given list of attributes of all datapoint elements.
    @param dpIdList  The list of attributes to dicconnect from. They must be listed in the
    same order as in the corresponding connect message.
    @param wait The callback object to identify the alertConnect or alertConnectRetVisible call.
    The object is deleted by the framework.
    @param target the manager to send the message to, default is event
    @return PVSS_TRUE if the disconnect message was sent, else PVSS_FALSE. A return value of
    PVSS_TRUE does not mean that the disconnect itself was successfull. You have still
    to check the answer message for any errors.
    @classification public use, call
   */
  static PVSSboolean alertDisconnect(const DpIdentList &dpIdList,
      const AlertHotLinkWaitForAnswer *wait = 0, const ManagerIdentifier &target = eventId);

  //@}

  /** @name SQL function family
   */
  //@{
  /** Connect to the datapoints and attributes listed in the query string.
    The hotlink message contains only those datapoints whose attribtes have been changed.
    @param query  The SQL query string
    @param queryId Returns the query id. Use this ID to disconnect the query
    @param values Specifies whether to retrieve values or not
    @param target the manager to send the message to
    @param wait  A callback object to receive the answer of the query-connect message.
    Because the answer message contains the query id used later in the hotlink
    messages and in the disconnect call you shall process the
    answer message.
    @param del   If set to PVSS_TRUE the manager class will delete the callback object wait,
    after the answer message has been processed. Otherwise the calling function
    is responsible to do this.
    @return PVSS_TRUE if the message was sent successfully. This does not mean the query-connect
    was successful, you have still to check the answer message.
    @see See the online documentation for the SQL syntax.
    @classification public use, call
   */
  static PVSSboolean dpQueryConnectSingle(const CharString &query, PVSSulong &queryId,
      PVSSboolean values, const ManagerIdentifier &target, WaitForAnswer *wait,
      PVSSboolean del = PVSS_TRUE);

  /** Connect to the datapoints and attributes listed in the query string.
    The hotlink message contains only those datapoints whose attribtes have been changed.
    The message is sent to the event
    @param query  The SQL query string
    @param queryId Returns the query id. Use this ID to disconnect the query
    @param values Specifies whether to retrieve values or not
    @param wait  A callback object to receive the answer of the query-connect message.
    Because the answer message contains the query id used later in the hotlink
    messages and in the disconnect call you shall process the
    answer message.
    @param del   If set to PVSS_TRUE the manager class will delete the callback object wait,
    after the answer message has been processed. Otherwise the calling function
    is responsible to do this.
    @return PVSS_TRUE if the message was sent successfully. This does not mean the query-connect
    was successful, you have still to check the answer message.
    @see See the online documentation for the SQL syntax.
    @classification public use, call
   */
  static PVSSboolean dpQueryConnectSingle(const CharString &query, PVSSulong &queryId,
      PVSSboolean values, WaitForAnswer *wait, PVSSboolean del = PVSS_TRUE)
  {
    return Manager::dpQueryConnectSingle(query, queryId, values, Manager::eventId, wait, del);
  }

  /** Connect to the datapoints and attributes listed in the query string.
    The hotlink message contains only those datapoints whose attribtes have been changed.
    The message is sent to the event
    @param query  The SQL query string
    @param values Specifies whether to retrieve values or not
    @param wait  A callback object to receive the answer of the query-connect message.
    Because the answer message contains the query id used later in the hotlink
    messages and in the disconnect call you shall process the
    answer message.
    @param del   If set to PVSS_TRUE the manager class will delete the callback object wait,
    after the answer message has been processed. Otherwise the calling function
    is responsible to do this.
    @return PVSS_TRUE if the message was sent successfully. This does not mean the query-connect
    was successful, you have still to check the answer message.
    @see See the online documentation for the SQL syntax.
    @classification public use, call
   */
  static PVSSboolean dpQueryConnectSingle(const CharString &query,
      PVSSboolean values,
      WaitForAnswer *wait, PVSSboolean del = PVSS_TRUE);

  /** Connect to the datapoints and attributes listed in the query string.
    The hotlink message contains only those datapoints whose attribtes have been changed.
    @param query  The SQL query string
    @param values Specifies whether to retrieve values or not
    @param target the manager to send the message to
    @param wait  A callback object to receive the answer of the query-connect message.
    Because the answer message contains the query id used later in the hotlink
    messages and in the disconnect call you shall process the
    answer message.
    @param del   If set to PVSS_TRUE the manager class will delete the callback object wait,
    after the answer message has been processed. Otherwise the calling function
    is responsible to do this.
    @return PVSS_TRUE if the message was sent successfully. This does not mean the query-connect
    was successful, you have still to check the answer message.
    @see See the online documentation for the SQL syntax.
    @classification public use, call
   */
  static PVSSboolean dpQueryConnectSingle(const CharString &query,
      PVSSboolean values,
      const ManagerIdentifier &target, WaitForAnswer *wait,
      PVSSboolean del = PVSS_TRUE);

  /** Connect to the datapoints and attributes listed in the query string.
    The hotlink message contains all matching datapoints if any attribute has been changed.
    @param query  The SQL query string
    @param queryId Returns the query id. Use this ID to disconnect the query
    @param values Specifies whether to retrieve values or not
    @param target the manager to send the message to
    @param wait  A callback object to receive the answer of the query-connect message.
    Because the answer message contains the query id used later in the hotlink
    messages and in the disconnect call you shall process the
    answer message.
    @param del   If set to PVSS_TRUE the manager class will delete the callback object wait,
    after the answer message has been processed. Otherwise the calling function
    is responsible to do this.
    @return PVSS_TRUE if the message was sent successfully. This does not mean the query-connect
    was successful, you have still to check the answer message.
    @see See the online documentation for the SQL syntax.
    @classification public use, call
   */
  static PVSSboolean dpQueryConnectAll(const CharString &query, PVSSulong &queryId,
      PVSSboolean values, const ManagerIdentifier &target, WaitForAnswer *wait,
      PVSSboolean del = PVSS_TRUE);

  /** Connect to the datapoints and attributes listed in the query string.
    The hotlink message contains all matching datapoints if any attribute has been changed.
    The message is sent to the event
    @param query  The SQL query string
    @param queryId Returns the query id. Use this ID to disconnect the query
    @param values Specifies whether to retrieve values or not
    @param wait  A callback object to receive the answer of the query-connect message.
    Because the answer message contains the query id used later in the hotlink
    messages and in the disconnect call you shall process the
    answer message.
    @param del   If set to PVSS_TRUE the manager class will delete the callback object wait,
    after the answer message has been processed. Otherwise the calling function
    is responsible to do this.
    @return PVSS_TRUE if the message was sent successfully. This does not mean the query-connect
    was successful, you have still to check the answer message.
    @see See the online documentation for the SQL syntax.
    @classification public use, call
   */
  static PVSSboolean dpQueryConnectAll(const CharString &query, PVSSulong &queryId,
      PVSSboolean values, WaitForAnswer *wait, PVSSboolean del = PVSS_TRUE)
  {
    return Manager::dpQueryConnectAll(query, queryId, values, Manager::eventId, wait, del);
  }

  /** Connect to the datapoints and attributes listed in the query string.
    The hotlink message contains all matching datapoints if any attribute has been changed.
    The message is sent to the event
    @param query  The SQL query string
    @param values Specifies whether to retrieve values or not
    @param wait  A callback object to receive the answer of the query-connect message.
    Because the answer message contains the query id used later in the hotlink
    messages and in the disconnect call you shall process the
    answer message.
    @param del   If set to PVSS_TRUE the manager class will delete the callback object wait,
    after the answer message has been processed. Otherwise the calling function
    is responsible to do this.
    @return PVSS_TRUE if the message was sent successfully. This does not mean the query-connect
    was successful, you have still to check the answer message.
    @see See the online documentation for the SQL syntax.
    @classification public use, call
   */
  static PVSSboolean dpQueryConnectAll(const CharString &query,
      PVSSboolean values,
      WaitForAnswer *wait, PVSSboolean del = PVSS_TRUE);

  /** Connect to the datapoints and attributes listed in the query string.
    The hotlink message contains all matching datapoints if any attribute has been changed.
    @param query  The SQL query string
    @param values Specifies whether to retrieve values or not
    @param target the manager to send the message to
    @param wait  A callback object to receive the answer of the query-connect message.
    Because the answer message contains the query id used later in the hotlink
    messages and in the disconnect call you shall process the
    answer message.
    @param del   If set to PVSS_TRUE the manager class will delete the callback object wait,
    after the answer message has been processed. Otherwise the calling function
    is responsible to do this.
    @return PVSS_TRUE if the message was sent successfully. This does not mean the query-connect
    was successful, you have still to check the answer message.
    @see See the online documentation for the SQL syntax.
    @classification public use, call
   */
  static PVSSboolean dpQueryConnectAll(const CharString &query,
      PVSSboolean values,
      const ManagerIdentifier &target, WaitForAnswer *wait,
      PVSSboolean del = PVSS_TRUE);

  // dpQueryDisconnect family of functions
  /** Disconnect from a previous dpQueryConnectSingle or dpQueryConnectAll call.
    @param id    The query id, which was returned in the answer message of the corresponding
    connect call and all hotlink messages.
    @param wait The callbackobject of the connect. As the identification will be made over the id, this parameter can be NULL,
    the corresponding wait object will be deleted by the framework anyway.
    @return PVSS_TRUE if the message was sent successfully. This does not mean the query-disconnect
    was successful, you have still to check the answer message.
    @classification public use, call
   */
  static PVSSboolean dpQueryDisconnect(PVSSulong id, WaitForAnswer *wait);

  /** Disconnect from a previous dpQueryConnectSingle or dpQueryConnectAll call.
    @param id    The query id, which was returned in the answer message of the corresponding
    connect call and all hotlink messages.
    @param target the manager to send the message to
    @param wait obsolete parameter. The object is NOT deleted by the framework.
    @return PVSS_TRUE if the message was sent successfully. This does not mean the query-disconnect
    was successful, you have still to check the answer message.
    @classification public use, call
   */
  static PVSSboolean dpQueryDisconnect(PVSSulong id, const ManagerIdentifier &target, WaitForAnswer *wait);

  // dpQuery family of functions
  /** Query attributes of a set of datapoints with a SQL-like query string.
    The message is sent to the event
    @param query  The SQL query string
    @param wait  A callback object to receive the answer of the query-connect message.
    @param del   If set to PVSS_TRUE the manager class will delete the callback object wait,
    after the answer message has been processed. Otherwise the calling function
    is responsible to do this.
    @return PVSS_TRUE if the message was sent successfully. This does not mean the query-connect
    was successful, you have still to check the answer message.
    @see See the online documentation for the SQL syntax.
    @classification public use, call
   */
  static PVSSboolean dpQuery(const CharString &query,
      WaitForAnswer *wait, PVSSboolean del = PVSS_TRUE);

  /** Query attributes of a set of datapoints with a SQL-like query string.
    @param query  The SQL query string
    @param target the manager to send the message to
    @param wait  A callback object to receive the answer of the query-connect message.
    @param del   If set to PVSS_TRUE the manager class will delete the callback object wait,
    after the answer message has been processed. Otherwise the calling function
    is responsible to do this.
    @return PVSS_TRUE if the message was sent successfully. This does not mean the query-connect
    was successful, you have still to check the answer message.
    @see See the online documentation for the SQL syntax.
    @classification public use, call
   */
  static PVSSboolean dpQuery(const CharString &query,
      const ManagerIdentifier &target, WaitForAnswer *wait,
      PVSSboolean del = PVSS_TRUE);

  /** Query attributes of a set of datapoints with a SQL-like query string.
    Allow multiple answers. Yield a handle to support request aborting.
    @param query [IN] The SQL query string.
    @param reqId [OUT] A handle identifying this request.
    @param wait  [IN] A callback object to receive the answer of the query message.
    @param del   [IN] If PVSS_TRUE the manager class will delete the wait object,
                 after all answer messages are processed, or the request is aborted.
                 Otherwise, the calling function is responsible to do this.
   */
  static PVSSboolean dpQuery(
      const CharString &query,
      PVSSulong &reqId,
      WaitForAnswer *wait,
      PVSSboolean del = PVSS_TRUE);

  /** Query attributes of a set of datapoints with a SQL-like query string.
    Allow multiple answers. Yield a handle to support request aborting.
    @param query  [IN] The SQL query string.
    @param reqId  [OUT] A handle identifying this request.
    @param target [IN] the manager to send the message to
    @param wait   [IN] A callback object to receive the answer of the query message.
    @param del    [IN] If PVSS_TRUE the manager class will delete the wait object,
                  after all answer messages are processed, or the request is aborted.
                  Otherwise, the calling function is responsible to do this.
   */
   static PVSSboolean dpQuery(
       const CharString &query,
       PVSSulong &reqId,
       const ManagerIdentifier &target,
       WaitForAnswer *wait,
       PVSSboolean del = PVSS_TRUE);


  //@}

  //  alertSet family of functions
  /** Set alert values for datapoint elements
    For this you need an AlertList.
    The value change message goes to the event manager by default.
    @param aList a list containing AlertItems
    @param target the manager to send the message to, default is event
    @return PVSS_TRUE if the message has been sent
    @classification public use, call
   */
  static PVSSboolean alertSet(const AlertList &aList, const ManagerIdentifier &target = eventId);

  /** Set alert values for datapoint elements.
    For this you need an AlertList.
    The answer handler is invoked with the reply for the setValue message.
    The value change message goes to the event manager.
    @param aList a list containing AlertItems
    @param wait the answer handler
    @param del If set to PVSS_TRUE the manager class will delete the callback object wait,
    after the answer message has been processed. Otherwise the calling function
    is responsible to do this.
    @return PVSS_TRUE if the message has been sent
    @classification public use, call
   */
  static PVSSboolean alertSet(const AlertList &aList, WaitForAnswer *wait,
      PVSSboolean del = PVSS_TRUE);

  /** Set alert values for datapoint elements.
    For this you need an AlertList.
    The answer handler is invoked with the reply for the setValue message.
    @param aList a list containing AlertItems
    @param target the manager to send the message to
    @param wait the answer handler
    @param del If set to PVSS_TRUE the manager class will delete the callback object wait,
    after the answer message has been processed. Otherwise the calling function
    is responsible to do this.
    @return PVSS_TRUE if the message has been sent
    @classification public use, call
   */
  static PVSSboolean alertSet(const AlertList &aList, const ManagerIdentifier &target,
      WaitForAnswer *wait, PVSSboolean del = PVSS_TRUE);

  //  alertSetTimed family of functions
  /** Set alert values for datapoint elements
    For this you need an AlertList.
    The value change message goes to the event manager by default.
    @param originTime the source time for the alert value change.
    @param aList a list containing AlertItems
    @param target the manager to send the message to, default is event
    @return PVSS_TRUE if the message has been sent
    @classification public use, call
   */
  static PVSSboolean alertSetTimed(const TimeVar &originTime, const AlertList &aList,
                                   const ManagerIdentifier &target = eventId);

  /** Set alert values for datapoint elements.
    For this you need an AlertList.
    The answer handler is invoked with the reply for the setValue message.
    The value change message goes to the event manager.
    @param originTime the source time for the alert value change.
    @param aList a list containing AlertItems
    @param wait the answer handler
    @param del If set to PVSS_TRUE the manager class will delete the callback object wait,
    after the answer message has been processed. Otherwise the calling function
    is responsible to do this.
    @return PVSS_TRUE if the message has been sent
    @classification public use, call
   */
  static PVSSboolean alertSetTimed(const TimeVar &originTime, const AlertList &aList,
                                   WaitForAnswer *wait, PVSSboolean del = PVSS_TRUE);

  /** Set alert values for datapoint elements.
    For this you need an AlertList.
    The answer handler is invoked with the reply for the setValue message.
    @param originTime the source time for the alert value change.
    @param aList a list containing AlertItems
    @param target the manager to send the message to
    @param wait the answer handler
    @param del If set to PVSS_TRUE the manager class will delete the callback object wait,
    after the answer message has been processed. Otherwise the calling function
    is responsible to do this.
    @return PVSS_TRUE if the message has been sent
    @classification public use, call
   */
  static PVSSboolean alertSetTimed(const TimeVar &originTime, const AlertList &aList,
                                   const ManagerIdentifier &target, WaitForAnswer *wait,
                                   PVSSboolean del = PVSS_TRUE);

  /** Get alert values for datapoint elements.
    For this you need an AlertList.
    The answer handler is invoked with the reply for the getValue message.
    @param aList a list containing AlertItems
    @param target the manager to send the message to
    @param wait the answer handler
    @param del If set to PVSS_TRUE the manager class will delete the callback object wait,
    after the answer message has been processed. Otherwise the calling function
    is responsible to do this.
    @return PVSS_TRUE if the message has been sent
    @classification public use, call
   */
  static PVSSboolean alertGet(const AlertList &aList,
      const ManagerIdentifier &target, WaitForAnswer *wait, PVSSboolean del = PVSS_TRUE);

  // alertGetPeriod family of functions
  /** Get all alert values of one datapoint element of a time period.
    The request goes to the event manager.
    An answer is requested which holds the value or an error.
    @param start the start time of the request period
    @param stop the end time of the request period
    @param dpId the dp identifier to get the value for
    @param wait the answer handler which should handle the values
    @param del determines whether the answer handler should be deleted after processing the answer
    (default, PVSS_TRUE) or the caller is responsible for deleting it (PVSS_FALSE)
    @return PVSS_TRUE if the message has been sent
    @classification public use, call
   */
  static PVSSboolean alertGetPeriod(const TimeVar &start, const TimeVar &stop,
      const DpIdentifier &dpId, WaitForAnswer *wait,
      PVSSboolean del = PVSS_TRUE);
  /** Get all alert values of one datapoint element of a time period.
    An answer is requested which holds the value or an error.
    @param start the start time of the request period
    @param stop the end time of the request period
    @param dpId the dp identifier to get the value for
    @param target the manager to send the message to
    @param wait the answer handler which should handle the values
    @param del determines whether the answer handler should be deleted after processing the answer
    (default, PVSS_TRUE) or the caller is responsible for deleting it (PVSS_FALSE)
    @return PVSS_TRUE if the message has been sent
    @classification public use, call
   */
  static PVSSboolean alertGetPeriod(const TimeVar &start, const TimeVar &stop,
      const DpIdentifier &dpId, const ManagerIdentifier &target,
      WaitForAnswer *wait, PVSSboolean del = PVSS_TRUE);
  /** Get all alert values of several datapoint elements of a time period.
    The request goes to the event manager.
    An answer is requested which holds the value or an error.
    Each request is placed in a separate group. this applies for the answer, too.
    @param start the start time of the request period
    @param stop the end time of the request period
    @param dpIdList a list containing the dp identifiers to get the values for
    @param wait the answer handler which should handle the values
    @param del determines whether the answer handler should be deleted after processing the answer
    (default, PVSS_TRUE) or the caller is responsible for deleting it (PVSS_FALSE)
    @return PVSS_TRUE if the message has been sent
    @classification public use, call
   */
  static PVSSboolean alertGetPeriod(const TimeVar &start, const TimeVar &stop,
      const DpIdentList &dpIdList, WaitForAnswer *wait,
      PVSSboolean del = PVSS_TRUE);
  /** Get all alert values of several datapoint elements of a time period.
    An answer is requested which holds the value or an error.
    Each request is placed in a separate group. this applies for the answer, too.
    @param start the start time of the request period
    @param stop the end time of the request period
    @param dpIdList a list containing the dp identifiers to get the values for
    @param target the manager to send the message to
    @param wait the answer handler which should handle the values
    @param del determines whether the answer handler should be deleted after processing the answer
    (default, PVSS_TRUE) or the caller is responsible for deleting it (PVSS_FALSE)
    @return PVSS_TRUE if the message has been sent
    @classification public use, call
   */
  static PVSSboolean alertGetPeriod(const TimeVar &start, const TimeVar &stop,
      const DpIdentList &dpIdList, const ManagerIdentifier &target,
      WaitForAnswer *wait, PVSSboolean del = PVSS_TRUE);

  /** Get all alert values of several datapoint elements of a time period.
    An answer is requested which holds the value or an error.
    Each request is placed in a separate group. this applies for the answer, too.
    Allow multiple answers. Yield a handle to support request aborting.
    @param start  [IN] The start time of the request period.
    @param stop   [IN] The end time of the request period.
    @param dpIdList [IN] A list containing the DP identifiers to get the values for.
    @param reqId  [OUT] A handle identifying this request.
    @param wait   [IN] A callback object to receive the answer of the message.
    @param del    [IN] If PVSS_TRUE the manager class will delete the wait object,
                  after all answer messages are processed, or the request is aborted.
                  Otherwise, the calling function is responsible to do this.
   */
static PVSSboolean alertGetPeriod(
    const TimeVar &start,
    const TimeVar &stop,
    const DpIdentList &dpIdList,
    PVSSulong &reqId,
    WaitForAnswer *wait,
    PVSSboolean del = PVSS_TRUE);

  /** Get all alert values of several datapoint elements of a time period.
    An answer is requested which holds the value or an error.
    Each request is placed in a separate group. this applies for the answer, too.
    Allow multiple answers. Yield a handle to support request aborting.
    @param start  [IN] The start time of the request period.
    @param stop   [IN] The end time of the request period.
    @param dpIdList [IN] A list containing the DP identifiers to get the values for.
    @param reqId  [OUT] A handle identifying this request.
    @param target [IN] The manager to send the message to.
    @param wait   [IN] A callback object to receive the answer of the message.
    @param del    [IN] If PVSS_TRUE the manager class will delete the wait object,
                  after all answer messages are processed, or the request is aborted.
                  Otherwise, the calling function is responsible to do this.
   */
static PVSSboolean alertGetPeriod(
    const TimeVar &start,
    const TimeVar &stop,
    const DpIdentList &dpIdList,
    PVSSulong &reqId,
    const ManagerIdentifier &target,
    WaitForAnswer *wait,
    PVSSboolean del = PVSS_TRUE);

  /** Abort a pending query request (dpGetPeriod, alertGetPeriod, dpQuery).
    You must have previously called a API function variant that enables
    "message splitting" and returns a handle identifying the request.
    An abort message is sent to the DATA manager that processes the related query request.
    It is a hint for the DATA manager to stop all related activities.
    At any rate, no answer messages to the related query request are accepted any more,
    immediately after running this function. The wait object of the related query request
    will never be called back again. If the manager class is responsible for the life-time
    of the wait object, this function even deletes it.
    There is no wait object passed as parameter because the abort message itself is not answered.
    @param reqId  [IN] A handle identifying the request to abort.
    @return PVSS_TRUE if ABORT message has been successfully sent, PVSS_FALSE otherwise
  */
  static PVSSboolean abortRequest(PVSSulong reqId);

  /** Get the mass param dpidentifier.
    @param dpId the datapoint to query
    @param [out] mpId the mass param datapoint
    @result PVSS_TRUE if successful, else PVSS_FALSE
  */
  static PVSSboolean getMassParamId(const DpIdentifier &dpId, DpIdentifier &mpId);

  /** Get the dp identifier for a given datapoint name.
    The name consists of at least a datapoint name. Element names and further fields
    are optional but when given they must state a contemporary name.
    When the name is preceded by a @ sign this means we have an alias name for DP.EL.
    Wildcards are not allowed and conversion is only possible if the manager
    has received its dp identification container on startup.
    @param name the datapoint name (SYS:DP.EL:CF.DT.AT) must be filled from DP to AT, SYS is optional
    @param [out] dpId a reference to the dpIdentifier object which gets the answer
    @return PVSS_TRUE if conversion was successful.
    @classification public use, call
   */
  static PVSSboolean getId(const char *name, DpIdentifier &dpId );

  /** Get a list of dp identifiers for a given datapoint name with wildcards.
    The name consists of at least a datapoint name. Element names and further fields
    are optional but when given they must state a consecutive name.
    Wildcards are allowed. Conversion is only possible if the manager
    has received its dp identification container on startup.
    @param wildName the datapoint name (SYS:DP.EL:CF.DT.AT) with wildcards, SYS is optional
    @param [out] dpIdArr a reference to the dpIdentifier array which gets the answer
    @param [out] howMany the length of the dpIdentifier array
    @param typeId a dptype preselection (if != 0)
    @return PVSS_TRUE if conversion was successful.
    @classification public use, call
   */
  static PVSSboolean getIdSet(const char *wildName, DpIdentifier *&dpIdArr,
      PVSSlong &howMany, DpTypeId typeId = 0);

  /** Get the identifier for a type.
    @param typeName The type name
    @param [out] typeId   The type id for the type name
    @param sysNum   The system to look for the type.
    @return PVSS_TRUE if successfull
   */
  static PVSSboolean getTypeId(const CharString &typeName, DpTypeId &typeId,
      SystemNumType sysNum = DpIdentification::getDefaultSystem());

  /// Get the system id
  static PVSSboolean getSystemId(const CharString &sysName, SystemNumType &sysNum);

  /** Get the datapoint name for a given dp identifier.
    The dp identifier should at least contain a datapoint number.
    Further entries are optional but must be consecutive.
    Conversion is only possible if the manager
    has received its dp identification container on startup.
    @param dpId the dp identifier which name shall be retrieved
    @param [out] name the CharString which will be filled with the name
    @return PVSS_TRUE if conversion was successful.
    @classification public use, call
   */
  static PVSSboolean getName(const DpIdentifier &dpId, CharString &name);

  /** Get the datapoint name for a given dp identifier.
    The dp identifier should at least contain a datapoint number.
    Further entries are optional but must be consecutive.
    Conversion is only possible if the manager
    has received its dp identification container on startup.
    @param dpId the dp identifier which name shall be retrieved
    @param [out] name a pointer to a char * which gets the name. This function allocates the
    memory with new, the caller shall free the memory with delete[] name.
    @return PVSS_TRUE if conversion was successful.
    @classification public use, call
   */
  static PVSSboolean getName(const DpIdentifier &dpId, char *&name);

  /** Get the datapoint element name for a given alias.
    @param alias The alias of a datapoint element. A missing '@' is inserted.
    @param [out] name  The name of the datapoint element.
    @return PVSS_TRUE, if the alias could be resolved, else PVSS_FALSE
    @classification public use, call
  */
  static PVSSboolean getName(const char *alias, CharString &name);

  // Auch noch TI 2070: Fuer ErrHdl und aehnliches Klumpert
  /** Get the language independent datapoint name for a given dp identifier.
    The dp identifier should at least contain a datapoint number.
    Further entries are optional but must be consecutive.
    Conversion is only possible if the manager
    has received its dp identification container on startup.
    this is used for ErrHdl and other stuff.
    @param dpId the dp identifier which name shall be retrieved
    @param [out] name a pointer to a char * which gets the li name. This function allocates the
    memory with new, the caller shall free the memory with delete[] name.
    @return PVSS_TRUE if conversion was successful.
    @classification public use, call
   */
  static PVSSboolean getLIName(const DpIdentifier &dpId, char *&name);

# ifdef OS_FREEBSD
  /** Converts the dpId into the name. Only for freebsd.
    @param dpId the dp identifier which name shall be converted
    @param [out] name  The name of the datapoint element.
    @return PVSS_TRUE, if convert was successful, else PVSS_FALSE
    @classification ETM internal
  */
  static PVSSboolean convertIdToName(const DpIdentifier &dpId, char *&name);
#endif

  // TI 2070
  /** Get the datapoint name with language independent
    config, detail and attribute names for a given dp identifier.
    The dp identifier should at least contain a datapoint number.
    Further entries are optional but must be consecutive.
    Conversion is only possible if the manager
    has received its dp identification container on startup.
    @param dpId the dp identifier which name shall be retrieved
    @param [out] name a reference to a CharString which gets the value
    @param sys the system the datapoint belongs to. A system specified in the dpId parameter has precedence.
    @return PVSS_TRUE if conversion was successful.
    @classification public use, call
   */
  static PVSSboolean getLIName(const DpIdentifier &dpId, CharString &name, SystemNumType sys = DpIdentification::getDefaultSystem());

  /** Get the type name for a type id.
    @param typeId  The given type id
    @param [out] typeName The type name
    @param sysNum The system to query
    @result PVSS_TRUE if successful
    @classification public use, call
   */
  static PVSSboolean getTypeName(DpTypeId typeId, CharString &typeName,
      SystemNumType sysNum = DpIdentification::getDefaultSystem());

  /** Get the system name.
    @param sysNum The system to query
    @param [out] sysName The systemName
    @result PVSS_TRUE if successful
    @classification public use, call
   */
  static PVSSboolean getSystemName(SystemNumType sysNum, CharString &sysName);

  /** Get current system name.
    @param [out] sysName The systemName
    @result PVSS_TRUE if successful
    @classification public use, call
   */
  static PVSSboolean getSystemName(CharString &sysName);

  /** Set an alias on a dpName:dpElement duple.
    An alias must be a system unique string. You can set one alias per DP.EL duple.
    @param dpId the dp identifier to set the alias for; only the DP and EL part are used.
    @param alias the alias name in all known languages
    @param wait an answer handler to check for error
    @classification public use, call
   */
  static PVSSboolean setDpAlias(const DpIdentifier &dpId, const LangText &alias,
      WaitForAnswer *wait);

  /** Set a comment on a dpName:dpElement duple.
    A comment is a free string. however, only one comment per DP.EL duple can be set.
    @param dpId the dp identifier to set the alias for; only the DP and EL part are used.
    @param comment the comment in all known languages
    @param wait an answer handler to check for error. The object is deleted by the framework.
    @classification public use, call
   */
  static PVSSboolean setDpComment(const DpIdentifier &dpId, const LangText &comment,
      WaitForAnswer *wait);
  // TI 563 Irena
  // folgende Methoden dienen dem Setzen und Holen des Langtextes eines
  // Datenpunktelementes sowie deren Format und Einheit
  //  get the Comment
  /** Get the comment part from a datapoint comment.
    @param dpe the dp with element string
    @param [out] comment a LangTextVar to receive the comment
    @param mode handles the behaviour, what shall be returned if the comment does not exist
           see PVSS - help for more information
    @return DpIdentOK if the function was successfull
    @classification public use, call
   */
  static DpIdentificationResult dpGetComment(const TextVar &dpe, LangTextVar &comment,
      int mode = Resources::dpGetCommentMode);
  /** Get the comment part from a datapoint comment.
    The datapoint comment consists of unit, format and comment. This function retrieves
    only the comment part of this string.
    @param id the dpidentifier to get the comment from
    @param comment a LangTextVar to receive the comment
    @param mode handles the behaviour, what shall be returned if the comment does not exist
           see PVSS - help for more information
    @return DpIdentOK if the function was successfull
    @classification public use, call
   */
  static DpIdentificationResult dpGetComment(const DpIdentifier &id, LangTextVar &comment,
      int mode = Resources::dpGetCommentMode);

  //  get the Format
  /** Get the format part of the active language from a datapoint comment.
    @param dpe the dp with element string
    @param [out] format a CharString to receive the format
    @return DpIdentOK if the function was successfull
    @classification public use, call
   */
  static DpIdentificationResult dpGetFormat(const TextVar &dpe, CharString &format);
  /** Get the format part of all languages from a datapoint comment.
    @param dpe the dp with element string
    @param [out] format a CharString to receive the format
    @return DpIdentOK if the function was successfull
    @classification public use, call
   */
  static DpIdentificationResult dpGetFormat(const TextVar &dpe, LangTextVar &format);
  /** Get the format part of the active language from a datapoint comment.
    The datapoint comment consists of unit, format and comment. This function retrieves
    only the format part of this string.
    @param id the dpidentifier to get the format from
    @param [out] format a CharString to receive the format
    @return DpIdentOK if the function was successfull
    @classification public use, call
   */
  static DpIdentificationResult dpGetFormat(const DpIdentifier &id, CharString &format);
  /** Get the format part of all languages from a datapoint comment.
    The datapoint comment consists of unit, format and comment. This function retrieves
    only the format part of this string.
    @param id the dpidentifier to get the format from
    @param [out] format a CharString to receive the format
    @return DpIdentOK if the function was successfull
    @classification public use, call
   */
  static DpIdentificationResult dpGetFormat(const DpIdentifier &id, LangTextVar &format);

  //  get the Unit
  /** Get the unit part of the active language from a datapoint comment.
    @param dpe the dp with element string
    @param [out] unit a CharString to receive the unit
    @return DpIdentOK if the function was successfull
    @classification public use, call
   */
  static DpIdentificationResult dpGetUnit(const TextVar &dpe, CharString &unit);
  /** Get the unit part of all languages from a datapoint comment.
    @param dpe the dp with element string
    @param [out] unit a CharString to receive the unit
    @return DpIdentOK if the function was successfull
    @classification public use, call
   */
  static DpIdentificationResult dpGetUnit(const TextVar &dpe, LangTextVar &unit);
  /** Get the unit part of the active language from a datapoint comment.
    The datapoint comment consists of unit, format and comment. This function retrieves
    only the unit part of this string.
    @param id the dpidentifier to get the unit from
    @param [out] unit a CharString to receive the unit
    @return DpIdentOK if the function was successfull
    @classification public use, call
   */
  static DpIdentificationResult dpGetUnit(const DpIdentifier &id, CharString &unit);
  /** Get the unit part of all languages from a datapoint comment.
    The datapoint comment consists of unit, format and comment. This function retrieves
    only the unit part of this string.
    @param id the dpidentifier to get the unit from
    @param [out] unit a CharString to receive the unit
    @return DpIdentOK if the function was successfull
    @classification public use, call
   */
  static DpIdentificationResult dpGetUnit(const DpIdentifier &id, LangTextVar &unit);

  /** Set the comment part of a datapoint comment
    The datapoint comment consists of unit, format and comment. This function sets
    the comment part of this string only.
    @param dpId the datapoint whose comment shall be set
    @param comment a LangTextVar which holds the comment
    @param wait an answer object to receive the answer. The object is deleted by the framework.
    @classification public use, call
   */
  static PVSSboolean dpSetComment(const DpIdentifier &dpId, const LangTextVar &comment, WaitForAnswer *wait);

  /** Set the format part of a datapoint comment
    The datapoint comment consists of unit, format and comment. This function sets
    the format part of this string only.
    @param dpId the datapoint whose comment shall be set
    @param format the new format
    @param wait an answer object to receive the answer. The object is deleted by the framework.
    @classification public use, call
   */
  static PVSSboolean dpSetFormat(const DpIdentifier &dpId, const LangTextVar &format, WaitForAnswer *wait);

  /** Set the unit part of a datapoint format
    The datapoint comment consists of unit, format and comment. This function sets
    the unit part of this string only.
    @param dpId the datapoint whose comment shall be set
    @param unit the new unit
    @param wait an answer object to receive the answer. The object is deleted by the framework.
    @classification public use, call
   */
  static PVSSboolean dpSetUnit(const DpIdentifier &dpId, const LangTextVar &unit, WaitForAnswer *wait);
  // TI 563 Ende

  /** @name Access the type information of a datapoint
   */
  //@{
  /** Get father of given datapoint element.
    @param dpId The datapoint element for which the father is asked for.
    @param [out] father A reference to a DpIdentifier that will be set to the father.
    If the datapoint element is already the root node or if the father cannot
    be looked up, the result is undefined.
    @return PVSS_TRUE if successful.
    @classification public use, call
   */
  static PVSSboolean getFather(const DpIdentifier &dpId, DpIdentifier &father);

  /** Get root element for given datapoint
    @param dpId The datapoint element for which the root element is asked for.
    @param [out] root A reference to a DpIdentifier that will be set to the root.
    @return PVSS_TRUE if successful.
    @classification public use, call
   */
  static PVSSboolean getRoot(const DpIdentifier &dpId, DpIdentifier &root);

  /** Get the number of sons of a datapoint element
    @param dpId The datapoint element for which the number of sons is asked for
    @param [out] sons A references to an unsigned long that will receive the result.
    @return PVSS_TRUE if successful.
    @classification public use, call
   */
  static PVSSboolean getNumberOfSons(const DpIdentifier &dpId, unsigned long &sons);

  /** Get a son for a datapoint element
    @param dpId The datapoint element for which the son is asked for.
    @param sonNr The 0-based son index
    @param [out] son A reference to a DpIdentifier that will be set to the result.
    If there is no such son the result is undefined.
    @return PVSS_TRUE if successful.
    @classification public use, call
   */
  static PVSSboolean getSon(const DpIdentifier &dpId, unsigned long sonNr, DpIdentifier &son);

  /** Check if a datapoint element is a leaf, i.e. has no sons.
    @param dpId The datapoint element checked.

    @return PVSS_TRUE if successful and the datapoint element is a leaf.
    @classification public use, call
   */
  static PVSSboolean isLeaf(const DpIdentifier &dpId);

  /** Check if the datapoint element is the root element
    @param dpId The datapoint element checked
    @return PVSS_TRUE if successful and the datapoint element is the root element.
    @classification public use, call
   */
  static PVSSboolean isRoot(const DpIdentifier &dpId);

  /** Check if the datapoint element is of array type, This means this element may have
    only sons of a simple element type like int, dyn_float, ...
    @param dpId The datapoint element checked
    @return PVSS_TRUE if successful and the datapoint element is of array type.
    @classification public use, call
   */
  static PVSSboolean isArray(const DpIdentifier &dpId);

  /** Check if the datapoint element is of struct type. This means this element may have
    any number of sons of any type.
    @param dpId The datapoint element checked.
    @return PVSS_TRUE if successful and the datapoint element is of struct type.
    @classification public use, call
   */
  static PVSSboolean isStruct(const DpIdentifier &dpId);

  /** Check if the datapoint element is of reference type. This means this element is a
    reference to another datapoint type.
    @param dpId The datapoint element checked.
    @return PVSS_TRUE if successful and the datapoint element if of reference type.
    @classification public use, call
   */
  static PVSSboolean isReference(const DpIdentifier &dpId);

  /** Get the element type of a datapoint element.
    @param dpId The datapoint element the element type is asked for.
    @param [out] type A reference to a DpElementType which will receive the result.
    If the element type could not be resolved the result is undefined.
    @return PVSS_TRUE if successful.
    @classification public use, call
   */
  static PVSSboolean getElementType(const DpIdentifier &dpId, DpElementType &type);
  //@}

  /** Get the attribute value of an attribute.
    This function has to be defined for each manager - the basic function simply returns 0
    @param id a DpIdentifier with set DpId, element, config, detail and attribute.
    @param recurseUp currently not used, default PVSS_FALSE
    @return if the attribute is found, a new Variable is returned
     otherwise you get a 0-pointer as return value
    @classification public use, call
   */
  virtual Variable *getAttribut(const DpIdentifier &id, PVSSboolean recurseUp = PVSS_FALSE) const;

  /** tool function. installs a BCM server-port for manager connections.
    @param port the server port number
    @classification ETM internal
   */
  static void installServer(int port);

  /** Installs a BCM server-port for alive connections.
    @param port the server port number
    @classification ETM internal
   */
  static void installAlive(int port);

  /** Open the connection to a given manager, we are client.
    also for redu.
    @param connString: host and port as a string like "host:port"
    @param redConnString: host and port of redundant manager as a string like "host:port"
    @param destMan  the manager to connect to
    @param hostMan  how we identify us in the connection
    @param dontWait wait until we have the connection or timed out
    @return PVSS_TRUE if manager has been connected, PVSS_FALSE if not
    @classification ETM internal
   */
  static PVSSboolean connect(const CharString &connString, const CharString &redConnString,
      const ManagerIdentifier &destMan, const ManagerIdentifier &hostMan,
      PVSSboolean dontWait);

  // Simplicity
  /** Open the connection to a given manager, we are client.
    not for redu.
    @param connString: host and port as a string like "host:port"
    @param destMan  the manager to connect to
    @param hostMan  how we identify us in the connection
    @param dontWait wait until we have the connection or timed out
    @return PVSS_TRUE if manager has been connected, PVSS_FALSE if not
    @classification ETM internal
   */
  static PVSSboolean connect(const CharString &connString,
      const ManagerIdentifier &destMan, const ManagerIdentifier &hostMan,
      PVSSboolean dontWait);

  // Oldtimers
  /** Open the connection to a given manager, we are client.
    not for redu.
    @param host: the host
    @param portNr: the port
    @param destMan  the manager to connect to
    @param hostMan  how we identify us in the connection
    @param dontWait wait until we have the connection or timed out
    @return PVSS_TRUE if manager has been connected, PVSS_FALSE if not
    @classification ETM internal
   */
  static PVSSboolean connect(const CharString &host, unsigned short portNr,
      const ManagerIdentifier &destMan, const ManagerIdentifier &hostMan,
      PVSSboolean dontWait);

  /** Open the connection to a given manager, we are client.
    also dor redu.
    @param host: the host
    @param port: the port
    @param redHost: the redundant host
    @param redPort: the redundant port
    @param destMan  the manager to connect to
    @param hostMan  how we identify us in the connection
    @param dontWait wait until we have the connection or timed out
    @return PVSS_TRUE if manager has been connected, PVSS_FALSE if not
    @classification ETM internal
   */
  static PVSSboolean connect(const CharString &host, unsigned short port,
      const CharString &redHost, unsigned short redPort,
      const ManagerIdentifier &destMan, const ManagerIdentifier &hostMan,
      PVSSboolean dontWait);

  // dispatch
  /** the manager heartbeat.
    The dispatch function receives messages and sends the messages that are inserted with the send method in the internal send buffer.
    This function checks if there is something to do. If not it will wait  indefinitely until data arrives.
    @classification public use, call
   */
  static void dispatch();

  /** the manager heartbeat.
    The dispatch function receives messages and sends the messages that are inserted with the send method in the internal send buffer.
    It waits the given amount of time or shorter, if there was something to do.
    This fuction should be called repeatedly over time to enable the
    message layer to send and receive messages. When this function is not called, the manager
    will not receive any messages. However, it may spontaneously send messages if the
    outbound buffer is full. The timeout varies on the manager, for API managers a timeout
    of 0,1 to 0,01 secs will be appropriate.
    If sec and microSec are 0 it will just check if data are available and return immediately.
    @param [in] sec timeout (secs) to wait for incomming messages.
    @param [in] microSec timeout (msec) to wait for incoming messages.
    @classification public use, call
   */
  static void dispatch(long &sec, long &microSec);   // maximum time to wait for new messages

  // A dispatch that will wait the given amount of time in the select, but not call getCurrentTime
  /** the manager heartbeat.
    The dispatch function receives messages and sends the messages that are inserted with the send method in the internal send buffer.
    It waits the given amount of time or shorter, if there was something to do. If the timeout is 0 it will just check if data are available and return immediately.
    Alerternative function to the other dispatch functions.
    @param timeout secs to wait for incomming messages (you can also wait 0.05 secs).
    @classification public use, call
   */
  static void dispatch(double timeout);

  /** hook method for derived classes called inside local blocking loops.
      Some managers might need to do additional things while the Manager is inside
      a local blocking loop, e.g. inside connectToEvent(), connectToData(), etc.,
      e.g. the User Interface Manager needs to also handle the window system events.
      This implementation does nothing but is called inside all local blocking loops.
      @classification overload
    */
  virtual void loopHook();

  // timers
  /** function to start a timer.
    in a specific time (sec, msec) the itcIOHandler is triggered
    @param sec the seconds.
    @param usec the micro seconds.
    @param handler a pointer to the itcIOHandler.
    @classification public use, call
   */
  static void startTimer(long sec, long usec, itcIOHandler *handler);
  /** function to stop a timer.
    @param handler a pointer to the itcIOHandler.
    @classification public use, call
   */
  static void stopTimer(itcIOHandler *handler);

  /** Check if the event is fully initialized.
    @return PVSS_TRUE if initialized or else PVSS_FALSE
    @classification public use, call
   */
  virtual PVSSboolean isEvInitialized();

  /** Check the connection to the data manger.
    @return PVSS_TRUE if the data manager (or one of the redundant data managers) is connected
    @classification public use, call
   */
  static PVSSboolean isDataConnOpen();

  /** check the connection to event manager
    @return PVSS_TRUE if event manager (or one of the redundant event manavers) is connected
    @classification public use, call
   */
  static PVSSboolean isEvConnOpen();


  /** check the connection to a given manager
    @param man the manager connection to check
    @return PVSS_TRUE if manager is connected
    @classification public use, call
   */
  static PVSSboolean isConnOpen(const ManagerIdentifier &man);
  /** check the connection to the redundant replica of this manager
    @param man The manager whose redundant replica will be checked
    @return PVSS_TRUE if redundant replica is connected
    @classification public use, call
   */
  static PVSSboolean isRedConnOpen(const ManagerIdentifier &man);
  /** close the connection to a given manager and don't flush
    @param manager the manager connection to close
    @return PVSS_TRUE if manager was connected, PVSS_FALSE if not
    @classification public use, call

   */
  static PVSSboolean abortConnection(const ManagerIdentifier &manager);
  /** close the connection to a given manager and flush
    @param manager the manager connection to close
    @return PVSS_TRUE if manager was connected, PVSS_FALSE if not
    @classification public use, call
   */
  static PVSSboolean closeConnection(const ManagerIdentifier &manager);

  /** Send a SHUT_DOWN_MANAGER message (but only if the sending manager is DATA or EVENT),
      flush all pending data and close the connection to a given manager.
    @param manager the manager connection to close
    @param err the reason the connection is closed (e.g. LICENSE_EXPIRED)
    @return PVSS_TRUE if manager was connected, PVSS_FALSE if not
    @classification public use, call

   */
  static PVSSboolean closeConnection(const ManagerIdentifier &manager, const ErrClass &err);

  /** Callback for new connections
    Notify a new connection
    @param manager The manager which just opened the connection
    @return PVSS_TRUE if ok, PVSS_FALSE if not
    @classification ETM internal
   */
  static PVSSboolean newConnection(const ManagerIdentifier &manager);
  /** Callback for updates on an existing connections
    Notify a change to an existing connection
    this method is called for redundant connected managers if
    - the manager was connected to ev/data and now the connection was established to the second redundant partner
    - the manager was connected to both redundant partners and has lost a connection to one of them
    @param mId The manager to which we have now a connection or to which we lost it
    @param disconnect Flag if the the connection was lost (PVSS_TRUE) or a new connection was established (PVSS_FALSE)
    @classification ETM internal
   */
  static void updateConnection(const ManagerIdentifier &mId, PVSSboolean disconnect)
  {
    manPtr->handleManagerUpdate(mId, disconnect);
  }
  /** Callback for closed connections
    Notify a closed or lost connection
    @param mId the manager which has closed its connection (to us)
    @classification ETM internal
   */
  static void connectionClose(const ManagerIdentifier &mId)  { manPtr->doConnectionClose(mId); }

  /** send any message.
    @param msg the message to send
    @return PVSS_TRUE if the call was successfull, PVSS_FALSE otherwise
    @classification ETM internal
   */
  static PVSSboolean send(Msg &);

  /** send any message.
    @param msg the message to send
    @param target the manager to send to
    @return PVSS_TRUE if the call was successfull, PVSS_FALSE otherwise
    @classification ETM internal
   */
  static PVSSboolean send(Msg &, const ManagerIdentifier &);

  // send automatically to eventmanager
  /** Send a SysMsg to the event manager
    Use this function to send an SysMsg message. Ths message is sent to
    the destination in the msg, or, if empty, to the event manager.
    @param msg The message to send
    @return PVSS_TRUE if the call was successfull, PVSS_FALSE otherwise
    @classification public use, call
   */
  static PVSSboolean send(SysMsg &msg);

  // send to given destination
  /** Send a SysMsg to any manager.
    Use this function to send an SysMsg to any manager, e.g.
    a NameServerSysMsg to the data manager.
    @param msg the message to send
    @param target the manager to send the message to
    @classification public use, call
   */
  static PVSSboolean send(SysMsg &msg, const ManagerIdentifier &target);

  /** Send a DP-message to the event manager and request an answer.
    Use this function to send an arbitrary datapoint message to the event manager
    @param msg a datapoint message to send
    @param wait an answer handler to recieve the answer
    @param del Specifies whether the manager shall delete the answer object
    (default, PVSS_TRUE) or the caller will be responsible for it.
    @classification public use, call
   */
  static PVSSboolean send(DpMsg &msg, WaitForAnswer *wait = 0,
      PVSSboolean del = PVSS_TRUE);
  /** Send a DP-msg to any manager and request an answer.
    Use this function to send an arbitrary datapoint message to any manager.
    @param msg a datapoint message to send
    @param target the manager to send the message to
    @param wait an answer handler to recieve the answer
    @param del Specifies whether the manager shall delete the answer object
    (default, PVSS_TRUE) or the caller will be responsible for it.
    @classification public use, call
   */
  static PVSSboolean send(DpMsg &msg, const ManagerIdentifier &target,
      WaitForAnswer *wait = 0, PVSSboolean del = PVSS_TRUE);

  // get the opened connection (relevant for eventmanager only!)
  /** get the first connection.
    only relevant for the event manager
    @return a pointer to the first manager we are connected with or null is there is no first
    @classification ETM internal
   */
  static ManagerIdentifier *getFirstConnection();
  /** get the next connection.
    only relevant for the event manager
    @return a pointer to the next manager we are connected with or null if there is no next
    @classification ETM internal
   */
  static ManagerIdentifier *getNextConnection();

  // get the opened connections of a managertype in a DynVar
  /** get the manager numbers of opened connections of a manager type in a DynVar.
    @param t the manager type
    @return a const reference to the DynVar that stores all manager numbers of this type
    @classification ETM internal
   */
  const DynVar & getConnectManNum(ManagerType t) const    { return connData[t].connManNum; }
  /** get the start times of opened connections of a manager type in a DynVar.
    @param t the manager type
    @return a const reference to the DynVar that stores all start times of this type
    @classification ETM internal
   */
  const DynVar & getConnectStartTime(ManagerType t) const { return connData[t].connStartTime; }
  /** get the host names of opened connections of a manager type in a DynVar.
    @param t the manager type
    @return a const reference to the DynVar that stores all host names of this type
    @classification ETM internal
   */
  const DynVar & getConnectHostName(ManagerType t) const  { return connData[t].connHostName; }

  // Answer Handling
  /** clears the WaitforAnswer object from the answerList.
    @param ptr the WaitforAnswer object
    @classification ETM internal
   */
  static void clearCallBack(const WaitForAnswer *);
  /** clears the CallbackItems, related to the given manager from the answerList.
    @param mId the manager, we lost the connection to
    @classification ETM internal
   */
  static void removeDeadManager(const ManagerIdentifier &mId);
  /** inserts the callbackItem in the correct List depending on the message type.
    @param answer the DpMsgAnswer object, related to the callback item in the answerlist
    @classification ETM internal
   */
  static void insertAnswer(DpMsgAnswer *answer);
  /** returns the number of items in the answerList.
    Obsoleted by getNumberOfPendingAnswers
    @return the number of items
    @classification ETM internal
   */
  static unsigned int getNumberOfItems();
  /** returns the number of items in the answerList.
    @return the number of items
    @classification ETM internal
   */
  static unsigned int getNumberOfPendingAnswers();
  /** returns the number of items in the answerList related to the given manager.
    @param manId the Manager we expecting the answers from
    @return the number of items
    @classification ETM internal
   */
  static unsigned int getNumberOfPendingAnswers(const ManagerIdentifier &manId);

  /** returns if the given manager type is allowed to run under another user (than root).
    @param manT the managertype
    @return PVSS_TRUE, if there are more users allowed, or PVSS_FALSE if the manager only accepts root
    @classification ETM internal
   */
  static PVSSboolean isDefaultUserManager(PVSSuchar manT);

  /** Get current time (synchronised among replicas, if running redundant)
    @param [out] tim the current time
    @classification ETM internal
   */
  static void getSyncCurrentTime(TimeVar &tim);

  /** Get value for the given license option
    @param option the license options as CharString
    @return the value of the requested license option
    @classification ETM internal
   */
  static  int getLicenseOption(const CharString & option);

  /** Consume the given license option
    @param option the license options as CharString
    @param count the amount of licenses needed for this manager
    @callback the callback object
    @classification ETM internal
   */
  void getLicenseOption(const CharString& option,
                        unsigned count,
                        Manager::LicenseCallback callback);

  /** Check if a license option is available
    @param option the license options as CharString
    @param target the type of the requested quest
    @callback the callback object
    @classification ETM internal
   */
  void checkLicenseOptionExists(const CharString& option,
                                QuestTarget target,
                                Manager::LicenseCallback callback);

  /** Check if a license option is available - local info variant
    @param option the license options as CharString
    @param target the type of the requested quest
    @return the number of available licenses with the defined target, -1 if the target is not available
    @classification ETM internal
  */
  static int checkLicenseOptionExists(const CharString& option,
                                      QuestTarget target);

  /** Get license host information string for logging
    @return the host information
    @classification ETM internal
   */
  static CharString getLicenseHostInfo();

  /** Get license options information string for logging
    @param license the license
    @return the license option information string
    @classification ETM internal
   */
  static CharString getLicenseOptInfo( License& license);

  /** wait for system license message
    @classification ETM internal
   */
  static void waitForNextLicenseMsg(PVSSTime lastMsgTime);

  /** get the timestamp of the last license message
    @classification ETM internal
   */
  static PVSSTime getLastLicenseMsgTime() {return licenseMsgReceived;}

  /** tool function. print a status report to the given stream.
    @param [in,out] to the stream to print on
    @classification public use, call
   */
  virtual void reportStatus(std::ostream &to) const;

  /** tool function. print a status report to the given stream.
  @param [in,out] to the stream to print on
  @classification public use, call
  */
  void debugNFR(std::ostream &to) const;

  /** tool function. reports status to the reportstream (set in the resources) if a status is pending.
    @classification public use, call
   */
  void reportStatusIfPending() const;

  /** prefix check for connections from a client to a server
    @param target the server manager
    @param source the client manager
    @return PVSS_TRUE if the check is ok, PVSS_FALSE
    @classification ETM internal
   */
  virtual PVSSboolean prefixConnectFromClient(ManagerIdentifier &target, ManagerIdentifier &source);

  /** prefix check for connections from a server to a client
    @param target the client manager
    @param source the server manager (often ignored, as *this is used)
    @return PVSS_TRUE if the check is ok, PVSS_FALSE
    @classification ETM internal
   */
  virtual PVSSboolean prefixConnectFromServer(ManagerIdentifier &target, ManagerIdentifier &source);

  /** prefix check for connections from a server to a client
    @param target the client manager
    @param source the server manager (often ignored, as *this is used)
    @param initSysMsg the initial SysMsg that often contains params for the check
    @return PVSS_TRUE if the check is ok, PVSS_FALSE
    @classification ETM internal
   */
  virtual PVSSboolean prefixConnectFromServer(ManagerIdentifier &target, ManagerIdentifier &source,
                                              const InitSysMsg &initSysMsg);

  /** prefix check for connections from a server to a client
    @param target the client manager
    @param source the server manager (often ignored, as *this is used)
    @param initSysMsg the initial SysMsg that often contains params for the check
    @param failureReason [OUT] all ErrCodes other than NOERR will be sent via SHUT_DOWN_MANAGER message to the client
    @return PVSS_TRUE if the check is ok, else PVSS_FALSE
    @classification ETM internal
   */
  virtual PVSSboolean prefixConnectFromServer(ManagerIdentifier &target, ManagerIdentifier &source,
                                              const InitSysMsg &initSysMsg, ErrClass &failureReason);

  /** tool function. print a message statistic info to the given stream.
   *  The messages which occurred in the last interval are listed in total and
   *  per manager.
    @param [in,out] to the stream to print on
    @classification public use, call
   */
  static void messageStatInfo(std::ostream &to);

  /** function to create a new wait object
    @param itc DiagItcIOHandler used as input for the new wait obejct
    @return the new DiagHotLinkWaitForAnswer object
    @classification ETM internal
   */
  virtual HotLinkWaitForAnswer * newDiagWaitObject(DiagItcIOHandler &itc)
  {
    return(new DiagHotLinkWaitForAnswer(itc));
  }

  /** Check if this is a connection to a redundant manager pair
    @param manId the manager identificating the connection
    @return PVSS_TRUE if this connection is to a redundant manager pair, or PVSS_FALSE else
   */
  virtual  PVSSboolean  isRedundantConnection(const ManagerIdentifier &manId);

  /** Check if message has to be sent to the target manager
    @param target the manager identificating the connection
    @param msg the message we want to send
    @return PVSS_TRUE if the message has to be sent, or PVSS_FALSE else
   */
  virtual  PVSSboolean  reduSendMsgLogic(const ManagerIdentifier &target, const Msg &msg);

  /** Check if the message from the source manager has to be handled
    @param source the manager which sent the message
    @param msg the message we want to handle
    @return PVSS_TRUE if the message has to be handled, or PVSS_FALSE else
   */
  virtual  PVSSboolean  reduRecvMsgLogic(const ManagerIdentifier &source, const Msg &msg);

  /** Handle switch of manager active state
    @param man the manager which state shall be changed
    @param newState the newState of the manager
   */
  virtual  void  reduSwitchManagerStateLogic(const ManagerIdentifier &man, PVSSboolean newState);

  /** Handle switch of connection state
    @param man the manager which identifies the connection which state shall be changed
    @param newState the newState of the connection
   */
  virtual  void  reduSwitchConnectionStateLogic(const ManagerIdentifier &man, PVSSboolean newState);

  /** Determine the destination system of the message
    @param [in,out] msg the message we want to send
    @return PVSS_TRUE if the system was correct or we have corrected the system in the message
            PVSS_FALSE if we could not find the correct system
   */
  virtual  PVSSboolean setupSystem(Msg &msg) const;

  /** Setup the next distination on the route of a message
    @param [in,out] msg the message we want to send
    @return PVSS_TRUE if everything ok, PVSS_FALSE else
    @classification public use, overload, call setupRoutingForDistributedProject
   */
  virtual  PVSSboolean setupRouting(Msg &msg) const;

  // File transfer functions
  /** Request file list from server.
    @param target the manager to which the request is sent
    @param fileList the listed files
    @param options see Util::FileListOptions
    @return PVSS_TRUE if the request could be sent, PVSS_FALSE else
    @classification ETM internal
   */
  PVSSboolean requestFileList(const ManagerIdentifier &target, const DynVar &fileList, const Util::FileListOptions &options);
  /** Request file list from server.
    @param target the manager to which the request is sent
    @param fileList the listed files
    @param optionsList the options per file see Util::FileListOptions
    @return PVSS_TRUE if the request could be sent, PVSS_FALSE else
    @classification ETM internal
   */
  PVSSboolean  requestFileList(const ManagerIdentifier &target, const DynVar &fileList, const DynVar &optionsList);

  /** Server response with file list.
    @param target the manager that requested
    @param fileList the listed files
    @param statList the state of the files (size, time,...)
    @return PVSS_TRUE if ok, PVSS_FALSE else
    @classification ETM internal
   */
  virtual  PVSSboolean notifyFileList(const ManagerIdentifier &target, const DynVar &fileList, const DynVar &statList);

  /** Request transfer of one file from server
    @param target the manager to which the request is sent
    @param fileName the requested file name
    @param fileStat the state of the file (size, time,...)
    @return PVSS_TRUE if ok, PVSS_FALSE else
    @classification ETM internal
   */
  PVSSboolean  requestFileTransfer(const ManagerIdentifier &target, const CharString &fileName, RecVar *fileStat = 0);

  /** Abort file transfer for one file
    @param target the manager to/from which the filetransfer shall be canceled
    @param file the requested file name
    @return PVSS_TRUE if ok, PVSS_FALSE else
    @classification ETM internal
   */
  PVSSboolean  abortFileTransfer(const ManagerIdentifier &target, const CharString &file);

  /** Abort all transfers from / to manager
    @param target the manager to/from which all transfers shall be canceled. An empty target will cancel all transfers
    @return PVSS_TRUE if ok, PVSS_FALSE else
    @classification ETM internal
   */
  PVSSboolean  abortAllFileTransfers(const ManagerIdentifier &target);

  /** Get pending file transfers
    @return the number of pending filetransfers
    @classification ETM internal
   */
  long  getNumberOfPendingFileTransfers();

  /** Reset error state flag for file transfers.
      The flag is initially reset, but otherwise never automatically reset.
    @classification ETM internal
   */
  void resetFileTransferErrorState();

  /** Get error state flag for file transfers.
      The flag is set by any unsuccessful file transfer.
    @return error state flag
    @classification ETM internal
   */
  PVSSboolean isFileTransferInErrorState() const;

  /** Get the send buffer size
    @param manId the manager which buffersize is asked
    @return the send buffersize to the given manager
    @classification ETM internal
   */
  long  getSendBufferLength(const ManagerIdentifier &manId) const;

  /** Notify of a BCM buffer overflow.
    @param manId the manager which buffersize has an overflow
    @return PVSS_TRUE to close the connection (this is the default) - or PVSS_FALSE else.
    @classification overload
   */
  virtual PVSSboolean  handleBCMBufferOverflow(const ManagerIdentifier &manId);

  /** Check if Manager target is allowed to connect as user upn.
    @param target the manager we want to connect to
    @param upn the user per name
    @param groups the usergroups
    @param [out] userId the userId of the given user (upn)
    @return PVSS_TRUE if authorized to connect, else PVSS_FALSE
    @classification ETM internal
   */
  virtual PVSSboolean isAuthorizedToConnect( const ManagerIdentifier &target,
      const CharString &upn, const DynVar &groups, PVSSuserIdType &userId);

  /** Get the minimal allowed message version
    @return the minimal allowed message version
    @classification ETM internal
   */
  static PVSSushort myMinMsgVersion() { return(minMsgVersion_); }

  /** set internal flag to indicate console/admin module
    @return void
    @classification ETM internal
    */
  static void  setLicenseConsoleFlag();

  protected:

  /** Cleanup internal variables
   */
  static void cleanup();

  /** Change own replica number
    @param repl the new replica number
    @return PVSS_TRUE is change was successful, else PVSS_FALSE
    @classification ETM internal
   */
  static PVSSboolean setOwnReplica(PVSSuchar repl);

  /** Change own system number
    @param newSys the new system number
    @return PVSS_TRUE is change was successful, else PVSS_FALSE
    @classification ETM internal
   */
  static PVSSboolean  setOwnSystem(SystemNumType newSys);

  /** Connect to the data manger
    This function will connect the manager to the data manager and send the
    StartDpInitSysMsg. You specify in the call what information will be requested.
    @see StartDpInitSysMsg for a description of the flags
    @param needsForInit binary or-ed flags whether to request TypeContainer and / Identification.
    @param configNrList a list of the requested configs. Since no API manager handles configs this
    parameter is always 0.
    @param dontExit by default this function call will succeed in establishing a connection to
    the data manager or call exit the manager.
    If this flag is set to PVSS_TRUE the manager will not
    exit and the function may return without an established connection.
    @return PVSS_TRUE if the connect call to the data manager was successful
    @classification public use, call
   */
  static PVSSboolean connectToData(PVSSuchar needsForInit = 0, const DpConfigNrType *configNrList = 0,
      PVSSboolean dontExit = PVSS_FALSE);

  /** Connect to the event manager.
    @param dontExit by default the function will succeeed in establishing a connection to the
    event manger or the exit the manger.
    If this flag is set to PVSS_TRUE the manager will not
    exit and the function may return without an established connection.
    Note that the event manager may close the connection immedeately if there is no
    license for this manager. You are advised to check with Manager::isEvConnOpen if the
    connection is still open.
    @return PVSS_TRUE if the connect call to the event manager was successful
    @classification public use, call
   */
  static PVSSboolean connectToEvent(PVSSboolean dontExit = PVSS_FALSE);

  /** Connect to the event manager.
    @param dontExit by default the function will succeeed in establishing a connection to the
    event manger or the exit the manger.
    If this flag is set to PVSS_TRUE the manager will not
    exit and the function may return without an established connection.
    Note that the event manager may close the connection immedeately if there is no
    license for this manager. You are advised to check with Manager::isEvConnOpen if the
    connection is still open.
    @param bAutoSwitchToRunning by default Connecting to the event manager will set the Manager
    to state STATE_RUNNING. Otherwise this must be done manually lateron.
    @return PVSS_TRUE if the connect call to the event manager was successful
    @classification public use, call
   */
  static PVSSboolean connectToEvent(PVSSboolean dontExit, PVSSboolean bAutoSwitchToRunning);

  /** sets the Manager into running state (also OS)
    if a manager calls connectToEvent with bAutoSwitchToRunning = PVSS_FALSE it will not automatically set
    to running state. In that case the manager has to set to running state manually by thios function.
    This is used for managers, that are not fully initialized after establishing the connection to the event, because
    e.g. more data is needed to fully initialize the manager (e.g. drivers)
    the pmon waits to start the next manager until the current manager is in running state
    @return PVSS_TRUE if successful, else PVSS_FALSE
    @classification public use, call
   */
  static PVSSboolean setRunningEvent();

  /** Store local identification to cache
   */
  static void storeLocalIdentification();

  /** Restore local identification from cache
   * @param needsForInit what to restore
   * @return true if successful
   */
  static bool restoreLocalIdentification(PVSSuchar needsForInit);

  /** Notify a closed or lost connection.
    When a manager closes an established connection, this callback
    function is called. you can use this function to handle aborts from EM and DM.
    When overloading this function you should call the basic function after your work.
    @param mId the manager which has closed its connection (to us)
    @classification public use, overload, call basic
   */
  virtual void doConnectionClose(const ManagerIdentifier &mId);  //       {removeDeadManager(mId);}

  /** Notify a new or lost connection.
    This function is called whenever a manager connects or disconnects.
    You shall call the base class function.
    @param manId The manager which just opened or closed the connection
    @param disconnect A flag whether the manager connected or disconnected
    @classification public use, overload, call basic
    */
  virtual void handleManagerConnect(const ManagerIdentifier &manId, PVSSboolean disconnect = PVSS_FALSE);

  /** Notify a change to an existing connection.
    This function is called, when a manager opens or closes a redundant connection.
    @param manId The manager establishing or closing a connection
    @param disconnect Flag if the the connection was lost (PVSS_TRUE) or a new connection (PVSS_FALSE)
    */
  virtual void handleManagerUpdate(const ManagerIdentifier &manId, PVSSboolean disconnect);

  /** Notify a SHUT_DOWN_MANAGER message.
      This function is called whenever a SHUT_DOWN_MANAGER message is received.
      Default implementation is writing a trace log.
      This function shall be overridden for client-manager specific code.
      @param manId The manager which has sent the message.
      @param failureReason The failure reason. if a SHUT_DOWN_MANAGER message without error is received the
      failureReason(ErrClass::PRIO_INFO, ErrClass::ERR_SYSTEM, ErrClass::NOERR, "SHUT_DOWN_MANAGER received") is passed.
      @classification public use, overload
   */
  virtual void handleShutDownReceived( const ManagerIdentifier &manId, const ErrClass &failureReason);

  /** Check connection. This function is called periodically from within the dispatch call
    to reconnect to other managers. The manager cann reconnect to servers like data or event only.
    By default all managers in Manager::checkedManagerList are checked every "connectDelay" seconds.
    To add a manager to this list call Manager::addCheckedManager with target manager identifier,
    host name and port number.
    @return PVSS_TRUE if it was time to check, else PVSS_FALSE
    @ classification overload, call
   */
  virtual PVSSboolean checkConnections();

  /** Add manager to the checked manager list. Only server (this manager will connect to)
    may be checked.
    @param connectString  The connection string (like "host:port")
    @param port The default port number to connect to
    @param destMan  The manager identifier for the connect call
    @param hostMan  Our manager identifier for the connect call
    @return PVSS_TRUE if the manager could be added to the list, else PVSS_FALSE
   */
  PVSSboolean  addCheckedManager(const CharString &connectString, unsigned short port,
      const ManagerIdentifier &destMan, const ManagerIdentifier &hostMan);

  /** Remove manager from the checking list
    @param manId the manager to remove
    @return PVSS_TRUE if successful, else PVSS_FALSE
   */
  PVSSboolean  removeCheckedManager(const ManagerIdentifier &manId);

  // Those two functions must be public so they can be called from CallBack classes
  public:
  /// Stop reconnecting to other managers
  void startCheckConnections() {doCheckConnections = PVSS_TRUE;}
  /// Start reconnecting to other managers
  void stopCheckConnections()  {doCheckConnections = PVSS_FALSE;}

  void setPermissionCheck(PermissionCheck *pc) {delete permissionCheck; permissionCheck = pc;}

  PermissionCheck * getPermissionCheck() const {return permissionCheck;}

  /** Check permission for user and manager for specified operation for datapoints
    @param what The type of operation
    @param dpId The datapoint to check
    @param uid The user
    @param manId The manager
    @return ErrClass::NOERR if the operation is allowed
  */
  ErrClass::ErrCode permitted(PermissionCheck::What what, const DpIdentifier &dpId, PVSSuserIdType uid, const ManagerIdentifier &manId)
  {
    return permissionCheck ? permissionCheck->permitted(what, dpId, uid, manId) : ErrClass::NOERR;
  }

  /** Check permission for given permission set and manager for specified operation for datapoints
    @param what The type of operation
    @param dpId The datapoint to check
    @param permissions the effective user permissions
    @param manId The manager
    @return ErrClass::NOERR if the operation is allowed
  */
  ErrClass::ErrCode permitted(PermissionCheck::What what, const DpIdentifier &dpId, Bit32 permissions, const ManagerIdentifier &manId)
  {
    return permissionCheck ? permissionCheck->permitted(what, dpId, DEFAULT_USER, manId, permissions) : ErrClass::NOERR;
  }

  /** Check permission for user and manager for specified operation for datapoints
    @param what The type of operation
    @param dpId The datapoint to check
    @param uid The user
    @param manId The manager
    @return ErrClass::NOERR if the operation is allowed
  */
  ErrClass::ErrCode permitted(PermissionCheck::What what, const AlertAttrList &aaList, PVSSuserIdType uid, const ManagerIdentifier &manId)
  {
    return permissionCheck ? permissionCheck->permitted(what, aaList, uid, manId) : ErrClass::NOERR;
  }

  /** Check permission for given permission set and manager for specified operation for datapoints
    @param what The type of operation
    @param dpId The datapoint to check
    @param permissions the effective users permissions
    @param manId The manager
    @return ErrClass::NOERR if the operation is allowed
  */
  ErrClass::ErrCode permitted(PermissionCheck::What what, const AlertAttrList &aaList, Bit32 permissions, const ManagerIdentifier &manId)
  {
    return permissionCheck ? permissionCheck->permitted(what, aaList, DEFAULT_USER, manId, permissions) : ErrClass::NOERR;
  }

  /**
   * Returns a pointer to the manager-global instance of the
   * CommonNameService-interface.
   * @return pointer to CNS interface
   */
  CommonNameService *getCNS() { return cns; }

  /**
   * Returns true if the security plugin should be used for client side
   * security checks, otherwise false.
   * If it returns true, getSecurityPlugin() can be expected to return
   * a valid pointer.
   */
  static bool useSecurityPlugin() { return useSecurityPlugin_; }

  /**
   * Returns a pointer to the Security Plugin that this manager uses,
   * or a nullptr if no Security Plugin is loaded.
   */
  static SecurityPlugin *getSecurityPlugin() { return securityPlugin; }

  /**
   * Tries to load a Security Plugin from a shared library with the given path.
   *
   * @return The new security plugin instance, or null if loading failed.
   *         The caller has to take ownership of the returned object.
   */
  static SecurityPlugin *loadSecurityPlugin(const CharString &pluginPath);

  protected:
  // dient auch zum geordneten Beenden des Managers ueber SysMsg
  /** signalhandler.
    for clean exit over SysMsg
    @param sig the signal
    @classification ETM internal
   */
  virtual void signalHandler(int);

  /** init connect datapoints
    @classification ETM internal
   */
  void initConnectDps();

  /** this method is called by the framework to handle newly received non-const DpMsg and handle them.
    This method calls doReceive(DpMsg &msg) for the actual message handling.
    @param msg a pointer to a message of type DpMsg. The messge is deleted in that function.
    @classification ETM internal
   */
  virtual void doReceive(DpMsg *msg);
  /** method to handle the different dp messages.
    It can be overloaded to implement special handling for messages.
    When overloading this function don't forget to call the original function for all messages
    you do not process.
    @param msg a message of type DpMsg
    @classification public use, overload, call basic
   */
  virtual void doReceive(DpMsg &msg);
  /** this method is called by the framework to handle newly received non-const SysMsg and handle them.
    This method calls doReceive(SysMsg &msg) for the actual message handling.
    @param msg a pointer to a message of type SysMsg
    @classification ETM internal
   */
  virtual void doReceive(SysMsg *msg);
  /** method to handle the different sys messages.
    It can be overloaded to implement special handling for messages.
    When overloading this function don't forget to call the original function for all messages
    you do not process. This is very important since we are handling system messages here!
    @param msg a message of type SysMsg. The message is deleted in that function.
    @classification public use, overload, call basic
   */
  virtual void doReceive(SysMsg &msg);

  /** handle refresh msg (in a redundancy change-over)
    If a redundancy change-over is triggered, a redundant connected manager has to refresh all its connection, by closing
    them and reconnect to the formaly connected managers. This has to be done, because the passive one could be started later than
    the active one, and therefore it does not have all the connections.
    @param mId the managerId that identifies the connection to the eventmanager of the system that did the redundancy change-over
    @classification ETM internal
   */
  virtual void doRefresh(const ManagerIdentifier &mId);

  /** Handle system disconnect.
    If we loose the connection to another system, this method is called.
    @param sys the system we lost the connection to
    @classification ETM internal
   */
  virtual void doSystemDisconnect(SystemNumType sys);

  /** initialize config
    is called by setConfig
    @param group the DpICGroup
    @param config the config to init
    @classification ETM internal
   */
  virtual void doInitConfig(const DpICGroup *group, const DpConfig *config) const;

  /** handle a NameServerSysMsg
    @param msg the message to handle
    @classification ETM internal
   */
  virtual PVSSboolean handleNameServerSysMsg(const NameServerSysMsg &msg);

  /** Handle one token of the InitSysMsg
    @param manId the manager that sent the InitSysMsg
    @param token the init token to handle
    @param value the value of the token
   */
  virtual PVSSboolean handleInitToken(const ManagerIdentifier &manId, const CharString &token, const CharString &value);

  /** Helper function to setup routing for a distributed project
      Useful when setupRouting has been overriden but routing in distributed projects is still wanted
      Does nothing when the project is not distributed - it is safe to always call this method
    @param [in,out] msg the message we want to send
    @return PVSS_TRUE if everything ok, PVSS_FALSE else
   */
  PVSSboolean setupRoutingForDistributedProject(Msg &msg) const;

  /**
   * Add tokens to the InitSysMsg.
   *
   * @param manId The target manager that will receive the InitSysMsg.
   * @param [in,out] msg The InitSysMsg to which the tokens will be appended.
   */
  virtual void  addInitToken(const ManagerIdentifier &manId, InitSysMsg &msg);

  /** sets the license options
    @param license license including the options we want to set
    @classification ETM internal
   */
  static  void  setLicenseOptions(License &license);

  // File transfer functions
  /** handle a FileTransferSysMsg
    @param msg the message to handle
    @classification ETM internal
   */
  virtual void  handleFileTransferSysMsg(FileTransferSysMsg &msg);

  /** wait for system license message
    @classification ETM internal
   */
  static void waitForLicense();

  /// the managerstate
  static ManagerState managerState;
  /// the control pointer
  static Controller *ctrlPtr;
  /// Messages waiting for answers
  static CallBackList * answerList;
  /// dpConnect Messages
  static CallBackList * connectList;
  /// dpQueryConnect Messages
  static CallBackList * queryList;
  /// dpCorrConnect Messages
  static CallBackList * corrList;
  /// connects for all DPE
  static CallBackList * globalList;
  /// alertConnects
  static CallBackList * alertList;

  /// internal running state
  RunningState * runningState;

  /// Listitem of supervised managers
  struct  ManListItem : PtrListItem
  {
    /// the target manager
    ManagerIdentifier  target;
    /// the source manager
    ManagerIdentifier  source;
    /// the connect string
    CharString         connectString;
  };

  /** the list of managers, for which the TCP/IP connection is monitored.
    * If one of the connections get lost, the framework periodically tries to reconnect.
    * Typically the (redundant) data and eventconnections are in this list.
    */
  PtrList  checkedManagerList;

  /// flag indicating that connections are checked
  PVSSboolean doCheckConnections;

  /** shall we check to delay the exit?
     Normally the Manager checks for the exitDelay config entry to delay the final exit.
     However, it shall not do this when stopped with a signal (which is a normal exit, e.g.
     from Pmon).
     If you have another special requirement to inhibit this, set this flag to false
  */
  static bool checkExitDelay;

  /// if ever reported, auto-dump codeCoverage on exit
  static bool codeCoverageReported;

  PermissionCheck * permissionCheck;


  protected:
  /** @name Datapoint (type) callback functions
   * @{
   */
  /** Callback function for datapoint creation.
   * Use this function by overloading to receive notifications for newly created datapoints.
   * @param system the system the datapoint was created on
   * @param dpName the name of the newly created datapoint
   * @param dpId the DpIdentifier of the newly created datapoint
   * @see dpCreate()
   */
  virtual void dpCreated(SystemNumType system, const CharString & dpName, const DpIdentifier & dpId) {}

  /** Callback function for datapoint deletion.
   * Use this function by overloading to receive notifications for deleted datapoints.
   * @param system the system the datapoint was deleted from
   * @param dpId the DpIdType of the deleted datapoint
   * @see dpDelete()
   */
  virtual void dpDeleted(SystemNumType system, DpIdType dpId) {}

  /** Callback function for datapoint renaming.
  * Use this function by overloading to receive notifications for newly created datapoints.
  * @param system the system of the renamed datapoint
  * @param dpName the new name of the datapoint
  * @param dpId the DpIdentifier of the renamed datapoint
  * @see dpCreate()
  */
  virtual void dpRenamed(SystemNumType system, const CharString & dpName, const DpIdentifier & dpId)
  {
    dpDeleted(system, dpId.getDp());
    dpCreated(system, dpName, dpId);
  }


  /** Callback function for datapoint type creation.
   * Use this functions by overloading to receive notifications for newly created datapoint types
   * @param system the system the DpType was created on
   * @param newType the DpType of the newly created datapoint type
   * @see dpTypeCreate()
   */
  virtual void dpTypeCreated(SystemNumType system, const DpType & newType) {}

  /** Callback function for datapoint type modification.
   * Use this functions by overloading to receive notifications for modified datapoint types
   * @param system the system the DpType was modified on
   * @param changedType the DpType of the modified datapoint type
   * @see dpTypeChange()
   */
  virtual void dpTypeChanged(SystemNumType system, const DpType & changedType) {}

  /** Callback function for datapoint type deletion.
   * Use this functions by overloading to receive notifications prior to the deletion of datapoint types
   * @param system the system the DpType will be deleted from
   * @param oldType the DpTypeId of the soon-to-be-deleted datapoint type
   * @see dpTypeDelete()
   */
  virtual void dpTypeDoomed(SystemNumType system, DpTypeId oldType) {}

  /** Callback function for datapoint type deletion.
   * Use this functions by overloading to receive notifications for deleted datapoint types
   * @param system the system the DpType was deleted from
   * @param oldType the DpType of the deleted datapoint type
   * @see dpTypeDelete()
   */
  virtual void dpTypeDeleted(SystemNumType system, DpTypeId oldType) {}

  /** Callback function for time correction usage.
   * Override this function to return true if you want to use time correction.
   * @return bool indicating whether time correction is use
   */
  virtual bool useServerTime() {return false;}

  /** Handle a SHUT_DOWN_MANAGER message.
      Default handling of a SHUT_DOWN_MANAGER message.
      This method calls the virtual void handleShutDownReceived(const ManagerIdentifier&, const ErrClass&) method
      @param msg The SHUT_DOWN_MANAGER message.
      @classification ETM internal

   */
  void handleShutDownReceived(const SysMsg &msg);

  /// indicates whether time correction is used
  static bool useServerTime_;

  /// stores a WaitForAnswer object provided to receive Re-Login Answers
  static WaitForAnswer *loginAnswer_;

  private:
  /** used in the constructors for common initialization tasks (everything but CNS)
    @param manId the managerIdentifier we want to init
    @classification ETM internal
   */
  void init(const ManagerIdentifier &manId);

  /** the internal dispatch routine
    @classification ETM internal
   */
  static void internalDispatch();

  /** the real send call
    @param msg the message to send
    @classification ETM internal
   */
  static PVSSboolean sendCall(Msg *);

  /** get the format of one specific language
    @param id the dpidentifier to get the format from
    @param lang the language
    @param [out] the format
    @return DpIdentOK if it worked
    @classification ETM internal
   */
  static DpIdentificationResult dpGetFormat(const DpIdentifier &id, const LanguageIdType lang, CharString &format);
  /** get the unit of one specific language
    @param id the dpidentifier to get the format from
    @param lang the language
    @param [out] the unit
    @return DpIdentOK if it worked
    @classification ETM internal
   */
  static DpIdentificationResult dpGetUnit(const DpIdentifier &id, const LanguageIdType lang, CharString &unit);
  /** Split the comment into description, format and unit
    @param dpComment the comment to split
    @param comment the description
    @param format the format
    @param unit the unit
    @classification ETM internal
   */
  static void splitComment(const char *, CharString &, CharString &, CharString &);
  /** update the dpTypeContainer
    called by "receive" for DpMsgManipDpType
    @param manipDpTypeMsg the message indicating a DpTypeContainer change
    @return PVSS_TRUE if everything worked, PVSS_FALSE else
    @classification ETM internal
   */
  PVSSboolean updateDpTypeContainer(DpMsgManipDpType &manipDpTypeMsg) const;
  /** update the DpContainer
    @param DpMsgManipDp the message indicating a DpContainer change
    @return PVSS_TRUE if everything worked, PVSS_FALSE else
    @classification ETM internal
   */
  // diese Funktion veraendert den Datenpunktkontainer anhand der Message
  PVSSboolean updateDpContainer(const DpMsgManipDp &msg) const;

  /** update the DpContainer
  @param msg the message indicating a DpContainer change
  @return PVSS_TRUE if everything worked, PVSS_FALSE else
  @classification ETM internal
  */
  // diese Funktion veraendert den Datenpunktkontainer anhand der Message
  PVSSboolean updateDpContainer(const DpMsgManipDpName &msg) const;

  /** update the DpIdentification
    @param identifierItemPtr item indicating the change
    @return PVSS_TRUE if everything worked, PVSS_FALSE else
    @classification ETM internal
   */
  // wenn die Identifikation sich aendert, kann diese Funktion aufgerufen werden
  PVSSboolean updateDpIdentification(const DpIdentifierItem *identifierItemPtr) const;
  /** set the config
    @param msg init config message
    @return PVSS_TRUE if everything worked, PVSS_FALSE else
    @classification ETM internal
   */
  PVSSboolean setConfig(DpMsgInitConfig &msg) const;
  // loescht die Elemente der Datenpunkte bei Typaenderungen
  /** delete all elements of datapoints of changed types
    @param manipDpTypeMsg the message indicating the typechange
    @param sysId the affected system
    @param DpTypeId the affected typeId
    @classification ETM internal
   */
  void deleteDpElements(const DpMsgManipDpType &manipDpTypeMsg,
      const SystemNumType &sysId,const DpTypeId &typeId) const;
  // loescht ElementIdentification und die aller Subknoten!
  /** deletes the elementidentification of the current node and all subnodes
    @param dpType for that dpType
    @param elId for that element id
    @param sysId for that system
    @classification ETM internal
   */
  void deleteRecursiveElIdentification(const DpType *dpType,const DpElementId & elId,
      const SystemNumType &sysId) const;

  /** @internal
   * Function used by dpTypeGet() to recursively build DpTypeDefinitions.
   * @warning This function assumes it's called from dpTypeGet or from itself.
   *          NEVER use this function on its own unless you check everything
   *          dpTypeGet does and you know what you're doing.
   * @param dpIdent reference to the system's DpIdentification
   * @param dpType reference to the datapoint type used for construction
   * @param rootElement the DpElementId used as root element for the current subtree
   * @param includeTypeRefs include referenced types
   * @param system the system to get the type definition for
   * @return a pointer to a DpTypeDefinition corresponding to the current subtree
   */
  static DpTypeDefinition * dpTypeGetRecursive(DpTypeId dptId, const DpType & dpType, DpElementId rootElement, PVSSboolean includeTypeRefs, const DpIdentification & dpIdent, SystemNumType system);

  /** Send the message to the destination
    originTime of the msg is set to current time before sending.
    @param msg message to send
    @return PVSS_TRUE if all ok, else PVSS_FALSE
    @classification ETM internal
   */
  static PVSSboolean send(Msg *msg);

  // IM 90573: valueChangeTimeDiff and validTimeDiff should be the same time
  /** Send the message to the destination
    @param msg message to send
    @param _setTime if true set originTime of the msg to current time before sending
                    if false don't touch originTime of the msg.
    @return PVSS_TRUE if all ok, else PVSS_FALSE
    @classification ETM internal
   */
  static PVSSboolean send(Msg *msg, bool _setTime);

  /** Receive a message
    @param msg message to receive
    @classification ETM internal
   */
  static void receive(Msg *msg);

  // diese Funktion verarbeitet eine Antwort, fuer die es keinen Call-Back gibt
  // standardmaessig loescht sie einfach die Antwort.
  /** this function handles an answer, that has no callback.
    per default the answer is just deleted.
    @param answer answer to handle
    @classification ETM internal
   */
  static void handleNoCallBackAnswer(DpMsgAnswer *answer)
  { manPtr->doHandleNoCallBackAnswer(answer); }

  /** this function handles an answer, that has no callback.
    per default the answer is just deleted
    @param answer answer to handle
    @classification ETM internal
   */
  virtual void doHandleNoCallBackAnswer(DpMsgAnswer *answer);

  /** print the manager size to the given stream
    @param to the stream
    @classification ETM internal
   */
  void dpConfigManagerSize(std::ostream &to) const;

  /** updates the CNS
    @param msg the manip message for the cns
    @return PVSS_TRUE if everything is ok, PVSS_FALSE else
    @classification ETM internal
   */
  PVSSboolean updateCNS(DpMsgManipCNS &msg);

  /** gets the CNS Change Type from the message
    @param msg the manip message for the cns
    @return change type
    @classification ETM internal
   */
  static CNSObserver::CNSChanges getCNSChangeTypeFromMsg(const DpMsgManipCNS &msg);

  /** get the CNS Path from the message
    @param msg the manip message for the cns
    @return the CNS Path
    @classification ETM internal
   */
  static CharString getCNSPathFromMsg(const DpMsgManipCNS &msg);

  /** check if the message version of the peer has at least the given value
    @param msg message to send
    @param version version to check for
    @return PVSS_TRUE if peer version is at least the given value
            PVSS_FALSE if there is no valid peer for the message or peer version is less (older) than the given value
    @classification ETM internal
   */
  static PVSSboolean isPeerVersionGreaterEqual(Msg *msg, unsigned short version);

  static void LoginAnswer(LoginSubType ackOrNack);

  static void handleSysMsgLogin(SysMsg &msg);

  /** create the payload for a LicenseSysMsg
    @param licenseOption  the requested option name
    @param count  the requested total count for this manager
    @quest A license quest is requested
   */
  static MappingVar* LicenseAdditionalData(const CharString& licenseOption,
                                           unsigned count,
                                           bool quest);

  /** get the payload from a LicenseSysMsg request
    @param msg the message
    @param licenseOption  the requested option name
    @param count  the requested total count for this manager
    @quest A license quest is requested
    @return  the message had a correct additional data field
   */
  static bool getLicenseAdditionalData(const SysMsg& msg,
                                       CharString& licenseOption,
                                       unsigned& count,
                                       bool& quest);

  /** creates and sends a License Request to Event
    @param licenseOption  the requested option name
    @param count  the requested total count for this manager
    @quest additionally do a license quest
    @return the sent message ID
   */
  static PVSSulong sendLicenseRequest(const CharString& licenseOption,
                                      unsigned count,
                                      bool quest,
                                      int& numRequestSent);

  static PVSSuserIdType userId;
  static DynPtrArrayIndex manCnt;
  static PVSSboolean useAnswerHandler;
  static Manager *manPtr; // Pointer to the only instance of the Manager
  static DpContainer *dpContainerPtr;
  static DpIdentification *dpIdentificationPtr;
  static UserTable *userTable;
  static ManagerTable *managerTable;

  // Lizensierung
  static LicenseOptions  *licenseOptionsPtr;
  static LicenseOptions  *licenseQuestAllPtr;
  static LicenseOptions  *licenseQuestFreePtr;
  static LicenseOptions  *licenseQuestUsedPtr;
  static LicenseOptions  *licenseQuestUsedOwnPtr;
  static LicenseOptions  *licenseQuestFeatureMapPtr;
  static PVSSTime        licenseMsgReceived;
  static PVSSushort      minMsgVersion_;

  //Languages
  static void (*ctrlReportFct)(std::ostream &);  // pointer to CTRL-report function

  // aktuelle Verbindungen zu Managern mit ManNum, Startzeit, Host
  /// actual connection to manager with mannum, starttime, host
  struct  DLLEXP_MANAGER  ConnData
  {
    /// manager number
    DynVar  connManNum;              // Manager-Nummern
    /// dp for manager number
    DpIdentifier  connManNumDp;      // DP fuer ManagerNummer

    /// start time
    DynVar  connStartTime;           // Startzeit
    /// dp for start time
    DpIdentifier  connStartTimeDp;   // DP fuer Startzeit

    /// hostname
    DynVar  connHostName;            // Hostname
    /// dp for hostname
    DpIdentifier  connHostNameDp;    // DP fuer Hostname
  } connData[MAX_MAN];

  static TimeVar  lastCheckConnTime;        // Last time we checked our connections

  DiagMsgItcIOHandler msgDiagTimer_;
  DiagConfigAndDpItcIOHandler configAndDpDiagTimer_;

  FileTransferList  fileTransferList;

  /// item for the connStatusList
  struct DLLEXP_MANAGER ConnStatusListItem : public PtrListItem
  {
    static bool initialized;

    ManagerIdentifier peer;
    int dpIdsStatus;
    DpIdentifier link0DP;
    DpIdentifier link1DP;
    DpIdentifier crcDP;
    DpIdentifier timeDiffDP;
    PVSSboolean link0;
    PVSSboolean link1;
    PVSSboolean crc;
    double timeDiff;
    PVSSboolean needUpdate;
  };

  PtrList connStatusList;

  /** initialize the connection state DP
  */
  void initConnStatusItems();

  /** change the connection state
    @param peer the peer
    @param state the new state
    @classification ETM internal
   */
  void changeConnState ( const ManagerIdentifier &peer, PVSSboolean state);
  /** flushs the stored connection states
    @classification ETM internal
   */
  void flushConnStates ();

  /**  set the time difference
       @param peer the peer
       @param timeDiff the time difference
       @classification ETM internal
   */
  void setTimeDifference(const ManagerIdentifier &peer, double timeDiff);

  /**
    set the use of CRC
    @param peer the peer
    @param crc the use of CRC
    @classification ETM internal
  */
  void setUseOfCRC(const ManagerIdentifier &peer, PVSSboolean crc);

  /** search a conn status item. If none is found a new item is created
    @param peer for the given peer
    @return a pointer to the item
    @classification ETM internal
   */
  ConnStatusListItem * findConnStatusItem (const ManagerIdentifier &peer);

  static bool exitRequested_;
  static int exitCodeRequested_;

  CommonNameService *cns;
  static SecurityPlugin *securityPlugin;
  static CharString licenseOption_;

  // determines whether the plugin will intercept its relevant functions
  static bool useSecurityPlugin_;

  //create a DpMsgComplexVC for dpset and dpsettimed
  static DpMsgComplexVC createDpSetMsg(const TimeVar &originTime,
                                       const DpIdentifier &dpId,
                                       const Variable &value,
                                       const ManagerIdentifier &target,
                                       WaitForAnswer *wait,
                                       PVSSboolean isTimed);

  static DpMsgComplexVC createDpSetMsg(const TimeVar &originTime,
                                       const DpIdValueList &dpIdList,
                                       const ManagerIdentifier &target,
                                       WaitForAnswer *wait,
                                       PVSSboolean isTimed);

  // security plugin callbacks (cannot be caught in libManager)
  static bool handleSecurityPluginGetDpAliasCheck(const DpIdentifier &dpId);
  static bool handleSecurityPluginGetIdSetCheck(DpIdentList &list);
  static bool handleSecurityPluginGetAllAliasesCheck(const DpIdentifier &dpId);
  static bool getPluginChallenge(const ManagerIdentifier &manId, CharString &challenge);
  static bool getPluginResponse(const ManagerIdentifier &manId, const CharString &challenge, CharString &response);
  static bool validatePluginResponse(const ManagerIdentifier &manId, const CharString &response, CharString &newChallenge);

  /**
   * Passes the given error to the wait object by wrapping it in an answer
   * message created from the given message.
   *
   * The call will take ownership of the given error object.
   * If deleteWait is true, it will also delete the wait object.
   */
  static void handleSecurityPluginError(ErrClass *errPtr, DpMsg &msg,
                                        WaitForAnswer *wait = 0,
                                        bool deleteWait = true);

  /**
   * Check whether the DpIdentList exceeds the max number (used in dpConnect).
   * @params dpIdList the list to be checked
   * returns true if the list does not exceed the maximum, else false and
   *         creates an error
   */
  static bool checkConnectSize(const DpIdentList &dpIdList);

  /**
   * Sets the preferred OS error reporting mode
   * @params mode Error reporting mode
  */
  static void setErrorReportingMode(unsigned int mode);


private:
  struct LicenseRequestDetail
  {
    LicenseRequestDetail()
      : sent(PVSSTime::getSystemTime())
   {}

    LicenseCallback callback;
    CharString option;
    unsigned count;
    bool quest;
    QuestTarget target;
    PVSSTime sent;
    int outstandingRequests;
  };

#ifdef _WIN32
# pragma warning(push)
# pragma warning(disable: 4251)
#endif
  std::map<PVSSulong, LicenseRequestDetail> m_licenseCallbacks;
#ifdef _WIN32
# pragma warning(pop)
#endif
};

//--------------------------------------------------------------------------------

inline PVSSboolean Manager::dpSet(const DpIdentifier &dpId,
    const Variable &value,
    const ManagerIdentifier &target)
{
  return dpSet(dpId, value, target, 0);
}

inline PVSSboolean Manager::dpSet(const DpIdentifier &dpId,
    const Variable &value,
    WaitForAnswer *wait,
    PVSSboolean del)
{
  return dpSet(dpId, value, eventId, wait, del);
}

inline PVSSboolean Manager::dpSet(const DpIdValueList &dpIdList,
    const ManagerIdentifier &target)
{
  return dpSet(dpIdList, target, 0);
}

inline PVSSboolean Manager::dpSet(const DpIdValueList &dpIdList,
    WaitForAnswer *wait,
    PVSSboolean del)
{
  return dpSet(dpIdList, eventId, wait, del);
}

inline PVSSboolean Manager::dpSetTimed(const TimeVar &originTime,
    const DpIdentifier &dpId,
    const Variable &value,
    const ManagerIdentifier &target)
{
  return dpSetTimed(originTime, dpId, value, target, 0);
}

inline PVSSboolean Manager::dpSetTimed(const TimeVar &originTime,
    const DpIdentifier &dpId,
    const Variable &value,
    WaitForAnswer *wait,
    PVSSboolean del)
{
  return dpSetTimed(originTime, dpId, value, eventId, wait, del);
}

inline PVSSboolean Manager::dpSetTimed(const TimeVar &originTime,
    const DpIdValueList &dpIdList,
    const ManagerIdentifier &target)
{
  return dpSetTimed(originTime, dpIdList, target, 0);
}

inline PVSSboolean Manager::dpSetTimed(const TimeVar &originTime,
    const DpIdValueList &dpIdList,
    WaitForAnswer *wait,
    PVSSboolean del)
{
  return dpSetTimed(originTime, dpIdList, eventId, wait, del);
}

inline PVSSboolean Manager::dpGet(const DpIdentifier &dpId,
    WaitForAnswer *wait,
    PVSSboolean del)
{
  return dpGet(dpId, eventId, wait, del);
}

inline PVSSboolean Manager::dpGet(const DpIdentList &dpIdList,
    WaitForAnswer *wait,
    PVSSboolean del)
{
  return dpGet(dpIdList, eventId, wait, del);
}

inline PVSSboolean Manager::dpGetMaxAge(PVSSulong maxAge, const DpIdentifier &dpId,
    WaitForAnswer *wait,
    PVSSboolean del)
{
  return dpGetMaxAge(maxAge, dpId, eventId, wait, del);
}

inline PVSSboolean Manager::dpGetMaxAge(PVSSulong maxAge, const DpIdentList &dpIdList,
    WaitForAnswer *wait,
    PVSSboolean del)
{
  return dpGetMaxAge(maxAge, dpIdList, eventId, wait, del);
}

inline PVSSboolean Manager::dpGetAsynch(const TimeVar &forTime,
    const DpIdentifier &dpId,
    WaitForAnswer *wait,
    PVSSboolean del)
{
  return dpGetAsynch(forTime, dpId, eventId, wait, del);
}

inline PVSSboolean Manager::dpGetAsynch(const TimeVar &forTime,
    const DpIdentList &dpIdList,
    WaitForAnswer *wait,
    PVSSboolean del)
{
  return dpGetAsynch(forTime, dpIdList, eventId, wait, del);
}

inline PVSSboolean Manager::dpGetPeriod(const TimeVar &start,
    const TimeVar &stop,
    PVSSushort number,
    const DpIdentifier &dpId,
    WaitForAnswer *wait,
    PVSSboolean del)
{
  return dpGetPeriod(start, stop, number, dpId, eventId, wait, del);
}

inline PVSSboolean Manager::dpGetPeriod(const TimeVar &start,
    const TimeVar &stop,
    PVSSushort number,
    const DpIdentList &dpIdList,
    WaitForAnswer *wait,
    PVSSboolean del)
{
  return dpGetPeriod(start, stop, number, dpIdList, eventId, wait, del);
}

inline PVSSboolean Manager:: dpGetPeriod(
    const TimeVar &start,
    const TimeVar &stop,
    PVSSushort number,
    const DpIdentList &dpIdList,
    PVSSulong &reqId,
    WaitForAnswer *wait,
   PVSSboolean del)
{
  return dpGetPeriod(start, stop, number, dpIdList, reqId, eventId, wait, del);
}

inline PVSSboolean Manager::dpConnect(const DpIdentifier &dpId,
    WaitForAnswer *wait,
    PVSSboolean del)
{
  return dpConnect(dpId, eventId, wait, del);
}

inline PVSSboolean Manager::dpConnectNoSource(const DpIdentifier &dpId,
    WaitForAnswer *wait,
    PVSSboolean del)
{
  return dpConnectNoSource(dpId, eventId, wait, del);
}

inline PVSSboolean Manager::dpConnect(const DpIdentifier &dpId,
    const ManagerIdentifier &target)
{
  return dpConnect(dpId, target, (WaitForAnswer *) 0);
}

inline PVSSboolean Manager::dpConnectNoSource(const DpIdentifier &dpId,
    const ManagerIdentifier &target)
{
  return dpConnectNoSource(dpId, target, (WaitForAnswer *) 0);
}

inline PVSSboolean Manager::dpConnect(const DpIdentList &dpIdList,
    WaitForAnswer *wait,
    PVSSboolean del)
{
  return dpConnect(dpIdList, eventId, wait, del);
}

inline PVSSboolean Manager::dpConnectNoSource(const DpIdentList &dpIdList,
    WaitForAnswer *wait,
    PVSSboolean del)
{
  return dpConnectNoSource(dpIdList, eventId, wait, del);
}

inline PVSSboolean Manager::dpConnect(const DpIdentList &dpIdList,
    const ManagerIdentifier &target)
{
  return dpConnect(dpIdList, target, (WaitForAnswer*) 0);
}

inline PVSSboolean Manager::dpConnectNoSource(const DpIdentList &dpIdList,
    const ManagerIdentifier &target)
{
  return dpConnectNoSource(dpIdList, target, (WaitForAnswer*) 0);
}

inline PVSSboolean Manager::alertConnect(const DpIdentifier &dpId,
    WaitForAnswer *wait,
    PVSSboolean del)
{
  return alertConnect(dpId, eventId, wait, del);
}

inline PVSSboolean Manager::alertConnect(const DpIdentifier &dpId,
    const ManagerIdentifier &target)
{
  return alertConnect(dpId, target, 0);
}

inline PVSSboolean Manager::alertConnect(const DpIdentList &dpIdList,
    WaitForAnswer *wait,
    PVSSboolean del)
{
  return alertConnect(dpIdList, eventId, wait, del);
}

inline PVSSboolean Manager::alertConnect(const DpIdentList &dpIdList,
    const ManagerIdentifier &target)
{
  return alertConnect(dpIdList, target, 0);
}


inline PVSSboolean Manager::alertConnectRetVisible(const DpIdentifier &dpId,
    WaitForAnswer *wait,
    PVSSboolean del)
{
  return alertConnectRetVisible(dpId, eventId, wait, del);
}


inline PVSSboolean Manager::alertConnectRetVisible(const DpIdentList &dpIdList,
    WaitForAnswer *wait,
    PVSSboolean del)
{
  return alertConnectRetVisible(dpIdList, eventId, wait, del);
}


inline PVSSboolean Manager::alertSet(const AlertList &aList,
    const ManagerIdentifier &target)
{
  return alertSet(aList, target, 0);
}

inline PVSSboolean Manager::alertSet(const AlertList &aList,
    WaitForAnswer *wait,
    PVSSboolean del)
{
  return alertSet(aList, eventId, wait, del);
}

inline PVSSboolean Manager::alertSetTimed(const TimeVar &originTime,
                                          const AlertList &aList,
                                          const ManagerIdentifier &target)
{
  return alertSetTimed(originTime, aList, target, 0);
}

inline PVSSboolean Manager::alertSetTimed(const TimeVar &originTime,
                                          const AlertList &aList,
                                          WaitForAnswer *wait,
                                          PVSSboolean del)
{
  return alertSetTimed(originTime, aList, eventId, wait, del);
}

inline PVSSboolean Manager::alertGetPeriod(const TimeVar &start,
    const TimeVar &stop,
    const DpIdentifier &dpId,
    WaitForAnswer *wait,
    PVSSboolean del)
{
  return alertGetPeriod(start, stop, dpId, eventId, wait, del);
}

inline PVSSboolean Manager::alertGetPeriod(const TimeVar &start,
    const TimeVar &stop,
    const DpIdentList &dpIdList,
    WaitForAnswer *wait,
    PVSSboolean del)
{
  return alertGetPeriod(start, stop, dpIdList, eventId, wait, del);
}

inline PVSSboolean Manager::alertGetPeriod(
    const TimeVar &start,
    const TimeVar &stop,
    const DpIdentList &dpIdList,
    PVSSulong &reqId,
    WaitForAnswer *wait,
    PVSSboolean del)
{
  return alertGetPeriod(start, stop, dpIdList, reqId, eventId, wait, del);
}

inline PVSSboolean Manager::dpQueryConnectSingle(
    const CharString &query,
    PVSSboolean values,
    WaitForAnswer *wait,
    PVSSboolean del)
{
  return dpQueryConnectSingle(query, values, eventId, wait, del);
}

inline PVSSboolean Manager::dpQueryConnectAll(
    const CharString &query,
    PVSSboolean values,
    WaitForAnswer *wait,
    PVSSboolean del)
{
  return dpQueryConnectAll(query, values, eventId, wait, del);
}

inline PVSSboolean Manager::dpQueryDisconnect( PVSSulong id, WaitForAnswer *wait)
{
  return dpQueryDisconnect(id, eventId, wait);
}

inline PVSSboolean Manager::dpQuery(const CharString &query,
    WaitForAnswer *wait, PVSSboolean del)
{
  return dpQuery(query, eventId, wait, del);
}

inline PVSSboolean Manager::dpQuery(
    const CharString &query,
    PVSSulong &reqId,
    WaitForAnswer *wait,
    PVSSboolean del)
{
  return dpQuery(query, reqId, eventId, wait, del);
}


inline PVSSboolean Manager::hasUserPermission(PVSSuchar level, PVSSuserIdType userId, const ManagerIdentifier & manId)
{
  if (userId==ROOT_USER || level==0)
    return PVSS_TRUE;

  return hasPermission(level, Bit32(getUserPermissionSet(userId, manId)));
}

inline PVSSboolean Manager::hasPermission(PVSSuchar level, Bit32 permissions)
{
  return (level == 0) || permissions.getBit(level - 1);
}

inline PVSSboolean Manager::hasPermission(PVSSuchar level)
{
  return hasUserPermission(level, userId, getMyManagerId());
} // ????

inline PVSSboolean Manager::hasPermission(PVSSuchar level, PVSSuserIdType userId)
{
  return hasUserPermission(level, userId, getMyManagerId());
}

inline PVSSboolean Manager::isDefaultUserManager(PVSSuchar manT)
{
  if (manT==EVENT_MAN ||
      manT==DRIVER_MAN ||
      manT==DB_MAN ||
      manT==DEVICE_MAN ||
      manT==DIST_MAN ||
      manT==REDU_MAN)
    return PVSS_FALSE;

  return PVSS_TRUE;
}



inline  void  Manager::setTypeContainerPtr(DpTypeContainer *newPtr)
{
  DpTypeContainer::setTypeContainerPtr(newPtr);
}


inline  DpTypeContainer * Manager::getTypeContainerPtr(SystemNumType sys)
{
  return DpTypeContainer::getTypeContainerPtr(sys);
}


inline  DpTypeContainer * Manager::cutTypeContainerPtr(SystemNumType sys)
{
  return DpTypeContainer::cutTypeContainerPtr(sys);
}


#endif /* _MANAGER_H_ */

