#ifndef _DPTYPENODE_H_
#define _DPTYPENODE_H_

// DATEIBESCHREIBUNG ==============================================================
// DATEINAME:     DpTypeNode.hxx
// VERANTWORTUNG:   Stanislav Meduna
//
// BESCHREIBUNG:  Element eines DpTypen. Entspricht einem Dp-Element
//                eines Typs. Hat einen Vorgaenger und evtl. mehrere
//                Nachfolger (Baumstruktur).
//
//                Folgende Funktionen bilden die Schnittstelle dieser
//                Klasse:
//
//                isLeaf, getSonNumber, getSon, addSon
//
//                und die Zugriffsfunktionen fuer Attribute
//                (set/get ElementType, Father, Id)
//
//  24.02.2002    Memory Optimized, Martin Koller

#ifndef _DPTYPES_H_
#include <DpTypes.hxx>
#endif

#ifndef _DPELEMENTTYPE_H_
#include <DpElementType.hxx>
#endif

#ifndef _RESOURCES_H_
#include <Resources.hxx>
#endif

#include <ostream>

// Forward declarations :
class itcNdrUbSend;
class itcNdrUbReceive;

/** Element of the the DpType.
    Corresponds to a DpElement of particular Type and does have one parent and several siblings (tree structure).
    Following methods compose the interface of that class: Is Leaf, getSonNumber, getSon, addSon.
    And the access methods for attributes: Set/get ElementType/Father/Id.
    */
class DLLEXP_DATAPOINT DpTypeNode
{
  public:
    /// Default constructor.
    DpTypeNode();
    /// Constructor.
    DpTypeNode(const DpTypeNode &aNode);
    /// Destructor.
    ~DpTypeNode();

    // Operators :
    /// Comparison operator.
    int operator==(const DpTypeNode &rVal) const {return(id == rVal.id);}
    /// Comparison operator.
    int operator!=(const DpTypeNode &rVal) const {return(id != rVal.id);}
    /// Comparison operator.
    int operator< (const DpTypeNode &node) const {return id < node.id;}

    /// Assignment operator.
    const DpTypeNode &operator=(const DpTypeNode &aNode);

    /// Write the instance into the itcNdrUbSend stream.
    friend DLLEXP_DATAPOINT itcNdrUbSend &operator<<(itcNdrUbSend &ndrStream, const DpTypeNode &type);
    /// Read the instance from the itcNdrUbReceive stream.
    friend DLLEXP_DATAPOINT itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream, DpTypeNode &type);


    // Special methods :
    /// Set element ID.
    PVSSboolean setId(DpElementId newId);
    /// Set element type.
    PVSSboolean setElementType(DpElementType newType);
    /// Set father.
    PVSSboolean setFather(DpElementId newFather);

    /// Set referenced type.
    void setReferencedType(DpTypeId newType) { referencedType = newType; }
    /** Set RefSrc type.
        If a type contains a type reference, the "father" type tree may not end at the node which references the other type. Instead it may
        continue to include the nodes of the references type. Those nodes have to keep track that they originally did not belong to the father type
        but to another type and also which was their original element id.

        "May not end": When dealing with a type all nodes have a unique element id. When a type contains references to another type the
        elements of the referenced type must get an element id that is unique within the father type. E.g. the root node of the referenced type has
        the element id 1. But the root node of the father type has the element id 1, too. So within the father type the root node of the referenced
        type must get another element id which is what is stored in that node, beside the original element id (1) and the original type id.
	@param newType the new srcType
    */
    void setRefSrcType(DpTypeId newType) { refSrcType = newType; }
    /** Set RefSrc element.
        @param newEl the new srcElement
        For more information regarding RefSrc see setRefSrcType().
    */
    void setRefSrcElement(DpElementId newEl) { refSrcElement = newEl; }

    /// Add son.
    PVSSboolean addSon(DpElementId newSon);
    /// Get son.
    DpElementId getSon(unsigned int sonIndex) const { return (sonIndex >= count_) ? 0 : dpElementIdList_[sonIndex]; }
    /** Check if the node contains sons.
        @return Returns PVSS_TRUE if the node does not contains sons.
    */
    PVSSboolean isLeaf() const { return (count_ == 0); }
    /// Get number of sons.
    unsigned int getSonNumber() const { return count_; }

    /// Get the index in the sons array of the specified element.
    unsigned int getElementIndex(DpElementId elId) const;

    /// Get ID.
    const DpElementId &getId()     const { return id; }
    /// Get father.
    const DpElementId &getFather() const { return father; }

    /// Get element type.
    const DpElementType &getElementType() const { return elementType; }

    /// Get referenced type.
    const DpTypeId    &getReferencedType() const { return referencedType; }
    /** Get RefSrc type.
        For more information regarding RefSrc see setRefSrcType().
    */
    const DpTypeId    &getRefSrcType()     const { return refSrcType; }
    /** Get RefSrc element.
        For more information regarding RefSrc see setRefSrcType().
    */
    const DpElementId &getRefSrcElement()  const { return refSrcElement; }

    /// Check if the element is array type.
    static PVSSboolean isArrayType    (DpElementType elType) { return DpElType::isArrayType(elType); }
    /// Check if the element is record type.
    static PVSSboolean isRecordType   (DpElementType elType) { return DpElType::isRecordType(elType); }
    /// Check if the element is leaf type.
    static PVSSboolean isLeafType     (DpElementType elType) { return DpElType::isLeafType(elType); }
    /// Check if the element is Dyn type.
    static PVSSboolean isDynType      (DpElementType elType) { return DpElType::isDynType(elType); }
    /// Check if the element is reference type.
    static PVSSboolean isReferenceType(DpElementType elType) { return DpElType::isReferenceType(elType); }
    /// Get array type of the specified element type.
    static DpElementType getArrayType (DpElementType elType) { return DpElType::getArrayType(elType); }
    
    /// Get the type of the leaf element.
    static DpElementType getSubNodeType(DpElementType arrayType)
      { return DpElType::getSubNodeType(arrayType); }

    /// Check if the element is array type.
    PVSSboolean isArrayType    (void) const { return DpElType::isArrayType(elementType); };
    /// Check if the element is record type.
    PVSSboolean isRecordType   (void) const { return DpElType::isRecordType(elementType); };
    /// Check if the element is leaf type.
    PVSSboolean isLeafType     (void) const { return DpElType::isLeafType(elementType); };
    /// Check if the element is Dyn type.
    PVSSboolean isDynType      (void) const { return DpElType::isDynType(elementType); };
    /// Check if the element is reference type.
    PVSSboolean isReferenceType(void) const { return DpElType::isReferenceType(elementType); };

    /// Write the content of the object into the debug stream.
    void debug(std::ostream &to, int level, int indent = 0) const;

    /** Check if instances are the same.
        Id, Typ und Father are checked.
	@param node the other Node to be checked with
        */
    PVSSboolean isEqual(const DpTypeNode &node) const;

  protected:

  private:
    DpElementId id;
    DpElementType elementType;
    DpElementId father;

    // DpElementId is just a number. Store it in an array
    DpElementId* dpElementIdList_;
    unsigned int count_;

    // If the node is a type reference, store the destination type id
    DpTypeId    referencedType;

    // If this node resulted from type expansion,
    // remember the source.
    // refSrcType == 0, if this is a type's 'own' node.
    // This is direct ancestor - if A references B references C,
    // then the expanded elements of C will point to B, not to A.
    DpTypeId    refSrcType;
    DpElementId refSrcElement;

    friend class UNIT_TEST_FRIEND_CLASS; 
};

// --------------------------------------------------------------------------------
// Konstruktor

inline DpTypeNode::DpTypeNode()
  : id(0), elementType(DPELEMENT_NOELEMENT), father(0), dpElementIdList_(0), count_(0),
    referencedType(0), refSrcType(0), refSrcElement(0)
{
    Resources::getDiag().addDpTypeNode(sizeof(DpTypeNode));
}

// --------------------------------------------------------------------------------
// Konstruktor

inline DpTypeNode::DpTypeNode(const DpTypeNode &aNode)
  : dpElementIdList_(0), count_(0)
{
  Resources::getDiag().addDpTypeNode(sizeof(DpTypeNode));

  *this = aNode;
}

// --------------------------------------------------------------------------------

inline PVSSboolean DpTypeNode::setId(DpElementId newId)
{
  if (! newId)
    return PVSS_FALSE;

  id = newId;

  return PVSS_TRUE;
}

// --------------------------------------------------------------------------------

inline PVSSboolean DpTypeNode::setFather(DpElementId newFather)
{
  if (! newFather)
    return PVSS_FALSE;

  father = newFather;

  return PVSS_TRUE;
}

// --------------------------------------------------------------------------------

inline PVSSboolean DpTypeNode::isEqual(const DpTypeNode &node) const
{
  return (id == node.id) &&
         (elementType == node.elementType) &&
         (father == node.father);
}

#endif /* _DPTYPENODE_H_ */
