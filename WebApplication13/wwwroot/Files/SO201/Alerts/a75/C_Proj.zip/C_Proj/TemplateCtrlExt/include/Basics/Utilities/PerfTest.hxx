// DATEIBESCHREIBUNG ==============================================================
// DATEINAME:    PerfTest.hxx
// Verantwortung:	Stanislav Meduna
// Beschreibung :	mit Hilfe dieser Klasse kann die Bearbeitungszeit (real time)
//    zwischen verschiedenen Messpunkten ermittlelt werden
//    die Klasse merkt sich dabei jeweils die Anzahl und die Gesamtzeit fuer jede
//    aufgetretene Kombination von Start- und Stop-Messpunkt (2-dimensionales
//    Array)
//    fuer jeden Messpunkt muss sich der Benutzer ein Handle reservieren (zu jedem
//    Handle kann ein erklaerender Text hinzugefuegt werden) und mit diesem Handle
//    dann bei jedem Durchlauf den Timer starten, der folgende Timer-Start stoppt
//    automatisch den gerade aktiven Timer
//    fuer Timer-Starts in der BCM (oder auch anderen Extern-Libs) sind fixe Handles
//    reserviert (PERF_RESERVED_HANDLES), der eigentliche Aufruf erfolgt ueber einen
//    Function-Pointer
//    ausserdem bietet die Klasse eine Moeglichkeit die im dispatch() "verschlafene"
//    Zeit zu berechnen
//    die Ergebnisse koennen mit der Methode print() ausgegeben werden,
//    reset() setzt alle Timer und Zaehler auf 0 zurueck

#ifndef _PERFTEST_H_
#define _PERFTEST_H_

#define PERF_RESERVED_HANDLES 16
#define PERF_ARRAY_SIZE 64

#include <PVSSBcm.hxx>

/** Class for performance testing. This class determines the time expired for certain
    operations between two given points of execution.
    @classification CoreTest
*/
class DLLEXP_BASICS PerfTest
{
friend class UNIT_TEST_FRIEND_CLASS;

  public:
    // ermittelt, was ein getstruct timeval-Aufruf in etwa kostet
    // (wird dann vor der Ausgabe rausgerechnet)
    // initialisiert ausserdem die ExternLibs-Function-Ptr
    /// Resets all the variables to initial values and then call calibration.
    static void init();

    /// Free the texts[] array containing the description of the handles.
    static void destroy();
      
    /// Reset all timer values.
    static void reset();

    // liefert freies Handle (immer >= PERF_RESERVED_HANDLES)
    // und merkt sich den Text
    /// Gets the new unused handle and assign it a name.
    /// @param t Name of the new handle.
    /// @return Handle number. If new handle is not available, returns -1. 
    static int getHandle(const char * t);
    
    // initialisiert den Text fuer reserviertes Handle
    /// Sets the name for a specific handle number. 
    /// @param handle Handle number.
    /// @param t Name of the handle.
    static void intReservedText(int handle, const char * t);
    
    // beendet aktiven Timer und rechnet die verbrauchte Zeit zur
    // entsprechenden Position [activeHandle, newHandle] im
    // 2-dimensionalen Array hinzu, zusaetzlich wird der entsprechende
    // Counter erhoeht, gleichzeitig wird ein neuer Timer gestartet
    // startTimer(newHandle >= PERF_ARRAY_SIZE) stoppt den aktiven Timer
    /// Starts the timer associated with a specific handle number. This method
    /// will compute the time interval between the current time and the last time
    /// the timer was started. This elapsed time will then be stored in the
    /// two-dimmensional arrays times, mintime, maxtime and counts.
    /// @param newHandle Handle number. The handle must be previously
    /// initialized with getHandle() method.
    static void startTimer(int newHandle);
    
    // berechnet aus den dispatch() Ein- und Ausgangswerten die im select
    // "verschlafene" Zeit und addiert diese zur dispatchSleepTime
    /// This method updates the member dispatchSleepTime, storing the elapsed time
    /// between two timepoints.
    /// @param @inSec Starting elapsed time, seconds.
    /// @param @inMicroSec Starting elapsed time, microseconds.
    /// @param @outSec Ending elapsed time, seconds.
    /// @param @outMicroSec Ending elapsed time, microseconds.
    static void incDispatchSleepTime(long inSec, long inMicroSec, long outSec, long outMicroSec);
    
    // rechnet (je nach counts[i, j] die struct timeval-Aufrufe raus
    // und gibt jeweils Zeit, Anzahl und Prozentsatz aller verwendeten
    // Handles mit ihren Texten, sowie die dispatchSleepTime aus
    /// Print the state of the timers and arrays with elapsed time computations.
    static void print();
    
  private:
  
    /// Stores total elapsed time for all combination of handles. times[i][j]
    /// will store the total time elapsed between calling the startTimer(i),
    /// followed by the call startTimer(j).
    static struct timeval times[PERF_ARRAY_SIZE][PERF_ARRAY_SIZE];    // total time

    /// Similar to timer[i][j], but this array will store the minimal elapsed time
    /// between startTimer(i) and startTimer(j) calls.
    static struct timeval mintime[PERF_ARRAY_SIZE][PERF_ARRAY_SIZE];  // min time

    /// Similar to timer[i][j], but this array will store the maximal elapsed time
    /// between startTimer(i) and startTimer(j) calls.
    static struct timeval maxtime[PERF_ARRAY_SIZE][PERF_ARRAY_SIZE];  // max time

    /// In counts[i][j] will be remembered, how many times the call startTimer(i) was
    /// followed by calling startTimer(j).
    static unsigned long counts[PERF_ARRAY_SIZE][PERF_ARRAY_SIZE];    // num of exec
    
    /// This array will remember a text description for each handle
    static char * texts[PERF_ARRAY_SIZE];
    
    /// This variable helps to compute time interval between two time points
    static struct timeval dispatchSleepTime;

    /// counts how much the incDispatchSleepTime() method was called
    static unsigned long  dispatchCount;
    
    /// Timestamp with the first startTimer() call 
    static struct timeval firstTimerStart;

    /// Timestamp with the last startTimer() call 
    static struct timeval lastTimerStart;
    
    /// Number of the first unused handle. Is incremented after each call of getHandle().
    static int nextFreeHandle;

    /// Remembers the last parameter the startTimer() method was called with.
    static int activeHandle;
    
    /// Used by calibration (see init() method)
    static double ownTime;
};

#endif /* _PERFTEST_H_ */

