#ifndef _FILETRANSFERSYSMSG_H_
#define _FILETRANSFERSYSMSG_H_

/*
VERANTWORTUNG: Laszlo Szakony        
BESCHREIBUNG:
*/

#include <SysMsg.hxx>
#include <StringToken.hxx>

#include <DynVar.hxx>

class  TextVar;
class  RecVar;

/**  The file transfer system message class. 
 *   
 */
class DLLEXP_MESSAGES FileTransferSysMsg : public SysMsg 
{
  friend class UNIT_TEST_FRIEND_CLASS;    // ein Unit-Test braucht erweiterten zugriff auf diese Klasse

  public:
    /// Default constructor
    FileTransferSysMsg();
    
    /** Destination constructor
        @param newDestination a destination identification 
        @param type a message type 
        @param subType a messae subtype 
     */
    FileTransferSysMsg(const ManagerIdentifier &newDestination, SysMsgType type, PVSSuchar subType);
     
    /** Copy constructor
        @param newMsg an instance of the message to be copied from
     */
    FileTransferSysMsg(FileTransferSysMsg &newMsg);
    
    /// Destructor
    ~FileTransferSysMsg();

    // Operatoren :

   /** BCM output streaming operator.  
    *  
    *  @param [in,out] ndrStream the BCM output stream
    *  @param sysMsg the FileTransferSysMsg object to stream over BCM
    *  @return ndrStream
    *
    */
    friend DLLEXP_MESSAGES itcNdrUbSend &operator<<(itcNdrUbSend &ndrStream, const FileTransferSysMsg &sysMsg);

   /** BCM input streaming operator. All properties found in the stream replace the
    *  corresponding properties in the FileTransferSysMsg
    *
    *  @param [in,out] ndrStream the BCM input stream
    *  @param [out] sysMsg the FileTransferSysMsg object to receive from BCM
    *  @return ndrStream
    */
    friend DLLEXP_MESSAGES itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream, FileTransferSysMsg &sysMsg);

   /** Output streaming operator. 
    *  
    *  @param [in,out] ofStream the output stream
    *  @param sysMsg the FileTransferSysMsg object to stream over BCM
    *  @return ndrStream
    */
    friend DLLEXP_MESSAGES std::ostream &operator<<(std::ostream &ofStream, const FileTransferSysMsg &sysMsg);

   /** Equal operator. The operator compares the messages instances.
    *  
    *  @param rVal an instance of Msg to be compared to
    *  @return int 0, if instances are equal, or not 0 otherwise
    */
    virtual int operator==(const Msg &rVal) const;

    /** Equal operator. The operator compares the file transfer system messages instances.
     *  
     *  @param rVal an instance of FileTransferSysMsg to be compared to
     *  @return int 0, if instances are equal, or not 0 otherwise
     *
     */
    int operator==(const FileTransferSysMsg &rVal) const;

    /** Assignment operator. The operator assigns the content of the specified system message instances.
     *  
     *  @param rVal an instance of Msg to assign from
     *  @return Msg, assigned Msg instance
     *
     */
    Msg &operator=(const Msg &rVal);

    /** Assignment operator. The operator assigns the content of the specified file transfer system message instances.
     *  
     *  @param rVal an instance of FileTransferSysMsg to assign from
     *  @return FileTransferSysMsg, assigned file transfer system message instance
     *
     */
    FileTransferSysMsg &operator=(const FileTransferSysMsg &rVal);

    // Spezielle Methoden :

    /** Method returns the type of the system message.
     *   @param  msgType a system message type 
     *   @return MsgType, a SYS_MSG_FILE_TRANSFER type is returned for a FileTransferSysMsg type, or NO_MSG otherwise
     */
    virtual MsgType isA(MsgType msgType) const;
    
    /** Method returns a system message type.
     *   @return MsgType, a SYS_MSG_FILE_TRANSFER type is always returned
     */
    virtual MsgType isA() const;

    /** Receives from itcNdrUbReceive stream
     *   @param ist the stream, which to receive from
     */
    virtual void inNdrUb(itcNdrUbReceive &ist);

    /** Sends to itcNdrUbSend stream
     *   @param ost the stream, which to send to
     */
    virtual void outNdrUb(itcNdrUbSend &ost) const;

    /** Sends a formatted output about internal status of the instance to the specified stream.
     * (used for logging purpose)
     *  @param ofStream   output stream
     */
    virtual void outToFile(std::ostream &ofStream) const;

    /** Method creates a new FileTransferSysMsg instance.
     *   @return Msg, a new FileTransferSysMsg instance
     */
    virtual Msg *allocate() const;

    /** Sends a formatted output about internal status of the instance to the specified stream.
     * (used for debugging purpose)
     *  @param to   output stream
     *  @param level   debugging level
     */
    virtual void debug(std::ostream &to, int level) const;
    
  public:
    /** Appends file name and the value to the list. Pointers are grabbed.
     *  @param file   a file name pointer
     *  @param value  a value pointer
     *  @return PVSSboolean, returns PVSS_TRUE if the value & filename were added into the list, PVSS_FALSE otherwise.
     */
    PVSSboolean  appendTransferData(TextVar *file, RecVar *value);
    /** Cuts out file and value from the list.
     *  @param file   a file name pointer
     *  @param value  a value pointer
     *  @return PVSSboolean, returns PVSS_TRUE if the value & filename were removed from the list, PVSS_FALSE otherwise, e.g. items not found.
     */
    PVSSboolean  cutTransferData(TextVar *&file, RecVar *&value);
    
  private:
    DynVar  files;    // DYNTEXT_VAR
    DynVar  values;   // DYNREC_VAR
};


#endif /* _LICENSESYSMSG_H_ */
