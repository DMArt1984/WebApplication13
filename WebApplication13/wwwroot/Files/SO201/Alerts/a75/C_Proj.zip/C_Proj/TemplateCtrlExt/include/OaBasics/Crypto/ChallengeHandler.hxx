// -----------------------------------------------------------------------------
// creator: Andras Horvath - 01.09.2017
// purpose: SSA Challenge Handler Base
// -----------------------------------------------------------------------------
#ifndef _CHALLENGEHANDLER_HXX_
#define _CHALLENGEHANDLER_HXX_

#include <ManagerIdentifier.hxx>
#include <CharString.hxx>
#include <memory>

/** Forward declaration of SecurityPlugin class
    */
class SecurityPlugin;
class QJsonObject;

/**
  @class ChallengeHandler
  @brief The ChallengeHandler class
         is the abstract base class for other ChallengeHandlers.
         Only the functions getVersion() and getSerialized() are implemented
         because they are the same for all ChallengeHandler classes
*/
class DLLEXP_OABASICS ChallengeHandler
{
public:
  /// constructor
  ChallengeHandler() = default;

  /// destructor
  virtual ~ChallengeHandler() = default;

  virtual bool getChallenge() = 0;

  virtual bool getResponse() = 0;

  virtual bool checkResponse() = 0;

  virtual int serialize(QJsonObject& json) = 0;

  virtual std::string getName() = 0;

  /**
    @brief getVersion function of ChallengeHandler
           returns the Version of the implementation to prevent
           the usage of two different versions
    @return std::string with value "1"
  */
  virtual std::string getVersion();

  virtual std::string getIdentification() = 0;

  /**
    @brief getSerialized function of ChallengeHandler
           inserts the keys "base", "type" and "version" into
           the return JSON object as well as the "data" key containing
           the information of the concrete class serialize function
    @param json  the generated JSON document
    @return int  0 if no error, else error code
  */
  int getSerialized(QJsonObject& json);

  virtual bool getUsername(std::string &username) = 0;
};

#endif  // _CHALLENGEHANDLER_HXX_
