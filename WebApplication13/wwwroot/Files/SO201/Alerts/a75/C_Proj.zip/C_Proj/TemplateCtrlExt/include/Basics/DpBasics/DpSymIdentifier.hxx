#ifndef _DPSYMIDENTIFIER_H_
#define _DPSYMIDENTIFIER_H_

// System-Include-Files
#include <Types.hxx>
#include <DpIdentificationResultType.hxx>
#include <PathItem.hxx>
#include <DynPtrArray.hxx>

/// the depth of the symbolic name given to the symbolic identifier object. it shows the last valid descriptor in the string
enum DpSymIdLevel {
    /// (0). string was empty
    DPL_Nothing,
    /// (1). system name string found
    DPL_SYS,
    /// (2). datapoint name string found
    DPL_DP,
    /// (3). element name string found
    DPL_EL,
    /// (4). config name found
    DPL_CF,
    /// (5). detail name found
    DPL_DT,
    /// (6). attribute name found
    DPL_AT
};

// ========== DpSymIdentifier ============================================================

/** This class is used to convert a symbolic datapoint identifier (his string representation) to an
    internal dp identifier. The symbolic name may not necessarily hold the complete description. Its contents must be separable
    in one continuous step, however. There must not be any "holes" in the description.
*/
#ifdef WIN32
#pragma warning ( disable: 4231 )
#endif

#if defined(LIBS_AS_DLL)
  EXTERN_BASICS template class DLLEXP_BASICS DynPtrArray<PathItem>;
#endif

#ifdef WIN32
#pragma warning ( default: 4231 )
#endif


class DLLEXP_BASICS DpSymIdentifier
{
public:
  /// Default constructor.
  DpSymIdentifier();
  /** Constructor.
      Takes the symbolic name and prepare for splitting.
      @param path The symbolic name to split.
  */
  DpSymIdentifier(const char *path);
  /// Destructor.
  ~DpSymIdentifier() { clear(); }

  /// Clear the symbolic name.
  void clear();
  /// Get number of element name parts.
  DynPtrArrayIndex getElPathItemsNo() const;
  /** Get element part name.
      @param idx Index of the element part name.
  */
  const char *getElPathItemName(DynPtrArrayIndex idx) const;
  /** Get element part type.
      @param idx Index of the element part type.
  */
  PathItemType getElPathItemType(DynPtrArrayIndex idx) const;
  /** Get number of indices for the element part.
      @param idx Index of the element part.
  */
  DynPtrArrayIndex getElPathItemNoOfIndexes(DynPtrArrayIndex idx) const;
  /** Get index for the element part at the specified position.
      @param idx Index of the element part.
      @param item Position of the index at the element part.
  */
  DynPtrArrayIndex getElPathItemIndex(DynPtrArrayIndex idx, DynPtrArrayIndex item) const;

  /** Breaks down the symbolic name to its elements, starts with the system part.
      @param path The symbolic datapoint name.
      @param withWildCard Specifies whether wildcards may occur in the string.
  */
  DpIdentificationResult breakPath(const char *path, bool withWildCard = true) {DpSymIdLevel l; return breakPath(path,l, withWildCard);};
  /** Breaks down the symbolic name to its elements, starts with the system part.
      @param path The symbolic datapoint name.
      @param lastLevel Returns the type of the last valid string found.
      @param withWildCard Specifies whether wildcards may occur in the string.
  */
  DpIdentificationResult breakPath(const char *path, DpSymIdLevel &lastLevel, bool withWildCard = true);
  /** Breaks down the symbolic name to its elements, starting from the end.
      @param path The symbolic datapoint name.
      @param firstLevel Returns the type of the last valid string found - starting at attribute level.
  */
  DpIdentificationResult breakPathReverse(const char *path, DpSymIdLevel &firstLevel);

  /** Breaks down the symbolic name to its elements, starts with the system part (legacy method).
      In contrast to the breakPath() method, this method expects the string UTF8 encoded to break the path.
      @param path The symbolic datapoint name.
      @param lastLevel Returns the type of the last valid string found.
      @param withWildCard Specifies whether wildcards may occur in the string.
      @classification internal
  */
  DpIdentificationResult breakPathUTF8(const char *path, DpSymIdLevel &lastLevel, bool withWildCard = true);

  /** Breaks down the symbolic name to its elements, starting from the end (legacy method).
      In contrast to the breakPathReverse() method, this method expects the string UTF8 encoded to break the path.
      @param path The symbolic datapoint name.
      @param firstLevel Returns the type of the last valid string found - starting at attribute level.
      @classification internal
  */
  DpIdentificationResult breakPathReverseUTF8(const char *path, DpSymIdLevel &firstLevel);

  /// Checks if the current object matches a wildcard mask given in another DpSymIdentifier object.
  PVSSboolean match(const DpSymIdentifier &symIdMask) const;

  /// Match function used to compare a symbolic datapoint name with a wildcard mask.
  static PVSSboolean match(const char *mask, const char *str);
  static PVSSboolean matchIgnoreCase(const char *mask, const char *str, GlobalLanguageIdType langIdg = 0);

  /// ETM internal.
  /// Check syntax of a single part of the symbolic name.
  static PVSSboolean syntaxCheckNormal(const char *str);
  /// Check syntax of the index part of the symbolic name.
  static PVSSboolean syntaxCheckIndex(const char *str);

  /// Returns if needs leafs only.
  PVSSboolean leafOnly() {return wantsLeafOnly;}

  // Generierte Methoden :

  /// Get the system name string - valid after calling the breakPath(Reverse) function only.
  const char *getSystem() const;
  /// Get the datapoint name string - valid after calling the breakPath(Reverse) function only.
  const char *getDp() const;
  /// Get the element name string - valid after calling the breakPath(Reverse) function only.
  const char *getEl() const;
  /// Get the config name string - valid after calling the breakPath(Reverse) function only.
  const char *getConfig() const;
  /// Get the detail name string - valid after calling the breakPath(Reverse) function only.
  const char *getDetail() const;
  /// Get the attribute name string - valid after calling the breakPath(Reverse) function only.
  const char *getAttr() const;
  /// get the alias string - valid after calling the breakPath(Reverse) function only.
  const char *getAlias() const;

  // Access to the fix*-family. internal use only
  /// Get the fix* system name string - internal use only.
  const char *getFixSystem() const;
  /// Get the fix* datapoint name string - internal use only.
  const char *getFixDp() const;
  /// Get the fix* element name string - internal use only.
  const char *getFixEl() const;
  /// Get the fix* config name string - internal use only.
  const char *getFixConfig() const;
  /// Get the fix* detail name string - internal use only.
  const char *getFixDetail() const;
  /// Get the fix* attribute name string - internal use only.
  const char *getFixAttr() const;
  /// Get the fix* alias string - internal use only.
  const char *getFixAlias() const;

private:
  // Konstruktor
  DpSymIdentifier(const DpSymIdentifier &) {};  //COVINFO LINE: defensive (AP: disallow copy ctor)
  DpSymIdentifier &operator=(const DpSymIdentifier &) { return *this; } //COVINFO LINE: defensive (AP: disallow =operator)

  static PVSSboolean doMatchLoop(const char *mask, const char *str);

  DpIdentificationResult breakElToItems(char* elementbuf);

  // copy until the first special character
  void  copyFixPart(char *&dest, const char *src);
  
  // converts the given string to utf8 and frees the input.
  // the caller is responsible for the memory of the return value
  char *convertFromUTF8(char *utf8);
  void convertFromUTF8();

  char *system;
  char *dp;
  char *el;
  char *config;
  char *detail;
  char *attr;
  char *alias;
  DynPtrArray<PathItem> pathItemArray;

  // Fixparts (alles vor der ersten Wildcard) fuer System, DP, etc
  char *fixSystem;
  char *fixDp;
  char *fixEl;
  char *fixConfig;
  char *fixDetail;
  char *fixAttr;
  char *fixAlias;

  PVSSboolean wantsLeafOnly;
};

// ================================================================================
// Inline-Funktionen :
inline const char *DpSymIdentifier::getSystem() const
{
  return system;
}

inline const char *DpSymIdentifier::getDp() const
{
  return dp;
}

inline const char *DpSymIdentifier::getEl() const
{
  return el;
}

inline const char *DpSymIdentifier::getConfig() const
{
  return config;
}

inline const char *DpSymIdentifier::getDetail() const
{
  return detail;
}

inline const char *DpSymIdentifier::getAttr() const
{
  return attr;
}


inline const char *DpSymIdentifier::getAlias() const
{
  return alias;
}


inline const char *DpSymIdentifier::getFixDp() const
{
  return fixDp;
}

inline const char *DpSymIdentifier::getFixEl() const
{
  return fixEl;
}

inline const char *DpSymIdentifier::getFixConfig() const
{
  return fixConfig;
}

inline const char *DpSymIdentifier::getFixDetail() const
{
  return fixDetail;
}

inline const char *DpSymIdentifier::getFixAttr() const
{
  return fixAttr;
}

inline const char *DpSymIdentifier::getFixAlias() const
{
  return fixAlias;
}


// Konstruktor
inline DpSymIdentifier::DpSymIdentifier()
: system(0), dp(0), el(0), config(0), detail(0), attr(0), alias(0),
  fixSystem(0), fixDp(0), fixEl(0), fixConfig(0), fixDetail(0), fixAttr(0), fixAlias(0)
{
}

// Konstruktor
inline DpSymIdentifier::DpSymIdentifier(const char *path)
: system(0), dp(0), el(0), config(0), detail(0), attr(0), alias(0),
  fixSystem(0), fixDp(0), fixEl(0), fixConfig(0), fixDetail(0), fixAttr(0), fixAlias(0)
{
  breakPath(path);
}

inline DynPtrArrayIndex DpSymIdentifier::getElPathItemsNo() const
{
  return pathItemArray.getNumberOfItems();
}

inline const char *DpSymIdentifier::getElPathItemName(DynPtrArrayIndex idx) const
{
  return pathItemArray[idx]->getName();
}

inline PathItemType DpSymIdentifier::getElPathItemType(DynPtrArrayIndex idx) const
{
  return pathItemArray[idx]->getType();
}

inline DynPtrArrayIndex DpSymIdentifier::getElPathItemNoOfIndexes(DynPtrArrayIndex idx) const
{
  return pathItemArray[idx]->length();
}

inline DynPtrArrayIndex DpSymIdentifier::getElPathItemIndex(DynPtrArrayIndex idx, DynPtrArrayIndex item) const
{
  return pathItemArray[idx]->getIdxList(item);
}

#endif /* _DPSYMIDENTIFIER_H_ */
