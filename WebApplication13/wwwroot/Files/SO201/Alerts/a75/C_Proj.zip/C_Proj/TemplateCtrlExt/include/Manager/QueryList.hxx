#ifndef _QUERYLIST_H_
#define _QUERYLIST_H_

/*
VERANTWORTUNG: Robert Trausmuth      
BESCHREIBUNG:
*/

#include <Variable.hxx>
#include <DpIdentifier.hxx>
#include <DynPtrArray.hxx>
#include <CharString.hxx>
#include <DpSymIdentifier.hxx>
#include <DpIdentList.hxx>
#include <AnswerGroup.hxx>
#include <DpMsg.hxx>
#include <DynVar.hxx>
#include <TimeVar.hxx>
#include <ExtTimeVar.hxx>
#include <QueryGroupFunc.hxx>
#include <DpElementType.hxx>

class QueryTreeNode;

// TI 4345 Connect Single Trausi/Wokl
// 0x80 koennte auch 0x1 sein, einfach ein neues Flag
#define FIRSTTIME 0x80
 
class DLLEXP_MANAGER LineSet 
{
  friend class QueryList;    // need this to dynamically increase LineSet when detecting extra attribs!

  public:
    LineSet(PVSSushort max, void *uData=0);
    // delete all contained items
    ~LineSet();
    
    LineSet( const LineSet &ls) : list(0), userData(0), maxElements(0), Flags(FIRSTTIME) { *this = ls; }
    
    // deep copy for elements, user data ptr is copied
    LineSet &operator =(const LineSet &);

    // capture items
    PVSSboolean setAt(PVSSushort pos, VariablePtr ptr);
    VariablePtr cutAt(PVSSushort pos);
    
    VariablePtr getAt(PVSSushort i) const { return (i<maxElements) ? list[i] : 0 ; }
    VariablePtr getFirst() const {return (maxElements) ? list[0] : 0 ; }
    
    VariablePtr operator[] (unsigned i) const { return getAt(i); }
    
    PVSSushort nofItems() const {return maxElements; }
      
    void * getUserDataPtr() const { return userData; }
    
    void setId(DpIdentifier id) {lineId = id;}
    DpIdentifier &getIdRef() { return lineId; }
    const DpIdentifier &getId() const { return lineId; }
    
    // TI 4345 Query Connect Single Trausi/WOKL
    PVSSboolean isFirstTime() const { return (Flags & FIRSTTIME); }
    void clearFirstTime() { Flags = Flags & ~FIRSTTIME; }

    const VariablePtr* getListPtr() const { return list; }
 
  private:
    void append( VariablePtr );    // special func used by Querylist::prepareOneLine
  
    VariablePtr *list;
    void *userData;
    PVSSushort maxElements;
    
    DpIdentifier lineId;
    unsigned char Flags;        // TI 4345
  
    friend class UNIT_TEST_FRIEND_CLASS;
};

#if defined(LIBS_AS_DLL)

#ifdef WIN32
  #pragma warning ( push )
  #pragma warning ( disable: 4231 )
#endif

  EXTERN_MANAGER template class DLLEXP_MANAGER DynPtrArray<LineSet>;
  EXTERN_MANAGER template class DLLEXP_MANAGER DynPtrArray<QueryGroupFunc>;
  //COVINFO BLOCK: defensive (AP: code never reached)
  inline DynPtrArrayIndex DynPtrArray<QueryGroupFunc>::deepCopy(const DynPtrArray<QueryGroupFunc> &) { return 0; }
  //COVINFO BLOCKEND
#ifdef WIN32
  #pragma warning ( pop )
#endif

#endif
 
 
// result of conversion of system side part via DpIdentifier
typedef DynPtrArray<DpIdentifier> RowSet;
typedef DynPtrArray<LineSet> TableSet;
typedef DynPtrArray<QueryGroupFunc> GroupLineSet;

/** the query error types. each query operation returns an error code or code 0 (QueryOK) if suceeded.
*/
enum QueryFaultType {
    /** (0). query operation succeeded. */
    QueryOK,
    /** (1). query was parsed, a syntax error was encountered. */
    QuerySyntaxError,
    /** (2). internal error. some operations must be serialized. */
    QueryAnotherActive,
    /** (3). this manager has no identification container. some operations can not be performed. */
    QueryNoIdentification,
    /** (4). the dp identifiers asked for have overlapping areas, i.e. you ask for EL:CF.DT.AT FROM DP.EL */
    QueryLevelOverlap,
    /** (5). the dp names cannot be fetched. maybe there is a misspelled config name? */
    QueryCannotFetchHeader,
    /** (6). query has been cancelled due to low memory */
    QueryOutOfMemory,
    /** (7). internal error. we got a value not asked for */
    QueryValueOfNoInterest,
    /** (8). internal flag used by EV. send this query to DM */
    QueryCantHandleTimedRequest,
    /** (9). this is an alert request containing no alert attribs */
    QueryNoAlertAttribs,
    /** (10). internal signal. this is an alert request */
    QueryAlertRequest,
    /** (11). outer joins are not supported */
    QueryNoOuterJoins,
    /** (12). internal signal. no more lines available */
    QueryNoMoreLines,
    /** (13). query has been cancelled due to low memory */
    QueryTableOverflow,
    /** (14). there is a group function in a column to group by */
    QueryCannotGroupByFunction,
    /** (15). group by and order by differ */
    QueryGroupByNotInOrderBy,
    /** (16). connect mode not supported for group functions */
    QueryConnectGroupByNotSupported,
    /** (17). syntax error in condition part of query */
    QueryExtendedSyntaxError,
    /** (18). no matching datapoints found - maybe syntax error */
    QueryNoMatchFoundError,
    /** (19). ALERT supports only SYS:DP.EL for FROM-part */
    QueryWrongFromLevelForAlert,
    /** (20). ORDER BY requested for invalid column */
    QueryOrderByColInvalid,
    /** (21). TIMERANGE time 1 is later than time 2 */
    QueryWrongTimeRange,
    /** (22). internal flag used by EV. send this query to distributed System */
    QueryCantHandleRemoteRequest,
    /** (23). cannot handle System that ist not connected */
    QueryRemoteSystemFailed,
    /** (24). cannot handle System that ist not connected */
    QueryNoRemoteSystem,
    /** (25). duplicated values in DB are not allowed */
    QueryDupValuesInDb,
    /** (26). Group Name has illegal characters */
    QueryIllGroupNameError,
    /** (27). braces within DPGROUP-statement do not match */
    QueryBraceMatchError,
    /** (28). something within resolution of Group-DP went wrong */
    QueryGroupError,
    /** (29). Parsing the query took to long */
    QueryToComplex,
    /** (30). Alert query only supports alert config */
    QueryWrongConfigForAlert,
    /** (31). Language Filter uses not parameterized language */
    QueryLanguageError,
    // 11.11.2019 esperrer TFS 68362: ALL request should not be sent to NGA
    /** (32). internal flag used by EV. send this query to DM */
    QueryCantHandleTimedAllRequest
    };

/** the query instance. this class holds the functions to parse, initiate and finish a query. 
    the retrieving of values has to be solved in the specific manager. however, all the other stuff
    is supported by this class.
    @classification ETM internal
*/
class DLLEXP_MANAGER QueryList
{
  friend class UNIT_TEST_FRIEND_CLASS;

  public:
    /** constructor. this initializes a query table.
        @param connect the query table should handle hotlink messages, default is PVSS_FALSE
        @param handleTR the query table should handle timed requests, default is PVSS_FALSE. this means
          an error QueryCantHandleTimedRequests is returned when a timed request is encountered.
        @classification ETM internal
    */
    QueryList(PVSSboolean connect = PVSS_FALSE, PVSSboolean handleTR = PVSS_FALSE);
    /// destructor
    virtual ~QueryList();
    
    /** tool function. initiate, analyse and execute query.
        @param query the query string
        @return QueryOK on success or an appropriate error code
    */
    virtual QueryFaultType doQuery(const CharString &query);

    /** tool function. this function serves as syntax check tool. it performs the parse step only.
        no table is initialized. only syntax errors can be found, no dp name check is performed.
        @param query the query string
        @return QueryOK on success, errorcode otherwise
    */
    QueryFaultType checkSyntax(const CharString &query);

    /** rputz: IM 70702 ExternHdl calls checkSyntax it also has to check if we are distributed
                And check Syntax didn�t check this
    */
    QueryFaultType checkDistribution();
    
    /** tool function. drop all data in list and preprocess memory.
    */
    void drop();
    
    void resetLineCounter() {lineReset = PVSS_FALSE; lastLine = 0;}

    PVSSboolean isTimedRequest() const {return timedRequest;}
    PVSSboolean isConnection() const {return connectRequest;}
    PVSSboolean isAlertRequest() const {return alertRequest;}
    PVSSboolean isAlertSingle() const {return alertSingle;}  // TI 4345
    PVSSboolean isGroupRequest() const {return (groupCt) ? PVSS_TRUE : PVSS_FALSE;}
    
    DynPtrArrayIndex nofRows() const {return results.nofItems(); };
    DynPtrArrayIndex nofCols() const {return header.nofItems(); };
    DynPtrArrayIndex hasDirtyLines() const {return dirtyLines; }

    const CharString &getQueryText() const {return queryText;}
    PVSSushort getResultCompFlags() const {return resultCompFlags;}
    
    void setSendAll(PVSSboolean what = PVSS_FALSE) {sendAll = what;}
    PVSSboolean shallSendAll() const {return sendAll;}
    PVSSboolean needAlias() const {return aliasInUse;}

    PVSSboolean getSendAnswer() const { return shouldSendAnswer; }
    
    const DpIdentifier &getHeaderId(DynPtrArrayIndex i) {return *header.getAt(i); }

    /** to transfer results, call getDynDynAnyType() to get DynVar *
        after send, call releaseDynDynAnyType() to check out the variables
        the message deletes the DynVar
        @param getLast if PVSS_TRUE get the last line only (bei hotlinks)
        @param line a modified line. Valid only if getList == PVSS_TRUE. NULL means 'last line'
        @param noHeader if PVSS_FALSE the header row is additionally created, if PVSS_TRUE it is skipped
        @param estimatedRowCount value to resize the DynVar srAsDynDynVar right after allocation,
                                 only used if getLast == PVSS_TRUE and noHeader == PVSS_FALSE,
                                 estimated row count is without header row
    */
    DynVar *getDynDynAnyType(
        PVSSboolean getLast = PVSS_FALSE,
        LineSet *line = 0,
        PVSSboolean noHeader = PVSS_FALSE,
        unsigned int estimatedRowCount = 0);
    
    /** Finalize after creation of the DynVar srAsDynDynVar by getDynDynAnyType.
        The DynVar srAsDynDynVar that was possibly allocated too big is resized to its actual size.
        Necessary when getDynDynAnyType was called iteratively (getLast = PVSS_TRUE).
        Nothing to do if srAsDynDynVar is still NULL.
    */
    void finalizeDynDynAnyType();

    // Das Argument gibt ab, ob die DynVar srAsDynDynVar ebenfalls geloescht werden soll.
    void releaseDynDynAnyType(PVSSboolean delFlag = PVSS_FALSE);

    /** fetch internal error text due to error type
    */
    const char *getErrorText(QueryFaultType);
    
    static int sortEntryPt(const LineSet *, const LineSet *);
    
    /** this is the internal sorting function called by ::sortFunc
        two items are equal if they are equal in all compares columns
        variable *NULL are sorted to the end
        Note that LangTextVar texts are technically sorted and not locale aware.
    */
    static int compareFunction(const LineSet *, const LineSet *, int);
    
    static int resultCompare(const LineSet *, const LineSet *);
    
    const CharString &getString() const { return queryText; }

    const CharString &getAttribPart() const { return attribPart; }
    
    // print out current query state
    virtual void reportState(std::ostream &) const;

    /// In distributed settings deliver the broadcast information
    PVSSboolean  getRemoteAll() const { return remoteAll; }

    /// in distributed setting deliver the names
    const CharString &getRemoteSystem() const { return remoteSys; }

    /// delivers archiveno if existent in query; if not delivers -1
    long getArchiveNum() const { return archiveNum_; }

  protected:

    // used for preprocess query
    QueryFaultType parseQuery();
    QueryFaultType breakQuery(PVSSboolean rescanHeaderOnly = PVSS_FALSE);   

    // needed for Ev alert connect
    virtual QueryFaultType preprocessQueryForAlertConnect();

    QueryFaultType preprocessQuery();
    QueryFaultType prepareOneLine(LineSet *newLine, const DpIdentifier &mask);
    
    // interface for immediate requests
    virtual QueryFaultType fillTable();

    DynPtrArrayIndex findFirstResult(const DpIdentifier &, PVSSushort flags = DpIdentifier::compAll, Variable *tm = 0);
    QueryFaultType sortTable();

    QueryFaultType evaluateGroups();
    PVSSboolean isNewGroup(DynPtrArrayIndex);
    
    // TI 8086 WOKL
    // Methode zum Ueberschreiben in Event und Data - die DPGruppen muessen in
    // BreakQuery() sowie in NewDelDp() aufgeloest werden
    QueryFaultType replaceDpGroup( const CharString &fromPart, CharString &resolved, DpIdentList &list, SystemNumType sys = 0, DpIdType dp = 0);

    // Replace group name with comma separated dp-list
    PVSSboolean  getDpNamesFromGroup(const CharString &group, CharString &res);
    
    // Get List of DpIDs from group. This function will observe the WHERE condition if possible.
    PVSSboolean  getDpIdsFromGroup(const CharString &group, DpIdentList &list, SystemNumType sys = 0, DpIdType dp = 0);
    
    // Get DynVar-Value for DP-Element. Return 0, if value is not a DynVar
    virtual DynVar * getLastDynVar(const CharString &dpe);

    void debug();
    void debugLine(const LineSet *);

    static PVSSboolean isActive;
    static long **activeSortColumns;
    static int activeSortCt;
  
    CharString queryText;
    DynPtrArrayIndex lastLine;
    DynPtrArrayIndex currentRowCount;
    PVSSboolean lineReset;

    CharString  fromPart;
    PVSSboolean remoteAll;       // Query includes all distributed systems
    CharString  remoteSys;       // if not own system -> send to distributed system
    CharString  attribPart;
    
    PVSSboolean timedRequest;    // if true -> use DB instead of local Manager
    PVSSboolean getAllRequest;    // same as timedrequest, but time from 1.1.1970 - maxTime
    PVSSboolean reportRequest;

    PVSSboolean notVirtualRequest;
    PVSSboolean connectRequest;
    PVSSboolean alertRequest;
    PVSSboolean alertSingle;
    PVSSboolean sendAll;        // TRUE if whole table is to be sent in hotlink
    PVSSboolean shouldSendAnswer;
    
    long maxRows;               // return first xx rows (last if neg, all if 0)
    long **sortColumns;          // allow sort criterias for now, desc if neg.!
    int sortCt;                // how many entries in sortArray?
    long **groupColumns;          // allow group criterias for now, neg if dp-parts!
    int groupCt;                // how many entries in groupArray?

    QueryTreeNode *conditions;
    QueryTreeNode *havings;

    DpSymIdLevel ColsStartLevel;
    DpSymIdLevel MaxColStartLevel;

    ExtTimeVar startQuery;
    ExtTimeVar endQuery;
    long frameNumber;        // get more entries around the asked time frame
    long timeQueryMode;

    ExtTimeVar reportStart;
    ExtTimeVar reportEnd;

    DynPtrArrayIndex headerLength;
//    TitleSet titles;
    RowSet header;
    RowSet rowmask;
  
    TableSet results;  
    TableSet sortedResults;
    DynVar *srAsDynVar;
    PVSSushort resultCompFlags;

    DynPtrArrayIndex dirtyLines;    // used when processing hotlink
    PVSSboolean handleTimedRequests;

    PVSSulong queryId;
    PVSSulong groupSecs;
    PVSSulong groupStartSecs;
    
    GroupLineSet groupEvaluator;
    TableSet groupResults;

    DpTypeId myDpType;        // these are used when query string is simplified ( -> breakQuery)
    DpElementType myElType;
    PVSSboolean leaf_flag;

    PVSSboolean aliasInUse;

    // TI 8086 WOKL
    CharString dpGroupPart;   // wird nur belegt, wenn DPGROUP(..) vorkommt
    PVSSboolean dpGroupInUse; // ist in diesem Falle dann TRUE

    GlobalLanguageIdType qlFilterLang;

  private:
    // so that the compiler does not define them itself !!
    // copy constructor
    QueryList(const QueryList &) {}  //COVINFO LINE: defensive (AP: no copy allowed)
    // assignment operator
    QueryList &operator=(const QueryList &) { return *this; } //COVINFO LINE: defensive (AP: no operator= allowed)

    PVSSboolean   checkForLEAF();
    //Sucht nach einem eindeutigen _DPT und gibt ihn zur�ck wenn er ihn findet
    //Sollte er einen Filter haben (vergleich mit QTN_EQUAL) wird FilterEQFound auf true gesetzt
    DpTypeId      checkForDPT(bool &FilterEQFound);
    //Sucht nach einem eindeutigen _ELC und gibt ihn zur�ck wenn er ihn findet
    //Sollte er einen Filter haben (vergleich mit QTN_EQUAL) wird FilterEQFound auf true gesetzt
    DpElementType checkForELC(bool &FilterEQFound);

    // check alert specific query conditions
    QueryFaultType verifyAlertQuery(const GroupLineSet &groupEvaluator, const DpSymIdLevel &bottomUp);

    long archiveNum_;
};

#endif /* _QUERYLIST_H_ */
