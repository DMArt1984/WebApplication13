#ifndef _DPIDENTIFIER_H_
#define _DPIDENTIFIER_H_

// VERANTWORTUNG: Stanislav Meduna
// BESCHREIBUNG: Die komplette Adresse einer Parametrierung.
//    Ungueltige Felder besitzen den Wert 0, bzw.
//    DPCONFIG_NOCONFIG.

#ifndef _DPTYPES_H_
#include <DpTypes.hxx>
#endif

#ifndef _DPCONFIGNRTYPE_H_
#include <DpConfigNrType.hxx>
#endif

#include <iostream>


class CharString;

class itcNdrUbSend;
class itcNdrUbReceive;

// ========== DpIdentifierPtr ============================================================
class DpIdentifier;
typedef DpIdentifier* DpIdentifierPtr;

// ========== DpIdentifier ============================================================

/** The DpIdentifier class.
    Although datapoint attributes are accessible by names, they are stored as numbers internally.
    This class holds a complete identifier for PVSS-II datapoint attributes.
    an identifier consists of 6 main numbers (SYS:DP.EL:CF.Dt.AT) and has additional information
    about the DpType and AlertTime (in case of AlertIdentifier which is derived from this class).
    Some numbers may be 0, e.g. (DP.EL) identifies a datapoint element, (CF.Dt.AT) just an attribute
    without a datapoint.
*/
class DLLEXP_BASICS DpIdentifier
{
  /// <summary>
  /// Declare test class as a friended class, having access to private/protected methods
  /// </summary>    
  friend class UNIT_TEST_FRIEND_CLASS;
  
public:
  /** Flags for comparing two DpIdentifiers with isEqual().
      Flags can be combined with the binary or operator '|'.
  */
  enum dpCompFlags
  {
    /// Compare attributes
    compAttr = 0x0001,
    /// Compare details
    compDet  = 0x0002,
    /// Compare configs
    compConf = 0x0004,
    /// Compare elements
    compEl   = 0x0008,
    /// Compare datapoint ids
    compDp   = 0x0010,
    /// Compare system ids
    compSys  = 0x0020,
    /// Compare datapoint type ids
    compType = 0x0040,
    /// Compare alert time
    compTime = 0x0080,
    /// Compare datapoint and element id
    compDpEl = compDp | compEl,
    /// Compare system, datapoint and element id
    compSysDpEl = compSys | compDp | compEl,
    /// Compare config, detail and attribute
    compConfDetAttr = compConf | compDet | compAttr,
    /// Compare all
    compAll  = 0xFFFF
  };

  /// Defalt constructor
  DpIdentifier();
  /// Copy constructor
  DpIdentifier(const DpIdentifier &id);

  /// Constructor.  This will initiliaze the DpIdentifier with explicit given system, datapoint, ...
  DpIdentifier(SystemNumType aSys, DpIdType aDp = 0, DpElementId anEl = 0,
               DpConfigNrType aConf = DPCONFIGNR_NOCONFIGNR,
               DpDetailNrType aDet = 0, DpAttributeNrType anAttr = 0);

  /// Destructor
  virtual ~DpIdentifier();

  /** @name operators
    The comparision operators will compare all numbers from system to attribute plus the type id.
  */
  //@{
  /// Assignment operator
  const DpIdentifier &operator=(const DpIdentifier &id);
  /// Comparison operator.
  int operator==(const DpIdentifier &id) const
      { return (dp == id.dp && el == id.el && config == id.config && attr == id.attr && detail == id.detail &&
                system == id.system && dpType == id.dpType); }
  /// Comparison operator. This operator is implemented as (! operator==)
  int operator!=(const DpIdentifier &id) const { return ! (*this == id);}
  /// Comparison operator
  int operator<(const DpIdentifier &id) const;
  /// Comparison operator
  int operator>(const DpIdentifier &id) const {return !(*this == id || *this < id);}
  /// Comparison operator
  int operator<=(const DpIdentifier &id) const {   return (*this == id || *this < id); } // keep this because of doc++ error!
  /// Comparison operator implemented as ( ! < )
  int operator>=(const DpIdentifier &id) const { return ! (*this < id);}

  /** Assignment operator.
      This operator will set all numbers which are != 0 in id.
      All others, that are == 0 in id, are not changed.
  */
  int operator+=(const DpIdentifier &id);

  friend DLLEXP_BASICS itcNdrUbSend &operator<<(itcNdrUbSend &ndrStream, const DpIdentifier &id);
  friend DLLEXP_BASICS itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream, DpIdentifier &id);
  //@}

  /// Clear all numbers. After this call 'isNull()' will return PVSS_TRUE.
  virtual void invalidateAll();

  /** Print debug information to a stream.
      The second argument controls the amount of debug information printed. If the manager has a
      DpIdentification, the name is printed first, otherwise only the numbers are printed.
      @param to     The output stream
      @param level  Controls the debug information printed. If level is 0, nothing is printed.
  */
  virtual void debug(std::ostream &to, int level) const;

  /** Compare two DpIdentifier according to the given flags.
      Use this function to sort DpIdentifiers according to system, datapoint, element, ...
      @return -1, 0, +1, if this is less than, equal with or greater than withDpId
      @param withDpId     DpIdentifier to be compared with
      @param compareKey   Flags which specify what to compare. Default is 'compAll'.
  */
# if 0
  // DOC++: dpCompFlags ergibt einen Link zum enum
  int compare(const DpIdentifier &withDpId, dpCompFlags compareKey = compAll) const;
# endif
  int compare(const DpIdentifier &withDpId, PVSSushort compareKey = compAll) const;

  /** Static compare function. This function will call t1->compare(t2, compAll).
      Use this function to sort DpIdentifier with DynPtrArray<DpIdentifier>.
  */
  static int compareDp(const DpIdentifier *t1, const DpIdentifier *t2);

  // die im compareKey gesetzten Bits bestimmen, was verglichen wird
  // dazu sind Konstanten definiert, welche verodert werden koennen
  /** Compare two DpIdentifier according to the given flags.
      Use this function to test for equality.
      @return PVSS_TRUE if both are equal, PVSS_FALSE otherwise.
      @param withDpId     DpIdentifier to be compared with
      @param compareKey   Flags which specify what to compare. Default is 'compAll'.
  */
# if 0
  // DOC++: dpCompFlag ergibt einen Link zum enum
  PVSSboolean isEqual(const DpIdentifier &withDpId, dpCompFlags compareKey = DpIdentifier::compAll) const;
# endif
  PVSSboolean isEqual(const DpIdentifier &withDpId, PVSSushort compareKey = DpIdentifier::compAll) const;

  /// Check for an empty DpIdentifier. Returns PVSS_TRUE, if all numbers are invalid, PVSS_FALSE otherwise.
  int isNull() const { return (system.isNull() ) && (dp == 0) && (el == 0) &&
                              (config == DPCONFIGNR_NOCONFIGNR) &&
                              (detail == 0) && (attr == 0) && (dpType == 0); }

  /**
    Checks if an DpIdentifier is in range to another.
    This is simply be done by comparison operators
  */
  PVSSboolean inRangeInclusive(const DpIdentifier &id1, const DpIdentifier &id2) const;

  /** Convert DpIdentifier to a string.
      The convert function must be set. The Manager class will do this when
      it receives the DpIdentification.
      @param  out  The String that will receive the result
      @return true, if this was a valid DpId
  */
  PVSSboolean convertToString(CharString &out) const;

  /** Convenient function to generate a string representation without returning a "valid" information.
      Mainly useful in ErrHdl output.
  */
  CharString toString() const;

  /// Set the convertToString function
  static  void  setConvertToStringFct(PVSSboolean (*fct)(const DpIdentifier &dpId, char *&name));

  /** Convert a string to a DpIdentifier.
      The convert function must be set. The Manager class will do this when
      it receives the DpIDentification.
      @param  from The input string
      @return true if the string was a valid DpId
  */
  PVSSboolean convertFromString(const CharString &from);

  /// Set the convertFromString function
  static  void  setConvertFromStringFct(PVSSboolean (*fct)(const char *name, DpIdentifier &dpId));

  // Generierte Methoden :
  /** @name Get / Set the numbers
  */
  //@{
  /// Get the system number
  SystemNumType getSystem() const;
  /// Set the system number
  void setSystem(SystemNumType newSystem);
  /// Get the dp number
  DpIdType getDp() const;
  /// Set the dp number
  void setDp(DpIdType newDp);
  /// Get the element number
  DpElementId getEl() const;
  /// Set the element number
  void setEl(DpElementId newEl);
  /// Get the config number
  DpConfigNrType getConfig() const;
  /// Set the config number
  void setConfig(DpConfigNrType newConfig);
  /// Get the detail number
  DpDetailNrType getDetail() const;
  /// Set the detail number
  void setDetail(DpDetailNrType newDetail);
  /// Get the attribute number
  DpAttributeNrType getAttr() const;
  /// Set the attribute number
  void setAttr(DpAttributeNrType newAttr);
  /// Get the dp type number
  DpTypeId getDpType() const;
  /// Set the dp type number
  void setDpType(DpTypeId newDpType);
  //@}

protected:
  /// The System Number 
  SystemNumType     system;

  /// The Datapoint Number
  DpIdType          dp;

  /// The Element Number
  DpElementId       el;

  /// The Config Number
  DpConfigNrType    config;

  /// The Detail Number
  DpDetailNrType    detail;

  /// The Attribute Number
  DpAttributeNrType attr;

  /// The Dp Type Number
  DpTypeId          dpType;

private:
  static  PVSSboolean (*convertToStringFct)(const DpIdentifier &, char *&);
  static  PVSSboolean (*convertFromStringFct)(const char *, DpIdentifier &);
};

#ifdef WIN32
#pragma warning ( disable: 4231 )
#endif

#if defined(LIBS_AS_DLL)
  #include <DynPtrArray.hxx>
  EXTERN_BASICS template class DLLEXP_BASICS DynPtrArray<DpIdentifier>;
#endif

#ifdef WIN32
#pragma warning ( default: 4231 )
#endif



// ================================================================================
// Inline-Funktionen :
inline const DpIdentifier &DpIdentifier::operator=(const DpIdentifier &id)
{
  system    = id.system;
  dp        = id.dp;
  el        = id.el;
  config    = id.config;
  detail    = id.detail;
  attr      = id.attr;
  dpType    = id.dpType;

  return *this;
}


inline SystemNumType DpIdentifier::getSystem() const
{
  return system;
}


inline DpIdType DpIdentifier::getDp() const
{
  return dp;
}


inline DpElementId DpIdentifier::getEl() const
{
  return el;
}


inline DpConfigNrType DpIdentifier::getConfig() const
{
  return config;
}


inline DpDetailNrType DpIdentifier::getDetail() const
{
  return detail;
}


inline DpAttributeNrType DpIdentifier::getAttr() const
{
  return attr;
}


inline DpTypeId DpIdentifier::getDpType() const
{
  return dpType;
}


inline void DpIdentifier::setSystem(SystemNumType newSys)
{
  system = newSys;
}


inline void DpIdentifier::setDp(DpIdType newDp)
{
  dp = newDp;
}


inline void DpIdentifier::setEl(DpElementId newEl)
{
  el = newEl;
}


inline void DpIdentifier::setConfig(DpConfigNrType newConfig)
{
  config = newConfig;
}


inline void DpIdentifier::setDetail(DpDetailNrType newDetail)
{
  detail = newDetail;
}


inline void DpIdentifier::setAttr(DpAttributeNrType newAttr)
{
  attr = newAttr;
}

inline void DpIdentifier::setDpType(DpTypeId newDpType)
{
  dpType = newDpType;
}


inline DpIdentifier::DpIdentifier()
 : system(0),
   dp    (0),
   el    (0),
   config(DPCONFIGNR_NOCONFIGNR),
   detail(0),
   attr  (0),
   dpType(0)
{
}

inline DpIdentifier::DpIdentifier(const DpIdentifier &id)
{
  *this = id;
}

inline DpIdentifier::DpIdentifier(SystemNumType aSys, DpIdType aDp, DpElementId anEl, DpConfigNrType aConf, DpDetailNrType aDet, DpAttributeNrType anAttr)
  : system(aSys),
  dp(aDp),
  el(anEl),
  config(aConf),
  detail(aDet),
  attr(anAttr),
  dpType(0)
{
}

inline DpIdentifier::~DpIdentifier()
{
}

inline PVSSboolean DpIdentifier::isEqual(const DpIdentifier &withDpId, PVSSushort compareKey) const
{
  // Sortiert nach der Wahrscheinlichkeit des Unterschieds
  return (((compareKey & DpIdentifier::compDp)   == 0 || dp     == withDpId.dp)     &&
          ((compareKey & DpIdentifier::compEl)   == 0 || el     == withDpId.el)     &&
          ((compareKey & DpIdentifier::compConf) == 0 || config == withDpId.config) &&
          ((compareKey & DpIdentifier::compAttr) == 0 || attr   == withDpId.attr)   &&
          ((compareKey & DpIdentifier::compDet)  == 0 || detail == withDpId.detail) &&
          ((compareKey & DpIdentifier::compSys)  == 0 || system == withDpId.system) &&
          ((compareKey & DpIdentifier::compType) == 0 || dpType == withDpId.dpType));
}

inline PVSSboolean DpIdentifier::inRangeInclusive(const DpIdentifier &id1, const DpIdentifier &id2) const
{
  if (id1 < id2)
      return (*this >= id1 && *this <= id2);

  return (*this >= id2 && *this <= id1);
}

inline void DpIdentifier::invalidateAll()
{
  system  = 0;
  dp      = 0;
  el      = 0;
  config  = DPCONFIGNR_NOCONFIGNR;
  detail  = 0;
  attr    = 0;
  dpType  = 0;
}


inline  void  DpIdentifier::setConvertToStringFct(PVSSboolean (*fct)(const DpIdentifier &dpId, char *&name))
{
  convertToStringFct = fct;
}


inline  void  DpIdentifier::setConvertFromStringFct(PVSSboolean (*fct)(const char *name, DpIdentifier &dpId))
{
  convertFromStringFct = fct;
}


inline std::ostream &operator<<(std::ostream &oStream, const DpIdentifier &id)
{
    id.debug(oStream, 1);
    return oStream;
}

#endif /* _DPIDENTIFIER_H_ */
