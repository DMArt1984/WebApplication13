#ifndef INCLUDE_CONFIGVARIF_HXX
#define INCLUDE_CONFIGVARIF_HXX  // [

#include <DynVar.hxx>
#include <TextVar.hxx>
#include <IntegerVar.hxx>

#include <Config.hxx>

// ========== ConfigVarIF ============================================================

/** This class handles the PVSS Config file
    @classification internal use
*/
class DLLEXP_BASICS ConfigVarIF
{
public:
  friend class UNIT_TEST_FRIEND_CLASS;
  /// ATTENTION: these errors must be set in Pv2AdminExternHdl.cxx on corresponding PA-Error
  enum
  {
    E_ILL_VARTYPE  = 30,
    E_CONFIG_OPEN  = 31,
    E_CONFIG_CLOSE = 32,
    E_INSERT_ERROR = 33,
    E_NOT_FOUND    = 34
  };

  /** constructor, initialisation with zero values
    */
  ConfigVarIF() { ; };

  /** destructor
    */
  ~ConfigVarIF() { ; };

  /** @name Read functions
    */
  //@{

  /** search for given section, key and eventually host in given config file(s) 
      and return last valid matching value or list of values
      @param configFile the DynVar or TextVar specifying one or more files to be read
      @param section the section
      @param key the DynVar or TextVar specifying one or more keys
          @n If empty list, all keys are considered to be matching.
      @param value the returned value, can be TextVar, IntegerVar or FloatVar
          @n If the internal value doesn't fit, an error is returned.
      @param host the host
      @return 0 on success (all keys found)
  */
  int readValue( const Variable& configFile, const TextVar section, const Variable& key, 
                 Variable& value, const TextVar host = "" );

  /** search for given section, key and eventually host in given config file(s) 
      and return last valid matching value or list of values
      @param configFile the DynVar or TextVar specifying one or more files to be read
      @param section the section
      @param key the DynVar or TextVar specifying one or more keys
          @n If empty list, all keys are considered to be matching.
      @param value the returned value, can be TextVar, IntegerVar or FloatVar
          @n If the internal value doesn't fit, an error is returned.
      @param host the host
      @return 0 on success (all keys found)
  */
  int readValue( const Variable& configFile, const TextVar section, Variable& key, 
                 Variable& value, const TextVar host = "" );

  /** search for given section, key and eventually host in given config file(s) 
      and return last valid matching value
      @param configFile the DynVar or TextVar specifying one or more files to be read
      @param section the section
      @param key the key
      @param value the returned value, can be TextVar, IntegerVar or FloatVar
          @n If the internal value doesn't fit, an error is returned.
      @param host the host
      @return 0 on success (the key found)
  */
  int readSingleValue ( const Variable &configFile, const TextVar section, const TextVar key, 
                        Variable &value, const TextVar host = "" );

  /** search for given section, key and eventually host in given config file(s) 
      and return list of valid matching value
      @param configFile the DynVar or TextVar specifying one or more files to be read
      @param section the section
      @param key the list of multiple keywords, can be the several times the same too
      @param value the returned list of values
      @param host the host
      @return 0 on success (all keys found)
  */
  int readMultipleValue ( const Variable &configFile, const TextVar section, const DynVar key, 
                        DynVar &value, const TextVar host = "" );

  /** search for given section, key and eventually host in given config file(s) 
      and return list of valid matching value
      @param configFile the DynVar or TextVar specifying one or more files to be read
      @param section the section
      @param key the list of multiple keywords, can be the several times the same too
      @param value the returned list of values
      @param host the host
      @return 0 on success (all keys found)
  */
  int readMultipleValue2 ( const Variable &configFile, const TextVar section, DynVar &key, 
                       DynVar &value, const TextVar host = "" );


  /** search for given section, key and eventually host in given config file(s) 
      and return list of valid matching value separeted by separator
      @param configFile the DynVar or TextVar specifying one or more files to be read
      @param section the section
      @param key the key
      @param valList the returned list of values
      @param separator the separator
      @param host the host
      @return 0 on success (all keys found)
  */
  int readValueList( const Variable &configFile, const TextVar section, const TextVar key, 
                     DynVar &valList, const TextVar separator = "", const TextVar host = "" );
  //@}

  /** @name Insert, delete functions
    */
  //@{

  /** insert a key/value pair into given section of given config file (at the end
      of the last one from all matching ones)
      @param filename the filename specifying config file
      @param section the section
      @param key the key
      @param value the value to insert, can be TextVar, IntegerVar or FloatVar
      @param host the host
      @return 0 on success
  */
  int insertValue( const TextVar &filename, const TextVar &section, 
      const TextVar &key, const Variable &value, const TextVar &host );

  /** insert key/value pairs into given section of given config file (at the end
      of the last one from all matching ones)
      @param filename the filename specifying config file
      @param section the section
      @param keys the list of keys
      @param value the list of values to insert
      @param host the host
      @return 0 on success
  */
  int insertValue( const TextVar &filename, const TextVar &section, 
      const Variable &keys, const Variable &value, const TextVar &host );


  /** insert one or more key/value pairs into given section of given config file
      before/after the first/last searchKey
      @param filename the filename specifying config file
      @param section the section
      @param op the operation: BEFORE_FIRST(1), BEFORE_LAST(2), AFTER_FIRST(3), AFTER_LAST(4).
      @param searchKey the key to search
      @param keys the list of keys
      @param value the value to insert, can be TextVar, IntegerVar or FloatVar
      @param host the host
      @return 0 on success
  */
  int insertValue( const TextVar &filename, const TextVar &section, 
      IntegerVar op, const TextVar &searchKey,
      const Variable &keys, const Variable &value, const TextVar &host );

  /** delete all occurences of given key/value pair of given section of given config file
      @param filename the filename specifying config file
      @param section the section
      @param key the key
      @param value the value to delete, can be TextVar, IntegerVar or FloatVar
      @param host the host
      @return 0 on success
  */
  int deleteValue( const TextVar &filename, const TextVar &section, 
      const TextVar &key, const Variable &value, const TextVar &host );
  //@}

private:
  // not for use
  ConfigVarIF( ConfigVarIF &ref );

  // private methods
  /// INTERNAL - single config file method 
  int readSingleValue ( const TextVar &configFile, const TextVar section, const TextVar key, 
                        Variable &value, const TextVar host = "" );

  /// INTERNAL - single config file method 
  // NOT FOR FUTURE USE!
  int readMultipleValue ( const TextVar &configFile, const TextVar section, const DynVar key, 
                        DynVar &value, const TextVar host = "" );

  /// INTERNAL - single config file method 
  int readMultipleValue2 ( const TextVar &configFile, const TextVar section, DynVar &key, 
                        DynVar &value, const TextVar host = "" );

  /// INTERNAL - single config file method
  int readValueList( const TextVar &configFile, const TextVar section, const TextVar key, 
                     DynVar &valList, const TextVar host = "" );

  /// INTERNAL - separation method
  int separateValues( DynVar &valueList, const char* separator );

  // only private member
};

// Inlines ---------------------------------------------------


#endif // INCLUDE_CONFIGVARIF_HXX ]

