// DATEIBESCHREIBUNG ==============================================================
// DATEINAME:     DpMsgInitConfig.hxx
// VERANTWORTUNG:	WOLFGANG SCHUH + PETER PENTEK
// 
// BESCHREIBUNG:	DpInitMsgConfig dient zum Verschicken eines Datenpunktes mit
// 		all seinen zugehoerigen DpConfigs
// 		
// 		Das Verschicken der Datenpunkte geschieht ausschliesslich im
// 		Hochlauf. Deshalb benoetigt diese Message nie eine Antwort.
//
// AENDERUNGS-HISTORIE
// Ver.  | Datum      | Aenderungen                            | ModNr.| Autor
// ------+------------+-----------------Anfang-----------------+-------+-----------
//   1.0 |            | 1.Erstellung mit Westmount-OMT         |     0 |
// ======================================Ende======================================
#ifndef _DPMSGINITCONFIG_H_
#define _DPMSGINITCONFIG_H_

// Vorwaerts-Deklaration der Eigenen Klasse
class DpMsgInitConfig;

// System-Include-Files
#include <DpMsg.hxx>
#include <DpICGroup.hxx>

#include <Allocator.hxx>

// Vorwaerts-Deklarationen :
class DpMsgInitConfig;
class ManagerIdentifier;
class Msg;
// ========== DpMsgInitConfig ============================================================
/** DpMsg for sending a datapoint with all its corresponding config elements.
 *  This message is used only in the initialization phase, so it needs no answer
 */
class DLLEXP_MESSAGES DpMsgInitConfig : public DpMsg 
{
  friend class UNIT_TEST_FRIEND_CLASS;
  friend class UNIT_TEST_FRIEND_CLASS2;

  // Klassen-Enums:

// ..........................Anfang User-Klasseninterne-Definitionen..................
// ...........................Ende User-Klasseninterne-Definitionen...................
public:
  // Konstruktor
  /// Default constructor
  DpMsgInitConfig();

  /// Copy constructor
  DpMsgInitConfig(const DpMsgInitConfig &newMsg);

  /** Constructor
   * @param newDestination the Manager that shall receive this message
   */
  DpMsgInitConfig(ManagerIdentifier &newDestination);

  /// Destructor
  ~DpMsgInitConfig();

  /// Allocator class
  AllocatorDecl;


  // Operatoren :
  /** BCM output streaming operator
   * @param[in,out] ndrStream the BCM stream to write to
   * @param dpMsgInitConfig the DpMsgInitConfig instance to be written
   */
  friend DLLEXP_MESSAGES itcNdrUbSend &operator<<(itcNdrUbSend &ndrStream, const DpMsgInitConfig &dpMsgInitConfig);

  /** BCM input streaming operator
   * @param[in,out] ndrStream the BCM stream to read from
   * @param[out] dpMsgInitConfig the DpMsgInitConfig instance to be read
   */
  friend DLLEXP_MESSAGES itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream, DpMsgInitConfig &dpMsgInitConfig);

  /** Comparison operator
   * @param rVal the DpMsgInitConfig to compare with
   */
  int operator==(const DpMsgInitConfig &rVal) const;

  /** Comparison operator for Msg
   * @param rVal the Msg to compare with
   */
  virtual int operator==(const Msg &rVal) const;

  /** Copy operator
   * @param rVal the message to copy
   */
  DpMsgInitConfig &operator=(const DpMsgInitConfig &rVal);

  /** Assignment operator
   * @param rVal the message to copy
   */
  virtual Msg &operator=(const Msg &rVal);

  // Spezielle Methoden :
  /** Allocate instance
   * @return a new DpMsgInitConfig instance, the caller takes responsibility
   */
  virtual Msg *allocate() const;

  /** Is of type
   * @param dpMsgType msg type to be comared with
   * @returns dpMsgType if compatible, NO_MSG if not
   */
  virtual MsgType isA(MsgType dpMsgType) const;

  /// Returns the type of this message
  MsgType isA() const;

  /** Debug output method
   * @param[out] to the stream to write to
   * @param level controlls the amount of debug information, the higher the more
   */
  virtual void debug(std::ostream &to, int level) const;

  /** Inserts a new init-config group. This method makes a deep copy of the given
   *  DpICGroup, so insertDpMsgInitConfigs(DpICGroup*) is faster.
   * @param newDpMsgInitConfigs init-config group
   */
  void insertDpMsgInitConfigs(const DpICGroup &newDpMsgInitConfigs);

  /** Inserts a new init-config group.
   * @param newDpMsgInitConfigs init-config group, this method takes responsibility
   */
  void insertDpMsgInitConfigs(DpICGroup *newDpMsgInitConfigs);

  /// Gets the first DpICGroup
  DpICGroup *getFirstGroup() const { return (DpICGroup *)groupList.getFirst(); }
  /// Gets the next DpICGroup
  DpICGroup *getNextGroup() const { return (DpICGroup *)groupList.getNext(); }
  /// Get count of init-config groups
  PVSSulong getNrOfGroups() const { return groupList.getNumberOfItems(); }

  /** Gets the id of the group at the specified position
   * @param groupIdx index in the list
   * @return the id of the group or an empty DpIdentifier when the index
   *         is not valid
   */
  virtual DpIdentifier getGroupId(PVSSulong groupIdx) const;

  /// Removes all groups
  void clearGroups() { groupList.clear(); }

protected:
  /** Writes this message to the BCM stream
   * @param[out] ndrStream
   */
  virtual void outNdrUb(itcNdrUbSend &ndrStream) const;

  /** Reads this message from the BCM stream
   * @param[in,out] ndrStream
   */
  virtual void inNdrUb(itcNdrUbReceive &ndrStream);

private:
  ///ic groups list
  PtrList groupList;
};

#endif /* _DPMSGINITCONFIG_H_ */
