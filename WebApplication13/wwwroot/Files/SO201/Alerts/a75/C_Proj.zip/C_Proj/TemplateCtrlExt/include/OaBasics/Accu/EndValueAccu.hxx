#ifndef _ENDVALUEACCU_H_
#define _ENDVALUEACCU_H_

// Author: Wolfram Klebel
// Date:   21.9.2000
// Purpose: implement a statistic Accumulator to determine the first value (sample) within a period

#ifndef _SIMPLEACCU_H_
#include <SimpleAccu.hxx>
#endif

#ifndef _VARIABLE_H_
#include <Variable.hxx>
#endif

#ifndef _TIMEVAR_H_
#include <TimeVar.hxx>
#endif

/// A value accumulator class. This class is used to get the last accumulated value.
/// @classification ETM internal
class DLLEXP_OABASICS EndValueAccu: public SimpleAccu
{
  public:
    /// Constructor.
    /// @param aVarType VariableType of the accumulated values.
    /// @n Supported variable types are INTEGER_VAR, UINTEGER_VAR, FLOAT_VAR and TEXT_VAR.
    /// If other variable type is specified, FLOAT_VAR will be used instead.
    EndValueAccu(const VariableType aVarType);

    /// Destructor.
    virtual ~EndValueAccu();
    
    /// This method will accumulate the value, which means that the getResult() method
    /// will return the value specified in the last call of accumulate().
    /// @param theValue Variable which will be stored in the accumulator. 
    /// @n See constructor description for supported variable types. If variable of
    /// a different type as the one specified in the constructor will be passed here,
    /// it will be converted according to the specific rules implemented in that 
    /// particular Variable classes.
    /// @param atTime Time stamp. This variable is not used.
    virtual void accumulate(const Variable &theValue, const TimeVar &atTime );

    /// This method returns the last accumulated Variable.
    /// @return const reference to a Variable which was passed to the last call of accumulate() method.
    virtual const Variable &getResult();

    /// This method is obsolete (see comment in base class SimpleAccu.hxx). Does nothing.
    virtual void reset();
    
  protected:
  
  private:
    /// prevents the copy constructor to be called.
    EndValueAccu(const EndValueAccu &);

    /// prevents the assignment operator to be called.
    EndValueAccu &operator=(const EndValueAccu &);
  
    /// In this member the last accumulated Variable will be stored.
    Variable *sample;
};

#endif
