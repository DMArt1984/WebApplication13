#ifndef _TypeSpec_H_
#define _TypeSpec_H_

#include <Variable.hxx>
class UserType;

/**
  A struct to define a type, e.g. used at VectorVar to define which type a vector<> contains

  Examples:
  vector<int>                     ... varType = INTEGER_VAR
  vector<void>                    ... varType = NOTYPE_VAR  (special: can hold any Variable; like shared_ptr<void>)
  vector<MyClass>                 ... varType = CLASS_VAR, userType -> MyClass
  vector< shared_ptr<int> >       ... varType = POINTER_VAR, next -> { varType = INTEGER_VAR }
  vector< shared_ptr<MyClass> >   ... varType = POINTER_VAR, next -> { varType = CLASS_VAR, userType -> MyClass }
  vector< vector<int> >           ... varType = VECTOR_VAR,  next -> { varType = INTEGER_VAR }
  vector< vector<MyClass> >       ... varType = VECTOR_VAR,  next -> { varType = CLASS_VAR, userType -> MyClass }
  vector< vector< vector<int> > > ... varType = VECTOR_VAR,  next -> { varType = VECTOR_VAR, next -> { varType = INTEGER_VAR } }

  @classification ETM internal
*/
struct DLLEXP_CTRL TypeSpec
{
  VariableType varType = NO_VAR;
  const UserType *userType = nullptr;
  TypeSpec *next = nullptr;

  TypeSpec() = default;
  TypeSpec(const TypeSpec &other) { *this = other; }
  TypeSpec(const Variable *var);
  TypeSpec(VariableType type, const UserType *utype = nullptr) : varType(type), userType(utype) { }
  TypeSpec(const UserType *utype) : varType(CLASS_VAR), userType(utype) { }

  ~TypeSpec() { delete next; }

  TypeSpec &operator=(const TypeSpec &other);

  bool typeMatches(const TypeSpec &other) const;

  bool operator==(const TypeSpec &other) const;
  bool operator!=(const TypeSpec &other) const { return !(*this == other); }

  bool incRefCount(int fileNumber);  // on UserType
  void incRefCount();  // on UserType
  void decRefCount();  // on UserType

  Variable *allocate(int fileNumber) const;
};

#endif
