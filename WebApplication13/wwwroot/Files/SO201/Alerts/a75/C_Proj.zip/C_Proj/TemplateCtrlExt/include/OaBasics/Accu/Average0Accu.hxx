#ifndef _Average0Accu_H_
#define _Average0Accu_H_

// Author: Heinz MEISSL
// Date:   14.4.1997
// Purpose: implement a statistic Accumulator to determine the sum of values

#ifndef _SIMPLEACCU_H_
#include <SimpleAccu.hxx>
#endif

#ifndef _INTEGRAL0ACCU_H_
#include <Integral0Accu.hxx>
#endif

#ifndef _SUMACCU_H_
#include <SumAccu.hxx>
#endif

#ifndef _VARIABLE_H_
#include <Variable.hxx>
#endif

#ifndef _FLOATVAR_H_
#include <FloatVar.hxx>
#endif

#ifndef _TIMEVAR_H_
#include <TimeVar.hxx>
#endif

/** 
@class Average0Accu

@brief
    a zero order value accumulator class. this class is used to determine a 
    mean value of variables over time. no value transition approximation is
    applied, i.e. values change in a stepwise mode.
    @classification ETM internal
*/
class DLLEXP_OABASICS Average0Accu: public SimpleAccu
{
  friend class UNIT_TEST_FRIEND_CLASS;
  public: 
    /** constructor
    @param aVarType Variable type for accu
    */
    Average0Accu(const VariableType aVarType);
    
    /**increases the accumulator by theValue
    @param theValue Value to increase
    @param atTime    time of the value
    */
    virtual void accumulate(const Variable &theValue, const TimeVar &atTime );

    /**increases the accumulator by theValue
    @param theValue Value is handled as invalid
    @param atTime    time of the value
    */
    virtual void accumulateInvalid( const Variable &theValue, const TimeVar &atTime );

    /**computes the result
    @return result
    */
    virtual const Variable &getResult();

    // WOKL 2.2.01 TI 7411
    /** computes intermediate value temporary
    @param theValue the value
    @param start start time
    @param stop stop time
    @param valid Validity flag
    @return result
    */
    virtual const Variable &getIntermResult( const Variable &theValue, const TimeVar &myStart, const TimeVar &myStop, bool valid );

    /** resets accumulator
    */
    virtual void reset();
    
  protected:
  
  private:
    /** copy constructor
    */
    Average0Accu(const Average0Accu &);
    /** = operator
    */
    Average0Accu &operator=(const Average0Accu &);
  
    Integral0Accu myIntegral0Accu;
    SumAccu myTimeSumAccu;
    FloatVar theAverage;
    TimeVar start;
    TimeVar end;
    FloatVar intermResult_;
};

#endif
