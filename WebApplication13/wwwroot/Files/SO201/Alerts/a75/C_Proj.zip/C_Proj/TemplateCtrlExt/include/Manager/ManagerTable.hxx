#ifndef _MANTABLE_H_
#define _MANTABLE_H_

#include <Bit32Var.hxx>
#include <DpIdentList.hxx>
#include <DynPtrArray.hxx>
#include <ManagerIdentifier.hxx>
#include <WaitForAnswer.hxx>

// forward declarations
class DpIdValueList;
class DynVar;
class NameServerSysMsg;

/**
  Managerpermissions are held in a datapoint, where the key
  to a permission is the combination of ManagerId and ManagerType
  ManagerTable holds a copy of the information to provide FAST access
*/
// pointers to this struct will be saved for fast access

class DLLEXP_MANAGER ManagerPermission
{
  /// <summary>
  /// Declare test class as a friended class, having access to private/protected methods
  /// </summary>    
  friend class UNIT_TEST_FRIEND_CLASS;
  friend class ManagerTable;

  ManagerPermission(const ManagerIdentifier & id)
    : manType(id.getManType()), manNum(id.getManNum())
  { /* empty */ }

  ManagerPermission(PVSSuchar t = NO_MAN, PVSSuchar id = 0, const Bit32Var * val = 0)
    : manType(t), manNum(id)
  {
    if ( val )
      manPerm = *val;
  }

  ManagerPermission(const ManagerIdentifier & id, const Bit32Var & val)
    : manType(id.getManType()), manNum(id.getManNum()), manPerm(val)
  { /* empty */ }

  const ManagerPermission & operator=(const ManagerIdentifier & mId)
  {
    manType = mId.getManType();
    manNum = mId.getManNum();
    manPerm = 0;

    return *this;
  }

  PVSSuchar manType; // store manType and manNum
  PVSSuchar manNum;  // I do not use ManagerIdentifier here,
                     // becaus it may grow and all i need is manType
                     // and manNum
  Bit32Var manPerm;  // the permissions
};

#if defined(LIBS_AS_DLL)
  template class DLLEXP_MANAGER DynPtrArray<ManagerPermission>;
#endif

/** The manager table class. this class is part of the PVSS-II user access system.
 *
 * Permissions can be granted on a per user per manager basis.
 * A local copy of this table must be requested by a manager which wants to use the
 * access system. @see Manager
 * @classification ETM internal
 **/
class DLLEXP_MANAGER ManagerTable
{
  /// <summary>
  /// Declare test class as a friended class, having access to private/protected methods
  /// </summary>    
  friend class UNIT_TEST_FRIEND_CLASS;

  public:
    ManagerTable();

    ~ManagerTable()
    {
      if ( wait )
        wait->table = 0;
    }

    /** Wait for all data to arrive **/
    void waitForData();

    /** Update the internal copy of the manager table
     *
     * @param values the new values of the manager table dp
     * @return 1 if values were copied
     **/
    int dpValueChanged(const DpIdValueList & values);

    /** Get manager permissions for a specific manager ID.
     *
     * @param manType the manager type
     * @param manId the manager ID
     * @returns the permissions for the specified manager ID or
     *          0 if the manager ID doesn't exist
     **/
    const Bit32Var * getManPermission(PVSSuchar manType, PVSSuchar manId);

    /** Get manager permissions for a specific manager ID.
     *
     * @param id the manager ID
     * @returns the permissions for the specified manager ID or
     *          0 if the manager ID doesn't exist
     **/
    const Bit32Var * getManPermission(const ManagerIdentifier & id);

    /** Get manager permissions for a specific manager ID.
     *
     * @param manType the manager type
     * @param manId the manager ID
     * @returns the permissions for the specified manager ID or
     *          ~0 if the manager ID doesn't exist
     **/
    PVSSulong getManPermissionLong(PVSSuchar manType, PVSSuchar manId);

    /** Get manager permissions for a specific manager ID.
     *
     * @param id the manager ID
     * @returns the permissions for the specified manager ID or
     *          ~0 if the manager ID doesn't exist
     **/
    PVSSulong getManPermissionLong(const ManagerIdentifier & id);

    /** Reconnect to the manager table datapoint **/
    void reConnect();

    /** Handle NameServerSysMsg **/
    PVSSboolean handleNameServerSysMsg(const NameServerSysMsg &msg);

  private:
    // no copying
    ManagerTable(const ManagerTable &);
    const ManagerTable &operator=(const ManagerTable &);

    // update internal table
    void updateManPerms(const DynVar * varManType, const DynVar * varManNum, const DynVar * varManPerm);

    // used for sorting internal table
    static int compareItems(const ManagerPermission * m1, const ManagerPermission * m2);

    // called by WaitForAnswer object
    void dpConnectCallback(DpMsgAnswer & msg);

    class DLLEXP_MANAGER WaitFor : public WaitForAnswer
    {
      friend class ManagerTable;

      public:
        WaitFor(ManagerTable * mt) : table(mt) { /* empty */ }

        ~WaitFor()
        {
          if ( table )
            table->wait = 0;
        }

        virtual void callBack(DpMsgAnswer & answer)
        {
          table->dpConnectCallback(answer);
        }

      private:
        ManagerTable * table;
    };

    friend class WaitFor;
    WaitFor * wait;
    bool receivedAnswer;
    
    // store the permissions for all known managers
    DynPtrArray<ManagerPermission> permValues;

    // cache last accessed manager and permissions
    PVSSuchar  cacheManType;
    PVSSuchar  cacheManNum;
    Bit32Var * cacheVal;

    // store the DpIdentifiers so we know if HotLinks concern us
    DpIdentList identList;

    static const size_t MAX_MAN_DPIDS = 3;
    struct NameIdMap
    {
      CharString   dpName;
      DpIdentifier dpId;
    } internalIds[MAX_MAN_DPIDS];

    size_t pendingNameServerSysMsgs;
};

inline PVSSulong ManagerTable::getManPermissionLong(const ManagerIdentifier & mId)
{
  const Bit32Var * temp = getManPermission(mId);
  return temp ? (PVSSulong) temp->getValue() : PVSSulong(0xFFFFFFFF);
}

inline PVSSulong ManagerTable::getManPermissionLong(PVSSuchar manType, PVSSuchar manNum)
{
  return getManPermissionLong(ManagerIdentifier(manType, manNum));
}

inline const Bit32Var * ManagerTable::getManPermission(PVSSuchar manType, PVSSuchar manNum)
{
  return getManPermission(ManagerIdentifier(manType, manNum));
}

#endif /* _MANTABLE_H_ */

