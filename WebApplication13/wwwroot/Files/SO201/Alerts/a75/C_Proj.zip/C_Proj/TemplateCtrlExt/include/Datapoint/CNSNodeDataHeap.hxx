#ifndef _CNSNODEDATAHEAP_H_
#define _CNSNODEDATAHEAP_H_

#include <CNSNode.hxx>
#include <CNSNamesHeap.hxx>

#include <utility> // for std::pair

// forward declaration
class SystemNumType;
class CNSTreeVisitor;
class CNSTreeNode;
class CNSNodeNames;
class CNSDataIdentifier;


/**
 * A container to store node names and indices for fast CNS searches.
 * @internal
 */
class DLLEXP_DATAPOINT CNSNodeDataHeap
{
  public:
    /**
     * Type of the items used in the indices. The first member refers to
     * a name or display name of a CNS node, the second member refers to
     * the node itself.
     */
    typedef std::pair<const char *, const CNSTreeNode *> StringNodePair;

    ///
    CNSNodeDataHeap(int _bufferSize = CNS_NAMES_HEAP_SIZE);

    ///
    ~CNSNodeDataHeap();

  public:
    /** add the names of a CNSTreeNode to the heap.
      * @param node the CNStreeNode which should be referenced for fast search.
      * @param names the names of the CNSTreeNode that will be stored in the heap.
      * @return the index for direct acces if the names or null in case of an error.
      */
    StringNodePair *add(CNSTreeNode &node, const CNSNodeNames &names);

    /// remove the names of CNSTreeNode referenced by item from the heap.
    bool remove(StringNodePair *item);

    /// @return the names of the CNSTreeNode referenced by item.
    CNSNodeNames getNames(const StringNodePair *item) const;

    /// @return name of the CNSTreeNode referenced by item.
    const char *getNamePtr(const StringNodePair *item) const;

    /// @return the display name of the given language of the CNSTreeNode referenced by pos.
    const char *getDisplayNamePtr(const StringNodePair *item, LanguageIdType lang) const;

    /** Set new names for an existing CNSTreeNode.
      * @param item reference to the CNSTreeNode. This pointer will be invalid after the call.
      * @param node CNSTreeNode that should get new names.
      * @param names the new names.
      * @return the index that references to node, or null in case of an error.
      */
    StringNodePair *setNames(StringNodePair *item, CNSTreeNode &node, const CNSNodeNames &names);

    /**
     * Invokes the given visitor for nodes that roughly matches the pattern and
     * the specified system(s) and view(s). the visitor checks if the node
     * really meets all search criteria only if this is the case the node is added
     * to the visitors result list.
     *
     * @param pattern The search pattern.
     * @param sys The number of the system(s) which will be searched.
     *            Use ALL_SYSTEMS to search all systems.
     * @param viewId The viewId of the view that will be searched in the
     *               specified system(s).
     *               Use ALL_VIEWS to search all views.
     * @param visitor A visitor functor which is called for nodes that might match.
     *
     * @return false if no optimised search was possible.
     */
    bool find(const char *pattern,
              const SystemNumType &sys,
              const ViewId &viewId,
              bool caseSensitive,
              CNSTreeVisitor &visitor) const;

    /**
     * Invokes the given visitor for nodes that roughly matches the given id and
     * the specified system(s) and view(s). the visitor checks if the node
     * really meets all search criteria only if this is the case the node is added
     * to the visitors result list.
     *
     * @param id The CNSDataIdentifier.
     * @param sys The number of the system(s) which will be searched.
     *            Use ALL_SYSTEMS to search all systems.
     * @param viewId The viewId of the view that will be searched in the
     *               specified system(s).
     *               Use ALL_VIEWS to search all views.
     * @param visitor A visitor functor which is called for nodes that might match.
     *
     * @return false if no optimised search was possible.
     */
    bool find(const CNSDataIdentifier &id,
              const SystemNumType &sys,
              const ViewId &viewId,
              CNSTreeVisitor &visitor) const;

    /// has to be called before a CNSDataIdentifier is changed
    void preUpdateDp(StringNodePair *item);

    /// has to be called after a CNSDataIdentifier was changed
    void postUpdateDp(StringNodePair *item);

    /** empty the heap.
      * removing nodes is not very efficient.
      * Manager::cleanup() should use this method,
      * if the whole heap will not be needed anymore.
      */
    void cleanup();

    /// size of the heap.
    size_t size();

    /// size of the strings held by the heap.
    size_t textSize();

    /// size of the structures for optimized search.
    size_t structureSize();

  private:
    /// get the pattern for the optimized search in the string heap.
    static CharString strHeapPattern(const char *pattern);

    /// adds a string to the string heap and to the string index.
    bool addString(const char *name, const CNSTreeNode &node, StringNodePair &addItem);

    /** Adds the item to the index over the datapoints of all nodes.
      * Note that the datapoint index has a two-layered structure for performance reasons.
      * The indices are grouped in rows. If the number of items in a rows exceeds
      * a certain threshold, the row is split.
      * @param addItem item to add
      */
    void addToDataPointIndex(StringNodePair *addItem);
};

// --------------------------------------------------------------------------------
// --
// --------------------------------------------------------------------------------
inline CNSNodeDataHeap::~CNSNodeDataHeap()
{
  cleanup();
}

//------------------------------------------------------------------------------
//--
//------------------------------------------------------------------------------
inline const char *CNSNodeDataHeap::getNamePtr(const StringNodePair *item) const
{
  return( item[0].first );
}

#endif // _CNSNODEDATAHEAP_H_
