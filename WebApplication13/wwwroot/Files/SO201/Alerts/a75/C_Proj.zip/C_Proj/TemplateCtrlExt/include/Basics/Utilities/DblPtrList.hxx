// DATEIBESCHREIBUNG ==============================================================
// DATEINAME:     DblPtrList.hxx
// VERANTWORTUNG:	Thomas Koroschetz
// BESCHREIBUNG:	Die Klasse DblPtrList dient als Schnittstelle zu den von 
// 		DblPtrList abgeleiteten Klassen = Objekte in doppelt 
// 		verketteter Liste.
// 		
// 		Die doppelt verkettete Liste wird hierbei als Ringstruktur
// 		realisiert.
//
// ======================================Ende======================================
#ifndef _DBLPTRLIST_H_
#define _DBLPTRLIST_H_

// Vorwaerts-Deklaration der Eigenen Klasse
class DblPtrList;

// System-Include-Files
#ifndef _TYPES_HXX_
#include <Types.hxx>
#endif

#ifndef _DBLPTRLISTITEM_H_
#include <DblPtrListItem.hxx>
#endif

/** a double pointer list. this list stores DblPtrListItem objects.
    the list is organized in a ring structure, although the getPrev(void) and getNext(void)
    members will stop at the (internal) beginning / end of the list.
*/
class DLLEXP_BASICS DblPtrList 
{
public:
  // Liefert das vorherige Element nach einem Aufruf von getLast() - getPrev()
  // Loop nur vom 1. bis zum letzten Element, d.h. nicht im Kreis!
  // getPrev(ptr) aendert in der Reihenfolge nichts

  /** get the previous element. The list knows the last accessed element and returns the previous one.
   *  Modifications via append() or insertBefore() are allowed, modifications via remove() or cut()
   *  may result in strange behaviour.
   * @return the previous element or 0 if the list's head is reached
   */
  DblPtrListItem *getPrev() const
  {
    return ((DblPtrListItem*&)lastAccessedPtr =
             ((lastAccessedPtr && (lastAccessedPtr != headPtr)) ?
               lastAccessedPtr->prevPtr : 0));
  }

  // Liefert das naechste Element nach einem Aufruf von getFirst() - getNext()
  // Loop nur vom 1. bis zum letzten Element, d.h. nicht im Kreis!
  // getNext(ptr) aendert in der Reihenfolge nichts

  /** get the next element. The list knows the last accessed element and returns the next one.
   *  Modifications via append() or insertBefore() are allowed, modifications via remove() or cut()
   *  may result in strange behaviour.
   * @return the next element or 0 if the list's tail is reached
   */
  DblPtrListItem *getNext() const
  {
    return ((DblPtrListItem *&) lastAccessedPtr =
              ((lastAccessedPtr && (lastAccessedPtr->nextPtr != headPtr)) ?
                (DblPtrListItem *) lastAccessedPtr->nextPtr : 0));
  }

  /// Get the last accessed element once again.
  DblPtrListItem*  getLastAccessed() const { return lastAccessedPtr; }

public:
  /// constructor
  DblPtrList();
  /// destructor; list is clear()ed
  virtual ~DblPtrList();

  // Dieser operator sollte sparsam verwendet werden da im unguenstigsten Fall
  // die halbe Liste durchlaufen werden muss!
  /// access operator - keep in mind that the list has to be traversed, however!
  DblPtrListItem *operator[](unsigned int index) const;

  // Spezielle Methoden :
  /// get the number of items in the list
  unsigned int getNumberOfItems() const;
  /// append a new item to the list; the item is captured by the list
  void append(DblPtrListItem *itemPtr);

  /** remove an item from the list; itemPtr must be a pointer to the item to remove
   * @param itemPtr a pointer to the item to remove from the same list
   * @return PVSS_TRUE if removal succeeded, PVSS_FALSE otherwise
   */
  PVSSboolean remove(DblPtrListItem *itemPtr);

  // Fuegt Element itemPtr2ins VOR element itemPtr ein!
  /** insert itemPtr2ins before itemPtr; the item is captured by the list
   * @param itemPtr a pointer to an item in this list
   * @param itemPtr2ins a pointer to an item that is not in a list
   * @return PVSS_TRUE if insertion succeeded, PVSS_FALSE otherwise
   */
  PVSSboolean insertBefore(DblPtrListItem *itemPtr, DblPtrListItem *itemPtr2ins);
  /// get the first item
  DblPtrListItem *getFirst() const;
  /// get the last item
  DblPtrListItem *getLast() const;

  /// get the item before itemPtr
  DblPtrListItem *getPrev(DblPtrListItem *itemPtr) const;
  /// get the item before itemPtr
  DblPtrListItem *getPrev(const DblPtrListItem *itemPtr) const;
  /// get the item after itemPtr
  DblPtrListItem *getNext(DblPtrListItem *itemPtr) const;
  /// get the item after itemPtr
  DblPtrListItem *getNext(const DblPtrListItem *itemPtr) const;

  /// cut out the first item; you are responsible for deleting it!
  DblPtrListItem *cutFirst();
  /// cut out the last item; you are responsible for deleting it!
  DblPtrListItem *cutLast();
  /** cut out the given item; you are responsible for deleting it!
   * @param itemPtr a pointer to the item to cut form the list
   * @return @e itemPtr if cutting succeeded, 0 otherwise
   */
  DblPtrListItem *cut(DblPtrListItem *itemPtr);
  /// clear the list; all captured items are deleted
  void clear();

private:
  unsigned int numberOfItems;
  DblPtrListItem *headPtr;

  /// used by getNext() and getPrev() to traverse the list
  DblPtrListItem *lastAccessedPtr;

  // damit sie niemand verwenden kann
  inline DblPtrList(const DblPtrList &) {}; //COVINFO LINE: defensive (AP: disallow copy ctor)
  inline DblPtrList &operator=(const DblPtrList &) {return *this;};  //COVINFO LINE: defensive (AP: disallow =operator)

};

// ================================================================================
// Inline-Funktionen :
inline unsigned int DblPtrList::getNumberOfItems() const
{
	return numberOfItems;
}

inline DblPtrListItem *DblPtrList::getFirst() const
{
	return ((DblPtrListItem*&)lastAccessedPtr = headPtr);
}

inline DblPtrListItem *DblPtrList::getLast() const
{
	return ((DblPtrListItem *&) lastAccessedPtr = headPtr ? headPtr->prevPtr : 0);
}

inline DblPtrListItem *DblPtrList::getPrev(DblPtrListItem *itemPtr) const
{
	return (DblPtrListItem *) (itemPtr ? itemPtr->prevPtr : 0);
}

inline DblPtrListItem *DblPtrList::getNext(DblPtrListItem *itemPtr) const
{
	return (DblPtrListItem *) (itemPtr ? itemPtr->nextPtr : 0);
}

inline DblPtrListItem *DblPtrList::getPrev(const DblPtrListItem *itemPtr) const
{
	return (DblPtrListItem *) (itemPtr ? itemPtr->prevPtr : 0);
}

inline DblPtrListItem *DblPtrList::getNext(const DblPtrListItem *itemPtr) const
{
	return (DblPtrListItem *) (itemPtr ? itemPtr->nextPtr : 0);
}


#endif /* _DBLPTRLIST_H_ */
