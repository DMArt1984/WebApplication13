// DATEIBESCHREIBUNG ==============================================================
// DATEINAME:  HWObject.hxx
//        Abstrakte Basis-Klasse fuer HW-Adresse und HW-Daten.

#ifndef _HWOBJECT_H_
#define _HWOBJECT_H_

#ifndef _DPTYPES_H_
#include <DpTypes.hxx>
#endif

#ifndef _CONFIGTYPES_H_
#include <ConfigTypes.hxx>
#endif

#ifndef _TIMEVAR_H_
#include <TimeVar.hxx>
#endif

#ifndef _BITVEC_H_
#include <BitVec.hxx>
#endif

#ifndef _RECVAR_H_
#include <RecVar.hxx>
#endif

#ifndef _CHARSTRING_H_
#include <CharString.hxx>
#endif

#ifndef _QUALITYCODE_H_
#include <QualityCode.hxx>
#endif

#include <stdio.h>

/** The internal flag is used to signal the origin of a HWObject. The state is used inside the
  * ComDrv for vaious purposes. Default value is 0 (srcSpont) and should not be set by a derived
  * driver or HWObject.
  */
enum ObjectSourceType
  {
    /** (0). HWObject generated due to incoming / outgoing data */
    srcSpont,
    /** (1). HWObject generated due to polling request */
    srcPolled,
    /** (2). HWObject generated due to a single request */
    srcSingleQ,
    /** (3). HWObject generated due to a general request */
    srcGeneralQ,
    /** (4). HWObject generated due to a direct write request */
    srcDirectWrite,
    /** (5). HWObject generated due to a direct update request */
    srcDirectQ,
  };

/** The HWObject contains the data buffer and all information needed by the ComDrv to process
  * the data. This is a base class which is intended to be derived for own drivers.
  * The derived class should also contain any information needed for addressing 
  * the data to the hardware.
  * @classification public use, overload
  */
class HWObject
{
 public:
   /** Default constructor
     */
   HWObject();

   /** Constructor, which sets the periphAddr and transformationType.
     * The connectionId will be set to 0 by default
     * @param addressString address of the HW object
     * @param trans type of transformation 
   */
   HWObject(const char* addressString, TransformationType trans);

   /** Constructor, which sets the periphAddr and transformationType.
     * @param addressString address of the HW object
     * @param connectionId the connection id
     * @param trans type of transformation 
   */
   HWObject(DpIdType connectionId, const char* addressString, TransformationType trans);

   /**  Destructor. If the data pointer is not NULL, it is deleted.
     *  Call overloaded deleteData method if special deletion must be done.
     */ 
   virtual ~HWObject();
   
   /** Creates a new HWObject
     * This function returns an empty HWObject, no properties are duplicated or copied!
     * @classification public use, overload, call base
     */
   virtual  HWObject * clone() const;
   
   /** Reset all platform relevant parts of the HWObject. when overloading this member
     * don't forget to call the basic function!
     * @classification public use, overload, call base
     */
   virtual void               clear();
   
   /** Gets pointer to data
     * @return pointer to data
     */
   const PVSSchar *   getDataPtr() const                          { return dataPtr; }

   /** Gets the data buffer pointer
     * @return data buffer pointer
   */
   PVSSchar *         getData()                                   { return dataPtr; }
   
    /** Cut the data buffer out of the HWObject.
     * This function is used to avoid the deletion
     * of the data buffer, when a new pointer is set using
     * setData() or the HWObject is deleted.
     * @return pointer to the data of the HWObject
     */
   PVSSchar *         cutData();

   /** Get the data buffer lenght
     * @return length of the data buffer
   */
   PVSSushort           getDlen() const                             { return dataLen; }

   /** Set ptr to the data buffer, pointer is captured.
     * The actual data pointer in the HWObject is deleted,
     * if it is not NULL. To avoid the deletion use cutData()
     * in order to cut out the pointer.
     * @param ptr pointer to new data
     */
   void               setData(PVSSchar *ptr);
   
   /** Set the data length
     * @param len length to be set
   */
   inline void        setDlen(const PVSSushort len)                 { dataLen = len; }

   /** Get the periph address
     * @return periph address string
   */
   const CharString & getAddress() const                          { return address; }

   /** Get the connection id
     * @return connection id
   */
   inline DpIdType    getConnectionId() const                          { return connectionId; }

   /** Set the connection id
     * @param connId connection id to be set
   */ 
   void               setConnectionId(DpIdType connId)             { connectionId = connId; }

   /** Get the transformation type
     * @return type of transformation
   */
   TransformationType getType() const                             { return transType; }
   
   /** Set the transformation type
     * @param typ type of transformation for setting
   */
   void               setType(const TransformationType typ)       { transType = typ; }
   
   /** Get the subindex
     * @return subindex
   */
   PVSSushort           getSubindex() const                         { return subindex; }
   
   /** Set the subindex
     * @param sx subindex to be set
   */ 
   void               setSubindex( const PVSSushort sx)             { subindex = sx; }
   
   /** Get the origin time
     * @return origin time
   */
   const TimeVar&     getOrgTime() const                          { return originTime; }

   /** Get the origin time
     * @return oriin time
   */
   TimeVar&           getOrgTime()                                { return originTime; }
  
   /** Set the origin time
     * @param tm origin time to be set
   */
   void               setOrgTime(const TimeVar& tm)               { originTime = tm; }

   /** Get HWObject purpose
     * @return objSrcType
   */
   ObjectSourceType   getObjSrcType() const                       { return objSrcType; }

   /** Set HWObject purpose
     * @param tp objSrcType
   */
   void               setObjSrcType(const ObjectSourceType tp)    { objSrcType = tp; }

   /** Get number of elements in data buffer
     * @return number of elements in data buffer
   */
   PVSSushort           getNumberOfElements() const                 { return number_of_elements; }

   /** Set number of elements in data buffer
     * @param var number of elements in data buffer
   */
   void               setNumberOfElements(const PVSSushort var)     { number_of_elements = var; }

   /** Prints the basic HWObject information on stderr.
     * in case of overloading don't forget to call the base function!
     * @classification public use, overload, call base
     */
   virtual void      debugPrint(std::ostream &os) const;

   /** Prints the basic HWObject information on stderr.
     * in case of overloading don't forget to call the base function!
     * this is used for linux for beeing compatible
     * @classification public use, overload, call base
     */
   virtual void      debugPrint() const;

   /** Prints the basic HWObject info in one CharString for internal debug DP.
   * in case of overloading call base function first, then append specific info 
     *  @classification public use, overload, call base 
   */
   virtual CharString getInfo() const;

   /** Set the periph address
     * @param adrStr pointer to address string
   */
   virtual void       setAddress(const char *adrStr);

   /** Set the additional data (flag, orig time, valid user byte,etc)
     * @param data aditional flags that be set
   * @param subix subindex, use subix 0 for setting values by default  
     */ 
   virtual void       setAdditionalData(const RecVar &data, PVSSushort subix);

   /** Set the 'origin time comes from periph' flag 
     */
   void               setTimeOfPeriphFlag() 
   {
     setSbit(DRV_TIME_OF_PERIPH);
   }

   /** Check whether time comes from periph
     * @return PVSS_TRUE if the time is from perip
     */
   PVSSboolean        isTimeFromPeriph() const   
   {
     // If isTimeOfPeriph is set, it must be valid
     return getSbit(DRV_TIME_OF_PERIPH);
   }

   /** Set the flag if you want to receive callback if event has answered the value change   
     */
   void setWantAnswerFlag() 
   {
     setSbit(DRV_WANT_ANSWER);
   }

   /** Get the status of the 'want answer, flag
     */
   PVSSboolean        getWantAnswerFlag() const   
   {
     // If isTimeOfPeriph is set, it must be valid
     return getSbit(DRV_WANT_ANSWER);
   }

   /** Check if this HWObject has a PA quality code set
     */
   PVSSboolean       hasQualityCode() const
   {
     return getSbit(DRV_HAS_QUALITY_CODE);
   }

   /** Get the HWObject PA quality code.
     * This code is only valid if the hasQualityCode() function returns PVSS_TRUE
     */
   QualityCode getPAQuality() const;
   
  /** set the PA quality code to be sent to the process image.
      @param qc the code received from the periphery. only the 8 bit PA compatible quality code is stored.
      @return PVSS_TRUE if the code has been accepted, PVSS_FALSE otherwise
  */
  PVSSboolean  setPAQuality(QualityCode qc);

  /** Set the user bit given by input parameter.
    * Status bits defined by the enum DriverBits
    * @param bitno bit number
    * @return PVSS_TRUE if bit was set
    */ 
   PVSSboolean        setSbit(PVSSushort bitno)       
   {
     return (status.set(bitno) && status.set(bitno + (PVSSushort)DRV_VALID_INVALID - (PVSSushort)DRV_INVALID));
   }
   
   /** Clear the user bit given by input parameter
      * @param bitno bit number
   * @return PVSS_TRUE if bit was cleared
   */ 
   PVSSboolean        clearSbit(PVSSushort bitno)     
   {
     return (status.clear(bitno) && status.set(bitno + (PVSSushort)DRV_VALID_INVALID - (PVSSushort)DRV_INVALID));
   }
   
   /** Check valid flag for user bit
      * @param bitno bit number
   * @return result (is valid or not)
   */
   PVSSboolean        isValidSbit(PVSSushort bitno) const   
   {
     return status.get(bitno + (PVSSushort)DRV_VALID_INVALID - (PVSSushort)DRV_INVALID);
   }
   
   /** Check any bit
      * @param bitno bit number
   * @return status of the bit on bitno position
   */
   PVSSboolean        getSbit(PVSSushort bitno) const      {return status.get(bitno);}

   /** Clear all status bits
     * return status of clear all
   */
   PVSSboolean        clearStatus() {return status.clearAll();}
   
   /** Get the status of this object
     * @return bit vector status
     */
   const BitVec &     getStatus() const {return status;}
   
   /** Set status of the bit vector
     * @param bv deference to bit vector to be set as status 
     */
    void               setStatus(const BitVec &bv) {status = bv;}

   /** Set a user byte in the status.
     * @param userByteNo number of user byte range 0..3
     * @param val        value to set
     * @return PVSS_TRUE execution OK
     *         PVSS_FALSE in case of error
     */
   PVSSboolean setUserByte (PVSSushort userByteNo, PVSSuchar val);

   /** Reads a user byte from the status.
     * @param userByteNo number of user byte range 0..3
     * @return the requested user byte
     */
    PVSSuchar getUserByte (PVSSushort userByteNo) const;

   /** Check validity of user byte.
     * @param userByteNo number of user byte range 0..3
     * @return PVSS_TRUE user byte is valid
     *         PVSS_FALSE user byte is not valid
     */
   PVSSboolean isValidUserByte(PVSSushort userByteNo) const;

   /** Format status bits into a string
   * @param str status bits converted to string 
   */
    void formatStatus (CharString & str) const ;
  // ------------------------------------------------------------------
  // internal ones

   /** Set data length
     * @param dlen  data length 
   */
    void setDlenLlc (PVSSushort dlen) {dataLenLlc = dlen;}

    // functions for low level comparision
    /** Update buffer for low level comparision in this HW object from
      * the HW object given as parameter.
      * The offset1 parameter will be usually 0 if toDp is called with an HWObject
      * starting with subindex 0.
      * This function can be overloaded, if more than a simple memcpy is required
      * for storage of the buffer for LLC.
      * @param hwo HW object containing the buffer to copy
      * @param offset1 offset in the destination buffer
      */
    virtual void updateBufferLlc (HWObject * hwo, int offset1 = 0);

    /** Function for comparision of the my data buffer with the buffer of the HW
      * object given in the parameter. 
      * The offset1 and offset2 parameter will be usually 0 if toDp is called with an HWObject
      * starting with subindex 0 and the number of elements in the HW Object is 1.
      * This function can be overloaded to if a special comparision for LLC is desired.
      * @param hwo HW object containing the buffer to compare withpy
      * @param offset1 offset in my buffer
      * @param offset2 offset in hwo's buffer
      * @param len number of bytes to compare
      * @return 0 if the buffer is eval
      *          != 0 if the buffer is not eval
      */
    virtual int compareLlc (HWObject * hwo, int offset1 = 0, int offset2 = 0, int len = -1);

    /** Get dataLenLlc
    * @return dataLenLlc
    */
    PVSSushort getDlenLlc () const {return dataLenLlc;}

    /** Function to delete the data buffer; overload AND call in destructor
      * if special deletion must be done.
      */
    virtual void deleteData ();

    /** Set HW identifier
    * @param id hw identifier to be set
    */
    void setHwoId(PVSSulong id) {hwoId = id;}

  /** Get HW identifier
    * @return hw identifier
    */
  PVSSulong getHwoId() const {return hwoId;}

  // we reuse the hwoId field here, otherwise hwoId is used in input dir only
  /** Set answer ID (_redirect_io and directWrite only)
    * @param answer message id - given by original message
    */
  void setAnswerID(PVSSulong id) {hwoId = id;}

  /** Get answer ID
    * @return answer id
    */
  PVSSulong getAnswerId() const {return hwoId;}

  /// get TracingSingle bit for tracing a single datapoint
  /// @return true if tracing of specific datapoints should be done
  bool shouldTraceSingle() const;

  /// set TracingSingle bit for tracing a single datapoint
  /// @param enableTraceSingle is true if tracing of specific datapoints should be done
  void setTraceSingle(bool traceSingle = true);

 protected:
   /// the dynamic data buffer
   PVSSchar*          dataPtr;
   /// the data buffer len
   PVSSushort         dataLen;
   /// the start subix for the data buffer
   PVSSushort         subindex;
   /// the pvss2 periph address string
   CharString         address;
   /// the datatype of the data in the buffer (i.e. transformationtype)
   TransformationType transType;
   /// the time of income, normally set by the constructor
   TimeVar            originTime;
   /// the purpose of this HWObject
   ObjectSourceType   objSrcType;
   /// the user bits of the original config
   BitVec             status;
   /// the connection id
   DpIdType           connectionId;
   /// the number of elements in the data buffer, used for arrays and records
   PVSSushort         number_of_elements;        // fuer array!!!

   // PAQuality is part of the flags!

  private:
    PVSSushort dataLenLlc;
    PVSSulong hwoId;
    bool traceSingle; // should object be traced
};


#endif
