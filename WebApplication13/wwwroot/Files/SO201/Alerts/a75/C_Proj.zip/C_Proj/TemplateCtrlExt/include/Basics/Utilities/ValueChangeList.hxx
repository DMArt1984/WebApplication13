#ifndef _VALUECHANGELIST_H_
#define _VALUECHANGELIST_H_

// System-Include-Files
#ifndef _DPIDENTIFIER_H_
#include <DpIdentifier.hxx>
#endif

#ifndef _PTRLIST_H_
#include <PtrList.hxx>
#endif

#ifndef _MANAGERIDENTIFIER_H_
#include <ManagerIdentifier.hxx>
#endif

#ifndef _TIMEVAR_H_
#include <TimeVar.hxx>
#endif

#ifndef _DPVCITEM_H_
#include <DpVCItem.hxx>
#endif

// Vorwaerts-Deklarationen :
class ValueChangeList;
class Variable;

typedef ValueChangeList* ValueChangeListPtr;

/**
 * This class contains the attributes and new values if a value change is
 * performed.
 *
 * Each attribute can only be contained once, this is checked on insert.
 *
 * @remarks Do not use the allValueConfigs flag. It is only intended
 * for use in the event manager.
 *
 * @internal
 */
class DLLEXP_BASICS ValueChangeList : public PtrList
{
  /// Output to std::ostream
  friend DLLEXP_BASICS std::ostream & operator<<(std::ostream &os, const ValueChangeList &vcList);

public:
  /**
   * Creates a new list with the specified time, manager identifier
   * and user id set and the specified DpIdentifier and associated value
   * inserted.
   *
   * @param time The original time of the value change
   * @param man The original manager of the value change
   * @param user The original user id of the value change
   * @param dpIdentifier The identifier whose value has changed
   * @param value The new value of the identifier
   */
  ValueChangeList(const TimeVar &time, const ManagerIdentifier &man,
	PVSSuserIdType user, const DpIdentifier &dpIdentifier, const Variable &value);

  /**
   * Creates an empty list with the specified time, manager identifier
   * and user id set.
   *
   * @param time The original time of the value change
   * @param man The original manager of the value change
   * @param user The original user id of the value change
   */
  ValueChangeList(const TimeVar &time, const ManagerIdentifier &man,
	PVSSuserIdType user);

  /**
   * Creates an empty list.
   */
  ValueChangeList();

  /**
   * Copy constructor
   */
  ValueChangeList(const ValueChangeList &rVal){(*this)=rVal;}

  /// Destructor
  ~ValueChangeList();

  /**
   * Assignment operator
   */
  ValueChangeList &operator=(const ValueChangeList &rVal);

  /**
   * Inserts the specified pair of identifier and new value.
   *
   * Checks whether the identifier already exists before inserting.
   *
   * @param dpIdentifier The identifier whose value has changed.
   * @param value The associated new value.
   *
   * @return False if the identifier already exists, otherwise true.
   */
  PVSSboolean insertValueChange(const DpIdentifier &dpIdentifier, const Variable &value);

  /**
   * Inserts the specified pair of identifier and new value.
   *
   * Checks whether the identifier is already contained before inserting.
   * If no valuePtr is specified, a nullpointer will be used as associated value.
   *
   * @param dpIdentifier The identifier whose value has changed.
   * @param valuePtr The associated new value.
   *
   * @return False if the identifier already exists, otherwise true.
   */
  PVSSboolean insertValueChange(const DpIdentifier &dpIdentifier, VariablePtr valuePtr = 0);
  
  /**
   * More performant insert method, does not check whether the identifier is
   * already contained.
   *
   * Only use if you are sure that the identifier is not already contained!!!
   *
   * @param dpIdentifier The identifier whose value has changed.
   * @param valuePtr The associated new value.
   */
  void insVCWithoutCheck(const DpIdentifier &dpIdentifier, VariablePtr valuePtr = 0)
      { append(new DpVCItem(dpIdentifier,valuePtr)); }

  /**
   * Sets the value for an already contained identifier which does not have an
   * associated value.
   *
   * This will only work if the specified identifier already exists in the list,
   * but does not have a value yet.
   *
   * @param dpIdentifier The identifier whose value will be set
   * @param value The value to set
   *
   * @return True if the value was successfully set, otherwise false.
   */
  PVSSboolean setValue(const DpIdentifier &dpIdentifier, const Variable &value);

  /**
   * Sets the value for an already contained identifier which does not have an
   * associated value.
   *
   * This will only work if the specified identifier already exists in the list,
   * but does not have a value yet.
   *
   * @param dpIdentifier The identifier whose value will be set
   * @param valuePtr The value to set
   *
   * @return True if the value was successfully set, otherwise false.
   */
  PVSSboolean setValue(const DpIdentifier &dpIdentifier, VariablePtr valuePtr);

  /**
   * Resets the internal pointer of the list and returns the first identifier.
   *
   * Can be used to start iterating through the list.
   * After calling this method, use getCurrentVariablePtr() to get the
   * associated value.
   *
   * @return A pointer to the first identifier, or a nullpointer if the list
   * is empty.
   */
  DpIdentifierPtr firstDpIdentifierPtr() const;

  /**
   * Sets the internal pointer of the list to the next identifier and returns
   * that identifier.
   *
   * Can be used to iterate through the list.
   * After calling this method, use getCurrentVariablePtr() to get the
   * associated value.
   *
   * If allValueConfigs is set and the list contains a DPVALUE config,
   * this method will also iterate over virtual ONLINEVALUE and OFFLINEVALUE
   * configs which delegate to the DPVALUE config.
   *
   * @remarks Do not use the allValueConfigs flag. It is only intended
   * for use in the event manager.
   * 
   * @return A pointer to the next identifier in the list, or a nullpointer
   * if there are no more items.
   */
  DpIdentifierPtr nextDpIdentifierPtr() const;

  /**
   * Returns the value of the current identifier when iterating through the list.
   *
   * Call only after calling firstDpIdentifierPtr() or nextDpIdentifierPtr().
   *
   * @return A pointer to the associated value of the current identifier, or a nullpointer
   * if the current identifier does not have a value.
   */
  VariablePtr getCurrentVariablePtr() const;

  /**
   * Merges the specified list into this list.
   *
   * Only identifiers which do not exist in this list will be added.
   * The values of already existing identifiers will be left unchanged.
   *
   * Also copies originTime, originMan and originUser from the specified list
   * if they are not set.
   *
   * Removes all items from the specified list, regardless of
   * whether the item will be added to this list or not.
   */
  void mix(ValueChangeList &valueChangeList);

  /**
   * More performant mix()-method, does not check whether an identifier already
   * exists in this list.
   *
   * Only use if you are sure that the lists have no common identifiers!!!
   */
  void mixWithoutCheck(ValueChangeList &valueChangeList);

  /**
   * Returns the value change item (identifier and value) for the
   * specified identifier, or a nullpointer if the identifier
   * does not exist in this list.
   *
   * If allValueConfigs is set, calls with a DPCONFIGNR_ONLINEVALUE or
   * DPCONFIGNR_OFFLINEVALUE identifier will be delegated to the
   * DPCONFIGNR_DPVALUE identifier, if one exists.
   *
   * @remarks Do not use the allValueConfigs flag. It is only intended
   * for use in the event manager.
   */
  DpVCItem *dpIdentifierExists(const DpIdentifier &dpIdentifier);

  // Generated methods:

  /**
   * Returns the original time of the value change
   */
  const TimeVar &getOriginTime() const;

  /**
   * Returns the original time of the value change
   */
  TimeVar &getOriginTime();

  /**
   * Sets the original time of the value change
   */
  void setOriginTime(const TimeVar &newOriginTime);

  /**
   * Returns the original manager of the value change
   */
  const ManagerIdentifier &getOriginMan() const { return originMan; }

  /**
   * Sets the original manager of the value change
   */
  void setOriginMan(const ManagerIdentifier &man) { originMan = man; }

  /**
   * Returns the original user id of the value change
   */
  PVSSuserIdType getOriginUser() const { return originUser; }

  /**
   * Sets the original user id of the value change
   */
  void setOriginUser(PVSSuserIdType user) { originUser = user; }

  /**
   * Copies originTime, originMan and originUser from the specified list.
   */
  void setOriginAttr(const ValueChangeList &list);

  // allValueConfigs ist gesetzt, wenn die Original-Attr. stellvertretend
  // auch fuer die entsprechenden Online- und Offline-Attr. stehen

  /**
   * Checks whether allValueConfigs is set.
   *
   * If allValueConfigs is set and the list contains a DPVALUE config,
   * it will also act as ONLINEVALUE and OFFLINEVALUE config.
   *
   * @remarks Do not use the allValueConfigs flag. It is only intended
   * for use in the event manager.
   *
   * @return True if allValueConfigs is set, otherwise false.
   */
  PVSSboolean getAllValueConfigs() const { return allValueConfigs; }

  /**
   * Sets the allValueConfigs flag.
   *
   * If allValueConfigs is set and the list contains a DPVALUE config,
   * it will also act as ONLINEVALUE and OFFLINEVALUE config.
   *
   * @remarks Do not use the allValueConfigs flag. It is only intended
   * for use in the event manager.
   */
  void setAllValueConfigs(PVSSboolean b) { allValueConfigs = b; }

protected:
private:
  TimeVar originTime;
  ManagerIdentifier originMan;
  PVSSuserIdType originUser;
  VariablePtr lastValue;
  DpIdentifier lastId;
  PVSSboolean allValueConfigs;

};

// ================================================================================
// Inline-Funktionen :

// Destruktor
inline ValueChangeList::~ValueChangeList()
{
}

// Konstruktor
inline ValueChangeList::ValueChangeList(const TimeVar &time,
    const ManagerIdentifier &man, PVSSuserIdType user, const DpIdentifier &dpIdentifier,
    const Variable &value)
	: PtrList(),
	  originTime(time),
	  originMan(man),
	  originUser(user),
	  lastValue(0),
	  lastId(),
	  allValueConfigs(PVSS_FALSE)
{
	insertValueChange(dpIdentifier,value);
}

// Konstruktor
inline ValueChangeList::ValueChangeList(const TimeVar &time, const
ManagerIdentifier &man, PVSSuserIdType user)
	: PtrList(),
	  originTime(time),
	  originMan(man),
	  originUser(user),
	  lastValue(0),
	  lastId(),
	  allValueConfigs(PVSS_FALSE)
{
}

// Konstruktor
inline ValueChangeList::ValueChangeList()
	: PtrList(),
	  originTime(0, 0),
	  originMan(),
	  originUser(0),
	  lastValue(0),
	  lastId(),
	  allValueConfigs(PVSS_FALSE)
{
}

inline const TimeVar &ValueChangeList::getOriginTime() const
{
  return originTime;
}

inline TimeVar &ValueChangeList::getOriginTime()
{
  return originTime;
}
inline void ValueChangeList::setOriginTime(const TimeVar &newOriginTime)
{
  originTime = (TimeVar &) newOriginTime;
}

inline VariablePtr ValueChangeList::getCurrentVariablePtr() const
{
	return lastValue;
}

#endif /* _VALUECHANGELIST_H_ */
