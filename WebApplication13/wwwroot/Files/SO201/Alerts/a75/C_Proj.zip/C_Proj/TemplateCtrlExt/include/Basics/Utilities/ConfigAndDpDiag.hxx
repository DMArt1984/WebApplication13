#ifndef _CONFIGANDDPDIAD_H_
#define _CONFIGANDDPDIAD_H_

#include <CharString.hxx>
#include <DpIdentifier.hxx>
#include <DpIdValueList.hxx>
#include <ManagerIdentifier.hxx>

class ResourceDiag;

// ========== ConfigAndDpDiag ============================================================

/** This class returns a diagnostic DataPoint identifier depending on config and DP operation
    @classification internal use
  */
class DLLEXP_BASICS ConfigAndDpDiag
{
public:
  
  /** constructor
      @param getId the pointer to getId function
      @param maxNrOfConfigs the max number of config types
      @param diag the resource diagnostic
      @n NOTE: manager type id defined by Resources
    */
  ConfigAndDpDiag(PVSSboolean (*getId)(const char *, DpIdentifier&),
                  unsigned long maxNrOfConfigs, 
                  ResourceDiag &diag);

  /** destructor
    */
  ~ConfigAndDpDiag() {}

  /** add DataPoint operation
      @n Call if a DataPoint has been added.
    */
  void addDp();

  /** add DataPoint type operation
      @n Call if a DataPoint type has been added.
    */
  void addDpType();

  /** add config operation
      @n Call if a config has been added.
      @param theConfig the value of added config
    */
  void addConfig(unsigned long theConfig);

  /** remove DataPoint operation
      @n Call if a DataPoint has been removed.
    */
  void removeDp();

  /** remove DataPoint type operation
      @n Call if a DataPoint type has been removed.
    */
  void removeDpType();

  /** remove config operation
      @n Call if a config has been removed.
      @param theConfig the value of removed config
    */
  void removeConfig(unsigned long theConfig);

  /** set DP identifier for given DP name
      @param dpName the DP name
      @param dpId the DP identifier
      @return TRUE if at least one DP found else FALSE
    */
  PVSSboolean setDpId(CharString dpName, DpIdentifier dpId);

  /** get DP name for the next config type or DP
      @return the next DP name, if no more DP empty string is returned
  */
  CharString getNextDpName() const;

  /** get list of all DP identifiers, which has been changed since last call of getDirtyList()
      @param dpIdList the list of DP identifiers
      @return TRUE if at least one DP found else FALSE
    */
  bool getDirtyList(DpIdValueList &dpIdList);

  /** get config names
      @return the list of config names
  */
  const CharString *getConfigNames() { return(configNameList_); }

  /** get initializing status
  */
  bool isInitialized();

  /** config types enumerator
    */
  enum ConfigType 
  { 
    _value,
    _address,
    _alert_class,
    _alert_hdl,
    _archive,
    _auth,
    _cmd_conv,
    _default,
    _distrib,
    _dp_fct,
    _logger,
    _msg_conv,
    _pv_range,
    _smooth,
    _u_range,
    _others,
    DPs,
    DPTs,
    MAX_CONFIG_CNT
  };

  /** get config type for given config value
      @param theConfig the config value
      @return the config type enumerator value
    */
  static ConfigAndDpDiag::ConfigType getConfigMapping(unsigned long theConfig);

private:

  // Methoden 
  // --------
  bool myGetId(int dpIdx, DpIdentifier &dpid);

  // Member
  // ------
  PVSSboolean (*getId_)(const char *, DpIdentifier&);
  CharString configNameList_[MAX_CONFIG_CNT];
  unsigned long maxNrOfConfigs_;
  bool fullInitialized_;
  ResourceDiag &diag_;
  ManagerIdentifier me_;

  char         dirty_[ConfigAndDpDiag::MAX_CONFIG_CNT];
  DpIdentifier msgDpId_[ConfigAndDpDiag::MAX_CONFIG_CNT];
};

// ---------------------------------------------------------------------------
// ---------------------------------------------------------------------------
// ---------------------------------------------------------------------------
inline bool ConfigAndDpDiag::isInitialized() 
{ 
  return(fullInitialized_);
}
#endif /* _CONFIGANDDPDIAD_H_ */
