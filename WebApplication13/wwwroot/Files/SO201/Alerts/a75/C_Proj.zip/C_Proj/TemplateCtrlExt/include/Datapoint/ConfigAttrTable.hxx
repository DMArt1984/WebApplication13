// -----------------------------------------------------------------
// ConfigAttrTable.hxx
// creator: Andreas Pfluegl at 06.03.06
// purpose: for Compartible Messages starting with PVSS II 3.1,
//          skip the ConfigAttrTable of the DpIdentification of a 3.1 System
// -----------------------------------------------------------------
// history:
// 20yy-mm-dd:  <Name> N            ( B O C X )
// -----------------------------------------------------------------
#ifndef _CONFIGATTRTABLE_H_
#define _CONFIGATTRTABLE_H_

#ifndef _DPCONFIGNRTYPE_H_
#include <DpConfigNrType.hxx>
#endif

// ========== ConfigAttrTableItem ============================================================
class itcNdrUbSend;
class itcNdrUbReceive;

/// This class is only for compatibility with PVSS_3_0_1.
/// It consists of the input and output stream operators, working on
/// streams with the version PVSS_3_0_1. The output stream just outputs the value
/// of zero to the stream, while the input stream will read certain values from
/// the stream (see the implementation for further details), thus effectively
/// "skipping" them.
class DLLEXP_DATAPOINT ConfigAttrTable
{
public:

  /// Constructor
  ConfigAttrTable() {}

  /// Destructor
  ~ConfigAttrTable() {}

  /// Outputs the instance to the itcNdrUbSend stream
  /// @param ndrStream Output stream
  /// @param _tab Streamed ConfigAttrTable instance
  /// @return itcNdrUbSend stream
  friend DLLEXP_DATAPOINT itcNdrUbSend &operator<<(itcNdrUbSend &ndrStream, ConfigAttrTable &_tab);

  /// Receives the instance from the itcNdrUbReceive stream
  /// @param ndrStream Input stream
  /// @param _tab ConfigAttrTable instance receiving the value from the stream
  /// @return itcNdrUbReceive stream
  friend DLLEXP_DATAPOINT itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream, ConfigAttrTable &_tab);

  /// Reads several values from the input stream (see implementation for details)
  /// @param ndrStream Input stream
  void skipConfigAttrTableItem(itcNdrUbReceive &ndrStream);
};

#endif /* _CONFIGATTRTABLE_H_ */
