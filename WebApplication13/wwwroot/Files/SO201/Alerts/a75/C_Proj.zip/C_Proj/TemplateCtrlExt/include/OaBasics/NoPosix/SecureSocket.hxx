#ifndef _SECURE_SOCKET_H_
#define _SECURE_SOCKET_H_

#include <ServerSocket.hxx>
#include <CharString.hxx>

// #include <openssl/ssl.h>

typedef struct ssl_st SSL;
typedef struct ssl_ctx_st SSL_CTX;

class ErrClass;

/** A Socket which can be secured by using SSL/TLS.
    It uses the openSSL library, see \URL{http://www.openSSL.org}
    @classification public use
*/

class DLLEXP_OABASICS SecureSocket : public ServerSocket
{
  public:
    /// constructor
    SecureSocket();

    /** read from a TCP socket
        @param buf pointer to user buffer
        @param len length of user buffer
        @param flags recv flags (see recv manual page) normally = 0
        @param byteRecv returned bytes received
        @return PVSS_TRUE for success
                PVSS_FALSE for error
    */
    virtual PVSSboolean recv(char *buf, int len, int flags, int &byteRecv);

    /** write to a TCP socket (calls send with flags = 0)
        @param buf pointer to user buffer
        @param len length of user data
        @param flags send flags (see send manual page) normally = 0
        @param byteSend returned number of bytes send
        @return PVSS_TRUE for success
                PVSS_FALSE for error
    */
    virtual PVSSboolean send(const char *buf, int len, int flags, int &byteSend);

    /// close a socket
    virtual void close();

    /** initialize this socket as a secure server socket (SSL/TLS).
        @param certificateFile Filename which holds the server certificate pem file. It is searched
               in all config directories.
        @param privateKeyFile Filename which holds the private key pem file. It is searched
               in all config directories.
        @param cipherSuiteList Use specified cipherSuiteList (see ciphers / CIPHER STRINGS man-page). If this argument is empty or missing, cipherSuiteList from config file will be used.
        @return 0 on success, else a pointer to a newly created ErrClass describing the error.
                The object must be deleted by the caller.
    */
    ErrClass *initSecureServer(CharString certificateFile, CharString privateKeyFile, CharString cipherSuiteList = CharString());

    /** secure this socket via SSL/TLS. All following read/writes will be encrypted.
        Call this in a server after accepting an incoming connection.
        @param securedSocket This is a server socket, which has been secured with initSecureServer()
        @return 0 on success, else a pointer to a newly created ErrClass describing the error.
                The object must be deleted by the caller.
    */
    ErrClass *secureAccept(SecureSocket &securedSocket);

    /** secure this socket via SSL/TLS. All following read/writes will be encrypted.
        Call this in a client after connecting a connection.
        @return 0 on success, else a pointer to a newly created ErrClass describing the error.
                The object must be deleted by the caller.
    */
    ErrClass *secureConnect();

    /// tells if this connection is secured
    virtual PVSSboolean isSecured() const { return (ssl != 0); }

    /// Get number if pending bytes, if secured
    int  getPendingBytes();

    /// Get the current SSL error
    CharString getSSLError();

  private:
    /// initialize SSL/TLS stuff. Must be called before SSL functions shall be used
    ErrClass *SSLInit();

    /// initialize SSL/TLS connection.
    ErrClass *secureStart(SSL_CTX *ssl_ctx);

  protected:
    SSL *ssl;
    SSL_CTX *ctx;
	
    friend class UNIT_TEST_FRIEND_CLASS;
};

#endif
