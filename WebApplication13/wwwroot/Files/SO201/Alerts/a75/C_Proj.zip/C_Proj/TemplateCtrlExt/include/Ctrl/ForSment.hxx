#ifndef _FORSMENT_H_
#define _FORSMENT_H_

#include <LoopSment.hxx>
#include <CtrlExpr.hxx>
#include <CtrlSmentList.hxx>

/*  author VERANTWORTUNG: Mark Probst */
/** the for loop         */
class DLLEXP_CTRL ForSment : public LoopSment
{
  public:
    /// wird vom YACC auf gerufen
    ForSment (int line, int filenum) 
      : LoopSment(line, filenum), initExpr(0), reinitExpr(0) {}

    /// delete aller private member
    virtual ~ForSment ();

    /** Beim Parsen: Expression der Schleife die vor jedem Durchlauf getestet wird.
      * for( i = 1; i <= 10; i++)
      * @param theInitExpr   IN: wird vom destructor frei gegeben.   ( i = 1;   )
      * @param theCondition  IN: wird bei jedem Durchlauf getestet   ( i <= 10; )
      * @param theReinitExpr IN: wird bei jedem Durchlauf ausgef�hrt ( i++      )
      */
    void setExprs (
      CtrlExpr *theInitExpr,
      CtrlExpr *theCondition,
      CtrlExpr *theReinitExpr);

    /** Legt einen Block am Stack an und testet condition
      * @return wenn condition == TRUE  erstes CtrlSment der schleife
      * @return wenn expr == FALSE erstes CtrlSment nach der schleife
      */
    virtual const CtrlSment *execute (CtrlThread *thread) const;

    // Liefert eine Sequenz von Initialisierer und Condition.
    virtual const CtrlExpr * getFirstExpr(CtrlThread *) const;

    // Liefert eine Sequenz von Reinit und Condition
    virtual const CtrlExpr * getIterationExpr(CtrlThread *) const;

    /// Gewichtung des CtrlSment
    virtual SmentWeight getWeight() const { return SM_WT_Low; }

    virtual void writeTrace(CtrlThread *thread, bool writeValue = true) const;

    virtual bool checkIntegrity(const CharString &location, CtrlThread *) const;

    /** dump the whole tree for code coverage analysis
        @param to output stream
      */
    virtual void dumpCoverageTree(std::ostream &to, CoverageAction action = DUMP) const;

  private:
    ForSment ();

  private:
    CtrlExpr  *initExpr;    // Initialisierer
    CtrlExpr  *reinitExpr;  // Iteration
};

#endif

