#ifndef _ANYTYPEVAR_H_
#define _ANYTYPEVAR_H_

#ifndef _VARIABLE_H_
#include <Variable.hxx>
#endif

#ifndef _CHARSTRING_H_
#include <CharString.hxx>
#endif
 
// ========== AnyTypeVar ============================================================

/** Variable class. which serves as a container for all other variable types
    whenever the exact type is not known or not wanted to be known
    @n The assignment operator covers the conversion from and to the AnyType var.
  */
//author Martin Koller
class DLLEXP_BASICS AnyTypeVar : public Variable
{
  public:
    /** constructor
        @param v the Variable, which shall be initialised from
      */
    AnyTypeVar(Variable *v = 0);
    
    /** copy constructor
        @param rVal the AnyTypeVar, which shall be copied from
      */
    AnyTypeVar(const AnyTypeVar &rVal);

    /** destructor
      */
    virtual ~AnyTypeVar() { delete var; }
    
    /** allocator deallocator class
      */
    AllocatorDecl;

    /** operator << for itcNdrUbSend stream
        @param ndrStream the stream, which to send to
        @param fVar the AnyTypeVar
      */
    friend DLLEXP_BASICS itcNdrUbSend &operator<<(itcNdrUbSend &ndrStream, const AnyTypeVar &fVar);

    /** operator >> for itcNdrUbReceive stream
        @param ndrStream the stream, which to receive from
        @param fVar the AnyTypeVar
      */
    friend DLLEXP_BASICS itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream, AnyTypeVar &fVar);

    /** return type of variable
        @return ANYTYPE_VAR
      */
    virtual VariableType isAUncached() const { return ANYTYPE_VAR; }

    /** return type of variable
        @param varType the VariableType to check
        @return ANYTYPE_VAR if AnyTypeVar else return other VariableType
      */
    virtual VariableType isAUncached(VariableType varType) const;

    /** comparison operator ==
        @param v the Variable to compare with
            @n Important: this operator checks the VariableType, so two objects are only equal, if
               they also have the same class (no conversion is done; see other operators).
        @return 0 if not equal else 1
      */
    virtual int operator==(const Variable &v) const;

    /** assignment operator used for type conversion
        @param newVar the Variable to convert
            @n Every variable type can be converted to a AnyTypeVar.
        @return the resulting Variable
      */
    virtual Variable &operator=(const Variable &newVar);

    /** assignment operator for the same type
        @param rVal the AnyTypeVar to assign
        @return the resulting AnyTypeVar
      */
    virtual AnyTypeVar &operator=(const AnyTypeVar &rVal)
      { operator=((const Variable&)rVal); return *this; }

    /** check if this AnyTypeVar object is logically true, i.e. if not empty and != 0
        @return PVSS_FALSE if this AnyTypeVar object is empty else PVSS_TRUE
      */
    PVSSboolean isTrue() const {return (var) ? var->isTrue() : PVSS_FALSE; }
    
    /** allocate new AnyTypeVar
        @return the new AnyTypeVar
      */
    virtual Variable *allocate() const { return new AnyTypeVar(); }

	  /** get pointer to the stored Variable object
        @return the pointer to the stored Variable object
        @n The caller is not allowed to delete the memory.
      */
    Variable *getVar() const { return var; }

    /** cut the stored Variable object out of the AnyTypeVar container
        @return the pointer to the Variable object
        @n The caller is responsible to delete the memory.
      */
    Variable *cutVar() { Variable *v = var; var = 0; return v; }

    /** set a new Variable object for the AnyTypeVar container, the old one is deleted,
        the new one is captured
        @param v the Variable object to set
      */
    virtual void setVar(Variable *v); 

    /** send to output stream
        @param to the stream, which to send to
      */
    virtual void outToFile(std::ostream &to) const;
    
    /** get from input stream
        @param from the stream, which to get from
      */
    virtual void inFromFile(std::istream &from);
 
    /** format the value according to the format string
        @param  format the CharString format
		    @n  If the value is not empty it is used as an argument to the sprintf function. Else the value
                itself is returned.
        @return the string representation of the value
      */
    virtual CharString formatValue(const CharString &format) const;

    /** format the value according to a format string
        @param format the format string
            @n If the string is not empty it is used as an argument to the sprintf function,
               else "%lu" is used as a default.
        @param target the buffer, which is directly written to
            @n This method is more performant than the one which returns a CharString,
               because no alloc is done.
        @param len the length of the buffer
        @return number of bytes written into target without 0-byte,
                or a negative value on error (like buffer too small)
    */
    virtual int formatValue(const CharString &format, char *target, size_t len) const;

    /** clone the current AnyTypeVar object
        @return the Variable as clone of this object
      */
    virtual Variable *clone() const {return new AnyTypeVar((var)?var->clone():0);}

    /** for container-like types (e.g. AnyTypeVar) this method returns the final target
        @return The final target Variable instance
    */
    virtual Variable *getTarget() const { return var; }

  protected:
    /** member holding the Variable value
      */
    Variable *var;

  private:
    virtual void outNdrUb(itcNdrUbSend &) const;
    virtual void inNdrUb(itcNdrUbReceive &);
};


// -------------------------------------------------------------------------------

inline void AnyTypeVar::setVar(Variable *newVar)
{
  delete var;

  // Unpack an AnyTypeVar
  if (newVar && newVar->isA(ANYTYPE_VAR) == ANYTYPE_VAR)
  {
    var = ((AnyTypeVar *) newVar)->cutVar();
    delete newVar;
  }
  else
    var = newVar;
}


inline  AnyTypeVar::AnyTypeVar(Variable *v)
                  : var(0)
{
  cachedIsA = ANYTYPE_VAR;

  setVar(v);
}


inline AnyTypeVar::AnyTypeVar(const AnyTypeVar &rVal)
                 : Variable(rVal), var(0)
{
  if (rVal.var)
    var = rVal.var->clone();
}


#endif /* _ANYTYPEVAR_H_ */
