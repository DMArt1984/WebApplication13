#ifndef _ALERTCLASS_OBJECT_HXX_
#define _ALERTCLASS_OBJECT_HXX_

#ifndef _CHARSTRING_H_
#include <CharString.hxx>
#endif

#ifndef _DPIDENTIFIER_H_
#include <DpIdentifier.hxx>
#endif

#define APRIO_INVALID (-1L)

class AlertService;

/** Base class for alert.  
  * @classification public use 
  */
class AlertClassObject 
{
// only AlertService can set the AClass to internal ...
friend class AlertService;

public:
    /** Constructor, the property priority is set to APRIO_INVALID at first.
    * @param name a deference to name  
      */
    AlertClassObject(const CharString &name) : AClassPrio_(APRIO_INVALID), internal_(PVSS_FALSE) 
      {AClassName_ = name; if (AClassName_[AClassName_.len()-1] == '.') AClassName_[AClassName_.len()-1] = '\0'; }

  /** Constructor, the parameter AClassPrio is set to APRIO_INVALID at first.
      */
    AlertClassObject() : AClassPrio_(APRIO_INVALID), internal_(PVSS_FALSE) {}
    
  /** Destructor
      */
  ~AlertClassObject() {}

  /** Assignment operator 
    * @param aco deference to alert object
    * @return reference to alert object 
    */
    const AlertClassObject & operator =(const AlertClassObject &aco) 
      { AClassName_ = aco.AClassName_; AClassContainer_ = aco.AClassContainer_; AClassPrio_ = aco.AClassPrio_; internal_ = aco.internal_; return *this; }
    
  /** Copy constructor
      * @param aco reference to another AlertClassObject
    */
  AlertClassObject(const AlertClassObject &aco) {if (this != &aco) *this = aco;}

    /** Gets the name of the object.
    * @return a dp name
    */
    const CharString &getName() const { return AClassName_; }

  /** Sets DP identifier.
      * @param dpId the dp identifier representing the name of this object
    */  
    void setDpIdentifier(const DpIdentifier &dpId) { AClassContainer_ = dpId; }

    /** Gets DP identifier.
    *  @return a DPIdentifier representing the name of this object
    */
    const DpIdentifier & getDpIdentifier() const {return AClassContainer_;}

    /** Sets the alert class priority.
      * @param prio alert class priority
      */
    void setPriority(PVSSlong prio) {AClassPrio_ = prio;}

   /** Gets the alert class priority.
     * @return alert class priority 
     */
    PVSSlong getPriority() const {return AClassPrio_;}

    /** Chrck if this is an internally set AClass.
      * @return PVSS_TRUE if the AClass has been registered internally
      */
    PVSSboolean isInternal() const {return internal_;}

private:
    CharString AClassName_;             // a DP name
    DpIdentifier AClassContainer_;      // the DPIdentifier representing the name (plus root element (?))
    PVSSlong AClassPrio_;               // the AClass prio
    mutable PVSSboolean internal_;      // this AClass name was set internally, exclude from DP processing
};

#include <set>
using namespace std;

// Comparison operators - sort objects by name.
/** Comparison operator (equality) - compares objects by name.
  * @param aco1
  * @param aco2
  * @return PVSS_TRUE if name of first object is equal to name of second object
  */
inline int operator ==(const AlertClassObject &aco1, const AlertClassObject &aco2) {return (aco1.getName() == aco2.getName());}

/** Comparison operator (less than..)- compares objects by name.
  * @param aco1
  * @param aco2
  * @return result of names comparison
  */
inline int operator < (const AlertClassObject &aco1, const AlertClassObject &aco2) {return (aco1.getName() < aco2.getName());}

typedef std::set<AlertClassObject> AClassSet;

#endif
