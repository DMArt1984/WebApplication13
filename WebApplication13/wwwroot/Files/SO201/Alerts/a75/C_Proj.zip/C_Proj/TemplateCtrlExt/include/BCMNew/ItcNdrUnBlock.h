//
//  $RCSfile$
//  $Date$
//  $Revision$
//  $Author$
//  $Locker$
//  $State$
//  $Source$
//
// %Z%JESSI-COMMON-FRAMEWORK 2.0
// %Z%Copyright (C) by Siemens Nixdorf Informationssysteme AG 1992
// %Z%Copyright (C) by Universitaet GH Paderborn 1992
// %Z%Development of this software was partially funded by ESPRIT project 7364.
// %Z%BCM %M% %I% %E%

#ifndef ItcNdrUnBlock_H
#define ItcNdrUnBlock_H

//#ifdef __GNUG__
//#pragma interface
//#endif

#include "ItcNDR.h"

class itcConnection;
class itcNdrUbSend;
class itcNdrUbReceive;


///the itcNDRSend extended to maintain its transmission state 
class DLLEXP_BCM itcNdrUbSend : public itcNDRSend {
  // -- TYPES --
  public:
    ///send states enum
    enum SndState {
      nothingTransmitted = 0,
      partOfMagicTransmitted = 1,
      partOfLengthTransmitted = 2,
      partOfDataTransmitted = 3,
      allTransmitted = 4,
      transmissionError = 5
    };


    // -- FRIENDS --
    friend class DLLEXP_BCM itcNdrUbReceive;
    friend class UNIT_TEST_FRIEND_CLASS;

    friend DLLEXP_BCM NDR_range operator<<(itcConnection &conn, itcNdrUbSend &ndr);
    friend DLLEXP_BCM int operator<<(int tr, itcNdrUbSend &ndr);

    friend DLLEXP_BCM NDR_range send_rawdata(itcConnection &conn, itcNdrUbSend &ndr);

    friend DLLEXP_BCM itcNdrUbSend &operator<<(itcNdrUbSend &, const itcXNDR &);

    friend DLLEXP_BCM itcNdrUbSend &operator<<(itcNdrUbSend &, char);
    friend DLLEXP_BCM itcNdrUbSend &operator<<(itcNdrUbSend &, unsigned char);
    friend DLLEXP_BCM itcNdrUbSend &operator<<(itcNdrUbSend &, signed char);
    friend DLLEXP_BCM itcNdrUbSend &operator<<(itcNdrUbSend &, int16_t);
    friend DLLEXP_BCM itcNdrUbSend &operator<<(itcNdrUbSend &, uint16_t); 
    friend DLLEXP_BCM itcNdrUbSend &operator<<(itcNdrUbSend &, int32_t);
    friend DLLEXP_BCM itcNdrUbSend &operator<<(itcNdrUbSend &, uint32_t);
    friend DLLEXP_BCM itcNdrUbSend &operator<<(itcNdrUbSend &, int64_t);
    friend DLLEXP_BCM itcNdrUbSend &operator<<(itcNdrUbSend &, uint64_t);
    friend DLLEXP_BCM itcNdrUbSend &operator<<(itcNdrUbSend &, float);
    friend DLLEXP_BCM itcNdrUbSend &operator<<(itcNdrUbSend &, double);
    friend DLLEXP_BCM itcNdrUbSend &operator<<(itcNdrUbSend &, const char*);
    friend DLLEXP_BCM itcNdrUbSend &operator<<(itcNdrUbSend &, const itcBinData &);

    // Not used in PVSS II
# if 0
    friend DLLEXP_BCM itcNdrUbSend &operator<<(itcNdrUbSend &, const std::string&);
# endif


    // -- METHODS --
  public:
    /**ctor(unsigned short _version)
      @param _version user defined version no of the stream
    */
    itcNdrUbSend(unsigned short _version);
    /**ctor(unsigned short _version, int size);
      @param _version user defined version no of the stream
      @param size buffer size
    */
    itcNdrUbSend(unsigned short _version, int size);
    ///destructor
    virtual ~itcNdrUbSend();

    ///get send state
    SndState send_state() const { return snd_state; }
    ///send state ok
    int send_state_ok() const { 
      return snd_state != transmissionError; 
    }
    ///send state failed
    int send_state_fail() const { 
      return snd_state == transmissionError; 
    }
    ///nothing sent
    int send_state_nothing() const { 
      return snd_state == nothingTransmitted; 
    }
    ///sending data in progress
    int send_state_in_progress() const { 
      return (snd_state > nothingTransmitted && 
          snd_state < allTransmitted); 
    }
    ///all data sent
    int send_state_all() const { 
      return snd_state == allTransmitted; 
    }

    /**insert string data into sender
      @param ch_ptr data buffer, should be maintained by caller
      @param count buffer size
    */
    itcNdrUbSend &insert(const char *ch_ptr, int count);     // REDEFINITION

    /**put general data into sender
      @param opaque data buffer
      @param count buffer size
      @param do_align true - compute alignment before writing buffer and write to correctly aligned address
      @param add_count true - write size of data buffer first and the the buffer self
    */
    itcNdrUbSend &put_opaque(const void *opaque, int count, bool do_align = true, bool add_count = true); // REDEFINITION

    ///reset sender
    void reset(); // REDEFINITION, reset for adding
    
    ///reset transmission state
    void reset_transmission_state(); // reset for transmission
    ///get data size ready for sending
    NDR_range  get_data_tobe_sent() const {return data_tobe_sent;} 
    ///get sent byte count
    NDR_range  get_bytes_sent() const     {return bytes_sent;}
    ///get version of the stream
    unsigned short get_version() const    {return version;}
    /**set version
      @param _version version number of the stream
      */
    void set_version(unsigned short _version) {version = _version; }


    /*
    // Methoden sind unsicher, da der Send-Buffer anders verwendet wird!!!
    // siehe ItcNDRSend.C und ItcNdrUnBlock.C
    itcNdrUbSend& operator = (itcNdrUbReceive &rec);  // REDEFINITION
    void take_over(itcNdrUbReceive &rec);             // REDEFINITION
     */


    // -- DATA --
  private:
    NDR_data      snd_data_ptr;     // current transmission of data
    NDR_range     data_tobe_sent;   // bytes of data still to be sent
    SndState      snd_state;        // transmission state of send buffer
    NDR_range     bytes_sent;
    unsigned short version;          // user defined version no of the stream

    //IM99368, tschirk: operator= and copy ctor shall never be used! therefore set it private
    ///copy ctor
    itcNdrUbSend(const itcNdrUbSend &ndr) {};
    ///= operator
    itcNdrUbSend &operator=(const itcNdrUbSend &ndr) {return *this;};
};


///the itcNDRReceive extended to maintain its transmission state 
class DLLEXP_BCM itcNdrUbReceive : public itcNDRReceive 
{
  // -- TYPES --
  public:
    ///receive states enum
    enum RcvState {
      nothingReceived = 0,
      partOfMagicReceived = 1,
      partOfLengthReceived = 2,
      partOfDataReceived = 3,
      allReceived = 4,
      transmissionError = 5,
      disconnected = 6
    };


    // -- FRIENDS --
    friend class itcNdrUbSend;

    friend DLLEXP_BCM NDR_range operator>>(itcConnection &conn, itcNdrUbReceive &ndr);
    friend DLLEXP_BCM int operator>>(int tr, itcNdrUbReceive &ndr);

    friend DLLEXP_BCM NDR_range receive_rawdata(itcConnection &conn, itcNdrUbReceive &ndr);

    friend DLLEXP_BCM itcNdrUbReceive &operator>>(itcNdrUbReceive &, itcXNDR &);

    friend DLLEXP_BCM itcNdrUbReceive &operator>>(itcNdrUbReceive &, char &);
    friend DLLEXP_BCM itcNdrUbReceive &operator>>(itcNdrUbReceive &, unsigned char &);
    friend DLLEXP_BCM itcNdrUbReceive &operator>>(itcNdrUbReceive &, signed char &);
    friend DLLEXP_BCM itcNdrUbReceive &operator>>(itcNdrUbReceive &, int16_t &);
    friend DLLEXP_BCM itcNdrUbReceive &operator>>(itcNdrUbReceive &, uint16_t &);
    friend DLLEXP_BCM itcNdrUbReceive &operator>>(itcNdrUbReceive &, int32_t &);
    friend DLLEXP_BCM itcNdrUbReceive &operator>>(itcNdrUbReceive &, uint32_t &);
    friend DLLEXP_BCM itcNdrUbReceive &operator>>(itcNdrUbReceive &, int64_t &);
    friend DLLEXP_BCM itcNdrUbReceive &operator>>(itcNdrUbReceive &, uint64_t &);
    friend DLLEXP_BCM itcNdrUbReceive &operator>>(itcNdrUbReceive &, float &);
    friend DLLEXP_BCM itcNdrUbReceive &operator>>(itcNdrUbReceive &, double &);
    friend DLLEXP_BCM itcNdrUbReceive &operator>>(itcNdrUbReceive &, itcBinData &);

  public:
    /// secure replacement of friend DLLEXP_BCM itcNdrUbReceive &operator>>(itcNdrUbReceive &, char*);
    itcNdrUbReceive &read_string(char*, size_t size);


    // -- METHODS --
  public:
    /**ctor(unsigned short _version)
      @param _version user defined version no.\, will be checked against the number contained at the beginning of the stream
    */
    itcNdrUbReceive(unsigned short _version);
    /**ctor(unsigned short _version, int size)
      @param _version user defined version no. of the stream\, see prev. ctor
      @param size buffer size
    */
    itcNdrUbReceive(unsigned short _version, int size);
    /**ctor(unsigned short _version, const char *buffer, int size)
      @param _version user defined version no of the stream\, see prev. ctor
      @param buffer buffer ptr    
      @param size buffer size
    */
    itcNdrUbReceive(unsigned short _version, const char *buffer, int size);
    ///destructor
    virtual ~itcNdrUbReceive();

    ///get receive state
    RcvState receive_state() const { return rcv_state; }
    ///receive state ok
    int receive_state_ok() const { 
      return rcv_state < transmissionError; 
    }
    ///receive failed
    int receive_state_fail() const {
      return rcv_state == transmissionError;
    }
    ///nothing received
    int receive_state_nothing() const { 
      return rcv_state == nothingReceived; 
    }
    ///receive in progress
    int receive_state_in_progress() const {
      return (rcv_state > nothingReceived && 
          rcv_state < allReceived);
    }
    ///all received
    int receive_state_all() const { 
      return rcv_state == allReceived; 
    }
    ///disconnected
    int receive_state_disconnected() const {
      return rcv_state == disconnected;
    }

    /**go to some position in buffer
      @param count how many bytes should be the position adjusted
    */
    itcNdrUbReceive &skip(int count);


    // REDEFINITION

    /**extract string data
      @param ch_ptr input buffer
      @param count sizeof buffer
    */  
    itcNdrUbReceive &extract(char *ch_ptr, unsigned int &count); 
    /**extract string data
      @param ch_ptr in/out buffer can be reallocated internally
      @param size sizeof buffer
      @param count new size
    */  
    itcNdrUbReceive &extract(char *&ch_ptr, int size, int &count); 
    /**get general data
      @param opaque in/out buffer can be reallocated internally
      @param size sizeof buffer
      @param count new size
    */  
    itcNdrUbReceive &get_opaque(void *&opaque, int size, int &count);


    ///reset reader
    void reset(); // REDEFINITION, reset for reading
    ///reset transmision state
    void reset_transmission_state(); // reset for transmission

    ///get received byte count
    NDR_range get_bytes_received() const {return bytes_rcvd;}

    /*
    // Methoden sind unsicher, da der Send-Buffer anders verwendet wird!!!
    // siehe ItcNDRSend.C und ItcNdrUnBlock.C
    itcNdrUbReceive& operator = (itcNdrUbSend &send);  // REDEFINITION
    void take_over(itcNdrUbSend &send);                // REDEFINITION
     */
    ///get version might be initalized in ctor
    unsigned short get_version() const    {return version;}
    /**set version for the received data
      @param _version version number of the stream
    */
    void set_version(unsigned short _version) {version = _version; }


    // -- DATA --
  private:
    char          rcv_magic[NDR_Magic_Len];  // storage of magic
    NDR_data      rcv_magic_ptr;    // current transmission of magic
    NDR_range     magic_tobe_rcvd;  // bytes of magic still to be received
    
    NDR_range     rcv_length;       // length of NDR stream to be received
    NDR_data      rcv_length_ptr;   // current transmission of length
    NDR_range     length_tobe_rcvd; // bytes of length still to be received

    NDR_data      rcv_data_ptr;     // current transmission of data
    NDR_range     data_tobe_rcvd;   // bytes of data still to be received
    RcvState      rcv_state;        // transmission state of receive buffer

    NDR_range     bytes_rcvd;       // Number of bytes currently received
    unsigned short version;          // user defined version no of the stream

    //IM99368, tschirk: opertor= and copy ctor shall never be used! therefore set it private
    ///copy ctor
    itcNdrUbReceive(const itcNdrUbReceive &ndr) {};
    ///asignment operator
    itcNdrUbReceive &operator=(const itcNdrUbReceive &ndr) {return *this;};

    friend class UNIT_TEST_FRIEND_CLASS;
};

#endif /* ItcNdrUnBlock_H */
