#ifndef _TypeAlias_H_
#define _TypeAlias_H_

// @author: Martin Koller; 26.April 2019
// @classification ETM internal

#include <TypeSpec.hxx>
#include <CharString.hxx>

class DLLEXP_CTRL TypeAlias
{
  public:
    TypeAlias(CharString *theName, const TypeSpec &typeSpec, int lineNum, int fileNum);

    ~TypeAlias();

    const CharString &getName() const { return *name; }
    const TypeSpec &getTypeSpec() const { return typeSpec; }

    TypeAlias *getNext() const { return next; }
    void setNext(TypeAlias *n) { next = n; }

    int getLineNumber() const { return lineNumber; }
    int getFileNumber() const { return fileNumber; }

  private:
    CharString *name = nullptr;
    TypeSpec typeSpec;
    TypeAlias *next = nullptr;
    int lineNumber = -1;    // for debugging/error reporting
    int fileNumber = -1;    // for debugging/error reporting
    bool refCounting = false;
};

#endif
