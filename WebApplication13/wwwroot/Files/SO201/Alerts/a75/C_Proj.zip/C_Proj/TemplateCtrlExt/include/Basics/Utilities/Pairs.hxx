// DATEIBESCHREIBUNG ==============================================================
// DATEINAME:     Pair.hxx
// VERANTWORTUNG: Andreas Pfluegl
// BESCHREIBUNG : clone of the STL class std::pair and extentions of this class
//                
//
// AENDERUNGS-HISTORIE
// Ver.  | Datum      | Aenderungen                            | ModNr.| Autor
// ------+------------+-----------------Anfang-----------------+-------+-----------
//   1.0 |            | 1.inital                               |     0 |
// ======================================Ende======================================
#ifndef _PAIRS_H_
#define _PAIRS_H_

// Anm.: 
// Das ist eine reine Template Klasse -> 
// In der Libs/Basics gibt es keine Instanzierung und somit auch keinen Code.
// Aus diesem Grund braucht die Klasse auch keine export/import Deklaration "DLLEXP_BASICS"
//
// Derzeit habe ich nur implementiert was ich gerade brauche. Wer mehr vom pair interface braucht 
// darf es sich gerne implementieren. 

/** clone of the STL class std::pair.
  */
template <class T1, class T2> class Pair
{
  public:
    ///
    Pair<T1, T2>() {}

    ///
    Pair<T1, T2>(const T1 &_first, const T2 &_second)
      :first(_first), 
       second(_second) {}

    virtual ~Pair() {}

  public:
    T1 first;
    T2 second;
};

/** extends Pair with the static method compare, 
    so that you can simply use it with DynPtrArray. 
    if you use compare as "compare function" of a DynPtrArray, it is sorted accordingly 
    the member "first".

    Prerequisites: Datatypes that want to be used as key have to implement the "<" and the "==" operators 
  */
template <class T1, class T2> class KeyValuePair: public Pair<T1, T2>
{
  public:
    ///
    KeyValuePair<T1, T2>()
      :Pair<T1, T2>() {}

    ///
    KeyValuePair<T1, T2>(const T1 &_key, const T2 &_value)
      :Pair<T1, T2>(_key, _value) {}

    ///
    virtual ~KeyValuePair() {}

  public:
    ///
    const T1 &getKey()   { return(this->first);  }
    ///
    const T2 &getValue() { return(this->second); }

  public:
    /** compares two Objects of the type KeyValuePair.
        @return: -1 if _p1.first <  _p2.first
                  0 if _p1.first == _p2.first
                  1 if _p1.first >  _p2.first
      */
    static int compare(const KeyValuePair *_p1, const KeyValuePair *_p2) { return((_p2->first == _p1->first) ? 0 : ((_p1->first < _p2->first) ? -1 : 1)); }
};


/** is a partly specialisation of KeyValuePair. 
    it is a pair where the "first" member is of datatype "const char *".
  */
template <class T> class StringValuePair: public KeyValuePair<const char *, T>
{
  public:
    ///
    StringValuePair<T>()
      :KeyValuePair<const char *, T>() {}

    ///
    StringValuePair<T>(const char *_key, const T &_value)
      :KeyValuePair<const char *, T>(_key, _value) {}

    ///
    virtual ~StringValuePair() {}

  public:
    /** compares two Objects of the type StringValuePair.
        @return: strcmp(_p1->first, _p2->first)
      */
    static int compare(const StringValuePair *_p1, const StringValuePair *_p2) { return(strcmp(_p1->first, _p2->first)); }
};

#endif /* _PAIRS_H_ */

