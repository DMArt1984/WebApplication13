#ifndef _LISTRECURSER_H_
#define _LISTRECURSER_H_

/*
VERANTWORTUNG: Robert Trausmuth     *
BESCHREIBUNG:
*/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include <Types.hxx>
#include <CharString.hxx>

/** the list recurser class. it checks a string for curly braces and iterates through the parts, returning the single string elements once per call
    @classification ETM internal
*/
class DLLEXP_BASICS ListRecurser 
{
  friend class UNIT_TEST_FRIEND_CLASS;    
public:
  /** constructor. takes a string of the form "{item1,item2,item3}"
      @param source the string in braces
  */
  ListRecurser(const CharString &source);
 
  /** check if number of opening braces match closing ones
      @return PVSS_FALSE on error
  */
  PVSSboolean checkBraces();
  /** get the next string part
      @returns 0 if no more strings are found
  */
  const char *getNextFromPart();

private:
    CharString orig;
    // char buf[200];      // internal buffer // WOKL: um Gottes Willen!
    CharString buf;
    char *headPtr;
    char *tailPtr;
    char *currentPtr;
    char *bracePtr;
    // int level;
    PVSSboolean init;

    // so that the compiler does not define them itself !!

    /* copy constructor
    */
    ListRecurser(const ListRecurser &) {}
    /* assignment operator
    */
    ListRecurser &operator=(const ListRecurser &) { return *this; } //COVINFO LINE: defensive (AP: disallow =operator)
};

#endif /* _LISTRECURSER_H_ */
