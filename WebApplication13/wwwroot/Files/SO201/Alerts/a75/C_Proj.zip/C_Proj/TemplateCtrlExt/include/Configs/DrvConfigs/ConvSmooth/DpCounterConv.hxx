// DATEIBESCHREIBUNG ==============================================================
// DATEINAME:     DpCounterConv.hxx
// VERANTWORTUNG:	Stanislav Meduna
// 
// BESCHREIBUNG:	Zaehlerumrechnung
//
// AENDERUNGS-HISTORIE
// Ver.  | Datum      | Aenderungen                            | ModNr.| Autor
// ------+------------+-----------------Anfang-----------------+-------+-----------
//   1.0 |            | 1.Erstellung mit Westmount-OMT         |     0 |
//   1.1 | 08.09.2010 | Adding doxygen comments                |       | psedik
// ======================================Ende======================================
#ifndef _DPCOUNTERCONV_H_
#define _DPCOUNTERCONV_H_

// forward declarations and includes
class DpCounterConv;

#include <DpConversion.hxx>
#include <IntegerVar.hxx>
#include <ConfigTypes.hxx>

class DpConvSmooth;
class DpCounterConv;
class Variable;
class BitVec;

// ========== DpCounterConv ============================================================
/// Conversion class used for counting edges and pulses
class DLLEXP_CONFIGS DpCounterConv : public DpConversion 
{
public:
  
  /// Constructor
  DpCounterConv();

  /// Destructor
  ~DpCounterConv();

  /// Outputs the instance to the itcNdrUbSend stream
  /// @param ndrStream Output stream
  /// @param aConv Streamed DpCounterConv instance
  /// @return itcNdrUbSend stream
  friend DLLEXP_CONFIGS itcNdrUbSend &operator<<(itcNdrUbSend &ndrStream, const DpCounterConv &aConv);

  /// Receives the instance from the itcNdrUbReceive stream
  /// @param ndrStream Input stream
  /// @param aConv DpCounterConv instance receiving the value from the stream
  /// @return itcNdrUbReceive stream
  friend DLLEXP_CONFIGS itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream, DpCounterConv &aConv);
  
  /// Assignment operator
  /// @param aConv assigned value
  /// @return DpConvSmooth reference with the assigned value
  DpConvSmooth &operator=(const DpConvSmooth &aConv);

  /// Returns conversion type of this class
  /// @return DpConvCounter
  virtual DpConversionType convType() const;

  /// Convert method. Will incremented the internally stored counter according to the attrWhatToCount
  /// and inpVar value. The new counter will be returned in the outVarPtr
  /// @param inpVar BitVar which will specify if the counter will be incremented or not (depending
  /// on the attrWhatToCount member)
  /// @param outVarPtr Reference to a pointer, where the newly allocated IntegerVar with new
  /// actual counter value will be assigned
  /// @param unused BitVec value, not used in the code
  /// @return 
  /// - DpConversionOK if the call was successfull
  /// - DpConversionError if attrWhatToCount has invalid value or it was not possible to allocate new IntegerVar
  /// - DpConversionBadType if inpVar is not of type BitVar
  virtual DpConversionResultType convert(const Variable &inpVar, Variable * & outVarPtr, const BitVec &unused);

  /// Allocates the new DpCounterConv instance with default constructor.
  /// @return DpConvSmooth pointer to a newly allocated instance.
  virtual DpConvSmooth *allocate() const;

  /// Set the attribute.
  /// @param attrNr Attribute number
  /// @n For this class, the following attributes are implemented:
  /// - COUNTER_WHAT_TO_COUNT_ATTR: Sets the attrWhatToCount member
  /// - COUNTER_RESET_AT_ATTR: Sets the attrResetAt member
  ///
  /// @param var Variable with the attribute value.
  /// @return PVSS_TRUE if the attribute was set, otherwise PVSS_FALSE.
  virtual PVSSboolean setAttribut(DpAttributeNrType attrNr, const Variable &var);

  /// Get the attribute with the specified number. See setAttribut() for more info.
  /// @param attrNr Attribute index
  /// @return Pointer to the Variable with the value.
  virtual Variable *getAttribut(DpAttributeNrType attrNr) const;

  /// Checks if the attrWhatToCount member has correct value
  /// @return PVSS_TRUE if type is correct, PVSS_FALSE otherwise
  virtual PVSSboolean isConsistent() const;

  /// Gets the attrWhatToCount member specifying what will be counted in the convert() method
  /// @return IntegerVar will the value from the CounterConvType enum
  const IntegerVar &getAttrWhatToCount() const;

  /// Gets the attrWhatToCount member specifying what will be counted in the convert() method
  /// @return IntegerVar will the value from the CounterConvType enum
  IntegerVar &getAttrWhatToCount();

  /// Set the attrWhatToCount member
  /// @param newAttrWhatToCount New value to be set
  void setAttrWhatToCount(const IntegerVar &newAttrWhatToCount);

  /// Gets the attrResetAt member specifying a value at which the counter will be reset to 0
  /// @return IntegerVar with the attrResetAt value
  const IntegerVar &getAttrResetAt() const;

  /// Gets the attrResetAt member specifying a value at which the counter will be reset to 0
  /// @return IntegerVar with the attrResetAt value
  IntegerVar &getAttrResetAt();

  /// Set the attrResetAt member
  /// @param newAttrResetAt New value to be set
  void setAttrResetAt(const IntegerVar &newAttrResetAt);

  /// Gets the counter value. It is incremented by the convert() method.
  /// @return currentCount member
  const PVSSlong &getCurrentCount() const;

  /// Gets the counter value. It is incremented by the convert() method.
  /// @return currentCount member
  PVSSlong &getCurrentCount();

  /// Set the value of the counter
  /// @param newCurrentCount New value to be set
  void setCurrentCount(const PVSSlong &newCurrentCount);

protected:
private:
  /// This specifies the type of conversion, see implementation of the convert() method
  IntegerVar attrWhatToCount;

  /// When counter reaches the attrResetAt number, it is reset to 0
  IntegerVar attrResetAt;

  /// Counter, incremented in convert() method when the conditions are met
  PVSSlong currentCount;

  /// Flag specifying if this is a last value. See implementation of convert() method 
  PVSSboolean lastValue;

  /// set to true when at least one convert() call happened, then reset back to false
  /// is operator>> and setAttribut
  PVSSboolean living;

friend class UNIT_TEST_FRIEND_CLASS;
};

// ================================================================================
// Inline methods

inline const IntegerVar &DpCounterConv::getAttrWhatToCount() const
{
  return attrWhatToCount;
}

inline IntegerVar &DpCounterConv::getAttrWhatToCount()
{
  return attrWhatToCount;
}
inline void DpCounterConv::setAttrWhatToCount(const IntegerVar &newAttrWhatToCount)
{
  attrWhatToCount = (IntegerVar &) newAttrWhatToCount;
}
inline const IntegerVar &DpCounterConv::getAttrResetAt() const
{
  return attrResetAt;
}

inline IntegerVar &DpCounterConv::getAttrResetAt()
{
  return attrResetAt;
}
inline void DpCounterConv::setAttrResetAt(const IntegerVar &newAttrResetAt)
{
  attrResetAt = (IntegerVar &) newAttrResetAt;
}
inline const PVSSlong &DpCounterConv::getCurrentCount() const
{
  return currentCount;
}

inline PVSSlong &DpCounterConv::getCurrentCount()
{
  return currentCount;
}
inline void DpCounterConv::setCurrentCount(const PVSSlong &newCurrentCount)
{
  currentCount = (PVSSlong &) newCurrentCount;
}

#endif /* _DPCOUNTERCONV_H_ */
