#ifndef _RESOURCEDIAG_H_
#define _RESOURCEDIAG_H_

#include <TimeVar.hxx>
#include <CharString.hxx>
#include <MessageDiag.hxx>
#include <ConfigAndDpDiag.hxx>
#include <ManagerIdentifier.hxx>

// ========== ResourceDiag ============================================================

/**
 * This class provides counting methodes and reports for several PVSS Resources
 * @classification ETM internal
 */

class DLLEXP_BASICS ResourceDiag
{
  /// <summary>
  /// Declare test class as a friended class, having access to private/protected methods
  /// </summary>    
  friend class UNIT_TEST_FRIEND_CLASS;

  public:
    /// constructor
    ResourceDiag();

    /// virtual destructor
    virtual ~ResourceDiag();

    /** set initializing parameters of ResourceDiag class
        @param maxNrOfConfigs the max. number of config files
        @param numOfLangs the number of languages (unused)
        @param getId the function to get config ID
      */
    void init(unsigned long maxNrOfConfigs,
              unsigned long numOfLangs /*unused*/,
              PVSSboolean (*getId)(const char *, DpIdentifier&));


  /** add config operation
      @n Call if a config has been added.
      @param theConfig the value of added config
      @param sizeOfTheConfig the size of added config
    */
    void addConfig(unsigned long theConfig, unsigned long sizeOfTheConfig);

    /** remove config operation
      @n Call if a config has been removed.
      @param theConfig the value of removed config
      @param sizeOfTheConfig the size of removed config
    */
    void removeConfig(unsigned long theConfig, unsigned long sizeOfTheConfig);

    /** get config info
      @param configMemSum the config memory sum
      @param configCount the count of configs
      @param configNames the names of configs
      @return max number of configs
    */
    unsigned long dpConfigManagerInfo(unsigned long &configMemSum, unsigned long *&configCount, const CharString* & configNames);

    /** add DP type operation
      @n Call if a DP type has been added.
      @param sizeOfDpType the size of added DP type
    */
    void addDpType(unsigned long sizeOfDpType);

    /** remove DP type operation
      @n Call if a DP type has been removed.
      @param sizeOfDpType the size of removed DP type
    */
    void removeDpType(unsigned long sizeOfDpType);

    /** add DP type node operation
      @n Call if a DP type node has been added.
      @param sizeOfDpTypeNode the size of added DP type node
    */
    void addDpTypeNode(unsigned long sizeOfDpTypeNode);

    /** remove DP type node operation
      @n Call if a DP type node has been removed.
      @param sizeOfDpTypeNode the size of removed DP type node
    */
    void removeDpTypeNode(unsigned long sizeOfDpTypeNode);

    /** add type reference string operation
      @n Call if a type reference string has been added.
      @param sizeOfTypeRefStr the size of added type reference string
    */
    void addTypeRefStr(unsigned long sizeOfTypeRefStr);

    /** remove type reference string operation
      @n Call if a type reference string has been removed.
      @param count the count of removed type reference strings
      @param sizeOfTypeRefStr the size of removed type reference strings
    */
    void removeTypeRefStr(unsigned int count, unsigned long sizeOfTypeRefStr);

    /** get type container info
      @param typeCount the count of types
      @param typeNodeCount the count of types of nodes
      @param typeRefCount the count of types of references
      @return sum of memory
    */
    unsigned long dpTypeContainerInfo(unsigned long &typeCount,
                                      unsigned long &typeNodeCount,
                                      unsigned long &typeRefCount);

    /** get ConfigAndDpDiag
      @return ConfigAndDpDiag
    */
    ConfigAndDpDiag *getConfigAndDpDiag();

    /** init ConfigAndDpDiag
    */
    void initConfigAndDp();

    /** get list of all DP identifiers, which has been changed since last call of getDirtyList()
        @param dpIdList the list of DP identifiers
        @return TRUE if at least one DP found else FALSE
      */
    bool getConfigAndDpDirtyList(DpIdValueList &dpIdList);

    /** set Datapoint count
        @param dpCnt the count of Datapoints
      */
    void setDatapointCnt(unsigned long dpCnt);

    /** get Datapoint count
        @return the count of Datapoints
      */
    unsigned long getDatapointCnt() const;

    /** send message status
    */
    void sndMessageStat();

    /** receive message status
    */
    void rcvMessageStat();

    /** get message status info
        @param sndTotal the total number of sent messages
        @param rcvTotal the total number of received messages
        @param sndSinceLastReport the number of sent messages since last report
        @param rcvSinceLastReport the number of received messages since last report
        @param elapsedSec the elapsed seconds
    */
    void messageStatInfo(unsigned long &sndTotal,
                         unsigned long &rcvTotal,
                         unsigned long &sndSinceLastReport,
                         unsigned long &rcvSinceLastReport,
                         double &elapsedSec);

    /** send message status
        @param man the manager identifier
        @param msgType the message type
    */
    void sndMessageStat(const ManagerIdentifier &man, const MessageDiag::MsgType msgType);

    /** receive message status
        @param man the manager identifier
        @param msgType the message type
    */
    void rcvMessageStat(const ManagerIdentifier &man, const MessageDiag::MsgType msgType);

    /** get list of all DP identifiers, which has been changed since last call of getDirtyList()
        @param dpIdList the list of DP identifiers
        @param summen the list of DP identifiers
        @return TRUE if at least one DP found else FALSE
      */
    bool getMsgDirtyList(DpIdValueList &dpIdList, DpIdValueList &summen);

    /** get list of all DP identifiers, which has been changed
        @param resList the list results
        @return TRUE if at least one result found else FALSE
      */
    bool getMsgTotalList(MessageDiag::DynInfoItem &resList);

  protected:

  private:
  // -----------------------------------------------
  // --
  // -----------------------------------------------
    ConfigAndDpDiag *configAndDp_;
    unsigned long maxNrOfConfigs_;
    unsigned long *dpConfigCount_;
    unsigned long dpConfigMemSum_;

  // -----------------------------------------------
  // --
  // -----------------------------------------------
    unsigned long dpTypeCount_;
    unsigned long dpTypeMemSum_;
    unsigned long dpTypeNodeCount_;
    unsigned long dpTypeNodeMemSum_;
    unsigned long typeStrRefCount_;
    unsigned long typeStrRefMemSum_;

  // -----------------------------------------------
  // --
  // -----------------------------------------------
    unsigned long datapointCount_;

  // -----------------------------------------------
  // --
  // -----------------------------------------------
    unsigned long connTableEntryCount_;
    unsigned long connTableEntryMemSum_;

  // -----------------------------------------------
  // --
  // -----------------------------------------------
    unsigned long ctrlScriptCount_;
    unsigned long ctrlThreadCount_;
    unsigned long ctrlSmentCount_;
    unsigned long ctrlSmentMemSum_;

  // -----------------------------------------------
  // --
  // -----------------------------------------------
    unsigned long queryPendingRuns_;
    unsigned long alertPendingRuns_;
    unsigned long hotLinkPendingRuns_;
    unsigned long allPendingRunsMemSum_;

  // -----------------------------------------------
  // --
  // -----------------------------------------------
    PVSSboolean (*getId_)(const char *, DpIdentifier&);

    PtrList snd_[MAX_MAN];
    PtrList rcv_[MAX_MAN];

    MessageDiag  *sndMsgTotal;
    MessageDiag  *rcvMsgTotal;

    unsigned long updateRate_;

    TimeVar lastReportTime_;
    unsigned long sndCountTotal_;
    unsigned long rcvCountTotal_;
    unsigned long sndCountSinceLastReport_;
    unsigned long rcvCountSinceLastReport_;
};

// -------------------------------------------------
// -------------------------------------------------
// -------------------------------------------------

// -----------------------------------------------
// --
// -----------------------------------------------
inline ConfigAndDpDiag *ResourceDiag::getConfigAndDpDiag()
{
  return(configAndDp_);
}

// -----------------------------------------------
// --
// -----------------------------------------------
inline void ResourceDiag::sndMessageStat()
{
  sndCountTotal_++;
  sndCountSinceLastReport_++;
}

// -----------------------------------------------
// --
// -----------------------------------------------
inline void ResourceDiag::rcvMessageStat()
{
  rcvCountTotal_++;
  rcvCountSinceLastReport_++;
}

#endif /* _RESOURCEDIAG_H_ */
