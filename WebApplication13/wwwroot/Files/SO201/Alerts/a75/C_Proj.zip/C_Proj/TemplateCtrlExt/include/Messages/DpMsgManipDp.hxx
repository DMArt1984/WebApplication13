// DATEIBESCHREIBUNG ==============================================================
// DATEINAME:     DpMsgManipDp.hxx
//
//
// ======================================Ende======================================
#ifndef _DPMSGMANIPDP_H_
#define _DPMSGMANIPDP_H_

// Vorwaerts-Deklaration der Eigenen Klasse
class DpMsgManipDp;

// System-Include-Files
#include <DpMsg.hxx>
#include <DpTypes.hxx>
#include <PtrList.hxx>

// Vorwaerts-Deklarationen :
class DpIdentifierItem;
class DpMsgManipDp;
class Msg;

// ========== DpMsgManipDp ============================================================

/** Create or delete a datapoint. 
    This message is used to request the creation or deletion of a datapoint and also to notify the manager of a new or deleted datapoint.  
*/
class DLLEXP_MESSAGES DpMsgManipDp : public DpMsg 
{
  /// Write the instance into the itcNdrUbSend stream.
  friend DLLEXP_MESSAGES itcNdrUbSend &operator<<(itcNdrUbSend &ndrStream, const DpMsgManipDp &msg);
  /// Read the instance from the itcNdrUbReceive stream.
  friend DLLEXP_MESSAGES itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream, DpMsgManipDp &msg);

public:
  // Construct a dpCreate message

  /** Constructor to create a datapoint. 
      @param dpId A DpIdentifier that must contain the datapoint type and shall contain the system id.
      @param name The new datapoint name.
      @param req If PVSS_TRUE construct a request message (DP_MSG_DP_REQ), else construct a notification message.
  */ 
  DpMsgManipDp(const DpIdentifier &dpId, const CharString &name, PVSSboolean req = PVSS_TRUE);

  /** Constructor to delete a datapoint.
      @param dpId A DpIdentifier that must contain the datapoint id and shall contain the datapoint type and the system id.
      @param req If PVSS_TRUE construct a request message (DP_MSG_DP_REQ), else construct a notification message.
  */
  DpMsgManipDp(const DpIdentifier &dpId, PVSSboolean req = PVSS_TRUE);

  /// The copy constructor.
  DpMsgManipDp(const DpMsgManipDp &newMsg) { *this = newMsg; }

  /** The default constructor. 
      This constructs an empty request message (DP_MSG_DP_REQ) to delete a datapoint.
  */  
  DpMsgManipDp();

  /// Destructor.
  ~DpMsgManipDp();


  // Operatoren :
  /// Comparison operator.
  int operator==(const DpMsgManipDp &rVal) const;
  /// Comparison operator.
  virtual int operator==(const Msg &rVal) const;
  /// Assignment operator.
  DpMsgManipDp &operator=(const DpMsgManipDp &rVal);
  /// Assignment operator.
  virtual Msg &operator=(const Msg &rVal);

  // Spezielle Methoden :
  /// Check if own type matches other type.
  MsgType isA(MsgType dpMsgType) const;
  /// Get own type.
  MsgType isA() const;

  /// Get flag indicating whether answer is required.
  PVSSboolean needsAnswer() const;

  /// Set the id of the newly created datapoint and change the message type to DP_MSG_MANIP_DP.
  PVSSboolean changeToManipMsg(DpIdType dp);
  /// Change type to DP_MSG_MANIP_DP.
  PVSSboolean changeToManipMsg();

  /** Set the id of the newly created datapoint and change the message type to DP_MSG_MANIP_DP.
      @deprecated this method is not used anymore
  */
  PVSSboolean transform2cmd(DpIdType dp) {return changeToManipMsg(dp);}
  /** Change type to DP_MSG_MANIP_DP.
      @deprecated this method is not used anymore
  */
  PVSSboolean transform2cmd()            {return changeToManipMsg();}

  /// Check if this is a create or delete message.
  PVSSboolean isDeleteDpMsg() const     {return newDp ? PVSS_FALSE : PVSS_TRUE;}
  /// Old function call to check if this is a create or delete message.
  PVSSboolean isNotDeleteDpMsg() const  {return newDp;}

  /** Set DpID.
      @classification internal
  */
  PVSSboolean setDpId(DpIdType dpNum);

  /// Create new instance.
  Msg *allocate() const;
  /// Get number of groups.
  virtual PVSSulong getNrOfGroups() const {return itemList.getNumberOfItems();}
  /** Get the DpIdentifier from the first group.
  The getGroupId method is called by the AnswerHandler::sendMsgWaitingForAnswer() to return the DpIdentifier from the first group.
  */
  virtual DpIdentifier getGroupId(PVSSulong) const {return getDpId();}

  /** Print the contents of the list to an output stream.   
  Level controls the amount of debug information printed and shall be > 0.
  */
  virtual void debug(std::ostream &to, int level) const;

  /// Get the created / deleted datapoint.
  const DpIdentifier & getDpId() const;

  /// Get the name of a new datapoint.
  CharString getDpName() const;

  /// Get the system number of the DpIdentifier.
  SystemNumType getSystem() const {return getDpId().getSystem();}
  /// Get the dp type number of the DpIdentifier.
  DpTypeId getDpType() const      {return getDpId().getDpType();}
  /// Get the DpID of the DpIdentifier.
  DpIdType getDp() const          {return getDpId().getDp();}

  /// Get UserID.
  PVSSuserIdType getUserId() const   { return userId; }
  /// Set UserID.
  void setUserId(PVSSuserIdType uId) { userId= uId; }

  // Obsolete Funktionen:

  /** Get the system number of the DpIdentifier.
      @deprecated this method is not used anymore
  */       
  SystemNumType  getSystemNum() const {return getSystem();}
  /** Get the DpID of the DpIdentifier.
      @deprecated this method is not used anymore
  */
  DpIdType       getDpNum() const     {return getDp();}

  /** Get the (first) DpIdentifierItem pointer. 
      @return The (first) DpIdentifierItem pointer, the caller must not delete it
  */
  DpIdentifierItem *getIdentifierItemPtr() const ;

  /// Write the instance into the itcNdrUbSend stream.
  virtual void outNdrUb(itcNdrUbSend &ndrStream) const;
  /// Read the instance from the itcNdrUbReceive stream.
  virtual void inNdrUb(itcNdrUbReceive &ndrStream);

private:
  MsgType         messageType;
  PVSSboolean     newDp;
  PVSSuserIdType  userId;
  PtrList         itemList;

public:
};


inline DpIdentifierItem * DpMsgManipDp::getIdentifierItemPtr() const
{
  return (DpIdentifierItem *) itemList.getFirst();
}

#endif /* _DPMSGMANIPDP_H_ */
