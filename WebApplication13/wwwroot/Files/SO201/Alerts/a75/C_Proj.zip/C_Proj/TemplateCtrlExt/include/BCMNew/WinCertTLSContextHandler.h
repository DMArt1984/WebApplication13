#ifndef _WINCERTTLSCONTEXTHANDLER_H
#define _WINCERTTLSCONTEXTHANDLER_H
//----------------------------------------------------------------------------
// Copyright (C) Siemens AG 2011. All Rights Reserved. Confidential.
//----------------------------------------------------------------------------
// Descr.: Class definition of CertFileTLSContextHandler
//----------------------------------------------------------------------------

#ifdef _WIN32
# include <wincrypt.h>
#endif

#include "ItcPrelude.h"
#include <TLSContextHandler.h>

typedef struct x509_st X509;

/**
    @n This class is responsible for the secure data handling using SSL. It is derived from ITLSContextHandler, the virtual function descriptions can be read there.
    @classification public use
  */

class DLLEXP_BCM WinCertTLSContextHandler : public TLSContextHandler
{

public:
  /// ERROR codes used at initiation of SSL library
  enum WinCertTlsErrorCodes
  {
    // Unspecified error has appeared
    ERR_UNKNOWN = -1,

    // no error
    ERR_SSL_NONE = 0,

    // The registering of the available SSL/TLS ciphers and digests is failed.
    ERR_SSL_LIBRARY_INIT = 1,

    // Checking of the consistency of a private key with the corresponding certificate loaded into ctx is failed.
    ERR_SSL_PRIVATE_KEY_CHECK = 2,

    // The loading of the certificates and private keys into the SSL_CTX or SSL object is failed.
    ERR_SSL_PRIVATE_KEY_USE = 3,

    //  The loading of a certificate chain from file into ctx is failed.
    ERR_SSL_CERT_CHAIN_USE = 4,

    // The location for ctx, at which CA certificates for verification purposes (or the CAFile) are located is wrong.
    ERR_SSL_LOAD_VERIFY_LOCATIONS = 5,

    // CRL file loading is failed.
    ERR_SSL_CRL_LOAD = 6,

    // Certificate lookup is failed.
    ERR_SSL_STORE_LOAD = 7,

    // The cipher list cannot be set.
    ERR_SSL_CIPHER_LIST_LOAD_FAIL = 8,

    // Creating of a new SSL_CTX object is failed.
    ERR_SSL_CTX_NEW = 9,

    // SSL wrapper init failed.
    ERR_INIT_SSL_WRAPPER = 10,
    
    // see: SslWrapper::InitStatus
    ERR_WRAPPER_VERSION_NOT_SUFFICIENT = 11,
    ERR_WRAPPER_FUNCTION_NOT_FOUND = 12,
    ERR_WRAPPER_LIBRARY_NOT_FOUND = 13,
    ERR_WRAPPER_NOT_INITIALIZED = 14,
    
    //
    ERR_KEY_MISMATCH = 15,
    
    // 
    ERR_SET_PRIVATE_KEY = 16,
        
    // 
    ERR_SET_CERTIFICATE = 17,
    ERR_SSL_SET_TMP_DH = 18,
    ERR_SSL_SET_TMP_ECDH = 19

  };

  /// Simple constructor
  WinCertTLSContextHandler();

  /// Initiate CertFileTLSContextHandler object with SSL specific data
  /// @param cFile is the location of certificate file (public key)
  /// @param kFile is the location of private key file
  /// @param caFile is the location of root CA cetrificate file (public key)
  /// @param crlFile is the location of certification revocate list
  /// @param inVerifyTime is a flag. If inVerifyTime = 0 the outdated certificates will be accepted too.
  /// @param dhParamFile is the location of a PEM file from which DH params
  ///                    for ephemeral DH key exchange are read. If null or empty,
  ///                    default params will be used.
  /// @param ecdhCurveName is the name of the curve to use for ephemeral ECDH key exchange.
  ///                      If null or empty, a default curve will be used.
  /// @return failure code. return >= 0 means OK
  WinCertTlsErrorCodes createWinCertContext ( const char *loc, const char *store, const char *name, 
                                              const char *caLoc, const char *caStore, const char *caName, 
                                              int inVerifyTime, const int wcFindType, 
                                              const char * cipherSuite, const char * caChainPrefix, 
                                              const char *dhParamFile, const char *ecdhCurveName );

  virtual void doBeforeSslHandshake();

  /// Destructor
  virtual ~WinCertTLSContextHandler();

  /** verificates the given certificate cert by use of Windows Crypto API
      returns OpenSSL error X509_V_OK on success of an error code like X509_V_ERR_APPLICATION_VERIFICATION, etc. indicating the error.
    */
  static int verifyCertificate(X509 *cert, const std::string &caloc, const std::string &caStore, const std::string &caName, int wcFindType, const std::string &chainPrefix);
#ifdef _WIN32
  static int verifyCertificate(PCCERT_CONTEXT peer, const std::string &loc, const std::string &store, const std::string &name, int wcFindType, std::string &localCertChain);
  static int verifyCertificate(PCCERT_CONTEXT peer, PCCERT_CONTEXT caCert, const std::string &name, DWORD verifyOptions, std::string &localCertChain);
  static PCCERT_CONTEXT getCertificateHandle(const std::string &loc, const std::string &store, const std::string &name, int wcFindType);
#endif

  static void clearOnlineCrlCheckRequired() { onlineCrlCheckRequired = false; }   // #52476

private:
  char *rootCaLoc;
  char *rootCaStore;
  char *rootCaName;
  int findType; // how to find the cert in the store - by name, by sha1, ...

  static bool onlineCrlCheckRequired;   // #52476

  friend class UNIT_TEST_FRIEND_CLASS;
};

#endif
