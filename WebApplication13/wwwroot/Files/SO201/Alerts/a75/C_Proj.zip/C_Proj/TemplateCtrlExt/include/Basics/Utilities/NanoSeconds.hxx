#ifndef _NANOSECONDS_H_
#define _NANOSECONDS_H_

// DATEIBESCHREIBUNG ==============================================================
// VERANTWORTUNG: Andreas Pfluegl
// BESCHREIBUNG: 
// ======================================Ende======================================

// System-Include-Files
#ifndef _TYPES_HXX_
#include <Types.hxx>
#endif


/** The 0,000 000 001 [ billionth ] fraction of a second expressed as a unsigned number in the range from 0 to 999 999 999. 
    this class can also deal with over and underruns.
  */
class DLLEXP_BASICS NanoSeconds
{
public:
  /** Default Constructor creates a "0 ns" object
  */
  NanoSeconds()                         :nano_(0) {}

  /** Constructor's for datatypes big enough to hold system numbers
  */
#if SIZEOF_LONG != SIZEOF_LONGLONG
  explicit NanoSeconds(long nano_)     :nano_(nano_) {}
#endif
  explicit NanoSeconds(PVSSlong nano_) :nano_(nano_) {}
  

  /** Copy Constructor
  */
  NanoSeconds(const NanoSeconds& _op) :nano_(_op.nano_) {}

  /** Operator =
  */
  NanoSeconds &operator=(const NanoSeconds& _op) { nano_ = _op.nano_; return(*this); }

  /** Operator +
  */
  NanoSeconds operator+(const NanoSeconds& _op) const { return(NanoSeconds(nano_ + _op.nano_)); }
  /** Operator -
  */
  NanoSeconds operator-(const NanoSeconds& _op) const { return(NanoSeconds(nano_ - _op.nano_)); }

  /** Operator >
  */
  bool operator> (const NanoSeconds& _op) const { return(this->nano_ >  _op.nano_); }
  /** Operator <
  */
  bool operator< (const NanoSeconds& _op) const { return(this->nano_ <  _op.nano_); }

  /** Operator ==
  */
  bool operator==(const NanoSeconds& _op) const { return(this->nano_ == _op.nano_); }
  /** Operator !=
  */
  bool operator!=(const NanoSeconds& _op) const { return(this->nano_ != _op.nano_); }
  

  /** minds the over/underruns when it calculates the nano seconds stored in this object.
      E.g. if stored -3 getNanoSecond() returns 999999997 and getOverUnderRuns() returns -1
    */
  PVSSulong getNanoSeconds() const;
  
  /** get the over/underruns of the nano seconds stored in this object. 
      @see getNanoSeconds()
    */
  time_t getOverUnderRuns() const;

  /** return the nanoseconds. No over/underrun calculation is done.
  */
  PVSSlong getValue() const { return nano_; }

  /** adjust the nano seconds to a value without over/underrun
      E.g. if stored -3 nano_ will be set to 999999997
    */
  void normalize();

  /** calculate the nano seconds and the over/underrun of a given value
      E.q. _nano -3 will result in return value 999999997 and _overUnderRun = -1
    */
  static PVSSulong normalize(PVSSlonglong _nano, time_t &_overUnderRun);

public:
  /// one second in nano seconds
  static const PVSSlong ONE_SECOND = 1000000000;
    
private: 
  NanoSeconds(PVSSchar);          // verbiete zu kleine typen
  NanoSeconds(PVSSuchar);
  NanoSeconds(PVSSshort);
  NanoSeconds(PVSSushort);
  
  NanoSeconds(PVSSulong);         // verbiete zu gro�e typen
  NanoSeconds(PVSSlonglong);
  NanoSeconds(PVSSulonglong);
  ///
  // alle casts verboten, damit der compiler nicht implizit auf eine zahl casten kann 
  // wer eine zahl will muss getPVSSulong() verwenden.
  operator bool( );

  operator char( );
  operator unsigned char( );
  
  operator short( );
  operator unsigned short( );
  
  operator int( );
  operator unsigned int( );
  
  operator long( );
  operator unsigned long( );
  
  operator long long( );
  operator unsigned long long( );
  
  operator bool( ) const;

  operator char( ) const;
  operator unsigned char( ) const;
  
  operator short( ) const;
  operator unsigned short( ) const;
  
  operator int( ) const;
  operator unsigned int( ) const;
  
  operator long( ) const;
  operator unsigned long( ) const;
  
  operator long long( ) const;
  operator unsigned long long( ) const;


private: 
  PVSSlong nano_;
};

// ---------------------------------------------------------------------------------
// --
// ---------------------------------------------------------------------------------
inline PVSSulong  NanoSeconds::getNanoSeconds() const
{ 
  time_t dummy;
  return(normalize(PVSSlonglong(nano_), dummy)) ;
}

// ---------------------------------------------------------------------------------
// --
// ---------------------------------------------------------------------------------
inline time_t NanoSeconds::getOverUnderRuns() const  
{ 
  time_t res;
  normalize(PVSSlonglong(nano_), res);

  return(res) ;
}

// ---------------------------------------------------------------------------------
// --
// ---------------------------------------------------------------------------------
inline void NanoSeconds::normalize()  
{ 
  nano_ = this->getNanoSeconds();
}

// ---------------------------------------------------------------------------------
// --
// ---------------------------------------------------------------------------------
inline PVSSulong NanoSeconds::normalize(PVSSlonglong _nano, time_t &_overUnderRun)  
{
  if ( (_nano >= 0) && (_nano < ONE_SECOND) )
  {
    _overUnderRun = 0;
    return static_cast<PVSSulong>(_nano);
  }

  PVSSlonglong sec(_nano / PVSSlonglong(ONE_SECOND));
  if ((_nano                               <  0) &&
      ((-_nano % PVSSlonglong(ONE_SECOND)) != 0))
  {
    sec--;          // 
    if (sec < MIN_TIME_VAR_SEC) sec = MIN_TIME_VAR_SEC;
  }
  else
  {
    if (sec > MAX_TIME_VAR_SEC) sec = MAX_TIME_VAR_SEC;
  }
  _overUnderRun = time_t(sec);
    
  // 
  PVSSlonglong fraction = _nano % PVSSlonglong(ONE_SECOND);
  if (_nano < 0)
  {
    PVSSlonglong tmp(-_nano % PVSSlonglong(ONE_SECOND));           // -3 bedeutet 999999997 nano sec
    fraction = ONE_SECOND - PVSSlong(tmp);                         // tmp ist immer kleiner als ONE_SECOND
  }

  return(PVSSulong(fraction)) ;
}
#endif /* _NANOSECONDS_H_ */
