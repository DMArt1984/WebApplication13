#ifndef _WHILESMENT_H_
#define _WHILESMENT_H_

#include <LoopSment.hxx>
#include <CtrlSmentList.hxx>

class CtrlExpr;

/*  author VERANTWORTUNG: Martin Koller */
/** while-loop statement */
class DLLEXP_CTRL WhileSment : public LoopSment
{
  public:
    /// wird vom YACC auf gerufen
    WhileSment(int line, int filenum) : LoopSment(line, filenum)  {}

    /** Beim Parsen: Expression der Schleife die vor jedem Durchlauf getestet wird.
      * @param theExpr IN: wird von ~DoSment frei gegeben.
      */
    void setExpr(CtrlExpr *theExpr) { expr = theExpr; }

    /** Legt einen Block am Stack an und testet expr.
      * @return wenn expr == TRUE  erstes CtrlSment der schleife
      * @return wenn expr == FALSE erstes CtrlSment nach der schleife
      */
    virtual const CtrlSment *execute(CtrlThread *thread) const;

    virtual const CtrlExpr * getFirstExpr(CtrlThread *) const;

    virtual const CtrlExpr * getIterationExpr(CtrlThread *) const;

    /// Gewichtung des CtrlSment
    virtual SmentWeight getWeight() const { return SM_WT_Medium; }

    virtual void writeTrace(CtrlThread *thread, bool writeValue = true) const;

    virtual bool checkIntegrity(const CharString &location, CtrlThread *thread) const;

    /** dump the whole tree for code coverage analysis
        @param to output stream
      */
    virtual void dumpCoverageTree(std::ostream &to, CoverageAction action = DUMP) const;
};

#endif /* _WHILESMENT_H_ */
