#ifndef _COLLECTFILTERREQUEST_H_
#define _COLLECTFILTERREQUEST_H_

// DATEIBESCHREIBUNG ==============================================================
// DATEINAME:     CollectFilterRequest.hxx
// VERANTWORTUNG: Andreas Pfluegl
// BESCHREIBUNG: 
//
// AENDERUNGS-HISTORIE
// Ver.  | Datum      | Aenderungen                            | ModNr.| Autor
// ------+------------+-----------------Anfang-----------------+-------+-----------
//   1.0 |            | 1.inital                               |     0 |
// ======================================Ende======================================
// System-Include-Files

class DpMsg;
class MsgMap;
class DpMsgAnswer;
class DLLEXP_MANAGER CollectFilterRequest
{

public:
  ///
  CollectFilterRequest(const DpMsgAnswer *_msgToAppend);

  ///
  ~CollectFilterRequest();

  ///
  bool collect(DpMsgAnswer *_msg);

private: 
  const DpMsgAnswer *msgToAppend_;
};

#endif /* _COLLECTFILTERREQUEST_H_ */

