#ifndef _PERIODACCU_H_
#define _PERIODACCU_H_

// Author: Heinz MEISSL
// Date:   14.4.1997
// Purpose: provide a buffer for time related cumulating functions,
// working on Variables

// ****************************************************************************
// Function:
//
// Values (class Variables) are observed at a specific time (class TimeVar).
// These value-time-tuples (short Tuples) shall be cummulated for given period(s).
// The cumulation stategy is implemented by a derivate of SimpleAccu.
// PeriodAccu is concerned with the filtering of tuples for a specific period of
// time; SimpleAccu doesn't know anything about periods.
//
// PeriodAccu may be used in two internal modes:
// - SIMPLE, values passed, are simply handed on to the SimpleAccu
// - INTERPOLATE, at period start and end time additional values are calculated
//   (interpolated by using the last value before, and the first value after the
//   interpolation point).
//   Additionally, when calling getResult() within an incomplete period,
//   PeriodBuffer fills the period with the last received value
// * two different types of intepolation are supported:
//   INTERPOLATE_0 ... the last received value is used -> stair interpolation
//   INTERPOLATE_1 ... linear interpolation is used
// ----------------------------------------------------------------------------
// Conditions & assumptions:
//
// ! If the following is ignored, results of getResult() are unpredictable!
//
// * Tuples passed to addValue() or addHistory() are in an ascending (time) order;
//   WITHIN each other and TO each other!
// ! The last history value may be of the same time as the first buffered online value.
// * the last history value must be before the current period end
// * call getResult() ONLY ONCE per period, when operating in mode INTERPOLATE
// ----------------------------------------------------------------------------
// Usage: 
//
// 1. Create PeriodAccu and assign a SimpleAccu in constructor.
//    PeriodBuffer is in state WAIT_FOR_HISTORY
// 2. Call addValue() for online values, they are buffered.
//    Call addHistory() for history values, they are passed to the SimpleAccu
//    immediately.
// 3. After the last history value call startWorking().
//    PeriodAccu feeds buffered online values to the SimpleAccu, as far as 
//    they belong to the current period.
//    PeriodAccu switches to the state WORKING.
// 4. Call addValue() for online values.
//    They are passed to the SimpleAccu immediately, or
//    if the values belong to the subsequent period(s), they are buffered
// 5. If you think the period is complete, call getResult().
//    If startWorking() has not been called before (state WAIT_FOR_HISTORY),
//    it is done automatically (after that, state is WORKING).
// 6. Call workNextPeriod() to advance to the subsequent period.
//    Buffered values that belong to this new period are feed to the SimpleAccu
//    automatically to update the accu status.
//    Values for subsequent period(s) remain in the buffer.
// continue at 4.
// -------------
// For a total reset to state WAIT_FOR_HISTORY call reset() and continue at 2.
// -------------
// If you try to call addHistory(), when PeriodBuffer is in state WORKING
// the tuple is ignored!
// ******************************************************************************

#ifndef _SIMPLEACCU_H_
#include <SimpleAccu.hxx>
#endif

#ifndef _BASEACCU_H_
#include <BaseAccu.hxx>
#endif

#include <QLinkedList>

#ifndef _VARIABLE_H_
#include <Variable.hxx>
#endif

#ifndef _BITVAR_H_
#include <BitVar.hxx>
#endif

#ifndef _TIMEVAR_H_
#include <TimeVar.hxx>
#endif

/** This class provides a buffer for time related cumulating functions, working on Variables.
    PeriodAccu stores temporarily actual value changes and historical values and manages the accumulation of values over predefined period of time. Using SimpleAccu derived class it can provide various kinds of result values.

    @classification ETM internal
*/
class DLLEXP_OABASICS PeriodAccu : public BaseAccu
{
  public:
    friend class UNIT_TEST_FRIEND_CLASS;
    /// Available working modes.
    enum AccuMode { NONE, INTERPOLATE_0, INTERPOLATE_1, INTERPOLATE_2, INTERPOLATE_3 };

    /** Constructor.
        PeriodAccu accumulates uses SimpleAccu derived object to perform specific calculation.

        @param  aSimpleAccu Pointer to SimpleAccu derived accumulator.
        @param  aVarType The type identifier, for which the accumulatior is created.
        @param  aMode Mode of work of the accumulator (see AccuMode enumeration).
        @param  aIntervalStart Starting timestamp.
        @param  aIntervalStop Stopping timestamp.
    */
    PeriodAccu( SimpleAccu * aSimpleAccu,
              const VariableType aVarType,
              const AccuMode aMode,
              const TimeVar &aIntervalStart,
              const TimeVar &aIntervalStop );

    /// Destructor
    virtual ~PeriodAccu();
    
    /// Add new value to the accumulator.
    virtual void addValue( const Variable &theValue, const TimeVar &atTime );
    /// Add new invalid value to the accumulator.
    virtual void addInvalidValue( const Variable &theValue, const TimeVar &atTime );

    /// Add new value to history.
    virtual void addHistory( const Variable &theValue, const TimeVar &atTime );
    /// Add new invalid value to history.
    virtual void addInvalidHistory(const Variable &theValue, const TimeVar &atTime);

    /** Advance to the subsequent period and process buffered values (if any).
        This function is always called after the getResult() method.
    */
    virtual void workNextPeriod( const TimeVar & nextStop );

    /** Process the buffered values. 
        When there is no history, this is a first function after the constructor which is called from StatFunc.
    */
    virtual void startWorking();

    // This method is probably not called from any external source. It can be private (WOKL 2.1.2001).
    // void reset( const TimeVar &theStart, const TimeVar &theStop );

    /// Return the result kept in the accumulator.
    virtual const Variable &getResult(TimeVar* periodStop = 0, PVSSboolean isIntermediate = false );

    /// Check if the accumulator is in the valid state. 
    virtual PVSSboolean isValid() const;

    /// Returns the start and stop time.
    virtual void getStartStop( TimeVar *start, TimeVar *stop) const;
    /// Set the start and stop time.
    virtual void setStartStop( const TimeVar &start, const TimeVar &stop);
    /// Reset the start and stop time.
    virtual void reset( const TimeVar &theStart, const TimeVar &theStop );

  protected:
    
  private:

    PeriodAccu();
    PeriodAccu(const PeriodAccu &);
    PeriodAccu &operator=(const PeriodAccu &);
    
    enum InternalMode { SIMPLE, INTERPOLATE };
    
    enum InterpolationMode { MODE_0, MODE_1, MODE_2, MODE_3 };
    
    enum AccuState { WAIT_FOR_HISTORY, WORKING, FINISHED };
    
    void setInterpolatedValue ( Variable &VarToSet, const TimeVar & atTime,
                                const Variable &FirstVar, const TimeVar &FirstTime,
                                const Variable &SecVar, const TimeVar &SecTime );

    void addFromBuffer();

    void addAllValues( const Variable &theValue, const TimeVar &atTime, const bool valid);
    void addAllHistory(const Variable &theValue, const TimeVar &atTime, const bool valid);
    void myAccumulate(SimpleAccu *theAccu, const Variable &theValue, const TimeVar &atTime, bool valid);
    void setLastIntermValue( const Variable &var, const TimeVar &time );

    AccuState myState;
    InternalMode myMode;
    InterpolationMode myInterpolationMode;
    QLinkedList<Variable *> myValueBuffer;
    QLinkedList<BitVar *> myValidBuffer;
    QLinkedList<TimeVar *> myTimeBuffer;
    Variable *lastHistoryValue;
    TimeVar lastHistoryTime;
    Variable *lastIntermValue;    // hier werden die Letzt- bzw. die Startwerte des Intervalls f�r die
    TimeVar lastIntermTime;       //    Zwischenwertgenerierung gemerkt
    TimeVar startAt;
    TimeVar stopAt;
    SimpleAccu *myAccu;

    // kopiert das valid-Flag zu lastHistoryValue (WOKL 31.1.01)
    // true nach reset und ctor
    // Bedeutung nicht nur fuer lastHistory..., sondern wird auch fuer my...Buffer verwendet (?)
    bool lastValueValid;    
};

// ****************************************************************************

inline PVSSboolean PeriodAccu::isValid() const
{
  return myAccu->isValid();
}

inline void PeriodAccu::getStartStop( TimeVar *sa, TimeVar *sp ) const
{
  *sa = startAt;
  *sp = stopAt;

  return;
}

inline void PeriodAccu::setStartStop( const TimeVar &sa, const TimeVar &sp )
{
  startAt = sa;
  stopAt = sp;

  return;
}

#endif
