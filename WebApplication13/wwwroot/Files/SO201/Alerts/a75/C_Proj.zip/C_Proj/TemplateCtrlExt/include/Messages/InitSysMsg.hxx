#ifndef _INITSYSMSG_H_
#define _INITSYSMSG_H_

/*
VERANTWORTUNG: Laszlo Szakony        
BESCHREIBUNG:
*/

#include <SysMsg.hxx>
#include <StringToken.hxx>

/**  The initialization message system class. 
 *   The message is sent during initialization of the connection between the client and the server. 
 *   It contains connection specific message data, e.g. Kerberos context, connection timeouts, addresing information, 
 *   message version, ... Message data is stored as a <key,value> pairs in the internal string buffer. 
 *   
 *   System initialization message also signals if the connection is ready for other message handshake. 
 *   This is only allowed if the Kerberos context is fully initialzed. Otherwise the client should wait until the connection is not fully initialized.
 */
class DLLEXP_MESSAGES InitSysMsg : public SysMsg 
{
  public:
    /// Default constructor
    InitSysMsg();

    /** Destination constructor
        @param newDestination a destination identification 
     */
    InitSysMsg(const ManagerIdentifier &newDestination);

    /** Copy constructor
        @param newMsg an instance of the message to be copied from
     */
    InitSysMsg(InitSysMsg &newMsg);

    /// Destructor
    ~InitSysMsg();

    // Operatoren :
 
   /** BCM output streaming operator.  
    *  
    *  @param [in,out] ndrStream the BCM output stream
    *  @param sysMsg the InitSysMsg object to stream over BCM
    *  @return ndrStream
    *
    */
    friend DLLEXP_MESSAGES itcNdrUbSend &operator<<(itcNdrUbSend &ndrStream, const InitSysMsg &sysMsg);

   /** BCM input streaming operator. All properties found in the stream replace the
    *  corresponding properties in the InitSysMsg
    *
    *  @param [in,out] ndrStream the BCM input stream
    *  @param [out] sysMsg the InitSysMsg object to receive from BCM
    *  @return ndrStream
    */
    friend DLLEXP_MESSAGES itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream, InitSysMsg &sysMsg);

   /** Output streaming operator. 
    *  
    *  @param [in,out] ofStream the output stream
    *  @param sysMsg the InitSysMsg object to stream over BCM
    *  @return ndrStream
    */
    friend DLLEXP_MESSAGES std::ostream &operator<<(std::ostream &ofStream, const InitSysMsg &sysMsg);

   /** Equal operator. The operator compares the messages instances.
    *  
    *  @param rVal an instance of Msg to be compared to
    *  @return int 0, if instances are equal, or not 0 otherwise
    */
    virtual int operator==(const Msg &rVal) const;

    /** Equal operator. The operator compares the initialization system messages instances.
     *  
     *  @param rVal an instance of InitSysMsg to be compared to
     *  @return int 0, if instances are equal, or not 0 otherwise
     *
     */
    int operator==(const InitSysMsg &rVal) const;

    /** Assignment operator. The operator assigns the content of the specified system message instances.
     *  
     *  @param rVal an instance of Msg to assign from
     *  @return Msg, assigned Msg instance
     *
     */
    Msg &operator=(const Msg &rVal);

    /** Assignment operator. The operator assigns the content of the specified initialization system message instances.
     *  
     *  @param rVal an instance of InitSysMsg to assign from
     *  @return InitSysMsg, assigned initialization system message instance
     *
     */
    InitSysMsg &operator=(const InitSysMsg &rVal);

    // Spezielle Methoden :

    /** Method returns the type of the system message.
     *   @param  msgType a system message type 
     *   @return MsgType, a SYS_MSG_INIT type is returned for a InitSysMsg type, or NO_MSG otherwise
     */
    virtual MsgType isA(MsgType msgType) const;
    
    /** Method returns a system message type.
     *   @return MsgType, a SYS_MSG_INIT type is always returned
     */
    virtual MsgType isA() const;

    /** Receives from itcNdrUbReceive stream
     *   @param ist the stream, which to receive from
     */
    virtual void inNdrUb(itcNdrUbReceive &ist);

    /** Sends to itcNdrUbSend stream
     *   @param ost the stream, which to send to
     */
    virtual void outNdrUb(itcNdrUbSend &ost) const;

    /** Sends a formatted output about internal status of the instance to the specified stream.
     * (used for logging purpose)
     *  @param ofStream   output stream
     */
    virtual void outToFile(std::ostream &ofStream) const;

    /** Method creates a new InitSysMsg instance.
     *   @return Msg, a new InitSysMsg instance
     */
    virtual Msg *allocate() const;

    /** Sends a formatted output about internal status of the instance to the specified stream.
     * (used for debugging purpose)
     *  @param to   output stream
     *  @param level   debugging level
     */
    virtual void debug(std::ostream &to, int level) const;
    
    // Get first / next key/value pair. Return false if no more vailable

    /** Returns first key=value pair from the internal message data buffer.
     *  @param key   a key string
     *  @param value   a key value string
     *  @return PVSS_TRUE, if the buffer is not empty, otherwise PVSS_FALSE is returned
     */
    PVSSboolean  getFirstData(CharString &key, CharString &value);

    /** Returns subsequent key=value pair from the internal message data buffer.
     *  @param key   a key string
     *  @param value   a key value string
     *  @return PVSS_TRUE, if the buffer is not empty, otherwise PVSS_FALSE is returned
     */
    PVSSboolean  getNextData(CharString &key, CharString &value);
    
    // Get data for key. Return false if key not found.

    /** Returns value of the specified key. The internal message data buffer is searched.
     *  @param key   a key string
     *  @param [out] value   a key value string
     *  @return PVSS_TRUE, if the key was found, otherwise PVSS_FALSE is returned
     */
    PVSSboolean  getData(const CharString &key, CharString &value);
    
    // Add key/value pair

    /** Adds a new key=value pair into the internal message data buffer.
     *  @param key   a new key string
     *  @param value   a new key value string
     */
    void  addData(const CharString &key, const CharString &value);
    
  private:
    CharString   data;  
    StringToken  token;
};


#endif /* _InitSysMsg_H_ */
