// DATEIBESCHREIBUNG ==============================================================
// DATEINAME:     DpVCItem.hxx
// VERANTWORTUNG: Johannes Ertl
// BESCHREIBUNG:  Diese Klasse enthaelt die Adresse und den dazugehoerigen Wert
//                eines Attributes.
// ======================================Ende======================================
#ifndef _DPVCITEM_H_
#define _DPVCITEM_H_

class DpMsgDriverVC;

#ifndef _TYPES_HXX_
#include <Types.hxx>
#endif

#ifndef _DPIDENTIFIER_H_
#include <DpIdentifier.hxx>
#endif

#ifndef _PTRLISTITEM_H_
#include <PtrListItem.hxx>
#endif

#ifndef _VARIABLE_H_
#include <Variable.hxx>
#endif

#ifndef _ALLOCATOR_H_
#include <Allocator.hxx>
#endif

#include <iostream>


// ========== DpVCItem ============================================================
/** The DpVCItem class. This class holds a pair of DpIdentifier and the corresponding value
  packed in a Variable object. This class is used as a data atom for messages of all kinds.
  The items inside a message group are mainly DpVCItem objects.
 */
class DLLEXP_BASICS DpVCItem : public PtrListItem
{
  friend class AnswerItem;
  friend class DpMsgDriverVC;

  // SecurityPlugin: some MsgGroupIterators need to manipulate the value of a DpVCItem
  friend class DpMsgAnswerIterator;
  friend class DpMsgAnswerWithAlertsIterator;
  friend class DpMsgAlertIterator;
  friend class DpMsgHotLinkIterator;

  public:
  /// Constructor. The value is cloned.
  DpVCItem(const DpIdentifier &dpId, const Variable &val) {dpIdentifier = dpId; value = val.clone();}

  /// Constructor, stores the poiner, not a deep copy. 
  DpVCItem(const DpIdentifier &dpId, VariablePtr valPtr) {dpIdentifier = dpId; value = valPtr;}

  /// Copy constructor. Performs a deep copy of the argument.
  DpVCItem(const DpVCItem &item);

  /// Create an empty item. 
  DpVCItem() : dpIdentifier(), value(0) {}

  /// Destructor. delete value, when it is not 0.
  ///  @see DpVCItemProt
  ///  @see cutValuePtr()
  virtual ~DpVCItem();

  /// Custom Allocator declaration.
  AllocatorDecl;

  /// Assignment operator. Performs a deep copy of the argument.
  /// @warning It is not virtual, so not use the following constructs,
  ///   when the compiler sees a *DpVCItem:
  ///   <ul>
  ///     <li> *myDpVCItemProt = *yourDpVCItemProt
  ///     <li> *myDpVCItem = *yourDpVCItemProt
  ///     <li> *myDpVCItemProt = *yourDpVCItem
  ///   </ul>

// "*((*DpVcItem) (&DpVCItemProt)) = DpVCItem" and related.
  virtual DpVCItem &operator=(const DpVCItem &rVal);
  
  /// Comparison operator. DpIdentifier and value are compared.
  int operator==(const DpVCItem &rVal) const;
  /// Comparison operator. DpIdentifier and value are compared.
  int operator!=(const DpVCItem &rVal) const;

  /// Writes the DpVCItem to a BCM Stream.
  friend DLLEXP_BASICS itcNdrUbSend &operator<<(itcNdrUbSend &ndrStream, const DpVCItem &item);
  /// Reads the DpVCItem from a BCM Stream.
  friend DLLEXP_BASICS itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream, DpVCItem &item);
  /// @see DpMsgDriverVC
  friend DLLEXP_BASICS itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream, DpMsgDriverVC &msg);

  /** Print the contents to an output stream.
      level controls the amount of debug information printed.
      Nothing is printed if level <= 0.
        @param to the stream to print to.
        @param level how much info wanted. 0 means nothing.
   */
  void debug(std::ostream &to, int level) const;

  /// Set a new value.
  /// If the old value pointer will be deleted if not 0.
  ///   @see DpVCItemProt
  ///   @see cutValuePtr()
  virtual void setValue(VariablePtr valuePtr);

  /// Get the DpIdentifier
  const DpIdentifier &getDpIdentifier() const  {return dpIdentifier;}

  /// Set the DpIdentifier
  void setDpIdentifier(const DpIdentifier &id) { dpIdentifier = id; }

  /// don't use this one! Use getValuePtr().
  /// @warning This methode is only for compatibility in the interface
  /// and will be removed. It has serious problems when the value
  /// pointer is 0.
  const Variable &getValue() const;

  /// Get the pointer to the variable
  VariablePtr getValuePtr() const {return value;}

  // liefert Pointer auf Variable und setzt internen Pointer auf 0 !!!
  /// Cut out the pointer to the variable.
  /// The caller is now responsible to delete the pointer.
  virtual VariablePtr cutValuePtr();

  protected:
  /// The Itentifier
  DpIdentifier dpIdentifier;
  /// The value
  VariablePtr value;
};


/// class with protected value ptr.
/// This class do not delete the value pointer, when DpVCItem will do so.
class  DLLEXP_BASICS  DpVCItemProt : public DpVCItem
{
  public:
    /// Constructor, stores the poiner, not a deep copy.
    DpVCItemProt(VariablePtr theValuePtr) : DpVCItem(DpIdentifier(), theValuePtr) {};
    /// Default constructor
    DpVCItemProt() : DpVCItem() {}

    /// Descrutor avoid delete of value pointer.
    ~DpVCItemProt();

    /// Set the value pointer to the new value, but do not delete the old one.
    virtual void setValue(VariablePtr valuePtr);

    /// clones the value pointer returned.
    virtual VariablePtr cutValuePtr();

    virtual DpVCItemProt &operator=(const DpVCItem &rVal);

    virtual DpVCItemProt &operator=(const DpVCItemProt &rVal);
};

// ================================================================================
// Inline-Funktionen :
// liefert Pointer auf Variable und setzt internen Pointer auf 0 !!!
inline int DpVCItem::operator==(const DpVCItem &rVal) const
{
  return (dpIdentifier == rVal.dpIdentifier &&
      ((value == 0 && rVal.value == 0) ||
       (value && rVal.value && *value == *(rVal.value))));
}


inline int DpVCItem::operator!=(const DpVCItem &rVal) const
{
  return !operator==(rVal);
}



inline DpVCItem::DpVCItem(const DpVCItem &val)
  :PtrListItem(), value(0)
{
  *this = val;
}


#endif /* _DPVCITEM_H_ */
