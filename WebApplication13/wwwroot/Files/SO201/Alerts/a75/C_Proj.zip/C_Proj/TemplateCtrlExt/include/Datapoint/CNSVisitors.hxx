#ifndef _CNSVISITORS_H_
#define _CNSVISITORS_H_

#include <SystemNumType.hxx>
#include <ViewId.hxx>
#include <LangText.hxx>
#include <CharString.hxx>

#include <CNSPath.hxx>
#include <CNSTree.hxx>
#include <CNSTreeVisitor.hxx>

/**
 * Implementation of CNSTreeVisitor which passes every node that matches the
 * specified CNSDataIdentifier to the given visitor.
 *
 * Used for CommonNameService::getNodes(const CNSDataIdentifier &, ...)
 *
 * @internal
 */
class DLLEXP_DATAPOINT DataIdentifierFilter : public CNSTreeVisitor
{
public:
  /**
   * Creates a new visitor which compares every passed node to the specified
   * CNSDataIdentifier and passes the matching ones on to the given visitor.
   */
  DataIdentifierFilter(const CNSDataIdentifier &id, CNSTreeVisitor &visitor)
    : id_(id), visitor_(visitor)
  {
  }

  /**
   * Overridden visitor method of CNSTreeVisitor.
   * All nodes that match the specified data identifier are passed to the
   * visitor specified in the constructor.
   */
  virtual CNSVisitor::NavigationHints visit(const CNSTreeNode &node);

private:
  /// The id to filter for
  const CNSDataIdentifier id_;
  /// The visitor to which matching nodes are passed
  CNSTreeVisitor &visitor_;

};

//------------------------------------------------------------------------------

inline CNSVisitor::NavigationHints DataIdentifierFilter::visit(const CNSTreeNode &node)
{
  if (node.getDataIdentifier().matches(id_))
  {
    return visitor_.visit(node);
  }

  return CNSVisitor::CONTINUE; // no match => no error
}

//------------------------------------------------------------------------------
// helper class PathPatternFilter
//------------------------------------------------------------------------------

/**
 * Implementation of CNSTreeVisitor which passes every node that matches the
 * specified path pattern to the given visitor.
 *
 * Used for CommonNameService::getNodes(const char *pattern, ...) and getIdSet()
 *
 * @internal
 */
class DLLEXP_DATAPOINT PathPatternFilter : public CNSTreeVisitor
{
public:
  /**
   * Creates a new visitor which compares every passed node to the specified
   * path pattern and other attributes and calls the given visitor for every
   * matching node.
   *
   * See CommonNameService::getIdSet() for the meaning of the parameters.
   */
  PathPatternFilter(const CharString &pattern,
                    const CNSVisitor::SearchMode &whichNames,
                    const LanguageIdType &langIdx,
                    const CNSDataIdentifierType &type,
                    CNSTreeVisitor &visitor)
    : pattern_(pattern), whichNames_(whichNames), langIdx_(langIdx), type_(type), visitor_(visitor)
  {
    ignoreCase = (whichNames_ & CNSVisitor::CASE_INSENSITIVE);
    if (ignoreCase)
    {
      pattern_.toLower();
    }
  }

  /**
   * Overridden visitor method of CNSVisitor.
   * Adds any passed nodes that match the specified criteria.
   */
  virtual CNSVisitor::NavigationHints visit(const CNSTreeNode &node);

private:
  CharString pattern_;
  const CNSVisitor::SearchMode whichNames_;
  const LanguageIdType langIdx_;
  const CNSDataIdentifierType type_;
  bool ignoreCase;
  /// The visitor to which the matching nodes are passed
  CNSTreeVisitor &visitor_;

  /**
   * Compare a path to a wildcard pattern.
   *
   * @param pattern The pattern to which the given path is compared to.
   * @param path The path to match
   * @param [out] willFailForChildren Tells whether the same pattern would
   *                                  fail to match for children of a node
   *                                  with the given path.
   * @param ignoreCase If true, the path will be matched case insensitive.
   *                   Be aware that the pattern is expected to already be
   *                   lowercased, since it does not change during the tree
   *                   traversal and thus only needs to be lowercased once.
   *
   * @return True if the path matches the pattern, otherwise false.
   */
  bool matchPath(const CharString &pattern, CharString &path,
                 bool &willFailForChildren, bool ignoreCase = false);
};


//------------------------------------------------------------------------------

inline bool PathPatternFilter::matchPath(const CharString &pattern, CharString &path,
                                         bool &willFailForChildren, bool ignoreCase)
{
  if (ignoreCase)
  {
    path.toLower();
  }

  return CNSPath::match(pattern.c_str(), path.c_str(), willFailForChildren);
}

//------------------------------------------------------------------------------
// helper class CNSVisitorWrapper
//------------------------------------------------------------------------------

/**
 * Allows to use a CNSVisitor as CNSTreeVisitor.
 *
 * @internal
 */
class DLLEXP_DATAPOINT CNSVisitorWrapper : public CNSTreeVisitor
{
public:
  CNSVisitorWrapper(CNSVisitor &visitor) : visitor_(visitor) { }

  /**
   * Overridden visitor method of CNSTree::Visitor.
   * All passed nodes will be delegated to the wrapped visitor.
   */
  virtual CNSVisitor::NavigationHints visit(const CNSTreeNode &node);

private:
  CNSVisitor &visitor_;
};

//------------------------------------------------------------------------------
// inline methods:

inline CNSVisitor::NavigationHints CNSVisitorWrapper::visit(const CNSTreeNode &node)
{
  CNSNode wrappedNode(node);
  return visitor_.visit(wrappedNode.getSystem(), wrappedNode.getView(), wrappedNode,
                        wrappedNode.getPath(), wrappedNode.getDisplayPaths());
}

//------------------------------------------------------------------------------
// helper class NodeCollector
//------------------------------------------------------------------------------

/**
 * Collects every passed node into a CNSNodeVector
 *
 * @internal
 */
class DLLEXP_DATAPOINT NodeCollector : public CNSTreeVisitor
{
public:
  /**
   * Creates a new collector which adds every passed node
   * to the specified collection.
   */
  NodeCollector(CNSNodeVector &collection) : collection_(collection) { }

  /**
   * Adds the passed node to the collection specified in the constructor.
   *
   * @return Always CONTINUE
   */
  virtual CNSVisitor::NavigationHints visit(const CNSTreeNode &node);

private:
  CNSNodeVector &collection_;
};

//------------------------------------------------------------------------------
// inline methods:

inline CNSVisitor::NavigationHints NodeCollector::visit(const CNSTreeNode &node)
{
  collection_.push_back(CNSNode(node));
  return CNSVisitor::CONTINUE;
}

//------------------------------------------------------------------------------
// helper class DataIdentifierCollector
//------------------------------------------------------------------------------

/**
 * Collects the data identifier of every passed node into a CNSDataIdentifierSet
 *
 * @internal
 */
class DLLEXP_DATAPOINT DataIdentifierCollector : public CNSTreeVisitor
{
public:
  /**
   * Creates a new collector which adds the data identifier of every passed node
   * to the specified collection.
   */
  DataIdentifierCollector(CNSDataIdentifierSet &collection) : collection_(collection) { }

  /**
   * Adds the data identifier of the passed node to the collection specified
   * in the constructor.
   *
   * @return Always CONTINUE
   */
  virtual CNSVisitor::NavigationHints visit(const CNSTreeNode &node);

private:
  CNSDataIdentifierSet &collection_;
};

//------------------------------------------------------------------------------
// inline methods:

inline CNSVisitor::NavigationHints DataIdentifierCollector::visit(const CNSTreeNode &node)
{
  collection_.insert(node.getDataIdentifier());
  return CNSVisitor::CONTINUE;
}


#endif // _CNSVISITORS_H_
