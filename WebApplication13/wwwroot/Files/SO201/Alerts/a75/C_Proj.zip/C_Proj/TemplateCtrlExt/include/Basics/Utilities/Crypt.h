#ifndef _CRYPT_H
#define _CRYPT_H

#ifdef __cplusplus
extern "C" 
#endif

/** Password encryption
@pw password to be encrypted
@salt if salt[0]== '_' + 4 Byte count + 4 else 2 char salt, parametrization for DES encryption
*/
DLLEXP_BASICS const char * PVSScrypt(const char * pw, const char *salt);

#endif	// _CRYPT_H

