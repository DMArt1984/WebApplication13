#ifndef _DONECB_H_
#define _DONECB_H_

class Variable;

/*  author Martin Koller */
/** Baseclass for executing statements after a dpValueChanged().
- call was fully executed in a CtrlScript, or a user-defd function was fully executed.
  In the case of a user-defd-func, the Variable* points to the returnValue,
  or 0 if the function returns void
*/
class DLLEXP_CTRL DoneCB
{
  public:
    /// destructor
    virtual ~DoneCB();

    /// return a copy of this
    virtual DoneCB *clone() const = 0;

    /// this is the Callback-function
    virtual void execute(const Variable *var = 0) = 0;
};

#endif /* _DONECB_H_ */
