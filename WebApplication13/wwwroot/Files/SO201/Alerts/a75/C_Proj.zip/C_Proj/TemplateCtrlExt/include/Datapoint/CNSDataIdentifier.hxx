#ifndef _CNSDATAIDENTIFIER_H_
#define _CNSDATAIDENTIFIER_H_

#include <Types.hxx>
#include <SystemNumType.hxx>
#include <DpTypes.hxx>
#include <Blob.hxx>

#include <iostream>
#include <vector>
#include <set>

#include <DpIdentifier.hxx>

// forward declaration
class Variable;
class DpIdentification;
class itcNdrUbReceive;
class itcNdrUbSend;


/**
 * An id to identify the data stored in CNSDataIdentifier
 * The range 0 to 500 are reserved for internal use, all others are free.
 */
typedef PVSSulong CNSDataIdentifierType;

/**
 * A container to store data of different structure in CNS nodes.
 *
 * For now it only handles DpIds. It also stores a UserData field, which can be
 * used to hold arbitrary Blobs of up to 255 bytes length. This UserData field
 * is ignored in relational operators (==, <, compare(), matches(), ...).
 */
class DLLEXP_DATAPOINT CNSDataIdentifier
{
public:
  /// BCM stream output operator
  friend DLLEXP_DATAPOINT itcNdrUbSend &operator<<(itcNdrUbSend &ndrStream, const CNSDataIdentifier &rval);

  /// BCM stream input operator
  friend DLLEXP_DATAPOINT itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream, CNSDataIdentifier &rval);

  /// Standard stream output operator. Useful for Unit Tests (CUAssertEQ).
  friend DLLEXP_DATAPOINT std::ostream &operator<<(std::ostream &strStream, const CNSDataIdentifier &rval);

public:

  enum
  {
    /// Maximum length of the data stored in the userData field
    MAX_USERDATA_LEN = 255
  };

  /**
   * Internal types for the stored data.
   * The range 0 to 500 are reserved for internal use,
   * all others are free to use.
   */
  enum Types
  {
    /// Smallest internal type
    MIN_INTERNAL_TYPE = 0,
    /// Used in CommonNameService to match every type. Do not use as type for
    /// an instance, except for searching with CommonNameService::getNodes()!
    ALL_TYPES = MIN_INTERNAL_TYPE,
    /// No data
    EMPTY = 1,
    /// A datapoint address (DpIdentifierVar)
    DATAPOINT = 2,
    /// Largest internal type
    MAX_INTERNAL_TYPE = 500
  };

  /**
   * Creates an empty instance with type EMPTY, which does not hold any data.
   */
  CNSDataIdentifier() : userData(0), sysId(0), dpId(0), elId(0), type(EMPTY) { }

  /**
   * Creates a new instance, pointing to a datapoint with the specified
   * system number and DpId.
   *
   * @param newSys The number of the system in which the datapoint exists
   * @param newDp The id of the datapoint in the specified system
   * @param newType The type of data in this instance. A user-defined
   *                value (above 500) can be specified to separate
   *                between different types or categories of datapoints.
   */
  CNSDataIdentifier(const SystemNumType &newSys, const DpIdType &newDp,
                    const CNSDataIdentifierType &newType = DATAPOINT)
    : userData(0), sysId(newSys), dpId(newDp), elId(0), type(newType)
  {
  }

  
  /**
   * Creates a new instance, pointing to a datapoint with the specified
   * DpId.
   *
   * @param id 
   * @param newType 
   * @param userDataBlob A Blob of arbitrary user data. Maximum length is
   *                    255 bytes, anything longer will be truncated.
   */  
  CNSDataIdentifier(const DpIdentifier &id, const CNSDataIdentifierType &newType = DATAPOINT, const Blob &userDataBlob = Blob())
    : userData(0), sysId(id.getSystem()), dpId(id.getDp()), elId(id.getEl()), type(newType)
  {
    if (userDataBlob.size() != 0)
      setUserData(userDataBlob);
  }
  
  
  /**
   * Creates a new instance, pointing to a datapoint with the specified
   * system number and DpId.
   *
   * @param newSys The number of the system in which the datapoint exists
   * @param newDp The id of the datapoint in the specified system
   * @param newUserData A Blob of arbitrary user data. Maximum length is
   *                    255 bytes, anything longer will be truncated.
   */
  CNSDataIdentifier(const SystemNumType &newSys, const DpIdType &newDp,
                    const Blob &newUserData)
    : userData(0), sysId(newSys), dpId(newDp), elId(0), type(DATAPOINT)
  {
    setUserData(newUserData);
  }

  /// Copy constructor
  CNSDataIdentifier(const CNSDataIdentifier &rval);

  /// Destructor
  ~CNSDataIdentifier();

  /// Equality operator
  bool operator==(const CNSDataIdentifier &rval) const;

  /// Inequality operator
  bool operator!=(const CNSDataIdentifier &rval) const;

  /// Less than operator (necessary for insertion into std::set)
  bool operator<(const CNSDataIdentifier &rval) const;

  /// Copy assignment operator
  CNSDataIdentifier &operator=(const CNSDataIdentifier &rval);

  /**
   * Compares this instance with the given instance.
   *
   * If the type of one of them is ALL_TYPES, the types will be considered equal
   * and the other members will be compared as with operator==().
   * Otherwise, it will return the same result as operator==().
   *
   * @param rval The instance with which to compare
   *
   * @return True if the two instances match, otherwise false
   */
  bool matches(const CNSDataIdentifier &rval) const;

  /**
   * Returns the type of the data in this instance.
   *
   * @see CNSDataIdentifier::Types
   */
  CNSDataIdentifierType isA() const { return type; }

  /**
   * Get the data.
   *
   * @param result The data in a suitable Variable type.
   *               For DATAPOINT this is a DpIdentifierVar.
   * @return true if the data has been assigned to result.
   */
  bool getData(Variable &result) const;

  /**
   * Stores a Blob of arbitrary data in this instance.
   * Anything longer than 255 bytes will be truncated.
   */
  void setUserData(const Blob &newUserData);

  /**
   * Stores a Blob of arbitrary data in this instance.
   * Anything longer than 255 bytes will be truncated.
   *
   * @param userDataPtr A pointer to the data to be copied.
   * @param userDataLen The length of the data in userDataPtr.
   */
  void setUserData(const PVSSuchar *userDataPtr, unsigned int userDataLen);

  /**
   * Returns the User Data Blob stored in this instance. Might be empty.
   */
  Blob getUserData() const;

  /**
   * Returns the number of bytes of User Data stored in this instance.
   */
  unsigned int getUserDataLen() const;

  /**
   * Returns a pointer to the User Data stored in this instance, or null
   * if it contains no User Data.
   */
  const PVSSuchar *getUserDataPtr() const;

  /**
   * Compares the given CNSDataIdentifier.
   *
   * This method provides the sort order for the internal datapoint index.
   * For other purposes, please use the less-than operator.
   *
   * @param a CNSDataIdentifier to compare
   * @param b CNSDataIdentifier to compare
   *
	 * @retval A negative value if a is smaller than b.
   * @retval A positive value if a is greater than b.
   * @retval Zero if both are equal.
   */
  static int compare(const CNSDataIdentifier &a, const CNSDataIdentifier &b);

private:
  const PVSSuchar *userData;
  SystemNumType sysId;
  DpIdType dpId;
  PVSSulong elId;
  CNSDataIdentifierType type;

};

//------------------------------------------------------------------------------
typedef std::vector<CNSDataIdentifier> CNSDataIdentifierVector;
typedef std::set<CNSDataIdentifier> CNSDataIdentifierSet;

//------------------------------------------------------------------------------
// inline-methods:

inline bool CNSDataIdentifier::matches(const CNSDataIdentifier &rval) const
{
  return (type == rval.type || type == ALL_TYPES || rval.type == ALL_TYPES) &&
         (sysId == rval.sysId) && (dpId == rval.dpId) && (elId == rval.elId);
}

//------------------------------------------------------------------------------

inline bool CNSDataIdentifier::operator==(const CNSDataIdentifier &rval) const
{
  return (type == rval.type) && (sysId == rval.sysId) && (dpId == rval.dpId) && (elId == rval.elId);
}

//------------------------------------------------------------------------------

inline bool CNSDataIdentifier::operator!=(const CNSDataIdentifier &rval) const
{
  return ! (*this == rval);
}

//------------------------------------------------------------------------------

inline bool CNSDataIdentifier::operator<(const CNSDataIdentifier &rval) const
{
  if (type  < rval.type) return true;
  if (type == rval.type)
  {
    if (sysId  < rval.sysId) return true;
    if (sysId == rval.sysId)
    {
      if (dpId  < rval.dpId) return true;
      if (dpId == rval.dpId)
      {
        return elId < rval.elId;
      }
    }
  }

  return false;
}

//------------------------------------------------------------------------------

inline void CNSDataIdentifier::setUserData(const Blob &newUserData)
{
  setUserData(newUserData.getData(), (unsigned int) newUserData.getLen());
}

//------------------------------------------------------------------------------

inline Blob CNSDataIdentifier::getUserData() const
{
  const PVSSuchar *dataPtr = getUserDataPtr();
  if (! dataPtr)
  {
    return Blob();
  }

  // it should be safe to const_cast here because the Blob ctor will only copy
  // the data.
  return Blob(const_cast<PVSSuchar *>(dataPtr), getUserDataLen(), PVSS_TRUE);
}


#endif // _CNSDATAIDENTIFIER_H_
