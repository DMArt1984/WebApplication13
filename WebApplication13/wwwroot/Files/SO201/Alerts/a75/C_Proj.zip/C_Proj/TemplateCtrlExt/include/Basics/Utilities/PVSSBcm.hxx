// DATEIBESCHREIBUNG ============================================================== 
// DATEINAME:      PVSSBcm.hxx
// VERANTWORTUNG:  Gerhard Fellrieser
//BESCHREIBUNG : Header-File fuer BCM-Library
//        Schaltet Macro __GNUG__ aus um "pragma-interface"-Switch in den
//        Header-Files der Bcm-Library zu deaktivieren. Bcm-Library (GNUmakefile), 
//        als auch Source-Files, die BCM-Funktionalitaet nutzen, werden 
//        ohne "interface"-Switch compiliert. Inline-Funktionen werden als `inline` 
//        implementiert. 

//
// AENDERUNGS-HISTORIE 
// Ver.  | Datum      | Aenderungen                            | ModNr.| Autor
// ------+------------+-----------------Anfang-----------------+-------+-----------
//   1.0 |01.12.1994  | 1.Erstellung                           |     0 | Gerhard Fellrieser
// ======================================Ende======================================


#ifndef _PVSSBCM_H_
#define _PVSSBCM_H_

#ifndef PVSS_CONSOLE_NT    /* avoid Bcm in NT-Console */

#include <Bcm.h>

/// The BCM interface class.
class DLLEXP_BASICS PVSSBcm
{
public:
  /// Startup the TCP/IP socket subsystem.
  static int Startup();
  /// Cleanup the TCP/IP socket subsystem.
  static int Cleanup();
};

#else     /* PVSS_CONSOLE_NT  */
class DLLEXP_BASICS itcNdrUbSend
{
  public:
};

class DLLEXP_BASICS itcNdrUbReceive
{
  public:
    itcNdrUbReceive & operator >> (long);
};

#endif    /* PVSS_CONSOLE_NT  */

#endif /* PVSSBCM_H_ */
