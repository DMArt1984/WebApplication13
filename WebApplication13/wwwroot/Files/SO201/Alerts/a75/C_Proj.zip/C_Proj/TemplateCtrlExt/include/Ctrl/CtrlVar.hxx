#ifndef _CTRLVAR_H_
#define _CTRLVAR_H_

#include <CtrlExpr.hxx>
#include <TypeSpec.hxx>
#include <Allocator.hxx>
#if defined (LIBS_AS_DLL)
#include <SimplePtrArray.hxx>
#endif
#include <ostream>

class CtrlExpr;
class Variable;
class UserType;

typedef uintptr_t CtrlVarId;

/*  author VERANTWORTUNG: Martin Koller */
/** Klasse zur Speicherung von CTRL-Variablen
    @classification ETM internal
*/

class DLLEXP_CTRL CtrlVar : public CtrlExpr
{
  public:
    enum
    {
      TQ_NONE         =   0,
      TQ_CONST        =   1, // is this var constant
      TQ_OPTIONAL     =   2, // is this an optional parameter
      TQ_GLOBAL       =   4, // is this a global variable (temporary used)
      TQ_LOCAL        =   8, // is this a local variable (temporary used)
      TQ_PRIVATE      =  16, // is this a private variable
      TQ_PROTECTED    =  32, // is this a protected variable
      TQ_PUBLIC       =  64, // is this a public variable
      TQ_STATIC       = 128, // is this a static variable
      TQ_SYNCHRONIZED = 256, // Not used in this class, just for parser
      TQ_REFERENCED   = 512  // internal: this CtrlVar is referenced by some other CtrlVar and must not delete the var (see AssExpr)
    };

    /// this constructor stores the given Variable-Pointer (no deep-copy)
    CtrlVar(Variable *newVar, int qualifier = TQ_NONE, int line = -1, int file = -1)
      : CtrlExpr(line, file), name(nullptr),
        id((CtrlVarId) this), init(nullptr), var(newVar), referTo(nullptr), refTypeSpec(NOTYPE_VAR),
        currentThread(nullptr), lockCount(0), flags(qualifier) { }

    /** this constructor creates a reference-var.
      * The (later set) Variable will not be deleted in the destructor
      */
    CtrlVar(VariableType type, int qualifier = TQ_NONE, int line = -1, int file = -1, const UserType *utype = nullptr)
      : CtrlExpr(line, file), name(nullptr),
        id((CtrlVarId) this), init(nullptr), var(nullptr), referTo(nullptr), refTypeSpec(type, utype),
        currentThread(nullptr), lockCount(0), flags(qualifier) { }

    /** this constructor creates a reference-var.
      * The (later set) Variable will not be deleted in the destructor
      */
    CtrlVar(const TypeSpec &typeSpec, int qualifier = TQ_NONE, int line = -1, int file = -1)
      : CtrlExpr(line, file), name(nullptr),
        id((CtrlVarId) this), init(nullptr), var(nullptr), referTo(nullptr), refTypeSpec(typeSpec),
        currentThread(nullptr), lockCount(0), flags(qualifier) { }

    /// copy-constructor
    CtrlVar(const CtrlVar &newVar) : CtrlExpr(newVar.getCurrentLine(), newVar.getFileNumber()),
       name(new CharString(newVar.name ? *(newVar.name) : shared_empty_name)), id(newVar.id), init(nullptr),
       var(newVar.var ? newVar.var->clone() : nullptr),
       referTo(newVar.referTo), refTypeSpec(newVar.refTypeSpec),
       currentThread(nullptr), lockCount(0), flags(newVar.flags) { }

    /// destructor
    ~CtrlVar();

    AllocatorDecl;

    virtual ExprType isA() const { return VAR_EXPR; }

    // capture the pointer
    void setNamePtr(CharString *newName) { name = newName; }

    CharString *cutNamePtr() { CharString *p = name; name = 0; return p; }

    /// copy the string
    void setName(const char *newName)
    {
      if ( !name )
        name = new CharString(newName);
      else
        *name = newName;
    }

    ///
    const CharString &getName() const { return name ? *name : shared_empty_name; }

    void setId(CtrlVarId newId) { id = newId;}
    CtrlVarId getId() const { return id; }

    // while parsing and using a userType class as declaration/parameter in a function inside the
    // class itself, the class is not yet completely known with all members. Therefore this method ensures
    // that the ClassVar, which this points to, matches the definition of the class
    void ensureClassInstance() const;

    ///
    Variable *getVar() const;

    /**
     * set the variable of this CtrlVar.
     * If this is not a reference var the variable will be grabbed and destroyed in the destructor.
     * If this is a reference var this call will set the variable the CtrlVar refers to and the
     * variable will not be destroyed in the destructor.
     */
    void setVar(Variable *newVar, CtrlThread *thread = nullptr);

    /**
     * Cut the variable. Never call this, if the CtrlVar will be used afterwards.
     * @returns NULL if this is a reference var.
     */
    Variable *cutVar();

    /// Get the next CtrlVar pointer, without check.
    CtrlVar *getNextVar() const {return (CtrlVar *) next;}

    ///
    void setNextVar(CtrlVar *theNext);

    /// Beispiel: int a = sin(180);   sin(180) ist der Initializer
    void setInitializer(CtrlExpr *newInit);

    ///
    CtrlExpr *getInitializer() const { return init; }

    CtrlExpr *cutInitializer() { CtrlExpr *ini = init; init = nullptr; return ini; }

    /// tells, if this CtrlVar is used as a reference-variable
    bool isReference() const { return (refTypeSpec.varType != NOTYPE_VAR); }

    /// tells, if this CtrlVar is constant (=read only)
    bool isConstant() const { return (flags & TQ_CONST); }

    /// tells, if this CtrlVar is an optional parameter in a function
    bool isOptional() const { return (flags & TQ_OPTIONAL); }

    /// tells, if this CtrlVar was declared as global (Manager-global)
    bool isGlobal() const { return (flags & TQ_GLOBAL); }

    /// tells, if this CtrlVar was declared as local
    bool isLocal() const { return (flags & TQ_LOCAL); }

    bool isStatic() const { return (flags & TQ_STATIC); }

    bool isReferenced() const { return (flags & TQ_REFERENCED); }

    /// tells, if this CtrlVar was declared private
    bool isPrivate() const { return (flags & TQ_PRIVATE); }

    /// tells, if this CtrlVar was declared protected
    bool isProtected() const { return (flags & TQ_PROTECTED); }

    /// tells, if this CtrlVar was declared public
    bool isPublic() const { return (flags & TQ_PUBLIC); }

    void setLocal() { if (!isGlobal()) flags |= TQ_LOCAL; }

    void setPrivate() { flags &= ~(TQ_PROTECTED | TQ_PUBLIC); flags |= TQ_PRIVATE; }

    void setProtected() { flags &= ~(TQ_PRIVATE | TQ_PUBLIC); flags |= TQ_PROTECTED; }

    void setPublic() { flags &= ~(TQ_PRIVATE | TQ_PROTECTED); flags |= TQ_PUBLIC; }

    void setGlobal() { flags |= TQ_GLOBAL; }

    void setConstant() { flags |= TQ_CONST; }

    void setOptional() { flags |= TQ_OPTIONAL; }

    // for copied vars from libraries to avoid ctrl_perf dump
    void avoidPerfDump() { flags &= ~TQ_OPTIONAL; }

    void setStatic() { flags |= TQ_STATIC; }

    void setReferenced() { flags |= TQ_REFERENCED; }

    /// tells, which referenceType
    VariableType getReferenceType() const { return refTypeSpec.varType; }
    const UserType *getReferenceUserType() const { return refTypeSpec.userType; }
    const TypeSpec &getReferenceTypeSpec() const { return refTypeSpec; }

    /// converts this to a non-reference-variable
    void convertToValue();

    const CtrlSment *execute(CtrlThread *thread) const;

    const Variable *evaluate(CtrlThread *thread) const;

    Variable *getTarget(CtrlThread *thread) const;

    virtual void writeTrace(CtrlThread *thread, bool writeValue = true) const;

    virtual CharString toString() const;

    virtual bool checkIntegrity(const CharString &location, CtrlThread *) const;

    /** dump the whole tree for code coverage analysis
        @param to output stream
      */
    virtual void dumpCoverageTree(std::ostream &to, CoverageAction action = DUMP) const;

    virtual bool lock(CtrlThread *t) const;
    virtual bool unlock(CtrlThread *t) const;
    virtual bool isLocked(CtrlThread *t) const;
    virtual CtrlThread *getCurrentThread(CtrlThread *t) const;

  private:
    // disable this method; only setNextVar() is used
    virtual void setNext(CtrlSment *theNext) { CtrlExpr::setNext(theNext); }

  private:
    static const CharString shared_empty_name;

    CharString *name;
    CtrlVarId id;
    CtrlExpr *init;
    Variable *var;
    Variable *referTo;    // if this is a reference-var and the type mismatches, referTo
                          // holds a pointer to the refered variable and a Variable of
                          // type refTypeSpec is created for var

    TypeSpec refTypeSpec;

    // synchronized access
    mutable CtrlThread *currentThread;
    mutable unsigned    lockCount;

    // type qualifiers, etc.
    int flags;
};

//------------------------------------------------------------------------------

inline Variable * CtrlVar::getVar() const
{
  if (var)
    return var;
  else
    return referTo;
}

//------------------------------------------------------------------------------

inline Variable * CtrlVar::cutVar()
{
  if (isReference())
    return 0;

  Variable *tmp = var;
  var = 0;
  return tmp;
}

//------------------------------------------------------------------------------

inline void CtrlVar::setNextVar(CtrlVar *theNext)
{
  next = theNext;

  if (init)
    init->setNext(theNext);
}

#ifdef WIN32
#pragma warning ( disable: 4231 )
#endif

#if defined (LIBS_AS_DLL)
  EXTERN_CTRL template class DLLEXP_CTRL SimplePtrArray<CtrlVar>;
#endif

#ifdef WIN32
#pragma warning ( default: 4231 )
#endif

#endif /* _CTRLVAR_H_ */
