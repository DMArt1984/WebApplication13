#ifndef _SHARED_LIB_H_
#define _SHARED_LIB_H_

#include <CharString.hxx>

class DynVar;

typedef int (*SharedLibraryFunction)(void);

/**
 * Allows loading shared libraries ('.dll'- or '.so'-files) during runtime
 * and calling their functions.
 */
class DLLEXP_BASICS SharedLib
{
public:

  /**
   * Calls the function @p fctName in the library @p libName with the parameters
   * @p in and @p out.
   * The library will be searched and loaded as described for SharedLib::load()
   * if it has not been loaded already.
   *
   * The called function is expected to take two parameters of type DynVar
   * and return a value of type @p int.
   *
   * @param libName The name of the library to use.
   * @param fctName The name of the function in the library.
   * @param in The first parameter passed to the called function.
   * @param out the second parameter passed to the called function.
   *
   * @return 0 on any errors (library not found, function not found),
   *         otherwise the return value of the called function.
   *
   * @remarks The called function should not return 0, since this value is
   *          already used by this function as error value.
   */
  static int userDefFunc(
    const char *libName,
    const char *fctName,
    DynVar &in,
    DynVar &out);

  /**
   * Loads the library with the specified name or filename.
   *
   * @remarks The OS-specific function for loading libraries is used,
   *          so if and where a library will be found depends on the
   *          operating system.
   *          The full path of the library file can be used to ensure
   *          that the library will be found. Use SharedLib::find()
   *          to locate libraries in the PVSS project '/bin' directory.
   *
   * @param libName The name or path of the library to be loaded.
   *
   * @retval true Library has been successfully loaded.
   * @retval false Library has not been loaded.
   */
  static bool load(const char *libName);

  /**
   * Returns whether the given library is loaded.
   *
   * @note Only valid for libraries loaded with SharedLib.
   *
   * @param libName The exact same name with which the library was loaded.
   */
  static bool isLoaded(const char *libName);

  /**
   * Unloads the library with the specified name.
   *
   * @param libName The exact same name with which the library was loaded.
   *
   * @retval true Library has been successfully unloaded.
   * @retval false Library was not found.
   */
  static bool unload(const char *libName);

  /**
   * Unloads all libraries that where loaded using SharedLib.
   */
  static void unloadAll();

  /**
   * Returns a function pointer to the function with the name @p fctName
   * in the library @p libName.
   * The library will be searched and loaded as described for SharedLib::load()
   * if it has not been loaded already.
   *
   * @param libName The name or path of the library to use.
   * @param fctName The name of the function in the library.
   * @param complain If true, errors will be written to ErrHdl
   *
   * @return If the function was found, a function pointer,
   *         otherwise (if the library or function was not found) a nullpointer.
   *
   * @code
   * // example code (without error handling)
   *
   * // get the function pointer
   * SharedLibraryFunction functionPtr = SharedLib::getFuncPtr("libssl", "SHA1", false);
   *
   * // cast the function pointer to the real signature
   * unsigned char * (*functionSHA1) (const unsigned char * d, unsigned long n, unsigned char * md) =
   *   (unsigned char* (*)(const unsigned char * d, unsigned long n, unsigned char * md)) functionPtr;
   *
   * // prepare input
   * const unsigned char *digest = 0;
   * const unsigned char *key = (const unsigned char *) "1234567890ABCDEF";
   * unsigned char *md = new unsigned char[20];
   *
   * // call function
   * digest = (*functionSHA1)(key, 16, md);
   * @endcode
   */
  static SharedLibraryFunction getFuncPtr(
    const char *libName,
    const char *fctName,
    bool complain = true);

  /**
   * Searches for a library with the specified name in the subdirectory 'bin'
   * of the PVSS project directory.
   *
   * If the library is not found under the specified name, it is searched
   * with the suffix '.dll' or '.so' appended.
   * If it is still not found, 'lib' will be prefixed in addition to the
   * suffixes.
   *
   * @param libBaseName The basename of the library (without path;
   *                    file extension optional), e.g. 'libssl.so.4',
   *                    'libssl.dll', 'libssl', '/bin/libssl.so.4'.
   *                    The file extension should be specified if it is not
   *                    one of '.dll' or '.so'.
   * @param os Only considered when the library was not found in the directory
   *           'bin' of the project directory. If false, an empty string will
   *           be returned, if true, the specified libBaseName suffixed with
   *           '.dll' or '.so' depending on the OS will be returned.
   *
   * @return If the library was found, the full path of the library, otherwise
   *         when os is specified as false, an empty string,
   *         or when os is true, the specified library name appended with
   *         '.dll' or '.so'.
   *
   * @remarks os == true allows the return value to be used afterwards in
   *          SharedLib::getFuncPtr() when the lib was not found in the
   *          PVSS bin directory.
   */
  static CharString find(const CharString &libBaseName, bool os = false);

  /**
    * Returns the name of a platform specific subdirectory, which
    * will also be used to look for a shared library (e.g. used in find())
   */
  static CharString getPlatformSubdir();

private:
  static class DynLibList *loadedLibs;
};

#endif
