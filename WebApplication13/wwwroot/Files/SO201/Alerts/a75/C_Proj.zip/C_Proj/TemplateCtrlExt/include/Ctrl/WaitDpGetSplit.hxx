/*  author VERANTWORTUNG: Andras Horvath                                            */
/** class handles the wait for a response of a splitted dpGetPeriod() and dpQuery() */

#ifndef _WAITDPGETSPLIT_H_
#define _WAITDPGETSPLIT_H_

#include <WaitDpGet.hxx>
#include <DynVar.hxx>

class IntegerVar;
class CtrlExpr;
class SplitTblEntry;

//--------------------------------------------------------------------------------

class DLLEXP_CTRL WaitDpGetSplit : public WaitDpGet
{
public:
  /** constructor for Splitted dpGet - command.
    *
    * @param theThread IN: thread der wartet bis antwort eintrifft.
    *                      thread wird nicht frei gegeben.
    * @param argList   IN: (deep copy) parameterliste
    * @paran dyn       IN: (deep copy) if dyn == 0, it means every arg is a non-dyn-type
    *                      else, the dyn must hold for every arg the number of items
    * @param asynch    IN:
    */
  WaitDpGetSplit(CtrlThread *theThread, ExprList *argList, DynVar *dyn = 0,
                 PVSSboolean asynch = PVSS_FALSE, SplitTblEntry* conn = 0);

  /// destructor 
  virtual ~WaitDpGetSplit();

  void dpGetPeriodResponse(DpMsgAnswer &msg);

  void dpQueryResponse(DpMsgAnswer &answer);

  // helper function for dpGetPeriodResponse
  static ErrClass* writeDpGetPeriodResponse(DpMsgAnswer &msg, CtrlThread* thread, ExprList* args, Variable *dynString, Variable *dynValue, Variable *dynTime, Variable *dynType, IntegerVar* progress, CtrlExpr *expr, bool clearArrays);

  // connect with the splitting table entry
  void setConnection(SplitTblEntry* conn);

  // return the value in the next call
  void setWaitNextAnswer(bool wait);

  // called on redu change
  PVSSboolean needRefresh();

  void waitQuery();
  void continueQuery();

  // IM118565: check if the ctrl thread still exists
  bool threadExists();

protected:

private:

  SplitTblEntry* connection;

  bool firstAnswer;
  bool needNextAnswer;
  bool clearArrays;
  bool waitStatus;
};

#endif /* _WAITDPGETSPLIT_H_ */
