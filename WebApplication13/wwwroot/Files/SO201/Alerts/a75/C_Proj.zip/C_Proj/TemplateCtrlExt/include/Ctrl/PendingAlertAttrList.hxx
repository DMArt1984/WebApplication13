#ifndef _PENDINGALERTATTRLIST_H_
#define _PENDINGALERTATTRLIST_H_


#include <AlertAttrList.hxx>

class DoneCB;


/*  author VERANTWORTUNG: Martin Koller*/
/** class holds an AlertAttrList for later use as input to a CtrlThread.
  Also it holds a pointer to a DoneCB object, which will be called, when this
  AlertAttrList was used in CtrlThread and the thread was fully executed.
*/
class DLLEXP_CTRL PendingAlertAttrList : public AlertAttrList
{
  public:
    /// 
    PendingAlertAttrList(const AlertAttrList &newList, DoneCB *done);
    ///
    ~PendingAlertAttrList();
    ///
    DoneCB *getDoneCB() const { return doneCB; }

  protected:

  private:
    DoneCB *doneCB;
};

#endif /* _PENDINGALERTATTRLIST_H_ */
