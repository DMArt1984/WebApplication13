#ifndef _CNSOBJECT_H_
#define _CNSOBJECT_H_

#include <PVSSBcm.hxx>
#include <SimplePtrArray.hxx>

#include <ostream>

// forward declaration
class CharString;
class LangText;
class CNSView;
class CNSTreeNode;

/**
 * Common base class for CNSView and CNSTree.
 * Used for sending a view or tree in a DpMsgManipCNS message.
 *
 * @internal
 */
class DLLEXP_DATAPOINT CNSObject
{
public:
  /// BCM stream input operator
  friend DLLEXP_DATAPOINT itcNdrUbReceive &operator>>(itcNdrUbReceive &from, CNSObject &obj);

  /// BCM stream output operator
  friend DLLEXP_DATAPOINT itcNdrUbSend &operator<<(itcNdrUbSend &to, const CNSObject &obj);

  enum CNSObjectType
  {
      CNS_VIEW = 0,
      CNS_TREE,
      CNS_TREE_NODE
  };

public:
  /// Constructor
  CNSObject() { }

  /// Destructor
  virtual ~CNSObject() { }

  /** Equality operator (virtual). 
      @return int 1 if the values are equal, otherwise 0.
  */
  virtual int operator==(const CNSObject &rVal) const = 0;
  
  /** Check if own type matches or is derived from a given type.
      @param type CNSObjectType to check.
      @return true if the type does match, false if the type does not match.
   */
  virtual bool isA(CNSObjectType type) const = 0;

  /// @return the CNSObjectType of the object.
  virtual CNSObjectType isA() const = 0;
  
  /**
   * Abstract BCM stream input method.
   * Has to be overridden by derived classes.
   */
  virtual void inNdrUb(itcNdrUbReceive &ndrStream) = 0;

  /**
   * Abstract BCM stream output method.
   * Has to be overridden by derived classes.
   */
  virtual void outNdrUb(itcNdrUbSend &ndrStream) const = 0;

  /**
   * Returns the view this tree belongs to.
   */
  virtual const CNSView *getView() const = 0;
  
  /**
   * Adds an existing tree node.
   * If the node is successfully added, the parent (a view or a tree) takes ownership of it.
   *
   * Empty pointers or nodes with existing names will not be added.
   *
   * @return True if the node was successfully added, otherwise false.
   */
  virtual bool addChild(CNSTreeNode *newChild) = 0;

public:
  /**
   * Comparator for derived classes. Compares the names of the items
   * (Item::getNamePtr()).
   * Can be used for sorted inserts into a SimplePtrArray.
   *
   * @retval -1 If a < b
   * @retval  0 If a == b
   * @retval  1 If a > b
   */
  template <class Item> static int compare(const Item *a, const Item *b);
  
  /// The debug function. Print out the contents according to format level (1 - 3)
  void debug(std::ostream &to, int level) const;
  
  /** The clone function is used to create an exact copy of the current object.
      Even if it is a CNSView the whole view with all its trees is cloned.
      This copy should be deleted after use.
      @return CNSObject* pointer to a newly cloned CNSObject (deep copy).
  */
  CNSObject *clone() const;

  /**
   * Returns the descendant element with the specified relative path,
   * or null if no such element was found.
   *
   * If the given path does not contain a path separator,
   * this method will act like getChild().
   *
   * Filesystem-like path segments such as '.' (current node) and
   * '..' (parent node) are not supported.
   * Examples for valid relative paths are: 'Tree1', 'Tree1.Node1', and so on.
   */
  CNSTreeNode *getDescendant(const char *relativePath);

  /**
   * Returns the descendant element with the specified relative path,
   * or null if no such element was found.
   *
   * If the given path does not contain a path separator,
   * this method will act like getChild().
   *
   * Filesystem-like path segments such as '.' (current node) and
   * '..' (parent node) are not supported.
   * Examples for valid relative paths are: 'Tree1', 'Tree1.Node1', and so on.
   */
  const CNSTreeNode *getDescendant(const char *relativePath) const;

  /** create a new CNSObject.
   * @param type the type of the CNSObjectType to be created.
   * @return the new allocated CNSObject. caller is responsible for freeing object.
   */
  static CNSObject *allocate(CNSObjectType type);
  
protected:
  /// Appends the second parameter to the first
  void appendDisplayPath(LangText &target, const LangText &source) const;

  /// Appends the second parameter to each language of the first parameter
  void appendDisplayPath(LangText &target, const char source) const;

private:
  /**
   * Helper method that delegates to the getChild() / getTree() method of the
   * appropriate type.
   */
  CNSTreeNode *getDirectDescendant(const char *childName);

  /**
   * Helper method that delegates to the getChild() / getTree() method of the
   * appropriate type.
   */
  const CNSTreeNode *getDirectDescendant(const char *childName) const;

};

//------------------------------------------------------------------------------
// to avoid warning C4251:
// 'DpMsgManipCNS::objs_' : class 'SimplePtrArray<Item>' needs to have dll-interface
#ifdef WIN32
  #pragma warning ( disable: 4231 )
#endif
#ifdef LIBS_AS_DLL
  EXTERN_DATAPOINT template class DLLEXP_DATAPOINT SimplePtrArray<CNSObject>;
#endif
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
// inline-methods:
//------------------------------------------------------------------------------

template <class Item>
int CNSObject::compare(const Item *a, const Item *b)
{
  if (a && b) // none are null
  {
    return(strcmp(a->getNamePtr(), b->getNamePtr()));
  }
  else // at least one is null (should not happen; implemented for completeness)
  {
    // COVINFO BLOCK: defensive (should not happen)
    if (a < b) { return -1; }
    if (a > b) { return 1; }

    return 0; // both are null => equal
    // COVINFO BLOCKEND
  }
}

#endif // _CNSOBJECT_H_
