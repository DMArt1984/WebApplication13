#ifndef _VIEWID_H_
#define _VIEWID_H_

#include <Types.hxx>

typedef PVSSulong ViewId;

#endif // _VIEWID_H_
