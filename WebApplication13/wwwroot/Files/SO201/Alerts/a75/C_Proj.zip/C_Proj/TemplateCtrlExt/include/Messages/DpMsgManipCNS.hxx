#ifndef _DPMSGMANIPCNS_H_
#define _DPMSGMANIPCNS_H_

#include <CNSPath.hxx>
#include <CNSView.hxx>

#include <DpMsg.hxx>

class CNSTree;
class CNSObject;
class CNSTreeNode;
class DpIdentificationProSystem;

class DLLEXP_MESSAGES DpMsgManipCNS : public DpMsg
{
  public:
    friend class UNIT_TEST_FRIEND_CLASS;    // ein Unit-Test braucht erweiterten zugriff auf diese Klasse

    /// global operator for sending DpMsgManipCNS via network
    friend DLLEXP_MESSAGES itcNdrUbSend &operator<<(itcNdrUbSend &ndrStream, const DpMsgManipCNS &msg);
    /// global operator for receiving DpMsgManipCNS via network
    friend DLLEXP_MESSAGES itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream, DpMsgManipCNS &msg);
 
    enum CNSActionType
    {
        NO_ACTION = 0,
        
        SYSTEM_NAMES,
        
        CREATE_VIEW,
        DELETE_VIEW,
        CHANGE_VIEW_NAMES,
        CHANGE_VIEW_SEPARATORS,

        CREATE_TREE,
        DELETE_TREE,
        CHANGE_TREE,
        ADD_TREE,
        
        CHANGE_NODE_NAMES,
        CHANGE_NODE_DATA
    };

  public:
    /// create a DP_MSG_CNS_REQ message.
    DpMsgManipCNS();

    /// create a DP_MSG_CNS_REQ or DP_MSG_MANIP_CNS message.
    DpMsgManipCNS(MsgType type);

    /// create a copy of this message
    DpMsgManipCNS(const DpMsgManipCNS &rVal);
    
    /// Destructor
    virtual ~DpMsgManipCNS();

  public:
    /// operator == (DpMsg Interface)
    virtual int operator==(const Msg &rVal) const;
    /// operator =  (DpMsg Interface)
    virtual Msg &operator=(const Msg &rVal);

    /// @return DP_MSG_CNS_REQ or DP_MSG_MANIP_CNS. The MsgType of this MSG (DpMsg Interface)
    virtual MsgType isA() const;
    
    /**
     * type or base type of this a message. (DpMsg Interface)
     * @param type IN. The type.
     * @return NO_MSG or the given MsgType. 
     * if NO_MSG ist returned the MSG is not of the given type and even not derived from the given type.
     * values for type that return the given type are: DP_MSG_CNS_REQ / DP_MSG_MANIP_CNS, DP_MSG, PVSS_MSG
     */     
    virtual MsgType isA(MsgType type) const;
    
    /**
      * allocate a new instance of DpMsgManipCNS. (DpMsg Interface)
      * The caller is responsible for freeing the object.
      */
    virtual Msg *allocate() const;
    
    /**
      * @return if PVSS_TRUE the sender expects a answer. (DpMsg Interface)
      * Note! 
      * for some messages the sender can decide if he wants an answer.
      * For DpMsgManipCNS the answer behaviour is fix coded. 
      * DP_MSG_CNS_REQ require an answer DP_MSG_MANIP_CNS do not.
      */
    virtual PVSSboolean needsAnswer() const;

    /**
      * @return the number of groups this msg is holding. (DpMsg Interface)
      * Note! 
      * one group is one CNSObject
      */
    virtual PVSSulong getNrOfGroups() const;
    
    /**
      * @return a DpIdentifier where only system is set. 
      * according to the system's CNS you want to change  (DpMsg Interface)
      */
    virtual DpIdentifier getGroupId(PVSSulong) const;

    /// write the msg to the stream "to" in human readable debug format (DpMsg Interface)
    virtual void debug(std::ostream &to, int level) const;

  public:
    /// change DP_MSG_CNS_REQ message to DP_MSG_MANIP_CNS
    void changeToManipMsg(ViewId id = 0);

    /// @return the user who has sent this message
    PVSSuserIdType getUserId() const;
    
    /// @return the action 
    CNSActionType getActType() const;
    
    /// @return the ID of the system you want to change with this message
    SystemNumType getSystem() const;
    
    /// @return the CNSView object sent by this message
    const CNSView &getView() const;
    
    /**
      * @return the CNSTree object sent by this message. 
      * If no tree is sent 0 is returned. the object is still owned by the message.
      */
    const CNSTree *getTree() const;

    /**
      * @return the CNSTree object sent by this message. 
      * If no tree is sent 0 is returned. the caller is responsible for freeing the object.
      */
    CNSTreeNode *cutTree();

    /**
      * @return the CNSDataIdentifier object sent by this message. 
      * Only in case of CNSActionType CHANGE_NODE_DATA this methode returns usefull data.
      * In all other cases an empty CNSDataIdentifier is returned
      */
    CNSDataIdentifier getDataIdentifier() const;
    
    /**
      * @return the CNSNodeNames object sent by this message. 
      * Only in case of CNSActionType CHANGE_NODE_NAMES this methode returns usefull data.
      * In all other cases an empty CNSNodeNames object is returned
      */
    CNSNodeNames getNodeNames() const;

    /**
      * @return the LangText object sent by this message. 
      * Only in case of CNSActionType SYSTEM_NAMES this methode returns usefull data.
      * In all other cases an empty LangText is returned
      */
    LangText getDisplayNames() const;

    /**
      * @return the ViewId of the View deleted/created/modified by this message. 
      * this methode returns usefull data for all CNSActionType's but SYSTEM_NAMES and NO_ACTION.
      * Note! for a CREATE_VIEW message ViewId is 0 to indicate that 
      * the next free ViewId should be used for this new View.
      */
    ViewId getViewId() const;

    /**
      * @return the CNSDataIdentifier object sent by this message. 
      * Only in case of CNSActionType CHANGE_NODE_DATA this methode returns usefull data.
      * In all other cases an empty CNSDataIdentifier is returned
      */
    CNSPath getPath() const;    

  public:
    /// set the ViewId of the message to id. (used by data)
    void setViewId(ViewId id);
      
  public:
    /**
     * set CNS display names for a system.
     * @param sys   IN. The system.
     * @param names IN. The dsplay names of the system.
     * @param user  IN. The user calling this method.
     */
    PVSSboolean setSystemNames(SystemNumType sys, const LangText &names, PVSSuserIdType user);

    /**
     * delete a view.
     * @param sys  IN. The system of the view.
     * @param view IN. The the view (not part of CNSContainer) containing the new data
     * @param user IN. The user calling this method.
     */
    PVSSboolean deleteView(SystemNumType sys, ViewId view, PVSSuserIdType user);
    /**
     * create a new view for a specified system.
     * @param sys  IN. The system of the view.
     * @param view IN. The the view to be created. It is not part of CNSContainer and contains the new data
     * @param user IN. The user calling this method.
     */
    PVSSboolean createView(SystemNumType sys, const CNSView &view, PVSSuserIdType user);
    /**
     * Changes the names accordingly to the content of view. 
     * the view is addressed by viewId of view
     * @param sys  IN. The system of the view.
     * @param view IN. The id of the view.
     * @param names IN. The new names of the view.
     * @param user IN. The user calling this method.
     */
    PVSSboolean changeViewNames(SystemNumType sys, ViewId view, const CNSNodeNames &names, PVSSuserIdType user);
    /**
     * Changes the separator of the specified view.
     * @param sys  IN. The system of the view.
     * @param view IN. The id of the view.
     * @param separators IN. The new display separators of the view.
     * @param user IN. The user calling this method.
     */
    PVSSboolean changeViewSeparators(SystemNumType sys, ViewId view,
                                     const LangText &separators, PVSSuserIdType user);
    /**
     * Adds a tree to the given view. The tree may consist of
     * a single specified node.
     * @param sys  IN. The system of the view.
     * @param view IN. The the view where the tree should be created.
     * @param tree IN. The new tree (not part of CNSContainer) that should be created.
     * @param user IN. The user calling this method.
     */
    PVSSboolean createTree(SystemNumType sys, ViewId view, CNSTree *tree, PVSSuserIdType user);
    /**
     * deletes a (sub-)tree. The given node all all its children are deleted.
     * @param node    IN. The node of the CNSContainer.
     * @param user    IN. The user calling this method.
     */
    PVSSboolean deleteTree(const CNSTree &node, PVSSuserIdType user);
    /**
     * Adds a (sub-)tree below the given parent node. The tree may consist of
     * a single node.
     * @param parent  IN. The node of the CNSContainer that should get newTree as child.
     * @param newTree IN. The new tree (not part of CNSContainer) that should be added.
     * @param user    IN. The user calling this method.
     */
    PVSSboolean addTree(const CNSTreeNode &parent, CNSTree *newTree, PVSSuserIdType user);
    /**
     * Deletes the specified tree del and instead attaches the tree newTree.
     * @param del     IN. The tree of the CNSContainer that should be deleted.
     * @param newTree IN. The new tree (not part of CNSContainer) that should be added.
     * @param user    IN. The user calling this method.
     */
    PVSSboolean changeTree(const CNSTreeNode &del, CNSTree *newTree, PVSSuserIdType user);
        
    /**
     * Changes the contents (CNSDataIdentifier, CNSNodeNames) of the
     * given node.
     * @param node  IN. The node of the CNSContainer that should be changed.
     * @param data  IN. The new data that should be assigned.
     * @param names IN. The new names that should be assigned.
     * @param user  IN. The user calling this method.
     */
    PVSSboolean changeNode(const CNSTreeNode &node, const CNSDataIdentifier &data, PVSSuserIdType user);
    PVSSboolean changeNode(const CNSTreeNode &node, const CNSNodeNames &names, PVSSuserIdType user);
    
  public:
    /// convert CNSActionType numer to a string 
    static const char *debugCNSActionType(CNSActionType type);
    
  protected:
    /// implements receiving of ths message via network (DpMsg Interface)
    virtual void inNdrUb(itcNdrUbReceive &ndrStream);

    /// implements sending of ths message via network (DpMsg Interface)
    virtual void outNdrUb(itcNdrUbSend &ndrStream) const;

  private:
    // get the DpIdentification of the system of the CSObject
    const DpIdentificationProSystem *getDpIdentificationProSystem(const CNSView *v, const char *obj, bool silent = false) const;    

  private:
    SystemNumType   sys_;
    CNSActionType   what_;
    PVSSuserIdType  user_;

    CharString cnsPath_;
    SimplePtrArray<CNSObject> objs_;
    bool request_;
};

// ================================================================================
// Inline-Funktionen :
// ================================================================================
inline PVSSuserIdType DpMsgManipCNS::getUserId() const 
{ 
  return(user_); 
}    

// --------------------------------------------------------------------------------
// --
// --------------------------------------------------------------------------------
inline DpMsgManipCNS::CNSActionType DpMsgManipCNS::getActType() const
{ 
  return(what_); 
}

// --------------------------------------------------------------------------------
// --
// --------------------------------------------------------------------------------
inline SystemNumType DpMsgManipCNS::getSystem() const
{
  return(sys_);
}

#endif /* _DpMsgManipCNS_H_ */
