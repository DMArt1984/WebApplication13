#ifndef _DPSMOOTHAUX_H_
#define _DPSMOOTHAUX_H_

// Vorwaerts-Deklaration der Eigenen Klasse
class DpSmoothAux;

// System-Include-Files
#include <DpConvSmoothContainer.hxx>

// Vorwaerts-Deklarationen :
class DpConfig;

// ========== DpSmoothAux ============================================================

/** The class derived from the abstract DpConvSmoothContainer.
    This class enables to create an instance of DpConvSmoothContainer object.
    @classification ETM internal  
  */
class DLLEXP_CONFIGS DpSmoothAux : public DpConvSmoothContainer 
{
public:

  /// constructor, initialisation with zero values
  DpSmoothAux();

  /// destructor
  ~DpSmoothAux();

  /// non virtual assignment operator for DpSmoothAux
  /// @param rVal the DpSmoothAux to assign
  /// @return the resulting DpSmoothAux
  DpSmoothAux &operator=(const DpSmoothAux &rVal)
    { DpConvSmoothContainer::operator=((const DpConvSmoothContainer &) rVal); return *this; }

	/// check if own DP config type matches other DP config type
  /// @param conf the DpConfigType to check
  /// @return matching DpConfigType
  virtual DpConfigType isA(DpConfigType conf) const;

  /// return type of DP config
  virtual DpConfigNrType getDpConfigNrUncached() const;

  /// allocate new DpSmoothAux
  /// @return the new DpSmoothAux
  virtual DpConfig *allocate() const;

  // Generierte Methoden :
protected:
private:

// ............................Anfang User-Attribut-Definitionen...................
public:

  /// return type of DP config
	virtual DpConfigType isA() const;

  /// return size of DP config
  virtual unsigned long sizeOf() const;

// .............................Ende User-Attribut-Definitionen....................
};

// ================================================================================
// Inline-Funktionen :

// ............................Anfang User-Inlines.................................
inline unsigned long DpSmoothAux::sizeOf() const
{
  return sizeof(DpSmoothAux);
}
// .............................Ende User-Inlines..................................

#endif /* _DPSMOOTHAUX_H_ */
