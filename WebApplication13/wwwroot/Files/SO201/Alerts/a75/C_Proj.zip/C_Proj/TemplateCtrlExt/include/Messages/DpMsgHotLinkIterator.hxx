#ifndef _DPMSGHOTLINKITERATOR_H_
#define _DPMSGHOTLINKITERATOR_H_

#include <MsgGroupIterator.hxx>

#include <DpHLGroup.hxx>

// forward declarations
class DpVCItem;


/**
 * A MsgGroupIterator-implementation for DpMsgHotLink.
 *
 * Some implementation properties:
 * - The iterator does not receive the message as a whole; only a single group.
 *   This implies that the iterator will never have more than a single group.
 *   Thus, when removeCurrentGroup() is called, it cannot remove anything,
 *   it just acts like an empty iterator.
 * - Items of a group in the message may belong to multiple DPEs.
 * - Calling getFirst() / getNext() changes the internal cursor of the group.
 *
 * @internal
 */
class DLLEXP_MESSAGES DpMsgHotLinkIterator : public MsgGroupIterator
{
public:
  DpMsgHotLinkIterator(DpHLGroup &group);

  virtual ~DpMsgHotLinkIterator() { delete copyGroup_; }

  virtual bool getFirstGroup() const;

  virtual bool getNextGroup() const;

  virtual const DpIdentifier *getFirst() const;

  virtual const DpIdentifier *getNext() const;

  virtual const DpIdentifier *getCurrent() const;

  /**
   * We only use a single group, so we can't remove a group.
   * So we just set a flag to act like an empty iterator.
   */
  virtual bool removeCurrentGroup(ErrClass *errorPtr = 0);

  /**
   * Returns the value at the current position.
   */
  virtual const Variable *getCurrentValue() const;

  /**
   * Returns the value at the current position. Might be changed in place.
   * Because other users might receive the same hotlink group, we cannot
   * directly modify the hotlink group, so it will be copied on the first call
   * of getCurrentValue() or replaceCurrentValue().
   *
   * If you only want to read the value, and not change it, please use the const
   * version of this method.
   */
  virtual Variable *getCurrentValue();

  /**
   * Replaces the value at the current position.
   * Because other users might receive the same hotlink group, we cannot
   * directly modify the hotlink group, so it will be copied on the first call
   * of getCurrentValue() or replaceCurrentValue().
   */
  virtual bool replaceCurrentValue(Variable *newValue);

  virtual bool hasSameDpePerGroup() const { return false; }

  /**
   * Returns the copied hotlink group, or null if no copy has been made.
   * Do not delete the returned pointer, it belongs to the iterator object.
   */
  DpHLGroup *getCopyGroup() { return copyGroup_; }

  /**
   * Returns true when removeCurrentGroup() has been called.
   */
  bool isEmpty() const { return isEmpty_; }

private:
  // avoid copy construction and copy assignment
  DpMsgHotLinkIterator(const DpMsgHotLinkIterator &);
  DpMsgHotLinkIterator &operator=(const DpMsgHotLinkIterator &);

  /**
   * If copyGroup_ is not yet created, copy the hotlink group to copyGroup_ and
   * set group_ to the newly created copy.
   * Does nothing when copyGroup_ already exists.
   */
  void copyOnWrite();

// members
  mutable DpHLGroup *group_;
  mutable DpVCItem *currentItem_;

  // The index of the current item. Necessary to transfer the position from
  // the old to the new group in copyOnWrite().
  mutable unsigned int currentIdx_;

  // when getCurrentValue() or replaceCurrentValue() are used, the group will be
  // copied to avoid changing the hotlinks of other users.
  DpHLGroup *copyGroup_;

  // this value is true after removeCurrentGroup() has been called
  bool isEmpty_;

};


#endif // _DPMSGHOTLINKITERATOR_H_
