#ifndef _QUALITYCODE_H_
#define _QUALITYCODE_H_

#ifndef _TYPES_HXX_
#include <Types.hxx>
#endif

#include <IntegerVar.hxx>

/// The quality code representation inspired by OPC DA and Profibus PA
typedef uint16_t QualityCode_t;

// field separators - mask & shift constans
const uint16_t QC_FLAGMASK = 0xF000;
const uint16_t QC_EXTMASK  = 0x0F00;
const uint16_t QC_QMASK    = 0x00C0;
const uint16_t QC_SUBMASK  = 0x003C;
const uint16_t QC_LIMMASK  = 0x0003;

const uint16_t QC_FLAGSHIFT = 12;
const uint16_t QC_EXTSHIFT  =  8;
const uint16_t QC_QSHIFT    =  6;
const uint16_t QC_SUBSHIFT  =  2;
const uint16_t QC_LIMSHIFT  =  0;

const uint16_t QC_SOURCETIMEBIT    = 0x2000;
const uint16_t QC_SOURCEQUALITYBIT = 0x1000;

/** This is a set of functions to access the quality code items.
  * The class defines constants and static access functions.
*/
class QualityCode
{
  friend class UNIT_TEST_FRIEND_CLASS;

public:

  /// Profibus PA Quality code 
  enum Quality {
    QCQ_BAD = 0,
    QCQ_UNCERTAIN,
    QCQ_GOOD,
    QCQ_GOOD_C,
  };

  /// Profibus PA Quality Substatus code 
  enum SubStatus {
    // sub status for BAD quality
    QCS_B_NON_SPECIFIC = 0,
    QCS_B_CONFIG_ERROR,
    QCS_B_NOT_CONNECTED,
    QCS_B_DEVICE_FAILURE,
    QCS_B_SENSOR_FAILURE,
    QCS_B_NO_COMM_VALUE_OK,
    QCS_B_NO_COMM_NO_VALUE,
    QCS_B_OUT_OF_SERVICE,
    QCS_B_RESERVED_8,
    QCS_B_RESERVED_9,
    QCS_B_RESERVED_10,
    QCS_B_RESERVED_11,
    QCS_B_RESERVED_12,
    QCS_B_RESERVED_13,
    QCS_B_RESERVED_14,
    QCS_B_RESERVED_15,

    // sub status for UNCERTAIN quality
    QCS_U_NON_SPECIFIC = 0,
    QCS_U_LAST_VALUE_OK,
    QCS_U_SUBSTITUTE_VALUE,
    QCS_U_INITIAL_VALUE,
    QCS_U_SENSOR_CONVERSION,
    QCS_U_ENGINEERING_UNIT_VIOLATION,
    QCS_U_SUB_NORMAL,
    QCS_U_CONFIG_ERROR,
    QCS_U_SIMULATED_VALUE,
    QCS_U_SENSOR_CALIBRATION,
    QCS_U_RESERVED_10,
    QCS_U_RESERVED_11,
    QCS_U_RESERVED_12,
    QCS_U_RESERVED_13,
    QCS_U_RESERVED_14,
    QCS_U_RESERVED_15,

    // sub status for GOOD quality
    QCS_G_OK = 0,
    QCS_G_UPDATE_EVENT,
    QCS_G_ADVISORY_ALARM,
    QCS_G_CRITICAL_ALARM,
    QCS_G_UNACK_UPDATE_EVENT,
    QCS_G_UNACK_ADVISORY_ALARM,
    QCS_G_UNACK_CRITICAL_ALARM,
    QCS_G_RESERVED_7,
    QCS_G_INIT_FAILSAFE,
    QCS_G_MAINTENANCE_REQUIRED,
    QCS_G_RESERVED_10,
    QCS_G_RESERVED_11,
    QCS_G_RESERVED_12,
    QCS_G_RESERVED_13,
    QCS_G_RESERVED_14,
    QCS_G_RESERVED_15,

    // sub status for GOOD cascade 
    QCS_C_OK = 0,
    QCS_C_INIT_ACKED,
    QCS_C_INITREQ,
    QCS_C_NOT_INVITED,
    QCS_C_RESERVED_4,
    QCS_C_DO_NOT_SELECT,
    QCS_C_LOCAL_OVERRIDE,
    QCS_C_RESERVED_7,
    QCS_C_INIT_FAILSAFE,
    QCS_C_RESERVED_9,
    QCS_C_RESERVED_10,
    QCS_C_RESERVED_11,
    QCS_C_RESERVED_12,
    QCS_C_RESERVED_13,
    QCS_C_RESERVED_14,
    QCS_C_RESERVED_15,
  };

  /// Profibus PA Limits code 
  enum Limits {
    QCL_OK = 0,
    QCL_LOW_FAULT,
    QCL_HIGH_FAULT,
    QCL_CONSTANT,
  };

  /// IL RT Quality Extended Substatus code 
  enum ExtendedStatus {
    // extended sub status for BAD quality
    QCE_B_NON_SPECIFIC = 0,
    QCE_B_LOGGING_DISABLED,

    // extended sub status for UNCERTAIN quality
    QCE_U_NON_SPECIFIC = 0,
    QCE_U_CALCULATED,

    // extended sub status for GOOD quality
    QCE_G_NON_SPECIFIC = 0,
    QCE_G_CALCULATED,
    QCE_G_MANUAL,
    QCE_G_CORRECTED,
  };

  /// QualityCode Constructor - init data with BAD - UNKNOWN
  QualityCode()                           { data = 0; }
  /// QualityCode Constructor - init with given quality code
  QualityCode(QualityCode_t init)         { data = init; }
  /// QualityCode Constructur - init with given Variable, this is used in the CHROM Facade
  QualityCode(const Variable &var)              
  { 
    IntegerVar ivar;
    ivar = var;
    data = ivar.getValue();
  }

  /// Assign operator.
  QualityCode &operator=( const QualityCode &qc) 
  { 
    data = qc.data;
    return *this; 
  }

  QualityCode &operator=( const Variable &var) 
  { 
    IntegerVar ivar;
    ivar = var;
    data = ivar.getValue();
    return *this;
  }

  bool operator==(const QualityCode &qc) const
  {
    return (this->data == qc.data);
  }

  /// set the "time from source"  flag
  void setSourceTimeFlag()                 { data |= QC_SOURCETIMEBIT; }
  /// clear the "time from source"  flag
  void clearSourceTimeFlag()              { data &= (QC_SOURCETIMEBIT ^ 0xFFFF); }

  /// set the "quality from source" flag
  void setSourceQualityFlag()             { data |= QC_SOURCEQUALITYBIT; }
  /// clear the "quality from source" flag
  void clearSourceQualityFlag()           { data &= (QC_SOURCEQUALITYBIT ^ 0xFFFF); }

  uint16_t        getFlags()              const { return ( data & QC_FLAGMASK); }
  uint16_t        getQualityBits()        const { return ( data & QC_QMASK); }
  uint16_t        getExtendedStatusBits() const { return ( data & QC_EXTMASK); }
  uint16_t        getSubStatusBits()      const { return ( data & QC_SUBMASK); }
  uint16_t        getLimitBits()          const { return ( data & QC_LIMMASK); }

  uint16_t        getSourceQualityFlag()  const { return (( data & QC_SOURCEQUALITYBIT ) >> QC_FLAGSHIFT); }
  uint16_t        getSourceTimeFlag()     const { return (( data & QC_SOURCETIMEBIT ) >> (QC_FLAGSHIFT + 1)); }

  Limits          getLimitCode()          const { return (Limits)         (( data & QC_LIMMASK ) >> QC_LIMSHIFT); }
  Quality         getQualityCode()        const { return (Quality)        (( data & QC_QMASK ) >> QC_QSHIFT); }
  SubStatus       getSubStatusCode()      const { return (SubStatus)      (( data & QC_SUBMASK ) >> QC_SUBSHIFT); }
  ExtendedStatus  getExtendedStatusCode() const { return (ExtendedStatus) (( data & QC_EXTMASK ) >> QC_EXTSHIFT); }

  void            setLimitCode(Limits l)                  
                                          { data &= (QC_LIMMASK ^ 0xFFFF); data |= ( (l << QC_LIMSHIFT) & QC_LIMMASK ); }
  void            setQualityCode(Quality q)               
                                          { data &= (QC_QMASK ^ 0xFFFF); data |= ( (q << QC_QSHIFT) & QC_QMASK ); }
  void            setSubStatusCode(SubStatus s)           
                                          { data &= (QC_SUBMASK ^ 0xFFFF); data |= ( (s << QC_SUBSHIFT) & QC_SUBMASK ); }
  void            setExtendedStatusCode(ExtendedStatus e) 
                                          { data &= (QC_EXTMASK ^ 0xFFFF); data |= ( (e << QC_EXTSHIFT) & QC_EXTMASK ); }

  /// get 16 bit quality code
  QualityCode_t   getValue() const { return data; }
  /// get 8 bit Profibus PA compatible part of quality code 
  QualityCode_t   getPAQuality() const { return data & 0xFF; }

private:

  QualityCode_t data;

};

#endif /* _QUALITYCODE_H_ */

