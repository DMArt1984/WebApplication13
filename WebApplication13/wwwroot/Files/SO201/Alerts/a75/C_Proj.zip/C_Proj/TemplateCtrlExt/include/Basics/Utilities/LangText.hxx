// DATEIBESCHREIBUNG ==============================================================
// VERANTWORTUNG: Martin Koller
// BESCHREIBUNG: generic object for storing language-dependent strings

#ifndef _LANGTEXT_H_
#define _LANGTEXT_H_

// System-Include-Files
#include <iostream>

#include <string.h>

#ifndef _CHARSTRING_H_
#include <CharString.hxx>
#endif

#ifndef _RESOURCES_H_
#include <Resources.hxx>
#endif

class itcNdrUbSend;
class itcNdrUbReceive;

// Fuer Sprachen, die nicht im config gelistet sind
class DLLEXP_BASICS LangTextItem
{
  public:
    GlobalLanguageIdType idx;
    CharString text;
};

// ========== LangText ============================================================
/** the language dependent text class. this class is designed to manage language dependent strings.
    the number of strings in one object depends on the parametrisation of the PVSS-II database.
*/
class DLLEXP_BASICS LangText
{
friend class UNIT_TEST_FRIEND_CLASS;
friend class LangTextParser;

public:
  /** constructor; initializes every language with empty text
  */
  LangText();

  /** constructor; initializes every language with text
  */
  LangText(const CharString &text);

  /** copy constructor
  */
  LangText(const LangText &newLangText);

  /** destructor
  */
  ~LangText();

  /** assignment operator
  */
  const LangText &operator=(const LangText &newLangText);
  /** comparison operator; checks each language
  */
  int operator==(const LangText &compLangText) const;
  /** comparison operator implemented as ( ! == )
  */
  int operator!=(const LangText &compLangText) const;
  /** comparision operator; compares only active language
      Note that the texts are technically sorted and not locale aware.
  */
  int operator<(const LangText &compLangText) const;
  /** cast to access the string table
  */
  operator const char**() const;

  /** check if the langtext is fully ident with the local one
    @param text to be compared
    @return TRUE or FALSE
  */
  int isFullIdent(const LangText &compLangText) const ;
  /** check if there are any equalities between the given langtext and the local one
    @param text to be compared
    @return TRUE or FALSE
  */
  int isPartIdent(const LangText &compLangText) const ;

  /** check if the langtext is empty
    * @return true of false
    */
  bool isEmpty() const;

  /** check if a string is contained in the local langtext
    @param text to be compared
    @return TRUE or FALSE
  */
  int contains(const CharString &text) const;

  /**streaming operators
  */
  friend DLLEXP_BASICS std::istream &operator>>(std::istream &from, LangText &langText);
  friend DLLEXP_BASICS std::ostream &operator<<(std::ostream &to, const LangText &langText);
  friend DLLEXP_BASICS itcNdrUbReceive &operator>>(itcNdrUbReceive &from, LangText &langText);
  friend DLLEXP_BASICS itcNdrUbSend &operator<<(itcNdrUbSend &to, const LangText &langText);

  /** return the number of languages
    @return lang count
  */
  LanguageIdType getNoOfLanguages() const;

  /** initialize every language with a given text
    @param text this string will be used to init each language
  */
  void setupLangTexts(const CharString &text = "");

  /** set the text for a specific language
  */
  void setText(LanguageIdType lang, const CharString &text);

  /** set the text for the active language only
    @param text init string for current language
  */
  void setText(const CharString &text);

  /** set text for a specific language (identify by GlobalLanguageID)
    @param lang global lang id
    @param text new text for lang
    @param append third parameter specifies if a new language shall be appended
  */
  void setTextByGlobalId(GlobalLanguageIdType lang, const CharString &text,
               PVSSboolean append = PVSS_FALSE);

  /** set text
    @param namePtrs new text
  */
  void setText(char const * const *namePtrs);

  /** get the text for a specific language
    @param lang local id of required lang
    @return text
  */
  const CharString &getText(LanguageIdType lang) const;
  /** get the text for the current language
    @return text
  */
  const CharString &getText() const;
  /** get the text for a specific language (identify by GlobalLanguageID).
    @param lang global id of required lang
    @return text
  */
  const CharString &getTextByGlobalId(GlobalLanguageIdType lang) const;

  /** test, if this object contains text for GlobalLanguageIdType lang
    @param lang checked id
  */
  bool hasGlobalId(GlobalLanguageIdType lang) const;

  /** remove a language not in the config file
    @param lang global id to be removed
  */
  void  removeLang(GlobalLanguageIdType lang);

  /** return the number of language strings stored but not defined in the current project
    @return lang count
  */
  unsigned getNumOfOtherLangs() const { return nofOtherLanguages; }

  /** return one of the extra strings stored (idx = 0 .. getNumOfOtherLangs()-1)
    @param idx language index
    @param lang returns the PVSS global language this entry represents
  */
  CharString getOtherText(unsigned idx, GlobalLanguageIdType &lang) const;

private:
  CharString *texts;
  static CharString emptyText;

  LangTextItem **otherLanguages;
  unsigned       nofOtherLanguages;

  mutable const char** charPtr;

  enum { KEEP_OTHERS, DEL_OTHERS };  // otherLanguageTexts
  int initTexts(int delOtherLangs = DEL_OTHERS);
};

#endif /* _LANGTEXT_H_ */
