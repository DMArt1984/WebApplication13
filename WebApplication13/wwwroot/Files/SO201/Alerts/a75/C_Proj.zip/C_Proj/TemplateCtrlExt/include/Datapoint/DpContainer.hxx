#ifndef _DPCONTAINER_H_
#define _DPCONTAINER_H_

// DATEIBESCHREIBUNG ==============================================================
// DATEINAME:     DpContainer.hxx
// VERANTWORTUNG: Johannes Ertl
// BESCHREIBUNG:  Dieser DpContainer enthaelt mehrere Datenpunkte, jeder Manager
//                hat soeinen fuer die Systemweiten Datenpunkte. Theoretisch
//                kann aber ein Manager fuer seinen privaten gebrauch einen
//                zweiten DpContainer anlegen.
//
//
//   23.02.02     Memory Optimierung (SimplePtrArray)   Martin Koller
// ======================================Ende======================================

#ifndef _DATAPOINT_H_
#include <Datapoint.hxx>
#endif

#ifndef _DPTYPES_H_
#include <DpTypes.hxx>
#endif

#include <DynPtrArray.hxx>

#ifdef WIN32
#pragma warning ( disable: 4231 )
#endif

#if defined(LIBS_AS_DLL)
  EXTERN_DATAPOINT  template  class DLLEXP_DATAPOINT  DynPtrArray<Datapoint>;
#endif

#ifdef WIN32
#pragma warning ( default: 4231 )
#endif

/** Datapoint container.
    Each Manager has an instance of this class for system-wide datapoints, but it may create other instances for its own use.
*/
class DLLEXP_DATAPOINT DpContainer
{
  public:
    /// Initial datapoint ID.
    static const DpIdType INIT_DP_ID;

    DpContainer() { datapointList.setCompareFunction(compareDatapoint); }
    /** Insert new datapoint.
        @param dpId Datapoint ID.
        @param dpType Type ID.
        @retval Returns PVSS_TRUE on success. Returns PVSS_FALSE if datapoint already exists.
        */
    PVSSboolean insertDatapoint(DpIdType dpId, DpTypeId dpType);

    /** Insert new datapoint.
        @param dpId Datapoint ID.
        @param dpType Type ID.
        @param[out] dp After return this pointer is set to the new Datapoint object. If the datapoint object already exists, this pointer is set to that existing object.
        @retval Returns PVSS_TRUE on success. Returns PVSS_FALSE if datapoint already exists.
        */
    PVSSboolean insertDatapoint(DpIdType dpId, DpTypeId dpType, Datapoint *&dp);

    /// Get the datapoint with the specified ID.
    Datapoint *getDatapoint(DpIdType dpId) const;

    /** Process datapoints.
        @param Process Pointer to processing function. This function is called for every existing datapoint.
        */
    void visitEveryDatapoint(PVSSboolean (*Process) (const Datapoint&)) const;

    /// Delete the datapoint with the specified ID.
    PVSSboolean deleteDatapoint(DpIdType dpId);

    /** Optimize the container.
        All empty datapoints (those which don't have any elements) will be deleted.
        @param elementOptimize If set to PVSS_TRUE, all datapoints are optimized.
        @retval Returns PVSS_TRUE if some of the datapoints were optimized.
        */
    PVSSboolean optimize(PVSSboolean elementOptimize);

    /// Get the number of datapoints in this container.
    unsigned int getNumberOfDps() const { return datapointList.getNumberOfItems(); }

  private:
    static int  compareDatapoint(const Datapoint *x, const Datapoint *y);

    DynPtrArray<Datapoint> datapointList;
};

#endif /* _DPCONTAINER_H_ */
