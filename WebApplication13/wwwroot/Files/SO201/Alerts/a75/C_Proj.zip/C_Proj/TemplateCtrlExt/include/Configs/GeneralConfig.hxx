// DATEIBESCHREIBUNG ==============================================================
// DATEINAME:     GeneralConfig.hxx
// VERANTWORTUNG:	Laszlo Szakony
// 
// BESCHREIBUNG:	Dieses Config ist eine 'allgemeine Config, das alle
// 		            Attributen speichern und wiedergeben kann. 
//                  
// 
//
// AENDERUNGS-HISTORIE
// Ver.  | Datum      | Aenderungen                            | ModNr.| Autor
// ------+------------+-----------------Anfang-----------------+-------+-----------
//   1.0 |            | 1.Erstellung mit Westmount-OMT         |     0 |
// ======================================Ende======================================
#ifndef _GENERALCONFIG_H_
#define _GENERALCONFIG_H_

// Vorwaerts-Deklaration der Eigenen Klasse
class GeneralConfig;

// System-Include-Files
#include <DpTypes.hxx>
#include <DpConfig.hxx>
#include <DpConfigNrType.hxx>
#include <SimplePtrArray.hxx>
#include <PVSSBcm.hxx>

// Vorwaerts-Deklarationen :
class GeneralConfig;
class Variable;

// ========== GeneralConfig ============================================================
/** The helper class to store all attributes internally in the array. The array is sorted based
 *  on detail and attribute numbers.
 */
class DLLEXP_CONFIGS GeneralAttribute {
public:
    /** Method compares two instances. Both detail number and attribute number are compared :
     *  - 0 : The instances have the same detail number and attribute number of both is ATTR_TYPE or
     *      the instances have the different detail number but attribute number of both is ATTR_TYPE or
     *      both arguments are NULL.
     *  - 1 : The instances have the same detail number, the attribute number of first instance is ATTR_TYPE and the second instance has some other attribute or
     *      The first argument is NULL.
     *  - -1: The instances have the same detail number, the attribute number of second instance is ATTR_TYPE and the first instance has some other attribute or
     *      The second argument is NULL.
     *  - num: If both instances has different detail number
     *  
     *  @param p1   A pointer to the GeneralAttribute instance
     *  @param p2   A pointer to the GeneralAttribute instance
     *  @return A value from the range <-1,0,1>
     */
    static int compareDetailAndAttr(const GeneralAttribute *p1, const GeneralAttribute *p2);

        /** Method compares two instances. Only detail number is compared :
     *  0 : The instances have the same detail number 
     *      both arguments are NULL.
     *  1 : The first argument is NULL.
     * -1 : The second argument is NULL.
     * num: If both instances has different detail number
     *  
     *  @param p1   A pointer to the GeneralAttribute instance
     *  @param p2   A pointer to the GeneralAttribute instance
     *  @return A value from the range <-1,0,1>
     */
    static int compareDetailOnly(const GeneralAttribute *p1, const GeneralAttribute *p2);

    /// Default constructor
    GeneralAttribute() {detailNr  = DpDetailNrType(0), 
                        attrNr    = DpAttributeNrType(0),
                        varPtr    = 0;
    };

    /** Full initialization constructor. It allows to specify both detail and attribute numbers along with the attribute value.
        @param detNr Detail number.
        @param atNr Attribute number.
        @param var A variable reference.
     */
    GeneralAttribute(DpDetailNrType detNr, DpAttributeNrType atNr, const Variable &var) {
                        detailNr  = detNr; 
                        attrNr    = atNr;
                        if ((varPtr = var.allocate()) != 0)
                            *varPtr   = var;
    };

    /** Partially initialization constructor. It allows to specify both detail and attribute numbers. The attribute value pointer is reset.
        @param detNr Detail number.
        @param atNr Attribute number.
     */
    GeneralAttribute(DpDetailNrType detNr, DpAttributeNrType atNr) {
                        detailNr  = detNr; 
                        attrNr    = atNr;
                        varPtr    = 0;
    };
    
    /// Destructor
    ~GeneralAttribute() {delete varPtr;};

    /** Copy constructor
     *  @param x An instance of the GeneralAttribute instance to be copied from
     */
    GeneralAttribute(const GeneralAttribute& x) {
                        detailNr  = x.detailNr; 
                        attrNr    = x.attrNr;
                        varPtr    = 0;
                        if (x.varPtr)
                            if ((varPtr = x.varPtr->allocate()) != 0)
                                *varPtr   = *x.varPtr;
    };

    /** Assignement operator
     *  @param x An instance of the GeneralAttribute instance to be copied from
     *  @return A reference to This pointer.
     */
    GeneralAttribute& operator =(const GeneralAttribute& x)
    {
                        if (this == &x)
                            return *this;
                            
                        detailNr  = x.detailNr; 
                        attrNr    = x.attrNr;
                        varPtr    = 0;
                        if (x.varPtr)
                            if ((varPtr = x.varPtr->allocate()) != 0)
                                *varPtr   = *x.varPtr;
                        return *this;
    };

    /** Comparison operator
     *  @param x An instance of the GeneralAttribute instance to be compared to
     *  @return true if attributes are equal.
     */
    bool operator==(const GeneralAttribute& x)
    {
      if (detailNr == x.detailNr &&
          attrNr   == x.attrNr &&
          *varPtr   == *(x.varPtr))
      {
        return true;
      }
      return false;
    };
    
    /** Writes content of the configuration class to the output stream.
        @param ndrStream Output stream.
        @param rVal Reference to GeneralAttribute instance.
        @return itcNdrUbSend stream.
     */
    friend DLLEXP_CONFIGS itcNdrUbSend & operator<<(itcNdrUbSend &ndrStream, const GeneralAttribute &rVal);

    /** Reads contents of the configuration class from the input stream. 
        @param ndrStream Input stream.
        @param rVal A reference to GeneralAttribute instance.
        @return itcNdrUbSend stream.
    */
    friend DLLEXP_CONFIGS itcNdrUbReceive & operator>>(itcNdrUbReceive &ndrStream, GeneralAttribute &rVal);

    /// Detail number
    DpDetailNrType detailNr;
    /// Attribute number
    DpAttributeNrType attrNr;
    /// A variable pointer
    Variable* varPtr;
};

inline itcNdrUbSend & operator<<(itcNdrUbSend &ndrStream, const GeneralAttribute &rVal)
{
  ndrStream << rVal.detailNr << rVal.attrNr << rVal.varPtr;
  return ndrStream;
}

inline itcNdrUbReceive & operator>>(itcNdrUbReceive &ndrStream, GeneralAttribute &rVal)
{
  ndrStream >> rVal.detailNr >> rVal.attrNr >> rVal.varPtr;
  return ndrStream;
}
   
#if defined(LIBS_AS_DLL)
  template class DLLEXP_CONFIGS SimplePtrArray<GeneralAttribute>;
#endif

/** The general configuration class to store all types of attributes.
 */
class DLLEXP_CONFIGS GeneralConfig : public DpConfig 
{
public:

  /** Default constructor. The instance is initialized with configuration number.
       @param configNr A configuration number
    */
  GeneralConfig(DpConfigNrType configNr);
  
  /** Copy constructor. The content of the attributeArray is not copied !
       @param newConf A reference of the instance to be copied to
    */
  GeneralConfig(const GeneralConfig &newConf);
  
  /// Destructor
  ~GeneralConfig();

  // Operatoren :

  /** Assigns a new instance of the configuration class. 
       @param rVal A reference of the instance to be assigned to
       @return A reference to this pointer is returned
    */
  virtual DpConfig &operator=(const DpConfig &rVal);
  
  /** Assigns a new instance of the configuration class. 
       @param rVal A reference of the instance to be assigned to
       @return A reference to this pointer is returned
    */
  GeneralConfig &operator=(const GeneralConfig &rVal)
    { operator=((const DpConfig &) rVal); return *this; }
  
  /** Compares two instances of the configuration class.
       @param rVal A reference of the instance to be compared to
       @return Always PVSS_FALSE is returned.
    */
  virtual int operator==(const DpConfig &rVal) const;

   /** Writes content of the configuration class to the output stream. 
        @param ndrStream Output stream.
        @param rVal Reference to GeneralConfig instance.
        @return itcNdrUbSend stream.
    */
  friend DLLEXP_CONFIGS itcNdrUbSend &operator<<(itcNdrUbSend &ndrStream, const GeneralConfig &rVal);

  /** Reads contents of the configuration class from the input stream. 
        @param ndrStream Input stream.
        @param rVal A reference to GeneralConfig instance.
        @return itcNdrUbSend stream.
   */
  friend DLLEXP_CONFIGS itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream, GeneralConfig &rVal);

  // Spezielle Methoden :

   /** Sets the specified attribute to a given value. Following function logic is implemented:
       - If the detailNr == 0 && attrNr == TYPE_ATTR, then all attributes of that Config are removed and the TYPE_ATTR is saved.
       - If the detailNr != 0 && attrNr == TYPE_ATTR, then all attributes of that Detail are removed and the TYPE_ATTR of that Detail is saved.
       - If the attribute already exists it value is replaced.

        @param detailNr Detail number.
        @param attrNr Attribute number.
        @param var A variable
        @return Always PVSS_TRUE.
    */
   virtual PVSSboolean setAttribut(DpDetailNrType detailNr, DpAttributeNrType attrNr, const Variable &var);

   /** Gets the actual value of the specified attribute. If the attribute is not found the father class of DpConfig is called instead.
        @param detailNr Detail number.
        @param attrNr Attribute number.
        @return var A value of the TYPE attribute or NULL in all other cases. The pointer is allocated by the method so it is
        up to the caller to release it then.
    */
  virtual Variable *getAttribut(DpDetailNrType detailNr, DpAttributeNrType attrNr) const;
  
    /** Checks if the configuration is consistent.
     *  @return PVSS_TRUE is always returned
     */
  virtual PVSSboolean isConsistent() const;

    /** Returns the type of the configuration.
       @return DPCONFIG_GENERAL_CONFIG type if the attribute is not found, DPCONFIG_NOCONFIG if the attribute value is not set, of the attribute type itself
    */
  virtual DpConfigType isA() const;

    /** Returns the size of the configuration object. 
       @return size of the object obtained via sizeof operator
    */
  virtual unsigned long sizeOf() const;

    /**
     *  Returns its own configuration type. If the parameter is not specified, own configuration typep is returned.
     *  Otherwise the type of the class from the derived (father) type is returned if that class is father class.
     *  @param  conf a configuration type.
     *  @return DPCONFIG_GENERAL_CONFIG type if the specified type is of the same type or the type of the instance otherwise.
     */
  virtual DpConfigType isA(DpConfigType conf) const;

    /** Returns the configuration type of the instance. Please override that method!
     *  @return DpConfigNrType an internal configuration type is returned
     */
  virtual DpConfigNrType getDpConfigNrUncached() const;

    /** Writes the content of the class into the specified stream
     *  @param ndrStream A stream to be written to
     */
  virtual void outNdrUb(itcNdrUbSend &ndrStream) const;

    /** Reads the content of the class from the specified stream
     *  @param ndrStream A stream to be read from
     */
  virtual void inNdrUb(itcNdrUbReceive &ndrStream);

    /**
     *  Allocates a new DpConfig instance. 
     *  @return A new instance of GeneralConfig class, or NULL if the allocation has failed.
     */
  virtual DpConfig *allocate() const;

    /**
     *  Provides an access to internal array of attributes. 
     *  @return A array of attributes.
     */
  SimplePtrArray<GeneralAttribute>& getAttributeArray() { return attributeArray; };
  
private:

    DpConfigNrType    myConfigNr;
    SimplePtrArray<GeneralAttribute> attributeArray;
};

// ================================================================================
// Inline-Funktionen :

inline unsigned long GeneralConfig::sizeOf() const
{
  return sizeof(GeneralConfig);
}

#endif /* _GENERALCONFIG_H_ */

