// -----------------------------------------------------------------------------
// creator: Andras Horvath - 14.11.2017
// purpose: Random Number Generator
//
// usage:
// Random<int> rng(0, 100);
// int r = rng.getNumber(); // generates an integer random between 0 and 100
//                          // (inclusive 0 and inclusive 100)
//
// Random<double> rngDbl(0, 1);
// double r = rngDbl.getNumber(); // generates a double random value
//                                // between 0.0 and 1.0
//                                // (inclusive 0.0 and exclusive 1.0)
//
// -----------------------------------------------------------------------------
#ifndef _RANDOM_HXX_
#define _RANDOM_HXX_

#undef min
#undef max

#include <limits>
#include <random>

/**
  @class Random Number Generator
  @brief Secure Random Number Generator for cryptographic purposes.
         Example generating an integer random between 0 and 100,
         inclusive 0 and inclusive 100:
         Random<int> rng(0, 100);
         int r = rng.getNumber();

         Example generating a double random between 0.0 and 1.0,
         inclusive 0.0 and exclusive 1.0:
         Random<double> rngDbl(0, 1);
         double r = rngDbl.getNumber();
  @tparam T  The type of the generated random numbers.
*/
template <typename T>
class Random
{
public:
  /**
    @brief Constructs a Random Number Generator.
    @param min  the inclusive minimum range of the random value
    @param max  the maximum range of the random value, inclusive for integral
                types,
                exclusive for floating types
  */
  Random(T min = std::numeric_limits<T>::min(),
         T max = std::numeric_limits<T>::max())
    : m_min{min}
    , m_max{max}
    , m_gen(getRandomDevice()){}

  /**
    @brief   Gets a random number.
    @details This function is used for integral types.
    @return  the random number
  */
  template <typename Q = T>
  typename std::enable_if<std::is_integral<Q>::value, T>::type getNumber()
  {
    std::uniform_int_distribution<T> dist(m_min, m_max);
    return dist(m_gen);
  }

  /**
    @brief   Gets a random number.
    @details This function is used for floating types.
    @return  the random number
  */
  template <typename Q = T>
  typename std::enable_if<std::is_floating_point<Q>::value, T>::type getNumber()
  {
    std::uniform_real_distribution<T> dist(m_min, m_max);
    return dist(m_gen);
  }

private:
  static std::random_device& getRandomDevice()
  {
    static std::random_device d;
    return d;
  }

  const T m_min;
  const T m_max;
  std::random_device& m_gen;
};

#endif  // _RANDOM_HXX_
