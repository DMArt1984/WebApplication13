#ifndef _CNSTREEVISITOR_H_
#define _CNSTREEVISITOR_H_

#include <CNSVisitor.hxx>

// forward declaration
class CNSTreeNode;

/**
 * Pure abstract base class for visitor objects,
 * which can be used with visitEveryCNSNode().
 * Derived classes must override visit(CNSTreeNode &).
 */
class DLLEXP_DATAPOINT CNSTreeVisitor
{
public:

  /// Destructor
  virtual ~CNSTreeVisitor() { }

  /**
   * This method is called for every node of the visited tree.
   *
   * It can return ABORT to stop the whole visiting process,
   * STOP_DESCENT to avoid visiting the descendants of the current node,
   * or CONTINUE to continue the visiting process.
   */
  virtual CNSVisitor::NavigationHints visit(const CNSTreeNode &node) = 0;

};

//------------------------------------------------------------------------------
// class CNSTreeFunctionVisitor
//------------------------------------------------------------------------------

/**
 * An implementation of CNSTreeVisitor which delegates to a function pointer.
 *
 * If an invocation of the function pointer returns false,
 * the whole visiting process is aborted.
 */
class DLLEXP_DATAPOINT CNSTreeFunctionVisitor : public CNSTreeVisitor
{
public:
  /**
   * Creates a new visitor which delegates every invocation to the
   * specified function pointer.
   */
  CNSTreeFunctionVisitor(PVSSboolean (*functionPtr)(const CNSTreeNode &node))
    : CNSTreeVisitor(), function(functionPtr) { }

  /**
   * Delegates to the function pointer specified in the constructor.
   *
   * @return CONTINUE if the function pointer returned true, otherwise ABORT
   */
  virtual CNSVisitor::NavigationHints visit(const CNSTreeNode &node);

private:
  /// The internal function pointer
  PVSSboolean (*function)(const CNSTreeNode &node);
};

//------------------------------------------------------------------------------
// methods:

inline CNSVisitor::NavigationHints CNSTreeFunctionVisitor::visit(const CNSTreeNode &node)
{
  if (function && (*function)(node))
  {
    return CNSVisitor::CONTINUE;
  }

  return CNSVisitor::ABORT;
}

#endif // _CNSTREEVISITOR_H_
