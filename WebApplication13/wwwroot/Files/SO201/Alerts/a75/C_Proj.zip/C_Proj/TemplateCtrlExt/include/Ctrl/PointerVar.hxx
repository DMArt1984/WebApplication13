#ifndef _POINTERVAR_H_
#define _POINTERVAR_H_

#include <CtrlVariable.hxx>
#include <Allocator.hxx>
#include <memory>

class UserType;

/**
  A class holding a shared pointer to a Variable instance

  @classification ETM internal
*/

class DLLEXP_CTRL PointerVar : public CtrlVariable
{
  public:
    PointerVar(const UserType *userType, bool doRefCount);
    PointerVar(VariableType vType = NO_VAR);

    virtual ~PointerVar();

    virtual VariableType isAUncached() const { return POINTER_VAR; }
    virtual VariableType isAUncached(VariableType varType) const;

    AllocatorDecl;

    // check if this is a nullptr (not true if it's a ptr to some type but still null)
    bool isNullPtr() const { return (varType == NO_VAR); }

    void createTarget();

    virtual Variable *getTarget() const;

    // captures the Variable and manages it. varType is set to the given Variable's type
    // var can be 0, which creates a nullptr
    void setTarget(Variable *var);

    const UserType *getUserType() const { return userType; }
    VariableType getVarType() const { return varType; }

    virtual Variable *clone() const;
    virtual Variable *allocate() const { return clone(); }

    virtual PVSSboolean isTrue() const;

    // assign given Variable if possible, else return false
    virtual bool assign(const Variable &rVal, CtrlThread *thread = 0);

    virtual int operator==(const Variable &rVal) const;
    virtual Variable &operator=(const Variable &rVal);

    virtual void outToFile(std::ostream &ofStream) const;

    virtual CharString formatValue(const CharString &format) const;

  private:
    bool typeMatches(const PointerVar &other) const;

  private:
    const UserType *userType;
    VariableType varType;

#ifdef _WIN32
// we can safely disable this compiler warning, because value is a private member
// see https://stackoverflow.com/questions/767579/exporting-classes-containing-std-objects-vector-map-etc-from-a-dll
#  pragma warning(push)
#  pragma warning(disable : 4251)
#endif
    std::shared_ptr<Variable> value;
#ifdef _WIN32
#  pragma warning(pop)
#endif

    bool refCounting;
};

#endif
