#ifndef _CTRL_UTILS_H_
#define _CTRL_UTILS_H_

#include <Types.hxx>
#include <DpIdentification.hxx>

class Variable;
class CtrlThread;
class CtrlExpr;
class EnumClass;

/// Helper methods for use in CTRL
/// @classification ETM internal

class DLLEXP_CTRL CtrlUtils
{
  public:
    ///Converts the language index to corresponding language id of certain system.
    ///@param langIdx The language index
    ///@param [out] langId The language id
    ///@return Valid language if the function was successful,
    ///        -1 in case of error
    ///@classification public use, call
    static GlobalLanguageIdType projectLangIndexToId(int langIdx);

    ///Converts the language index to corresponding language id of certain system.
    ///@param langIdx The language index
    ///@param [out] langId The language id
    ///@return Valid index (>0) if the function was successful,
    ///        -1 in case of error
    ///@classification public use, call
    static int projectLangIdToIndex(GlobalLanguageIdType langId);

    static const EnumClass *getOaLanguageEnum(CtrlThread *thread);

    static bool isOaLanguageEnum(const Variable *langVar, const CharString &funcName, CtrlThread *thread);

    static bool getLangIdFromArg(GlobalLanguageIdType &langId,
                                 const Variable *langVar, const CharString &funcName, CtrlThread *thread);
};

#endif //_CTRL_UTILS_H_ 
