#ifndef _CMWAITFORANSWER_H_
#define _CMWAITFORANSWER_H_

#include <HotLinkWaitForAnswer.hxx>

class CtrlModule;

/*  author VERANTWORTUNG: Martin Koller */
/** handles the returning values on initializing a Ctrl-Module */
class DLLEXP_CTRL CMWaitForAnswer : public HotLinkWaitForAnswer
{
  public:
    ///
    CMWaitForAnswer(CtrlModule *mod, int cData = 0) 
    : module(mod), 
      clientData(cData),
      hotLinkAnswered(false)  {}
    ///
    ~CMWaitForAnswer();

    /// Implement callBack 
    virtual void callBack(DpMsgAnswer &answer);
    ///
    /// HotLink Callback startet Thread und fuehrt work Function aus
    virtual void hotLinkCallBack(DpMsgAnswer &answer);
    /// HotLink Callback startet Thread und fuehrt work Function aus
    virtual void hotLinkCallBack(DpHLGroup &group);
    /// entferne ref auf WaitForDpValue
    void clearModule() { module = 0; }
    /// Ist die Antwort auf das dpConnect eingetroffen? true -> Hotlink ist aktiv.
    bool gotHotLinkAnswer() { return(hotLinkAnswered); }

  protected:

  private:
    CtrlModule *module;  // we do not delete this on destruction
    int clientData;
    bool hotLinkAnswered;
};

#endif /* _CMWAITFORANSWER_H_ */
