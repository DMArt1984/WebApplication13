#ifndef _VARIABLE_H_
#define _VARIABLE_H_

// DATEIBESCHREIBUNG ==============================================================
// DATEINAME:     Variable.hxx
// VERANTWORTUNG: Johannes Ertl
// BESCHREIBUNG:  Abstrakte Variable, die im PVSS-2 eingesetzt wird.
// ERWEITERUNGEN: Wird ein neuer Variablentyp eingefuehrt, so muss in der Funktion
//                allocate(VariableType) das switch Statement erweitert und
//                der enum im VariableType ergaenzt werden.
//
//
// BEWARE: isA() result is cached in Variable::cachedIsA. You _MUST_ do the
//         following when deriving new Variable:
//
//         - define isAUncached() and isAUncached(VariableType) functions
//           to return the desired isA() value
//
//         - define the copy constructor
//
//         - fill in cachedIsA in EVERY constructor, including the copy constructor
//
//         - fill in cachedIsA whenever the variable status changes so that
//           isA() return value should change
//
//         The summary: when leaving any of your class's member functions,
//         Variable::cachedIsA must have the same value, as the isAUncached()
//         function returns.
//


#ifndef _TYPES_HXX_
#include <Types.hxx>
#endif

#ifndef _CHARSTRING_H_
#include <CharString.hxx>
#endif

#ifndef _ALLOCATOR_HXX_
#include <Allocator.hxx>
#endif

#ifndef _DYNPTRARRAY_H_
#include <DynPtrArray.hxx>
#endif

#ifndef _SIMPLEPTRARRAY_H_
#include <SimplePtrArray.hxx>
#endif

#include <iostream>

class Variable;
class ULongVar;
class itcNdrUbSend;
class itcNdrUbReceive;

/** The variable types used in PVSS-II. whenever a message has to be sent or decoded
    the Variable and subclasses are used.
*/
enum VariableType
{
  /** (0x00000000). unset variable type */
  NO_VAR                 = 0x00000000,
  /** (0x00010000). void variable type */
  NOTYPE_VAR             = 0x00010000,
  /** (0x00020000). empty variable type */
  VARIABLE               = 0x00020000,
  /** (0x00030000). time variable type */
  TIME_VAR               = 0x00030000,
  /** (0x00040000). bit variable type */
  BIT_VAR                = 0x00040000,
  /** (0x00050000). integer variable type */
  INTEGER_VAR            = 0x00050000,
  /** (0x00060000). unsigned integer variable type */
  UINTEGER_VAR           = 0x00060000,
  /** (0x00070000). float variable type */
  FLOAT_VAR              = 0x00070000,
  /** (0x00080000). text variable type */
  TEXT_VAR               = 0x00080000,
  /** (0x00090000). 32 bit variable type */
  BIT32_VAR              = 0x00090000,
  /** (0x000A0000). char variable type */
  CHAR_VAR               = 0x000A0000,
  /** (0x000B0000). dp identifier variable type */
  DPIDENTIFIER_VAR       = 0x000B0000,
  /** (0x000C0000). empty dynvar type */
  DYN_VAR                = 0x000C0000,
  /** (0x000D0000). dyn_time variable type */
  DYNTIME_VAR            = 0x000D0000,
  /** (0x000E0000). dyn_bit variable type */
  DYNBIT_VAR             = 0x000E0000,
  /** (0x000F0000). dyn_int variable type */
  DYNINTEGER_VAR         = 0x000F0000,
  /** (0x00100000). dyn_uint variable type */
  DYNUINTEGER_VAR        = 0x00100000,
  /** (0x00110000). dyn_float variable type */
  DYNFLOAT_VAR           = 0x00110000,
  /** (0x00120000). dyn_text variable type */
  DYNTEXT_VAR            = 0x00120000,
  /** (0x00130000). dyn_32bit variable type */
  DYNBIT32_VAR           = 0x00130000,
  /** (0x00140000). dyn_char variable type */
  DYNCHAR_VAR            = 0x00140000,
  /** (0x00150000). dyn_dpidentifier variable type */
  DYNDPIDENTIFIER_VAR    = 0x00150000,
  /** (0x00160000). recvar  type */
  REC_VAR                = 0x00160000,
  /** (0x00170000). file variable type */
  FILE_VAR               = 0x00170000,
  /** (0x00180000). empty anytype variable type */
  ANYTYPE_VAR            = 0x00180000,
  /** (0x00190000). argument variable type (internal use)*/
  ARG_VAR                = 0x00190000,
  /** (0x001A0000). dyn_dyn_time variable type*/
  DYNDYNTIME_VAR         = 0x001A0000,
  /** (0x001B0000). dyn_dyn_bit variable type*/
  DYNDYNBIT_VAR          = 0x001B0000,
  /** (0x001C0000). dyn_dyn_int variable type*/
  DYNDYNINTEGER_VAR      = 0x001C0000,
  /** (0x001D0000). dyn_dyn_uint variable type*/
  DYNDYNUINTEGER_VAR     = 0x001D0000,
  /** (0x001E0000). dyn_dyn_float variable type*/
  DYNDYNFLOAT_VAR        = 0x001E0000,
  /** (0x001F0000). dyn_dyn_text variable type*/
  DYNDYNTEXT_VAR         = 0x001F0000,
  /** (0x00200000). dyn_dyn_32bit variable type*/
  DYNDYNBIT32_VAR        = 0x00200000,
  /** (0x00210000). dyn_dyn_char variable type*/
  DYNDYNCHAR_VAR         = 0x00210000,
  /** (0x00220000). dyn_dyn_dpidentifier variable type*/
  DYNDYNDPIDENTIFIER_VAR = 0x00220000,
  /** (0x00230000). dyn_anytype variable type*/
  DYNANYTYPE_VAR         = 0x00230000,
  /** (0x00240000). dyn_dyn_anytype variable type*/
  DYNDYNANYTYPE_VAR      = 0x00240000,
  /** (0x00250000). extended_time variable type*/
  EXTTIME_VAR            = 0x00250000,
  /** (0x00260000). dyn_extended_time variable type*/
  DYNEXTTIME_VAR         = 0x00260000,
  /** (0x00270000). dyn_dyn_extended_time variable type*/
  DYNDYNEXTTIME_VAR      = 0x00270000,
  /** (0x00280000). langtext variable type*/
  LANGTEXT_VAR           = 0x00280000,
  /** (0x00290000). dyn_langtext variable type*/
  DYNLANGTEXT_VAR        = 0x00290000,
  /** (0x002A0000). dyn_dyn_langtext variable type*/
  DYNDYNLANGTEXT_VAR     = 0x002A0000,
  /** (0x002B0000). error variable type*/
  ERROR_VAR              = 0x002B0000,
  /** (0x002C0000). dyn_error variable type*/
  DYNERROR_VAR           = 0x002C0000,
  /** (0x002D0000). dyn_dyn_error variable type*/
  DYNDYNERROR_VAR        = 0x002D0000,
  /** (0x002E0000). blob variable type */
  BLOB_VAR               = 0x002E0000,
  /** (0x002F0000). dyn_blob variable type */
  DYNBLOB_VAR            = 0x002F0000,
  /** (0x00310000). ADO data types          */
  RECHDL_VAR            = 0x00310000,
  CONNHDL_VAR           = 0x00320000,
  CMDHDL_VAR            = 0x00330000,
  POINTER_VAR           = 0x00340000,   /* in Libs/Ctrl */
  SHAPE_VAR             = 0x00350000,   /* shape type - UI */
  IDISPATCH_VAR         = 0x00360000,   /* IDispatch type - UI */
  DYNDYNBLOB_VAR        = 0x00370000,
  DYNREC_VAR            = 0x00380000,
  DYNDYNREC_VAR         = 0x00390000,
  MAPPING_VAR           = 0x003A0000,
  DYNMAPPING_VAR        = 0x003B0000,
  DYNDYNMAPPING_VAR     = 0x003C0000,
  MIXED_VAR             = 0x003D0000,
  DYNMIXED_VAR          = 0x003E0000,
  DYNDYNMIXED_VAR       = 0x003F0000,
  DYNRECHDL_VAR         = 0x00400000,
  DYNCONNHDL_VAR        = 0x00410000,
  DYNCMDHDL_VAR         = 0x00420000,
  DYNDYNRECHDL_VAR      = 0x00430000,
  DYNDYNCONNHDL_VAR     = 0x00440000,
  DYNDYNCMDHDL_VAR      = 0x00450000,
  LONG_VAR              = 0x00460000,
  DYNLONG_VAR           = 0x00470000,
  DYNDYNLONG_VAR        = 0x00480000,
  ULONG_VAR             = 0x00490000,
  DYNULONG_VAR          = 0x004A0000,
  DYNDYNULONG_VAR       = 0x004B0000,

  /*IM 87586: new _original, _online, _offline attribute _status64 */
  /** (0x004C0000). 64 bit variable type */
  BIT64_VAR             = 0x004C0000,
  DYNBIT64_VAR          = 0x004D0000,
  DYNDYNBIT64_VAR       = 0x004E0000,

  DYNSHAPE_VAR          = 0x004F0000,
  DYNDYNSHAPE_VAR       = 0x00500000,

  // defined in Libs/Ctrl
  FUNCTION_VAR          = 0x00510000,
  DYNFUNCTION_VAR       = 0x00520000,
  DYNDYNFUNCTION_VAR    = 0x00530000,
  REFERENCE_VAR         = 0x00540000,
  CLASS_VAR             = 0x00550000,
  VECTOR_VAR            = 0x00560000,
  DYNDYNCLASS_VAR       = 0x00570000,

  // QVariant in Qt-Ui
  QVARIANT_VAR          = 0x00580000
};

/// a Variable * shortcut
typedef Variable* VariablePtr;

/** The variable class. This is an abstract class for all types of variables like
    Integers, Doubles, Times, DpIdentifiers, but also for some special purpose types like
    database connections. Whenever we deal with messages values are stored in a dereived
    class and referenced by a pointer to this base class.
*/
class DLLEXP_BASICS Variable
{
  public:
    /** Result of the conversion between Variable instances
    */
    enum ConvertResult
    {
      OK,
      OUT_OF_RANGE,
      CONV_NOT_DEFINED
    };

    enum CompareOperator
    {
      GT,
      LT
    };
    /** Default constructor
    */
    Variable() : cachedIsA(NO_VAR) {}

    /** Copy constructor.
        @param rVal Source Variable value to be copied.
    */
    Variable(const Variable &rVal) : cachedIsA(rVal.cachedIsA) {}

    /** (virtual) destructor.
    */
    virtual ~Variable() {}

    /** Write variable type and value to the output stream.
        @param ndrStream Output stream.
        @param varPtr Pointer to the Variable value.
        @return itcNdrUbSend stream.
    */
    friend DLLEXP_BASICS itcNdrUbSend &operator<<(itcNdrUbSend &ndrStream, const VariablePtr &varPtr);

    /** Read variable type and value from the input stream and creates a new variable.
        @param ndrStream Input stream.
        @param varPtr Pointer to the Variable value.
        @return itcNdrUbSend stream.
    */
    friend DLLEXP_BASICS itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream, VariablePtr &varPtr);

    /** Write value to the output stream.
        @param ndrStream Output stream.
        @return itcNdrUbSend stream.
    */
    friend DLLEXP_BASICS itcNdrUbSend &operator<<(itcNdrUbSend &ndrStream, const Variable &) { return ndrStream; }

    /** Read value from the input stream.
        @param ndrStream Input stream.
        @return itcNdrUbReceive stream.
    */
    friend DLLEXP_BASICS itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream, Variable &) { return ndrStream; }

    /** Write variable type and value to the output stream std::ostream.
        @param ofStream Output stream (std::ostream).
        @param varPtr Pointer to the Variable value.
        @return std::ostream stream.
    */
    friend DLLEXP_BASICS std::ostream &operator<<(std::ostream &ofStream, const VariablePtr &varPtr);

    /** Read variable type and value from the input stream and creates a new Variable.
        @param ifStream Input stream (std::istream).
        @param varPtr Pointer to the Variable value.
        @return std::istream stream.
    */
    friend DLLEXP_BASICS std::istream &operator>>(std::istream &ifStream, VariablePtr &varPtr);

    /** Equality operator (virtual). This operator is needed to enable (*x)==(*y).
        When creating a new variable class don't forget to overload this operator!
        @param rVal Compared value.
        @return int 1 if the values are equal, otherwise 0.
        @n Important: this operator checks the VariableType, so two objects are only equal, if
        they also have the same class (no conversion is done; see other operators).
    */
    virtual int operator==(const Variable &rVal) const;

    /** Not-equal-to operator.
        @param rVal Compared value.
        @return The inverse of Equality operator (!operator==()).
        @n Important: this operator checks the VariableType, so two objects are only equal, if
        they also have the same class (no conversion is done; see other operators).
    */
    int operator!=(const Variable &rVal) const { return (! operator==(rVal)); }

    /** The less than operator. At least primitive types should overload this operator.
        @param rVal Compared value.
        @return int 1 if true, otherwise 0.
        @n Important: this operator also converts the given rVal to its own class-type if needed.
    */
    virtual int operator<(const Variable &rVal) const;

    /** The greater than operator. At least primitive types should overload this operator.
        @param rVal Compared value.
        @return int 1 if true, otherwise 0.
        @n Important: this operator also converts the given rVal to its own class-type if needed.
    */
    virtual int operator>(const Variable &rVal) const;

    /** The less than or equal operator.
        @param rVal Compared value.
        @return int 1 if true, otherwise 0.
        @n Important: this operator also converts the given rVal to its own class-type if needed.
    */
    int operator<=(const Variable &rVal) const { return (! operator>(rVal)); }

    /** The greater than or equal operator.
        @param rVal Compared value.
        @return int 1 if true, otherwise 0.
        @n Important: this operator also converts the given rVal to its own class-type if needed.
    */
    int operator>=(const Variable &rVal) const { return (! operator<(rVal)); }

    /** Virtual logical check function needed for compatibility with C style boolean conditions.
        @return PVSSboolean Default implementation in the Variable class returs PVSS_FALSE.
        Each derived class should provide its own implmentation.
    */
    virtual PVSSboolean isTrue() const;

    /** Virtual assignment operator used for type conversions (*x)=(*y).
        @n Important: DON'T copy cachedIsA - otherwise things will go wrong.
    */
    virtual Variable &operator=(const Variable &) { return *this; }

    /** Create a new variable of a given type.
        @param type Type of a new variable.
        @return Variable* pointer to a newly allocated instance.
    */
    static Variable *allocate(const VariableType &type);

    /** (pure virtual) Create a new Variable of its own type.
        @return Variable* pointer to a newly allocated variable.
    */
    virtual Variable *allocate() const = 0;

    /** (pure virtual) The clone function is used to create an exact copy of the current object.
        This copy should be deleted after use.
        @return Variable* pointer to a newly cloned variable (deep copy).
    */
    virtual Variable *clone() const = 0;

    /** (pure virtual) Check function to determine the type of the variable.
        @return VariableType of the variable.
    */
    virtual VariableType isAUncached() const = 0;

    /** Check function to determine the type of the variable. Derived classes should
        override this method to return its own type.
        @return VARIABLE type or NOTYPE_VAR.
    */
    virtual VariableType isAUncached(VariableType varType) const;

    /** This method returns its own variable type. Use this function to determine the type
        of a variable pointer before casting it to a derived class. This is a non-virtual
        function for fast access.
        @return VariableType.
    */
    VariableType isA() const;

    /** Check if own type matches or is derived from a given type.
        E.g. a DYNINTEGER_VAR (an array of IntegerVar) will match DYNINTEGER_VAR but also DYN_VAR
        and VARIABLE.
        @param varType VariableType to check.
        @return varType if the type does match, NOTYPE_VAR if the type does not match.
    */
    VariableType isA(VariableType varType) const;

    /** Check if this class inherits (or is) the given baseclass type
        @param varType VariableType to check.
        @return true if it inherits or is the given type, else false
    */
    bool inherits(VariableType varType) const { return isA(varType) == varType; }

    /** Write value to output stream.
        @param ofStream std::ostream to write to.
    */
    virtual void outToFile(std::ostream &ofStream) const { }

    /** Read value from the input stream.
        @param ifStream std::istream to read the value from.
    */
    virtual void inFromFile(std::istream &ifStream) { }

    /** format the value according to the default rules.
    */
    CharString formatValue() const {return formatValue("");}

    /** Format the value according to the format string.
        If format is an empty string, a default will be used, otherwise the
        format is VariableType dependent.
        @param  format  The format string. If the string is not empty it is
                used as an argument to the sprintf function.
                Otherwise a default is used.
        @return The string representation of the value.
    */
    virtual CharString formatValue(const CharString &format) const;

    /** Format the value according to a format string.
        @param format The format string. If the string is not empty is is
               used as an argument to the sprintf function (if useful).
               Else a default is used.
        @param target This is a buffer with length len, which is directly written to.
               This method is more performant than the one which returns a CharString,
               because no alloc is done.
        @param len Size of the output buffer.
        @return Number of bytes written into target without 0-byte,
                or a negative value on error (like buffer too small)
    */
    virtual int formatValue(const CharString &format, char *target, size_t len) const;

    /** Print the content of the Variable to the output stream.
        @param to Specifies the output stream.
        @param level Level controls the amount of debug information
        printed. Nothing is printed if level == 0.
    */
    virtual void debug(std::ostream &to, int level) const;

    /** Use this function to determine the relative casting order of the VariableType.
        @param varType VariableType for which the casting order should be returned.
        @return If the value is positive, the lower type should be casted to the higher.
        If the value is negative, no conversion is defined (dynvars etc.).
    */
    static int castingOrder(VariableType varType);

    /** Check if the variable is of type DYN_VAR (array).
        @return PVSSboolean. Default implementation returns PVSS_FALSE.
    */
    virtual PVSSboolean isDynVar() const {return PVSS_FALSE;}

    /** Check if the variable is of type DYNDYN_VAR (two-dimensional array).
        @return PVSSboolean. Default implementation returns PVSS_FALSE.
    */
    virtual PVSSboolean isDynDynVar() const {return PVSS_FALSE;}

    /** Returns a string representing the given VariableType, for example "FLOAT_VAR".
        @param varType VariableType.
        @return Const char* pointer to the variable type name.
    */
    static const char* getTypeName(VariableType varType);

    /** Write the variable type as a string to the output stream
        @param to Output stream to write to.
        @param level Debug level. (if 0, nothing will be written).
        @param varType VariableType whose name will be written to the stream.
    */
    static void debug(std::ostream &to, int level, VariableType varType);

    // versucht sich selbst in eine Variable "out" vom Typ "to" zu konvertieren
    // bei Konvertierung von float auf int-Typen erfolgt ein Runden !!!!
    // Returnwert:    OK: Konvertierung erfolgreich, "out" wurde neu allokiert
    //                OUT_OF_RANGE: Konvertierung grundsaetzlich moeglich, aber der
    //                Wert von "in" liegt ausserhalb des Wertebereichs des Typs "to",
    //                "out" wird trotzdem allokiert !!!! und enthaelt Min bzw. Max des
    //                moeglichen Wertebereichs
    //                CONV_NOT_DEFINED: Typumwandlung nicht moeglich, "out" wird auf 0
    //                gesetzt
    /** Converts the value to a Variable of another type.
        @param to VariableType of the variable converting to.
        @param out VariablePtr to a newly created Variable of the desired type.
        @return OK if correctly converted, OUT_OF_RANGE or CONV_NOT_DEFINED otherwise.
    */
    virtual ConvertResult convert(VariableType to, VariablePtr &out) const;

    /// registers a new VariableType which is used for cloning in allocate()
    /// @internal
    static void registerVariableType(VariableType varType, Variable *templateVar);

    /** for container-like types (e.g. AnyTypeVar) this method returns the final target
        For the basic types it just returns a pointer to this
        @return The final target Variable instance
    */
    virtual Variable *getTarget() const;

  protected:
    /** Greater-than method, comparing *this with rVal. If the Variables are of different
        types, this method try casting to convert them to same type using convert() method.
        @param rVal Reference to the Variable to be compared with this.
        @return 1 if the Variables can be converted to the same type and *this > rVal, otherwise 0.
    */
    int gt(const Variable &rVal) const;

    /** Greater-than method, comparing *this with rVal. If the Variables are of different
        types, this method try casting to convert them to same type using convert() method.
        @param rVal Reference to the Variable to be compared with this.
        @return 1 if the Variables can be converted to the same type and *this > rVal, otherwise 0.
    */
    int lt(const Variable &rVal) const;

  protected:
    /** This member stores the VariableType, which is returned by the non-virtual method isA().
        Each derived class should set this member in all its constructors and also when the type
        changes.
    */
    VariableType cachedIsA;

  private:
    int gt(const Variable &lVal, const Variable &rVal) const;
    int lt(const Variable &lVal, const Variable &rVal) const;
    int cmpULongVar(const Variable &val, const ULongVar &ul, CompareOperator op) const;
    int cmpULongVar(const ULongVar &ul, const Variable &val, CompareOperator op) const;
    const Variable &convert(VariableType to, VariablePtr &out, ConvertResult &res) const;

  private:
    // Ausgabe der entsprechenden Klasse
    virtual void outNdrUb(itcNdrUbSend &ndrStream) const { }  //COVINFO LINE: defensive (AP: force implementation by instance)

    // einlesen der Attribute der entsprechenden Klasse
    virtual void inNdrUb(itcNdrUbReceive &ndrStream) { }      //COVINFO LINE: defensive (AP: force implementation by instance)
};

// ------------------------------------------------------------------------

inline VariableType Variable::isA() const
{
        // no mutable - do a dirty cast trick
        return (cachedIsA != NO_VAR)
                ? cachedIsA
                : (((Variable*) this)->cachedIsA = isAUncached());
}

// ------------------------------------------------------------------------

inline VariableType Variable::isA(VariableType varType) const
{
  // isA must be called first or the following optimization will fail
  if ((varType == isA()) || (varType == VARIABLE))
    return varType;

  // Optimize for ANYTYPE and derivative.
  // isA() has been called and therefore cachedIsA is initialized
  if (varType == ANYTYPE_VAR)
    return (cachedIsA == MIXED_VAR || cachedIsA == REFERENCE_VAR ? ANYTYPE_VAR : NOTYPE_VAR);

  // No optimalise (yet)
  return isAUncached(varType);
}

// -----------------------------------------------------------------------------------
//Bug TFS-39916: Prevent blocking EVENT in case of handling corrupted messages
// ---------------------------------------------------------------------------
//   itcNdrUbSend &operator<<(itcNdrUbSend &ndrStream, const VariablePtr &varPtr) 
// and 
//   itcNdrUbSend &operator<<(itcNdrUbSend &ndrStream, const DynVar &array)
// contain code to write corrupt messages if -dbg corruption is set.
// This is to dangerous to be only disabled via -dbg flags
// -> to be able to test the fix for TFS-39916 you have to 
//    - uncomment the line "#define ENABLE_CORRUPT_MSG"
//    - recompile libBasics 
//
// #define ENABLE_CORRUPT_MSG
// -----------------------------------------------------------------------------------

// ------------------------------------------------------------------------
// ------------------------------------------------------------------------
// ------------------------------------------------------------------------
#ifdef WIN32
#pragma warning ( push )
#pragma warning ( disable: 4231 )
#endif

#if defined(LIBS_AS_DLL)
  EXTERN_BASICS template class DLLEXP_BASICS DynPtrArray<Variable>;
  EXTERN_BASICS template class DLLEXP_BASICS SimplePtrArray<Variable>;
  #include <DynPtrArrayTpl.hxx>
#endif

#ifdef WIN32
#pragma warning ( pop )
#endif

// used in most of the formatValue() functions
#ifdef _WIN32
#define snprintf _snprintf
#endif

#endif /* _VARIABLE_H_ */
