// DATEIBESCHREIBUNG ==============================================================
// DATEINAME:       RequestHandler.hxx
// VERANTWORTUNG:  Thomas Koroschetz
// BESCHREIBUNG:   Die Klasse RequestHandler behandelt die Request-Messages 
//                  des Treibers. Die Funktion processRequest nimmt eine
//                  RequestMessage entgegen, erzeugt eine ResponseMessage, 
//                  fuellt diese aus und liefert sie als Funktionsresultat
//                  zurueck.
//
#ifndef _REQUESTHANDLER_H_
#define _REQUESTHANDLER_H_

// Vorwaerts-Deklaration der Eigenen Klasse
class RequestHandler;

#ifndef _PTRLIST_H_
#include <PtrList.hxx>
#endif

#ifndef _REQUESTGROUP_H_
#include <RequestGroup.hxx>
#endif

// Vorwaerts-Deklarationen :
class DpIdentifier;
class DpMsgAnswer;
class DpMsgRequest;

class HWObject;

/** This class handles requests on driver configs. 
  * The processRequest() member creates an answer message and provides the results.
  *
  * @classification ETM internal
  */
class RequestHandler 
{

public:
  
  /** Constructor
    */
  RequestHandler();
  
  /** Destructor
    */ 
  ~RequestHandler();

  // Spezielle Methoden :

  /** Searches in all request items, creates and processes answer to dp request message. 
    * Calls function processSimpleRequestItem().
    * @param msg dp request message
  * @return pointer to answer message
    */

  DpMsgAnswer *processRequest(const DpMsgRequest &msg);

  /** Processes simle request item, checks atribute, creates error or normal answer. 
    * @param [out] ansPtr pointer to answer message
    * @param reqGrpPtr pointer to request group
  * @return 0
    */
  DynPtrArrayIndex processSimpleRequestItem(DpMsgAnswer *ansPtr, const RequestGroup *reqGrpPtr);

  /** Process direct request messages coming from EV.
    * @param [in] msg the request message
  */
  void processDirectRequest(const DpMsgRequest &msg);

  /** process notification for answering direct requests.
    * @param [in] objPtr the HWObject containing the answerID (HwoID)
    */
  void processNotificationForAnswer(HWObject *objPtr);

  /** check for answers ready to send.
    */
  void sendAnswers();
};

#endif /* _REQUESTHANDLER_H_ */
