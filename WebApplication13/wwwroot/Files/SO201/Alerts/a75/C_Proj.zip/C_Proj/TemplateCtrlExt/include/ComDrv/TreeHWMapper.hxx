// DATEIBESCHREIBUNG ==============================================================
// DATEINAME:  TreeHWMapper.hxx
//        Service-Modul fuer Mapping von Hardware-Adressen auf
//              Datenpunkte.
//

#ifndef _TREEHWMAPPER_HXX
#define _TREEHWMAPPER_HXX

#ifndef _HWMAPPADP_H_
#include <HWMapDpPa.hxx>
#endif

#ifndef _HWOBJECT_H_
#include <HWObject.hxx>
#endif

#ifndef _DPPERIPHADDR_H_
#include <PeriphAddr.hxx>
#endif

#ifndef _DPIDENTIFIER_H_
#include <DpIdentifier.hxx>
#endif

#include <AbstractHWMapper.hxx>

#include <TreeHWMapperComparators.hxx>


/** This class holds the connection between datapoints, configs and HWObjects.
  * The config represents the internal parametrisation whereas the HWObject represents the
  * connected hardware and available data. The purpose of this mapper is to combine the
  * incoming / outgoing data with the corresponding data objects (i.e. variables or HWObjects).
  *
  * <p> this class serves as base class for derived drivers. On overloading certain member functions
  * you enable the mapper to do his job, namely map HWObjects and PeriphAddr strings.
  *
  * @classification public use, overload
  */
class TreeHWMapper : public AbstractHWMapper
{

  friend class UNIT_TEST_FRIEND_CLASS;

public:

  /** Constructor
    */
  TreeHWMapper();

  /** Destructor
    */
  virtual ~TreeHWMapper();

  /** Add new dpId with config. This is a sorted insert algorithm.
    * @param dpId the new dpIdentifier
    * @param confPtr the new config entry; this object is captured by the list
    * @return PVSS_TRUE on success
    * @classification ETM internal
    */
  virtual  PVSSboolean  addDpPa(DpIdentifier& dpId, PeriphAddr *confPtr);

  /** Add new HWObject in a sorted manner.
    * @param objPtr an object derived from HWObject with all needed HW information; this object is captured by the list
    * @return PVSS_TRUE on success
    * @classification public use, overload
    */
  virtual PVSSboolean          addHWObject(HWObject *objPtr);

  /** Remove a HWMapDpPa entry from the list.
    * @param dpId the dpIdentifier to search for
    * @param confPtr the config to search for
    * @return PVSS_TRUE if found and deleted, else PVSS_FALSE
    * @classification ETM internal
    */
  virtual  PVSSboolean  clrDpPa(DpIdentifier& dpId, PeriphAddr *confPtr);

  /** Find a HWObject and remove it from the list. The HWObject is not deleted
    * since there is the possibility of external reference to this object. The caller of this
    * function is responsible for deleting the removed object.
    * @param objPtr the object which to search for - PeriphAddr and HW addr are compared
    * @return PVSS_TRUE if the object is found, otherwise PVSS_FALSE
    * @classification ETM internal
    */
  virtual PVSSboolean          clrHWObject(HWObject *objPtr);

  /** Clear all registered HWObjects. The HWObjects are deleted by this function.
    * @classification ETM internal
    */
  virtual void                 delHWObjects();

  /** Searches for all DpPa objects for a given HW address.
    * @param hwAdr HWObject containing a known PeriphAddr string
    * @return the index of the first DpPa object matching the PeriphAddr
    * @classification ETM internal
    */
  virtual HWMapDpPa * getFirstMatch(HWObject *hwAdr);

  /** Searches for all DpPa objects for a given HW address.
    * @param hwAdr HWObject containing a known PeriphAddr string
    * @return the index of the next DpPa object matching the PeriphAddr
    * @classification ETM internal
    */
  virtual HWMapDpPa * getNextMatch(HWObject *hwAdr);

  /** Searches for all DpPa objects for a given DpId.
    * @warning Do not mix with getFirst(), getNext() because they use the same iterator.
    * @param dpId contains a DpIdentifier
    * @return the index of the first DpPa object matching the dpId
    * @classification ETM internal
    */
  virtual HWMapDpPa * getFirstMatch(const DpIdentifier &dpId);

  /** Searches for all DpPa objects for a given DpId.
    * @param dpId contains a DpIdentifier
    * @return the index of the next DpPa object matching the dpId
    * @classification ETM internal
    */
  virtual HWMapDpPa * getNextMatch(const DpIdentifier &dpId);

  /** This is the standard iterator over HWMapDpPa objects in DpId order.
    * @warning This function reuses the DpIdentifier iterator!
    * @return the corresponding objects (first)
    * @classification ETM internal
    */
  virtual HWMapDpPa *getFirstDpPa();

  /** This is the standard iterator over HWMapDpPa objects in DpId order.
    * @warning This function reuses the DpIdentifier iterator!
    * @return the corresponding objects (next)
    * @classification ETM internal
    */
  virtual HWMapDpPa *getNextDpPa();

  /** This function searches for an entry in the HW list matching the
    * given hardware address.
    * @param hwAdr derived HWObject which holds the hardware address for incoming data
    * @return HWObject from the mapper which holds the corresponding PeriphAddr
    * @classification public use, call
    */
  virtual HWObject*            findHWObject(HWObject* hwAdr);

  /** This functions returns a given entry in the HW list sorted by
    * hardware address.
    * @param hwAdr derived HWObject which holds the hardware address for incoming data
    * @return the first matching HWObject at the specified position in the HW list.
    */
  virtual HWObject *             getFirstHWObjMatch(HWObject *hwAdr);

  /** This functions returns a given entry in the HW list sorted by
    * hardware address.
    * @param hwAdr derived HWObject which holds the hardware address for incoming data
    * @return the next matching HWObject at the specified position in the HW list.
    */
  virtual HWObject *             getNextHWObjMatch(HWObject *hwAdr);

  /** Iterate through all HWObjects sorted by hardware address.
    * @return the first HW object
    */
  virtual HWObject *             getFirstHWObj();

  /** Iterate through all HWObjects sorted by hardware address.
    * @return the next HW object
    */
  virtual HWObject *             getNextHWObj();

  /** This function searches for an entry in the HW list matching the
    * given periph address.
    * @param adrObj HWObject which holds the periph address for outgoing data
    * @return derived HWObject from the mapper which holds the corresponding HW address
    * @classification public use, call
    */
  virtual HWObject*            findHWAddr(HWObject* adrObj);

  /** This function returns a given entry in the HW list sorted by periph
    * address.
    * @param adrObj HWObject which holds the periph address for outgoing data
    * @return the HWObject at the specified position (first)
    */
  virtual HWObject *             getFirstHWAdrMatch(HWObject *adrObj);

   /** This function returns a given entry in the HW list sorted by periph
    * address.
    * @param adrObj HWObject which holds the periph address for outgoing data
    * @return the HWObject at the specified position (next)
    */
   virtual HWObject *             getNextHWAdrMatch(HWObject *adrObj);

  /** Search first index for hardware components according to given hardware address.
    * This function uses the compare_HWcomponent() function.
    * @param hwAdr derived HWObject containing a valid hardware address
    * @return index of first stored HWObject for this hardware component
    * @classification ETM internal
    */
  virtual HWObject *             getFirstComponentMatch(HWObject *hwAdr);

  /** Search first index for hardware components according to given hardware address.
    * This function uses the compare_HWcomponent() function.
    * @param hwAdr derived HWObject containing a valid hardware address
    * @return index of next stored HWObject for this hardware component
    * @classification ETM internal
    */
  virtual HWObject *             getNextComponentMatch(HWObject *hwAdr);

  /** Search first index for hardware components according to given hardware address.
    * This function uses the compare_HWcomponent2() function.
    * @param hwAdr derived HWObject containing a valid hardware address
    * @return index of first stored HWObject for this hardware component
    * @classification ETM internal
    */
  virtual HWObject *             getFirstComponent2Match(HWObject *hwAdr);

  /** Search first index for hardware components according to given hardware address.
    * This function uses the compare_HWcomponent2() function.
    * @param hwAdr derived HWObject containing a valid hardware address
    * @return index of next stored HWObject for this hardware component
    * @classification ETM internal
    */
  virtual HWObject *             getNextComponent2Match(HWObject *hwAdr);

  /** Search first hardware components according to given connection id.
    * @param hwAdr derived HWObject containing a valid connection id
    * @return first stored HWObject for this hardware component
    * @classification ETM internal
    */
  virtual HWObject *             getFirstConnectionMatch(HWObject *hwAdr);

  /** Search next hardware components according to given connection id.
    * @param hwAdr derived HWObject containing a valid connection
    * @return next stored HWObject for this hardware component
    * @classification ETM internal
    */
  virtual HWObject *             getNextConnectionMatch(HWObject *hwAdr);

  /** Get the number of stored datapoints.
    * @return number of datapoints in mapper
    * @classification public use, call
    */
  virtual PVSSlong             getNumberOfDpIds() const;

  /** Get the config for a specific DpIdentifier
    * @param dpId is a DpIdentifier.
    * @return config on that index or 0 if dpId was not found
    * @classification public use, call
    */
  virtual PeriphAddr*          getConfigPtr(DpIdentifier const &dpId);

  /** The purpose of this function is the adjustment of the transformation objects
    * to match either the HWObject side or the pvss2 side type of the data to transform.
    * It is also used to check whether or not a specific periph address or hardware address is known
    * by the driver.
  * The third purpose is to adjust a newly created HWObject with the preset values
    * from the HWObject template in the mapper (i.e. datalen, nofElements, periphAddr,...)
    * @param dpId the datapoint concerned
    * @param confPtr pointer to the config with actual subix
    * @param hwaPtr pointer to HWObject which should contain the data
    * @param fConfPtr pointer to the config with subix 0
    * @return PVSS_TRUE if object is found and adjustment was succesful, otherwise PVSS_FALSE
    * @classification public use, overload
    */
  virtual PVSSboolean  actualize(DpIdentifier& dpId, PeriphAddr *confPtr, HWObject *hwaPtr, PeriphAddr *fConfPtr);

  /** When a datapoint is deleted, his config entries are removed, too.
    * @param dpNum the internal datapoint number
    * @classification ETM internal
    */
  virtual void  deleteDpPaByDpNumber(const DpIdType &dpNum);

  /** Print all registered HWObjects
    * @classification public use, call
    */
  virtual void  debugPrintHWObjects();

  /** Print all registered HWMapDpPa objects
      @classification public use, call
  */
  virtual void  debugPrintHWMapDpPa();

  /** Loop through existing names, compare with mask,
    * create a DynVar of DpIdentifierVar objects and send it to periphaddr diagnosis answer dpId
    * @param pa mask for comparison
  */
  virtual void reportDpPa(const CharString & pa);

  /** Loop through existing names, compare with mask,
    * create a DynVar of DpIdentifierVar objects and send it to HWaddr diagnosis answer dpId
    * @param pa mask for comparison
  */
  virtual void reportHWObjects(const CharString & pa);

  /** Return the first peripheral address object matching the mask
    * @param mask mask for comparison
    * @param conn optional connection id
    * @return pointer to the first found peripheral address
  */
  virtual PeriphAddr *getFirstHWMatch(const char * mask, DpIdType conn = 0);

  /** Return the next perip address object matching the mask
    * @param mask mask for comparison
    * @param conn optional connection id
    * @return pointer to the next found perip address
    */
  virtual PeriphAddr *getNextHWMatch (const char * mask, DpIdType conn = 0);

  /** Compare two HW objects;
    * the comparison looks at the hardware address.
    * This function has to be overloaded for derived drivers.
    * @param obj1 first HW object
    * @param obj2 second HW object
    * @return -1 if o1 < o2, 0 if o1 == o2 or +1 if o1 > o2
    * @classification public use, overload
    */
  virtual int compare_HWHW(const HWObject* obj1, const HWObject* obj2);

  /** Compare two HW objects.
    * The comparison looks at the component specific part of hardware address.
    * this function has to be overloaded for derived drivers.
    * @param obj1 first HW object
    * @param obj2 second HW object
    * @return -1 if o1 < o2, 0 if o1 == o2 or +1 if o1 > o2
    * @classification public use, overload
    */
  virtual int compare_HWcomponent(const HWObject* obj1, const HWObject* obj2);

  /** Compare two HW objects - second version of compare_HW_component function.
    * The comparison looks at the component specific part of hardware address.
    * this function has to be overloaded for derived drivers.
    * @param obj1 first HW object
    * @param obj2 second HW object
    * @return -1 if o1 < o2, 0 if o1 == o2 or +1 if o1 > o2
    * @classification public use, overload
    */
  virtual int compare_HWcomponent2(const HWObject* obj1, const HWObject* obj2);
  
  /** Report relevant data of the HWObjects in the HWMapper
    * @classification public use, overload
    */
  virtual void reportStatus(std::ostream &os, bool shortForm = false);

protected:

  /** Compare the periphAdr string against a pattern (a string with wildcards).
    * This function is used in getFirstHWMatch and getNextHWMatch.
    * You may use PatternMatch::patternMatch to perform the actual match.
    * @param ptr The HWMapDpPa object with the PeriphAddr config
    * @param pattern The pattern to match against
    * @return PVSS_TRUE if the pattern matches, else PVSS_FALSE
    * @classification public use, overload
    */
  virtual PVSSboolean  compare_PaMatch(HWMapDpPa *ptr, const char *pattern);

  /** Compare the address string in a HWObject against a pattern (a string
    * with wildcards). This function is used in reportHWObjects.
    * You may use PatternMatch::patternMatch to perform the actual match.
    * @param ptr The HWObject to be compared
    * @param pattern The pattern to match against
    * @return PVSS_TRUE if the pattern matches, else PVSS_FALSE
    * @classification public use, overload
    */
  virtual PVSSboolean  compare_HWMatch(HWObject *ptr, const char *pattern);

  /** compare the connectionIds
    * the comparison looks at the component specific part of hardware address.
    * this function has to be overloaded for derived drivers.
    * @param obj1 first HW object
    * @param obj2 second HW object
    * @return -1 if o1 < o2, 0 if o1 == o2 or +1 if o1 > o2
    * @classification public use, overload
    */
  virtual int compare_connection(const HWObject* obj1, const HWObject* obj2);

  /** Get number of address HWObjects in the HWMapper
    * @return count of address HWObjects in the HWMapper
  */
  virtual PVSSlong getHwaCnt();

  protected:

    // this is a special function for the simulator for testing purposes only
    HWHWSET &getHWSet() { return hwo_hw_set; }

  private:

      // HWMapDpPa nach DP
      DPSET dp_set;
      // HWMapDpPa nach PA
      PASET ad_set;

      // iterators
      DPSET_Iterator lastDPSearch;    // for HWMapDpPa * getFirstMatch(const DpIdentifier &dpId);
      DPSET_Iterator lastDPPA;        // for HWMapDpPa * getFirstDpPa();
      PASET_Iterator lastADSearch;    // for HWMapDpPa * getFirstMatch(HWObject *hwAdr);
      PASET_Iterator lastPASearch;    // for HWMapDpPa * getFirstHWMatch(const char *mask);

      // HWObject nach PA
      HWADSET hwo_ad_set;
      // HWObject nach HW
      HWHWSET hwo_hw_set;

      HWHWSET_Iterator  lastHWAdrSearch;       // for HWObject * getFirstHWObjMatch(HWObject *hwAdr);
      HWHWSET_Iterator  lastHWAdrIndex;        // for HWObject * getFirstHWObj();

      HWADSET_Iterator  lastPeriphAdrSearch;   // for HWObject * getFirstHWAdrMatch(HWObject *hwAdr);
      HWADSET_Iterator  lastConnectionSearch;  // for HWObject * getFirstConnectionMatch(HWObject *hwAdr);

      HWHWSET_Iterator  lastComponentSearch;   // for HWObject * getFirstComponentMatch(HWObject *hwAdr);
      HWHWSET_Iterator  lastComponent2Search;  // for HWObject * getFirstComponent2Match(HWObject *hwAdr);
};


#endif
