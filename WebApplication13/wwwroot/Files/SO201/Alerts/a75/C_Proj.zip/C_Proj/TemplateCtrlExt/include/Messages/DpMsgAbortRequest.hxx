// DATEIBESCHREIBUNG ==============================================================
// DATEINAME:		  DpMsgAbortRequest.hxx
// VERANTWORTUNG: Walter Fasching
//
// BESCHREIBUNG:	DpMsgAbortRequest class is used for aborting query requests
//                for historical data when "message splitting" is used.

#ifndef _DPMSGABORT_H_
#define _DPMSGABORT_H_

#include <DpMsg.hxx>

class DLLEXP_MESSAGES DpMsgAbortRequest : public DpMsg
{
  public:

    /// Default constructor.
    DpMsgAbortRequest();
    /// Copy constructor.
    DpMsgAbortRequest(const DpMsgAbortRequest &rVal);
    /// Destructor.
    ~DpMsgAbortRequest();

    /// Write the instance into the itcNdrUbSend stream.
    friend DLLEXP_MESSAGES itcNdrUbSend &operator<<(itcNdrUbSend &ndrStream, const DpMsgAbortRequest &msg);
    /// Read the instance from the itcNdrUbReceive stream.
    friend DLLEXP_MESSAGES itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream, DpMsgAbortRequest &msg);
    /// Comparison operator.
    int operator==(const DpMsgAbortRequest &rVal) const;
    /// Comparison operator.
    int operator==(const Msg &rVal) const;
    /// Assignment operator.
    DpMsgAbortRequest &operator=(const DpMsgAbortRequest &rVal);
    /// Assignment operator.
    Msg &operator=(const Msg &rVal);

    /// Get own type.
    MsgType isA() const { return DP_MSG_ABORT_REQUEST; }
    /// Check if own type matches other type.
    MsgType isA(MsgType dpMsgType) const { return (dpMsgType == DP_MSG_ABORT_REQUEST ? dpMsgType : DpMsg::isA(dpMsgType)); }
    /// Get flag indicating whether answer is required.
    PVSSboolean needsAnswer() const { return PVSS_FALSE; }
    /// Create new instance.
    virtual Msg *allocate() const { return new DpMsgAbortRequest; }
    /** Get number of groups.
        This always returns 1.
        */
    virtual PVSSulong getNrOfGroups() const { return 1; }
    /** Print the contents of the list to an output stream.   
      Level controls the amount of debug information printed and shall be > 0.
    */
    virtual void debug(std::ostream &to, int level) const;

    /// Set the original message id identifying the request to abort.
    void setRelatedOrigMsgId(PVSSulong msgId) { relatedOrigMsgId = msgId; }
    /// Get the original message id identifying the request to abort.
    PVSSulong getRelatedOrigMsgId() const { return relatedOrigMsgId; }

  protected:
    /// Write the instance into the itcNdrUbSend stream.
    virtual void outNdrUb(itcNdrUbSend &ndrStream) const;
    /// Read the instance from the itcNdrUbReceive stream.
    virtual void inNdrUb(itcNdrUbReceive &ndrStream);

  private:
    // Original message id identifying the request to abort.
    PVSSulong relatedOrigMsgId;

    friend class UNIT_TEST_FRIEND_CLASS;
};


#endif /* _DPMSGABORT_H_ */
