#ifndef _LANGUAGE_FALLBACK_TABLE_H_
#define _LANGUAGE_FALLBACK_TABLE_H_

#include <map>
#include <vector>

#ifdef QT_NAMESPACE
namespace QT_NAMESPACE
{
  class QMutex;
};

using QT_NAMESPACE::QMutex;
#else
class QMutex;
#endif

#ifndef _TYPES_HXX_
#include <Types.hxx>
#endif

#include <set>

typedef std::vector<GlobalLanguageIdType> LanguageFallbackRec;
//typedef DynPtrArray<GlobalLanguageIdType> LanguageFallbackRec;

// ========== LanguageFallbackTable ====================================================
/** Language Fallback Table
 *  Stores a language fallback record for each project language in a high-performance cache
 *  initialized at start-up in Resources. Additional languages are stored in a thread-safe
 *  low-performance cache.
 *
 *  @threadsafe
 *  @classification: internal
 */
class LanguageFallbackTable
{
  public:
    LanguageFallbackTable();

     ~LanguageFallbackTable();

    /** Initialize table
     */
    void init(const std::vector<GlobalLanguageIdType> &defaultLangIds);

    /** Clear table
     */
    void clear();

    /** Retrieve a language fallback record for a language from the cache.
     *  If not found, add one to the additional low-performance cache.
     *  @param glid Global language ID of the language
     *  @return Pointer to the language fallback record
     */
    LanguageFallbackRec getLanguageFallbackRec(const GlobalLanguageIdType &glid);

  protected:

    typedef std::map<GlobalLanguageIdType, LanguageFallbackRec> LanguageFallbackMapType;

    /** helper function for initFallbackLangTable.
     *  returns the next global language ID for a given ID
     *  where only the region is different.
     *  @param langId global language ID for which to search
     *  @param returnId the result if any
     *  @param idx [IN]  index within global language table to start the search.
     *             [OUT] index within global language table of found language if any.
     *  @return PVSS_TRUE if language found
     */
    static PVSSboolean getOtherTerritory(
        GlobalLanguageIdType langId,
        GlobalLanguageIdType &returnId,
        const std::vector<GlobalLanguageIdType> &allLangs,
        std::vector<GlobalLanguageIdType>::iterator &idx);

    /** helper function for initFallbackLangTable.
    *  returns the next global language ID for a given ID
    *  where only the encoding is different.
    *  @param langId global language ID for which to search
    *  @param returnId the result if any
    *  @param idx [IN]  index within global language table to start the search.
    *             [OUT] index within global language table of found language if any.
    *  @param territoryIndependent: get the terretory independent language e.g. en
    *  @return PVSS_TRUE if language found
    */
    static PVSSboolean getOtherEncodedLang(
      GlobalLanguageIdType langId,
      GlobalLanguageIdType &returnId,
      const std::vector<GlobalLanguageIdType> &allLangs,
      std::vector<GlobalLanguageIdType>::iterator &idx);

    /** fills the result with a pointer to a language fallback table
     *  for a given global language ID.
     *  The algorithm which languages to add to the fallback table:
     *  1. the given language/region/encoding
     *  2. the same language/region, but different encoding
     *  3. the same language/encoding, but different region
     *  4. the same language, but different region/encoding
     *  5. the same encoding, but en_US (if not yet added)
     *  6. en_US and different encoding (if not yet added)
     *  7. de_AT.iso88591 (if not yet added)
     *  @param res the result
     *  @param searchLang global language ID for which to build the fallback table
     *  @return PVSS_TRUE if OK
     */
    static PVSSboolean initFallbackLangTable(
        std::vector<GlobalLanguageIdType> &res,
        GlobalLanguageIdType searchedLang);

    /** Look up a language fallback record for a language in the primary cache.
     *  If not found, it also searches the additional low-performance cache.
     *  @param glid Global language ID of the language
     *  @return Pointer to the language fallback record if cached, otherwise 0
     */
    LanguageFallbackRec find(const GlobalLanguageIdType &glid) const;

    /** Look up a language fallback record for a language in the cache for
     *  additional languages.
     *  @param glid Global language ID of the language
     *  @return Pointer to the language fallback record if cached, otherwise 0
     */
    LanguageFallbackRec findInAddendum(const GlobalLanguageIdType &glid) const;

    LanguageFallbackMapType addendum; // cache for languages
    QMutex* mutex;  // Mutex to protect the low-performance cache
    bool initialized; // Prevents use of an uninitialized language fallback table
};

#endif  // _LANGUAGE_FALLBACK_TABLE_H_
