#ifndef _IFSMENT_H_
#define _IFSMENT_H_

#include <CtrlSment.hxx>

class CtrlExpr;


/*  author VERANTWORTUNG: Martin Koller */
/** "if" Statement         */
class DLLEXP_CTRL IfSment : public CtrlSment
{
  public:
    /// wird vom YACC auf gerufen. "line" ist ZeilenNr von keyword "if"
    IfSment(int line, int filenum)
      :CtrlSment(line, filenum),
      elseLineNo(-1),
      expr(0),
      thenBranch(0),
      elseBranch(0) {}

    virtual ~IfSment();

    void setExpr(CtrlExpr *theExpr) { expr = theExpr; }
    void setThen(CtrlSment *list) { thenBranch = list; }
    void setElse(CtrlSment *list) { elseBranch = list; }

    void setElseLineNumber(int line) { elseLineNo = line; }

    virtual void setNext(CtrlSment *n);

    /** Wertet if(cond) aus und returns abhaengig davon das naechste CtrlSment.
      * (then zweig, else zweig oder das Statement nach dem IF)
      */
    virtual const CtrlSment *execute(CtrlThread *thread) const;

    virtual const CtrlExpr *getFirstExpr(CtrlThread *thread) const;

    /// Gewichtung des CtrlSment
    virtual SmentWeight getWeight() const { return SM_WT_Low; }

    virtual void writeTrace(CtrlThread *thread, bool writeValue = true) const;

    virtual bool checkIntegrity(const CharString &location, CtrlThread *) const;

    /// Evaluate the type of this statement. Returns 1 if type is SMENT_IF
    virtual int isA(SmentType type) const { return (type == SMENT_IF); }

    /** dump the whole tree for code coverage analysis
        @param to output stream
      */
    virtual void dumpCoverageTree(std::ostream &to, CoverageAction action = DUMP) const;

  private:
    int elseLineNo;
    CtrlExpr  *expr;
    CtrlSment *thenBranch;
    CtrlSment *elseBranch;

    friend class EditorWidget;
};

#endif /* _IFSMENT_H_ */
