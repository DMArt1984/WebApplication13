#ifndef  STATISTICTIMER_H
#define  STATISTICTIMER_H
//COVINFO FILE: obsolete (actually: not yet used in WinCC OA, dhoegerl)
#include <DrvTimer.hxx>
#include <HmiConnection.hxx>
#include <HmiConnectionStatistics.hxx>

class HmiConnection;
class HmiConnectionStatistics;

class StatisticTimer : public DrvTimer
{
public:

  StatisticTimer() { };

  virtual ~StatisticTimer() { };

  typedef void (*updateStatsCBType)(HmiConnection*);  

  void regCallBack(updateStatsCBType Fname, HmiConnection *hmiConn);

  bool isStatRunning() { return isRunning(); }

private:

  void updateStatsUsingCB(); 

  void timerExpired() override;

  void updateCOV();

  updateStatsCBType m_funcName; 
  HmiConnection* m_funcArgs;

};

#endif
