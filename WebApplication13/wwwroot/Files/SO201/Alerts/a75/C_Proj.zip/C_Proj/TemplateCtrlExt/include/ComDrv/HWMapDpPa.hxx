// DATEIBESCHREIBUNG ==============================================================
// DATEINAME:  HWMapDpPa.hxx
//        Speicherklasse fuer Objekt mit Zeiger auf Peripherieadressen-
//              config und DpIdentifier (fuer Tabelle in HWMapper die interne
//              Verbindung (String) zwischen Hardware-Adresse und Datenpunkt
//              herstellt.


#ifndef _HWMAPPADP_H_
#define _HWMAPPADP_H_

#ifndef _RESOURCES_H_
#include <Resources.hxx>
#endif

#ifndef _DPPERIPHADDR_H_
#include <PeriphAddr.hxx>
#endif

#ifndef _DPIDENTIFIER_H_
#include <DpIdentifier.hxx>
#endif

#ifndef _TIMEVAR_H_
#include <TimeVar.hxx>
#endif

#include <Allocator.hxx>

/** This struct is a short version of the DpIdentifier used ComDrv internally to save memory space 
*/
struct DpIdShort
{
  /// the DpIdentifier DP part
  DpIdType dpId_;          // DP of identifier
  /// the DpIdentifier EL part
  DpElementId elId_;       // EL of identifier

  /// Own allocations depending on USE_OWN_ALLOCATOR
  AllocatorDecl;

  /// default constructor
  DpIdShort() : dpId_(0), elId_(0) {}
  /// constructor for DpIdentifier
  DpIdShort(const DpIdentifier &id) { dpId_ = id.getDp();  elId_ = id.getEl(); }

  /// assignment of DpIdentifier
  const DpIdShort &operator =(const DpIdentifier &id) { dpId_ = id.getDp(); elId_ = id.getEl(); return *this; }
};

/// Less-than operator 
inline bool operator <(const DpIdShort &p1, const DpIdShort &p2)
{
    return ((p1.dpId_ < p2.dpId_) || ((p1.dpId_ == p2.dpId_) && (p1.elId_ < p2.elId_)));
}

/// Equal-to operator 
inline bool operator ==(const DpIdShort &p1, const DpIdShort &p2)
{
  if (p1.dpId_ != p2.dpId_) return false;
  if (p1.elId_ != p2.elId_) return false;

  return true;
}

/** The DpIdentifier PeriphAddr connection. This class incorporates the connection between 
  * datapoints and PeriphAddr configs.
  * @classification ETM internal
  */

// dpIdentifier can be stored in an easy way:
// just keep DpId, ElId and DpTypeId
// systemId is always local
// config is _periphAddrMain
// attribute is _type

class HWMapDpPa
{
 public:
   /** Constructor
     * @param dpId dp identifier
   * @param confPtr pointer to PeriphAddr configs
   */
   HWMapDpPa(const DpIdentifier &dpId, PeriphAddr *confPtr);

   /** Destructor
     */ 
  ~HWMapDpPa() { /* delete confPtr; */ }

//   DpIdentifier& getDpIdentifier() {return dpId;}
//   const DpIdentifier &getDpIdentifier() const {return dpId;}

  /** Sets system, DP, element, DP type, config, attribute, detail  
    * by ext dp identifier.
  * @param extDpId ext dp identifier
    */
  void getDpIdentifier(DpIdentifier &extDpId) const;
   // Leider nicht const, weil andere Funktionen den Inhalt aendern.
   // Auf das Objekt selbst hat das jedoch keinen Einfluss

   /** Gets the pointer to the configuration
     * @return the pointer to configuration
   */ 
   PeriphAddr* getConfigPtr()         {return confPtr;}

   /** Gets the pointer to the configuration
     * @return the pointer to configuration
   */ 
   const PeriphAddr *getConfigPtr() const {return confPtr; }

   /** Gets the datapoint number of the pollgroup dp
     * @return the dp number
   */ 
   DpIdType getPollGroupId() const { return (confPtr) ? confPtr->getPollGroupId() : (DpIdType)0; }

   /// Internal use
   DpIdType getDp() const { return myDp.dpId_; }
   DpTypeId getDpType() const { return theType; }
   DpElementId getEl() const { return myDp.elId_; }

  private:

    // DpIdentifier dpId;
    DpIdShort    myDp;
    DpTypeId     theType;

    PeriphAddr  *confPtr;
};


inline  HWMapDpPa::HWMapDpPa(const DpIdentifier &dpId, PeriphAddr *conf)
  : confPtr(conf)
{
    myDp.dpId_ = dpId.getDp();    // keep this for inline optimization
    myDp.elId_ = dpId.getEl();
    theType = dpId.getDpType();
}

inline void HWMapDpPa::getDpIdentifier(DpIdentifier &extDpId) const
{
    extDpId.setSystem(Resources::getSystem());
    extDpId.setDp(myDp.dpId_);
    extDpId.setEl(myDp.elId_);
    extDpId.setDpType(theType);
    extDpId.setConfig(DPCONFIGNR_PERIPH_ADDR_MAIN);
    extDpId.setAttr(0);
    extDpId.setDetail(0);
}

#endif
