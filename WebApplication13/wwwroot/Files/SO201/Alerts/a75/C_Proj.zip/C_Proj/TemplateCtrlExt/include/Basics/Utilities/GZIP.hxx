
// Deflate and inflate data in the gzip format

#include <stdlib.h>
#include <zlib.h>

#include <Types.hxx>

// PVSS version dependent modifiers for GZIP class
#if PVSS_VERS < 305000
#define GZIP_MODIFIERS
#else
#define GZIP_MODIFIERS DLLEXP_BASICS
#endif
/** Provides a simple-to-use interface to the data compression functionality
 *  of the <tt>zlib</tt> library
 * @see GUNZIP for data decompression
 */
class GZIP_MODIFIERS GZIP
{
  friend class UNIT_TEST_FRIEND_CLASS;

  public:
    /// Compresses data. The result is availabe immedately, no data shall be appended.
    GZIP(const char * data, size_t len);

    /** Convenience constructor to avoid casting from unsigned to signed,
     *  equal to GZIP::GZIP(const char*, size_t)
     */
    GZIP(const unsigned char *data, size_t len);

    /// Default constructor, data may be appended via deflate()
    GZIP();

    /** Construct with specified parameters, data may be appended via deflate()
     * @see zlib documentation for specific values
     */
    GZIP(int level, int method, int windowBits, int memLevel, int strategy);

    /// Destructor
    ~GZIP();

    /// Compresses the data and appends it to the internal buffer.
    void deflate(const char *data, size_t len);

    /** Convenience method to avoid casting from unsigned to signed,
     *  equal to GZIP::deflate(const char*, size_t)
     */
    void deflate(const unsigned char *data, size_t len) 
    { deflate( (const char *) data, len ); }

    /// Finishes compression. No data shall be appended after that call.
    void finish();

    /// Reset internal state. The object is then equal to a newly constructed one.
    void reset();

    /** Set compression level and strategy
     * @see zlib documentation for specific values
     */
    void setParams(int level, int strategy);

    /** Get the result buffer. A string would be 0-terminated.
     *  The data might be incomplete until finish() was called
     * @return the result buffer
     */
    const char *getResultPtr() const;

    /** Cut the result buffer out. The allocated size is at least 2 bytes more than getLen().
     *  finish() has to be called before cutting the result buffer
     * @return the result buffer, you have to manage it
     */
    char * cutResultPtr();

    /** Get the (current) length of the compressed data. At least 2 bytes more are allocated.
     * A correct length might not be available until finish() was called
     * @return the (current) length of the compressed data
     */
    size_t getLen() const;

    /** Get the error code. Return >= 0 if there was no error.
     * @see zlib documentation for specific error codes
     */
    int getErrorCode() const;

    /** Get the error message or 0 if there is no error.
     * @see zlib documentation for specific error messages
     */
    const char *getErrorMsg() const;

    /// Check if no error was produced by the last action performed
    PVSSboolean wasOK() const;

  private:
    void     init();
    void     init(int level, int method, int windowBits, int memLevel, int strategy);
    int      ret;
    unsigned crc;
    z_stream strm;
};
#undef GZIP_MODIFIERS  // restrict modifiers of GZIP class to the class definition

// PVSS version dependent modifiers for GUNZIP class
#if PVSS_VERS < 305000
#define GUNZIP_MODIFIERS
#else
#define GUNZIP_MODIFIERS DLLEXP_BASICS
#endif
/** Provides a simple-to-use interface to the data decompression functionality
 *  of the <tt>zlib</tt> library
 * @see GZIP for data compression
 */
class GUNZIP_MODIFIERS GUNZIP
{
  friend class UNIT_TEST_FRIEND_CLASS;

  public:
    /// Uncompresses data. The result is available immediately, no data shall be appended.
    GUNZIP(const char *data, size_t len);

    /** Convenience constructor to avoid casting from unsigned to signed,
     *  equal to GUNZIP::GUNZIP(const char*, size_t)
     */
    GUNZIP(const unsigned char *data, size_t len);

    /// Default constructor, data may be appended via inflate()
    GUNZIP();

    /** Construct with specified parameters, data may be appended via inflate()
     * @see zlib documentation for specific values
     */
    GUNZIP(int windowBits);

    /// Destructor
    ~GUNZIP();

    /// Decompresses the data and appends it to the internal buffer
    void inflate(const char *data, size_t len);

    /** Convenience method to avoid casting from unsigned to signed,
     *  equal to GUNZIP::inflate(const char*, size_t)
     */
    void inflate(const unsigned char *data, size_t len)
    { inflate( (const char *) data, len ); }

    /// Finishes decompression. No data shall be appended after that call.
    void finish();

    /// Reset internal state. The object is then equal to a newly constructed one.
    void reset();

    /** Get the result buffer. A string would be 0-terminated.
     *  The data might be incomplete until finish() was called
     * @return the result buffer
     */
    const char *getResultPtr() const;

    /** Cut the result buffer out. The allocated size is at least 2 bytes more than getLen().
     *  finish() has to be called before cutting the result buffer
     * @return the result buffer, you have to manage it
     */
    char * cutResultPtr();

    /** Get the (current) length of the decompressed data. At least 2 bytes more are allocated.
     *  A correct length might not be available until finish() was called
     * @return the (current) length of the decompressed data
     */
    size_t getLen() const;

    /** Get the error code. Return >= 0 if there was no error.
     * @see zlib documentation for specific error codes
     */
    int  getErrorCode() const;

    /** Get the error message or 0 if there is no error.
     * @see zlib documentation for specific error messages
     */
    const char *getErrorMsg() const;

    /// Check if no error was produced by the last action performed
    PVSSboolean wasOK() const;

  private:
    void     init();
    void     init(int windowBits);
    void     checkHeader();
    int      ret;
    unsigned crc;
    z_stream strm;
};
#undef GUNZIP_MODIFIERS  // restrict modifiers of GUNZIP class to the class definition
