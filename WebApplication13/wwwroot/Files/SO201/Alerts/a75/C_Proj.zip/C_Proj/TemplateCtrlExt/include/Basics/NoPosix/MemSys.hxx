#ifndef _MEMSYS_H_
#define _MEMSYS_H_

/*
VERANTWORTUNG: Laszlo Szakony
BESCHREIBUNG: Speicherverwaltung + info
*/

#include <Types.hxx>

#include <iostream>


/** the memory system wrapper.
  * Use this class to:
  * <ul>
  *   <li> get info about the memory behavior and CPU state;
  *   <li> to set allocation strategy, when supported.
  * </ul>
*/
class DLLEXP_BASICS MemSys
{
  public:
    /// Information about the memeory.
    struct MemorySystemStatus
    {
        /// total size of the memory in kilobytes
        size_t    totalKBytes;
        /// size of free memory in kilobytes
        size_t    freeKBytes;
        /// size of available memory for non-superuser in kilobytes
        size_t    availKBytes;
    };

  public:
    /// write memory statistics to the given ostream
    ///   @param to the stream to write the report to.
    /// @osdiff The content of the report depends on the OS.
    static void reportHeap(std::ostream &to);

    /// write CPU statistics to the given ostream
    ///   @param to the stream to write the report to.
    /// @osdiff The content of the report depends on the OS.
    static void reportCPU(std::ostream &to);

    /// set an allocation strategy for malloc(), when supported for the OS.
    ///   @param options the os depented representation of
    ///                  the allocation strategy.
    /// @osdiff Does nothing enxcept for OS_HPUX.
    ///         On OS_HPUX the options must contain two integers.
    ///         The first is the value for M_MXFAST.
    ///         The second is the value for M_NLBLKS.
    static void adjustAllocator(const char *options);

    /// Get memory information
    ///    @return true when all fields hold a valid value, false otherweise.
    static PVSSboolean memInfo(MemorySystemStatus &stat);

  private:
    // so that the compiler does not define them itself !!

    /// constructor
    MemSys();

    // copy constructor
    MemSys(const MemSys &) {}  //COVINFO LINE: defensive (AP: disallow copy ctor)

    // assignment operator
    MemSys &operator=(const MemSys &) { return *this; }  //COVINFO LINE: defensive (AP: disallow =operator)
};

#endif /* _MEMSYS_H_ */
