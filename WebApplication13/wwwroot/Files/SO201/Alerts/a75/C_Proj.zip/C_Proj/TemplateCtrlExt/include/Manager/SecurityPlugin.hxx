#ifndef _SECURITYPLUGIN_H_
#define _SECURITYPLUGIN_H_

#include <Types.hxx>
#include <SystemNumType.hxx>
#include <ViewId.hxx>
#include <ManagerIdentifier.hxx>
#include <CNSObserver.hxx>
#include <CommonNameService.hxx>

// forward declaration
class SecurityPlugin;
class MsgGroupIterator;
class DpIdentifier;
class DpIdentList;
class ResourceMap;


#ifdef WIN32
#  define SECURITY_PLUGIN_EXPORT  __declspec(dllexport)
#else
#  define SECURITY_PLUGIN_EXPORT
#endif

/**
 * Defines the functions that are necessary to load a security plugin.
 * - newSecurityPlugin() creates a new instance of the security plugin.
 * - getVersionString() returns the WinCC OA version the plugin was compiled for.
 *
 * @param CLASS The name of your security plugin class.
 */
#define SECURITY_PLUGIN(CLASS) extern "C" \
      { \
        SECURITY_PLUGIN_EXPORT SecurityPlugin *newSecurityPlugin() \
        { \
          return new CLASS(); \
        } \
        \
        SECURITY_PLUGIN_EXPORT const char *getVersionString() \
        { \
          return PVSS_VERS_DLL; \
        } \
      }


/**
 * The abstract base class for a Security Plugin.
 *
 * It defines several security callback methods which are invoked for
 * some functions (Ctrl and API) and allow restricting or denying
 * access to datapoints, alerts and CNS elements.
 *
 * For details on which functions are handled and how they can be
 * influenced, see the various permitted()-methods.
 *
 * For permitted()-methods which return ErrClass objects, the following
 * values are recommended for the error:
 * - ErrType: ERR_PARAM, ERR_SYSTEM
 * - ErrPrio: PRIO_SEVERE, PRIO_WARNING, PRIO_INFO
 */
class DLLEXP_MANAGER SecurityPlugin 
{
public:

  /// A typedef for the newSecurityPlugin() factory function
  typedef SecurityPlugin *(*newSecurityPluginFunction)();

  /// A typedef for the getVersionString() function
  typedef const char *(*getVersionStringFunction)();

  /**
   * Specifies the function that triggered a call to permitted().
   */
  enum SecuredFunction
  {
// DP Access
    DP_GET,
    DP_SET,
    DP_CONNECT,
    DP_QUERY,
    DP_QUERY_CONNECT,
    DP_GET_PERIOD,
    DP_GET_ASYNC,
// Alert Access
    // DP_QUERY_ALERT is handled as DP_QUERY
    // DP_QUERY_CONNECT_ALERT is handled as DP_QUERY_CONNECT
    ALERT_GET,
    ALERT_SET,
    ALERT_CONNECT,
    ALERT_GET_PERIOD,
// Id
    DP_CREATE,
    DP_DELETE,
    DP_RENAME,
    // DP_EXISTS is handled as GET_ID
    GET_ID,
    GET_NAME,
    GET_ID_SET,
    DP_SET_ALIAS,
    DP_SET_COMMENT,
    // DP_SET_FORMAT is handled as DP_SET_COMMENT
    // DP_SET_UNIT is handled as DP_SET_COMMENT
    DP_GET_ALIAS,
    DP_GET_COMMENT,
    DP_GET_FORMAT,
    DP_GET_UNIT,
    DP_GET_ALL_ALIASES,
    // DP_GET_ALL_ATTRIBUTES is handled as GET_ID_SET
    // DP_GET_ALL_COMMENTS is handled as GET_ID_SET
// CNS
    CNS_GET_VIEW_ID,
    CNS_GET_VIEWS,
    CNS_GET_VIEW_NAMES,
    CNS_DELETE_VIEW,
    CNS_ADD_TREE,
    // CNS_CHANGE_TREE is handled as CNS_DELETE_TREE and CNS_ADD_TREE
    CNS_DELETE_TREE,
    CNS_GET_TREES,
    CNS_ADD_NODE,
    // CNS_CHANGE_NODE is handled as CNS_DELETE_TREE and CNS_ADD_NODE
    CNS_GET_NODE,
    CNS_GET_NODES,
    CNS_GET_ID_SET,
    CNS_GET_PARENT,
    CNS_GET_ROOT,
    CNS_GET_CHILDREN,
    CNS_OBSERVER_NOTIFICATION,
// NEWDELDPOBSERVER
    NEWDP_OBSERVER_NOTIFICATION,
    DELDP_OBSERVER_NOTIFICATION,
// User
    SET_USER_ID,
    SET_USER_IDSSO
  };

  /// Destructor
  SecurityPlugin();
  /// Destructor
  virtual ~SecurityPlugin();

public:

  // -------------------------------------------------------------------------
  // -- Resource Handling
  // -------------------------------------------------------------------------

  /**
   * The setResource() and the getResource() methods are not called by the Manager Framework.
   * They implement a common storage for the SecurityPlugin and all parties interacting with the SecurityPlugin. 
   */

   /**
   * Set a resource associated with the given key.
   * The SecurityPlugin is responsible for the memory of value.
   * 
   * The given value is added to the Resource map if the key is not found.
   * Because key is unique the value stored along with the given key is deleted and replaced by the new given value, 
   * if the key is already registered.
   * If value is NULL the value associated to the given key will be deleted from the Resource map.
   *
   * @param key     to access value.
   * @param value   Variable to be stored in the Resource map.
   */
  void setResource(const CharString &key, Variable *value);
  
  
  /**
   * Get the resource asscociated with the given key.
   *
   * @param key     to access a resource.
   * @return a const pointer to the resource associated with the given key, else NULL is returned.
   */
  const Variable *getResource(const CharString &key) const;

  // -------------------------------------------------------------------------
  // -- Scope restriction
  // -------------------------------------------------------------------------

  /**
   * This method is called after the plugin has been created, to
   * determine whether it will be used in the current manager.
   *
   * @return If true, the plugin will be used in the current manager,
   *         otherwise it will be deleted.
   */
  virtual bool needsSecurityPlugin(const ManagerIdentifier &manId) const
  {
    return true;
  }

  // -------------------------------------------------------------------------
  // -- Identity Check
  // -------------------------------------------------------------------------

  /**
   * This method is called before connecting to data.
   *
   * It should be used to verify the integrity of this manager and its
   * security relevant libraries.
   *
   * If the integrity check fails, it is recommended to throw an error
   * message through ErrHdl with priority PRIO_FATAL, which will
   * terminate the manager.
   *
   * If the check is successful, the method is expected to return an
   * "identity string" which will be sent to data, where it will be
   * passed to checkIdentity() to verify the integrity of the manager.
   *
   * @return An identity string which is sent to data where
   *         it will be passed to checkIdentity() to verify the integrity
   *         of the manager. If null is returned, the manager will
   *         terminate.
   */
  virtual const char *getIdentity() = 0;

  /**
   * This method is only used by data, which will invoke it for
   * each manager that connects to it.
   *
   * It should be used to check the integrity of the connecting managers.
   * If a call returns false, the connection to the manager which
   * provided the identity string will be closed, thus forcing it to
   * shut down.
   *
   * @param identity The identity string generated by getIdentity() in
   *                 the connecting manager.
   *
   * @return If true is returned, the connecting manager will continue
   *         its initialization, otherwise its connection will be closed,
   *         thus forcing it to shut down.
   */
  virtual bool checkIdentity(const char *identity) = 0;

  // -------------------------------------------------------------------------
  // -- Challenge / Response
  // -------------------------------------------------------------------------


  /**
  * This method is called on Managers with server role before allowing 
  * client connection.
  *
  *   - getChallenge() has to handle several parallel connections 
  *     according ManagerIdentifier 
  *   - getChallenge() could generate a security cryptographically
  *     secure random challenge on the server side
  *
  * @param manId the ManagerIdentifier of the client the connected to the server
  * @param challenge the challenge the client has to answer
  *        empty strings means no validation of client necessary
  *
  * @return result of operation. If FALSE is returned, the connection
  *         will be aborted.
  */
  virtual bool getChallenge(const ManagerIdentifier &manId, CharString &challenge) = 0;

  /**
  * This method is called on Managers with client role before allowing 
  * client connection.
  *
  *   - response could contain version information (response type)
  *   - response should depend on the challenge 
  *   - response could depend on the current customer to protect servers
  *     from connecting clients from other clients
  *   - response could depend on the client system integrity marks. For example
  *     SHA1 signatures of loaded binaries.
  *   - response may be dependent from Id of connected managers
  *   - response should be hashed (one way coding)
  *
  * @param manId the ManagerIdentifier of the server
  * @param challenge the challenge the client has to answer
  * @param response the answer of challenge has to be sent back to server
  *
  * @return result of operation. If FALSE is returned, the connection
  *         will be aborted.
  */
  virtual bool getResponse(const ManagerIdentifier &manId, const CharString &challenge, CharString &response) = 0;

  /**
  * This method is called on Managers with server role before allowing 
  * client connection.
  *
  *   - checkResponse() has to handle several parallel connections 
  *     according ManagerIdentifier
  *   - validation algorithm may be chosen according version information (response type)
  *   - validation could based on compare the hash values. One hash value come
  *     from client, the other one should be calculated on server (one way coding)
  *   - hash value should base on a trustable data store which contains all
  *     information what was used on the client side
  *
  * @param manId the ManagerIdentifier of the server
  * @param response the answer of challenge has to be sent back to server
  * @param newChallenge the other challenge the client has to answer
  *        empty string means the client authentication has finished,
  *        no need for other challenge-response validation
  * 
  * @return result of operation. 
  *         TRUE if and only if validation is successful
  *         FALSE is returned, the connection will be aborted
  */
  virtual bool checkResponse(const ManagerIdentifier &manId, const CharString &response, CharString &newChallenge) = 0;

  // -------------------------------------------------------------------------
  // -- init
  // -------------------------------------------------------------------------

  /**
   * This method is called after the Manager is almost completely
   * initialized by data and event
   * (userTable and license data are not yet available).
   * The Security-Plugin may use it to connect to datapoints
   * or request additional information.
   *
   * It is possible to wait for answers on sent messages by using
   * Manager::dispatch(). Otherwise the answers will already be
   * intercepted by the plugin.
   *
   * After this method returns, all security callbacks will be in effect.
   */
  virtual void init() = 0;

  // -------------------------------------------------------------------------
  // -- Permission checks
  // -------------------------------------------------------------------------

  /**
   * This security callback handles the following functions:
   * - Manager::dpSet
   * - Manager::alertSet
   *
   * It is called before the related message is sent.
   * The message cannot be changed, only denied as a whole.
   *
   * @param it A list of DpIdentifiers given to one of the
   *           aforementioned functions.
   * @param func The function that triggered a call to this method.
   * @param user The user that requested the current operation.
   * @param wait The wait-object of the current operation.
   *
   * @return If null is returned, the operation will proceed as usual,
   *         otherwise the operation will be aborted and the returned
   *         error will be used in the answer given to the wait object.
   */
  virtual ErrClass *permitted(const MsgGroupIterator &it,
                              SecuredFunction func,
                              PVSSuserIdType user,
                              WaitForAnswer *wait) = 0;

  /**
   * This security callback handles the following functions:
   * - Manager::dpRename
   * - Manager::dpCreate
   * - Manager::dpDelete
   * - Manager::setDpAlias
   * - Manager::setDpComment
   *
   * It is called before the related message is sent.
   *
   * It cannot change the passed data, only deny the whole operation.
   *
   * @param dpId A DpIdentifier given to or resulting from one of the
   *             aforementioned functions.
   * @param func The function that triggered a call to this method.
   * @param user The user that requested the current operation.
   * @param wait The wait-object of the current operation.
   *
   * @return If null is returned, the operation will proceed as usual,
   *         otherwise the operation will be aborted and the returned
   *         error will be used in the answer given to the wait object.
   */
  virtual ErrClass *permitted(const DpIdentifier &dpId,
                              SecuredFunction func,
                              PVSSuserIdType user,
                              WaitForAnswer *wait) = 0;

  /**
   * This security callback handles the following functions:
   * - Manager::getId
   * - Manager::getName
   * - Manager::getDpAlias
   * - Manager::dpGetComment
   * - Manager::dpGetUnit
   * - Manager::dpGetFormat
   * - DpIdentification::getAllAliases (called once for each DpIdentifier;
   *                                    remove items by returning false)
   *
   * It cannot change the passed data, only deny the whole operation.
   *
   * @param dpId A DpIdentifier given to or resulting from one of the
   *             aforementioned functions.
   * @param func The function that triggered a call to this method.
   * @param user The user that requested the current operation.
   *
   * @return If true is returned, the operation will proceed as usual,
   *         otherwise the operation will be aborted.
   */
  virtual bool permitted(const DpIdentifier &dpId,
                         SecuredFunction func,
                         PVSSuserIdType user) = 0;

  /**
   * This security callback handles the following functions:
   * - Manager::dpGet
   * - Manager::dpGetPeriod
   * - Manager::dpGetAsync
   * - Manager::dpConnect
   * - Manager::alertGet
   * - Manager::alertGetPeriod
   * - Manager::alertConnect
   *
   * It is called when an answer or hotlink to the function is received.
   *
   * It can remove groups from the passed data, change values of
   * single items, and deny the whole operation.
   *
   * @param it A list of DpIdentifiers resulting from one of the
   *           aforementioned functions.
   * @param func The function that triggered a call to this method.
   * @param user The user that requested the current operation.
   * @param wait The wait-object of the current operation.
   *
   * @return If null is returned, the operation will proceed as usual,
   *         otherwise the operation will be aborted and the returned
   *         error will be used in the answer given to the wait object.
   */
  virtual ErrClass *permitted(MsgGroupIterator &it,
                              SecuredFunction func,
                              PVSSuserIdType user,
                              WaitForAnswer *wait) = 0;

  /**
   * This security callback handles the following functions:
   * - Manager::dpQuery
   * - Manager::dpQueryConnect
   *
   * It can change the passed data as well as
   * denying the whole operation.
   *
   * @param table A dyn_dyn_anytype resulting from one of the
   *              aforementioned functions.
   * @param func The function that triggered a call to this method.
   * @param user The user that requested the current operation.
   * @param wait The wait-object of the current operation.
   *
   * @return If null is returned, the operation will proceed as usual,
   *         otherwise the operation will be aborted and the returned
   *         error will be used in the answer given to the wait object.
   */
  virtual ErrClass *permitted(DynVar &table,
                              SecuredFunction func,
                              PVSSuserIdType user,
                              WaitForAnswer *wait) = 0;

  /**
   * This security callback handles the following functions:
   * - DpIdentification::getIdSet
   *
   * It can remove items from the passed data as well as
   * denying the whole operation.
   *
   * @param list A list of DpIdentifiers resulting from the
   *             aforementioned function.
   * @param func The function that triggered a call to this method.
   * @param user The user that requested the current operation.
   *
   * @return If true is returned, the operation will proceed as usual,
   *         otherwise the operation will be aborted.
   */
  virtual bool permitted(DpIdentList &list,
                         SecuredFunction func,
                         PVSSuserIdType user) = 0;

  /**
   * This security callback handles the following functions
   * - CommonNameService::getViewId
   * - CommonNameService::getViewNames
   *
   * It cannot change the passed data, only deny the whole operation.
   *
   * @param sysId The system id of the affected CNS element.
   * @param viewId The view id of the affected CNS element.
   * @param func The function that triggered a call to this method.
   * @param user The user that requested the current operation.
   *
   * @return If true is returned, the operation will proceed as usual,
   *         otherwise the operation will be aborted.
   */
  virtual bool permitted(SystemNumType sysId,
                         ViewId viewId,
                         SecuredFunction func,
                         PVSSuserIdType user) = 0;

  /**
   * This security callback handles the following functions
   * - CommonNameService::deleteView
   *
   * It cannot change the passed data, only deny the whole operation.
   *
   * @param sysId The system id of the affected CNS element.
   * @param viewId The view id of the affected CNS element.
   * @param func The function that triggered a call to this method.
   * @param user The user that requested the current operation.
   * @param wait The wait-object of the current operation
   *
   * @return If null is returned, the operation will proceed as usual,
   *         otherwise the operation will be aborted and the returned
   *         error will be used in the answer given to the wait object.
   */
  virtual ErrClass *permitted(SystemNumType sysId,
                              ViewId viewId,
                              SecuredFunction func,
                              PVSSuserIdType user,
                              WaitForAnswer *wait) = 0;

  /**
   * This security callback handles the following function
   * - CommonNameService::getViews
   *
   * It can remove items from the passed data as well as
   * denying the whole operation.
   *
   * @param sysId The system id of the affected CNS element.
   * @param viewId The view ids of the affected CNS elements.
   * @param func The function that triggered a call to this method.
   * @param user The user that requested the current operation.
   *
   * @return If true is returned, the operation will proceed as usual,
   *         otherwise the operation will be aborted.
   */
  virtual bool permitted(SystemNumType sysId,
                         ViewIdVector &viewIds,
                         SecuredFunction func,
                         PVSSuserIdType user) = 0;

  /**
   * This security callback handles the following functions
   * - CommonNameService::addTree (called once for the root of the new tree/subtree)
   * - CommonNameService::changeTree (modeled as deleteTree and addTree)
   * - CommonNameService::deleteTree (called once for the root of the tree/subtree)
   * - CommonNameService::addNode
   * - CommonNameService::changeNode (modeled as deleteTree and addNode)
   *
   * It cannot change the passed data, only deny the whole operation.
   *
   * @param sysId The system id of the affected CNS element.
   * @param viewId The view id of the affected CNS element.
   * @param cnsPath The path of the affected CNS element.
   * @param dpId The datapoint stored in the affected CNS node
   *             (might be empty).
   * @param func The function that triggered a call to this method.
   * @param user The user that requested the current operation.
   * @param wait The wait-object of the current operation
   *
   * @return If null is returned, the operation will proceed as usual,
   *         otherwise the operation will be aborted and the returned
   *         error will be used in the answer given to the wait object.
   */
  virtual ErrClass *permitted(SystemNumType sysId,
                              ViewId viewId,
                              const CharString &cnsPath,
                              const DpIdentifier &dpId,
                              SecuredFunction func,
                              PVSSuserIdType user,
                              WaitForAnswer *wait) = 0;

  /**
   * This security callback handles the following functions
   * - CommonNameService::getTrees
   * - CommonNameService::getChildren
   *
   * It can remove items from the passed data as well as
   * denying the whole operation.
   *
   * @param nodes A list of CNSNodes resulting from the
   *              current operation.
   * @param func The function that triggered a call to this method.
   * @param user The user that requested the current operation.
   *
   * @return If true is returned, the operation will proceed as usual,
   *         otherwise the operation will be aborted.
   */
  virtual bool permitted(CNSNodeVector &nodes,
                         SecuredFunction func,
                         PVSSuserIdType user) = 0;

  /**
   * This security callback handles the following functions
   * - CommonNameService::getNode
   * - CommonNameService::getParent (called with the result of getParent)
   * - CommonNameService::getRoot   (called with the result of getRoot)
   * - CommonNameService::getNodes  (called once for each found node;
   *                                remove items by returning false)
   * - CommonNameService::getIdSet  (same as getNodes)
   *
   * It cannot change the passed data, only deny the whole operation.
   *
   * @param node The CNSNode resulting from the current operation.
   * @param func The function that triggered a call to this method.
   * @param user The user that requested the current operation.
   *
   * @return If true is returned, the operation will proceed as usual,
   *         otherwise the operation will be aborted.
   */
  virtual bool permitted(const CNSNode &node,
                         SecuredFunction func,
                         PVSSuserIdType user) = 0;

  /**
   * if a CNSObserver is registered with CommonNameService::addObserver()
   * this security callback is called whenever a CNS notification arrives  
   *
   * It cannot change the passed data, only deny the whole operation.
   *
   * @param sysId The system id of the affected CNS element.
   * @param viewId The view id of the affected CNS element.
   * @param cnsPath The path of the affected CNS element.
   * @param changeType The type of change that is reported to the
   *                   registered CNS observers.
   * @param func The function that triggered a call to this method.
   * @param user The user that requested the current operation.
   *
   * @return If true is returned, the operation will proceed as usual,
   *         otherwise the operation will be aborted.
   */
  virtual bool permitted(SystemNumType sysId,
                         ViewId viewId,
                         const CharString &cnsPath,
                         CNSObserver::CNSChanges changeType,
                         SecuredFunction func,
                         PVSSuserIdType user) = 0;
						 
  /**
   * This security callback handles the following function
   * - Manager::setUserId
   * - Manager::setUserIdSSO
   *
   * It cannot change the passed data, only deny the whole operation.
   *
   * @param newUser The user that will be new.
   * @param func The function that triggered a call to this method.
   * @param user The user that requested the current operation that will be changed.
   *
   * @return If true is returned, the operation will proceed as usual,
   *         otherwise the operation will be aborted.
   */
  virtual bool permitted(PVSSuserIdType newUser,
                         SecuredFunction func,
                         PVSSuserIdType user) = 0;				

private:

  ResourceMap *resources;                         
};


#endif // _SECURITYPLUGIN_H_
