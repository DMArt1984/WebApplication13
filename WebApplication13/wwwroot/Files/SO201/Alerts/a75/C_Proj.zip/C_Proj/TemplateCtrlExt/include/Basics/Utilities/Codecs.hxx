#ifndef _CODECS_HXX_
#define _CODECS_HXX_

#include <CharString.hxx>

#include <Blob.hxx>

#include <string.h>
#include <ctype.h>

/**
 * Handles Base64 encoding/decoding and RFC2396 encoding/decoding
 * (URL encoding).
 */
class  DLLEXP_BASICS Codecs
{
  public:
    /**
     * Encodes the specified c-string to Base64.
     *
     * @remarks The string has to be terminated by a null-character.
     *
     * @param uncoded The string to be encoded. It can contain all
     * bytes from 1 to 255, and has to be terminated by a 0-byte.
     *
     * @return The Base64-encoded string
     */
    static CharString base64Encode(const char *uncoded);

    /**
     * Encodes the specified CharString to Base64.
     *
     * @param uncoded The string to be encoded. It can contain all
     * bytes from 0 to 255.
     *
     * @return The Base64-encoded string
     */
    static CharString base64Encode(const CharString &uncoded);

    /**
     * Encodes the first @p len bytes of the specified string to Base64.
     *
     * @param uncoded The string to be encoded. It can contain all
     * bytes from 0 to 255.
     * @param len The first @p len bytes of @p uncoded will be read for encoding.
     * @param [out] coded Receives the encoded Base64 string
     */
    static void base64Encode(const char *uncoded, size_t len, CharString &coded);

    /**
     * Encodes the specified Blob to Base64.
     *
     * @param uncoded The data to be encoded
     * @param [out] encoded Receives the encoded Base64 string
     */
    static void base64Encode(const Blob &uncoded, CharString &encoded);

    /**
     * Decodes the specified Base64 string.
     *
     * @param encoded The encoded Base64 string. Has to be terminated
     * by a null-character.
     * @param [out] decoded Receives the decoded data.
     *
     * @return True for successful decoding, otherwise false
     * (e.g. for invalid Base64 strings).
     */
    static bool base64Decode(const char *encoded, Blob &decoded);

    /**
     * Decodes the specified Base64 string.
     *
     * @param encoded The encoded Base64 string.
     * @param [out] decoded Receives the decoded data.
     *
     * @return True for successful decoding, otherwise false
     * (e.g. for invalid Base64 strings).
     */
    static bool base64Decode(const CharString &encoded, Blob &decoded);

    /**
     * Decodes the first @p len characters of the specified string
     * from Base64.
     *
     * @param encoded The encoded Base64 string.
     * @param len The number of bytes to be read from @p encoded
     * @param [out] decoded Receives the decoded data.
     *
     * @return True for successful decoding, otherwise false
     * (e.g. for invalid Base64 strings).
     */
    static bool base64Decode(const char *encoded, size_t len, Blob &decoded);

    /**
     * Encodes the specified string to make it usable inside a URL
     * (RFC2396 / URL encoding).
     * It leaves alphanumerics and some special characters unescaped,
     * everything else is encoded in the form "%xx", where xx is a
     * byte in hexadecimal notation.
     *
     * @remarks The specified string has to be terminated by a null-character.
     *
     * @param uncoded The string to be encoded
     *
     * @return The encoded string
     */
    static CharString RFC2396Encode(const char * uncoded);

    /**
     * Encodes the specified string to make it usable inside a URL
     * (RFC2396 / URL encoding).
     * It leaves alphanumerics and some special characters unescaped,
     * everything else is encoded in the form "%xx", where xx is a
     * byte in hexadecimal notation.
     *
     * @param uncoded The string to be encoded
     *
     * @return The encoded string
     */
    static CharString RFC2396Encode(const CharString &);

    /**
     * Decodes the specified string from URL encoding (RFC2396).
     *
     * @remarks The specified string has to be terminated by a null-character.
     *
     * @param encoded The string to be decoded
     *
     * @return The decoded string
     */
    static CharString RFC2396Decode(const char * encoded);

    /**
     * Decodes the specified string from URL encoding (RFC2396).
     *
     * @param encoded The string to be decoded
     *
     * @return The decoded string
     */
    static CharString RFC2396Decode(const CharString &);
};

#endif /* _CODECS_HXX_ */
