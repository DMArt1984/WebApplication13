// DATEIBESCHREIBUNG ==============================================================
// DATEINAME:     DpMsgRequest.hxx
// VERANTWORTUNG: 	WOLFGANG SCHUH + PETER PENTEK
// 
// BESCHREIBUNG:	DpMsgRequest ist eine Abfragemeldung ueber mehrere Attribute
// 		- zum aktuellen Zeitpunkt
// 		- zu einem bestimmten Zeitpunkt (synchron, asynchron)
// 		- fuer eine Zeitspanne (von-bis)
// 		
// 		Ein Request hat immer eine Antwort -> Response
// 
// 		Je Request-Item kann man mehrere Attribute eines
//
// komplette Umstellung der Message: 28.03.96 (Thomas Exner)
// Aenderungen:
// - enthaelt jetzt eine PtrList von RequestGroups (siehe dort)
// - es gibt die Request-Subtypen: DP_MSG_SIMPLE_REQUEST, DP_MSG_ASYNCH_REQUEST,
//   DP_MSG_SYNCH_REQUEST, DP_MSG_PERIOD_REQUEST, DP_MSG_ALERT_TIME_REQU und
//   DP_MSG_ALERT_PERIOD_REQU. Um welche es sich handelt, bestimmt die erste
//   eingefuegte Gruppe (Abfrage mit isA()). Nach der ersten duerfen nur noch
//   gleichartige Gruppen eingefuegt werden.
// - zum Aufbau der Message dient insertGroup(), bzw. fuer simple requests gibt
//   es insertSimpleItems() (die Gruppenzuordnung erfolgt dabei automatisch)

#ifndef _DPMSGREQUEST_H_
#define _DPMSGREQUEST_H_

// Vorwaerts-Deklaration der Eigenen Klasse
class DpMsgRequest;

// ========== DpMsgRequestPtr ============================================================
typedef DpMsgRequest* DpMsgRequestPtr;

// System-Include-Files
#include <DpMsg.hxx>
#include <RequestGroup.hxx>

// Vorwaerts-Deklarationen :
class DpMsgRequest;
class DpType;
class ManagerIdentifier;

// ========== DpMsgRequest ============================================================
/** General request message for datapoints.
 */
class DLLEXP_MESSAGES DpMsgRequest : public DpMsg 
{
public:
  /** Constructor
   * @param allowed enable multiple answer
   */
  DpMsgRequest(PVSSboolean allowed = PVSS_FALSE);

  /** Constructor
   * @param newDestination the Manager that shall receive this message
   * @param allowed enable multiple answer
   */
  DpMsgRequest(ManagerIdentifier &newDestination, PVSSboolean allowed = PVSS_FALSE);

  /// Copy constructor
  DpMsgRequest(const DpMsgRequest &newMsg);

  ///Destructor
  ~DpMsgRequest();

  // Operatoren :
  /** BCM output streaming operator
   * @param[in,out] ndrStream the BCM stream to write to
   * @param dpMsgRequest the DpMsgRequest instance to be written
   */
  friend DLLEXP_MESSAGES itcNdrUbSend &operator<<(itcNdrUbSend &ndrStream, const DpMsgRequest &dpMsgRequest);

  /** BCM input streaming operator
   * @param[in,out] ndrStream the BCM stream to read from
   * @param[out] dpMsgRequest the DpMsgRequest instance to be read
   */
  friend DLLEXP_MESSAGES itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream, DpMsgRequest &dpMsgRequest);

  /// Comparison operator
  virtual int operator==(const Msg &rVal) const;

  /// Assignment operator for Msg
  virtual Msg &operator=(const Msg &rVal);
  
  /// Assignment operator
  DpMsgRequest &operator= (const DpMsgRequest &rVal) { operator=((const DpMsg&)rVal); return *this; }

  // Spezielle Methoden :
  /** Allocate instance
   * @return a new DpMsgRequest instance, the caller takes responsibility
   */
  virtual Msg *allocate() const;

  /** Is of type
   * @param dpMsgType msg type to be comared with
   * @returns dpMsgType if compatible, NO_MSG if not
   */
  virtual MsgType isA(MsgType dpMsgType) const;

  /// Returns the type of this message
  virtual MsgType isA() const
	  {return myType;};

  /// Returns whether this message needs an answer; always PVSS_TRUE
  virtual PVSSboolean needsAnswer() const {return PVSS_TRUE;};

  // baut eine SimpleRequest-Msg, die Gruppenzuordnung erfolgt automatisch (was in eine
  // Gruupe kann, kommt auch in eine Gruppe)
  /** Builds up a RequestItem for a DP_MSG_SIMPLE_REQUEST, the RequestGroup assignment
   *  will be arranged automatically
   * @param id new msg id
   * @return PVSS_TRUE on success, PVSS_FALSE otherwise
   */
  PVSSboolean insertSimpleItem(const DpIdentifier &id);

  // fuegt eine neue Gruppe in die Msg ein, die erste Gruppe legt fest, von welchem
  // Typ die Msg ist, danach duerfen nur noch Gruppen des selben Typs eingefuegt werden
  /** Inserts a new RequestGroup in the Msg, the first Group defines which MsgType has
   *  been used, after that only RequestGroup objects of the same type can be inserted
   * @param group a new group of requests, must not be 0; this method takes ownership
   * @return PVSS_TRUE on success, PVSS_FALSE otherwise
   */
  PVSSboolean insertGroup(RequestGroup *group);

  /// Gets the first group from the list
  RequestGroup *getFirstGroup() const {return (RequestGroup *) list.getFirst();};
  /// Gets the next group from the list
  RequestGroup *getNextGroup() const {return (RequestGroup *) list.getNext();};

  /// Gets the group count
  virtual PVSSulong getNrOfGroups() const {return list.getNumberOfItems();};

  // wird im AnswerHandler::sendMsgWaitingForAnswer() benoetigt und liefert aus einer 
  // Group den ersten DpIdentifier
  /** Returns the id of the group at the specified position
   * @param groupIndex index to the group list
   * @return the id of the group or an empty DpIdentifier if not found
   */
  virtual DpIdentifier getGroupId(PVSSulong groupIndex) const;

  /** Prepares the message to get all configs
   * @param dpNum id of the processed type DP
   * @param typePtr datapoint type; this method iterates recursively over it and its
   *                children, while preparing a request for each element
   * @param system system number
   * @return PVSS_TRUE on success, PVSS_FALSE otherwise
   * @see recursivPrepMsg4CR()
   */
  PVSSboolean prepareMsg4ConfigRequest(DpIdType dpNum, const DpType *typePtr, SystemNumType system);

  /** Prepares the message to get all configs.
   *  It walk through all DpType structure and assign the configs RequestQroup to the msg
   * @param typePtr datapoint type; this method iterates recursively over it and its
   *                children, while preparing a request for each element
   * @param dpId DpId Id of the processed type
   */
  void recursivPrepMsg4CR(const DpType *typePtr, DpIdentifier dpId);

  /** Debug output method
   * @param[out] to the stream to write to
   * @param level controlls the amount of debug information, the higher the more
   */
  virtual void debug(std::ostream &to, int level) const;

  /** This function is used to set the DpMsgRequest type to DP_MSG_SIMPLE_REQUEST.
   *  Use this function to convert DP_MSG_MAXAGE_REQUEST messages.
   */
  void convertToSimpleRequest() {myType = DP_MSG_SIMPLE_REQUEST;}

  // Get the indication whether multiple answers are allowed
  PVSSboolean getMultipleAnswersAllowed() const { return multipleAnswersAllowed; }

protected:
  /** Writes this message to the BCM stream
   * @param[out] ndrStream
   */
  virtual void outNdrUb(itcNdrUbSend &ndrStream) const;

  /** Reads this message from the BCM stream
   * @param[in,out] ndrStream
   */
  virtual void inNdrUb(itcNdrUbReceive &ndrStream);
private:
  PtrList list;
  MsgType myType;

  // Flag whether multiple answers are allowed. Initialized in constructor.
  PVSSboolean multipleAnswersAllowed;

  friend class UNIT_TEST_FRIEND_CLASS;
  friend class UNIT_TEST_FRIEND_CLASS2;
};

// ========== inline-functions ============================================================
// Destruktor
inline DpMsgRequest::~DpMsgRequest()
{
}

/** Constructor
  * @param allowed enable multiple answer
  */
inline DpMsgRequest::DpMsgRequest(PVSSboolean allowed)
  : DpMsg(),
	  list(),
	  myType(DP_MSG_REQUEST),
    multipleAnswersAllowed(allowed)
{
}

/** constructor(ManagerIdentifier &newDestination)
  *@param newDestination ManagerIdentifier
  *@param allowed enable multiple answer
  */
inline DpMsgRequest::DpMsgRequest(ManagerIdentifier &newDestination, PVSSboolean allowed)
	: DpMsg(newDestination),
	  list(),
	  myType(DP_MSG_REQUEST),
    multipleAnswersAllowed(allowed)
{
}

/// Copy constructor
inline DpMsgRequest::DpMsgRequest(const DpMsgRequest &newMsg)
	: DpMsg(),
	  list()
{
	operator=(newMsg);
}

///DpMsgRequest::allocate
inline Msg *DpMsgRequest::allocate() const
{
	return new DpMsgRequest;
}

#endif /* _DPMSGREQUEST_H_ */
