#ifndef _SMENTWEIGHT_H_
#define _SMENTWEIGHT_H_

/*  author VERANTWORTUNG: Heinz Meissl*/
/** Statement - Gewichtungen; wird fuer CtrlSment und CtrlModule verwendet
*/

#include <Types.hxx>
/// Gewichtung eines CtrlSment
enum SmentWeight
{
  SM_WT_None = 0,
  SM_WT_Low = 1,
  SM_WT_Medium = 2,
  SM_WT_High = 3,
  SM_WT_ExtraHigh = 4
};

#endif /* _SMENTWEIGHT_H_ */
