#ifndef _CNSNODE_H_
#define _CNSNODE_H_

#include <vector>
#include <ViewId.hxx>
#include <CNSNodeNames.hxx>
#include <CNSDataIdentifier.hxx>
#include <SystemNumType.hxx>
#include <Blob.hxx>

// forward declaration
class CNSTreeNode;
class MyManager;
class CommonNameService;
class CNSVisitorWrapper;

/**
 * Public interface to access the data of a single CNS node.
 */
class DLLEXP_DATAPOINT CNSNode
{
public:

  // These classes need access to the private constructor
  friend class CNSNodeTree;
  friend class MyManager; // Ascii Manager
  friend class CommonNameService;
  friend class CNSVisitorWrapper;
  friend class NodeCollector;
  friend class SecurityPluginFilter;

  friend class UNIT_TEST_FRIEND_CLASS;    // ein Unit-Test braucht erweiterten zugriff auf diese Klasse

  /// Default constructor. Creates an empty node.
  CNSNode();

  /// Creates a node with the specified names and data.
  CNSNode(const CNSNodeNames &names, const CNSDataIdentifier &data = CNSDataIdentifier());

  /// Destructor
  virtual ~CNSNode();

  /**
   * Copy constructor.
   * Be aware that this will not perform a deep copy.
   * Ownership will remain in the original object (rval).
   */
  CNSNode(const CNSNode &rval);

  /**
   * Assignment operator.
   * Be aware that this will not perform a deep copy.
   * Ownership will remain in the original object (rval).
   */
  CNSNode &operator=(const CNSNode &rval);

public:
  /**
   * Returns the display names of this node.
   */
  LangText getDisplayNames() const;

  /**
   * Returns the display paths for this node in a format similar to getPath(),
   * except for the path separators, which can be defined separately for each
   * used language.
   *
   * @see getPath()
   */
  LangText getDisplayPaths() const;

  /**
   * Returns the (technical) name of this node.
   *
   * @see CNSNodeNames
   */
  CharString getName() const;

  /**
   * Returns the (technical) path of this node
   * (e.g. 'System1.View1:Tree1.Node1.Node2').
   *
   * @see CNSNodeNames
   */
  CharString getPath() const;

  /**
    Compute the (technical) path of this node
   * (e.g. 'System1.View1:Tree1.Node1.Node2').
   *
   * @see CNSNodeNames
   */
  void getPath(CharString &path) const;


  /**
   * Returns the id of the view that contains this node, or 0 if the node
   * is not part of a view.
   */
  ViewId getView() const;

  /**
   * Returns the number of the system that contains this node, or 0 if the node
   * is not part of a system.
   */
  SystemNumType getSystem() const;

  /**
   * Returns the data stored in this node.
   */
  CNSDataIdentifier getDataIdentifier() const;

  /**
   * Returns a copy of the User Data Blob stored in this node.
   */
  Blob getUserData() const;

  /**
   * Returns the number of bytes of User Data stored in this node.
   */
  unsigned int getUserDataLen() const;

  /**
   * Returns a pointer to the User Data stored in this node, or null
   * if it contains no User Data.
   */
  const PVSSuchar *getUserDataPtr() const;

private:
  /// pointer to the internal node
  const CNSTreeNode *node;
  /// specifies whether the node pointer has to be deleted
  bool ownership;

  /**
   * Creates a new node which delegates to the specified internal node.
   */
  CNSNode(const CNSTreeNode &internalNode);

  /**
   * Returns a pointer to the internal node.
   */
  const CNSTreeNode *getInternalNode() const;

  /**
   * (Re-)Initializes the pointer to the internal node which
   * this node represents.
   */
  void setInternalNode(const CNSTreeNode &newNode);

};

typedef std::vector<CNSNode> CNSNodeVector;

#endif // _CNSNODE_H_
