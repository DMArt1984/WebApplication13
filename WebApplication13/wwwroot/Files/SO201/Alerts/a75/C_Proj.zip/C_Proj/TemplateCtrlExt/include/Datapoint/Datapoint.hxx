#ifndef _DATAPOINT_H_
#define _DATAPOINT_H_

// DATEIBESCHREIBUNG ==============================================================
// DATEINAME:     Datapoint.hxx
// VERANTWORTUNG: Johannes Ertl
// BESCHREIBUNG:  Das ist der vielzitierte Datenpunkt! Der Datenpunkt enthaelt
//                nur seine TypId, er weiss also seine Struktur nicht, die ist mit
//                dieser TypId im DpTypeContainer zu erfahren. Die getElement, getRoot,
//                getFather und getSon Funktion sollte immer mit dem TypContainer
//                (oder DpType: ist schneller!) aufgerufen werden, damit
//                ueberprueft werden kann, ob das Element ueberhaupt existieren
//                kann. Siehe auch untere Bemerkung:
// BEMERKUNG:     Die Elemente sind nicht wirklich im Datenpunkt enthalten, sie werden
//                erst beim ersten Aufruf von getElement , getRoot, getFather, getSon
//                (samt TypContainer oder DpType) tatsaechlich erzeugt (allokiert).
//                Wenn man sich seiner Sache sicher ist, kann man auch getElement
//                ohne dem DpTypContainer verwenden, nur erhaelt man nur ein Objekt,
//                wenn es tatsaechlich existiert (also schon einmal mit der anderen
//                getElement Funktion abgefragt wurde).
//
// 23.02.02       Memory Optimierung (SimplePtrArray)              Martin Koller
// ======================================Ende======================================

// System-Include-Files
#ifndef _DPELEMENT_H_
#include <DpElement.hxx>
#endif

#ifndef _DPTYPES_H_
#include <DpTypes.hxx>
#endif

#include <SimplePtrArray.hxx>

class DpType;
class DpTypeContainer;

#ifdef WIN32
#pragma warning ( disable: 4231 )
#endif

#if defined(LIBS_AS_DLL)
  EXTERN_DATAPOINT  template class DLLEXP_DATAPOINT  SimplePtrArray<DpElement>;
#endif

#ifdef WIN32
#pragma warning ( default: 4231 )
#endif


/** The datapoint.
    It only knows its type and id, but not the structure it is embedded in. 
    This can be queried via the DpTypeContainer. 
    The methods returning a DpElement pointer should only be called with a DpTypeContainer (or a DpType, which is slightly faster). Otherwise, the result may not be as expected. See the corresponding methods for details.
*/
class DLLEXP_DATAPOINT Datapoint
{
  public:
    /// Constructor.
    Datapoint(DpIdType theDpId, DpTypeId theDpType);

    /** Comparison operator.
        Only dpId is compared.
    */
    int operator==(const Datapoint &rVal) const { return dpId==rVal.dpId; }

    /** Comparison operator.
        Only dpId is compared.
    */
    int operator<(const Datapoint &rVal) const { return dpId<rVal.dpId; }

    /// Check whether the element exists within the type.
    PVSSboolean checkElementId(const DpTypeContainer &typeContainer, DpElementId elementId) const;
    /// Check whether the element exists within the type.
    PVSSboolean checkElementId(const DpType *theDpType, DpElementId elementId) const;

    /** Get element with the specified id.
        If the DpElement object still does not exist, it is created.
    */
    DpElement *getElement(const DpTypeContainer &typeContainer, DpElementId id);
    /** Get element with the specified id.
        If the DpElement object still does not exist, it is created.
    */
    DpElement *getElement(const DpType *theDpType, DpElementId id);
    /** Get element with the specified id.
        @remark The elements are not really in the Datapoint but are created upon the first call 
        to the corresponding method that takes a DpTypeContainer or a DpType. 
        The methods without DpTypeContainer/DpType can be used, but the caller must be shure 
        that the expected object was created before via a DpTypeContainer/DpType.
    */
    const DpElement *getElement(DpElementId id) const;
    /** Get element with the specified id.
        @remark The elements are not really in the Datapoint but are created upon the first call 
        to the corresponding method that takes a DpTypeContainer or a DpType. 
        The methods without DpTypeContainer/DpType can be used, but the caller must be shure 
        that the expected object was created before via a DpTypeContainer/DpType.
    */
    DpElement *getElement(DpElementId id);

    /// Get root element.
    DpElement *getRootElement(const DpTypeContainer &typeContainer);
    /// Get root element.
    DpElement *getRootElement(const DpType *theDpType);

    /// Get father element.
    DpElement *getFather(const DpTypeContainer &typeContainer, DpElementId id);
    /// Get father element.
    DpElement *getFather(const DpType *theDpType, DpElementId id);

    /// Get number of son elements.
    unsigned int getNumberOfSons(const DpTypeContainer &typeContainer, DpElementId id) const;
    /// Get number of son elements.
    unsigned int getNumberOfSons(const DpType *theDpType, DpElementId id) const;

    /// Get son element.
    DpElement *getSon(const DpTypeContainer &typeContainer, DpElementId id, unsigned int sonIndex);
    /// Get son element.
    DpElement *getSon(const DpType *theDpType, DpElementId id, unsigned int sonIndex);

    /// Get type object representing the type of this datapoint.
    const DpType *getType(const DpTypeContainer &typeContainer) const
      { return typeContainer.getTypePtr(dpType); }

    /** All elements without a configuration will be deleted. 
        This is a slow operation with complexity O(n<sup>2</sup>) where n is the number of DpElement objects known to the Datapoint.
        */
    PVSSboolean optimize();

    /** Process elements.
        @param Process Pointer to processing function. This function is called for every existing element.
        */
    void visitEveryElement(PVSSboolean (*Process)(const DpElement&)) const;
    /** Process elements.
        @param Process Pointer to processing function. This function is called for every existing element.
        */
    void visitEveryElement(PVSSboolean (*Process)(const Datapoint &, const DpElement &)) const;

    /// Get ID.
    DpIdType getDpId()   const { return dpId; }
    /// Get type.
    DpTypeId getDpType() const { return dpType; }

    /// Set ID
    void setDpId(DpIdType newDpId)     {dpId = newDpId;}
    /// Set type ID.
    void setDpType(DpTypeId newDpType) {dpType = newDpType;}

    /// Get number of elements.
    DynPtrArrayIndex length() const {return dpElementList.getNumberOfItems();}

  private:
    static int compareDpElement(const DpElement *x, const DpElement *y);

    DpIdType dpId;
    DpTypeId dpType;
    SimplePtrArray<DpElement> dpElementList;

    Datapoint(const Datapoint &) {} // COVINFO LINE: defensive (copy c'tor defined private so no one can use it)
    Datapoint & operator=(const Datapoint &) {return *this;} // COVINFO LINE: defensive (assignment operator defined private so no one can use it)
};

// ================================================================================

inline void Datapoint::visitEveryElement(PVSSboolean (*Process)(const DpElement&)) const
{
  unsigned int idx, len = dpElementList.getNumberOfItems();

  for (idx = 0; idx < len; idx++)
    (*Process)( *(dpElementList.getAt(idx)) );
}


inline void Datapoint::visitEveryElement(PVSSboolean (*Process)(const Datapoint &, const DpElement&)) const
{
  unsigned int idx, len = dpElementList.getNumberOfItems();

  for (idx = 0; idx < len; idx++)
    (*Process)( *this, *(dpElementList.getAt(idx)) );
}


#endif /* _DATAPOINT_H_ */
