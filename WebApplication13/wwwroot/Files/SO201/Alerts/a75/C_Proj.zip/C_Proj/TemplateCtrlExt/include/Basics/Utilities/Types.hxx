// DATEIBESCHREIBUNG ==============================================================
// DATEINAME:      types.hxx
// VERANTWORTUNG:  Gerhard Fellrieser
// BESCHREIBUNG:   Sichert die Systemunabhaengigkeit fuer alle
//     Standardtypen
// ======================================Ende======================================

#ifndef _TYPES_HXX_
#define _TYPES_HXX_

// get rid of hundreds warnings: "this used in base / member initializer list
#ifdef _WIN32
#pragma warning(disable:4355)
#endif // _WIN32

#include <climits>
#include <cfloat>
#include <cstddef>

/** @name Platform independent types
*/
//@{

//-------- Boolean ----------------------------------------------------------
/// the bool type
typedef unsigned int PVSSboolean;

/// set to 0
#define  PVSS_FALSE  static_cast<PVSSboolean>(0)
/// set to 1
#define  PVSS_TRUE   static_cast<PVSSboolean>(1)


// The ISO C99 standard specifies that in C++ implementations these
// macros (stdint.h,inttypes.h) should only be defined if explicitly requested.

// MSVC has stdint.h since VC10
// ISO C99: 7.18 Integer types
#ifndef __STDC_LIMIT_MACROS
#define __STDC_LIMIT_MACROS
#endif
#include <stdint.h>

// MSVC has inttypes.h since VC12. define fallback macros for VC10.
#if defined(_MSC_VER) && _MSC_VER < 1800

#define PRId8   "d"
#define PRId16  "hd"
#define PRId32  "I32d"
#define PRId64  "I64d"

#define PRIi8   "i"
#define PRIi16  "hi"
#define PRIi32  "I32i"
#define PRIi64  "I64i"

#define PRIu8   "u"
#define PRIu16  "hu"
#define PRIu32  "I32u"
#define PRIu64  "I64u"

#define PRIx8   "x"
#define PRIx16  "hx"
#define PRIx32  "I32x"
#define PRIx64  "I64x"

#define PRIX8   "X"
#define PRIX16  "hX"
#define PRIX32  "I32X"
#define PRIX64  "I64X"

#define SCNd8   "d"
#define SCNd16  "hd"
#define SCNd32  "I32d"
#define SCNd64  "I64d"

#define SCNi8   "i"
#define SCNi16  "hi"
#define SCNi32  "I32i"
#define SCNi64  "I64i"

#define SCNu8   "u"
#define SCNu16  "hu"
#define SCNu32  "I32u"
#define SCNu64  "I64u"

#define SCNx8   "x"
#define SCNx16  "hx"
#define SCNx32  "I32x"
#define SCNx64  "I64x"

#define SCNX8   "X"
#define SCNX16  "hX"
#define SCNX32  "I32X"
#define SCNX64  "I64X"

#else // defined(_MSC_VER) && _MSC_VER < 1800

// ISO C99: 7.8 Format conversion of integer types
#ifndef __STDC_FORMAT_MACROS
#define __STDC_FORMAT_MACROS
#endif
#include <inttypes.h>

#endif // defined(_MSC_VER) && _MSC_VER < 1800

#ifdef _WIN32

// There is no platform independent way to printf or scanf time_t
# ifdef _USE_32BIT_TIME_T
#   define PRIdTIM  PRId32
#   define SCNdTIM  SCNd32
# else
#   define PRIdTIM  PRId64
#   define SCNdTIM  SCNd64
# endif

// statt in ErrClass.hxx (um #include <winnt.h> zu umgehen):
typedef void *HANDLE;

#if !defined(R_OK)
#define R_OK 4
#define W_OK 2
#define X_OK 1
#define F_OK 0
#endif

#else

// There is no platform independent way to printf or scanf time_t
# ifdef __amd64
#   define PRIdTIM PRId64
#   define SCNdTIM PRId64
# else
#   define PRIdTIM PRId32
#   define SCNdTIM SCNd32
# endif

// Under Linux gcc-3.4.3 LLONG_MIN etc are not defined though _GNU_SOURCE is defined.
// workaround here
#if !defined (LLONG_MIN) && defined (LONG_LONG_MIN)
# define LLONG_MIN LONG_LONG_MIN
# define LLONG_MAX LONG_LONG_MAX
# define ULLONG_MAX ULONG_LONG_MAX
#endif

#endif

#define SIZEOF_CHAR  1
#define SIZEOF_SHORT 2
#define SIZEOF_INT   4

#if LONG_MAX == 0x7FFFFFFFFFFFFFFFLL
# define SIZEOF_LONG 8
#else
# define SIZEOF_LONG 4
#endif

#define SIZEOF_LONGLONG 8

#define SIZEOF_DOUBLE 8

// Note: get all predefined Macros with (GNU only!): cpp -dM < /dev/null
// with clang e.g.: clang -arch arm64 -dM -E linkedAt.cxx (any source file must be given)

#if defined(__BYTE_ORDER__)
#  if __BYTE_ORDER__ == __ORDER_LITTLE_ENDIAN__
#    define IS_LITTLE_ENDIAN
#  else
#    define IS_BIG_ENDIAN
#  endif
#elif defined(_WIN32) || defined(_WIN64)
  // Windows
# define IS_LITTLE_ENDIAN
#elif defined(__amd64) || defined(__i386__)
  // Intel- and AMD CPU
# define IS_LITTLE_ENDIAN
#elif defined(__sparc)
  // SPARC (Solaris)
# define IS_BIG_ENDIAN
#elif defined(__HP)
  // HP (HP-RISC)
# define IS_BIG_ENDIAN
#elif defined(__arm__)
  // ARM
# define IS_LITTLE_ENDIAN
#elif defined(__powerpc__)
# define IS_BIG_ENDIAN
#else
#error "unknown platform"
#endif

typedef int64_t  time64_t;
#if defined(__SUNPRO_CC)
  #define __int64     long long
#endif

//------- Standard-Typen ------------------------------------------------
/// the signed char type
  typedef int8_t         PVSSchar;     //  8 Bit

/// the signed int16 type (obsolete, use PVSSshort instead)
  IL_DEPRECATED("deprecated, use PVSSshort instead")
  typedef int16_t        PVSSint;      // 16 Bit

/// the signed int16 type
  typedef int16_t        PVSSshort;    // 16 Bit
/// the signed int32 type
  typedef int32_t        PVSSlong;     // 32 Bit
///  the unsigned char type
  typedef uint8_t        PVSSuchar;    //  8 Bit

/// the unsigned int16 type (obsolete, use PVSSushort instead)
  IL_DEPRECATED("deprecated, use PVSSushort instead")
  typedef uint16_t       PVSSuint;     // 16 Bit

/// the unsigned int16 type
  typedef uint16_t       PVSSushort;   // 16 Bit
/// the unsigned int32 type
  typedef uint32_t       PVSSulong;    // 32 Bit
///  the float type
  typedef float          PVSSfloat;    // 32 Bit
/// the double type
  typedef double         PVSSdouble;   // 64 Bit
/// the long double type
  typedef long double    PVSSlongdouble; // 128 bit
/// the 64 bit integer type
  typedef int64_t        PVSSlonglong; // 64 Bit Integer

/// the unsigned 64 bit integer type
  typedef uint64_t       PVSSulonglong;// 64 Bit unsigned Integer
/// the enum type
  typedef uint32_t       PVSSenum;     // Enum-Typ

// Limits fuer Variablen
#define MIN_CHAR_VAR   0
#define MAX_CHAR_VAR   UCHAR_MAX



#define MIN_SHORT_VAR  INT16_MIN
#define MAX_SHORT_VAR  INT16_MAX
#define MIN_USHORT_VAR 0
#define MAX_USHORT_VAR UINT16_MAX

#define MIN_INT_VAR    INT32_MIN
#define MAX_INT_VAR    INT32_MAX
#define MIN_UINT_VAR   0
#define MAX_UINT_VAR   UINT32_MAX

#define MIN_LONG_VAR   INT64_MIN
#define MAX_LONG_VAR   INT64_MAX
#define MIN_ULONG_VAR  0
#define MAX_ULONG_VAR  UINT64_MAX

// FloatVar stores a double; therefore min/max need to be double limits
#define MIN_FLOAT_VAR -DBL_MAX  // DBL_MIN ist der kleinste float, welcher noch groesser 0 ist, also 0,00000...
#define MAX_FLOAT_VAR DBL_MAX


// Time limits
#define MIN_TIME_VAR_SEC   INT32_MIN
#define MAX_TIME_VAR_SEC   INT32_MAX
#define MAX_TIME_VAR_MSEC  999

// Andere Limits
#define MAX_PVSSULONG  UINT32_MAX

// -------- NULL-Pointer-Value --------------------------------------------
#ifndef NULL
#define NULL 0
#endif


// User Type
typedef PVSSushort  PVSSuserIdType;

// ---------- LanguageIdType ---------------------------------------------
typedef PVSSuchar   LanguageIdType;        // Index
typedef PVSSushort  GlobalLanguageIdType;  // PVSS unique

//@}

#endif  // _TYPES_HXX_

// work-around for the impossibility on suncc to force an include file
#if defined(__SUNPRO_CC) && !defined(API_COMPILE)
#include "../../../pvssincl/vc8/iostream.h"
#endif
