#ifndef _EXTERNHDL_H_
#define _EXTERNHDL_H_

#include <BaseExternHdl.hxx>
#include <FuncNamesStruct.hxx>
#include <Variable.hxx>
#include <Types.hxx>

class IntegerVar;
class CharString;
class ExprList;
class CtrlThread;
class Controller;
class ExternData;

/*  author VERANTWORTUNG: Martin Koller*/
/** Die Klasse uebernimmt den Aufruf von Funktionen, die nicht im
  * Sprachumfang vom CTRL definiert sind und auch nicht in einem script vom User
  * definiert worden sind.
  */
class DLLEXP_CTRL ExternHdl: public BaseExternHdl
{
  public:
     ///
    ExternHdl(BaseExternHdl *hdl) : BaseExternHdl(hdl, 0, 0) {}

    /// get func names
    static void getFuncNames(const FuncNamesStruct * &fn, int &count);

    /** returns the function-number corresponding to funcName.
      * if the function is implemented in this class, or 0 if not
      */
    virtual PVSSulong getFuncNum(const CharString &funcName) const;

    /// calls builtin function
    virtual const Variable *execute
      (
        const CharString &funcName,
        PVSSulong funcNum,
        ExprList *args,
        ExternData *clientData,
        CtrlThread *thread
      );

    /// not used from Std. ExternHdl
    virtual const Variable *execute(ExecuteParamRec & /*param*/) { return(0); }

    /// Ctrl-Modul extStatFunc. (nur fuer Ctrl-Manager und Event-Manager)
    IntegerVar callExtStatFunc
    (
      const CharString &funcName,
      ExprList *args,
      ExternData *clientData,
      CtrlThread *thread
    );

    enum
    {
      F_dpConnect = 1,
      F_dpConnectUserData,
      F_dpDisconnect,
      F_dpDisconnectUserData,
      F_dpSet,
      F_dpSetWait,
      F_dpSetTimed,
      F_dpSetTimedWait,
      F_dpGet,
      F_dpGetMaxAge,
      F_dpGetPeriod,
      F_dpGetPeriodSplit,
      F_dpCancelSplitRequest,
      F_dpGetAsynch,

      F_alertConnect,
      F_alertDisconnect,
      F_alertSet,
      F_alertGet,
      F_alertGetPeriod,

      F_isAlertAttribute,

      F_dpCreate,
      F_dpDelete,
      F_dpRename,
      F_dpExists,

      F_dpGetId,
      F_dpGetName,

      F_dpNames,
      F_dpTypes,
      F_dpAliases,
      F_dpElementType,
      F_dpAttributeType,
      F_dpSubStr,
      F_dpTypeName,

      F_dpGetStatusBit,
      F_dpIsLegalName,

      F_setScriptUserId,
      F_setScriptLangId,
      F_setUserId,
      F_getUserId,
      F_getUserName,
      F_getUserPermission,
      F_checkPassword,

      F_myManNum,
      F_myManType,
      F_myManId,
      F_convManIdToInt,
      F_getManIdFromInt,
      F_convManIntToName,
      F_isEvConnOpen,

      F_dpAliasToName,
      F_dpNameToAlias,
      F_getDpComment,
      F_dpGetFormat,
      F_dpGetUnit,
      F_setDpComment,
      F_dpSetFormat,
      F_dpSetUnit,
      F_dpValToString,
      F_setDpAlias,
      F_dpGetAllAliases,
      F_dpGetAllComments,

      F_dpQuery,
      F_dpQuerySplit,
      F_dpQueryConnectAll,
      F_dpQueryConnectSingle,
      F_dpQueryDisconnect,
      F_checkQuery,

      // the following functions (until end of enum) were moved from FCall to ExternHdl,
      // since they are not supported by reports and only the ExternHdl should be modified
      // for the reports --> ReportExtHdl (ExternHdl and ShapeExtHdl)

      F_getCurrentTime,

// internal file-functions, moved to ExternHdl, because they are not supported by reports
      F_fopen,
      F_fclose,
      F_fflush,
      F_feof,
      F_ferror,
      F_fprintf,
      F_fscanf,

      F_fputs,
      F_access,
      F_fgets,
      F_rewind,
      F_fseek,
      F_ftell,
      F_fread,
      F_fwrite,
      F_fileToString,
      F_recode,
      F_remove,
      F_rename,

      F_exit,

      F_getCatStr,        // may be overloaded
      F_system,           // arbitrary system calls to dangerous for reports
      F_systemDetached,

      F_startSound,       // no sound in reports
      F_stopSound,

      F_sprintf,
      F_sscanf,

      F_crypt,      // password encryption
      F_RSAGenerateKeyPair,
      F_RSASealEnvelope,
      F_RSAOpenEnvelope,

#if PVSS_VERS < 400000
      F_translate,    // language dependent string translation
      F_mergeDictionary,
      F_getDictionary,
      F_readDictionary,
      F_writeDictionary,
#endif

      F_getLangCommentById,
      F_getHostname,
      F_beep,
      F_getAllSystemNames,
      F_getSystemNames,
      F_getSystemName,
      F_getSystemId,

      F_makeError,
      F_getErrorPriority,
      F_getErrorType,
      F_getErrorCode,
      F_getErrorDpName,
      F_getErrorManId,
      F_getErrorUserId,
      F_getErrorText,
      F_getErrorCatalog,
      F_getErrorStackTrace,
      F_throwError,
      F_getLastError,
      F_clearLastError,

      F_waitForDpValue,
      F_dpSetAndWaitForValue,  // IM 119755 WOKL

      F_getPath,

      F_userDefFunc,
      F_isModeExtended,

      F_dpTypeCreate,
      F_dpTypeChange,
      F_dpTypeDelete,
      F_dpGetDpTypeRefs,
      F_dpGetRefsToDpType,
      F_dpTypeGet,

      F_getGlobals,
      F_getGlobalType,
      F_globalExists,

      F_isDollarDefined,
      F_isFunctionDefined,
      F_getDollarValue,
      F_dollarSubstitute,

      F_fprintfUL,
      F_fprintfPL,
      F_fscanfUL,
      F_fscanfPL,
      F_sprintfUL,
      F_sprintfPL,
      F_sscanfUL,
      F_sscanfPL,

      F_dpGetAllConfigs,
      F_dpGetAllDetails,
      F_dpGetAllAttributes,
      F_dpTypeRefName,

      F_getLicenseOption,
      F_checkLicenseOption,
      F_isAnswer,
      F_isRefresh,
      F_isDistributed,
      F_isConnOpen,
      F_isConnActive,
      F_getKerberosSecurity,
      F_isReduActive,         // IM 114678 WOKL

#if PVSS_VERS < 400000
      F_useRDBArchive,
      F_useValueArchive,
      F_useNGA,
      F_useRDBGroups,
      F_useQueryRDBDirect,
      F_setQueryRDBDirect,
#endif

      F_getOriginUserId,
      F_getOriginManId,
      F_alertSetTimed,
      F_alertSetWait,
      F_alertSetTimedWait,

      F_dpSetTimedAndCompare,   //IM103111 - setzt timeOfPeriph Bit - Compare mit config discardOldValues

      // IM 117220 unicode functions
      F_uniFPrintf,
      F_uniFPrintfUL,
      F_uniFPrintfPL,
      F_uniSPrintf,
      F_uniSPrintfUL,
      F_uniSPrintfPL,

      // sysConnect
      F_sysConnect,
      F_sysConnectUserData,
      F_sysDisconnect,
      F_sysDisconnectUserData,

      F_ssaRelogin,
      F_getACPResource,
      F_setACPResource,

      LAST_Func,     // Beginn der Reserve f. Patch-Erweiterungen
      MAX_ExternHdl  // must always be the last enum-item
                    = LAST_Func + 48 // Reserve f. Patch-Erweiterungen
    };


  private:
    // helper functions for fprintf, fscanf
    char *firstFormat(CtrlThread *thread, const char *&formatPtr, const char *source,
                      int scanfMode, int &arg_needed, ExprList *args, int &error_occured,
                      VariableType &vType, long &width, long &precision) const;

    char *nextFormat(CtrlThread *thread, const char *&formatPtr, int scanfMode,
                     int &arg_needed, ExprList *args, int &error_occured,
                     VariableType &vType, long &width, long &precision) const;

    const Variable *nextVar(CtrlThread *thread, ExprList *args) const;
    Variable *nextIdVar(CtrlThread *thread, ExprList *args, const CharString &funcName) const;
    int processFormatStr(CtrlThread *thread, ExprList *args, CharString &result_str, bool uni) const;

    int processScanStr(CtrlThread *thread, const Variable *source, ExprList *args,
           const CharString &funcName) const;

    void  filterDpAndValue(DynVar &dps, DynVar &values, const char *dpPattern);

    /// check if there are at least @num arguments given; if not, throw an ErrHdl::error
    bool hasNumArgs(unsigned int num, const CharString &funcName, const ExprList *args, CtrlThread *thread) const;


    bool dpSetDynPrepParams(PVSSulong funcNum, const CharString &funcName, const ExprList *args, const ExternData *clientData, CtrlThread *thread,
      Variable *dpNameDynPtr, DpIdValueList &dpIdList);

    void dpSetWarnDupItems(const DpIdValueList &dpIdList, const CharString &funcName, CtrlThread *thread);
    void dpSetWarnDifferentSystemItems(const DpIdValueList &dpIdList, const CharString &funcName, CtrlThread *thread);

    VariableType memberVarIsA(const ClassVar *man, unsigned int idx, const CharString &name);
    CtrlExpr *getManagerIdentifier(ManagerIdentifier &msgDestination, const ExprList *args, CtrlThread *thread);

    static CharString utf8ByteOrderMark;

  public:
    static void convManIntToName(int manIdInt, CharString &manName, PVSSboolean bNum, PVSSboolean bShort);
    static Variable *getTarget(CtrlExpr *expr, const CharString &funcName,
                        const ExprList *args, CtrlThread *thread, VariableType type = NO_VAR);
};

#endif /* _EXTERNHDL_H_ */
