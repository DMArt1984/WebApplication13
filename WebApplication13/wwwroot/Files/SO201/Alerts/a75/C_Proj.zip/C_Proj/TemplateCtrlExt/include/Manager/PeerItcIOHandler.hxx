#ifndef _PEERITCIOHANDLER_H_
#define _PEERITCIOHANDLER_H_

#include <Types.hxx>
#include <ManagerIdentifier.hxx>
#include <PVSSBcm.hxx>
#include <PtrList.hxx>
#include <PVSSTime.hxx>
#include <PVSSMacros.hxx>
#include <ErrHdl.hxx>
#include <CRC.hxx>
#include <ostream>

class Filter;
class Msg;
class MsgItcDispatcher;
class itcConnection;
class Kerberos;
class InitSysMsg;

/** Der PeerItcIOHandler realisiert eine Verbindung ueber ein Socket.
    Die Callbacks uebernehmen das Lesen der Messages aus den Sockets, das
    Schreiben von Messages in den Sendekanal wird ebenfalls ueber eine
    Methode der itcIOHandler-Klasse bewaeltigt.
*/
//author Gerhard Fellrieser

class PeerItcIOHandler : public itcIOHandler,
                         public ICBBcmReady
{
public:
  /** Constructor used on server-side.
    * @param conn BCM connection
    * @param target identifier of associated target manager requesting the connection (at client-side)
    * @param initSysMsg initial system message. Used to determine the hostname of the manager acting as original client.
    *                   There may be a proxy in between or not.
    */
  PeerItcIOHandler(
    itcConnection *conn,
    const ManagerIdentifier &target,
    InitSysMsg &initSysMsg);

  /// constructor
  PeerItcIOHandler(const CharString &connectString,
                   const ManagerIdentifier &target, const ManagerIdentifier &host);
  /// Destructor
  ~PeerItcIOHandler();

  virtual int inputReady(itcConnection *conn, char *data);
  virtual int outputReady(itcConnection *conn, char *data);
  virtual int exceptionRaised(itcConnection *conn, char *data);

  /// Connect timer
  virtual void timerExpired(long sec, long usec) override;

  PVSSboolean sendCall(Msg &msg);

  /// Don't send, but allocate new send buffer
  void flush();

  void reportStatus(std::ostream &to) const;

  const ManagerIdentifier & getTarget() const  {return target;}
  void  setTarget(const ManagerIdentifier &newTarget);

  /// Close the connection. Send remaining data, if doFlush is TRUE
  void  closeConnection(PVSSboolean doFlush = PVSS_TRUE);
  ///
  void  flushConnection();

  // Returns PVSS_TRUE, if connPtr is a valid pointer
  PVSSboolean  isValid() const;

  /// Returns PVSS_TRUE, if a security context is established or not defined at all
  PVSSboolean  isEstablished() const;
  /// Returns PVSS_TRUE, if the connection is established
  PVSSboolean  isConnected() const;
  /// Returns PVSS_TRUE, if the connection is pending, but not yet established
  PVSSboolean  isConnecting() const;
  /// Returns PVSS_TRUE, if the connection is closing (writing disabled)
  PVSSboolean  isClosing() const;

  PVSSboolean isLastSendOk()  {return lastSendOk_;}

  itcNdrUbSend * getSender();
  itcNdrUbSend * getSender(PVSSboolean appendAlways);

  /// Own and remote hostname
  CharString  getSockname() const;
  CharString  getPeername() const;
  CharString  getEndToEndPeername() const { return endToEndPeerName_; }

  /// Own and remote hostaddress
  CharString  getSockaddress() const;
  CharString  getPeeraddress() const;
  CharString  getConnectString() const;
  int getSockport() const;
  int getPeerport() const;

  PVSSboolean  isBufferExceeded () { return (overLimit_ == 2 ? PVSS_TRUE : PVSS_FALSE);}
  void  resetBufferExceeded () {overLimit_ = 0;}

  /// How many bytes are pending in the send buffer
  PVSSlong  getSendBufferLength() const;

  void setVersion(PVSSushort _version);
  PVSSushort getVersion() const;

  void appendSendBuffer();

  void setKerberosContext(Kerberos *ptr) {krb5Ptr_ = ptr;}
  Kerberos * getKerberosContext() { return krb5Ptr_;}

  PVSSboolean setKerberosSecurity(const CharString &value);
  int  getKerberosSecurity() const {return krb5Security_;}

  void setSsaSecured(bool b = true) {ssaSecured_ = b;}
  bool isSsaSecured() const {return ssaSecured_;}

  void setMessageCompression(const CharString &type);
  const char * getMessageCompression() const;

  bool isMxProxyUsed() const;
  
  PVSSulong getPeerId() const {return peerId;}

  bool getUseCRC() const {return useCRC_;}
  void setUseCRC(bool useCRC) {useCRC_ = useCRC;}

  // Realize ICBBcmReady interface
  virtual void bcmReady(int result, void *params);

private:

  class itcNdrUbSendOption : public itcNdrUbSend
  {
    public:
    itcNdrUbSendOption(PVSSushort version) : itcNdrUbSend(version), flags_(raw) {};

    // Flags will be or'ed
    enum
    {
      raw = 0,
      zlib = 1,
      krb = 2,
      bzip2 = 4,
      crc = 8
    };

    unsigned flags_;
  };


  class itcNdrUbRecvOption : public itcNdrUbReceive
  {
    public:
    itcNdrUbRecvOption(PVSSushort version) : itcNdrUbReceive(version), flags_(0) {}

    itcNdrUbRecvOption(PVSSushort version, const char *data, size_t len)
      : itcNdrUbReceive(version, data, (int)len), flags_(raw) {}

    void reset()
    {
      itcNdrUbReceive::reset();
      flags_ = 0;
    }

    // Will be or-ed
    enum
    {
      raw = 0,
      zlib = 1,
      krb = 2,
      bzip2 = 4,
      crc = 8
    };

    unsigned flags_;
  };

  // To have several Buffers to send
  class SendBufferItem : public PtrListItem
  {
    public:
    SendBufferItem(PVSSushort _version)
      : out_(_version) {}

    itcNdrUbSendOption &sender() { return(out_); }

    public:
    itcNdrUbSendOption out_;
  };

protected:
  // So it can be used in unit tests
  virtual int  handleData(itcNdrUbRecvOption &recv);
  SendBufferItem * prepareMessage(SendBufferItem *itemPtr);

public:
  static DLLEXP_MANAGER char magic[4];  // Magic "PVSS" (without '\0') at the start of every message

  static const CharString LOCALHOST;   // String indicating that end-to-end peers run on the same host, used as a flag

private:
  void link();

  // Remove the connection ptr
  PVSSboolean rmPeer();

  // _sndLevel 1 or 2 print keep_alives if enabled
  // _sndLevel 3 or 4 print all enabled MSGs
  // with this debug you will see each msg as often as it is sent via a tcp-connection
  // this can be 4 times since one msg is send up to 4 times (redu-lan + redundant connected)
  void debug(const Msg &_msg, int _sndLevel);

  int  handleDataLoop(itcNdrUbRecvOption &recv);

  int  handleKerberizedData(itcNdrUbRecvOption &recv);
  int  handleCRCData(itcNdrUbRecvOption &recv);
  int  handleBzipData(itcNdrUbRecvOption &recv);
  int  handleZlibData(itcNdrUbRecvOption &recv);

  Msg * handleSignedMsg(itcNdrUbRecvOption &recv);
  Msg * handleEncryptedMsg(itcNdrUbRecvOption &recv);
  Msg * handlePlainMsg(itcNdrUbRecvOption &recv);

  int handleConnect(itcConnection *conn);

  int inputReadyForMXProxy(itcConnection *conn); // handling inputready from proxy

  // parts of send
  bool krb5Security2(itcNdrUbSendOption *ptrSender, Msg &msg);
  bool krb5Security3(itcNdrUbSendOption *ptrSender, Msg &msg);
  bool sysMsgInitOrAlive(itcNdrUbSendOption *ptrSender, Msg &msg);
  bool matroshkaFormat(itcNdrUbSendOption *ptrSender, Msg &msg);

  SendBufferItem * kerberizeMessage(SendBufferItem *itemPtr);
  SendBufferItem * kerberizeMessageSign(SendBufferItem *itemPtr);
  SendBufferItem * kerberizeMessageEncrypt(SendBufferItem *itemPtr);
  SendBufferItem * crcMessage(SendBufferItem *itemPtr);
  SendBufferItem * compressMessage(SendBufferItem *itemPtr);
  SendBufferItem * compressMessageBzip2(SendBufferItem *itemPtr);
  SendBufferItem * compressMessageZlib(SendBufferItem *itemPtr);

  void calcOverLimit(const ManagerIdentifier &target);
  void handleOverLimit(const ManagerIdentifier &target);
  void debugSendBuffer(const ManagerIdentifier &target);

  void setRemoteEncOnItcNDRObj(itcNDR &itcNDRObj);
  void setEstablished(bool established);

private:
  static CRC32 crc_;

private:
  // Pointer to the send/receive connection object
  itcConnection *connectPtr;

  // The receiver buffer
  itcNdrUbRecvOption receiver;

  // A list of sender buffer. If one is busy or contains more than BUFLEN data, allocate a new one
  PtrList  sendBufferList;

  // Manager identifier of the peer of this connection
  // This is used only to identify the peer in the Dispatcher list
  ManagerIdentifier target;

  PVSSboolean lastSendOk_;

  // Flag if the connection is closing
  PVSSboolean closePending;

  // Pointer to performance counter or internal variables
  PVSSlonglong *sndBufferLenPtr_;
  PVSSlonglong *rcvLenPtr_;
  PVSSlonglong *sndLenPtr_;

  // Store performance values here, if no performance counter is available
  PVSSlonglong rcvLen_;           // Bytes received
  PVSSlonglong sndLen_;           // Bytes sent
  PVSSlonglong sndRawLen_;        // Uncompressed bytes in send buffer
  PVSSlonglong rcvRawLen_;        // Uncompressed bytes in recv buffer
  PVSSlonglong sndBufferLen_;     // Bytes in send buffer
  PVSSlonglong sndMaxBufferLen_;  // Max bytes in send buffer ever
  PVSSlonglong rcvMaxBufferLen_;  // Max bytes in recv buffer ever

  // Variables for limit checking
  PVSSTime  currTime_;
  PVSSTime  crossTime_;
  PVSSuchar overLimit_;
  PVSSlonglong overLimitMaxBufferLen_;
  PVSSlonglong overLimitMinBufferLen_;

  // Sockname and PeerName
  CharString  sockName_;
  CharString  peerName_;
  CharString  endToEndPeerName_; // Set on both, client-side and server-side: either "localhost" if peer is on same host or hostname of end-to-end peer
  CharString  connectString_;

  PVSSushort  msgVersion_;        // welche Msg-Version versteht mein peer

  Kerberos   *krb5Ptr_;           // Kerberos context
  int         krb5Security_;

  bool        ssaSecured_;

  bool        established_;

  bool        useCRC_;

  CharString origHostname;   // Only set on client-side: Host name from configuration
  unsigned short origPortNr; // Destination port from configuration

  enum
  {
    none = 0,
    zlib = 1,
    bzip2 = 2,
    zlib_bzip2 = 3
  } msgCompType_;

  static const char *msgCompTypeNames[];

  // when using an HTTP Proxy, this is the state during the setup of the tunnel
  enum TunnelState
  {
    HTTP_IDLE,
    HTTP_WAIT_FOR_REPLY,
    HTTP_TUNNEL_OPEN,
    MXPROXY_IDLE,
    MXPROXY_WAIT_FOR_REPLY,
    MXPROXY_TUNNEL_OPEN
  } tunnelState_;

  CharString httpReceiveBuffer_; // buffer used for receiving the HTTP response
  itcInetAddress finalAddress_;  // when using HTTP Proxy, this is the final endpoint address
  
  CharString myProxyReceiveBuffer_; // buffer used for receiving the proxy response
  
  PVSSulong peerId;              // Unique ID for each connection of this Manager
  
  bool asyncConnectRunning;

  bool mxProxyUsed;

  friend class MsgItcDispatcher;
  
  friend class UNIT_TEST_FRIEND_CLASS;
};

//--------------------------------------------------------------------------------
inline bool PeerItcIOHandler::isMxProxyUsed() const
{
  return mxProxyUsed;
}

//--------------------------------------------------------------------------------
inline void PeerItcIOHandler::flush()
{
  // Allocate new SendBufferItem, if the last was written to.
  // Needed to send the first message to the InitItcIOHandler and the following ones
  // to the PeerItcIOHandler
  if ( sendBufferList.getLast() &&
       ((SendBufferItem *) sendBufferList.getLast())->sender().raw_length() )
  appendSendBuffer();
}

//--------------------------------------------------------------------------------

inline PVSSboolean PeerItcIOHandler::isValid() const
{
  if (connectPtr && ((connectPtr->Descriptor() >= 0) || asyncConnectRunning))
    return PVSS_TRUE;

  #if defined(INVALID_SOCKET)
  if (connectPtr && connectPtr->Descriptor() != INVALID_SOCKET)
  { //COVINFO BLOCK: defensive (AP: impl error)
    ERR_IMPL_SEVERE_UNEXPECTED("wrong descriptor check? i think " << connectPtr->Descriptor() << " is valid ");
    return(PVSS_TRUE);
  } //COVINFO BLOCKEND
  #endif

  return PVSS_FALSE;
}

//--------------------------------------------------------------------------------

#endif /* _PEERITCIOHANDLER_H_ */
