// DATEINAME:      WChar.hxx
// Adaptierung von Wide Character functions

#ifndef _WCHAR_HXX_
#define _WCHAR_HXX_

#include <wchar.h>

#if defined(__ANDROID__)
#include <CharString.hxx>
#endif

// ------------ wide character ctypes ----------------------------------------

// Einige weitere Konstanten
// wcdigit
static const wchar_t WcharDigit[]   = { 
  L'0', 
  L'1',
  L'2',
  L'3',
  L'4',
  L'5',
  L'6',
  L'7',
  L'8',
  L'9'
};

// DpSymIdentifier
static const wchar_t WcharDollar = L'$';
static const wchar_t WcharColon  = L':';
static const wchar_t WcharDot    = L'.';
static const wchar_t WcharLeftBracket  = L'[';
static const wchar_t WcharRightBracket = L']';
static const wchar_t WcharLeftBrace    = L'{';
static const wchar_t WcharRightBrace   = L'}';
static const wchar_t WcharHyphen = L'@';
static const wchar_t WcharSemicolon    = L';';
static const wchar_t WcharAsterisk     = L'*';
static const wchar_t WcharComma  = L',';           // Langenscheidt...
static const wchar_t WcharQuestionmark = L'?';
static const wchar_t WcharDash   = L'-';


/// check if the given wchar is a one byte digit
inline bool wcdigit(wchar_t c)
{
  return (c == WcharDigit[0] || c == WcharDigit[1] || c == WcharDigit[2] || c == WcharDigit[3] ||
          c == WcharDigit[4] || c == WcharDigit[5] || c == WcharDigit[6] || c == WcharDigit[7] ||
          c == WcharDigit[8] || c == WcharDigit[9]);
}


// Die Laenge eines mb-Strings
// Unter Linux liefert mbstowcs(0, ...) nicht die Stringlaenge zurueck
// Der Einfachheit halber liefert die Fun einfach die Laenge zurueck, das
// reicht in jedem Fall aus
/// get length for multibyte to wchar conversion buffer; workaround for linux since mbstowcs(0,...) does not report the needed buffer length 
inline  size_t  wcslenofmbs(const char *str, size_t len)
{
  #if !defined(OS_LINUX) && !defined(OS_FREEBSD)
    return mbstowcs(0, str, len);
  #else
    return len;
  #endif
}


// Linux kann kein '\0' in wc konvertieren
static  const wchar_t WcharNull = L'\0';

#if defined(__HP) && ! defined(wcsstr)            // HPUX vs Linux
#define wcsstr wcswcs
#endif

#ifdef __ANDROID__
inline size_t wcslen(const wchar_t *src)
{
  if ( !src )
    return 0;

  size_t len = 0;
  while ( *src++ ) len++;
  return len;
}

inline wchar_t *wcscat(wchar_t *dest, const wchar_t *src)
{
  // append including terminating 0
  memcpy(dest + wcslen(dest), src, (wcslen(src) + 1) * sizeof(wchar_t));
  return dest;
}

inline wchar_t *wcscpy(wchar_t *dest, const wchar_t *src)
{
  // copy including terminating 0
  memcpy(dest, src, (wcslen(src) + 1) * sizeof(wchar_t));
  return dest;
}

inline wchar_t *wcschr(const wchar_t *wcs, wchar_t wc)
{
  if ( !wcs ) return 0;

  while ( *wcs && (*wcs != wc) )
    wcs++;

  return *wcs ? const_cast<wchar_t*>(wcs) : 0;
}

inline wchar_t *wcspbrk(const wchar_t *wcs, const wchar_t *accept)
{
  if ( !wcs || !accept ) return 0;

  while ( *wcs )
  {
    const wchar_t *p = accept;
    while ( *p && (*wcs != *p) )
      p++;

    if ( *p )
      break;

    wcs++;
  }

  return *wcs ? const_cast<wchar_t*>(wcs) : 0;
}

inline int wcsncmp(const wchar_t *s1, const wchar_t *s2, size_t n)
{
  if ( n == 0 )
    return 0;

  do
  {
    if (*s1 != *s2++)
    {
      return (*s1 - *--s2);
    }
    if (*s1++ == 0)
      break;
  }
  while (--n != 0);

  return 0;
}

inline int wcscmp(const wchar_t *s1, const wchar_t *s2)
{
  while (*s1 == *s2++)
    if (*s1++ == 0)
      return (0);
  return (*s1 - *--s2);
}

inline wchar_t *wcsncpy(wchar_t *dest, const wchar_t *src, size_t n)
{
  if ( !dest || !src ) return 0;

  wchar_t *d = dest;
  while ( n && *src )
  {
    *d++ = *src++;
    n--;
  }
  *d = 0;

  return dest;
}

#ifndef NO_BCM
inline size_t wcstombs(char *dest, const wchar_t *src, size_t n)
{
  CharString str;
  str.setWCharStr(src, n);
  strcpy(dest, str.c_str());
  
  return(str.len());
}
#endif
#endif


// There is no wcsdup for Solaris and Android
#if defined(OS_SOLARIS) || defined(__ANDROID__)
inline wchar_t * wcsdup(const wchar_t *str)
{
  if (!str)
    return NULL;

  wchar_t *copy = (wchar_t *) malloc(sizeof(wchar_t) * (wcslen(str) + 1));
  wcscpy(copy, str);

  return copy;
}
#endif

#endif	// _WCHAR_HXX_
