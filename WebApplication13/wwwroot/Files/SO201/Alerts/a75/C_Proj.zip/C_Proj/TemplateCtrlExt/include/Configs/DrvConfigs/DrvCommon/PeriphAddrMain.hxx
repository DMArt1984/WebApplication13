#ifndef _DPPERIPHADDRMAIN_H_
#define _DPPERIPHADDRMAIN_H_

// Vorwaerts-Deklaration der Eigenen Klasse
class PeriphAddrMain;

// System-Include-Files
#include <PeriphAddr.hxx>


// ................................Anfang User-Definitionen........................
// .................................Ende User-Definitionen.........................

// Vorwaerts-Deklarationen :
class CharString;
class DpConfig;
class PeriphAddrMain;

// ========== PeriphAddrMain ============================================================

/** The _address config class derived from the abstract PeriphAddr.
    This class enables to create an instance of _address config object.
    @classification ETM internal  
  */
class DLLEXP_CONFIGS PeriphAddrMain : public PeriphAddr 
{

  // Klassen-Enums:

// ..........................Anfang User-Klasseninterne-Definitionen..................
// ...........................Ende User-Klasseninterne-Definitionen...................
public:
  /// constructor, initialisation with zero values
  PeriphAddrMain();

  /// copy onstruktor
  /// @param profiAdr the PeriphAddr, which shall be copied from
  PeriphAddrMain(const PeriphAddrMain &profiAdr);

  /// destructor
  ~PeriphAddrMain();


  // Operatoren :

  /** operator << for itcNdrUbSend stream
      @param ndrStream the stream, which to send to
    */
  itcNdrUbSend &operator<<(itcNdrUbSend &ndrStream);

  /** operator >> for itcNdrUbReceive stream
      @param ndrStream the stream, which to receive from
    */
  itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream);

  /** non virtual assignment operator for PeriphAddrMain
      @param rVal the PeriphAddrMain to assign
      @return the resulting PeriphAddrMain
    */
  PeriphAddrMain &operator=(const PeriphAddrMain &rVal)
    { PeriphAddr::operator=((const PeriphAddr &) rVal); return *this; }

  // Spezielle Methoden :

  /// return type of DP config
  virtual DpConfigType isA() const;

  /// return size of DP config
  virtual unsigned long sizeOf() const;

	/** check if own DP config type matches other DP config type
      @param confType the DpConfigType to check
      @return DPCONFIG_PERIPH_ADDR if argument is PeriphAddr else the DP config type
    */
  virtual DpConfigType isA(DpConfigType confType) const;

  /// return type of DP config
  virtual DpConfigNrType getDpConfigNrUncached() const;

  /** allocate new PeriphAddrMain
      @return the new PeriphAddrMain
    */
  virtual DpConfig *allocate() const;

  // Generierte Methoden :
protected:
private:
};

// ================================================================================
// Inline-Funktionen :

inline unsigned long PeriphAddrMain::sizeOf() const
{
  return sizeof(PeriphAddrMain);
}

#endif /* _DPPROFIPERIPHADDRMAIN_H_ */

