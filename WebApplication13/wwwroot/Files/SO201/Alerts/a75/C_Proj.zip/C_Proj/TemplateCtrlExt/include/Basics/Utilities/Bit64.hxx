#ifndef  _BIT64_H_  // [
#define  _BIT64_H_

#ifndef _TYPES_HXX_
#include <Types.hxx>
#endif

#include <iostream>

#ifndef NO_BCM
class  itcNdrUbSend;
class  itcNdrUbReceive;
#endif

/**
 * A set of 64 bits which can be separately set and unset.
 */
class DLLEXP_BASICS  Bit64
{
  public:
    /**
     * Creates a new instance with no bit set.
     */
    Bit64() : value_(0) {}

    /**
     * Creates a new instance from the specified unsigned 64bit value.
     */
    Bit64(PVSSulonglong val) : value_(val) {}

    /**
     * Returns the state of the specified bit.
     *
     * Invalid indices will always return false.
     *
     * @param nr An index between 0 and 63
     * @return True if the bit is set, otherwise false.
     */
    bool getBit(unsigned nr) const;

    /**
     * Returns the byte with the specified index.
     *
     * Invalid indices will always return zero.
     *
     * @param nr An index between 0 and 7
     * @return The nr-th least significant byte.
     */
    PVSSuchar getByte(unsigned nr) const;

    /**
     * Returns the specified part of the value
     * as short (2 bytes).
     *
     * Invalid indices will always return zero.
     *
     * @param nr An index between 0 and 3
     * @return The nr-th least significant 2-byte part.
     */
    PVSSushort getShort(unsigned nr) const;

    /**
     * Returns the specified part of the value
     * as long (4 bytes).
     *
     * Invalid indices will always return zero.
     *
     * @param nr An index between 0 and 1
     * @return The specified part of the value.
     */
    PVSSulong  getLong (unsigned nr) const;

    /**
     * Sets the specified bit to the specified state.
     *
     * If state is true, the bit will be set, otherwise
     * it will be cleared.
     *
     * @param nr An index between 0 and 63
     * @param state The intended state of the bit.
     */
    void  setBit(unsigned nr, bool state);

    /**
     * Sets the specified bit.
     *
     * @param nr An index between 0 and 63
     */
    void  setBit(unsigned nr);

    /**
     * Clears the specified bit.
     *
     * @param nr An index between 0 and 63
     */
    void  clearBit(unsigned nr);
    
    /**
     * Clears all bits.
     *
     * The value will be set to 0.
     */
    void  clearAll()  { value_ = 0; }

    /**
     * Cast to PVSSulonglong.
     */
    operator PVSSulonglong () const  { return value_; }

    /**
     * Equality operator for comparison with another Bit64 instance.
     */
    int operator == (Bit64 val) const { return(getValue() == val.getValue()); }

    /**
     * Equality operator for comparison with a 64bit value.
     */
    int operator == (PVSSulonglong val) const { return(getValue() == val); }

    /**
     * Binary AND assignment operator
     */
    Bit64 & operator &= (PVSSulonglong mask) { value_ &= mask; return *this; }

    /**
     * Binary OR assignment operator
     */
    Bit64 & operator |= (PVSSulonglong mask) { value_ |= mask;  return *this; }

    /**
     * Binary OR operator
     */
    Bit64 operator | (PVSSulonglong mask) const { return Bit64(value_ | mask); }

    /**
     * Binary AND operator
     */
    Bit64 operator & (PVSSulonglong mask) const { return Bit64(value_ & mask); }

    /**
     * Get value as PVSSulonglong.
     */
    PVSSulonglong getValue() const   { return value_; }

    /**
     * Set the value of this instance to the specified unsigned 64bit value.
     */
    void  setValue(PVSSulonglong ul) { value_ = ul; }

    /**
     * Writes the specified instance to an output stream.
     */
    friend  std::ostream & operator<<(std::ostream &os, const Bit64 &val) {os << val.value_; return os;}

    /**
     * Reads an instance from an input stream.
     */
    friend  std::istream & operator>>(std::istream &is, Bit64 &val)       {is >> val.value_; return is;}

#ifndef NO_BCM
    /**
     * Writes the specified instance to a network output stream.
     */
    friend  DLLEXP_BASICS itcNdrUbSend & operator<<(itcNdrUbSend &, const Bit64 &);

    /**
     * Reads an instance from a network input stream.
     */
    friend  DLLEXP_BASICS itcNdrUbReceive & operator>>(itcNdrUbReceive &, Bit64 &);
#endif

  private:
    /**
     * Avoid implicit casts to smaller datatypes
     */
    operator signed int () const; 

    /**
     * Avoid implicit casts to smaller datatypes
     */
    operator signed char () const;

    /**
     * Avoid implicit casts to smaller datatypes
     */
    operator signed short () const;
#if SIZEOF_LONG != SIZEOF_LONGLONG
    /**
     * Avoid implicit casts to smaller datatypes
     */
    operator signed long () const;
#endif

    /**
     * Avoid implicit casts to smaller datatypes
     */
    operator unsigned int () const;

    /**
     * Avoid implicit casts to smaller datatypes
     */
    operator unsigned char () const;

    /**
     * Avoid implicit casts to smaller datatypes
     */
    operator unsigned short () const;
#if SIZEOF_LONG != SIZEOF_LONGLONG

    /**
     * Avoid implicit casts to smaller datatypes
     */
    operator unsigned long () const;
#endif
    
    /**
     * Avoid comparison with smaller datatypes
     */
    int operator== (signed int) const;

    /**
     * Avoid comparison with smaller datatypes
     */
    int operator== (signed char) const;

    /**
     * Avoid comparison with smaller datatypes
     */
    int operator== (signed short) const;
#if SIZEOF_LONG != SIZEOF_LONGLONG
    /**
     * Avoid comparison with smaller datatypes
     */
    int operator== (signed long) const;
#endif

    /**
     * Avoid comparison with smaller datatypes
     */
    int operator== (unsigned int) const;

    /**
     * Avoid comparison with smaller datatypes
     */
    int operator== (unsigned char) const;

    /**
     * Avoid comparison with smaller datatypes
     */
    int operator== (unsigned short) const;
#if SIZEOF_LONG != SIZEOF_LONGLONG
    /**
     * Avoid comparison with smaller datatypes
     */
    int operator== (unsigned long) const;
#endif
    
  private:
    PVSSulonglong  value_;
};

//------------------------------------------------------------------------------
inline  bool Bit64::getBit(unsigned nr) const
{
  if (nr > 63) return(false);

  return ((value_ & (static_cast<PVSSulonglong>(1) << nr)) ? true : false);
}

//------------------------------------------------------------------------------
inline PVSSuchar Bit64::getByte(unsigned nr) const
{
  if (nr > 7) return('\0');
  
  return (static_cast<PVSSuchar>(value_ >> 8*nr));
}

//------------------------------------------------------------------------------
inline PVSSushort Bit64::getShort(unsigned nr) const
{
  if (nr > 3) return(0);

  return (static_cast<PVSSushort>(value_ >> 16*nr));
}

//------------------------------------------------------------------------------
inline PVSSulong  Bit64::getLong (unsigned nr) const
{
  if (nr > 1) return(0);

  return (static_cast<PVSSulong>(value_ >> 32*nr));
}

//------------------------------------------------------------------------------
inline void  Bit64::setBit(unsigned nr)
{
  if (nr < 64)
    value_ |= (static_cast<PVSSulonglong>(1) << nr);
}

//------------------------------------------------------------------------------
inline void  Bit64::clearBit(unsigned nr)
{
  if (nr < 64)
    value_ &= ~(static_cast<PVSSulonglong>(1) << nr);
}

//------------------------------------------------------------------------------
inline void  Bit64::setBit(unsigned nr, bool state)
{
  (state ? setBit(nr) : clearBit(nr));
}

#endif // ]
