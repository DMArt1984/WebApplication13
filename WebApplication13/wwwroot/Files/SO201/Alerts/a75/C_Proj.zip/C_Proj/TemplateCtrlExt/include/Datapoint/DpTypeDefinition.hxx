#ifndef _DPTYPEDEFINITION_HXX_
#define _DPTYPEDEFINITION_HXX_

#include <CharString.hxx>
#include <DpTypes.hxx>
#include <DpElementType.hxx>

#include <utility>
#include <vector>
#include <ostream>

class DpType;
// forward declaration of own class
class DpTypeDefinition;

/** Class used for storing datapoint type definitions
 *
 * The class is designed as a simple tree of arbitrary dimension.
 * Each node contains the type and name of a datapoint type element.
 * For container types children are stored in an STL vector.
 *
 * DpTypeDefinitions should only be used for temporary storage of
 * datapoint type definitions.
 *
 * @see Manager::dpTypeCreate()
 *      Manager::dpTypeChange()
 *      Manager::dpTypeGet()
 */
class DLLEXP_DATAPOINT DpTypeDefinition
{
public:
  /// Grant unit tests access to our private members.
  friend class UNIT_TEST_FRIEND_CLASS;

  /// Typedef for child vectors
  typedef std::vector<DpTypeDefinition *> DpTypeDefinitions;

  /// Typedef for element name vectors.
  typedef std::vector<std::pair<DpElementId, CharString>> DpElementNames;

  /** Constructor
   *
   * The constructor only needs to be called explicitly for the root node.
   * Child nodes are constructed by the addChild function.
   *
   * @param name The name of the datapoint type element.
   *        Name will be set to "ILLEGAL" if not a valid DPT name.
   *        Name will NOT be checked for uniqueness.
   * @param type The type of the datapoint type element.
   *        Type will be set to DPELEMENT_NOELEMENT if it is an
   *        invalid type.
   * @param elId the element id if the node exists
   */
  DpTypeDefinition(const CharString & name, DpElementType type, DpElementId elId = 0);

  /** Destructor
   *
   * Recursively deletes all child nodes.
   */
  ~DpTypeDefinition();

  /** Add a type reference element to this node.
   *
   * The functions checks whether the current node is
   * container type and if a child with the same name
   * already exists.
   * In either error case no child is added.
   *
   * @param name The name of the new child element.
   * @param reference The type ID of the referenced type.
   * @param elId the element id if the node exists
   * @return A pointer to the newly created child.
   *         Returns a 0 pointer if
   *         - the current node is not a container type
   *         - the new child type is invalid
   *         - the new child name contains illegal characters
   *         - the current node contains a child with the same name
   *         Ownership remains with the DpTypeDefinition.
   */
  DpTypeDefinition * addChild(const CharString & name, DpTypeId reference, DpElementId elId = 0);
  
  /** Add a child element to this node.
   *
   * The function checks whether the current node is a
   * container type and if a child with the same name
   * already exists.
   * In either error case no child is added.
   *
   * @param name The name of the new child element.
   * @param type The type of the new child element.
   * @param elId the element id if the node exists
   * @return A pointer to the newly created child.
   *         Returns a 0 pointer if
   *         - the current node is not a container type
   *         - the new child type is invalid
   *         - the new child name contains illegal characters
   *         - the current node contains a child with the same name
   *         - the new node is a type reference @see addChild(const CharString & name, DpTypeId reference)
   *         Ownership remains with the DpTypeDefinition.
   */
  DpTypeDefinition * addChild(const CharString & name, DpElementType type, DpElementId elId = 0);

  /** @internal
   * Add a child element (tree) to this node
   *
   * @warning This function does NOT check the integrity of the
   *          tree created. An inconsistent tree will lead to
   *          unspecified behaviour. Do not call this function
   *          directly without a GOOD reason.
   *
   * This function checks whether the current node is a
   * container type, the new (root) node is valid and if
   * a child with the same name already exists.
   * In either error case no child is added.
   *
   * @param childDef the DpTypeDefinition to be added.
   *                 This node assumes ownership of the child.
   *                 This child must not already be part of the
   *                 definition tree this node belongs to.
   * @return On success PVSS_TRUE is returned.
   *         Returns PVSS_FALSE if
   *         - the current node is not a container type
   *         - the child (root) type is invalid
   *         - the child (root) name contains illegal characters
   *         - the current node contains a child with the same name
   *         The DpTypeDefinition takes ownership of the child elements.
   */
  PVSSboolean addChild(DpTypeDefinition * childDef);

  /** @internal
   * Find a child by element id
   * @param elId the element id to search for
   * @return the type definition or nullptr if not found
   */
  DpTypeDefinition * findChild(DpElementId elId);

  /** @internal
  * Find a child by name
  * @param name the name to search for
  * @return the type definition or nullptr if not found
  */
  DpTypeDefinition * findChild(const CharString &name);

 /** @internal
   * Remove a child node. The child node is not deleted.
   * @param child a pointer to a child definition
   * @return PVSS_TRUE if the child was found
  */
  PVSSboolean removeChild(const DpTypeDefinition *child);

  /** Builds a DpType with the current node as root node.
   *
   * @param rootId is the first free DpElementId that is to be
   *        used for the root element. Needed for recursive build.
   * @return A pointer to the newly created DpType object.
   *         Returns a 0 pointer upon error.
   *         The DpTypeDefinition yields ownership of the object.
   */
  DpType * buildDpType(DpElementId rootId = 1) const;

  /** Builds a flat std::vector of element names.
   * The order of the names corresponds to the order of element IDs
   * in the output of buildDpType.
   * @return A pointer to the element names vector.
   *         The DpTypeDefinition yields ownership of the object
   */
  DpElementNames * getElementNames() const;

  /** Returns whether name, type and type reference (if any) are valid.
   * @return PVSS_FALSE if
   *         - name is an illegal DpType name
   *         - type is an invalid DpElementType
   *         - no type reference is stored for a reference type node
   *         PVSS_TRUE otherwise
   */
  PVSSboolean isValid() const;

  /// Get the node's name
  const CharString & getName() const { return m_name; }

  // Change the node's name
  void setName(const CharString &name) { m_name = name; }

  /// Get the node's id
  DpElementId getId() const { return m_elId; }

  /// Get the node's type
  DpElementType getType() const { return m_type; }

  /// Get the node's child vector
  const DpTypeDefinitions & getChildren()  const { return m_children;  }

  /// Get the node's referenced type (if any)
  DpTypeId getReference() const { return m_reference; }
  
  /** @internal
   * Set the referenced type for a reference type node.
   *
   * @param reference The type id of the referenced type
   * @return PVSS_FALSE if reference is 0 or the node is not a reference type.
   *         PVSS_TRUE otherwise
   *
   * @see addChild(const CharString & name, DpTypeId reference)
   */
  PVSSboolean         setReference(DpTypeId reference);

  /** @internal
   * Debug the type definition
   */
  void debug(std::ostream &str, int indent = 0) const;

private:
  /* Check whether the current node can have a specific child.
   * The function checks for proper name and type.
   */
  PVSSboolean canHaveChild(const DpTypeDefinition & newChild) const;

  DpElementId         m_elId;
  DpElementType       m_type;
  CharString          m_name;
  DpTypeId            m_reference;

#ifdef WIN32
#pragma warning ( push )
#pragma warning ( disable: 4251 )
#endif
  DpTypeDefinitions   m_children;
#ifdef WIN32
#pragma warning ( pop )
#endif

  // we don't want the compiler to generate any of these for us
  // if we ever need deep copies we should do it ourselves
  DpTypeDefinition(const DpTypeDefinition &);
  DpTypeDefinition & operator=(const DpTypeDefinition &);
};

#endif /* _DPTYPEDEFINITION_HXX_ */
