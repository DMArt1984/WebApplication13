// DATEIBESCHREIBUNG ==============================================================
// DATEINAME:     AlertIdentifier.hxx
//
//
// AENDERUNGS-HISTORIE
// Ver.  | Datum      | Aenderungen                            | ModNr.| Autor
// ------+------------+-----------------Anfang-----------------+-------+-----------
//   1.0 |            | 1.Erstellung mit Westmount-OMT         |     0 |
// tschirk, 16.12.2009: Comments added/corrected for doxygen (IM97338)
// ======================================Ende======================================

#ifndef _ALERTIDENTIFIER_H_
#define _ALERTIDENTIFIER_H_

// Vorwaerts-Deklaration der Eigenen Klasse
class AlertIdentifier;

// System-Include-Files

#ifndef _ALERTTIME_H_
#include <AlertTime.hxx>
#endif

#ifndef _TYPES_HXX_
#include <Types.hxx>
#endif

#ifndef _DPCONFIGNRTYPE_H_
#include <DpConfigNrType.hxx>
#endif

#ifndef _DPIDENTIFIER_H_
#include <DpIdentifier.hxx>
#endif

// Vorwaerts-Deklarationen :
class itcNdrUbSend;
class itcNdrUbReceive;

// ========== AlertIdentifier ============================================================

/** the alert identifier class.
  * an alert identifier is a dpIdentifier which has an additional member,
  * the alert time. this kind of identifier is used inside alert messages.
  */
class DLLEXP_BASICS AlertIdentifier : public DpIdentifier 
{
public:
  /** constructor
    * initialisation with zero values
    */
  AlertIdentifier();
  /** copy constructor
    * @param id The AlertIdentifier from which shall be copied
    */
  AlertIdentifier(const AlertIdentifier &id);
  /** constructor
    * @param id The DpIdentifier from which shall be copied
    * @param anAlertTime The AlertTime that shall be set - if empty 0 time
    */
  AlertIdentifier(const DpIdentifier &id, const AlertTime &anAlertTime = AlertTime());
  /** constructor
    * @param aSys The System of the AlertIdentifier
    * @param aDp The DatapointId of the AlertIdentifier
    * @param anEl The ElementId of the AlertIdentifier
    * @param aConf The Config of the AlertIdentifier
    * @param aDet The Detail of the AlertIdentifier
    * @param anAttr The Attribute of the AlertIdentifier
    * @param theTime The Time of the AlertIdentifier - if empty 0 time
    * @param aCount The timecount (for equal times) of the AlertIdentifier - if empty 0
    */
  AlertIdentifier(SystemNumType aSys, DpIdType aDp, DpElementId anEl, DpConfigNrType aConf, DpDetailNrType aDet, DpAttributeNrType anAttr, const PVSSTime &theTime = PVSSTime(0, 0), PVSSushort aCount = 0);  
  /** destructor
    */
  ~AlertIdentifier();
 
  /** assignment operator 
    * @param id The AlertIdentifier which shall be asigned
    * @return The assigned AlertIdentifier
    */
  AlertIdentifier &operator=(const AlertIdentifier &id);

  /** comparison operator 
    * @param id The AlertIdentifier to compare with
    * @return 0 if not equal (else 1)
    */
  int operator==(const AlertIdentifier &id) const;

  /** comparison operator 
    * @param id The AlertIdentifier to compare with
    * @return 0 if the elements in the AlertIdentifiers are equal (else 1)
    */
  int operator!=(const AlertIdentifier &id) const;

  /** comparison operator. 
    * an AlertIdentifier is smaller than another if
    * - the system is smaller
    * - the system is equal and the dpId is smaller
    * - the system and dpId are equal and the element is smaller
    * - the system, dpId and element are equal and the config is smaller
    * - the system, dpId, element and config are equal and the detail is smaller
    * - the system, dpId, element, config and detail are equal and the attribute is smaller
    * - the system, dpId, element, config, detail and attribute are equal and the dpType is smaller
    * - the system, dpId, element, config, detail, attribute and dpType are equal and the time is smaller
    * - the system, dpId, element, config, detail, attribute, dpType and time are equal and the timecounter is smaller
    * @param id The AlertIdentifier to compare with
    * @return 0 if the AlertIdentifier to compare with is smaller or equal (else 1)
    */
  int operator<(const AlertIdentifier &id) const;

  /** comparison operator.
    * an AlertIdentifier is bigger than another if 
    * - the system is bigger
    * - the system is equal and the dpId is bigger
    * - the system and dpId are equal and the element is bigger
    * - the system, dpId and element are equal and the config is bigger
    * - the system, dpId, element and config are equal and the detail is bigger
    * - the system, dpId, element, config and detail are equal and the attribute is bigger
    * - the system, dpId, element, config, detail and attribute are equal and the dpType is bigger
    * - the system, dpId, element, config, detail, attribute and dpType are equal and the time is bigger
    * - the system, dpId, element, config, detail, attribute, dpType and time are equal and the timecounter is bigger
    * @param id The AlertIdentifier to compare with
    * @return 0 if the AlertIdentifier to compare with is bigger or equal (else 1)
    */
  int operator>(const AlertIdentifier &id) const;

  /** comparison operator.
    * implements (x < y || x == y)
    * @param id The AlertIdentifier to compare with
    * @return 0 if the AlertIdentifier to compare with is smaller (else 1)
    */
  // new method (IM 98523)
  int operator<=(const AlertIdentifier &id) const;

  /** comparison operator.
    * implements (x > y || x == y)
    * @param id The AlertIdentifier to compare with
    * @return 0 if the AlertIdentifier to compare with is bigger (else 1)
    */
  // new method (IM 98523)
  int operator>=(const AlertIdentifier &id) const;

  /** the message stream send operator.
    * this operator is used to send an alert identifier through the
    * BCM message connection.
    * @param ndrStream The itcNdrUbSend stream
    * @param id The AlertIdentifier to add to the stream
    * @return the resulting itcNdrUbSend stream
    * @internal
    */
  friend DLLEXP_BASICS itcNdrUbSend &operator<<(itcNdrUbSend &ndrStream, const AlertIdentifier &id);
  /** the message stream receive operator. 
    * this operator is used to receive an alert identifier through the
    * BCM message connection.
    * @param ndrStream The itcNdrUbReceive stream
    * @param id The AlertIdentifier to get from the stream
    * @return the remaining itcNdrUbReceive stream
    * @internal
    */
  friend DLLEXP_BASICS itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream, AlertIdentifier &id);

  /** tool function. 
    * use this function to reset all data members
    */
  virtual void invalidateAll();
  
  // die im compareKey gesetzten Bits bestimmen, was verglichen wird
  // dazu sind Konstanten definiert, welche verodert werden koennen

  /** tool function. 
    * the dpIdentifier compare function overloaded to compare the
    * AlertTime, too. the compare key determines what we should compare. 
    * @see DpIdentifier::isEqual
    * @param withDpId the comparison partner
    * @param compareKey defines what to do by using the enumerator dpCompFlags.
    * @return PVSS_TRUE if equal
    */
  PVSSboolean isEqual(const AlertIdentifier &withDpId, PVSSushort compareKey) const;

  /** tool function. 
    * checks if every member is Null (overloaded from dpIdentifier to check the AlertTime too)
    * @see DpIdentifier::isNull
    * @return PVSS_TRUE if all members are NULL
    */
  // new method (IM 98523)
  int isNull() const;

// Spezial-Routine fuer AlertList::insertAttribute()
// prueft ob this groesser als id ist, ueberprueft wird Sys, Dp, El, Conf, AlertTime,
// Det und zwar in der aufgefuehrten Reihenfolge (! Attr wird nicht geprueft)
  /** tool function. 
    * a compare function mainly for AlertList::insertAttribute()
    * checks if this is greater than the AlertIdentifier to compare with
    * checked will be Sys, Dp, El, Conf, AlertTime, Det in this order. 
    * Attr will not be checked.
    * @param id the comparison partner
    * @return PVSS_TRUE if this is greater, PVSS_FALSE else
    */
  PVSSboolean greater(const AlertIdentifier &id) const;

  /** debug function. 
    * call this to dump the list to a file stream.
    * @param to the target stream
    * @param level the detail level of information, should be > 0
    */
  virtual void debug(std::ostream &to, int level) const;

  /** convert function.
    * Convenient function to generate a string representation without returning a "valid" information.
    * Mainly useful in ErrHdl output.
    * If no conversionmethod is set the stringrepresentation of the internal DpIdentifier is returned. 
    * @see DpIdentifier::toString
    * @see DpIdentifier::setConvertToStringFct
    * @return The created CharString
    */  
  CharString toString() const;

  /** convert function.
    * Convenient function to generate a string representation without returning a "valid" information.
    * Mainly useful in ErrHdl output.
    * If no conversionmethod is set the stringrepresentation of the internal DpIdentifier is returned. 
    * @see DpIdentifier::toString
    * @see DpIdentifier::setConvertToStringFct
    * @param extendedFormat if true the stringrepresentation of the alert time is added to the result.
    * @return The created CharString
    */
  CharString toString(bool extendedFormat) const;

  // Generierte Methoden :
  /** tool function. 
    * get the alert time 
    * @return the alert time
    */
  const AlertTime &getAlertTime() const;
  /** tool function. 
    * get the alert time 
    * @return the alert time
    */
  AlertTime &getAlertTime();
  /** tool function. 
    * set the alert time 
    * @param newAlertTime the new alert time
    */
  void setAlertTime(const AlertTime &newAlertTime);
protected:
private:
  AlertTime aTime;

};

#ifdef WIN32
#pragma warning ( disable: 4231 )
#endif

#if defined(LIBS_AS_DLL)
  #include <DynPtrArray.hxx>
  EXTERN_BASICS template class DLLEXP_BASICS DynPtrArray<AlertIdentifier>;
#endif

#ifdef WIN32
#pragma warning ( default: 4231 )
#endif

  
// ================================================================================
// Inline-Funktionen :
inline const AlertTime &AlertIdentifier::getAlertTime() const
{
  return aTime;
}

inline AlertTime &AlertIdentifier::getAlertTime()
{
  return aTime;
}
inline void AlertIdentifier::setAlertTime(const AlertTime &newAlertTime)
{
  aTime = (AlertTime &) newAlertTime;
}

inline void AlertIdentifier::invalidateAll()
{
	DpIdentifier::invalidateAll();
  aTime = AlertTime();
}

// Destruktor
inline AlertIdentifier::~AlertIdentifier()
{
}

// Konstruktor
inline AlertIdentifier::AlertIdentifier()
{
	invalidateAll();
}

inline AlertIdentifier &AlertIdentifier::operator=(const AlertIdentifier &id)
{
	DpIdentifier::operator=((const DpIdentifier &) id);
	aTime = id.aTime;
	
	return *this;
}

// Konstruktor
inline AlertIdentifier::AlertIdentifier(const AlertIdentifier &id)
{
	*this = id;
}

// Konstruktor
inline AlertIdentifier::AlertIdentifier(const DpIdentifier &id, const AlertTime &anAlertTime)
	: DpIdentifier(id),
	  aTime(anAlertTime)
{
}

// Konstruktor
inline AlertIdentifier::AlertIdentifier(SystemNumType aSys, DpIdType aDp, DpElementId anEl, DpConfigNrType aConf, DpDetailNrType aDet, DpAttributeNrType anAttr, const PVSSTime &theTime, PVSSushort aCount)
	: DpIdentifier(aSys, aDp, anEl, aConf, aDet, anAttr),
	  aTime(theTime, aCount)
{
}

inline int AlertIdentifier::operator==(const AlertIdentifier &id) const
{
	return DpIdentifier::operator==((const DpIdentifier &) id) &&
		aTime == id.aTime;
}

inline int AlertIdentifier::operator!=(const AlertIdentifier &id) const
{
	return ! (*this == id);
}

inline int AlertIdentifier::operator<(const AlertIdentifier &id) const
{
	if (DpIdentifier::operator<((const DpIdentifier &) id)) return 1;
	if (DpIdentifier::operator==((const DpIdentifier &) id) &&
		aTime < id.aTime) return 1;

	return 0;
}

inline int AlertIdentifier::operator>(const AlertIdentifier &id) const
{
	return !(*this == id || *this < id);
}

inline int AlertIdentifier::operator<=(const AlertIdentifier &id) const
{
  return (*this < id || *this == id);
}
 
inline int AlertIdentifier::operator>=(const AlertIdentifier &id) const
{
  return !(*this < id); //take !(<) instead of (> || ==) because less functioncalls
}

inline PVSSboolean AlertIdentifier::isEqual(const AlertIdentifier &withDpId, PVSSushort compareKey) const
{
	// Sortiert nach der Wahrscheinlichkeit des Unterschieds
	return (DpIdentifier::isEqual(withDpId, compareKey) &&
        ((compareKey & compTime) == 0 || aTime == withDpId.aTime));
}

inline int AlertIdentifier::isNull() const
{
  return (DpIdentifier::isNull() && this->aTime == AlertTime::NullTime);
}

// Spezial-Routine fuer AlertList::insertAttribute()
// prueft ob this groesser als id ist, ueberprueft wird Sys, Dp, El, Conf, AlertTime,
// Det und zwar in der aufgefuehrten Reihenfolge (! Attr wird nicht geprueft)
inline PVSSboolean AlertIdentifier::greater(const AlertIdentifier &id) const
{
    return                         (system > id.system ||
           (system == id.system && (dp     > id.dp     ||
           (dp     == id.dp     && (el     > id.el     ||
           (el     == id.el     && (config > id.config ||
           (config == id.config && (aTime  > id.aTime  ||
           (aTime  == id.aTime  && (detail > id.detail)))))))))));
}

#endif /* _ALERTIDENTIFIER_H_ */
