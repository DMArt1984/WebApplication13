#ifndef _NAMESERVERSYSMSG_H_
#define _NAMESERVERSYSMSG_H_

/** The result codes for queries */
enum NameServerResponseStatus
{
  /// Queried element was found
  NS_RESPONSE_OK,
  /// Queried element does not exist
  NS_RESPONSE_NONEXISTENT,
  /// An error occured
  NS_RESPONSE_ERROR
};


class NameServerSysMsg;

#include <SysMsg.hxx>
#include <CharString.hxx>
#include <DpIdentifier.hxx>
#include <PtrList.hxx>
#include <DpIdentifierItem.hxx>
#include <CNSDataIdentifier.hxx>


// ========== NameServerSysMsg ============================================================

/**
 * A message to query the DpIdentification.
 *
 * Managers that do not have a DpIdentification can send this message to the
 * data manager to query the DpIdentifier for any datapoint, config,
 * etc. or to query various information in CNS.
 *
 * See NameServiceSubType for the available queries.
 *
 * The answer is a NameServerSysMsg, too.
 */
class DLLEXP_MESSAGES NameServerSysMsg : public SysMsg
{
  public:
    friend class UNIT_TEST_FRIEND_CLASS;

    /// Default constructor
    NameServerSysMsg();

    /** Constructor that takes a destination for the message so that
     *  this information need not be set later
     *
     * @param newDestination the designated receiving Manager
     */
    NameServerSysMsg(const ManagerIdentifier &newDestination);

    /// Copy constructor
    NameServerSysMsg(const NameServerSysMsg &msg);

    /// Destructor
    ~NameServerSysMsg();

    /// sets the queriy result code, only relevant for responses
    void setResponseStatus(NameServerResponseStatus newStatus);
    /// gets the queriy result code, only relevant for responses
    NameServerResponseStatus getResponseStatus();

    /** BCM output streaming
     *
     * @param [in,out] ndrStream an open BCM output stream
     * @param [in] sysMsg the message to write to the stream
     * @return always ndrStream
     */
    friend DLLEXP_MESSAGES itcNdrUbSend &operator<<(itcNdrUbSend &ndrStream, const NameServerSysMsg &sysMsg);

    /** BCM input streaming
     *
     * @param [in,out] ndrStream an open BCM input stream
     * @param [out] sysMsg the message to read from the stream
     * @return always ndrStream
     */
    friend DLLEXP_MESSAGES itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream, NameServerSysMsg &sysMsg);

    /** file streaming, for debugging purposes
     *
     * @param [in,out] ofStream an open output stream
     * @param [in] sysMsg the message to write to the stream
     * @return always ofStream
     */
    friend DLLEXP_MESSAGES std::ostream &operator<<(std::ostream &ofStream, const NameServerSysMsg &sysMsg);

    /** Equality operator, considers all properties of the message
     *
     * @param rVal the message to compare to
     * @return 0 if rVal is not a NameServerSysMsg, otherwise the return value
     *         of operator==(const NameServerSysMsg&)
     */
    virtual int operator==(const Msg &rVal) const;

    /** Equality operator, considers all properties of the message
     *
     * @param rVal the message to compare to
     * @return 1 if all properties of this and rVal are equal, 0 otherwise
     */
    int operator==(const NameServerSysMsg &rVal) const;

    /** Assignment operator, duplicates all properties of rVal into this message
     *  if and only if rVal is a NameServerSysMsg, will not alter the object otherwise
     *
     * @param rVal the message to take all property values from
     * @return a reference to the current message instance
     */
    Msg &operator=(const Msg &rVal);
    
    /** Assignment operator, duplicates all properties of rVal into this message
     *
     * @param rVal the message to take all property values from
     * @return a reference to the current message instance
     */
    NameServerSysMsg &operator=(const NameServerSysMsg &rVal);

    /** Check if the own message type is assignable from the given MsgType
     *
     * @param msgType a message type
     * @return SYS_MSG_NAMESERVER if msgType is SYS_MSG_NAMESERVER, NO_MSG otherwise
     */
    virtual MsgType isA(MsgType msgType) const;

    /// Get own message type @return always SYS_MSG_NAMESERVER
    virtual MsgType isA() const;

    /** Determines if this message is a response or a query
     *
     * @return 0 if this message is a query, otherwise a pointer
     *         to the query's message id
     */
    virtual const PVSSulong *isAnswer() const;

    /** Determines if this message is a query or a response
     *
     * @return PVSS_TRUE if the message is a query, PVSS_FALSE otherwise
     */
    virtual PVSSboolean needsAnswer() const;
    
    /** BCM input streaming
     *
     * @param [in,out] ist an open BCM input stream
     */
    virtual void inNdrUb(itcNdrUbReceive &ist);

    /** BCM output streaming
     *
     * @param [in,out] ost an open BCM output stream
     */
    virtual void outNdrUb(itcNdrUbSend &ost) const;
    
    /** file streaming, for debugging purposes
     *
     * @param [in,out] ofStream an open output stream
     */
    virtual void outToFile(std::ostream &ofStream) const;

    /** Allocates a new Msg of the same type as this message
     *
     * @return always a NameServerSysMsg initialized with the default
     *         constructor NameServerSysMsg()
     */
    virtual Msg *allocate() const;

    /** file streaming, for debugging purposes, will only perform streaming if
     *  level is at least 2
     *
     * @param [in,out] to an open output stream
     * @param [in] level the debug level
     */
    virtual void debug(std::ostream &to, int level) const;

    /** Converts this message to a message with the corresponding response type.
     *  If the message is already a response, this method does nothing.
     *
     * @return PVSS_TRUE if the message was a query and is now a response,
     *         PVSS_FALSE if the message was already a response
     */
    PVSSboolean convertToResponse();

    /** Set the DpIdentifier for which the datapoint name will be returned in the
     *  response message.
     *
     * @param dpIdent the DpIdentifier to query
     * @return PVSS_TRUE if succeeded, PVSS_FALSE otherwise
     */
    PVSSboolean setDpNameQuery(const DpIdentifier & dpIdent);

    /** Get the DpIdentifier for which the datapoint name shall be returned in the
     *  response message.
     *
     * @param [out] dpIdent the DpIdentifier to query
     * @return PVSS_TRUE if succeeded, PVSS_FALSE otherwise
     */
    PVSSboolean getDpNameQuery(DpIdentifier & dpIdent) const;

    /** Set the datapoint type name for which the DpTypeId will be returned in the
     *  respone message.
     *
     * @param dptName the datapoint type name to query
     * @return PVSS_TRUE if succeeded, PVSS_FALSE otherwise
     */
    PVSSboolean setDpTypeQuery(const CharString & dptName);
    
    /** Get the datapoint type name for which the DpTypeId shall be returned in the
     *  respone message.
     *
     * @param [out] dptName the datapoint type name to query
     * @return PVSS_TRUE if succeeded, PVSS_FALSE otherwise
     */
    PVSSboolean getDpTypeQuery(CharString & dptName) const;

    // DPID_QUERY
    /** Set the datapoint name for which the DpIdentifier will be returned in the
     *  response message.
     *
     * @param newName the datapoint name to query
     * @param newLang the language of newName
     * @return PVSS_TRUE if succeeded, PVSS_FALSE otherwise
     */
    PVSSboolean setDpIdQuery(const CharString &newName, LanguageIdType newLang = 0);

    /** Get the datapoint name for which the DpIdentifier shall be returned in the
     *  response message.
     *
     * @param [out] queryRef the datapoint name to query
     * @param [out] langRef the language of queryRef
     * @return PVSS_TRUE if succeeded, PVSS_FALSE otherwise
     */
    PVSSboolean getDpIdQuery(CharString &queryRef, LanguageIdType &langRef) const;

    // SYSTEMNAMES_QUERY
    /**
     * Set the system name for which the CNS display names of this system will
     * be returned in the response message.
     *
     * @param sysName the system name to query
     * @return PVSS_TRUE if succeeded, PVSS_FALSE otherwise
     */
    PVSSboolean setCNSSystemNamesQuery(const CharString &sysName);

    /**
     * Get the system name for which the CNS display names of this system shall
     * be returned in the response message.
     *
     * @param [out] sysName the system name to query
     * @return PVSS_TRUE if succeeded, PVSS_FALSE otherwise
     */
    PVSSboolean getCNSSystemNamesQuery(CharString &sysName) const;
    
    // VIEWS_QUERY
    /**
     * Set the system name for which the CNS display names of this system will
     * be returned in the response message.
     *
     * @param sysName the system name to query
     * @return PVSS_TRUE if succeeded, PVSS_FALSE otherwise
     */
    PVSSboolean setCNSViewsQuery(const CharString &sysName);

    /**
     * Get the system name for which the CNS display names of this system shall
     * be returned in the response message.
     *
     * @param [out] sysName the system name to query
     * @return PVSS_TRUE if succeeded, PVSS_FALSE otherwise
     */
    PVSSboolean getCNSViewsQuery(CharString &sysName) const;
    
    // VIEW_DISPLAYNAMES_QUERY
    /**
     * Set the path of a CNS view for which the display names will be returned
     * in the response message.
     *
     * @param viewPath the view path to query
     * @return PVSS_TRUE if succeeded, PVSS_FALSE otherwise
     */
    PVSSboolean setCNSViewDisplayNamesQuery(const CharString &viewPath);

    /**
     * Get the path of a CNS view for which the display names shall be returned
     * in the response message.
     *
     * @param [out] viewPath the view path to query
     * @return PVSS_TRUE if succeeded, PVSS_FALSE otherwise
     */
    PVSSboolean getCNSViewDisplayNamesQuery(CharString &viewPath) const;
    
    // VIEW_SEPARATORS_QUERY
    /**
     * Set the path of a CNS view for which the separators will be returned
     * in the response message.
     *
     * @param viewPath the view path to query
     * @return PVSS_TRUE if succeeded, PVSS_FALSE otherwise
     */
    PVSSboolean setCNSViewSeparatorsQuery(const CharString &viewPath);

    /**
     * Get the path of a CNS view for which the separators shall be returned
     * in the response message.
     *
     * @param [out] viewPath the view path to query
     * @return PVSS_TRUE if succeeded, PVSS_FALSE otherwise
     */
    PVSSboolean getCNSViewSeparatorsQuery(CharString &viewPath) const;
    
    // TREES_QUERY
    /**
     * Set the path of a CNS view for which the paths of the trees contained
     * in it will be returned in the response message.
     *
     * @param viewPath the view path to query
     * @return PVSS_TRUE if succeeded, PVSS_FALSE otherwise
     */
    PVSSboolean setCNSTreesQuery(const CharString &viewPath);

    /**
     * Get the path of a CNS view for which the paths of the trees contained
     * in it shall be returned in the response message.
     *
     * @param [out] viewPath the view path to query
     * @return PVSS_TRUE if succeeded, PVSS_FALSE otherwise
     */
    PVSSboolean getCNSTreesQuery(CharString &viewPath) const;
    
    // CHILDREN_QUERY
    /**
     * Set the path of a CNS node for which the paths of the child nodes
     * contained in it will be returned in the response message.
     *
     * @param nodePath the node path to query
     * @return PVSS_TRUE if succeeded, PVSS_FALSE otherwise
     */
    PVSSboolean setCNSChildrenQuery(const CharString &nodePath);

    /**
     * Get the path of a CNS node for which the paths of the child nodes
     * contained in it shall be returned in the response message.
     *
     * @param [out] nodePath the node path to query
     * @return PVSS_TRUE if succeeded, PVSS_FALSE otherwise
     */
    PVSSboolean getCNSChildrenQuery(CharString &nodePath) const;
    
    // DISPLAYNAMES_QUERY
    /**
     * Set the path of a CNS node for which the display names will be returned
     * in the response message.
     *
     * @param nodePath the node path to query
     * @return PVSS_TRUE if succeeded, PVSS_FALSE otherwise
     */
    PVSSboolean setCNSDisplayNamesQuery(const CharString &nodePath);

    /**
     * Get the path of a CNS node for which the display names shall be returned
     * in the response message.
     *
     * @param [out] nodePath the node path to query
     * @return PVSS_TRUE if succeeded, PVSS_FALSE otherwise
     */
    PVSSboolean getCNSDisplayNamesQuery(CharString &nodePath) const;
    
    // ID_QUERY
    /**
     * Set the path of a CNS node for which the CNSDataIdentifier and the name
     * of the contained datapoint (if it is a datapoint) will be returned in
     * the response message.
     *
     * @param nodePath the node path to query
     * @return PVSS_TRUE if succeeded, PVSS_FALSE otherwise
     */
    PVSSboolean setCNSIdQuery(const CharString &nodePath);

    /**
     * Set the path of a CNS node for which the CNSDataIdentifier and the name
     * of the contained datapoint (if it is a datapoint) shall be returned in
     * the response message.
     *
     * @param [out] nodePath the node path to query
     * @return PVSS_TRUE if succeeded, PVSS_FALSE otherwise
     */
    PVSSboolean getCNSIdQuery(CharString &nodePath) const;
    
    // IDSET_QUERY
    /**
     * Set the search criteria for a search returning the CNSDataIdentifiers
     * and the names of the contained datapoints for all matching nodes.
     *
     * @param pattern       The name pattern.
     *                      e.q. System1.�berwachungsansicht:*B1*.
     * @param viewPath      If the pattern contains no view path this is a preselection
     *                      of the view that should be searched.
     * @param searchmode    a binary or combination of one or more of the following flags
     *                      - If CommonNameService::NAME only the name is used for search
     *                      - If CommonNameService::DISPLAY_NAME only the display names are
     *                        used (with respect of langIdx)
     *                      - If CommonNameService::ALL_NAMES the name and the
     *                        display names are used (with respect of langIdx)
     * @param langIdx       If not CommonNameService::ALL_LANGUAGES a preselection of the
     *                      display language.
     * @param type          If not CommonNameService::ALL_TYPES only CNSDataIdentifiers of
     *                      the same type are returned.
     * @return PVSS_TRUE if succeeded, PVSS_FALSE otherwise
     *
     * @see CommonNameService::getIdSet()
     */
    PVSSboolean setCNSIdSetQuery(const CharString &pattern, const CharString &viewPath,
                              int searchmode, LanguageIdType langIdx,
                              CNSDataIdentifierType type);

    /**
     * Get the search criteria for a search returning the CNSDataIdentifiers
     * and the names of the contained datapoints for all matching nodes.
     *
     * @param pattern       The name pattern.
     *                      e.q. System1.�berwachungsansicht:*B1*.
     * @param viewPath      If the pattern contains no view path this is a preselection
     *                      of the view that should be searched.
     * @param searchMode    a binary or combination of one or more of the following flags
     *                      - If CommonNameService::NAME only the name is used for search
     *                      - If CommonNameService::DISPLAY_NAME only the display names are
     *                        used (with respect of langIdx)
     *                      - If CommonNameService::ALL_NAMES the name and the
     *                        display names are used (with respect of langIdx)
     * @param langIdx       If not CommonNameService::ALL_LANGUAGES a preselection of the
     *                      display language.
     * @param type          If not CommonNameService::ALL_TYPES only CNSDataIdentifiers of
     *                      the same type are returned.
     * @return PVSS_TRUE if succeeded, PVSS_FALSE otherwise
     *
     * @see CommonNameService::getIdSet()
     */
    PVSSboolean getCNSIdSetQuery(CharString &pattern, CharString &viewPath,
                              int &searchMode, LanguageIdType &langIdx,
                              CNSDataIdentifierType &type) const;

    // NODESBYNAME_QUERY
    /**
     * Set the search criteria for a search returning the paths of all matching
     * nodes.
     *
     * @param pattern       The name pattern.
     *                      e.q. System1.�berwachungsansicht:*B1*.
     * @param viewPath      If the pattern contains no view path this is a preselection
     *                      of the view that should be searched.
     * @param searchMode    a binary or combination of one or more of the following flags
     *                      - If CommonNameService::NAME only the name is used for search
     *                      - If CommonNameService::DISPLAY_NAME only the display names are
     *                        used (with respect of langIdx)
     *                      - If CommonNameService::ALL_NAMES the name and the
     *                        display names are used (with respect of langIdx)
     * @param langIdx       If not CommonNameService::ALL_LANGUAGES a preselection of the
     *                      display language.
     * @param type          If not CommonNameService::ALL_TYPES only CNSDataIdentifiers of
     *                      the same type are returned.
     * @return PVSS_TRUE if succeeded, PVSS_FALSE otherwise
     *
     * @see CommonNameService::getNodes()
     */
    PVSSboolean setCNSNodesByNameQuery(const CharString &pattern, const CharString &viewPath,
                                    int searchMode, LanguageIdType langIdx,
                                    CNSDataIdentifierType type);

    /**
     * Get the search criteria for a search returning the paths of all matching
     * nodes.
     *
     * @param pattern       The name pattern.
     *                      e.q. System1.�berwachungsansicht:*B1*.
     * @param viewPath      If the pattern contains no view path this is a preselection
     *                      of the view that should be searched.
     * @param searchMode    a binary or combination of one or more of the following flags
     *                      - If CommonNameService::NAME only the name is used for search
     *                      - If CommonNameService::DISPLAY_NAME only the display names are
     *                        used (with respect of langIdx)
     *                      - If CommonNameService::ALL_NAMES the name and the
     *                        display names are used (with respect of langIdx)
     * @param langIdx       If not CommonNameService::ALL_LANGUAGES a preselection of the
     *                      display language.
     * @param type          If not CommonNameService::ALL_TYPES only CNSDataIdentifiers of
     *                      the same type are returned.
     * @return PVSS_TRUE if succeeded, PVSS_FALSE otherwise
     *
     * @see CommonNameService::getNodes()
     */
    PVSSboolean getCNSNodesByNameQuery(CharString &pattern, CharString &viewPath,
                                    int &searchMode, LanguageIdType &langIdx,
                                    CNSDataIdentifierType &type) const;

    // NODESBYDATA_QUERY
    /**
     * Set the search criteria for a search returning the paths of all nodes
     * which contain a matching CNSDataIdentifier.
     *
     * @param dpName    datapoint name
     * @param viewPath  a preselection of the view that should be searched.
     * @param type      If not CommonNameService::ALL_TYPES only CNSDataIdentifiers of
     *                  the same type are returned.
     * @return PVSS_TRUE if succeeded, PVSS_FALSE otherwise
     *
     * @see CommonNameService::getNodes()
     */
    PVSSboolean setCNSNodesByDataQuery(const CharString &dpName, const CharString &viewPath, CNSDataIdentifierType type);

    /**
     * Get the search criteria for a search returning the paths of all nodes
     * which contain a matching CNSDataIdentifier.
     *
     * @param dpName    datapoint name
     * @param viewPath  a preselection of the view that should be searched.
     * @param type      If not CommonNameService::ALL_TYPES only CNSDataIdentifiers of
     *                  the same type are returned.
     * @return PVSS_TRUE if succeeded, PVSS_FALSE otherwise
     *
     * @see CommonNameService::getNodes()
     */
    PVSSboolean getCNSNodesByDataQuery(CharString &dpName, CharString &viewPath, CNSDataIdentifierType &type) const;

    // DPID_RESPONSE
    /**
     * Convenience method that converts the message to a response and sets the
     * result to the specified DpId.
     * Works only for NAME_SERVER_DPID_QUERY. For other queries,
     * use convertToResponse() and set the result with the corresponding
     * set<QueryType>Response().
     *
     * @param newDpId the DpIdentifier for the response
     * @return equal to the return values of convertToResponse()
     */
    PVSSboolean convertToResponse(const DpIdentifier &newDpId);

    /** Set the answer data for a NAME_SERVICE_DPNAME_QUERY
     *
     * @param dpIdent The DpIdentifier queried
     * @param dpName  The corresponding datapoint name
     * @return PVSS_TRUE if succeeded, PVSS_FALSE otherwise
     */
    PVSSboolean setDpNameResponse(const DpIdentifier & dpIdent, const CharString & dpName);

    /** Get the response data of a NAME_SERVICE_DPNAME_QUERY. Note that you have to check the return value.
     *
     * @param [out] dpIdent The DpIdentifier queried
     * @param [out] dpName  The corresponding datapoint name
     * @return NS_RESPONSE_OK if the data are valid. Any other return value means invalid data.
     */
    NameServerResponseStatus getDpNameResponse(DpIdentifier & dpIdent, CharString & dpName) const;

    /** Set the answer data for a NAME_SERVICE_DPTYPE_QUERY
     *
     * @param dptName The datapoint type name queried
     * @param dpType  The corresponding datapoint type ID
     * @return PVSS_TRUE if succeeded, PVSS_FALSE otherwise
     */
    PVSSboolean setDpTypeResponse(const CharString & dptName, const DpTypeId & dpType);
    
    /** Get the response data of a NAME_SERVICE_DPTYPE_QUERY. Note that you have to check the return value.
     *
     * @param [out] dptName The datapoint type name queried
     * @param [out] dpType  The corresponding datapoint type ID
     * @return NS_RESPONSE_OK if the data are valid. Any other return value means invalid data.
     */
    NameServerResponseStatus getDpTypeResponse(CharString & dptName, DpTypeId & dpType) const;

    /** Set the answer data for a NAME_SERVER_DPID_QUERY
     *
     * @param newAnswerId the message id of the query
     * @param newName The datapoint name queried. 
     * @param newLang The language the datapoint name was given.
     * @param newDpId The DpIdentifier of the datapoint
     * @return PVSS_TRUE if succeeded, PVSS_FALSE otherwise
     */
    PVSSboolean setDpIdResponse(PVSSlong newAnswerId, const CharString &newName, 
        LanguageIdType newLang, const DpIdentifier &newDpId);
    
    /** Adds additional answer data for a NAME_SERVER_DPID_QUERY. The first data
     *  element must be added by setDpIdResponse(), which sets the answer id and
     *  the language for all datapoints in the response.
     *
     * @param name The datapoint name queried. 
     * @param dpId The DpIdentifier of the datapoint
     * @return PVSS_TRUE if succeeded, PVSS_FALSE otherwise
     */
    PVSSboolean addDpIdResponse(const CharString &name, const DpIdentifier &dpId);

    /** Get the response data of a DPID_QUERY. Note that you have to check the return value.
     *
     * @param nameRef  The datapoint name queried. 
     * @param langRef  The language the datapoint name was given.
     * @param dpIdRef  The DpIdentifier of the datapoint
     * @return NS_RESPONSE_OK if the data are valid. Any other return value means invalid data.
     */
    NameServerResponseStatus getDpIdResponse(CharString &nameRef, LanguageIdType &langRef, DpIdentifier &dpIdRef) const;

    // SYSTEMNAMES_RESPONSE
    /**
     * Returns the result of a SYSTEMNAMES_QUERY.
     *
     * @param [out] sysNames Receives the resulting display names.
     * @return See NameServerResponseStatus
     */
    NameServerResponseStatus getCNSSystemNamesResponse(LangText &sysNames) const;

    /**
     * Defines the result of a SYSTEMNAMES_QUERY.
     *
     * @param sysNames the resulting display names.
     * @return PVSS_TRUE if succeeded, PVSS_FALSE otherwise
     */
    PVSSboolean setCNSSystemNamesResponse(const LangText &sysNames);

    // VIEWS_RESPONSE
    /** Add a view path to the response for a VIEWS_QUERY
     *
     * @param viewPath a view path for the response
     * @return PVSS_TRUE if succeeded, PVSS_FALSE otherwise
     */
    PVSSboolean addCNSViewsResponse(const CharString &viewPath);

    /**
     * Get the first view path returned for a VIEWS_QUERY.
     *
     * @param [out] viewPath a view path from the response
     * @return PVSS_FALSE if the response is empty, otherwise PVSS_TRUE.
     */
    PVSSboolean getFirstFromCNSViewsResponse(CharString &viewPath) const;

    /**
     * Get the next view path for a VIEWS_QUERY.
     *
     * @param [out] viewPath a view path from the response
     * @return PVSS_FALSE if the response is empty, otherwise PVSS_TRUE.
     */
    PVSSboolean getNextFromCNSViewsResponse(CharString &viewPath) const;

    // VIEW_DISPLAYNAMES_RESPONSE
    /**
     * Get the display names returned for a VIEW_DISPLAYNAMES_QUERY.
     *
     * @param [out] displayNames the display names from the response
     * @return See NameServerResponseStatus
     */
    NameServerResponseStatus getCNSViewDisplayNamesResponse(LangText &displayNames) const;

    /**
     * Sets the display names for a VIEW_DISPLAYNAMES_QUERY.
     *
     * @param displayNames the display names for the response
     * @return See NameServerResponseStatus
     */
    PVSSboolean setCNSViewDisplayNamesResponse(const LangText &displayNames);
    
    // VIEW_SEPARATORS_RESPONSE
    /**
     * Get the separators returned for a VIEW_SEPARATORS_QUERY.
     *
     * @param [out] separators the separators from the response
     * @return See NameServerResponseStatus
     */
    NameServerResponseStatus getCNSViewSeparatorsResponse(LangText &separators) const;

    /**
     * Set the separators returned for a VIEW_SEPARATORS_QUERY.
     *
     * @param [out] separators the separators from the response
     * @return See NameServerResponseStatus
     */
    PVSSboolean setCNSViewSeparatorsResponse(const LangText &separators);

    // TREES_RESPONSE
    /** Add a tree path to the response for a TREES_QUERY.
     *
     * @param treePath a path for the response
     * @return PVSS_FALSE if the response is empty, otherwise PVSS_TRUE.
     */
    PVSSboolean addCNSTreesResponse(const CharString &treePath);

    /**
     * Get the first tree path returned for a TREES_QUERY.
     *
     * @param [out] treePath a path from the response
     * @return PVSS_FALSE if the response is empty, otherwise PVSS_TRUE.
     */
    PVSSboolean getFirstFromCNSTreesResponse(CharString &treePath) const;

    /**
     * Get the next tree path for a TREES_QUERY.
     *
     * @param [out] treePath a path from the response
     * @return PVSS_FALSE if the response is empty, otherwise PVSS_TRUE.
     */
    PVSSboolean getNextFromCNSTreesResponse(CharString &treePath) const;

    // CHILDREN_RESPONSE
    /// Add a node path to the response for a CHILDREN_QUERY.
    PVSSboolean addCNSChildrenResponse(const CharString &nodePath);

    /**
     * Get the first node path returned for a CHILDREN_QUERY.
     *
     * @param [out] nodePath a path from the response
     * @return PVSS_FALSE if the response is empty, otherwise PVSS_TRUE.
     */
    PVSSboolean getFirstFromCNSChildrenResponse(CharString &nodePath) const;

    /**
     * Get the next node path for a CHILDREN_QUERY.
     *
     * @param [out] nodePath a path from the response
     * @return PVSS_FALSE if the response is empty, otherwise PVSS_TRUE.
     */
    PVSSboolean getNextFromCNSChildrenResponse(CharString &nodePath) const;

    // DISPLAYNAMES_RESPONSE
    /**
     * Get the display names returned for a DISPLAYNAMES_QUERY.
     *
     * @param [out] displayNames the display names from the response
     * @return See NameServerResponseStatus
     */
    NameServerResponseStatus getCNSDisplayNamesResponse(LangText &displayNames) const;

    /**
     * Set the display names returned for a DISPLAYNAMES_QUERY.
     *
     * @param displayNames the display names for the response
     * @return See NameServerResponseStatus
     */
    PVSSboolean setCNSDisplayNamesResponse(const LangText &displayNames);

    // ID_RESPONSE
    /**
     * Get the CNSDataIdentifier and dp name for a ID_QUERY.
     *
     * @param [out] dpName the datapoint name queried.
     * @param [out] id the CNSDataIdentifier for the datapoint
     * @return See NameServerResponseStatus
     */
    NameServerResponseStatus getCNSIdResponse(CharString &dpName, CNSDataIdentifier &id) const;

    /**
     * Set the CNSDataIdentifier and dp name for a ID_QUERY.
     *
     * @param dpName the datapoint name queried.
     * @param id the CNSDataIdentifier for the datapoint
     * @return See NameServerResponseStatus
     */
    PVSSboolean setCNSIdResponse(const CharString &dpName, const CNSDataIdentifier &id);

    // IDSET_RESPONSE
    /** Add a CNSDataIdentifier to the response for a IDSET_QUERY.
     *
     * @param dpName a datapoint name that matches the query
     * @param id the CNSDataIdentifier for the datapoint
     * @return PVSS_TRUE if succeeded, PVSS_FALSE otherwise
     */
    PVSSboolean addCNSIdSetResponse(const CharString &dpName, const CNSDataIdentifier &id);

    /**
     * Get the first CNSDataIdentifier returned for a IDSET_QUERY.
     *
     * @param [out] dpName a datapoint name that matches the query
     * @param [out] id the CNSDataIdentifier for the datapoint
     * @return PVSS_FALSE if there are no more identifiers, otherwise PVSS_TRUE.
     */
    PVSSboolean getFirstFromCNSIdSetResponse(CharString &dpName, CNSDataIdentifier &id) const;

    /**
     * Get the next CNSDataIdentifier returned for a CHILDREN_QUERY.
     *
     * @param [out] dpName a datapoint name that matches the query
     * @param [out] id the CNSDataIdentifier for the datapoint
     * @return PVSS_FALSE if there are no more identifiers, otherwise PVSS_TRUE.
     */
    PVSSboolean getNextFromCNSIdSetResponse(CharString &dpName, CNSDataIdentifier &id) const;

    // NODESBYNAME_RESPONSE
    /** Add a node path to the response for a NODESBYNAME_QUERY.
     *
     * @param nodePath a node path that matches the query
     * @return PVSS_TRUE if succeeded, PVSS_FALSE otherwise
     */
    PVSSboolean addCNSNodesByNameResponse(const CharString &nodePath);

    /**
     * Get the first node path returned for a NODESBYNAME_QUERY.
     *
     * @param [out] nodePath a node path that matches the query
     * @return PVSS_FALSE if there are no more identifiers, otherwise PVSS_TRUE.
     */
    PVSSboolean getFirstFromCNSNodesByNameResponse(CharString &nodePath) const;

    /**
     * Get the next node path returned for a NODESBYNAME_QUERY.
     *
     * @param [out] nodePath a node path that matches the query
     * @return PVSS_FALSE if there are no more identifiers, otherwise PVSS_TRUE.
     */
    PVSSboolean getNextFromCNSNodesByNameResponse(CharString &nodePath) const;

    // NODESBYDATA_RESPONSE
    /** Add a node path to the response for a NODESBYDATA_QUERY.
     *
     * @param nodePath a node path that has the queried datapoint
     * @return PVSS_TRUE if succeeded, PVSS_FALSE otherwise
     */
    PVSSboolean addCNSNodesByDataResponse(const CharString &nodePath);

    /**
     * Get the first node path returned for a NODESBYDATA_QUERY.
     *
     * @param [out] nodePath a node path that has the queried datapoint
     * @return PVSS_FALSE if there are no more identifiers, otherwise PVSS_TRUE.
     */
    PVSSboolean getFirstFromCNSNodesByDataResponse(CharString &nodePath) const;

    /**
     * Get the next node path returned for a NODESBYDATA_QUERY.
     *
     * @param [out] nodePath a node path that has the queried datapoint
     * @return PVSS_FALSE if there are no more identifiers, otherwise PVSS_TRUE.
     */
    PVSSboolean getNextFromCNSNodesByDataResponse(CharString &nodePath) const;

    // Attribute
  private:
    /**
     * Returns the corresponding response type for a given query type,
     * or 0 if the type is not recognized.
     */
    static PVSSuchar getResponseType(PVSSuchar requestType);

    /**
     * Returns the name of the given response type.
     */
    static const char *getResponseStatusName(NameServerResponseStatus respStatus);

    /**
     * Actual code behind debug() and operator<<(std::ostream&, ...)
     */
    void internalDebug(std::ostream &to, const char *prefix = "", const char *suffix = "") const;

    // Input members:
    // Name + Sprache
    LanguageIdType  lang;
    CharString      query;

    // arguments for cns search
    CharString cnsViewPath;
    PVSSuchar cnsSearchMode;
    CNSDataIdentifierType cnsDataIdType;

    // Output members:
    PtrList  list;

    // Returncode
    NameServerResponseStatus        respStatus;

};

//------------------------------------------------------------------------------
// Inline-Funktionen

inline void NameServerSysMsg::setResponseStatus(NameServerResponseStatus newStatus)
{
  respStatus = newStatus;
}

//------------------------------------------------------------------------------

inline NameServerResponseStatus NameServerSysMsg::getResponseStatus()
{
  return respStatus;
}

//------------------------------------------------------------------------------

inline PVSSboolean NameServerSysMsg::setDpNameQuery(const DpIdentifier & dpIdent)
{
  setSysMsgSubType(NAME_SERVICE_DPNAME_QUERY);

  // format: System:DP.Element:Config.Detail.Attribute (Type)
  query.format("%u:%u.%hi:%hu.%hi.%i (%hi)",
      dpIdent.getSystem().toPVSSulong(),
      dpIdent.getDp(),
      dpIdent.getEl(),
      dpIdent.getConfig(),
      dpIdent.getDetail(),
      dpIdent.getAttr(),
      dpIdent.getDpType());

  return PVSS_TRUE;
}

inline PVSSboolean NameServerSysMsg::getDpNameQuery(DpIdentifier & dpIdent) const
{
  if ( getSysMsgSubType() != NAME_SERVICE_DPNAME_QUERY )
    return PVSS_FALSE;

  PVSSulong         sys;   // System
  DpIdType          dp;    // Datapoint
  DpElementId       el;    // Element
  PVSSushort        config;// Config
  DpDetailNrType    detail;// Detail
  DpAttributeNrType attr;  // Attribute
  DpTypeId          type;  // DP Type

  // format: System:DP.Element:Config.Detail.Attribute (Type)
  if ( 7 != sscanf(query.c_str(), "%u:%u.%hi:%hu.%hi.%i (%hi)", &sys, &dp, &el, &config, &detail, &attr, &type) )
    return PVSS_FALSE;

  dpIdent.setSystem(sys);
  dpIdent.setDp(dp);
  dpIdent.setEl(el);
  dpIdent.setConfig(static_cast<DpConfigNrType>(config));
  dpIdent.setDetail(detail);
  dpIdent.setAttr(attr);
  dpIdent.setDpType(type);

  return PVSS_TRUE;
}

inline PVSSboolean NameServerSysMsg::setDpTypeQuery(const CharString & dptName)
{
  setSysMsgSubType(NAME_SERVICE_DPTYPE_QUERY);

  query = dptName;
  lang = 0;

  return PVSS_TRUE;
}

inline PVSSboolean NameServerSysMsg::getDpTypeQuery(CharString & dptName) const
{
  if ( getSysMsgSubType() != NAME_SERVICE_DPTYPE_QUERY )
    return PVSS_FALSE;

  dptName = query;

  return PVSS_TRUE;
}

inline PVSSboolean NameServerSysMsg::setDpIdQuery(const CharString &newQuery, LanguageIdType newLang)
{
  setSysMsgSubType(NAME_SERVICE_DPID_QUERY);
  query = newQuery;
  lang  = newLang;

  return PVSS_TRUE;
}

//------------------------------------------------------------------------------

inline PVSSboolean NameServerSysMsg::getDpIdQuery(CharString &queryRef, LanguageIdType &langRef) const
{
  if (getSysMsgSubType() != NAME_SERVICE_DPID_QUERY)
    return PVSS_FALSE;

  queryRef = query;
  langRef  = lang;

  return PVSS_TRUE;
}

//------------------------------------------------------------------------------


// Since they all look the same, we'll just generate the query methods to DRY them up
// exclude the macro calls from the documentation, it confuses doxygen
/// @cond DONT_DOCUMENT

#define NAMESERVERSYSMSG_QUERY_METHODS(__method__, __enum__)                           \
  inline PVSSboolean NameServerSysMsg::setCNS ## __method__ ## Query(const CharString &q) \
  {                                                                                    \
    setSysMsgSubType(NAME_SERVICE_CNS_ ## __enum__);                                   \
                                                                                       \
    query = q;                                                                         \
    return PVSS_TRUE;                                                                  \
  }                                                                                    \
                                                                                       \
  inline PVSSboolean NameServerSysMsg::getCNS ## __method__ ## Query(CharString &q) const \
  {                                                                                    \
    if (getSysMsgSubType() != NAME_SERVICE_CNS_ ## __enum__) return false;             \
                                                                                       \
    q = query;                                                                         \
    return PVSS_TRUE;                                                                  \
  }

NAMESERVERSYSMSG_QUERY_METHODS(SystemNames,      SYSTEMNAMES_QUERY)       // getCNSSystemNamesQuery(), setCNSSystemNamesQuery()
NAMESERVERSYSMSG_QUERY_METHODS(Views,            VIEWS_QUERY)             // getCNSViewsQuery(), setCNSViewsQuery()
NAMESERVERSYSMSG_QUERY_METHODS(ViewDisplayNames, VIEW_DISPLAYNAMES_QUERY) // getCNSViewDisplayNamesQuery(), setCNSViewDisplayNamesQuery()
NAMESERVERSYSMSG_QUERY_METHODS(ViewSeparators,   VIEW_SEPARATORS_QUERY)   // getCNSViewSeparatorsQuery(), setCNSViewSeparatorsQuery()
NAMESERVERSYSMSG_QUERY_METHODS(Trees,            TREES_QUERY)             // getCNSTreesQuery(), setCNSTreesQuery()
NAMESERVERSYSMSG_QUERY_METHODS(Children,         CHILDREN_QUERY)          // getCNSChildrenQuery(), setCNSChildrenQuery()
NAMESERVERSYSMSG_QUERY_METHODS(DisplayNames,     DISPLAYNAMES_QUERY)      // getCNSDisplayNamesQuery(), setCNSDisplayNamesQuery()
NAMESERVERSYSMSG_QUERY_METHODS(Id,               ID_QUERY)                // getCNSIdQuery(), setCNSIdQuery()

#undef NAMESERVERSYSMSG_QUERY_METHODS

/// @endcond

//------------------------------------------------------------------------------

inline PVSSboolean NameServerSysMsg::setCNSIdSetQuery(const CharString &pattern,
                                                   const CharString &viewPath,
                                                   int searchMode,
                                                   LanguageIdType langIdx,
                                                   CNSDataIdentifierType type)
{
  setSysMsgSubType(NAME_SERVICE_CNS_IDSET_QUERY);
  query = pattern;
  cnsViewPath = viewPath;
  cnsSearchMode = searchMode;
  lang = langIdx;
  cnsDataIdType = type;

  return PVSS_TRUE;
}

//------------------------------------------------------------------------------

inline PVSSboolean NameServerSysMsg::getCNSIdSetQuery(CharString &pattern,
                                                   CharString &viewPath,
                                                   int &searchMode,
                                                   LanguageIdType &langIdx,
                                                   CNSDataIdentifierType &type) const
{
  if (getSysMsgSubType() != NAME_SERVICE_CNS_IDSET_QUERY) return false;

  pattern = query;
  viewPath = cnsViewPath;
  searchMode = cnsSearchMode;
  langIdx = lang;
  type = cnsDataIdType;

  return PVSS_TRUE;
}

//------------------------------------------------------------------------------

inline PVSSboolean NameServerSysMsg::setCNSNodesByNameQuery(const CharString &pattern,
                                                         const CharString &viewPath,
                                                         int searchMode,
                                                         LanguageIdType langIdx,
                                                         CNSDataIdentifierType type)
{
  setSysMsgSubType(NAME_SERVICE_CNS_NODESBYNAME_QUERY);
  query = pattern;
  cnsViewPath = viewPath;
  cnsSearchMode = searchMode;
  lang = langIdx;
  cnsDataIdType = type;

  return PVSS_TRUE;
}

//------------------------------------------------------------------------------

inline PVSSboolean NameServerSysMsg::getCNSNodesByNameQuery(CharString &pattern,
                                                         CharString &viewPath,
                                                         int &searchMode,
                                                         LanguageIdType &langIdx,
                                                         CNSDataIdentifierType &type) const
{
  if (getSysMsgSubType() != NAME_SERVICE_CNS_NODESBYNAME_QUERY) return false;

  pattern = query;
  viewPath = cnsViewPath;
  searchMode = cnsSearchMode;
  langIdx = lang;
  type = cnsDataIdType;

  return PVSS_TRUE;
}

//------------------------------------------------------------------------------

inline PVSSboolean NameServerSysMsg::setCNSNodesByDataQuery(const CharString &dpName,
                                                         const CharString &viewPath,
                                                         CNSDataIdentifierType type)
{
  setSysMsgSubType(NAME_SERVICE_CNS_NODESBYDATA_QUERY);
  query = dpName;
  cnsViewPath = viewPath;
  cnsDataIdType = type;

  return PVSS_TRUE;
}

//------------------------------------------------------------------------------

inline PVSSboolean NameServerSysMsg::getCNSNodesByDataQuery(CharString &dpName,
                                                         CharString &viewPath,
                                                         CNSDataIdentifierType &type) const
{
  if (getSysMsgSubType() != NAME_SERVICE_CNS_NODESBYDATA_QUERY) return false;

  dpName = query;
  viewPath = cnsViewPath;
  type = cnsDataIdType;

  return PVSS_TRUE;
}

//------------------------------------------------------------------------------

inline PVSSboolean NameServerSysMsg::setDpNameResponse(const DpIdentifier & dpIdent, const CharString & dpName)
{
  setSysMsgSubType(NAME_SERVICE_DPNAME_RESPONSE);

  list.clear();
  list.append(new DpIdentifierItem(dpIdent, dpName));

  return PVSS_TRUE;
}

inline NameServerResponseStatus NameServerSysMsg::getDpNameResponse(DpIdentifier & dpIdent, CharString & dpName) const
{
  if (getSysMsgSubType() != NAME_SERVICE_DPNAME_RESPONSE)
    return NS_RESPONSE_ERROR;

  if (list.getNumberOfItems() == 0)
    return NS_RESPONSE_NONEXISTENT;

  dpIdent = ((DpIdentifierItem *) list.getFirst())->getDpId();
  dpName  = ((DpIdentifierItem *) list.getFirst())->getName().getText();

  return respStatus;
}

//------------------------------------------------------------------------------

inline PVSSboolean NameServerSysMsg::setDpTypeResponse(const CharString & dptName, const DpTypeId & dpType)
{
  setSysMsgSubType(NAME_SERVICE_DPTYPE_RESPONSE);

  DpIdentifier typeIdent;
  typeIdent.setDpType(dpType);

  list.clear();
  list.append(new DpIdentifierItem(typeIdent, dptName));

  return PVSS_TRUE;
}

inline NameServerResponseStatus NameServerSysMsg::getDpTypeResponse(CharString & dptName, DpTypeId & dpType) const
{
  if (getSysMsgSubType() != NAME_SERVICE_DPTYPE_RESPONSE)
    return NS_RESPONSE_ERROR;

  if (list.getNumberOfItems() == 0)
    return NS_RESPONSE_NONEXISTENT;

  DpIdentifier typeIdent = ((DpIdentifierItem *) list.getFirst())->getDpId();

  dptName = ((DpIdentifierItem *) list.getFirst())->getName().getText();
  dpType = typeIdent.getDpType();

  return respStatus;
}

//------------------------------------------------------------------------------

inline PVSSboolean NameServerSysMsg::setDpIdResponse(PVSSlong newAnswerId, const CharString &newName, 
    LanguageIdType newLang, const DpIdentifier &newDpId)
{
  setSysMsgSubType(NAME_SERVICE_DPID_RESPONSE);

  list.clear();
  list.append(new DpIdentifierItem(newDpId, newName));

  lang = newLang;
  answerId = newAnswerId;

  return PVSS_TRUE;
}

//------------------------------------------------------------------------------

inline PVSSboolean NameServerSysMsg::addDpIdResponse(const CharString &newName, const DpIdentifier &newDpId)
{
  setSysMsgSubType(NAME_SERVICE_DPID_RESPONSE);

  list.append(new DpIdentifierItem(newDpId, newName));

  return PVSS_TRUE;
}

//------------------------------------------------------------------------------

inline NameServerResponseStatus NameServerSysMsg::getDpIdResponse(CharString &nameRef, LanguageIdType &langRef, 
    DpIdentifier &dpIdRef) const
{
  if (getSysMsgSubType() != NAME_SERVICE_DPID_RESPONSE)
    return NS_RESPONSE_ERROR;

  if (list.getNumberOfItems() == 0)
    return NS_RESPONSE_NONEXISTENT;

  langRef = lang;

  nameRef = ((DpIdentifierItem *) list.getFirst())->getName().getText();
  dpIdRef = ((DpIdentifierItem *) list.getFirst())->getDpId();

  return respStatus;
}

//------------------------------------------------------------------------------

inline NameServerResponseStatus NameServerSysMsg::getCNSSystemNamesResponse(LangText &sysNames) const
{
  if (getSysMsgSubType() != NAME_SERVICE_CNS_SYSTEMNAMES_RESPONSE)
    return NS_RESPONSE_ERROR;

  if (list.getNumberOfItems() == 0)
    return NS_RESPONSE_NONEXISTENT;

  sysNames = ((DpIdentifierItem *) list.getFirst())->getName();

  return respStatus;
}

//------------------------------------------------------------------------------

inline PVSSboolean NameServerSysMsg::setCNSSystemNamesResponse(const LangText &sysNames)
{
  setSysMsgSubType(NAME_SERVICE_CNS_SYSTEMNAMES_RESPONSE);

  list.clear();
  list.append(new DpIdentifierItem(sysNames));

  return PVSS_TRUE;
}

//------------------------------------------------------------------------------

inline PVSSboolean NameServerSysMsg::addCNSViewsResponse(const CharString &viewPath)
{
  setSysMsgSubType(NAME_SERVICE_CNS_VIEWS_RESPONSE);

  list.append(new DpIdentifierItem(DpIdentifier(), viewPath));
  return PVSS_TRUE;
}

//------------------------------------------------------------------------------

inline PVSSboolean NameServerSysMsg::getFirstFromCNSViewsResponse(CharString &viewPath) const
{
  if (getSysMsgSubType() != NAME_SERVICE_CNS_VIEWS_RESPONSE)
    return PVSS_FALSE;

  const DpIdentifierItem *item = static_cast<const DpIdentifierItem *>(list.getFirst());

  if (item)
  {
    viewPath = item->getName().getText();
    return PVSS_TRUE;
  }

  return PVSS_FALSE;
}

//------------------------------------------------------------------------------

inline PVSSboolean NameServerSysMsg::getNextFromCNSViewsResponse(CharString &viewPath) const
{
  if (getSysMsgSubType() != NAME_SERVICE_CNS_VIEWS_RESPONSE)
    return PVSS_FALSE;

  const DpIdentifierItem *item = static_cast<const DpIdentifierItem *>(list.getNext());

  if (item)
  {
    viewPath = item->getName().getText();
    return PVSS_TRUE;
  }

  return PVSS_FALSE;
}

//------------------------------------------------------------------------------

inline NameServerResponseStatus NameServerSysMsg::getCNSViewDisplayNamesResponse(LangText &displayNames) const
{
  if (getSysMsgSubType() != NAME_SERVICE_CNS_VIEW_DISPLAYNAMES_RESPONSE)
    return NS_RESPONSE_ERROR;

  if (list.getNumberOfItems() == 0)
    return NS_RESPONSE_NONEXISTENT;

  displayNames = static_cast<const DpIdentifierItem *>(list.getFirst())->getName();

  return respStatus;
}

//------------------------------------------------------------------------------

inline PVSSboolean NameServerSysMsg::setCNSViewDisplayNamesResponse(const LangText &displayNames)
{
  setSysMsgSubType(NAME_SERVICE_CNS_VIEW_DISPLAYNAMES_RESPONSE);

  list.clear();
  list.append(new DpIdentifierItem(displayNames));

  return PVSS_TRUE;
}

//------------------------------------------------------------------------------

inline NameServerResponseStatus NameServerSysMsg::getCNSViewSeparatorsResponse(LangText &separators) const
{
  if (getSysMsgSubType() != NAME_SERVICE_CNS_VIEW_SEPARATORS_RESPONSE)
    return NS_RESPONSE_ERROR;

  if (list.getNumberOfItems() == 0)
    return NS_RESPONSE_NONEXISTENT;

  separators = static_cast<const DpIdentifierItem *>(list.getFirst())->getName();

  return respStatus;
}

//------------------------------------------------------------------------------

inline PVSSboolean NameServerSysMsg::setCNSViewSeparatorsResponse(const LangText &separators)
{
  setSysMsgSubType(NAME_SERVICE_CNS_VIEW_SEPARATORS_RESPONSE);

  list.clear();
  list.append(new DpIdentifierItem(separators));

  return PVSS_TRUE;
}

//------------------------------------------------------------------------------

inline PVSSboolean NameServerSysMsg::addCNSTreesResponse(const CharString &treePath)
{
  setSysMsgSubType(NAME_SERVICE_CNS_TREES_RESPONSE);

  list.append(new DpIdentifierItem(DpIdentifier(), treePath));
  return PVSS_TRUE;
}

//------------------------------------------------------------------------------

inline PVSSboolean NameServerSysMsg::getFirstFromCNSTreesResponse(CharString &treePath) const
{
  if (getSysMsgSubType() != NAME_SERVICE_CNS_TREES_RESPONSE)
    return PVSS_FALSE;

  const DpIdentifierItem *item = static_cast<const DpIdentifierItem *>(list.getFirst());

  if (item)
  {
    treePath = item->getName().getText();
    return PVSS_TRUE;
  }

  return PVSS_FALSE;
}

//------------------------------------------------------------------------------

inline PVSSboolean NameServerSysMsg::getNextFromCNSTreesResponse(CharString &treePath) const
{
  if (getSysMsgSubType() != NAME_SERVICE_CNS_TREES_RESPONSE)
    return PVSS_FALSE;

  const DpIdentifierItem *item = static_cast<const DpIdentifierItem *>(list.getNext());

  if (item)
  {
    treePath = item->getName().getText();
    return PVSS_TRUE;
  }

  return PVSS_FALSE;
}

//------------------------------------------------------------------------------

inline PVSSboolean NameServerSysMsg::addCNSChildrenResponse(const CharString &nodePath)
{
  setSysMsgSubType(NAME_SERVICE_CNS_CHILDREN_RESPONSE);

  list.append(new DpIdentifierItem(DpIdentifier(), nodePath));
  return PVSS_TRUE;
}

//------------------------------------------------------------------------------

inline PVSSboolean NameServerSysMsg::getFirstFromCNSChildrenResponse(CharString &nodePath) const
{
  if (getSysMsgSubType() != NAME_SERVICE_CNS_CHILDREN_RESPONSE)
    return PVSS_FALSE;

  const DpIdentifierItem *item = static_cast<const DpIdentifierItem *>(list.getFirst());

  if (item)
  {
    nodePath = item->getName().getText();
    return PVSS_TRUE;
  }

  return PVSS_FALSE;
}

//------------------------------------------------------------------------------

inline PVSSboolean NameServerSysMsg::getNextFromCNSChildrenResponse(CharString &nodePath) const
{
  if (getSysMsgSubType() != NAME_SERVICE_CNS_CHILDREN_RESPONSE)
    return PVSS_FALSE;

  const DpIdentifierItem *item = static_cast<const DpIdentifierItem *>(list.getNext());

  if (item)
  {
    nodePath = item->getName().getText();
    return PVSS_TRUE;
  }

  return PVSS_FALSE;
}

//------------------------------------------------------------------------------

inline NameServerResponseStatus NameServerSysMsg::getCNSDisplayNamesResponse(LangText &displayNames) const
{
  if (getSysMsgSubType() != NAME_SERVICE_CNS_DISPLAYNAMES_RESPONSE)
    return NS_RESPONSE_ERROR;

  if (list.getNumberOfItems() == 0)
    return NS_RESPONSE_NONEXISTENT;

  displayNames = ((DpIdentifierItem *) list.getFirst())->getName();

  return respStatus;
}

//------------------------------------------------------------------------------

inline PVSSboolean NameServerSysMsg::setCNSDisplayNamesResponse(const LangText &displayNames)
{
  setSysMsgSubType(NAME_SERVICE_CNS_DISPLAYNAMES_RESPONSE);

  list.clear();
  list.append(new DpIdentifierItem(displayNames));

  return PVSS_TRUE;
}

//------------------------------------------------------------------------------

inline NameServerResponseStatus NameServerSysMsg::getCNSIdResponse(CharString &dpName, CNSDataIdentifier &id) const
{
  if (getSysMsgSubType() != NAME_SERVICE_CNS_ID_RESPONSE)
    return NS_RESPONSE_ERROR;

  if (list.getNumberOfItems() == 0)
    return NS_RESPONSE_NONEXISTENT;

  const DpIdentifierItem *item = static_cast<const DpIdentifierItem *>(list.getFirst());
  
  dpName = item->getName().getText();
  id = item->getCNSDataIdentifier();

  return respStatus;
}

//------------------------------------------------------------------------------

inline PVSSboolean NameServerSysMsg::setCNSIdResponse(const CharString &dpName, const CNSDataIdentifier &id)
{
  setSysMsgSubType(NAME_SERVICE_CNS_ID_RESPONSE);

  list.clear();
  list.append(new DpIdentifierItem(id, dpName));

  return PVSS_TRUE;
}

//------------------------------------------------------------------------------

inline PVSSboolean NameServerSysMsg::addCNSIdSetResponse(const CharString &dpName, const CNSDataIdentifier &id)
{
  setSysMsgSubType(NAME_SERVICE_CNS_IDSET_RESPONSE);

  list.append(new DpIdentifierItem(id, dpName));

  return PVSS_TRUE;
}

//------------------------------------------------------------------------------

inline PVSSboolean NameServerSysMsg::getFirstFromCNSIdSetResponse(CharString &dpName, CNSDataIdentifier &id) const
{
  if (getSysMsgSubType() != NAME_SERVICE_CNS_IDSET_RESPONSE)
    return PVSS_FALSE;

  const DpIdentifierItem *item = static_cast<const DpIdentifierItem *>(list.getFirst());

  if (item)
  {
    dpName = item->getName().getText();
    id = item->getCNSDataIdentifier();
    return PVSS_TRUE;
  }

  return PVSS_FALSE;
}

//------------------------------------------------------------------------------

inline PVSSboolean NameServerSysMsg::getNextFromCNSIdSetResponse(CharString &dpName, CNSDataIdentifier &id) const
{
  if (getSysMsgSubType() != NAME_SERVICE_CNS_IDSET_RESPONSE)
    return PVSS_FALSE;

  const DpIdentifierItem *item = static_cast<const DpIdentifierItem *>(list.getNext());

  if (item)
  {
    dpName = item->getName().getText();
    id = item->getCNSDataIdentifier();
    return PVSS_TRUE;
  }

  return PVSS_FALSE;
}

//------------------------------------------------------------------------------

inline PVSSboolean NameServerSysMsg::addCNSNodesByNameResponse(const CharString &nodePath)
{
  setSysMsgSubType(NAME_SERVICE_CNS_NODESBYNAME_RESPONSE);

  list.append(new DpIdentifierItem(DpIdentifier(), nodePath));

  return PVSS_TRUE;
}

//------------------------------------------------------------------------------

inline PVSSboolean NameServerSysMsg::getFirstFromCNSNodesByNameResponse(CharString &nodePath) const
{
  if (getSysMsgSubType() != NAME_SERVICE_CNS_NODESBYNAME_RESPONSE)
    return PVSS_FALSE;

  const DpIdentifierItem *item = static_cast<const DpIdentifierItem *>(list.getFirst());

  if (item)
  {
    nodePath = item->getName().getText();
    return PVSS_TRUE;
  }

  return PVSS_FALSE;
}

//------------------------------------------------------------------------------

inline PVSSboolean NameServerSysMsg::getNextFromCNSNodesByNameResponse(CharString &nodePath) const
{
  if (getSysMsgSubType() != NAME_SERVICE_CNS_NODESBYNAME_RESPONSE)
    return PVSS_FALSE;

  const DpIdentifierItem *item = static_cast<const DpIdentifierItem *>(list.getNext());

  if (item)
  {
    nodePath = item->getName().getText();
    return PVSS_TRUE;
  }

  return PVSS_FALSE;
}

//------------------------------------------------------------------------------

inline PVSSboolean NameServerSysMsg::addCNSNodesByDataResponse(const CharString &nodePath)
{
  setSysMsgSubType(NAME_SERVICE_CNS_NODESBYDATA_RESPONSE);

  list.append(new DpIdentifierItem(DpIdentifier(), nodePath));

  return PVSS_TRUE;
}

//------------------------------------------------------------------------------

inline PVSSboolean NameServerSysMsg::getFirstFromCNSNodesByDataResponse(CharString &nodePath) const
{
  if (getSysMsgSubType() != NAME_SERVICE_CNS_NODESBYDATA_RESPONSE)
    return PVSS_FALSE;

  const DpIdentifierItem *item = static_cast<const DpIdentifierItem *>(list.getFirst());

  if (item)
  {
    nodePath = item->getName().getText();
    return PVSS_TRUE;
  }

  return PVSS_FALSE;
}

//------------------------------------------------------------------------------

inline PVSSboolean NameServerSysMsg::getNextFromCNSNodesByDataResponse(CharString &nodePath) const
{
  if (getSysMsgSubType() != NAME_SERVICE_CNS_NODESBYDATA_RESPONSE)
    return PVSS_FALSE;

  const DpIdentifierItem *item = static_cast<const DpIdentifierItem *>(list.getNext());

  if (item)
  {
    nodePath = item->getName().getText();
    return PVSS_TRUE;
  }

  return PVSS_FALSE;
}

//------------------------------------------------------------------------------

inline MsgType NameServerSysMsg::isA(MsgType msgType) const
{
  if(msgType == isA())
    return SYS_MSG_NAMESERVER;
  return SysMsg::isA(msgType);
}

//------------------------------------------------------------------------------

inline MsgType NameServerSysMsg::isA() const
{
  return SYS_MSG_NAMESERVER;
}

//------------------------------------------------------------------------------

inline const PVSSulong *NameServerSysMsg::isAnswer() const
{
  return (getResponseType(getSysMsgSubType()) == 0) ? &answerId : 0;
}

//------------------------------------------------------------------------------

inline PVSSboolean NameServerSysMsg::needsAnswer() const
{
  return isAnswer() ? PVSS_FALSE : PVSS_TRUE;
}

//------------------------------------------------------------------------------

inline int NameServerSysMsg::operator==(const Msg &rVal) const
{
  return operator==((const NameServerSysMsg &)rVal);
}

//------------------------------------------------------------------------------

inline Msg &NameServerSysMsg::operator=(const Msg &rVal)
{
  return operator=((const NameServerSysMsg &)rVal);
}

//------------------------------------------------------------------------------

inline Msg *NameServerSysMsg::allocate() const
{
  return new NameServerSysMsg;
}

#endif /* _NAMESERVERSYSMSG_H_ */
