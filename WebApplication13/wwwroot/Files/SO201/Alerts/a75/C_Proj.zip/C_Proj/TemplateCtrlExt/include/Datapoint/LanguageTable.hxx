// -----------------------------------------------------------------
// LanguageTable.hxx
// creator: Andreas Pfluegl at 06.03.06
// purpose: for Compartible Messages starting with PVSS II 3.1,
//          skip the LanguageTable of the DpIdentification of a 3.1 System 
// -----------------------------------------------------------------
// history:
// 20yy-mm-dd:  <Name> N            ( B O C X )
// -----------------------------------------------------------------
#ifndef _LANGUAGETABLE_H_
#define _LANGUAGETABLE_H_

#include <Types.hxx>

class itcNdrUbReceive;
typedef  PVSSulong  LanguageTableItemId;

// ========== LanguageTable ============================================================

/// The language table, used for message compatibility with PVSS II versions prior to 3.1.
/// Since PVSS II 3.1, there is no longer a language table in the message.
class DLLEXP_DATAPOINT LanguageTable 
{
friend class UNIT_TEST_FRIEND_CLASS;    // ein Unit-Test braucht erweiterten zugriff auf diese Klasse

public:
  /// constructor, initialisation with zero values
  LanguageTable(): itemLen(0), dummy(0) {}

  /// destructor
  virtual ~LanguageTable();

  /// operator >> for itcNdrUbReceive stream
  /// @param ndrStream the stream, which to receive from
  /// @param table the language table
  friend DLLEXP_DATAPOINT itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream, LanguageTable &table);

  /// skip language table item
  /// @param ndrStream the stream, which to receive from
  void skipLanguageTableItem(itcNdrUbReceive &ndrStream);

private:
  unsigned itemLen;
  char *dummy;
};



#endif /* _LANGUAGETABLE_H_ */
