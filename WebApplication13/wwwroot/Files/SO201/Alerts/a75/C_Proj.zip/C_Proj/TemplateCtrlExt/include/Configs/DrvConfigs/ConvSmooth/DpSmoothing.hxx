// DATEIBESCHREIBUNG ==============================================================
// DATEINAME:     DpSmoothing.hxx
//
//
// AENDERUNGS-HISTORIE
// Ver.  | Datum      | Aenderungen                            | ModNr.| Autor
// ------+------------+-----------------Anfang-----------------+-------+-----------
//   1.0 |            | 1.Erstellung mit Westmount-OMT         |     0 |
//   1.1 |            | 1.API comments added                   |     0 | mrajnoha
// ======================================Ende======================================
#ifndef _DPSMOOTHING_H_
#define _DPSMOOTHING_H_

// Vorwaerts-Deklaration der Eigenen Klasse
class DpSmoothing;

// System-Include-Files
#include <DpConvSmooth.hxx>

// Vorwaerts-Deklarationen :

// ========== DpSmoothing ============================================================
/** This is a base abstract class for all smoothing classes.
    @classification public use, overload
*/
class DLLEXP_CONFIGS DpSmoothing : public DpConvSmooth 
{
public:
  /** Default constructor.
   */
  DpSmoothing();
  /** Overridden destructor.
   */
  virtual ~DpSmoothing();

  /** Indicates if the conversion is active.
      @return PVSS_TRUE if yes , PVSS_FALSE otherwise
   */
  virtual PVSSboolean isConversion() const;

  /** Indicates if the smoothing is active.
      @return PVSS_TRUE if yes , PVSS_FALSE otherwise
   */
  virtual PVSSboolean isSmoothing() const;

  // Generierte Methoden :
protected:
private:
};

// ================================================================================
// Inline-Funktionen :

// ............................Anfang User-Inlines.................................
// .............................Ende User-Inlines..................................

#endif /* _DPSMOOTHING_H_ */
