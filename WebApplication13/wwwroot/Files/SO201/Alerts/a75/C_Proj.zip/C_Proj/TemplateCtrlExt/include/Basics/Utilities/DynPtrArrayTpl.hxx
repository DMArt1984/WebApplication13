// declare basic instances of template classes
// to prevent link errors
#if !defined(_DYNPTRARRAYTPL_H_)
#define _DYNPTRARRAYTPL_H_

#if defined(LIBS_AS_DLL)
// void * DynPtrArray<Item>::staticUserDataPtr = 0;

inline DynPtrArrayIndex DynPtrArray<Variable>::deepCopy(const DynPtrArray<Variable> &src) 
{
  DynPtrArrayIndex i, count = src.nofItems();
  Variable *newItem, *srcItem;
  
  for (i=0; i<count; i++)
    {
    if ((srcItem = src.getAt(i)) != 0)
      {
      newItem = srcItem->clone();
      if (!newItem) {clear(); i = 0; break;}    //nothing has been copied - no memory 
      }
    else newItem = 0;
    setPtr(i, newItem);
    }
    
  return i;
}
#endif
#endif
