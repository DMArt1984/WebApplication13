#ifndef _MUTEX_H_
#define _MUTEX_H_

// Author: Martin Koller
/** A platform neutral Recursive Mutex implementation
*/

#ifndef _WIN32
#include <pthread.h>
#else
#include <windows.h>
#endif

class DLLEXP_OABASICS Mutex
{
  public:
    /** constructor
    */
    Mutex();

    /** destructor
        The mutex must be unlocked before being destroyed
    */
    ~Mutex();

    /** lock the mutex and return immediately or block the thread if the mutex
        is already locked by another thread.
        As this is a recursive mutex, an already locked mutex can be locked again,
        but make sure to unlock it the same number of times as you locked it
        @return returns 0 on success, -1 on error
    */
    int lock();

    /** try to lock the mutex. If it's already locked, return immediately with an error
        @return returns 0 on success, -1 on error
    */
    int tryLock();

    /** unlock the mutex
        @return returns 0 on success, -1 on error
    */
    int unlock();

  private:
#ifndef _WIN32
    pthread_mutex_t mutex_;
#else
    HANDLE mutex_;
#endif
};

#endif
