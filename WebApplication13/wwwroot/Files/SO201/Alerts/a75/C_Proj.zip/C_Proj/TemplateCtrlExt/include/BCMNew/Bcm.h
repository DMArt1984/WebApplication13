//
//  $RCSfile$
//  $Source$
//
// %Z%JESSI-COMMON-FRAMEWORK 2.0
// %Z%Copyright (C) by Siemens Nixdorf Informationssysteme AG 1992
// %Z%Copyright (C) by Universitaet GH Paderborn 1992
// %Z%Development of this software was partially funded by ESPRIT project 7364.
// %Z%BCM %M% %I% %E%


/*
 * application include files
 *
 */

#ifndef _BCM_H_
#define _BCM_H_

#define USES_timestuff
#define USES_sockets

#include "ItcPrelude.h"

#include "ItcStatus.h"

#include "ItcAddress.h"
#include "ItcTransport.h"

#include "ItcNDR.h"

#include "ItcNdrUnBlock.h"

#include "ItcIOCallback.h"
#include "ItcIOHandler.h"

#include "ItcMsgHdr.h"

#endif // ! _BCM_H_
