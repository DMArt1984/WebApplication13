//----------------------------------------------------------------------------
//  Copyright (C) Siemens AG 2018. All Rights Reserved.
//----------------------------------------------------------------------------
#pragma once

#include <Types.hxx>
#include <CharString.hxx>

#include <ItcAddress.h>

// forward decl
struct addrinfo;
struct hostent;
struct timeval;
#ifdef _WIN32
  struct fd_set;
#endif


/// Abstractions for OS-dependent networking functions
namespace NetUtil
{
  // helper class storing an IPv4 or IPv6 address in text and sockaddr format
  class DLLEXP_BASICS SockAddr
  {
  public:
    SockAddr();

    SockAddr(const CharString &textIP, const void *byteIP, short ipFamily);

  public:
    const char* c_str();
    short getFamily() const;
    const unsigned char *getAddress() const;
    struct sockaddr_storage getSockaddr() const;

  public:
    enum
    {
      IPV6ADDRESSLENGTH = 16,
      IPV4ADDRESSLENGTH = 4
    };

  public:
    CharString text;
    short family;
    unsigned char bytes[IPV6ADDRESSLENGTH];
  };

  /// get the internet hostname of your computer
  DLLEXP_BASICS CharString gethostname();

  /// get the host-entry struct for the given hostname
  DLLEXP_BASICS struct hostent* gethostbyname(const char* hostName);

  /// get the host-entry struct for the given network address
  DLLEXP_BASICS struct hostent* gethostbyaddr(const char* address);

  /// Returns the address family of an address or hostname.
  DLLEXP_BASICS int getAddrFamily(const char *addr);

  /** converts an (Ipv4) Internet network address into a string in Internet standard dotted format.
      Problem here is, that char* is given parameter, but requires struct in_addr, so reinterpret_cast<char*> must be performed
      @param address internet network address
      @return char* address in internet standard dotted format
  */
  DLLEXP_BASICS char* inet_ntoa(const char* address);

  // noposix select interface due to HPUX 9.05 incompatibility
  /// the select call for the socket interface
  // select call is OS_select, depending on operating system
  DLLEXP_BASICS int select(int nfds,
    fd_set *readfds, fd_set *writefds, fd_set *errorfds,
    struct timeval *timeout);

  /// check if this is a valid hostname
  DLLEXP_BASICS bool isValidHostname(const char *hn);

  /** Check if two hosts names are equal (Unix case sensitive compare / WIN case insenitive compare).
      @param host1 First hostname or IP-Address
      @param host2 Second hostname or IP-Address
      @return true if both hosts are the same, else false
  */
  DLLEXP_BASICS bool hostNameEq(const CharString &host1, const CharString &host2);

  /** Check if two hosts are the same by checking their IP addresses.
      @param host1 First hostname or IP-Address
      @param host2 Second hostname or IP-Address
      @return true if both hosts are the same, else false
  */
  DLLEXP_BASICS bool isSameHost(const char *host1, const char *host2);

  /** returns true the given string is a valid IP address and get the address family (IPv4 / IPv6).
      @param IP-Address
      @param out: addrress family (the given string is a valid IP address)
      @return true if the given string is a valid IP address
  */
  DLLEXP_BASICS bool isIPAddress(const char *addrerss, unsigned short* addressfamily);

  /** get all ip addresses from the local machine.
      @param p_IPs the list of addresses
      @return PVSS_FALSE if error occured, else PVSS_TRUE
  */
  DLLEXP_BASICS PVSSboolean getAllLocalIPs(std::vector<SockAddr>& result);

  /** get hostnames from the IP addresses.
      @param source IP addresses
      @param dest output: the hostnames
      @return PVSS_FALSE if error occure, else PVSS_TRUE
  */
  DLLEXP_BASICS PVSSboolean getHostnamesFromIPs(std::vector<SockAddr>& source, std::vector<CharString>& dest);

  /** check function.
      checks, if this host is the same host as in argument,
      i.e. if there is at least one matching address.
      Problem here is, that parameter is const char *, but must be char [],
      since const will be dropped in this function.
      @param hn the hostname to compare with
      @return PVSS_TRUE if yes, else PVSS_FALSE
  */
  DLLEXP_BASICS PVSSboolean amIThisHost(const char *hn);

  /** Parse host string
      @param host name of the host as string
      @param port number of port
      @return PVSS_TRUE parsing string done, else PVSS_FALSE; port number is written in port parameter
  */
  DLLEXP_BASICS PVSSboolean parseHostString(char *host, unsigned short &port);
} // namespace NetUtil

