// DATEIBESCHREIBUNG ==============================================================
// DATEINAME:		RequestItem.hxx
// VERANTWORTUNG:	Thomas Exner
// 
// BESCHREIBUNG:	Definiert das abzufragende DP-Attribut (member: id).
//			Fuer den PERIOD_REQUEST sind ausserdem eine FloatVar tolerance
//			(default = 0.0) und eine TimeVar smoothTime (default (0, 0))
//			enthalten. Liefert die Methode smoothAnswer() true, so ist der
//			Datenstrom fuer die Antwort mit einer kombinierten Glaettung
//			Typ: UND (also DpSimpleSmoothType ist gleich DpTimeAndValSmooth)
//			zu glaetten. Dies dient der Datenreduzierung z.B. bei der
//			Anforderung fuer einen Trend. Die Glaettungsparameter werden
//			dabei durch die Aufloesung des Trends bestimmt.

#ifndef _REQUESTITEM_H_
#define _REQUESTITEM_H_

// Vorwaerts-Deklaration der Eigenen Klasse
class RequestItem;

// ========== RequestItemPtr ============================================================
typedef RequestItem* RequestItemPtr;

// System-Include-Files
#include <DpIdentifier.hxx>
#include <FloatVar.hxx>
#include <PtrListItem.hxx>
#include <TimeVar.hxx>
#include <ostream>

// ========== RequestItem ============================================================
/** Represents the requested datapoint attribute. If the containing RequestGroup is a
 *  DP_MSG_PERIOD_REQUEST, the item also stores a smooting time and a smoothing
 *  tolerance value. The answer to the item is then a smoothed value calculated with
 *  those parameters. The smoothing used is DpTimeAndValSmooth.
 */
class DLLEXP_MESSAGES RequestItem : public PtrListItem
{
  public:

    /** default value for the constructor's newNumber parameter
     * @remark If this is are changed, correct the method getNumberForSmoothing() as well
     */
    static const PVSSushort onlyEvents;
    //  static const PVSSushort plus1And1;
    //  static const PVSSushort plus2And2;
    //  static const PVSSushort plus3And3;
    //  static const PVSSushort plus4And4;
    //  static const PVSSushort plus5And5;
    /** Value for plus start
     * @remark If this is are changed, correct the method getNumberForSmoothing() as well
     */
    static const PVSSushort plusStart;

    // Konstruktoren
    // wenn newNumber ungueltiger Wert ist, dann number = onlyEvents
    /** Constructor
     * @param newId id of the request
     * @param newNumber the number used for smoothing
     * @param newTolerance tolerance value
     * @param newSmoothTime smoothing time
     */
    RequestItem(const DpIdentifier &newId, PVSSushort newNumber = onlyEvents, const FloatVar &newTolerance = FloatVar(0.0), const TimeVar &newSmoothTime = TimeVar(0, 0));

    ///copy constructor
    RequestItem(const RequestItem &item);

    /// Destructor
    ~RequestItem();


    // Operatoren :
    /** BCM output streaming operator
     * @param[in,out] ndrStream the BCM stream to write to
     * @param item the RequestItem instance to be written
     */
    friend DLLEXP_MESSAGES itcNdrUbSend &operator<<(itcNdrUbSend &ndrStream, const RequestItem &item);

    /** BCM input streaming operator
     * @param[in,out] ndrStream the BCM stream to read from
     * @param[out] itemPtr the RequestItem instance to be read, this method allocated
     *                     a new RequestItem, the caller takes responsibility
     */
    friend DLLEXP_MESSAGES itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream, RequestItemPtr &itemPtr);

    ///comparison operator
    int operator==(const RequestItem &rVal) const
    {return (id == rVal.id && tolerance == rVal.tolerance && smoothTime == rVal.smoothTime);};

    ///assignment operator
    RequestItem &operator=(const RequestItem &rVal);

    // Spezielle Methoden :
    /// Returns whether the smoothing time is initialized
    PVSSboolean smoothAnswerTime() const
    {return smoothTime != TimeVar(0, 0);};

    /// Returns whether the smoothing value is initialized
    PVSSboolean smoothAnswerValue() const
    {return tolerance != FloatVar(0.0);};

    /** Returns whether smoothing time and value are initialized
     * @see smoothAnswerTime() and smoothAnswerValue()
     */
    PVSSboolean smoothAnswer() const
    {return smoothAnswerTime() || smoothAnswerValue();};

    /// Returns the id stored in this RequestItem
    const DpIdentifier &getId() const {return id;};

    /// Returns the actual number for smoothing
    PVSSushort getNumber() const {return number;};

    /// Returns the smoothing tolerance value
    const FloatVar &getTolerance() const {return tolerance;};

    /// Returns the smoothing time
    const TimeVar &getSmoothTime() const {return smoothTime;};

    /** Debug output method
     * @param[out] to the stream to write to
     * @param level controlls the amount of debug information, the higher the more
     */
    void debug(std::ostream &to, int level) const;

    /// Returns the corrected number for smoothing, which is influenced by plusStart
    PVSSushort getNumberForSmoothing() const { return (number == plusStart) ? 0 : number; }

  protected:
  private:
    DpIdentifier id;
    PVSSushort number;
    FloatVar tolerance;
    TimeVar smoothTime;
};

// ========== inline-functions ============================================================
inline RequestItem::RequestItem(const DpIdentifier &newId, PVSSushort newNumber, const FloatVar &newTolerance, const TimeVar &newSmoothTime)
  : PtrListItem(),
  id(newId),
  number(newNumber),
  //	  number(newNumber > plus5And5 && newNumber != plusStart ? onlyEvents : newNumber),
  tolerance(newTolerance),
smoothTime(newSmoothTime)
{
}

  inline RequestItem::RequestItem(const RequestItem &item)
: PtrListItem(), smoothTime(0, 0)
{
  operator=(item);
}

inline RequestItem::~RequestItem()
{
}

#endif /* _REQUESTITEM_H_ */

