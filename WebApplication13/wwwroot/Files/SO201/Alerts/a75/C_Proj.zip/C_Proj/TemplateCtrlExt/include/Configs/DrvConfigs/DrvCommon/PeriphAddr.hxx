#ifndef _DPPERIPHADDR_H_
#define _DPPERIPHADDR_H_

// Vorwaerts-Deklaration der Eigenen Klasse
class PeriphAddr;

#define DRV_IDENT_LEN	12

// System-Include-Files
#include <DpConfig.hxx>
#include <CharString.hxx>
#include <TimeVar.hxx>
#include <ConfigTypes.hxx>
#include <Resources.hxx>

#include <Transformation.hxx>

// Vorwaerts-Deklarationen :
class Variable;

// old polling - internal class, no comment by intent!
struct OldPolling {
  TimeVar t_start;
  TimeVar t_interval;
  TimeVar t_timeout;

  OldPolling() : t_start(TimeVar::NullTimeVar), t_interval(TimeVar::NullTimeVar), t_timeout(TimeVar::NullTimeVar) {}
  OldPolling(const OldPolling &op) : t_start(op.t_start), t_interval(op.t_interval), t_timeout(op.t_timeout) {}
};

// ============ PeriphAddr =======================================================================

/** The _address config class. This class holds all the information a driver needs to address data on
    the peripheral system. It does also hold a pointer to a transformation object, which is responsible
    to convert data between the hardware and the PVSS format.
    The base class DpConfig does not contain any relevant information for an API developer.
  */
class DLLEXP_CONFIGS PeriphAddr : public DpConfig 
{
  friend class UNIT_TEST_FRIEND_CLASS;
public:
  /// the (virtual) name attribute
  static const DpAttributeNrType NAME;
  /// the subindex attribute
  static const DpAttributeNrType SUBINDEX;
  /// the response mode attribute
  static const DpAttributeNrType RESPONSE_MODE;
  /// the t_start attribute
  static const DpAttributeNrType T_START;
  /// the poll interval attribute
  static const DpAttributeNrType T_INTERVAL;
  /// the timeout attribute
  static const DpAttributeNrType T_TIMEOUT;  
  /// the transformation type attribute @see Transformation
  static const DpAttributeNrType TRANSFORM;
  /// the driver description attribute
  static const DpAttributeNrType DRV_IDENT;
  /// the offset attribute
  static const DpAttributeNrType OFFSET;
  /// the (virtual) active attribute
  static const DpAttributeNrType ACTIVE;
  /// the (virtual) direction attribute
  static const DpAttributeNrType DIRECTION;
  /// the (virtual) internal attribute
  static const DpAttributeNrType INTERNAL;
  /// the (virtual) lowlevel attribute
  static const DpAttributeNrType LOWLEVEL;
  /// the real mode attribute. Internal use only!
  static const DpAttributeNrType RESPONSE_MODE_INTERNAL;
  /// the old text style poll group attribute
  static const DpAttributeNrType POLL_GROUP_NAME;
  /// the poll group attribute.
  static const DpAttributeNrType POLL_GROUP;
  /// the connection attribute.
  static const DpAttributeNrType CONNECTION;

  /// constructor, initialisation with zero values
  PeriphAddr();

  /// copy constructor
  /// @param profiAdr the PeriphAddr, which shall be copied from
  PeriphAddr(const PeriphAddr &profiAdr);

  /// destructor
  virtual ~PeriphAddr();

  /** operator << for itcNdrUbSend stream
      @param ndrStream the stream, which to send to
      @param aTrans the PeriphAddr
    */
  friend DLLEXP_CONFIGS itcNdrUbSend &operator<<(itcNdrUbSend &ndrStream, const PeriphAddr &aTrans);

  /** operator >> for itcNdrUbReceive stream
      @param ndrStream the stream, which to receive from
      @param aTrans the PeriphAddr
    */
  friend DLLEXP_CONFIGS itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream, PeriphAddr &aTrans);

  /** assignment operator used for type conversion
      @param aConfig the DpConfig to convert
      @return the resulting DpConfig
    */
  virtual DpConfig &operator=(const DpConfig &aConfig);

  /** non virtual assignment operator for PeriphAddr
      @param rVal the PeriphAddr to assign
      @return the resulting PeriphAddr
    */
  PeriphAddr &operator=(const PeriphAddr &rVal)
    { operator=((const DpConfig &) rVal); return *this; }

  /** comparison operator ==
      @param rVal the DpConfig to compare with
      @return 0 if not equal else 1
    */
  virtual int operator==(const DpConfig &rVal) const;

  /** allocate new PeriphAddr
      @param configNr the config type
      @return the new PeriphAddr
    */
  static PeriphAddr *allocate(const DpConfigNrType &configNr);

  /**  get a specific attribute
       @param detailNr the detail number, currently set to 0
       @param attrNr the attribute number, must be defined for this config
       @return a clone of the value variable for the requested attribute - delete after use!
  */
  virtual Variable *getAttribut(DpDetailNrType detailNr, DpAttributeNrType attrNr) const;

  /**  set a specific attribute
       @param detailNr the detail number, currently set to 0
       @param attrNr the attribute number, must be defined for this config
       @param var the value variable for the requested attribute - must be of the right type
       @return PVSS_TRUE if succes else PVSS_FALSE
  */
  virtual PVSSboolean setAttribut(DpDetailNrType detailNr, DpAttributeNrType attrNr, const Variable &var);

  /// return type of DP config
  virtual DpConfigType isA() const;

  /// return size of DP config
  virtual unsigned long sizeOf() const;

  /** check if own DP config type matches other DP config type
      @param configType the DpConfigType to check
      @return DPCONFIG_PERIPH_ADDR if argument is PeriphAddr else the DP config type
  */
  virtual DpConfigType isA(DpConfigType configType) const;

  /** send to itcNdrUbSend stream
      @param ndrStream the stream, which to send to
    */
  virtual void outNdrUb(itcNdrUbSend &ndrStream) const;

  /** receive from itcNdrUbReceive stream
      @param ndrStream the stream, which to receive from
    */
  virtual void inNdrUb(itcNdrUbReceive &ndrStream);

  /// check if the config settings are consistent
  virtual PVSSboolean isConsistent() const;

  /// send debug info to output stream
  /// @param to the output stream
  /// @param level the debug level
  virtual void debug(std::ostream &to, int level) const;

  // //////////////////////////////////////////// Zugriffs - Methoden ////////////////////////////////////////
  //

  /// get the address string (_address.._reference)
  const CharString &getName() const { return name; }			   // Name des Peripherieobjekts

  /// set the address string (_address.._reference)
  /// @param newName the name to set
  void setName(const CharString &newName) {name = newName; }

  /// get the poll group ID (_address.._poll_group)
  DpIdType getPollGroupId() const { return pollGroupId; }			   // poll group
  
  /// set the poll group ID (_address.._poll_group)
  /// @param newPollGroup the new poll group ID
  void setPollGroupId(DpIdType newPollGroup) { pollGroupId = newPollGroup; }
  
  /// get the connection ID (_address.._connection)
  DpIdType getConnectionId() const { return connectionId; }			   // connection

  /// set the connection ID (_address.._connection)
  /// @param newConnection the new connection ID
  void setConnectionId(DpIdType newConnection) { connectionId = newConnection; }

  /// get the subindex (_address.._subindex)
  PVSSushort getSubindex() const { return subindex; }				       // Subindex im Fall von Arrays

  /// set the subindex (_address.._subindex)
  /// @param newSubindex the subindex to set
  void setSubindex(PVSSushort newSubindex) { subindex = newSubindex; }
  
  /// get the driver identifcation (_address.._drv_ident)
  /// @n This is used by the para panel only.
  CharString getDrvIdent() const;

  /// set the driver identifcation (_address.._drv_ident)
  /// @n This is used by the para panel only.
  /// @param newIdent the identifcation to set
  void setDrvIdent(const CharString &newIdent);
  
  /// get the offset
  PVSSushort getOffset() const;				      // Offset im Falle von Records

  /// set the offset
  /// @param newOffset the offset to set
  void setOffset(PVSSushort newOffset);
  
  /// get the active bit (_address.._active)
  PVSSboolean getActive() const {return (response_mode & PERIPHACTIVE) ? PVSS_FALSE : PVSS_TRUE;}

  /// set the active bit (_address.._active)
  /// @param newState the value to set
  void  setActive(PVSSboolean newState);
  
  /// get the direction part of the response_mode (_address.._direction)
  PVSSuchar getDirection() const {return (response_mode & AM_MASK);}

  /// set the direction part of the response_mode (_address.._direction)
  /// @param newDir the direction to set
  void  setDirection(PVSSuchar newDir);
  
  /// get the internal flag
  PVSSboolean getInternal() const {return (response_mode & DRIVERINTERNAL) ? PVSS_TRUE : PVSS_FALSE;}

  /// set the internal flag
  /// @param newState the state to set
  void  setInternal(PVSSboolean newState);
  
  /// get the LLV-Flag
  PVSSboolean getLowLevelFilter() const {return (response_mode & LOWLEVELFILTER) ? PVSS_TRUE : PVSS_FALSE;}

  /// set the LLV-Flag
  /// @param newState the state to set
  void  setLowLevelFilter(PVSSboolean newState);
  
  /// get the address mode (_address.._mode)
  /// @see AddressMode 
  PVSSuchar getResponseMode() const;			// Response Mode siehe enum eRespMode

  /// get the address mode (_address.._mode)
  /// @see AddressMode 
  IL_DEPRECATED("deprecated, use getResponseMode() instead")
  PVSSuchar getResponse_mode() const { return getResponseMode(); }			// Response Mode siehe enum eRespMode

  /// set the address mode (_address.._mode)
  /// @see AddressMode 
  /// @param newResponse_mode the address mode to set
  void setResponseMode(PVSSuchar newResponse_mode);

  /// set the address mode (_address.._mode)
  /// @see AddressMode 
  /// @param newResponse_mode the address mode to set
  IL_DEPRECATED("deprecated, use setResponseMode() instead")
  void setResponse_mode(PVSSuchar newResponse_mode) { setResponseMode(newResponse_mode); }
  
  /// get the sync time for polled data (_address.._start)
  const TimeVar &getT_start() const;

  /// set the sync time for polled data (_address.._start)
  /// @param newT_start the sync time to set
  void setT_start(const TimeVar &newT_start);
  
  /// get the polling time (_address.._interval)
  const TimeVar &getT_interval() const;

  /// set the polling time (_address.._interval)
  /// @param newT_interval the polling time to set
  void setT_interval(const TimeVar &newT_interval);
  
  /// get the reply timeout (_address.._reply)
  const TimeVar &getT_timeout() const;

  /// set the reply timeout (_address.._reply)
  /// @param newT_timeout the reply timeout to set
  void setT_timeout(const TimeVar &newT_timeout);
  
  /// get the tranformation type (_address.._datatype)
  TransformationType getTransformationType() const;

  /// set the transformation type (_address.._datatype). 
  /// Use this function only if the hardware determines the transformation type like the profibus.
  /// @param newType the transformation type to set
  void setTransformationType(TransformationType newType);
  
  /// get the transformation object
  const Transformation *getTransform() const;

  /// get the transformation object
  Transformation *getTransform();

  /// set the transformation object. 
  /// @param newTransform the transformation object to set
  void setTransform(Transformation *newTransform);

  /// remove and delete the transformation object.
  void removeTransform();
    
  /// check if the transformation object is valid
  int isValidTransform() const;
  
  /// Check if the data are to be polled.
  PVSSboolean isPolling() const { return (( ((response_mode & AM_MASK) == AM_InputPoll) ||
                                            ((response_mode & AM_MASK) == AM_IOGroupPoll) ||
                                            ((response_mode & AM_MASK) == AM_IOSinglePoll) ||
                                            ((response_mode & AM_MASK) == AM_InputCyclicOnUse) ||
                                            ((response_mode & AM_MASK) == AM_IOCyclicOnUse) ||
                                            ((response_mode & AM_MASK) == AM_InputOnDemand) ||          // OnDemand actions are considered polling
                                            ((response_mode & AM_MASK) == AM_IOOnDemand) 
                                            ) ? PVSS_TRUE : PVSS_FALSE); }
  
  /// Check if the data are to be polled when displayed.
  PVSSboolean isPollingOnUse() const { return (( ((response_mode & AM_MASK) == AM_InputCyclicOnUse) ||
                                                 ((response_mode & AM_MASK) == AM_IOCyclicOnUse)                                    
                                                ) ? PVSS_TRUE : PVSS_FALSE); }

  /// Check if the data are to be refreshed when displayed.
  PVSSboolean isOnDemand() const { return (( ((response_mode & AM_MASK) == AM_InputOnDemand) ||
                                             ((response_mode & AM_MASK) == AM_IOOnDemand)                                    
                                            ) ? PVSS_TRUE : PVSS_FALSE); }

  /// Check if the data are to be refreshed when displayed.
  PVSSboolean isSpontaneousOnUse() const { return (( ((response_mode & AM_MASK) == AM_InputSpontaneousOnUse) ||
                                                     ((response_mode & AM_MASK) == AM_IOSpontaneousOnUse)                                    
                                                   ) ? PVSS_TRUE : PVSS_FALSE); }

  /// Check if the config needs subscription to _connect config
  PVSSboolean needsConnectCount() const { return (( 
                                            ((response_mode & AM_MASK) == AM_InputCyclicOnUse) ||
                                            ((response_mode & AM_MASK) == AM_IOCyclicOnUse) ||
                                            ((response_mode & AM_MASK) == AM_InputOnDemand) ||    
                                            ((response_mode & AM_MASK) == AM_IOOnDemand) ||
                                            ((response_mode & AM_MASK) == AM_InputSpontaneousOnUse) ||
                                            ((response_mode & AM_MASK) == AM_IOSpontaneousOnUse) 
                                           ) ? PVSS_TRUE : PVSS_FALSE); }

  /** Check if the data are to be sent to the hardware. 
      @return PVSS_TRUE if the direction is from PVSS to the hardware.
  */
  PVSSboolean isOutput() const { return (((response_mode & AM_MASK) == AM_Output ||
                                          (response_mode & AM_MASK) == AM_OutputSingle ||
                                          (response_mode & AM_MASK) == AM_IOGroupSpont ||
                                          (response_mode & AM_MASK) == AM_IOGroupPoll ||
                                          (response_mode & AM_MASK) == AM_IOSinglePoll ||
                                          (response_mode & AM_MASK) == AM_IOGroupSQuery ||
                                          (response_mode & AM_MASK) == AM_IOOnDemand ||
                                          (response_mode & AM_MASK) == AM_IOCyclicOnUse ||
                                          (response_mode & AM_MASK) == AM_IOSpontaneousOnUse
                                         ) ? PVSS_TRUE : PVSS_FALSE); }
  
  /** Check if the data are input and output. 
      @return PVSS_TRUE if the config is an input AND output condfig.
  */
  PVSSboolean isInputOutput() const { return (((response_mode & AM_MASK) == AM_IOGroupSpont ||
                                               (response_mode & AM_MASK) == AM_IOGroupPoll ||
                                               (response_mode & AM_MASK) == AM_IOSinglePoll ||
                                               (response_mode & AM_MASK) == AM_IOGroupSQuery ||
                                               (response_mode & AM_MASK) == AM_IOOnDemand ||
                                               (response_mode & AM_MASK) == AM_IOCyclicOnUse ||
                                               (response_mode & AM_MASK) == AM_IOSpontaneousOnUse
                                              ) ? PVSS_TRUE : PVSS_FALSE); }
  
  /** Check if the data are to be sent to the hardware. 
      @return PVSS_TRUE if the direction is from PVSS to the hardware.
  */
  PVSSboolean isOnlyOutput() const { return (((response_mode & AM_MASK) == AM_Output ||
                                          (response_mode & AM_MASK) == AM_OutputSingle) ? PVSS_TRUE : PVSS_FALSE); }

  /// check if it is an alert address.
  /// @return PVSS_TRUE if it is
  PVSSboolean isAlert() const { return (((response_mode & AM_MASK) == AM_Alert) ? PVSS_TRUE : PVSS_FALSE); }

  /// check for single connection
  /// @return PVSS_TRUE if _address.._mode is AM_OutputSingle
  PVSSboolean isSingle() const { return (((response_mode & AM_MASK) == AM_OutputSingle || 
                                          (response_mode & AM_MASK) == AM_IOSinglePoll ||
                                          (response_mode & AM_MASK) == AM_IOOnDemand ||
                                          (response_mode & AM_MASK) == AM_IOCyclicOnUse ||
                                          (response_mode & AM_MASK) == AM_IOSpontaneousOnUse
                                         ) ? PVSS_TRUE : PVSS_FALSE); }

  /// check if low level comparision is in effect
  PVSSboolean isLlfOn() const { return getLowLevelFilter(); }
  
  /// get the next polling time
  /// @param oldPoll the old polling time
  TimeVar getNextPollTime(TimeVar& oldPoll);

  /// check if group polling is active in this config
  PVSSboolean isGroupPolling ();

  // 6.6.2011 trausi: COMDRV-13b-6 monitor alarm config
  /** check if the alarm config is valid for an AM_Alarm config type. The flags are only maintained if the
      AM_Alarm mode is selected, otherwise they are 0 and therefore the function will return PVSS_FALSE.
      @return PVSS_TRUE if the corresponding _alert_hdl config exists and is active, else PVSS_FALSE 
  */
  PVSSboolean isAlarmConfigValid() const;

  /// set the AlarmConfig-Flag
  /// @param newState the state to set
  void  setAlarmConfigFlag(PVSSboolean newState);

  /// set the AlarmActive-Flag
  /// @param newState the state to set
  void  setAlarmActiveFlag(PVSSboolean newState);

  /// get the offset for connection count when doing xxx on use acquisition
  int getSubscriptionOffset() const;

  /// set the OnUseActive bit for acqu. modes xxxOnUse
  /// @param needsData is true if data acquisition should be done
  void setOnUseFlag(PVSSboolean needsData);

  /// get the OnUseActive bit
  PVSSboolean isOnUseActive() const;

  /// get TracingSingle bit for tracing a single datapoint
  /// @return true if tracing of specific datapoints should be done
  bool shouldTraceSingle() const;

  /// set TracingSingle bit for tracing a single datapoint
  /// @param enableTraceSingle is true if tracing of specific datapoints should be done
  void setTraceSingle(bool enableTraceSingle = true);

private:

  CharString name;
  PVSSushort subindex;
  PVSSushort offset;

  PVSSushort response_mode;           // originally 8 bit, has been expanded for internal purposes
//  char drv_ident[DRV_IDENT_LEN];    // max 11 chars + \0 - see define above
  PVSSshort drvIdentId;

  OldPolling *oldPollPtr;
  Transformation *transformPtr;
  TransformationType transType;

  DpIdType pollGroupId;
  DpIdType connectionId;
};

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Inline-Funktionen
//
inline  PVSSushort PeriphAddr::getOffset() const
{
  return offset;
}


inline void PeriphAddr::setOffset(PVSSushort newOffset)
{
  offset = newOffset;
}


inline  PVSSuchar PeriphAddr::getResponseMode() const
{
  return (PVSSuchar) (response_mode & RESPMODEMASK);
}


inline void PeriphAddr::setResponseMode(PVSSuchar  newResponse_mode)
{
  response_mode &= ~RESPMODEMASK;
  response_mode |= (newResponse_mode & RESPMODEMASK);
}

inline void PeriphAddr::setActive(PVSSboolean newState)
{
  if (newState)
    response_mode &= ~PERIPHACTIVE;
  else
    response_mode |= PERIPHACTIVE;
}

inline void PeriphAddr::setDirection(PVSSuchar newDir)
{
  response_mode &= ~AM_MASK;
  response_mode |= (newDir & AM_MASK);
}

inline void PeriphAddr::setInternal(PVSSboolean newState)
{
  if (newState)
    response_mode |= DRIVERINTERNAL;
  else
    response_mode &= ~DRIVERINTERNAL;
}

inline void PeriphAddr::setLowLevelFilter(PVSSboolean newState)
{
  if (newState)
    response_mode |= LOWLEVELFILTER;
  else
    response_mode &= ~LOWLEVELFILTER;
}

inline const TimeVar & PeriphAddr::getT_start() const
{
    return (oldPollPtr) ? oldPollPtr->t_start : TimeVar::NullTimeVar;
}

inline const TimeVar & PeriphAddr::getT_interval() const
{
    return (oldPollPtr) ? oldPollPtr->t_interval : TimeVar::NullTimeVar;
}

inline const TimeVar & PeriphAddr::getT_timeout() const
{
    return (oldPollPtr) ? oldPollPtr->t_timeout : TimeVar::NullTimeVar;
}

inline const Transformation * PeriphAddr::getTransform() const
{
  return transformPtr;
}

inline Transformation * PeriphAddr::getTransform()
{
  return transformPtr;
}

inline int PeriphAddr::isValidTransform() const
{
  return transformPtr != 0;
}

inline DpConfigType PeriphAddr::isA() const
{
	return DPCONFIG_PERIPH_ADDR;
}

inline DpConfigType PeriphAddr::isA(DpConfigType confType) const
{
	if( confType == DPCONFIG_PERIPH_ADDR ) return DPCONFIG_PERIPH_ADDR;
	return DpConfig::isA( confType );
}


inline TransformationType PeriphAddr::getTransformationType() const
{
  return transType;
}
  
inline void PeriphAddr::setTransformationType(TransformationType newType)
{
  if (newType != transType)
  {
    delete transformPtr;
    transformPtr = 0;
    transType = newType;
  }
}

inline unsigned long PeriphAddr::sizeOf() const
{
  return sizeof(PeriphAddr);
}

inline PVSSboolean PeriphAddr::isAlarmConfigValid() const
{
  if (! isAlert()) return PVSS_FALSE;

  PVSSushort validMask = AM_AlertConfigAvailable | AM_AlertConfigActive;

  return ((response_mode & validMask) == validMask) ? PVSS_TRUE : PVSS_FALSE;
}

inline void  PeriphAddr::setAlarmConfigFlag(PVSSboolean newState)
{
  if (! newState)
  {
    response_mode &= ~AM_AlertConfigAvailable;
    response_mode &= ~AM_AlertConfigActive;       // also clear the active bit
  }
  else
    response_mode |= AM_AlertConfigAvailable;
}

inline void  PeriphAddr::setAlarmActiveFlag(PVSSboolean newState)
{
  if (! newState)
    response_mode &= ~AM_AlertConfigActive;
  else
    response_mode |= AM_AlertConfigActive;
}

/// set the OnUseActive bit for acqu. modes xxxOnUse
/// @param needsData is true if data acquisition should be done
inline void PeriphAddr::setOnUseFlag(PVSSboolean needsData)
{
  if (! needsData)
    response_mode &= ~AM_OnUsePollActive;
  else
    response_mode |= AM_OnUsePollActive;
}

/// get the OnUseActive bit
inline PVSSboolean PeriphAddr::isOnUseActive() const
{
  return ((response_mode & AM_OnUsePollActive) == AM_OnUsePollActive) ? PVSS_TRUE : PVSS_FALSE;
}

inline bool PeriphAddr::shouldTraceSingle() const
{
  return ((response_mode & AM_TraceSingle) == AM_TraceSingle);
}

inline void PeriphAddr::setTraceSingle(bool enableTraceSingle)
{
  // COVINFO BLOCK: engineering (for debugging)
  if (enableTraceSingle)
  {
    // the standard case
    response_mode |= AM_TraceSingle;
  }
  else
  {
    // clear trace single bit
    response_mode &= ~AM_TraceSingle;
  }
  // COVINFO BLOCKEND
}

#endif /* _DPPERIPHADDR_H_ */

