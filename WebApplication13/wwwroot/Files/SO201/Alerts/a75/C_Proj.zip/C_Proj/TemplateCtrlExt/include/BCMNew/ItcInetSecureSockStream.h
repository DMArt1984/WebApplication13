#ifndef _ITCINETSECURESOCKSTREAM_H
#define _ITCINETSECURESOCKSTREAM_H

#include "ItcPrelude.h"
#include "ItcTransport.h"
#include "ITLSContextHandler.h"

#ifdef QT_NAMESPACE
namespace QT_NAMESPACE { class QThread; }
using QT_NAMESPACE::QThread;
#else
class QThread;
#endif

class itcInetAddress;
class ConnectWorker;
class AcceptWorker;

/// This class is an implementation of the itcNetConnection abstract class,
/// it facilitates the communication between two internet addresses using
/// sockets.
class DLLEXP_BCM itcInetSecureSockStream : public itcNetConnection
{
public:

  /// Constructor
  itcInetSecureSockStream(ITLSContextHandler *tlsCtxHandler);

  /// Constructor
  /// @param opt Connection options
  itcInetSecureSockStream(ITLSContextHandler *tlsCtxHandler, ConnOptions opt);

  /// Constructor
  /// @param ia Address to be bound to this socket
  itcInetSecureSockStream(ITLSContextHandler *tlsCtxHandler, itcInetAddress &ia);

  /// Constructor
  /// @param fd Socket descriptor
  /// @param type Connection type
  itcInetSecureSockStream(ITLSContextHandler *tlsCtxHandler, int fd, itcConnection::ConnType type);

  /// Destructor
  virtual ~itcInetSecureSockStream();

  /// Open the connection
  /// @param ia Address to which the connection should be established   
  /// @return 1 if successful, other value otherwise
  virtual int OpenConnection ( itcInetAddress &ia, ICBBcmReady *pcbFunc, void *pcbParams );

  /// Create the endpoint
  /// @param ia Address to assign to the bound socket.
  /// @return 1 if successful, 0 if failure
  virtual int CreateEndpoint(itcInetAddress &ia);

  /// Accept the connection
  /// @return Pointer to the itcConnection
  virtual int AcceptConnection ( itcConnection **newConnection, ICBBcmReady *pcbFunc, void *pcbParams );
  
  /// Read the data from the socket
  virtual int Read(void *, int);

  /// Writing data to the socket
  virtual int Write(const void *, int);

  /// Set connection options (using fcntl or ioctl socket methods)
  /// @param opt New connection options to be set
  virtual int SetOption(ConnOptions opt);
  
  /// Close the connection
  /// @return 1 if success, 0 in case of failure
  virtual int Close(); 
  
  /// Get the peername (calls the getpeername socket method)
  /// @param ia Receives the address of the peer
  /// @return 1 if successful, 0 if failure
  int GetPeername(itcInetAddress &ia);

  /// Get the name of the used ciphersuite
  /// @return ciphersuite's name 
  virtual const char *getCipherSuite() { return (tlsCtx ? tlsCtx->getCipherSuite(Descriptor()) : "failed to get cipher"); }
 
  /// Set connection timeout
  /// @param timo Connection timeout in milliseconds
  void setConnTimeout(unsigned int timo); 
  
  /// Calls ioctl socket method with the FIONREAD parameter
  virtual int Pending();  

  /// bytes method returns the number of bytes in internal buffers of the itcNetConnection
  virtual long bytes() { return((tlsCtx == 0) ? 0L : long(tlsCtx->getPending(td))); }
  
private:
  /// sets intrFlag to 1
  static void alrmSigHdl ( int );

  int OpenConnection_intern (itcInetAddress &ia, ICBBcmReady *pcbFunc, void *pcbParams);

  int AcceptConnection_intern (itcConnection **newConnection, ICBBcmReady *pcbFunc, void *pcbParams, QThread *worker);


  ITLSContextHandler *tlsCtx;

  struct Private;
  Private *internal_data;

  /// connection timeout
  unsigned int connTimo;

  friend class UNIT_TEST_FRIEND_CLASS;
  friend class ConnectWorker;
  friend class AcceptWorker;
};




#endif

