#ifndef _COMMONNAMESERVICE_H_
#define _COMMONNAMESERVICE_H_

#include <CNSDataIdentifier.hxx>
#include <CNSNodeNames.hxx>
#include <CNSNodeTree.hxx>
#include <CNSObserver.hxx>
#include <CNSVisitor.hxx>
#include <CNSNode.hxx>

#include <Types.hxx>
#include <SystemNumType.hxx>
#include <CharString.hxx>
#include <DpIdentifier.hxx>

#include <vector>
#include <set>
#include <utility> // std::pair

// forward declaration
class DpIdentification;
class CNSContainer;
class Manager;
class WaitForAnswer;
class ErrClass;
class CNSTree;
class CNSVisitor;
class CNSTreeVisitor;


// not to hide the implementation, only to make it enjoyable
typedef std::vector<CNSNodeNames> CNSNodeNamesVector;
typedef std::vector<CharString> CharStringVector;
typedef std::vector<ViewId> ViewIdVector;

typedef std::vector<CNSNodeNamesVector> CNSNodeNamesMatrix;
typedef std::vector<CNSDataIdentifierVector> CNSDataIdentifierMatrix;

// stores the registered observers and the users who registered them
typedef std::vector<std::pair<CNSObserver *, PVSSuserIdType> > CNSObserverVector;


/**
 * Public interface to the Common Name Service.
 */
class DLLEXP_MANAGER CommonNameService
{
  friend class UNIT_TEST_FRIEND_CLASS;

public:

  // Manager needs to call fireCNSObservers()
  friend class Manager;

  /**
   * Used for searches to define which names should be used for search.
   * For searching in names and display names, use ALL_NAMES.
   * It is possible to combine modes.
   */
  enum SearchMode
  {
    NAME = CNSVisitor::NAME,
    DISPLAY_NAME = CNSVisitor::DISPLAY_NAME,
    ALL_NAMES = NAME | DISPLAY_NAME,
    CASE_INSENSITIVE = CNSVisitor::CASE_INSENSITIVE
  };

  /// Used for searches to define that all views are to be searched.
  static const ViewId ALL_VIEWS;
  /// Used for searches to define that all systems are to be searched.
  static const SystemNumType ALL_SYSTEMS;
  /// Used for searches to define that all data identifiers should be matched.
  static const CNSDataIdentifierType ALL_TYPES;
  /// Used for searches to define that all display name languages should be matched.
  static const LanguageIdType ALL_LANGUAGES;

public:
  /**
   * Create an object that gets its information from the manager object.
   */
  CommonNameService();

  /// Destructor
  virtual ~CommonNameService();

public:
  /**
   * Add an observer for CNS changes.
   * The caller has to make sure that the specified object exists as long
   * as it is registered as observer.
   */
  virtual void addObserver(CNSObserver &observer);

  /**
   * Remove an observer for CNS changes.
   * The specified object has to have the same address with which it was added.
   */
  virtual PVSSboolean removeObserver(CNSObserver &observer);

  /**
   * Get the identifier for a view.
   *
   * @param sys The system in which to look for the view
   * @param viewName The view name
   *
   * @return The ViewId of the given view or 0 to indicate an error
   */
  virtual ViewId getViewId(const SystemNumType &sys, const char *viewName) const;

  /**
   * Get the identifier for a view from the local system.
   *
   * @param viewName The view name
   *
   * @return The ViewId of the given view or 0 to indicate an error
   */
  virtual ViewId getViewId(const char *viewName) const;

  /**
   * Get the separators of a view in the local system.
   * If no application specific separator is set, the default value ('.')
   * will be returned.
   *
   * @param sys The system that contains the view
   * @param view The id of the view
   * @param [out] separators Receives the separators.
   *
   * @return PVSS_FALSE if the system cannot be found, otherwise PVSS_TRUE.
   */
  virtual PVSSboolean getSeparators(const SystemNumType &sys,
                                    const ViewId &view,
                                    LangText &separators) const;

  /**
   * Get the separators of a view in the local system.
   * If no application specific separator is set, the default value ('.')
   * will be returned.
   *
   * @param view The id of the view
   * @param [out] separators Receives the separators.
   *
   * @return PVSS_FALSE if the system cannot be found, otherwise PVSS_TRUE.
   */
  virtual PVSSboolean getSeparators(const ViewId &view, LangText &separators) const;

  /**
   * Get all views of a system.
   *
   * @param sys   The system.
   * @param [out] views A vector that receives all ViewIds of the given system.
   *
   * @return PVSS_FALSE if the system cannot be found, else PVSS_TRUE.
   */
  virtual PVSSboolean getViews(const SystemNumType &sys, ViewIdVector &views) const;

  /**
   * Set the display names of a system.
   * The name is the PVSS name and cannot be changed.
   *
   * @param sys The system.
   * @param displayNames The display names of the system.
   * @param wait A WaitForAnswer object to handle the answer (maybe error!)
   * @param del  The WaitForAnswer object should be deleted by the framework (default)
   *
   * @return PVSS_TRUE if message has been sent.
   */
  virtual PVSSboolean setSystemNames(const SystemNumType &sys,
                                     const LangText &displayNames,
                                     WaitForAnswer *wait = 0,
                                     PVSSboolean del = PVSS_TRUE);

  /**
   * Get the names of a system.
   *
   * @param sys         The system.
   * @param [out] names Receives the names of the system (name and display names).
   *
   * @return PVSS_TRUE if successful.
   */
  virtual PVSSboolean getSystemNames(const SystemNumType &sys,
                                     CNSNodeNames &names);

  /**
   * Get the names of a view.
   *
   * @param sys         The system.
   * @param view        The view.
   * @param [out] names Receives the names of the view (name and display names).
   *
   * @return PVSS_TRUE if successful.
   */
  virtual PVSSboolean getViewNames(const SystemNumType &sys,
                                   const ViewId &view,
                                   CNSNodeNames &names);

  /**
   * Create a view in the local system.
   *
   * @param viewNames The name of the view (in all languages).
   * @param separator A language specific separator character.
   * @param wait      A WaitForAnswer object to handle the answer (maybe error!)
   * @param del  The WaitForAnswer object should be deleted by the framework (default)
   *
   * @return PVSS_TRUE if message has been sent.
   */
  virtual PVSSboolean createView(const CNSNodeNames &viewNames,
                                 const LangText &separators,
                                 WaitForAnswer *wait = 0,
                                 PVSSboolean del = PVSS_TRUE);

  /**
   * Create a view.
   *
   * @param sys The system where to create the view.
   *            If no sys is given this means local system.
   * @param viewNames The name of the view (in all languages).
   * @param separator A language specific separator character.
   * @param wait      A WaitForAnswer object to handle the answer (maybe error!)
   * @param del  The WaitForAnswer object should be deleted by the framework (default)
   *
   * @return PVSS_TRUE if message has been sent.
   */
  virtual PVSSboolean createView(const SystemNumType &sys,
                                 const CNSNodeNames &viewNames,
                                 const LangText &separators,
                                 WaitForAnswer *wait = 0,
                                 PVSSboolean del = PVSS_TRUE);

  /**
   * Modify an existing view in the local system.
   *
   * @param sys      The system where to find the view.
   * @param view     The view.
   * @param separator A language specific separator character.
   * @param wait      A WaitForAnswer object to handle the answer (maybe error!)
   * @param del  The WaitForAnswer object should be deleted by the framework (default)
   *
   * @return PVSS_TRUE if message has been sent.
   */
  virtual PVSSboolean changeView(const SystemNumType &sys,
                                 const ViewId &view,
                                 const LangText &separator,
                                 WaitForAnswer *wait = 0,
                                 PVSSboolean del = PVSS_TRUE);

  /**
   * Modify an existing view.
   *
   * @param sys      The system where to find the view.
   * @param view     The view.
   * @param viewNames The name of the view (in all languages).
   * @param wait      A WaitForAnswer object to handle the answer (maybe error!)
   * @param del  The WaitForAnswer object should be deleted by the framework (default)
   *
   * @return PVSS_TRUE if message has been sent.
   */
  virtual PVSSboolean changeView(const SystemNumType &sys,
                                 const ViewId &view,
                                 const CNSNodeNames &viewNames,
                                 WaitForAnswer *wait = 0,
                                 PVSSboolean del = PVSS_TRUE);

  /**
   * Delete an existing view.
   * All trees of the view will be deleted.
   *
   * @param view     The view.
   * @param wait     A WaitForAnswer object to handle the answer (maybe error!)
   * @param del  The WaitForAnswer object should be deleted by the framework (default)
   *
   * @return PVSS_TRUE if message has been sent.
   */
  virtual PVSSboolean deleteView(const ViewId &view,
                                 WaitForAnswer *wait = 0,
                                 PVSSboolean del = PVSS_TRUE);

  /**
   * Delete an existing view.
   * All trees of the view will be deleted.
   *
   * @param sys      The system.
   *                 If no sys is given this mean local system.
   * @param view     The view.
   * @param wait     A WaitForAnswer object to handle the answer (maybe error!)
   * @param del  The WaitForAnswer object should be deleted by the framework (default)
   *
   * @return PVSS_TRUE if message has been sent.
   */
  virtual PVSSboolean deleteView(const SystemNumType &sys,
                                 const ViewId &view,
                                 WaitForAnswer *wait = 0,
                                 PVSSboolean del = PVSS_TRUE);

  /**
   * Add a tree to a view.
   *
   * @param view      The view where to add the tree.
   * @param nameTree  Description of the structure of the tree
   * @param idTree    Description of the objects of the tree
   * @param wait      A WaitForAnswer object to handle the answer (maybe error!)
   * @param del  The WaitForAnswer object should be deleted by the framework (default)
   *
   * @return PVSS_TRUE if message has been sent.
   *
   * <b>Example:</b>
   * @code
   * // The tree is specified like a two-dimensional array, in which the elements are
   * // filled according to the structure of the tree to be created.
   * // For example, for a tree like
   * //
   * //     A
   * //    /|
   * //   B C
   * //  /|
   * // D E
   * //
   * // the input would look like the following:
   * CNSNodeNamesMatrix nameTree;
   * CNSNodeNamesVector v;
   *
   * // add A
   * v.push_back(CNSNodeNames("A"));
   * nameTree.push_back(v);
   *
   * // add B
   * v.clear();
   * v.push_back(CNSNodeNames()); // add an empty element, since B is one level deep
   * v.push_back(CNSNodeNames("B"));
   * nameTree.push_back(v);
   *
   * // add D
   * v.clear();
   * v.push_back(CNSNodeNames());
   * v.push_back(CNSNodeNames());
   * v.push_back(CNSNodeNames("D"));
   * nameTree.push_back(v);
   *
   * // add E
   * v.clear();
   * v.push_back(CNSNodeNames());
   * v.push_back(CNSNodeNames());
   * v.push_back(CNSNodeNames("E"));
   * nameTree.push_back(v);
   *
   * // add C
   * v.clear();
   * v.push_back(CNSNodeNames());
   * v.push_back(CNSNodeNames("C"));
   * nameTree.push_back(v);
   *
   * // The vector now has the following structure:
   * // ["A"]
   * // [""]  ["B"]
   * // [""]  [""]  ["D"]
   * // [""]  [""]  ["E"]
   * // [""]  ["C"]
   * //
   * // The idTree has to be specified in the same format. If a node should not store
   * // a CNSDataIdentifier, just leave the position empty.
   * @endcode
   */
  virtual PVSSboolean addTree(const ViewId &view,
                              const CNSNodeNamesMatrix &nameTree,
                              const CNSDataIdentifierMatrix &idTree,
                              WaitForAnswer *wait = 0,
                              PVSSboolean del = PVSS_TRUE);

  /**
   * Add a tree to a view.
   *
   * @param sys       The system where to add the tree.
   *                  If no sys is given this means local system.
   * @param view      The view where to add the tree.
   * @param nameTree  Description of the structure of the tree
   * @param idTree    Description of the objects of the tree
   * @param wait      A WaitForAnswer object to handle the answer (maybe error!)
   * @param del  The WaitForAnswer object should be deleted by the framework (default)
   *
   * See the other @link addTree(const ViewId &, const CNSNodeNamesMatrix &, const CNSDataIdentifierMatrix &, WaitForAnswer *, PVSSboolean) addTree() @endlink for a usage example.
   *
   * @return PVSS_TRUE if message has been sent.
   */
  virtual PVSSboolean addTree(const SystemNumType &sys,
                              const ViewId &view,
                              const CNSNodeNamesMatrix &nameTree,
                              const CNSDataIdentifierMatrix &idTree,
                              WaitForAnswer *wait = 0,
                              PVSSboolean del = PVSS_TRUE);

  /**
   * Add a tree to a view.
   *
   * @param view The view where to add the tree.
   * @param tree The tree.
   * @param wait A WaitForAnswer object to handle the answer (maybe error!)
   * @param del  The WaitForAnswer object should be deleted by the framework (default)
   *
   * @return PVSS_TRUE if message has been sent.
   *
   * <b>Example:</b>
   * @code
   * // For a tree like
   * //
   * //     A
   * //    /|
   * //   B C
   * //  /|
   * // D E
   * //
   * // the input would look like the following:
   *
   * CNSNodeTree newTree(CNSNodeNames("A"));
   *
   * newTree.addNode("A", CNSNode(CNSNodeNames("B")));
   * newTree.addNode("A", CNSNode(CNSNodeNames("C")));
   *
   * newTree.addNode("B", CNSNode(CNSNodeNames("D")));
   * newTree.addNode("B", CNSNode(CNSNodeNames("E")));
   * @endcode
   */
  virtual PVSSboolean addTree(const ViewId &view,
                              const CNSNodeTree &tree,
                              WaitForAnswer *wait = 0,
                              PVSSboolean del = PVSS_TRUE);

  /**
   * Add a tree to a view.
   *
   * @param sys  The system where to add the tree.
   *             If no sys is given this means local system.
   * @param view The view where to add the tree.
   * @param tree The tree.
   * @param wait A WaitForAnswer object to handle the answer (maybe error!)
   * @param del  The WaitForAnswer object should be deleted by the framework (default)
   *
   * See the other @link addTree(const ViewId &, const CNSNodeTree &, WaitForAnswer *, PVSSboolean) addTree() @endlink for a usage example.
   *
   * @return PVSS_TRUE if message has been sent.
   */
  virtual PVSSboolean addTree(const SystemNumType &sys,
                              const ViewId &view,
                              const CNSNodeTree &tree,
                              WaitForAnswer *wait = 0,
                              PVSSboolean del = PVSS_TRUE);

  /**
   * Modify an existing tree.
   *
   * The (sub-)tree of the given node is replaced by the new tree.
   * node and the whole tree below node is deleted an the new tree is added instead of it.
   *
   * @param node A reference to the subtree that should be modified.
   * @param nameTree Description of the structure of the tree
   * @param idTree   Description of the objects of the tree
   * @param wait     A WaitForAnswer object to handle the answer (maybe error!)
   * @param del  The WaitForAnswer object should be deleted by the framework (default)
   *
   * See @link addTree(const ViewId &, const CNSNodeNamesMatrix &, const CNSDataIdentifierMatrix &, WaitForAnswer *, PVSSboolean) addTree() @endlink for how to use a CNSNodeNamesMatrix.
   *
   * @return PVSS_TRUE if message has been sent.
   */
  virtual PVSSboolean changeTree(const CNSNode &node,
                                 const CNSNodeNamesMatrix &nameTree,
                                 const CNSDataIdentifierMatrix &idTree,
                                 WaitForAnswer *wait = 0,
                                 PVSSboolean del = PVSS_TRUE);

  /**
   * Modify an existing tree.
   *
   * The (sub-)tree of the given node is replaced by the new tree.
   * node and the whole tree below node is deleted an the new tree is added instead of it.
   *
   * @param node A reference to the subtree that should be modified.
   * @param tree The Tree.
   * @param wait A WaitForAnswer object to handle the answer (maybe error!)
   * @param del  The WaitForAnswer object should be deleted by the framework (default).
   *
   * See @link addTree(const ViewId &, const CNSNodeTree &, WaitForAnswer *, PVSSboolean) addTree() @endlink for how to use CNSNodeTree.
   *
   * @return PVSS_TRUE if message has been sent.
   */
  virtual PVSSboolean changeTree(const CNSNode &node,
                                 const CNSNodeTree &tree,
                                 WaitForAnswer *wait = 0,
                                 PVSSboolean del = PVSS_TRUE);

  /**
   * Delete an existing (sub-)tree.
   *
   * @param node A reference to the root node of the (sub-)tree.
   * @param wait A WaitForAnswer object to handle the answer (maybe error!)
   * @param del  The WaitForAnswer object should be deleted by the framework (default)
   *
   * @return PVSS_TRUE if message has been sent.
   */
  virtual PVSSboolean deleteTree(const CNSNode &node,
                                 WaitForAnswer *wait = 0,
                                 PVSSboolean del = PVSS_TRUE);

  /**
   * Get a list of the root nodes of all trees.
   *
   * @param sys           The system.
   * @param view          The view.
   * @param nodes         A reference to the CNSNodeVector which gets the answer
   *                      (may be empty)
   *
   * @return PVSS_TRUE if the input (sys, view) was correct.
   */
  virtual PVSSboolean getTrees(const SystemNumType &sys,
                               const ViewId &view,
                               CNSNodeVector &nodes) const;

  /**
   * Add a new node to an existing tree.
   *
   * @param parent The parent node.
   * @param names  The name and the display names of the node (e.g. northCam).
   * @param id     The CNSDataIdentifier of the node.
   * @param wait   A WaitForAnswer object to handle the answer (maybe error!)
   * @param del  The WaitForAnswer object should be deleted by the framework (default)
   *
   * @return PVSS_TRUE if message has been sent.
   */
  virtual PVSSboolean addNode(const CNSNode &parent,
                              const CNSNodeNames &names,
                              const CNSDataIdentifier &id,
                              WaitForAnswer *wait = 0,
                              PVSSboolean del = PVSS_TRUE);

  /**
   * Attach a new subtree to an existing node.
   *
   * @param parent The parent node.
   * @param nameTree Description of the structure of the tree
   * @param idTree   Description of the objects of the tree
   * @param wait   A WaitForAnswer object to handle the answer (maybe error!)
   * @param del    The WaitForAnswer object should be deleted by the framework (default).
   *
   * See the other @link addTree(const ViewId &, const CNSNodeNamesMatrix &, const CNSDataIdentifierMatrix &, WaitForAnswer *, PVSSboolean) addTree() @endlink for how to use a CNSNodeNamesMatrix.
   *
   * @return PVSS_TRUE if message has been sent.
   */
  virtual PVSSboolean addTree(const CNSNode &parent,
                              const CNSNodeNamesMatrix &nameTree,
                              const CNSDataIdentifierMatrix &idTree,
                              WaitForAnswer *wait = 0,
                              PVSSboolean del = PVSS_TRUE);

  /**
   * Attach a new subtree to an existing node.
   *
   * @param parent The parent node.
   * @param tree   The tree.
   * @param wait   A WaitForAnswer object to handle the answer (maybe error!)
   * @param del    The WaitForAnswer object should be deleted by the framework (default).
   *
   * See @link addTree(const ViewId &, const CNSNodeTree &, WaitForAnswer *, PVSSboolean) addTree() @endlink for how to use CNSNodeTree.
   *
   * @return PVSS_TRUE if message has been sent.
   */
  virtual PVSSboolean addTree(const CNSNode &parent,
                              const CNSNodeTree &tree,
                              WaitForAnswer *wait = 0,
                              PVSSboolean del = PVSS_TRUE);

  /**
   * Change the CNSDataIdentifier that is refered by an existing node.
   *
   * @param node The node.
   * @param id   The new CNSDataIdentifier of the node.
   * @param wait A WaitForAnswer object to handle the answer (maybe error!)
   * @param del  The WaitForAnswer object should be deleted by the framework (default)
   *
   * @return PVSS_TRUE if message has been sent.
   */
  virtual PVSSboolean changeNode(const CNSNode &node,
                                 const CNSDataIdentifier &id,
                                 WaitForAnswer *wait = 0,
                                 PVSSboolean del = PVSS_TRUE);

  /**
   * Change the names of an existing node.
   *
   * @param node     The node.
   * @param newNames The name and the display names of the node (e.g. northCam).
   * @param wait     A WaitForAnswer object to handle the answer (maybe error!)
   * @param del  The WaitForAnswer object should be deleted by the framework (default)
   *
   * @return PVSS_TRUE if message has been sent.
   */
  virtual PVSSboolean changeNode(const CNSNode &node,
                                 const CNSNodeNames &newNames,
                                 WaitForAnswer *wait = 0,
                                 PVSSboolean del = PVSS_TRUE);

  /**
   * Get the DpIdentifier for a given name.
   * Wildcards are not allowed.
   *
   * @param name The complete path to a node, DPE, config or even an attribute. 
   * @param id   A reference to the DpIdentifier object which gets the answer
   *
   * @return PVSS_TRUE if DpIdentifier was found.
   */
  virtual PVSSboolean getId(const char *name, DpIdentifier &id) const;

  /**
   * Get the data identifier for a given name.
   * Wildcards are not allowed.
   *
   * @param name The complete path to the node.
   * @param id   A reference to the CNSDataIdentifier object which gets the answer
   *
   * @return PVSS_TRUE if conversion was successful.
   */
  virtual PVSSboolean getId(const char *name, CNSDataIdentifier &id) const;

  /**
   * Get a list of data identifiers which names matches the given pattern.
   *
   * Although a CNSDataIdentifier might be found several times, it only appears
   * once in the result set.
   *
   * @param pattern       The name pattern.
   *                      e.q. System1.�berwachungsansicht:*B1*.
   * @param sys           If the pattern contains no system, sys is a preselection
   *                      of the systems that should be searched.
   *                      Note!
   *                      Sys == ALL_SYSTEMS means search through all systems
   * @param view          If the pattern contains no view name this is a preselection of the
   *                      view that should be searched.
   *                      Note!
   *                      view == ALL_VIEWS means search through all views
   * @param mode          If NAME only the name is used for search
   *                      if DISPLAY_NAME   only the display names are used
   *                      (with respect of langIdx)
   *                      if ALL_NAMES the name and the
   *                      display names are used (with respect of langIdx)
   * @param langIdx       If not ALL_LANGUAGES a preselection of the display language.
   * @param type          If not ALL_TYPES only CNSDataIdentifier of the same type are returned.
   * @param idSet         A reference to the CNSDataIdentifierSet which gets the answer
   *                      (may be empty)
   *
   * @return PVSS_TRUE if the pattern was correct.
   */
  virtual PVSSboolean getIdSet(const char *pattern,
                               const SystemNumType &sys,
                               const ViewId &view,
                               SearchMode mode,
                               LanguageIdType langIdx,
                               CNSDataIdentifierType type,
                               CNSDataIdentifierSet &idSet) const;

  /**
   * Get the CNSNode for a given name. Wildcards are not allowed.
   *
   * @param name The complete path to the node.
   * @param node A reference to the CNSNode object which gets the answer
   *
   * @return PVSS_TRUE if conversion was successful.
   */
  virtual PVSSboolean getNode(const char *name,
                              CNSNode &node) const;

  /**
   * Get a list of CNSNodes which names matches the given pattern.
   *
   * @param pattern       The name pattern.
   *                      e.q. System1.�berwachungsansicht:*B1*.
   * @param sys           If the pattern contains no system, sys is a preselection
   *                      of the systems that should be searched.
   *                      Note!
   *                      Sys == ALL_SYSTEMS means search all systems
   * @param view          If the pattern contains no view name this is a preselection of the
   *                      view that should be searched.
   *                      Note!
   *                      view == ALL_VIEWS means search all views
   * @param mode          If NAME only the name is used for search
   *                      if DISPLAY_NAME   only the display names are used
   *                      (with respect of langIdx)
   *                      if ALL_NAMES the name and the
   *                      display names are used (with respect of langIdx)
   * @param langIdx       If not ALL_LANGUAGES a preselection of the display language.
   * @param type          If not ALL_TYPES only CNSDataIdentifier of the same type are returned.
   * @param nodes         A reference to the CNSNodeVector which gets the answer
   *                      (may be empty)
   *
   * @return PVSS_TRUE if the input parameters were correct.
   */
  virtual PVSSboolean getNodes(const char *pattern,
                               const SystemNumType &sys,
                               const ViewId &view,
                               SearchMode mode,
                               LanguageIdType langIdx,
                               CNSDataIdentifierType type,
                               CNSNodeVector &nodes) const;

  /**
   * Invoke the specified visitor for each CNSNode whose path matches the given pattern.
   *
   * @param pattern       The name pattern.
   *                      e.q. System1.�berwachungsansicht:*B1*.
   * @param sys           If the pattern contains no system, sys is a preselection
   *                      of the systems that should be searched.
   *                      Note!
   *                      Sys == ALL_SYSTEMS means search all systems
   * @param view          If the pattern contains no view name this is a preselection of the
   *                      view that should be searched.
   *                      Note!
   *                      view == ALL_VIEWS means search all views
   * @param mode          If NAME only the name is used for search
   *                      if DISPLAY_NAME   only the display names are used
   *                      (with respect of langIdx)
   *                      if ALL_NAMES the name and the
   *                      display names are used (with respect of langIdx)
   * @param langIdx       If not ALL_LANGUAGES a preselection of the display language.
   * @param type          If not ALL_TYPES only CNSDataIdentifier of the same type are returned.
   * @param visitor       An object derived from CNSVisitor. The method visit() of the object
   *                      will be called for each matching node.
   *
   * @return PVSS_TRUE if the input parameters were correct.
   */
  virtual PVSSboolean getNodes(const char *pattern,
                               const SystemNumType &sys,
                               const ViewId &view,
                               SearchMode mode,
                               LanguageIdType langIdx,
                               CNSDataIdentifierType type,
                               CNSVisitor &visitor) const;

  /**
   * Get a list of CNSNodes which contain the given data identifier.
   *
   * @param id Data identifier. Use ALL_TYPES as type of the identifier to search
   *           for the same content regardless of type.
   * @param sys The systems that should be searched.
   *            Use ALL_SYSTEMS to search all systems.
   * @param view The view that should be searched.
   *             Use ALL_VIEWS to search all views.
   * @param nodes A reference to the CNSNodeVector which receives the matching nodes.
   *              (may be empty)
   *
   * @return PVSS_TRUE if the input parameters were correct.
   */
  virtual PVSSboolean getNodes(const CNSDataIdentifier &id,
                               const SystemNumType &sys,
                               const ViewId &view,
                               CNSNodeVector &nodes) const;

  /**
   * Invoke the specified visitor for each CNSNode which contains the given data identifier.
   *
   * @param id Data identifier. Use ALL_TYPES as type of the identifier to search
   *           for the same content regardless of type.
   * @param sys The systems that should be searched.
   *            Use ALL_SYSTEMS to search all systems.
   * @param view The view that should be searched.
   *             Use ALL_VIEWS to search all views.
   * @param visitor An object derived from CNSVisitor. The method visit() of
   *                the object will be called for each matching node.
   */
  virtual PVSSboolean getNodes(const CNSDataIdentifier &id,
                               const SystemNumType &sys,
                               const ViewId &view,
                               CNSVisitor &visitor) const;

  /**
   * Get parent of given node.
   *
   * @param node   The CNSNode for which the parent is asked.
   * @param parent A reference to the CNSNode of the parent.
   *
   * @return PVSS_TRUE if successful.
   */
  virtual PVSSboolean getParent(const CNSNode &node,
                                CNSNode &parent) const;

  /**
   * Get root element of a given node.
   *
   * @param node The datapoint element for which the root element is asked for.
   * @param root A reference to the root node.
   *
   * @return PVSS_TRUE if successful.
   */
  virtual PVSSboolean getRoot(const CNSNode &node,
                              CNSNode &root) const;

  /**
   * Get all children for a given node.
   *
   * If there are no children the result is an empty array.
   *
   * @param node     The node.
   * @param children A reference to the CNSNodeVector which gets the nodes of all children
   *
   * @return PVSS_TRUE if successful.
   */
  virtual PVSSboolean getChildren(const CNSNode &node,
                                  CNSNodeVector &children) const;

private:

// disable warning: 'std::vector<_Ty>' needs to have dll-interface
#ifdef WIN32
#pragma warning ( push )
#pragma warning ( disable: 4251)
#endif

  CNSObserverVector observers;

#ifdef WIN32
#pragma warning ( pop )
#endif

  /**
   * Returns true if at least one observer is registered.
   */
  bool hasObservers() const;

  /**
   * Invokes all registered CNSObserver objects.
   *
   * @param path The path of the element that changed.
   * @param what The type of change.
   * @param msg The msg that triggered the change in CNS.
   */
  void fireCNSObservers(const CharString &path,
                        CNSObserver::CNSChanges what,
                        const DpMsgManipCNS &msg);

  /**
   * A shortcut for Manager::getDpIdentificationPtr().
   */
  static DpIdentification *getDpIdent();

  /**
   * A shortcut for Manager::getCNSContainer()
   */
  static CNSContainer &getCNS();

  /**
   * Creates a new CNS tree out of the given name and data matrices.
   *
   * @param [out] newTree Receives the root node of the tree.
   *                      CNSTreeNode as well as CNSTree can be used here.
   * @param names A matrix representing the node names of a CNS tree.
   * @param data A matrix representing the data identifiers of a CNS tree.
   * @param row The row of the root node in the matrix. Can also be the root
   *            of a subtree or a single node without children.
   * @param depth The column of the root node in the matrix.
   *
   * @return The number of rows / nodes that were handled by the call.
   */
  static CNSNodeNamesMatrix::size_type buildTree(
    CNSTree &newTree,
    const CNSNodeNamesMatrix &names,
    const CNSDataIdentifierMatrix &data,
    CNSNodeNamesMatrix::size_type row = 0,
    CNSNodeNamesMatrix::value_type::size_type depth = 0);

  /**
   * Checks whether the field at the specified position in the given matrices
   * is a valid node.
   *
   * The name and display names of the field must not be empty and
   * the field in the data matrix must at least exist, but it
   * can be empty.
   *
   * @param names A matrix representing the node names of a CNS tree.
   * @param data A matrix representing the data identifiers of a CNS tree.
   * @param row The row of the node in the given matrices.
   * @param depth The column of the node in the given matrices.
   */
  static bool isValidNode(const CNSNodeNamesMatrix &names,
                          const CNSDataIdentifierMatrix &data,
                          CNSNodeNamesMatrix::size_type row,
                          CNSNodeNamesMatrix::value_type::size_type depth);

  /**
   * Checks whether the given vector has its only item at the specified
   * index.
   * Does not test the specified position, but every other position in
   * the vector.
   */
  static bool isOnlyItemInRow(const CNSNodeNamesVector &row,
                              CNSNodeNamesMatrix::size_type itemIndex);

  /**
   * @param sys The number of the system(s) which will be searched.
   *            ALL_SYSTEMS check that at least one systems exists.
   * @param viewId The viewId of the view that will be searched in the
   *               specified system(s).
   *               ALL_VIEWS check that at least one view exists.
   */
  static bool systemAndViewExist(const SystemNumType &sys, const ViewId &viewId);
  
  /**
   * Invokes the given visitor for each node in the specified system(s)
   * and view(s).
   *
   * @param sys The number of the system(s) which will be searched.
   *            Use ALL_SYSTEMS to search all systems.
   * @param viewId The viewId of the view that will be searched in the
   *               specified system(s).
   *               Use ALL_VIEWS to search all views.
   * @param visitor A visitor functor which is called for each node in
   *                the specified system(s) and view(s).
   *
   * @return True if no error occurred and the visitor never returned ABORT.
   */
  static bool forEachNode(const SystemNumType &sys, const ViewId &viewId,
                          CNSTreeVisitor &visitor);

  /**
   * Invokes the given visitor for each node in the specified system(s)
   * and view(s).
   *
   * @param id Data identifier. Use ALL_TYPES as type of the identifier to search
   *           for the same content regardless of type.
   * @param sys The number of the system(s) which will be searched.
   *            Use ALL_SYSTEMS to search all systems.
   * @param viewId The viewId of the view that will be searched in the
   *               specified system(s).
   *               Use ALL_VIEWS to search all views.
   * @param visitor A visitor functor which is called for each node in
   *                the specified system(s) and view(s).
   *
   * @return True if no error occurred and the visitor never returned ABORT.
   */
   static bool forEachNode(const CNSDataIdentifier &id, 
                                    const SystemNumType &sys, 
                                    const ViewId &viewId, 
                                    CNSTreeVisitor &visitor);

  /**
   * Same as above, but if the given pattern contains a view separator,
   * sys and viewId will be set to ALL_SYSTEMS and ALL_VIEWS.
   */
  static bool forEachNode(const char *pattern, 
                          const SystemNumType &sys,
                          const ViewId &viewId,
                          SearchMode whichNames, 
                          CNSTreeVisitor &visitor);

  /**
   * Returns the specified error through a WaitForAnswer-object.
   * The WaitForAnswer receives the error just like an error from
   * the Data Manager.
   *
   * @param wait The WaitForAnswer-object that will receive the error.
   * @param error The error message. The method takes ownership of this pointer,
   *              do not delete it.
   */
  void returnError(WaitForAnswer &wait, ErrClass *error);

};

#endif // _COMMONNAMESERVICE_H_
