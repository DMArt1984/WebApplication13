#ifndef _PENDINGDPHLGROUP_H_
#define _PENDINGDPHLGROUP_H_


#include <DpHLGroup.hxx>

class DoneCB;


/*  author VERANTWORTUNG: Martin Koller*/
/** class holds a DpHLGroup for later use as input to a CtrlThread.
  * Also it holds a pointer to a DoneCB object, which will be called, when this
  * DpHLGroup was used in CtrlThread and the thread was fully executed.           */
class DLLEXP_CTRL PendingDpHLGroup : public DpHLGroup
{
  public:
    /// create a hotlink group
    PendingDpHLGroup(const DpHLGroup &newGroup, DoneCB *done, int items = 1);
    /// 
    ~PendingDpHLGroup();

    AllocatorDecl;
    ///
    DoneCB *getDoneCB() const { return doneCB; }

    int getGroupItems() {return groupItems;}
  protected:

  private:
    DoneCB *doneCB;
    int groupItems;
};

#endif /* _PENDINGDPHLGROUP_H_ */
