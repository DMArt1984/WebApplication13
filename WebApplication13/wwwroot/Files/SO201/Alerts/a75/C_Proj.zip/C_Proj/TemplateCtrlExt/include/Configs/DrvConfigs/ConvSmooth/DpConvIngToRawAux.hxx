// DATEIBESCHREIBUNG ==============================================================
// DATEINAME:     DpConvIngToRawAux.hxx
//
//
// AENDERUNGS-HISTORIE
// Ver.  | Datum      | Aenderungen                            | ModNr.| Autor
// ------+------------+-----------------Anfang-----------------+-------+-----------
//   1.0 |            | 1.Erstellung mit Westmount-OMT         |     0 |
// ======================================Ende======================================
#ifndef _DPCONVINGTORAWAUX_H_
#define _DPCONVINGTORAWAUX_H_

// Vorwaerts-Deklaration der Eigenen Klasse
class DpConvIngToRawAux;

// System-Include-Files
#include <DpConvSmoothContainer.hxx>

// Vorwaerts-Deklarationen :
class DpConfig;

/** Conversion for engineering value to raw (hardware) value, identical to
 *  DpConvIngToRawMain for historical reasons.
 */
class DLLEXP_CONFIGS DpConvIngToRawAux : public DpConvSmoothContainer 
{

  // Klassen-Enums:

// ..........................Anfang User-Klasseninterne-Definitionen..................
// ...........................Ende User-Klasseninterne-Definitionen...................
public:
  /// Default construktor.
  DpConvIngToRawAux();
  /// Destructor.
  ~DpConvIngToRawAux();


  /// Assignment operator.
  DpConvIngToRawAux &operator=(const DpConvIngToRawAux &rVal)
    { DpConvSmoothContainer::operator=((const DpConvSmoothContainer &) rVal); return *this; }

  // Spezielle Methoden :

  /** Check the config type. 
      @return The type if the transformation types are identical, else DPCONFIG_NOCONFIG.
      @classification public use, overload.
  */
  virtual DpConfigType isA(DpConfigType conf) const;
  /** Get the config type.
      @return The transformation type represented by this object.
      @classification public use, overload
  */
  virtual DpConfigNrType getDpConfigNrUncached() const;
  /** Allocate new instance of the class.
      @classification public use, overload
  */
  virtual DpConfig *allocate() const;

  // Generierte Methoden :
protected:
private:

// ............................Anfang User-Attribut-Definitionen...................
public:
  /** Get the config type.
      @return The transformation type represented by this object.
      @classification public use, overload
  */
  virtual DpConfigType isA() const { return DPCONFIG_CONVERSION_ING_TO_RAW_AUX; };
  /// Returns the size of the object.
  virtual unsigned long sizeOf() const;
// .............................Ende User-Attribut-Definitionen....................
};

// ================================================================================
// Inline-Funktionen :

// ............................Anfang User-Inlines.................................
inline unsigned long DpConvIngToRawAux::sizeOf() const
{
  return sizeof(DpConvIngToRawAux);
}
// .............................Ende User-Inlines..................................

#endif /* _DPCONVINGTORAWAUX_H_ */
