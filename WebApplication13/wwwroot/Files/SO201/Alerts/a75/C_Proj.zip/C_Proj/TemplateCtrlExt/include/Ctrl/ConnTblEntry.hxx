#ifndef _CONNTBLENTRY_H_
#define _CONNTBLENTRY_H_

#include <Types.hxx>
#include <PtrList.hxx>
#include <PtrListItem.hxx>
#include <DpIdentList.hxx>
#include <PendingDpHLGroup.hxx>
#include <PendingAlertAttrList.hxx>
#include <PendingParams.hxx>
#include <TimeoutTimer.hxx>
#include <WaitDpVC.hxx>
#include <CharString.hxx>

class CtrlFunc;
class WaitForAnswer;
class ClassVar;

/*  author VERANTWORTUNG: Martin Koller */
/** Holds the signature of a Dp-CtrlFunction connection
  * and eventually pending DpHLGroups/pending AlertAttrList
  @classification ETM internal
  */
class DLLEXP_CTRL ConnTblEntry : public PtrListItem
{
  public:
    ///
    enum EntryType
    {
      /// Warte auf einen Hotlink
      DP_CONN,
      /// Warte auf einen Alarm
      ALERT_CONN,
      /// Warte auf das Ergebnis eines Queries
      QUERY_CONN,
      /// Warte auf eine Wertaenderung
      WAIT_CONN,
      /// Warte auf eine Funktion (event sink from activeX)
      WAIT_FUNC,
      /// a system event connection
      SYS_CONN
    };

    // Constructor for dpConnect, alertConnect
    ConnTblEntry(CtrlFunc *theFunc, const Variable *userData, const DpIdentList &theList, ConnTblEntry::EntryType eType);

    // Constructor for dpQueryConnect
    ConnTblEntry(CtrlFunc *theFunc, const Variable *userData, PVSSshort delay = -1);

    // Constructor for WaitForDpValue
    ConnTblEntry(WaitDpVC *theWDpVC, const DpIdentList &theList);

    // Constructor for wait for function
    ConnTblEntry(CtrlFunc *theFunc);

    // Constructor for system events connections (e.g. exitRequested, SysMsg, ...)
    ConnTblEntry(CtrlFunc *theFunc, const Variable *userData, const CharString &eventName);

    /// Destructor
    ~ConnTblEntry();

    void setClassScopeInstance(ClassVar *instance) { classScopeInstance = instance; }
    ClassVar *getClassScopeInstance() const { return classScopeInstance; }

    /** @name Get/Set Member Variables */
    //@{

    /** @return Dp List */
    const DpIdentList &getDpList() const { return list; }

    /** @return NULL | CtrlFunc die aufgerufen wird. */
    CtrlFunc *getFunc() const { return func; }

    /** @return NULL | Wait Object */
    WaitDpVC *getWaitDpVC() const { return wDpVC; }

    /** Set the wait condition */
    void setWaitDpVC(WaitDpVC *w) { wDpVC = w; }

    EntryType getType() const { return type; }

    /** @see setValid
      * @return false Connection is no longer valid and can be deleted
      */
    bool isValid() const { return valid; }

    /** @param isValid false: Der Entry kann nicht entfernt werden, weil gerade
      *                       noch ein Thread aktiv ist. Wenn der Thread beendet
      *                       wird muss jedoch auch der Entry entfernt werden. */
    void setValid(bool isValid) { valid = isValid; }

    /** @return true: Es wird gerade ein Thread exekutiert,
      * der fuer diesen ConnTblEntry gestartet wurde */
    bool isBusy() const { return busy; }

    /** @param isBusy true : fuer diesen Entry wird gerade ein Thread gestartet
      *               false: der Thread fuer diesen Entry wird gerade beendet */
    void setBusy(bool isBusy) { busy = isBusy; }

    WaitForAnswer *getWaitForAnswer() { return wDpVC ? wDpVC->getWaitForAnswer() : 0; }

    /// Get the user data of this connect
    const Variable *getUserData() const { return userData; }

    /// Get Query-Nummer (Query-Nummer wird vom EV vergeben)
    PVSSulong getQueryNum() const {return queryNum;}

    /// Verbinde Query mit der vom EV vergebenen Query-Nummer
    void setQueryNum(PVSSulong num) {queryNum = num;}

    //@}

    /** @name methods for pending HotLinks DpHLGroup. */

    //@{
    /// PendingDpHLGruppe einfuegen
    void appendPendingDpHLGroup(const DpHLGroup &newGroup, DoneCB *done, int items);

    /// Gruppe einfuegen
    void appendDpHLGroup(const DpHLGroup &newGroup, DoneCB *done);

    ///
    PendingDpHLGroup *cutFirstDpHLGroup();
    //@}

    /** @name methods for pending AlertAttrList. */
    //@{
    void appendAlertAttrList(const AlertAttrList &newList, DoneCB *done);

    PendingAlertAttrList *cutFirstAlertAttrList();

    bool hasPendingValues() const
      { return (pendings.getNumberOfItems() != 0); }

    int getNumberOfItems() const
      { return numberOfPendingItems; }
    //@}


    /// Function parameters einfuegen
    void appendParams(const Variable *newArgs);

    PendingParams *cutFirstParams();

    void discardPendings(const CharString &location);
    bool pendingsDiscarded() const { return pendingsDiscardedFlag; }
    void clearPendingsDiscardedFlag() { pendingsDiscardedFlag = false; }

    void prepareDpHLGroup(const DpHLGroup &newGroup, DoneCB *done);

    bool isValidForQuery();

    PVSSshort getQueryHLBlockedTime() { return queryHLBlockedTime; }

    void flushGroup();

    SystemNumType getGroupSystem(const DpHLGroup &group);

    const TimeVar & getNextWorkTime() const
    {
      if (busy)                                  // busy, Thread kuemmert sich um nextTime
        return TimeVar::MaxTimeVar;
      else if (internGroupValid)                 // blocked for query blocked time
        return syncTime.getEndTime();
      else if (pendings.getNumberOfItems() > 0)  // pending, aber keine Threads: bald weitermachen
        return TimeVar::NullTimeVar;
      else                                       // Nothing to do
        return TimeVar::MaxTimeVar;
    }

    bool sendDisconnect();

    const CharString &getEventName() const { return eventName; }

  private:
    EntryType type;
    ClassVar *classScopeInstance;
    CtrlFunc *func;
    WaitDpVC *wDpVC;
    PtrList pendings;    // holds pending values for serial execution of one connection
    int numberOfPendingItems;
    bool valid;   // is this entry still valid
    bool busy;    // is this connection currently in use by a thread
    bool pendingsDiscardedFlag;    // were pending values deleted
    DpIdentList list;
    const Variable *userData; // given to a connect, then handed as parameter in the call back
    PVSSulong queryNum;    // dpQuery handle returned by EV man
    CharString eventName;

    PtrList dpHLGroupPtrList;
    mutable TimeoutTimer syncTime;
    DoneCB *doneCB;
    bool internGroupValid;
    PVSSshort queryHLBlockedTime;
    int groupItems;
};

#endif /* _CONNTBLENTRY_H_ */
