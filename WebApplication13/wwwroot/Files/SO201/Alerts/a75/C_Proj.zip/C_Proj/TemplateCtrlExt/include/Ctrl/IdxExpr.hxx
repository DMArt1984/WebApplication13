#ifndef _IDXEXPR_H_
#define _IDXEXPR_H_

#include <CtrlExpr.hxx>


/*  author VERANTWORTUNG: Martin Koller                                    */
/** Indexed expression, e.g. i[5] (index starts with 1 at dyn_* types !!!)
    @classification ETM internal
 */
class DLLEXP_CTRL IdxExpr : public CtrlExpr
{
  public:
    /// Returns the type of the Expression
    virtual ExprType isA() const { return IDX_EXPR; }

    /// constructor
    IdxExpr(CtrlExpr *exp, CtrlExpr *idx, int line, int file);

    /// destructor
    ~IdxExpr();

    /// returns the Result of the expr 
    virtual const Variable *evaluate(CtrlThread *thread) const;

    virtual const CtrlExpr *getFirstExpr(CtrlThread *thread) const;

    /** return a pointer to the target for assignment. 
      * If index is out of bounds, make array larger to
      * hold index elements
      */
    Variable *getTarget(CtrlThread *thread) const;

    /// Return a pointer to the target, but ignore const
    Variable * getTargetNoConst(CtrlThread *thread) const;

    virtual void writeTrace(CtrlThread *thread, bool writeValue = true) const;

    virtual bool checkIntegrity(const CharString &location, CtrlThread *) const;

    virtual CharString toString() const;

  private:
    Variable * getTargetImpl(Variable *target, CtrlThread *thread) const;

    CtrlExpr *expr;
    CtrlExpr *index;
};

#endif /* _IDXEXPR_H_ */
