#ifndef _ERRHDL_H_
#define _ERRHDL_H_

// AUTHOR: Martin Koller

#ifndef _TYPES_HXX_
#include <Types.hxx>
#endif

#ifndef _ERRCLASS_H_
#include <ErrClass.hxx>
#endif

class ExternErrHdl;

/** The general error handler class. This class represents an error handler used by each manager.
    Depending on the -log flags given on manager startup, the error messages are either written
    into the PVSS_II.log file and/or to stderr

    <p>
    Different elements of an ErrClass can be represented in the error text when it is
    created, whereby some substitutions are made:
    <ul>
    <li> $DP     ... replaced with given DpIdentifier </li>
    <li> $MAN    ... replaced with given ManagerIdentifier </li>
    <li> $USER   ... replaced with given userId </li>
    <li> $1 - $9 ... replaced with the given notes </li>
    </ul>
    </p>

    <p>
    If the ErrHdl finds a shared library/dll with the name
    "ExternErrHdl" with one of the extensions ".so" or ".dll" or
    "libExternErrHdl" with one of the extensions ".so" or ".dll"
    (.dll only on Windows, .so only on non-Windows platform)
    in a projects bin dir, it will load it on startup, call
    extern "C" { ExternErrHdl *createExternErrHdl(); }
    to create an ExternErrHdl subclass instance, and call its
    handleError(const ErrClass &errorClass) method
    before it writes to the targets specified by -log
    </p>

    See also: \Ref{ExternErrHdl} in ExternErrHdl.hxx

    @classification CoreTest
*/
class DLLEXP_BASICS ErrHdl
{
  friend class UNIT_TEST_FRIEND_CLASS;    // ein Unit-Test braucht erweiterten zugriff auf diese Klasse
  public:
    /** Constructor - obsolete; no instance of this object is needed.
    */
    ErrHdl() {};

    /** The main init function. Loads external error handler, loads errors.cat.
        It is safe to call this method more than once.
    */
    static void init();

    /** throw an error message with explicit given ErrClass object.
        @param errorClass ErrClass instance with error description.
    */
    static void error(const ErrClass &errorClass);

    /** construct and throw an error message with argument substitution
        Use this
        1) if you want to place your error message texts into a special message catalog and/or
        2) if you want to easily pass arguments to the message text
        @param prio  The severity of the error (information only, severe error, ...)
        @param type  The error type (parameterization, implementation, ...)
        @param catalog The message catalog filename (without the .cat extension) located
          in one of the project_path/msg/language directories.
          If this is an empty string or a 0-pointer, the PVSS standard catalog errors.cat is used.
          Messages in this catalog to be used as ErrHdl texts must have as keyword
          the error-number formatted in 5 digits with leading zeros (e.g. "00012")
        @param code  The error number (== line number in message catalog file)
        @param note1 An additional note (can be used as $1).
        @param note2 An additional note (can be used as $2).
        @param note3 An additional note (can be used as $3).
        @param note4 An additional note (can be used as $4).
        @param note5 An additional note (can be used as $5).
        @param note6 An additional note (can be used as $6).
        @param note7 An additional note (can be used as $7). 
        @param note8 An additional note (can be used as $8).
        @param note9 An additional note (can be used as $9).

        You can pass up to 9 notes.
        The arguments are then used to replace the argument-placeholders given in the
        error-message text from the catalog, whereby $1 is replaced with the first note,
        $2 with the second, and so on.

        All arguments, which are not used for $-substitution, will also be printed when writing
        an ErrClass onto the error stream.
        error(ErrClass::PRIO_WARNING, ErrClass::ERR_IMPL, 0, 123, "first note", "second note");
    */
    static void error(ErrClass::ErrPrio prio, ErrClass::ErrType type,
                      const char *catalog, ErrClass::ErrCode code,
                      const char *note1 = 0, const char *note2 = 0, const char *note3 = 0,
                      const char *note4 = 0, const char *note5 = 0, const char *note6 = 0,
                      const char *note7 = 0, const char *note8 = 0, const char *note9 = 0);

    /** Use if you have a DpIdentifier for $DP.
        @param prio  The severity of the error (information only, severe error, ...).
        @param type  The error type (parameterization, implementation, ...).
        @param catalog The message catalog filename (without the .cat extension).
        @param code  The error number (== line number in message catalog file).
        @param dpId  The datapoint related to the error (can be used as $DP).
        @param note1  An additional note (can be used as $1).
        @param note2  An additional note (can be used as $2).
        @param note3  An additional note (can be used as $3).
    */
    static void error(ErrClass::ErrPrio prio, ErrClass::ErrType type,
                      const char *catalog, ErrClass::ErrCode code,
                      const DpIdentifier & dpId,
                      const char *note1 = 0, const char *note2 = 0,  const char *note3 = 0);

    /** Construct and throw an error message.
        @param bits Indicates whether dpId, manId and usrId are set.
        @param prio  The severity of the error (information only, severe error, ...).
        @param typ  The error type (parameterization, implementation, ...).
        @param code  The error number (== line number in message catalog file).
        @param dpId  The datapoint related to the error (can be used as $DP).
        @param manId  Our own manager identifier. Get it with Manager::getMyManagerId() (can be used as $MAN).
        @param usrId  Our own user id. Get it with Manager::getUserId() (can be used as $USER).
        @param note1  An additional note (can be used as $1).
        @param note2  An additional note (can be used as $2).
        @param note3  An additional note (can be used as $3).       
    */
    static void error(PVSSulong bits, ErrClass::ErrPrio prio, ErrClass::ErrType typ,
                      ErrClass::ErrCode code, const DpIdentifier &dpId,
                      const ManagerIdentifier& manId, PVSSushort usrId,
                      const char* note1 = 0, const char* note2 = 0, const char* note3 = 0);

    /** Construct and throw an error message.
        Use this function to report an error caused by the implementation of the manager.
        You may report all other types of errors, to.
        @param prio  The severity of the error (information only, severe error, ...).
        @param type  The error type (parameterization, implementation, ...).
        @param code  The error number (unexpected state, ...).
        @param note1  An additional note (can be used as $1).
        @param note2  An additional note (can be used as $2).
        @param note3  An additional note (can be used as $3).
   */
    static void error(ErrClass::ErrPrio prio, ErrClass::ErrType type, ErrClass::ErrCode code,
                      const char* note1 = 0, const char* note2 = 0, const char *note3 = 0);

    /** construct and throw an error message (parameterization).
        Use this constructor to report an error caused by the parameterization.
        @param prio  The severity of the error (information only, severe error, ...).
        @param typ  The error type (parameterization, implementation, ...).
        @param code  The error number (unexpected state, ...).
        @param dpId  The datapoint related to the error (can be used as $DP)
        @param manId Our own manager identifier. Get it with Manager::getMyManagerId() (can be used as $MAN)
        @param usrId Our own user id. Get it with Manager::getUserId() (can be used as $USER)
        @param note1  An additional note (can be used as $1)
        @param note2  An additional note (can be used as $2)
        @param note3  An additional note (can be used as $3)
   */
    static void error(ErrClass::ErrPrio prio, ErrClass::ErrType typ, ErrClass::ErrCode code,
                      const DpIdentifier &dpId, const ManagerIdentifier &manId, PVSSushort usrId,
                      const char* note1 = 0, const char* note2 = 0, const char* note3 = 0);

    /** Get the exit flag.
        @return PVSS_TRUE, if the exit flag was set.
   */
    static PVSSboolean getExitFlag() { return exitFlag; }

    /** Set the exit flag to PVSS_TRUE.
   */
    static void setExitFlag()        { exitFlag = PVSS_TRUE; }

    /** Set the function to be called whenever a FATAL error is thrown.
        @param fct Exit function.
    */
    static void setExitFct(void (*fct)(int exitCode)) { exitFunc = fct; }

    /** Set an error handler used inside the CTRL interpreter; it is called
        in addition to the normal error handling whenever a non ERR_CONTROL
        ErrClass is thrown (e.g. in Variable::operator=()).
        @param hdl Pointer to the ExternErrHdl class.
        @return returns the previously installed handler
        @internal use only
    */
    static ExternErrHdl *setCtrlErrHdl(ExternErrHdl *hdl);

    /** Returns the ErrClass of the last error that occurred.
        @param cnt Shows how often the last error consecutively occurred.
        @internal use only
    */
    static const ErrClass &getLastError(unsigned long &cnt);

  private:
    /** This method is called on FATAL errors and terminates the program
        @param exitCode
    */
    static void exit(int exitCode);

    static void (*exitFunc)(int exitCode);  // pointer to exit function
    static PVSSboolean exitFlag;

    static void outputError(const ErrClass &error);

    static ExternErrHdl *ctrlErrHdl;
    static ErrClass      last;
    static unsigned long lastErrCount;
};

#endif /* _ERRHDL_H_ */
