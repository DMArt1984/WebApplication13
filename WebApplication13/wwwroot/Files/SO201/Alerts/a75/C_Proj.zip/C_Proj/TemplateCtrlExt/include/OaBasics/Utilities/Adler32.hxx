#ifndef  ADLER32_H
#define  ADLER32_H

/**
 * A cumulative implementation of the Adler32 checksum algorithm.
 */
class DLLEXP_OABASICS Adler32
{
  public:
    /**
     * Constructs a new Adler32 object. It has an initial value of 1.
     *
     * @return Adler32
     */
    Adler32() {init();}

  public:
    /**
     * Initialize or reset the checksum to the value 1.
     */
    void  init() {value = 1;}

    /**
     * Updates the current checksum value with the specified data.
     *
     * @param buffer The data from which the checksum is computed and
     * integrated into the current value. Nullpointers will be ignored.
     * @param len The number of bytes to read from @p buffer.
     */
    void  update(const char *buffer, unsigned len);

    /**
     * Returns the current checksum value.
     *
     * @return The current value of the cumulative checksum
     */
    unsigned getValue() {return value;}

  private:

    /// The value member
    unsigned value;
};

#endif
