#ifndef _ALIASTABLEITEM_H_
#define _ALIASTABLEITEM_H_

/*
VERANTWORTUNG: Robert Trausmuth      
BESCHREIBUNG:  includes items required for Datapoint aliasing
i.e. DpIdentifier pt, LangText alias, LangText comment

pt and alias must be 1<->1 and cannot be duplicated
comment is optional
a comment without defined alias is possible

all items must be dynamically generated and then given to this class
the destructor is responsible for freeing them  
 */

#include <ostream>
#include <DpIdentifier.hxx>
#include <LangText.hxx>
#include <Resources.hxx>

class AliasTable;
class AliasTableItem;

DLLEXP_DATAPOINT int compareDp(const AliasTableItem *t1, const AliasTableItem *t2); 
DLLEXP_DATAPOINT int compareAliasActLang(const AliasTableItem *t1, const AliasTableItem *t2); 
DLLEXP_DATAPOINT int compareAliasParamLang(const AliasTableItem *t1, const AliasTableItem *t2); 

/// This class holds the alias and comment for a specific datapoint identifier.
class DLLEXP_DATAPOINT AliasTableItem
{
  public:

    /// copy constructor
    /// @param x Instance to be copied to this
    AliasTableItem(const AliasTableItem &x) {*this = x;}
        
    /// assignment operator
    /// @param x Instance to be assigned
    /// @return Reference to this
    AliasTableItem &operator=(const AliasTableItem &x);

    /// default constructor
    AliasTableItem() : dpId(0), elId(0), dpAlias(0), dpComment(0) {};

    /// constructor
    /// @param dp DpIdentifier
    /// @param alias Alias for the DpIdentifier
    /// @param comment Comment for the DpIdentifier
    AliasTableItem(const DpIdentifier &dp, const LangText *alias = 0, const LangText *comment = 0);

    /// destructor
    ~AliasTableItem();

    /// equal-to operator
    /// @param x Instance to be compared with this
    /// @return PVSS_TRUE if all members of both instances are equal, PVSS_FALSE otherwise
    int operator==(const AliasTableItem &x);    // x is ident in every item

    /// non-equal-to operator
    /// @param x Instance to be compared with this
    /// @return PVSS_FALSE if all members of both instances are equal, PVSS_TRUE otherwise
    int operator!=(const AliasTableItem &x);    // x is different in dpid and alias

    /// Gets the DpIdentifier of this item
    /// @param[out] id variable that will receive the DpIdentifier settings
    /// the dpId and elId members.
    void getId(DpIdentifier &id) const { id.setDp(dpId); id.setEl(elId); }

    /// Get the alias in the specified language
    /// @param lang_ Language Id
    /// @return CharString with the alias
    CharString getAlias(LanguageIdType lang_ = Resources::getParamLang()) const; 

    /// Get the comment in the specified language
    /// @param lang_ Language Id
    /// @return CharString with the comment
    CharString getComment(LanguageIdType lang_ = Resources::getParamLang()) const;

    /// Get the alias in the specified language
    /// @param lang_ Language Id
    /// @return const char* pointing to the alias string
    const char *getAliasStr(LanguageIdType lang_ = Resources::getParamLang()) const; 

    /// Set the alias string
    /// @param text LangText with the alias in all languages
    /// @return zero integer
    int setAlias(const LangText &text);            
    
    /// Set the comment string
    /// @param text LangText with the comment in all languages    
    int setComment(const LangText &text);          

    /// Set the DpIdentifier
    /// @param id DpIdentifier to be set to this
    void setId(const DpIdentifier &id);

    /// Get the DpIdType
    /// @return dpId member
    DpIdType getDpId() const     {return dpId;};

    /// Get the DpElementId
    /// @return elId member
    DpElementId getElId() const  {return elId;};
    
    /// Get the pointer to the alias pointer array
    /// @return dpAlias member
    const char * const *getAliasPtr() const   {return dpAlias;}

    /// Get the pointer to the comment pointer array
    /// @return dpComment member
    const char * const *getCommentPtr() const {return dpComment;}

    /// Change the alias for the specified language
    /// @param text New alias string
    /// @param lang Language Id
    /// @return zero value
    int changeAlias(const CharString &text, LanguageIdType lang = Resources::getParamLang());

    /// Change the comment for the specified language
    /// @param text New comment string
    /// @param lang Language Id
    /// @return zero value
    int changeComment(const CharString &text, LanguageIdType lang = Resources::getParamLang());

    /// Outputs the instance to the std::ostream
    /// @param to Output stream
    /// @param item Streamed AliasTableItem instance
    /// @return std::ostream stream
    friend DLLEXP_DATAPOINT std::ostream &operator<<(std::ostream &to, const AliasTableItem &item);

    /// Receives the instance from the itcNdrUbReceive stream
    /// @param from Input stream
    /// @param item AliasTableItem instance receiving the value from the stream
    /// @return itcNdrUbReceive stream
    friend DLLEXP_DATAPOINT itcNdrUbReceive &operator>>(itcNdrUbReceive &from, AliasTableItem &item);

    /// Outputs the instance to the itcNdrUbSend stream
    /// @param to Output stream
    /// @param item Streamed AliasTableItem instance
    /// @return itcNdrUbSend stream
    friend DLLEXP_DATAPOINT itcNdrUbSend &operator<<(itcNdrUbSend &to, const AliasTableItem &item);

    // these functions should not be used outside the AliasTable class!
    /// deletes the dpAlias and dpComment arrays
    void clear(); 

    /// Set the DpIdentifier
    /// @param x DpIdType to be set to the dpId member
    /// @param y DpElementId to be set to the elId member
    void setDp(const DpIdType x, const DpElementId y) {dpId = x; elId = y;}

    /// returns the sum of string sizes of the alias strings in all languages
    /// @return total string size
    unsigned  strsizeAlias() const;

    /// returns the sum of string sizes of the comment strings in all languages
    /// @return total string size
    unsigned  strsizeComment() const;

    /// comparing DpIdentifier of the two AliasTableItem instances
    /// @param t1 first AliasTableItem
    /// @param t2 second AliasTableItem
    /// @return t1->elId - t2->elId if dpIds are equal, otherwise t1->dpId - t2->dpId
    friend DLLEXP_DATAPOINT int compareDp(const AliasTableItem *t1, const AliasTableItem *t2); 

    /// comparing aliases in actual language of the two AliasTableItem instances
    /// @param t1 first AliasTableItem
    /// @param t2 second AliasTableItem
    /// @return strcmp() of the two aliases in the Resources::getActiveLang() language
    friend DLLEXP_DATAPOINT int compareAliasActLang(const AliasTableItem *t1, const AliasTableItem *t2); 

    /// comparing aliases in param language of the two AliasTableItem instances
    /// @param t1 first AliasTableItem
    /// @param t2 second AliasTableItem
    /// @return strcmp() of the two aliases in the Resources::getParamLang() language
    friend DLLEXP_DATAPOINT int compareAliasParamLang(const AliasTableItem *t1, const AliasTableItem *t2); 

  private:

    /// this two members specify the DpIdentifier
    DpIdType dpId;
    DpElementId elId;

    /// array of strings storing aliases in all defined languages
    char **dpAlias;

    /// array of strings storing comments in all defined languages
    char **dpComment;
};

#endif /* _ALIASTABLEITEM_H_ */
