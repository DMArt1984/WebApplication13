#ifndef _PRECISETIME_H_
#define _PRECISETIME_H_

#include <time.h>
#include <PVSSTime.hxx>

#ifndef _TYPES_HXX_
#include <Types.hxx>
#endif

#include <iostream>

/// This class is used to handle a time with microseconds resolution.
/// It is represented as two integers:
/// - Seconds (since 1.1.1970)
/// - Microseconds (0..999999)
class DLLEXP_BASICS PreciseTime
{
  public:

    /// Default constructor. Initializes with 0-time
    PreciseTime() : time_(0), micro_(0) {}

    /// Constructor. Initializes with given time (seconds/microseconds).
    /// @param newTime Seconds value.
    /// @param newMicro Microseconds value (can be 0..999999).
    PreciseTime(time_t newTime, PVSSlong newMicro = 0);

    /// Init with the current system time.
    PreciseTime &setCurrentTime();

    /// Gets the current system time in seconds and microseconds.
    /// @param sec Reference to a variable where seconds will be returned.
    /// @param usec Reference to a variable where microseconds will be returned.
    static void getPreciseTime(PVSSlong &sec, PVSSlong &usec);

#if defined (__amd64__) || defined (_WIN32) || defined (OS_LINUX) ||\
    defined (OS_SOLARIS) || defined(__APPLE__) || defined(__EMSCRIPTEN__)
    /// Gets the current system time in seconds and microseconds.
    /// @param sec Reference to a variable where seconds will be returned.
    /// @param usec Reference to a variable where microseconds will be returned.
    static void getPreciseTime(time_t &sec, PVSSlong &usec);
#endif

    /// Writes the instance to the output stream formatted in a human readable form.
    /// @param @ofStream Output stream.
    /// @param sec Seconds.
    /// @param usec Microseconds.
    static void outToFile(std::ostream &ofStream, PVSSlong sec, PVSSlong usec);

    /// Addition operator.
    /// @param rVal PreciseTime value to be added to this.
    /// @return PreciseTime with the sum of two times.
    PreciseTime operator+(const PreciseTime &rVal) const;

    /// Subtraction operator.
    /// @param rVal PreciseTime to subtract from this.
    /// @return PreciseTime with the subtracted value.
    PreciseTime operator-(const PreciseTime &rVal) const;

    /// Operator Less-than.
    /// @param rVal Compared value.
    /// @return true if *this value is less than rVal, false otherwise.
    bool operator<(const PreciseTime &rVal) const;

    /// Get the seconds part of the time.
    time_t getSeconds() const { return time_; }

    /// Get the microseconds part of the time.
    PVSSlong getMicro() const   { return micro_; }

    /// Set the seconds part of the time and leave the milliseconds unchanged.
    void setSeconds(time_t ti) { time_ = ti; }

    /// Set the microseconds part of the time.
    void setMicro(PVSSlong newMicro);

    /// Get the time as the double variable (microseconds are in the decimal fraction)
    PVSSdouble getDouble() const
    {
      return static_cast<PVSSdouble>(time_) + (micro_ / 1000000.0);
    }

    /// Cast to the less accurate PVSSTime (milliseconds resolution).
    operator PVSSTime() const { return PVSSTime(time_, micro_ / 1000); }

  private:

    /// Seconds since 1.1.1970
    time_t   time_;

    /// Microseconds
    PVSSlong micro_;

  private:
    friend class UNIT_TEST_FRIEND_CLASS;
    
    /// Hook method can be attached here which will return the current time.
    static void (*getTimeOfDayHook)(struct timeval *);
};

#endif /* _PRECISETIME_H_ */
