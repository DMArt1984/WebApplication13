#ifndef _SIMPLEACCU_H_ 
#define _SIMPLEACCU_H_

#ifndef _VARIABLE_H_
#include <Variable.hxx>
#endif

#ifndef _TIMEVAR_H_
#include <TimeVar.hxx>
#endif

// ========== SimpleAccu ============================================================

/** the simple accumulator class
    @n This class serves as common interface definition for all statistic accumulators.
    @classification ETM internal
*/
class DLLEXP_OABASICS SimpleAccu
{
  public:
    /// constructor
    SimpleAccu() : validFlag(PVSS_FALSE) {}

    /// virtual destructor
    virtual ~SimpleAccu() {}
    
    /// process a new value
    /// @n Implement this in derivate classes.
    /// @param theValue the value to process
    /// @param atTime the time of the processing
    virtual void accumulate( const Variable &theValue,
                             const TimeVar &atTime ) = 0;

    /// ignore value for a given time
    /// @n Implement this in derivate classes.
    /// @param theValue the value to ignore
    /// @param atTime the time of the processing
    virtual void accumulateInvalid( const Variable &theValue,
                                    const TimeVar &atTime );

    /// get result
    /// @n Implement this in derivate classes.
    /// @return the result
    virtual const Variable &getResult() = 0;

    /// get intermediate result
    /// @n Implement this in derivate classes.
    /// @param theValue the value to process
    /// @param start the start time of the processing
    /// @param stop the stop time of the processing
    /// @param valid the validity flag
    /// @return the intermediate result
    virtual const Variable &getIntermResult( const Variable &theValue, const TimeVar &start, const TimeVar &stop, bool valid );
    
    /// return validity flag
    PVSSboolean isValid() const{ return validFlag; }

    /// reset time of the period
    /// @n Implement this in derivate classes.
    /// @param periodTime the time of the period to set
    virtual void resetPeriodTime(const TimeVar * const periodTime);
    
  protected:
  
    /// validity flag
    PVSSboolean validFlag;
  
  private:
		// this method was public in former ages; now should not be
		// called any more WOKL 22.9.2000 TI 6461
		// but replaced by ::resetPeriodTime, except in the elder subclasses
    virtual void reset() = 0;		
};



inline void SimpleAccu::resetPeriodTime( const TimeVar * const /* periodTime */ )
{
	reset();
}

inline void SimpleAccu::accumulateInvalid( const Variable & /* theValue */, const TimeVar & /* atTime */ )
{
  // intentionally left empty!
}

inline const Variable &SimpleAccu::getIntermResult(  const Variable &/*theValue*/, const TimeVar &/*start*/, 
                                                     const TimeVar &/*stop*/, bool /*valid*/ )
{
	return getResult();
}

#endif
