#ifndef _CTRLTHREAD_H_
#define _CTRLTHREAD_H_

#include <Types.hxx>
#include <ExecReturn.hxx>
#include <DynVar.hxx>
#include <ErrorVar.hxx>
#include <PreciseTime.hxx>
#include <CtrlSment.hxx>

typedef PVSSlong ThreadId;

class CtrlFunc;
class FCall;
class TimeVar;
class RecVar;
class CharString;
class CtrlScript;
class WaitCond;
class DpHLGroup;
class ConnTblEntry;
class DoneCB;
class CtrlVar;
class CtrlExpr;
class StackItem;
class CtrlClass;
class ClassVar;
class CtrlVarList;

/* author: Martin Koller, Mark Probst, Christoph Theis */

/** CTRL interpreter thread with data segment for a running function.
*/

/*  The pointer to a statement may not modify a statement, as the code
  * is used by multiple threads.

  * the object maintains a stack at runtime which is used to
  * maintain local variables and to execute loops. Execution proceeds as
  * follows:
  *
  * if nextSment is nonnull, execute it and get the result. if the result
  * is nonnull, execute it etc.
  * if the result is null, look at the top of the stack. if the stack
  * contains a loop, get the nextIterationStatement from it. if it
  * is nonnull, execute it. otherwise, the loop has finished and is popped
  * off the stack. if the loop's next statement is nonnull, execute it.
  * otherwise, examine the stack top, as above.
  * if the top of the stack is not a loop but a list, let it clean up
  * its local variables and pop it off. execute the list's next statement
  * or, if it is null, proceed with the examination of the stack top, as
  * above.
  * if the top of the stack is neither a list nor a loop, simply pop it
  * off, get its next statement, execute it if nonnull, or examine the
  * the stack top, as above.
  *
  * furthermore, each stack item contains a pointer to a CtrlVarList,
  * which is nonnull only if the corresponding statement is an FCall, in
  * which case the CtrlVarList contains the local variables of the
  * calling function.
  *
  * to make the concept work, lists and loop have to cooperate. each time
  * they are execute, they push pointers to themselves onto the stack.
  */
class DLLEXP_CTRL CtrlThread
{
  /// @internal
  friend class Controller;

  public:
    /// constructor
    CtrlThread(const CtrlFunc *func, CtrlScript *sc, ConnTblEntry *entry = 0, DoneCB *done = 0, const Variable *args = 0);

    /// @internal to start an init statement after parsing
    CtrlThread(const CtrlSment *next, const CtrlFunc *func, CtrlScript *sc);

    /// destructor
    ~CtrlThread();

    /// @internal
    //@{
    CtrlThread *getNext() const { return next; }
    CtrlThread *getPrev() const { return prev; }

    void setNext(CtrlThread *theNext) { next = theNext; }
    void setPrev(CtrlThread *thePrev) { prev = thePrev; }

    const CtrlSment *getNextSment() const { return nextSment; }

    /// when shall we call work() again
    const TimeVar &nextWork() const;
    //@}

    /** @return EXEC_DONE if last sment was executed, else return EXEC_OK */
    ExecReturn work(PVSSlong maxWeight);

    /** set the return value of the currently executed function call
     * @param value Result value of function call
     */
    void setFuncCallReturn(const Variable &var);

    /// @internal
    //@{
    /** Add a new local variable to the block.
        Variables are added in front of the actual locals, so we find the new one
        first. The variable is copied and initialized.
      */
    void addLocal(const CtrlVar &newVar);

    // obsolete. use getCtrlVar()
    Variable *getLocal(const CharString &which, PVSSboolean throwError = PVSS_TRUE) const;

    /** get CtrlVar named "which".
      * returns a pointer to the named var or 0 if it does not exist
      * vars are searched from the beginning to the end in the actual locals
      * so that later added locals will be found first.
      * The variable will also be searched in differnt scopes (local, script-global, scope-lib, manager-global)
      */
    CtrlVar *getCtrlVar(const CharString &which, PVSSboolean throwError = PVSS_TRUE) const;

    CtrlVar *getCtrlVar(uintptr_t id, PVSSboolean throwError = PVSS_TRUE) const;

    /** Find the value of a previous execute for the specified CtrlExpr
      */
    const Variable *loadArgValue(const CtrlExpr *expr, bool throwError = true) const;

    /** Cuts the value of a previous execute for the specified CtrlExpr
      */
    Variable *cutArgValue(const CtrlExpr *expr) const;

    /** Get the CtrlVar that stores a previous execute for the specified CtrlExpr
      */
    CtrlVar *getArgCtrlVar(const CtrlExpr *expr) const;

    /** Store the value of a execute of the specified CtrlExpr for a later evaluate
      */
    void storeArgValue(const Variable &var, const CtrlExpr *expr);
    void storeArgValue(Variable *var, const CtrlExpr *expr);
    void storeArgValue(CtrlVar *ctrlVar, const CtrlExpr *expr);

    // same as above but stores for the currentSment when it's an FCall
    void storeArgValue(Variable *var);

    /// Get the va_list argument of the current function
    const RecVar *getVarArg() const;

    /// Get the local variables (list)
    CtrlVarList *getLocals() const { return locals; }
    //@}

    /// Get the Script associated to the thread
    CtrlScript *getScript() const { return script; }

    /// @internal
    //@{
    ConnTblEntry *getConnEntry() const { return connEntry; }

    /// pushes the actual state on the stack
    enum { DONT_DEFER = false, DEFER = true };
    enum { NO_EVAL = false, WANTS_EVAL = true };
    void pushState(const CtrlSment *theSment, CtrlVarList *newLocals = 0,
                   bool defer = DONT_DEFER, bool wantsEval = NO_EVAL,
                   const CtrlFunc *newFunc = 0, ClassVar *instance = 0);

    /// pops the first state from the stack and returns the next statement
    const CtrlSment *popState();

    const CtrlClass *getClassScope() const { return classScope; }
    ClassVar *getClassScopeInstance() const { return classScopeInstance; }
    void setClassScopeInstance(ClassVar *instance);
    void classInstanceAboutToDie(ClassVar *instance);

    /// specific work for "break"
    const CtrlSment *breakSment(const CtrlSment *sment);

    /// specific work for "continue"
    const CtrlSment *continueSment(const CtrlSment *sment);

    /// specific work for "return".
    const CtrlSment *returnSment(const CtrlExpr *sment);

    const CtrlSment *getCurrentSment() const { return currentSment; }

    /// Check if the current statement has to be evaluated or just executed
    bool wantEval() const;
    //@}

    /// sets the wait-condition; CtrlThread takes ownership
    void setWaitCond(WaitCond *cond);

    /// return id of this thread
    ThreadId getId() const { return id; }

    /** @name Error-Handling
      * control list of error messages
      * appendLastError always copies the error message!
      */
    //@{
    ///
    void clearLastError() { lastError.clear(); }
    ///
    void appendLastError(const ErrClass *err);
    ///
    void appendLastError(const ErrClass &err) { appendLastError(&err); }
    ///
    void appendLastError(const ErrorVar &err) { lastError.append( new ErrorVar(err) ); }
    ///
    const DynVar &getLastError() const { return lastError; }
    //@}

    /// Set thread to invalid
    void setInvalid() { valid = false; }

    /// Is thread invalid
    bool isValid() const { return valid; }

    /** @name Funktionen f�r Trace
        @internal
    */
    //@{
    /// Type of Trace
    enum KindOfTrace
    {
      /// kein Trace wird geschrieben
      NO_TRACE,
      /// TRACE Variablennamen ausgegeben
      VERIFY_TRACE,
      /// TRACE bei Variablen wird der Wert angezeigt
      EXECUTION_TRACE
    };

    /// Format a string that is used as TAB for the Trace
    enum TraceTabFormat
    {
      TRACE_LINE,
      TRACE_LABEL,
      SMENTLIST_LINE,
      SMENT_LINE
    };

    /// Chose Type of Trace
    inline KindOfTrace setTrace(KindOfTrace newTrace)
    {
      KindOfTrace old = trace;
      trace = newTrace;
      return(old);
    }
    /// Returns: TRUE when trace is on FALSE when trace is off
    bool traceON() const;
    /// Returns: type of current Trace
    KindOfTrace getKindOfTrace() const { return trace; }
    ///  Formatiere eine Zeichenkette die zum Einr�cken des Traces verwendet wird
    char *getTraceTab(TraceTabFormat format, int line = -1);
    ///  Einr�ckung vergroessern
    void incTraceTab() { traceTabAdd = traceTabAdd + 2; }            // -- Einrueckung die nur ein Statement lang lebt
    ///  Einr�ckung verkleinern
    void decTraceTab() { if (traceTab > 1) traceTab = traceTab - 2; }
    //@}

    /** Schiebe dem Thread eine neue doneCB unter. (Auch NULL ist erlaubt)
      * @returns doneCB die alte doneCB. Achtung!!! mu� vom Caller deleted werden!
      @internal
      */
    //@{
    inline DoneCB *updateDoneCB(DoneCB *newCB) { DoneCB *cb = doneCB; doneCB = newCB; return(cb); }

    inline void setSinkEvent() { isSinkEvent = true;}
    inline void setIsAnswer()  { isAnswer = true;}
    inline void setIsRefresh() { isRefresh = true;}

    inline bool getIsAnswer()  const { return isAnswer; }
    inline bool getIsRefresh() const { return isRefresh; }

    static PVSSulong getNumOfThreads() { return numOfThreads; }
    //@}

    const CtrlFunc *getCurrentUserFunc() const;
    const CtrlFunc *getStartedUserFunc() const;

    void getStackTrace(DynVar &var);

    void reportStatus(std::ostream &os) const;

    /** return information about current location of interpreting (for error messages)
      * It returns information about the script origin (e.g. file, panel)
      * and contains current line number, etc.
      */
    CharString getLocation() const;

    /// return information about location of the given statement (for error messages)
    CharString getLocation(const CtrlSment *sment) const;

    /// set an exception
    void setException(ErrorVar *ptr);

    /// get set exception
    const ErrorVar *getException() const { return exceptionPtr_; }

    /// move the exception from @fromThread into this thread
    void moveExceptionFrom(CtrlThread *fromThread);

    /// @internal
    //@{
    void setLastDebugTime(const PreciseTime &t) { lastDebugTime = t; }
    const PreciseTime &getLastDebugTime() const { return lastDebugTime; }

    void setInTry();
    void setInCatch();
    void setInFinally();

    void setThrowErrorAsException(bool on) { throwErrorAsException = on; }
    bool getThrowErrorAsException() const { return throwErrorAsException; }

    // get/set additional infos about the HL group currently processed
    inline PVSSulong getOriginUserId() { return(originUserId_); }
    inline PVSSlong  getOriginManId()  { return(originManId_ ); }

    inline void setOriginUserId(PVSSulong _userId) { originUserId_ = _userId; }
    inline void setOriginManId( PVSSlong _manId)   { originManId_ = _manId;   }
    //@}

  // ======================================================================
  private:
    static StackItem *recycleStack;
    static unsigned recycleCount;

    void setArgs(const Variable *args);

    void writeTraceListEnd(int line);
    void writeTrace(const CtrlSment *sment);

    bool isScriptCoded() const;

    ExecReturn workImpl(PVSSlong maxWeight);

    void updateStatistics(PreciseTime diff);
    void updateBlockingTime(PVSSulong diff);

    /** set the return value.
      * set the return value of the currently executed function. is called
      * by ReturnSment
      */
    void setFuncReturn(Variable *var)
    {
      if (var != funcReturn)
        delete funcReturn;
      funcReturn = var;
    }

    static PVSSulong numOfThreads;   // number of instances

    ThreadId id;

    bool valid;
    bool inWork;  // flag set while inside work() to avoid recursions

    CtrlScript *script;
    CtrlThread *next;
    CtrlThread *prev;
    const CtrlSment *nextSment;     // NaechstesStatement, das zur Ausfuehrung ansteht
    const CtrlSment *currentSment;  // Aktuelles Statement in der work-loop
    CtrlVarList *locals;            // Die lokalen Variablen
    CtrlVarList *argValues;         // Zwischenergebnisse
    StackItem *stack;
    WaitCond *waitCond;
    const CtrlClass *classScope;    // in which (user defd) class' scope are we currently running
    ClassVar *classScopeInstance;

    Variable *funcReturn;

    ConnTblEntry *connEntry;
    DoneCB *doneCB;

    DynVar lastError;

    // -- Variablen zum Traceschreiben --
    int traceTab;           // -- Einr�ckung f�r aktuelles Sment
    int traceTabAdd;        // -- Zus�tzliche Einr�ckung nach einem IF oder LOOP
    bool keepTabWhileList;
    KindOfTrace trace;

    unsigned deferredCount; // Count deferred statements
    unsigned syncCount;     // Count synchronized statements

    // Kein bitfeld, soviele Threads werden nicht laufen.
    // Schneller Zugriff ist wichtiger.
    bool isSinkEvent;
    bool isAnswer;
    bool isRefresh;

    // Entry point
    FCall *startFunc;

    // Statistics
    PreciseTime lastDebugTime;
    PreciseTime startTime_;        // When started
    PreciseTime blockStartTime_;   // When blocked
    PVSSulong interpreterTime_;  // How long interpreted (micro secs)
    PVSSulong blockedTime_;      // How long blocked (micro secs)

    // try - catch - finally
    ErrorVar *exceptionPtr_;     // Pointer to current exception
    bool inCatch_;               // Executing catch block
    bool inFinally_;             // Executing finally block
    bool throwErrorAsException;

    // get/set additional infos about the HL group currently processed
    PVSSulong originUserId_;      // additional infos about the HL group
    PVSSlong originManId_;        // additional infos about the HL group
};


inline void CtrlThread::setInCatch()
{
  inCatch_ = true;
  inFinally_ = false;

  // delete exceptionPtr_;
  // exceptionPtr_ = 0;
}


inline void CtrlThread::setInFinally()
{
  inCatch_ = false;
  inFinally_ = true;
}

#endif /* _CTRLTHREAD_H_ */
