// DATEIBESCHREIBUNG ==============================================================
// DATEINAME:     DpDerivSmooth.hxx
// VERANTWORTUNG:	Stanislav Meduna
// 
// BESCHREIBUNG:	Von Anstieg abhaengige Glaettung.
//
// AENDERUNGS-HISTORIE
// Ver.  | Datum      | Aenderungen                            | ModNr.| Autor
// ------+------------+-----------------Anfang-----------------+-------+-----------
//   1.0 |            | 1.Erstellung mit Westmount-OMT         |     0 |
// ======================================Ende======================================
#ifndef _DPDERIVSMOOTH_H_
#define _DPDERIVSMOOTH_H_

// Vorwaerts-Deklaration der Eigenen Klasse
class DpDerivSmooth;

// System-Include-Files
#include <DpSmoothing.hxx>
#include <FloatVar.hxx>
#include <TimeVar.hxx>
#include <Variable.hxx>

// Vorwaerts-Deklarationen :
class DpConvSmooth;
class DpDerivSmooth;

class BitVec;

// ========== DpDerivSmooth ============================================================

/** This is a derivative smoothing class used to smooth numerical variables. It supports INTEGER_VAR, UINTEGER_VAR, CHAR_VAR and FLOAT_VAR types.
     The class can be configured using following attributes:
        - smoothing interval
        - smoothing tolerance (deadband) 
        - smoothing tolerance (deadband) 
        - smoothing derivation limit

    @classification public use
*/
class DLLEXP_CONFIGS DpDerivSmooth : public DpSmoothing 
{
    friend class UNIT_TEST_FRIEND_CLASS;   
  // Klassen-Enums:

// ..........................Anfang User-Klasseninterne-Definitionen..................
// ...........................Ende User-Klasseninterne-Definitionen...................
public:
  /** Default constructor.
   */
  DpDerivSmooth();
  /** Default destructor.
   */
  ~DpDerivSmooth();

  // Operatoren :
  
  /** Writes content of the smoothing class to the output stream.
        @param ndrStream Output stream.
        @param aConv Reference to DpFlutterSmooth instance.
        @return itcNdrUbSend stream.
   */
  friend DLLEXP_CONFIGS itcNdrUbSend &operator<<(itcNdrUbSend &ndrStream, const DpDerivSmooth &aConv);

  /** Reads contents of the smoothing from the input stream.
        @param ndrStream Input stream.
        @param aConv Reference to DpFlutterSmooth instance.
        @return itcNdrUbSend stream.
   */
  friend DLLEXP_CONFIGS itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream, DpDerivSmooth &aConv);
  
  /** Assignment operator used for type conversions (*x)=(*y).
      @param aConv Reference to DpFlutterSmooth instance.  
      @return DpConvSmooth reference.
    */ 
  virtual DpConvSmooth &operator=(const DpConvSmooth &aConv);

  // Spezielle Methoden :

  /** Returns the class smoothing type.
      @return always DpConvFlutterSmooth type
  */
  virtual DpConversionType convType() const;

  /** Performs derivate smoothing for a given input variable. 
   *  
      @param inpVar value of the variable.  
      @param outVarPtr smoothed output value.  
      @param aTime timestamp of the variable.  
      @param ubits user defined bytes.  
      @return DpConversionOK on success and DpSmoothed if value was smoothed. In the case of an error a DpConversionError value is returned.
   */
  virtual DpConversionResultType convert(const Variable &inpVar, Variable * & outVarPtr, const TimeVar &aTime, const BitVec &ubits);

  /** Allocates a new DpDerivSmooth object.
      @return A pointer to a newly created object, or NULL.
   */
  virtual DpConvSmooth *allocate() const;

  /** Sets a new value of specified smoothing attribute.
      @param attrNr specified attribute number.  Following attributes are supported by this class : DERIV_SMOOTH_TOLER1_ATTR, DERIV_SMOOTH_TOLER2_ATTR, DERIV_SMOOTH_TIME_ATTR and DERIV_SMOOTH_LIMIT_ATTR.
      @param var a Variable object that holds specified attribute.
      @return PVSS_TRUE if the attribute's value was succesfully updated or PVSS_FALSE otherwise.
   */
  virtual PVSSboolean setAttribut(DpAttributeNrType attrNr, const Variable &var);

  /** Returns specified smoothing attribute value.
      @param attrNr specified attribute number.  Following attributes are supported by this class : TYPE_ATTR, DERIV_SMOOTH_TOLER1_ATTR, DERIV_SMOOTH_TOLER2_ATTR, DERIV_SMOOTH_TIME_ATTR and DERIV_SMOOTH_LIMIT_ATTR.
      @return A pointer to a Variable objects that holds specified attribute.
   */
  virtual Variable *getAttribut(DpAttributeNrType attrNr) const;

  /** Indicates if the instance is properly configured.
      @return always PVSS_TRUE 
   */
  virtual PVSSboolean isConsistent() const;

  // Generierte Methoden :

   /** Returns actual derivate tolerance limit. (const version)
      @return A reference to a FloatVar value that holds tolerance value.
   */
  const FloatVar &getAttrToler1() const;

   /** Returns actual derivate tolerance limit. 
      @return A reference to a FloatVar value that holds tolerance value.
   */
  FloatVar &getAttrToler1();
  
  /** Sets a new derivate tolerance limit attribute. 
      @param newAttrToler1 A reference to a FloatVar value that holds tolerance value.
   */
  void setAttrToler1(const FloatVar &newAttrToler1);
  
  /** Returns actual derivate tolerance limit. (const version)
      @return A reference to a FloatVar value that holds tolerance value.
   */
  const FloatVar &getAttrToler2() const;

  /** Returns actual derivate tolerance limit. 
      @return A reference to a FloatVar value that holds tolerance value.
   */
  FloatVar &getAttrToler2();

  /** Sets a new derivate tolerance limit attribute. 
      @param newAttrToler2 A reference to a FloatVar value that holds tolerance value.
   */
  void setAttrToler2(const FloatVar &newAttrToler2);
  
  /** Returns actual derivate limit. (const version)
      @return A reference to a FloatVar value that holds limit value.
   */
  const FloatVar &getAttrLimit() const;

  /** Returns actual derivate limit. 
      @return A reference to a FloatVar value that holds limit value.
   */
  FloatVar &getAttrLimit();

  /** Sets a new derivate limit attribute. 
      @param newAttrLimit A reference to a FloatVar value that holds limit value.
   */
  void setAttrLimit(const FloatVar &newAttrLimit);
  
  /** Returns actual smoothing flutter interval attribute. (const version)
      @return A reference to a TimeVar value that holds smoothing interval.
   */
  const TimeVar &getAttrInterval() const;

  /** Returns actual smoothing flutter interval attribute. 
      @return A reference to a TimeVar value that holds smoothing interval.
   */
  TimeVar &getAttrInterval();

  /** Sets a new smoothing flutter interval attribute. 
      @param newAttrInterval A reference to a TimeVar value that holds smoothing interval.
   */
  void setAttrInterval(const TimeVar &newAttrInterval);
  
  /** Returns an recently updated value. (const version)
      @return A reference to a Variable value that holds last sent value.
   */
  const Variable *getLastValueSent() const;

  /** Returns an recently updated value. 
      @return A reference to a Variable value that holds last sent value.
   */
  Variable *getLastValueSent();

  /** Sets a internal sent value. 
      @param newLastValueSent A reference to a Variable value that holds this new value.
   */
  void setLastValueSent(const Variable *newLastValueSent);

  /** Checks if the actual derivation is positive. (const version)
      @return PVSS_TRUE if derivation > 0, otherwise PVSS_FALSE.
   */
  const PVSSboolean &getLastRising() const;

  /** Checks if the actual derivation is positive. 
  @return PVSS_TRUE if derivation > 0, otherwise PVSS_FALSE.
   */
  PVSSboolean &getLastRising();

  /** Force the value of the actual derivation direction flag. 
      @param newLastRising a new derivation direction flag.
   */
  void setLastRising(const PVSSboolean &newLastRising);
  
  /** Returns last time the limit has been changed attribute. (const version)
      @return A reference to a TimeVar value that holds smoothing interval.
   */
  const TimeVar &getLimitChangeTime() const;

  /** Returns last time the limit has been changed attribute. 
      @return A reference to a TimeVar value that holds smoothing interval.
   */
  TimeVar &getLimitChangeTime();

  /** Sets a new last time the limit has been changed attribute. 
      @param newLimitChangeTime A reference to a TimeVar value that holds smoothing interval.
   */
  void setLimitChangeTime(const TimeVar &newLimitChangeTime);

  /** Checks if the limit was changed recently. (const version)
      @return PVSS_TRUE if yes, otherwise PVSS_FALSE.
   */
  const PVSSboolean &getLimitChangeTimeValid() const;

  /** Checks if the limit was changed recently.
      @return PVSS_TRUE if yes, otherwise PVSS_FALSE.
   */
  PVSSboolean &getLimitChangeTimeValid();

  /** Indicates that the limit was changed recently. 
      @param newLimitChangeTimeValid A boolean flag.
   */
  void setLimitChangeTimeValid(const PVSSboolean &newLimitChangeTimeValid);


protected:
private:
  const Variable *getLastValue() const;
  Variable *getLastValue();
  void setLastValue(const Variable *newLastValue);
  const TimeVar &getLastTime() const;
  TimeVar &getLastTime();
  void setLastTime(const TimeVar &newLastTime);
  const FloatVar *getTolerInUse() const;
  FloatVar *getTolerInUse();
  void setTolerInUse(const FloatVar *newTolerInUse);
  FloatVar attrToler1;
  FloatVar attrToler2;
  FloatVar attrLimit;
  TimeVar attrInterval;
  Variable *lastValue;
  Variable *lastValueSent;
  PVSSboolean lastRising;
  TimeVar lastTime;
  FloatVar *tolerInUse;
  TimeVar limitChangeTime;
  PVSSboolean limitChangeTimeValid;
  BitVec *lastBitsPtr;

// ............................Anfang User-Attribut-Definitionen...................
// .............................Ende User-Attribut-Definitionen....................
};

// ================================================================================
// Inline-Funktionen :
inline const FloatVar &DpDerivSmooth::getAttrToler1() const
{
  return attrToler1;
}

inline FloatVar &DpDerivSmooth::getAttrToler1()
{
  return attrToler1;
}
inline void DpDerivSmooth::setAttrToler1(const FloatVar &newAttrToler1)
{
  attrToler1 = (FloatVar &) newAttrToler1;
}
inline const FloatVar &DpDerivSmooth::getAttrToler2() const
{
  return attrToler2;
}

inline FloatVar &DpDerivSmooth::getAttrToler2()
{
  return attrToler2;
}
inline void DpDerivSmooth::setAttrToler2(const FloatVar &newAttrToler2)
{
  attrToler2 = (FloatVar &) newAttrToler2;
}
inline const FloatVar &DpDerivSmooth::getAttrLimit() const
{
  return attrLimit;
}

inline FloatVar &DpDerivSmooth::getAttrLimit()
{
  return attrLimit;
}
inline void DpDerivSmooth::setAttrLimit(const FloatVar &newAttrLimit)
{
  attrLimit = (FloatVar &) newAttrLimit;
}
inline const TimeVar &DpDerivSmooth::getAttrInterval() const
{
  return attrInterval;
}

inline TimeVar &DpDerivSmooth::getAttrInterval()
{
  return attrInterval;
}
inline void DpDerivSmooth::setAttrInterval(const TimeVar &newAttrInterval)
{
  attrInterval = (TimeVar &) newAttrInterval;
}
inline const Variable *DpDerivSmooth::getLastValue() const
{
  return lastValue;
}

inline Variable *DpDerivSmooth::getLastValue()
{
  return lastValue;
}
inline void DpDerivSmooth::setLastValue(const Variable *newLastValue)
{
  lastValue = (Variable *) newLastValue;
}
inline const Variable *DpDerivSmooth::getLastValueSent() const
{
  return lastValueSent;
}

inline Variable *DpDerivSmooth::getLastValueSent()
{
  return lastValueSent;
}
inline void DpDerivSmooth::setLastValueSent(const Variable *newLastValueSent)
{
  lastValueSent = (Variable *) newLastValueSent;
}
inline const PVSSboolean &DpDerivSmooth::getLastRising() const
{
  return lastRising;
}

inline PVSSboolean &DpDerivSmooth::getLastRising()
{
  return lastRising;
}
inline void DpDerivSmooth::setLastRising(const PVSSboolean &newLastRising)
{
  lastRising = (PVSSboolean &) newLastRising;
}
inline const TimeVar &DpDerivSmooth::getLastTime() const
{
  return lastTime;
}

inline TimeVar &DpDerivSmooth::getLastTime()
{
  return lastTime;
}
inline void DpDerivSmooth::setLastTime(const TimeVar &newLastTime)
{
  lastTime = (TimeVar &) newLastTime;
}
inline const FloatVar *DpDerivSmooth::getTolerInUse() const
{
  return tolerInUse;
}

inline FloatVar *DpDerivSmooth::getTolerInUse()
{
  return tolerInUse;
}
inline void DpDerivSmooth::setTolerInUse(const FloatVar *newTolerInUse)
{
  tolerInUse = (FloatVar *) newTolerInUse;
}
inline const TimeVar &DpDerivSmooth::getLimitChangeTime() const
{
  return limitChangeTime;
}

inline TimeVar &DpDerivSmooth::getLimitChangeTime()
{
  return limitChangeTime;
}
inline void DpDerivSmooth::setLimitChangeTime(const TimeVar &newLimitChangeTime)
{
  limitChangeTime = (TimeVar &) newLimitChangeTime;
}
inline const PVSSboolean &DpDerivSmooth::getLimitChangeTimeValid() const
{
  return limitChangeTimeValid;
}

inline PVSSboolean &DpDerivSmooth::getLimitChangeTimeValid()
{
  return limitChangeTimeValid;
}
inline void DpDerivSmooth::setLimitChangeTimeValid(const PVSSboolean &newLimitChangeTimeValid)
{
  limitChangeTimeValid = (PVSSboolean &) newLimitChangeTimeValid;
}

// ............................Anfang User-Inlines.................................
// .............................Ende User-Inlines..................................

// ................................OMT-Regeneration................................

#endif /* _DPDERIVSMOOTH_H_ */
