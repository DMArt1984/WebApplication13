//  The C++ Booch Components (Version 2.3)
//  (C) Copyright 1990-1994 Grady Booch. All Rights Reserved.
//
//  BCTime.h
//
// This file contains the declaration of the time and date class.

#ifndef BCTIME_H
#define BCTIME_H 1

#ifndef _TYPES_HXX_
#include <Types.hxx>
#endif

#include <time.h>
#include <iostream>



// Types denoting hours, minutes, and seconds.
typedef time_t   BC_Time;

typedef unsigned BC_Hour;         // 0 .. 23
typedef unsigned BC_Minute;       // 0 .. 59
typedef unsigned BC_Second;       // 0 .. 59

typedef time_t  BC_DaySecond;    // 0 .. 86399

enum BC_Meridiem {BC_kAM, BC_kPM};

// Types denoting months, days, and years.

typedef unsigned BC_Month;        // 1 .. 12
typedef unsigned BC_Day;          // 1 .. 31
typedef unsigned BC_Year;         // 1970 .. n

enum BC_MonthName {BC_kJanuary, BC_kFebruary, BC_kMarch,
                   BC_kApril, BC_kMay, BC_kJune,
                   BC_kJuly, BC_kAugust, BC_kSeptember,
                   BC_kOctober, BC_kNovember, BC_kDecember};

enum BC_DayName {BC_kSunday, BC_kMonday, BC_kTuesday, BC_kWednesday,
                 BC_kThursday, BC_kFriday, BC_kSaturday};

enum BC_DaylightSaving {BC_DaylightSavingDetect = -1,
                        BC_DaylightSavingOff = 0,
                        BC_DaylightSavingOn = 1};

// Types denoting year days and quarters.

typedef unsigned BC_YearDay; // 1 .. 366
typedef unsigned BC_Quarter; // 1 .. 4

/**
 * A time and date class.
 * Internally the time and date are stored as the number of seconds
 * since 1.1.1970, 00:00 UTC (unix time).
 * This class gives an interface to access the time as year, month, day, ...
 * or to manipulate the time, e.g. add one hour to it.
 */
class DLLEXP_BASICS BC_CTime 
{
  friend class UNIT_TEST_FRIEND_CLASS;

public:

  /// Default constructor. The time is set to the current system time
  BC_CTime();
  /**
   * Constructor. The time is set to that represented by t as a unix time.
   *
   * If an invalid value is specified, the created instance will have the value
   * "01.01.1970 00:00:00 UTC".
   *
   * @param t The number of seconds passed since 01.01.1970 00:00:00 UTC
   */
  BC_CTime(time_t t);
  /// Deprecated! Please use Constructor with BC_DaylightSaving. The time is set explicitely.
  BC_CTime(BC_Hour, BC_Minute, BC_Second, PVSSboolean daylightsavings = PVSS_FALSE);
  /// Deprecated! Please use Constructor with BC_DaylightSaving. Date and time is set explicitely.
  BC_CTime(BC_Month, BC_Day, BC_Year, BC_Hour, BC_Minute, BC_Second,
           PVSSboolean daylightsavings = 0);

  /// Deprecated! Please use Constructor with BC_DaylightSaving. Date and time is set explicitely.
  BC_CTime(BC_MonthName, BC_Day, BC_Year, BC_Hour, BC_Minute, BC_Second,
           PVSSboolean daylightsavings = 0);

  /**
   * Constructor. The time is set explicitely.
   *
   * The time values are evaluated in the local timezone.
   * The date of the created instance will be the current date.
   */
  BC_CTime(BC_Hour, BC_Minute, BC_Second, BC_DaylightSaving);

  /**
   * Constructor. Date and time is set explicitely.
   *
   * The time and date values are evaluated in the local timezone.
   *
   * If an invalid value is specified, the created instance will have the value
   * "01.01.1970 00:00:00 UTC".
   */
  BC_CTime(BC_Month, BC_Day, BC_Year, BC_Hour, BC_Minute, BC_Second, BC_DaylightSaving);

  /**
   * Constructor. Date and time is set explicitely.
   *
   * The time and date values are evaluated in the local timezone.
   * takes the monthconstants as input
   *
   * If an invalid value is specified, the created instance will have the value
   * "01.01.1970 00:00:00 UTC".
   */
  BC_CTime(BC_MonthName, BC_Day, BC_Year, BC_Hour, BC_Minute, BC_Second, BC_DaylightSaving);

  /// Copy constructor.
  BC_CTime(const BC_CTime&);
  /// Destructor.
  ~BC_CTime() {};

  /// Assignment operator.
  BC_CTime& operator=(const BC_CTime&);
  /// Checks if two instances are equal
  PVSSboolean operator==(const BC_CTime&) const;
  /// Checks if two instances are inequal
  PVSSboolean operator!=(const BC_CTime&) const;
  /// Checks if the first specified instance is smaller than the second instance.
  PVSSboolean operator<(const BC_CTime&) const;
  /// Checks if the first specified instance is smaller than or equal to
  /// the second instance
  PVSSboolean operator<=(const BC_CTime&) const;
  /// Checks if the first specified instance is greater than the second instance.
  PVSSboolean operator>(const BC_CTime&) const;
  /// Checks if the first specified instance is greater than or equal to
  /// the second instance
  PVSSboolean operator>=(const BC_CTime&) const;

  /// Sets the time to the current system time
  void setTime();
  /// Sets the time to that given by t as a unix time (UTC).
  void setTime(time_t t);

  /// Deprecated! Please use setTime with BC_DaylightSaving. Set the time as given.
  void setTime(BC_Hour, BC_Minute, BC_Second, PVSSboolean daylightsavings = 0);
  /// Deprecated! Please use setTime with BC_DaylightSaving. Set Date and Time as given.
  void setTime(BC_Month, BC_Day, BC_Year, BC_Hour, BC_Minute, BC_Second,
               PVSSboolean daylightsavings = 0);
  /// Deprecated! Please use setTime with BC_DaylightSaving. Set Date and Time as given.
  void setTime(BC_MonthName, BC_Day, BC_Year, BC_Hour, BC_Minute, BC_Second,
               PVSSboolean daylightsavings = 0);

  /// Set the time as given.
  void setTime(BC_Hour, BC_Minute, BC_Second, BC_DaylightSaving);

  /**
   * Set the time as given.
   *
   * The time and date values are evaluated in the local timezone
   */
  void setTime(BC_Month, BC_Day, BC_Year, BC_Hour, BC_Minute, BC_Second, BC_DaylightSaving);
  /**
   * Set the time as given.
   * takes the monthconstants as input
   *
   * The time and date values are evaluated in the local timezone
   */
  void setTime(BC_MonthName, BC_Day, BC_Year, BC_Hour, BC_Minute, BC_Second, BC_DaylightSaving);

  /// Increment the seconds. Date and time are adjusted accordingly.
  void NextSecond(BC_DaySecond count = 1);
  /// Increment the minute. Date and time are adjusted accordingly.
  void NextMinute(unsigned count = 1);
  /// Increment the hour. Date and time are adjusted accordingly.
  void NextHour(unsigned count = 1);
  /// Increment the day. Date and time are adjusted accordingly.
  void NextDay(unsigned count = 1);
  /// Increment the week. Date and time are adjusted accordingly.
  void NextWeek(unsigned count = 1);
  /**
   * Increment the month.
   * The days of the month remain the same
   * if the targetmonth has enough days
   * otherwise the method moves to the last day
   * of the target month.
   * The time may differ due to daylightsaving
   *
   * @param count The number of month we want to increment
   *
   */
  void NextMonth(unsigned count = 1);
  /// Increment the year. Date and time are adjusted accordingly.
  void NextYear(unsigned count = 1);
  /// Decrement the seconds. Date and time are adjusted accordingly.
  void PreviousSecond(BC_DaySecond count = 1);
  /// Decrement the minute. Date and time are adjusted accordingly.
  void PreviousMinute(unsigned count = 1);
  /// Decrement the hour. Date and time are adjusted accordingly.
  void PreviousHour(unsigned count = 1);
  /// Decrement the day. Date and time are adjusted accordingly.
  void PreviousDay(unsigned count = 1);
  /// Decrement the week. Date and time are adjusted accordingly.
  void PreviousWeek(unsigned count = 1);
  /**
   * Decrement the month.
   * The days of the month remain the same
   * if the targetmonth has enough days
   * otherwise the method moves to the last day
   * of the target month.
   * The time may differ due to daylightsaving
   *
   * @param count The number of month we want to decrement
   *
   */
  void PreviousMonth(unsigned count = 1);
  /// Decrement the year. Date and time are adjusted accordingly.
  void PreviousYear(unsigned count = 1);

  /// Returns the time as elapsed seconds since 1.1.1970 00:00 UTC (unix time)
  time_t ElapsedSeconds() const;
  /// Returns a time structure representing the local time.
  const tm* LocalTime() const;
  /// Returns a time structure representing GMT
  const tm* GreenwichMeanTime() const;
  /// Return the hour of the time, starting with 0.
  BC_Hour Hour() const;
  /// Return AM / PM of the time, AM represented by 0.
  BC_Meridiem Meridiem() const;
  /// Return the minute of the time starting with 0.
  BC_Minute Minute() const;
  /// Return the second of the time starting with 0.
  BC_Second Second() const;
  /// Return the time as seconds elapsed in the current day.
  BC_DaySecond DaySecond() const;
  /// Return the month of the date starting with 1.
  BC_Month Month() const;
  /// Return the name of the month as a enum, starting with 0.
  BC_MonthName MonthName() const;
  /// Return the day starting with 1.
  BC_Day Day() const;
  /// Return the name of the day starting with sunday as 0.
  BC_DayName DayName() const;
  /// Return the year.
  BC_Year Year() const;
  /// Return the day in the year, starting with 1.
  BC_YearDay YearDay() const;
  /// Return the quarter of the year, starting with 1.
  BC_Quarter Quarter() const;
  /// Return PVSS_TRUE, if daylight saving is in effect.
  PVSSboolean IsDaylightSavings() const;
  /// Return PVSS_TRUE, if the time is in the inclusive range between the
  /// two arguments.
  PVSSboolean IsBetween(const BC_CTime&, const BC_CTime&) const;

  /// Return the time difference in seconds between the local time and GMT.
  IL_DEPRECATED("deprecated, use PVSSTime::getTimeZoneDifference() instead")
  static time_t TimeFromGMT();
  /// Return the number of days in the month and year given.
  static BC_Day DaysInMonth(BC_Month, BC_Year);
  /// Return the number of days in the month and year given.
  static BC_Day DaysInMonth(BC_MonthName, BC_Year);
  /// Return the number of days in the year given.
  static BC_YearDay DaysInYear(BC_Year);
  /// Return PVSS_TRUE, if the given year is a leap year.
  static PVSSboolean IsLeapYear(BC_Year);

  /// Convert time as GMT to elapsed seconds
  static time_t TimeGM(BC_Month, BC_Day, BC_Year, BC_Hour, BC_Minute, BC_Second);
  /// Convert time as GMT to elapsed seconds
  static time_t TimeGM(BC_MonthName, BC_Day, BC_Year, BC_Hour, BC_Minute, BC_Second);

  // this func is needed by NT because there must not be negative timestamps!
  /// Convert a given time to unix time. The time shall not be before 1.1.1970 00:00!
  static time_t Time(BC_Month, BC_Day, BC_Year,
                      BC_Hour, BC_Minute, BC_Second,
                      PVSSboolean daylightsavings = 0);

  // this func is needed by NT because there must not be negative timestamps!
  /// Convert a given time to unix time. The time shall not be before 1.1.1970 00:00!
  static time_t Time(BC_MonthName, BC_Day, BC_Year,
                      BC_Hour, BC_Minute, BC_Second,
                      PVSSboolean daylightsavings = 0);

protected:

  /// The internal representation of the date and time value
  time_t fRep;

};

/// Returns the bigger of the two arguments
BC_CTime BC_Max(const BC_CTime&, const BC_CTime&);
/// Returns the smaller of the two arguments
BC_CTime BC_Min(const BC_CTime&, const BC_CTime&);

DLLEXP_BASICS std::ostream& operator<<(std::ostream&, const BC_CTime&);

inline BC_CTime::BC_CTime()
  : fRep(time(0)) {}

inline BC_CTime::BC_CTime(time_t t)
  : fRep(t)
{
#ifdef _WIN32
  if (fRep < 0)
    fRep = 0;
#endif
}

inline BC_CTime::BC_CTime(BC_Month month, BC_Day day, BC_Year year,
                   BC_Hour hour, BC_Minute minute, BC_Second second,
                   PVSSboolean daylightsavings)
  : fRep(Time(month, day, year, hour, minute, second, daylightsavings))
{
#ifdef _WIN32
  if (fRep < 0)
    fRep = 0;
#endif
}

inline BC_CTime::BC_CTime(const BC_CTime& time)
  : fRep(time.fRep)
{
#ifdef _WIN32
  if (fRep < 0)
    fRep = 0;
#endif
}


inline BC_CTime& BC_CTime::operator=(const BC_CTime& time)
{
  fRep = time.fRep;
  return *this;
}

inline PVSSboolean BC_CTime::operator==(const BC_CTime& time) const
{
  return (fRep == time.fRep);
}

inline PVSSboolean BC_CTime::operator!=(const BC_CTime& time) const
{
  return !operator==(time);
}

inline PVSSboolean BC_CTime::operator<(const BC_CTime& time) const
{
  return (fRep < time.fRep);
}

inline PVSSboolean BC_CTime::operator<=(const BC_CTime& time) const
{
  return (fRep <= time.fRep);
}

inline PVSSboolean BC_CTime::operator>(const BC_CTime& time) const
{
  return (fRep > time.fRep);
}

inline PVSSboolean BC_CTime::operator>=(const BC_CTime& time) const
{
  return (fRep >= time.fRep);
}

inline void BC_CTime::setTime()
{
  fRep = time(0);
}

inline void BC_CTime::setTime(time_t t)
{
  fRep = t;
#ifdef _WIN32
  if (fRep < 0)
    fRep = 0;
#endif
}

inline void BC_CTime::setTime(BC_Month month, BC_Day day, BC_Year year,
                       BC_Hour hour, BC_Minute minute, BC_Second second,
                       PVSSboolean daylightsavings)
{
  fRep = Time(month, day, year, hour, minute, second, daylightsavings);
#ifdef _WIN32
  if (fRep < 0)
    fRep = 0;
#endif
}

inline void BC_CTime::NextSecond(BC_DaySecond count)
{
  fRep = fRep + count;
}

inline void BC_CTime::PreviousSecond(BC_DaySecond count)
{
  fRep = fRep - count;
#ifdef _WIN32
  if (fRep < 0)
    fRep = 0;
#endif
}

inline time_t BC_CTime::ElapsedSeconds() const
{
  return fRep;
}

inline PVSSboolean BC_CTime::IsBetween(const BC_CTime& time1, const BC_CTime& time2) const
{
  return ((time1.fRep <= fRep) && (fRep <= time2.fRep));
}

inline BC_CTime BC_Max(const BC_CTime& time1, const BC_CTime& time2)
{
  return (time1 > time2) ? time1 : time2;
}

inline BC_CTime BC_Min(const BC_CTime& time1, const BC_CTime& time2)
{
  return (time1 < time2) ? time1 : time2;
}

//new Functions to use BC_MonthName in calls
inline BC_CTime::BC_CTime(BC_MonthName month, BC_Day day, BC_Year year,
                   BC_Hour hour, BC_Minute minute, BC_Second second,
                   PVSSboolean daylightsavings)
  : fRep(Time(month, day, year, hour, minute, second, daylightsavings))
{
#ifdef _WIN32
  if (fRep < 0)
    fRep = 0;
#endif
}

inline BC_CTime::BC_CTime(BC_MonthName month, BC_Day day, BC_Year year,
                       BC_Hour hour, BC_Minute minute, BC_Second second,
                       BC_DaylightSaving ds)
{
  setTime(month, day, year, hour, minute, second, ds);
}

inline void BC_CTime::setTime(BC_MonthName month, BC_Day day, BC_Year year,
                       BC_Hour hour, BC_Minute minute, BC_Second second,
                       PVSSboolean daylightsavings)
{
  setTime(static_cast<BC_Month>(month+1), day, year, hour, minute, second, daylightsavings);
}

inline void BC_CTime::setTime(BC_MonthName month, BC_Day day, BC_Year year,
                       BC_Hour hour, BC_Minute minute, BC_Second second,
                       BC_DaylightSaving ds)
{
  setTime(static_cast<BC_Month>(month+1), day, year, hour, minute, second, ds);
}

inline BC_Day BC_CTime::DaysInMonth(BC_MonthName month, BC_Year year)
{
  return BC_CTime::DaysInMonth(static_cast<BC_Month>(month+1), year);
}

inline time_t BC_CTime::TimeGM(BC_MonthName month, BC_Day day, BC_Year year,
                        BC_Hour hour, BC_Minute minute, BC_Second second)
{
  return BC_CTime::TimeGM(static_cast<BC_Month>(month+1), day, year, hour, minute, second);
}

inline time_t BC_CTime::Time(BC_MonthName month, BC_Day day, BC_Year year,
                       BC_Hour hour, BC_Minute minute, BC_Second second,
                       PVSSboolean daylightsavings)
{
  return Time(static_cast<BC_Month>(month+1), day, year, hour, minute, second, daylightsavings);
}


#endif
