#ifndef _CNSNODETREE_H_
#define _CNSNODETREE_H_

#include <CharString.hxx>
#include <CNSDataIdentifier.hxx>

// forward declaration
class CNSNodeNames;
class CNSTree;
class CNSNode;

/**
 * Public interface for local CNS tree manipulation.
 * Create a tree structure you want to add to one of the CNS Views.
 */
class DLLEXP_DATAPOINT CNSNodeTree
{
public:

  friend class CommonNameService;
  friend class UNIT_TEST_FRIEND_CLASS;    // ein Unit-Test braucht erweiterten zugriff auf diese Klasse

  enum RC
  {
    /// Operation successfully completed
    OK = 0,
    /// Invalid CNSDataIdentifier specified
    INVALID_DATA,
    /// Invalid (technical) name specified
    INVALID_NAME,
    /// Invalid display names specified
    INVALID_DISPLAY_NAMES,
    /// A node with the specified name already exists
    DUPLICATE_NODE_NAME,
    /// The specified element was not found
    NOT_FOUND
  };

public:
  /// Create a tree that already holds a root node
  CNSNodeTree(const CNSNodeNames &names, const CNSDataIdentifier &data = CNSDataIdentifier());

  /// Destructor
  virtual ~CNSNodeTree();

public:
  /**
   * Add a child node to the given path.
   *
   * The passed CNSNode will be copied into the tree as a single node,
   * so any children of the node will not be added to this tree.
   *
   * @param parentPath The path to the parent node (e.g. EITC.B5). It always
   *                   has to start with the root-node (the name of the tree).
   * @param node The child that should be added to node specified by parentPath.
   *
   * @return OK if successful else an error.
   */
  RC addNode(const char *parentPath, const CNSNode &node);

  /**
   * Add a subtree to the given path.
   *
   * The passed CNSNodeTree will be copied as a whole tree.
   *
   * @param parentPath The path to the parent node (e.g. EITC.B5). It always
   *                   has to start with the root-node (the name of the tree).
   * @param tree The subtree that should be added to the node
   *             specified by parentPath.
   *
   * @return OK if successful else an error.
   */
  RC addTree(const char *parentPath, const CNSNodeTree &tree);

private:
  CNSTree *internalTree; // will never be null

  /// Avoid generating a copy constructor
  CNSNodeTree(const CNSNodeTree &);
  /// Avoid generating an assignment operator
  CNSNodeTree &operator=(const CNSNodeTree &);

  /**
   * Returns a reference to the internal tree.
   */
  CNSTree &getInternalTree();

  /**
   * Returns a reference to the internal tree.
   */
  const CNSTree &getInternalTree() const;

  /**
   * Returns the node at the specified path, or null if the path does not exist.
   */
  CNSTree *getNode(const char *path);

};

#endif // _CNSNODETREE_H_
