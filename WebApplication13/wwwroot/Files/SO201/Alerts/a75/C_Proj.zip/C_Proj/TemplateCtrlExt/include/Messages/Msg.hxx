// DATEIBESCHREIBUNG ==============================================================
// DATEINAME:     Msg.hxx
// VERANTWORTUNG: Gerhard Fellrieser
//
// BESCHREIBUNG : Die Klasse Msg bildet den Container fuer alle Nachrichten
//  im PVSS-2 System. Eine Aufteilung von Msg in Msg-Typen  erfolgt in:
//
//  Datenpunkt-Messages DpMsg  (Nachrichten, die Datenpunkte betreffen)
//  System-Messages     SysMsg (Nachrichten im Systemhochlauf)
//
//
//
//  Attribute der Basisklasse:
//          source      : Sourcemanager (dieser Prozess)
//          destination     : Zielmanageradresse
//      originTime  : Quellzeit
//      realTime    : Zeiteindeutigkeit
//      msgId       : Eindeutige Identifizierungsnummer der
//                Message je Manager
//      answerId    : Antwort auf die Message mit dieser msgId
//      isSent      : TRUE, wenn die Nachricht mit dieser msgId
//                schon verschickt wurde
//      handleGlPtr : Globaler Pointer auf einen Messagehandler
//                mit folgendem Mechanismus: Existiert fuer die
//                Submessages (z.B.: DpMsg) kein Pointer
//                        auf einen Messagehandler, so kann hier ein
//                        globaler Message-Handler eingebaut werden.
//
//
//
//  Erklaerung zu msgId, answerId, isSent und deren Zugriffs-/Hilfsfunktionen
//
//      Eine abgeschickte Message muss eine eindeutige msgId besitzen, um
//      eventuelle Antwort-Messages zuordnen zu koennen.
//
//      Da aber eine Message mit einer msgId verschickt, dann veraendert und
//      dann noch einmal (mit derselben msgId) verschickt werden kann, wurde
//      das Flag isSent eingefuehrt, welches nach dem Verschicken gesetzt wird.
//      Eine Message kann aber nur dann verschickt werden, wenn dieses Flag
//      nicht gesetzt ist.
//
//      Bei einem Konstruktoraufruf sowie bei jeder Zusweisung eines Msg-
//      Objektes wird die msgId mitkopiert, wodurch zwei Messages mit
//      identischer msgId existieren, die beide verschickt werden koennten.
//      Um das zu verhindern, wird bei der Kopie das Flag isSent automatisch
//      gesetzt.
//
//      METHODE getNewMsgId
//      ===================
//      In so einem Fall muss der Benutzer manuell eine neue msgId mit der
//      Funktion getNewMsgId vergeben. In dieser Funktion wird das Flag
//      geloescht und die msgId hochgezaehlt.
//
//      METHODE isAnswer
//      ================
//      Ist eine Message eine Antwort-Message, so wird ein Pointer auf die
//      answerId zurueckgeliefert, sont ein 0-Pointer.
//
//      METHODE needsAnswer
//      ===================
//      Wenn eine Message eine Antwort benoetigt, so liefert diese Funktion
//      TRUE, sonst FALSE.
//
//  METHODE wasSent
//  ===============
//  Liefert TRUE, wenn die Message schon verschickt wurde, sonst FALSE
//
// AENDERUNGS-HISTORIE
// Ver.  | Datum      | Aenderungen                            | ModNr.| Autor
// ------+------------+-----------------Anfang-----------------+-------+-----------
//   1.0 |            | 1.Erstellung mit Westmount-OMT         |     0 |
// ======================================Ende======================================
#ifndef _MSG_H_
#define _MSG_H_

#include <MsgVersion.hxx>

// Vorwaerts-Deklaration der Eigenen Klasse
class Msg;

// ========== MsgType ============================================================
// Liste aller Typen von Messages.

/** The message types.
    All message types are identified by a unique number. Because most functions use a 
    pointer to the base classes Msg or DpMsg you shall check the type with the 
    isA-function before casting the object to the appropriate derived class.
    For most of the messages there are functions in the Manager class which are 
    a facade to the corresponding message.
*/
enum MsgType {
  PVSS_MSG,
  NO_MSG,
  /// system specific message
  SYS_MSG,
  /// start dpinit sequence sys message
  SYS_MSG_START_DPINIT,
  /// name server sys message @see NameServerSysMsg
  SYS_MSG_NAMESERVER,
  /// license information sys message
  SYS_MSG_LICENSE,
  /// initialization of manager 
  SYS_MSG_INIT,
  /// transfer / sync of files
  SYS_MSG_FILE_TRANSFER,
  /// common datapoint message @see DpMsg
  DP_MSG,
  /// config initialisation message
  DP_MSG_INITCONFIG,
  /// the identification message
  DP_MSG_IDENTIFICATION,
  /// the type container message
  DP_MSG_TYPECONTAINER,
  /// request to create a datapoint type
  DP_MSG_DPTYPE_REQ,
  /// notification of a new / deleted datapoint type
  DP_MSG_MANIP_DPTYPE,
  /// request to create a datapoint
  DP_MSG_DP_REQ,
  DP_MSG_REQ_NEW_DP = DP_MSG_DP_REQ,
  /// notification of a new / deleted datapoint
  DP_MSG_MANIP_DP,
  DP_MSG_CMD_NEWDEL_DP = DP_MSG_MANIP_DP,
  /// request to create / change / delete an alias or comment
  DP_MSG_DPALIAS_REQ,
  /// notification of a new / changed / deleted alias or comment
  DP_MSG_MANIP_DPALIAS,
  /// generic connection type message
  DP_MSG_CONNECTION,
  /// connect message
  DP_MSG_CONNECT,
  /// connect message without answer
  DP_MSG_CONNECT_RET,
  /// connect message; no hotlink if this manager changed the values 
  DP_MSG_CONNECT_NOSOURCE,
  /// disconnect message
  DP_MSG_DISCONNECT,
  /// hotlink message
  DP_MSG_HOTLINK,
  /// simple value change message
  DP_MSG_VALUECHANGE,
  /// optimized driver value change message
  DP_MSG_DRIVER_VC,
  /// complex value change message
  DP_MSG_COMPLEX_VC,
  /// common request message
  DP_MSG_REQUEST,
  /// common answer message
  DP_MSG_ANSWER,
  /// request value 
  DP_MSG_SIMPLE_REQUEST,
  /// request value in the past
  DP_MSG_ASYNCH_REQUEST,
  /// request value 
  DP_MSG_SYNCH_REQUEST,
  /// request values of a timerange
  DP_MSG_PERIOD_REQUEST,
  // base class DpMsgAlert, see below. 
  // It is at the end so the IDs won't change now. 
  // DP_MSG_ALERT,
  /// change alert values
  DP_MSG_ALERT_VC,
  /// connect to alert values
  DP_MSG_ALERT_CONNECT,
  /// connect to visible alert values
  DP_MSG_ALERT_CONNECT_VISIBLE,
  DP_MSG_ALERT_CONN_RET_VISIBLE = DP_MSG_ALERT_CONNECT_VISIBLE,
  /// disconnect from alert values
  DP_MSG_ALERT_DISCONNECT,
  DP_MSG_ALERT_DISCONN = DP_MSG_ALERT_DISCONNECT,
  /// notification messagse for alert values
  DP_MSG_ALERT_HL,
  /// request alert values of a timerange
  DP_MSG_ALERT_TIME_REQUEST,
  DP_MSG_ALERT_TIME_REQU = DP_MSG_ALERT_TIME_REQUEST,
  /// request alert values of a timerange
  DP_MSG_ALERT_PERIOD_REQUEST,
  DP_MSG_ALERT_PERIOD_REQU = DP_MSG_ALERT_PERIOD_REQUEST,
  /// query message
  DP_MSG_FILTER_REQUEST,
  /// query connect message
  DP_MSG_FILTER_CONNECT,
  /// query disconnect message
  DP_MSG_FILTER_DISCONNECT,
  DP_MSG_FILTER_DISCONN = DP_MSG_FILTER_DISCONNECT,
  /// query hotlink message
  DP_MSG_FILTER_HL,
  /// base class DpMsgAlert
  DP_MSG_ALERT,
  /// disconnect all
  DP_MSG_DISCONNECT_ALL,
  /// FT LIBS-13b-8 message splitting, abort a outstanding Request (dpQuery, dpGetPeriod, alertGetPeriod)
  DP_MSG_ABORT_REQUEST,

  // ------------------------------------------  
  // -- IM 98990 Implementation of CNS class --
  // ------------------------------------------  
  /// request to create / delete a CNS object (view, tree, node, ...)
  DP_MSG_CNS_REQ,
  /// notification of a new / deleted CNS object (view, tree, node, ...)
  DP_MSG_MANIP_CNS,

  // -----------------------------------------
  // FT COMDRV-V13-2 dpGetMaxAge functionality
  DP_MSG_MAXAGE_REQUEST,

  /// rename a datapoint
  DP_MSG_DPNAME_REQ,
  /// notification on renaming a datapoint
  DP_MSG_MANIP_DPNAME

  // end of transission, connection will be closed
  // END_OF_TRANS = 0X5A
};
// -----------------------------------------------------------------------------------
// MAX_DP_MSG_NR musz bei Erweiterung des Enums berichtigt werden!!!
#define MAX_DP_MSG_NR  (unsigned long) DP_MSG_MANIP_DPNAME
// -----------------------------------------------------------------------------------

// ========== MsgPtr ============================================================
typedef Msg* MsgPtr;

// System-Include-Files
#include <BitVar.hxx>
#include <ManagerIdentifier.hxx>
#include <TimeVar.hxx>
#include <fstream>
#include <DblPtrListItem.hxx>
#include <MessageDiag.hxx>
#include <Resources.hxx>

// Vorwaerts-Deklarationen :
class Msg;

// gcc 4.x mag solche freunde nicht -> globale operatoren
DLLEXP_MESSAGES itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream, MsgType &msgTyp); 
DLLEXP_MESSAGES itcNdrUbSend &operator<<(itcNdrUbSend &ndrStream, const MsgType &msgTyp);

// ========== Msg ============================================================

#if defined(LIBS_AS_DLL)
template class DLLEXP_MESSAGES SimplePtrArray<ManagerIdentifier>;
#endif

/** The abstract base class for all messages.
*/
class DLLEXP_MESSAGES Msg : public DblPtrListItem
{
  friend class UNIT_TEST_FRIEND_CLASS;    // ein Unit-Test braucht erweiterten zugriff auf diese Klasse

public:
  /// Enumeration of message directions
  enum Direction 
  {
    SEND,
    RECEIVE
  };
  /// Copy constructor
  Msg(const Msg &newMsg);
  /** Constructor
      @param newDestination Specify where to send the message to.
             Usually this is the event manager, Manager::eventId.
  */
  Msg(const ManagerIdentifier &newDestination);
  /// default constructor
  Msg();
  /// destructor
  virtual ~Msg();

  /// get the status of a message depending on msgTypeToMessagDiagMsgType static list
  static MessageDiag::MsgType isAStat(MsgType msg);
  
  /// get the name of the message via its type
  static const char *getMsgName(MsgType type);    // there are several SysMsg's that have the same MsgType "SysMsg"
                                                  // you will not get their name with this methode. use the virtual getMsgName() to obtain their names
  /// get the message type via the name of the message
  static MsgType getMsgType(const CharString &name);

  // Operatoren :
  /// stream operator >> for MsgPtr type
  /// creates for some messages a message object via DpMsg::allocate or SysMsg::allocate
  friend DLLEXP_MESSAGES itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream, MsgPtr &msgPtr);
  /// stream operator << for MsgPtr type
  friend DLLEXP_MESSAGES itcNdrUbSend &operator<<(itcNdrUbSend &ndrStream, const MsgPtr &msgPtr);
  /// stream operator >> for Msg type
  friend DLLEXP_MESSAGES itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream, Msg &msg);
  /// stream operator << for Msg type
  friend DLLEXP_MESSAGES itcNdrUbSend &operator<<(itcNdrUbSend &ndrStream, const Msg &msg);
  /// stream operator << for Msg type via normal streams
  friend DLLEXP_MESSAGES std::ostream &operator<<(std::ostream &ofStream, const Msg &msg);

  /// compare operator != with Msg
  int operator!=(const Msg &rval) const;
  /// compare operator == with Msg
  virtual int operator==(const Msg &rval) const;
  /// assignment operator = with Msg
  virtual Msg &operator=(const Msg &rVal);

  /// The debug functions. Print out the message contents according to format level (1 - 3)
  /// Debug function depending on level, direction, timestamps, connection and PVSS-Version
  void debug(std::ostream &to, int level, TimeVar now, TimeVar delta, PVSSushort _version, Direction dir, const char *_connection) const;
  /// Debug function depending on level, direction, timestamps and PVSS-Version
  void debug(std::ostream &to, int level, TimeVar now, TimeVar delta, PVSSushort _version, Direction dir) const;
  /// Debug function depending on level, direction and timestamps
  void debug(std::ostream &to, int level, TimeVar now, TimeVar delta, Direction dir) const;
  /// Debug function depending on level
  virtual void debug(std::ostream &to, int level) const;
  /// Public function to get the message name
  virtual const char *getMsgName() const = 0;

  /// Call the debug functions through message type and level
  virtual void debugMsgType(std::ostream &to, int level, MsgType type) const;

  /// Check if the current settings allow to print the contents of this message
  PVSSboolean checkDebugPrint(Direction dir) const;

  // special methods
  /// function to set the current time
  void setCurrentTime() { originTime = TimeVar().getValue(); }

  /// Get the message type.
  virtual MsgType isA(MsgType msgType) const;
  /// Get the message type. Call this function before casting a message pointer to a derived class.
  virtual MsgType isA() const;
  /// check, whether the message type is an answering message.
  /// The derived classes shouild return a long pointer to the AnswerId, if Msg is an answer message.
  virtual const PVSSulong *isAnswer() const;

  /// Check if message needs answer
  virtual PVSSboolean needsAnswer() const;
  /// set the message status to being sent
  void setSent() { isSent = true; }
  /// check if message was already sent - get new message id for sending it again!
  bool wasSent() const { return isSent; }
  
  /// Set the peerMsgId. Internal use only!
  void setPeerMsgId(PVSSulong id) {peerMsgId = id;}
  /// Get the peerMsgId. Intneral use only.
  PVSSulong getPeerMsgId() const  {return peerMsgId;}

  /// Get the current message id. Every transmitter sets this id.
  PVSSulong getCurrentMsgId() const { return currentMsgId; }
  /// Get the message id, i.e. the original message id. Only the source sets this id.
  PVSSulong getMsgId() const { return origMsgId;}
  /// Get the original message id. Only the source sets this id.
  PVSSulong getOrigMsgId() const    { return origMsgId; }
  /// Get a new message id to resend the message
  void  getNewMsgId();
  /// Set the new msgId
  void  setNewMsgId();
  // uebernimmt, wenn m noch nicht gesendet wurde, von m die msgId und ruft m.setSend() auf
  /// if m is not sent, then call m.setSent()
  PVSSboolean importMsgId(Msg &m);
  /// allocate memory for the message
  virtual Msg *allocate() const = 0;

  /// Obsolete call: Get the original sender, i.e. the sender id
  const ManagerIdentifier &getOrigSource() const {return source;}
  /// Get sender id
  const ManagerIdentifier &getSource() const { return source; }
  /// set sender id
  void setSource(const ManagerIdentifier &newSource);
  /// get destination id
  const ManagerIdentifier &getDestination() const { return destination; }
  /// Set destination id
  void setDestination(const ManagerIdentifier &newDestination); 
  /// Get the current transmitter (hop) id of this message
  const ManagerIdentifier &getPeer() const   { return peer; }
  /// Set the current transmitter (hop) id of this message
  void setPeer(const ManagerIdentifier &newPeer)  { peer = newPeer; }

  /// depending on the manager identifier add the destination of the message
  void addDestination(const ManagerIdentifier &newDestination);
  /// get a dynamic list of destinations
  const SimplePtrArray<ManagerIdentifier> & getDestinationList() const;
  /// clear all destinations of the message
  void clearDestinationList();

  /// get time of creation
  TimeVar getOriginTime() const { return TimeVar(originTime); }
  /// set time of creation
  void setOriginTime(const TimeVar &newOriginTime) { originTime = newOriginTime.getValue(); }

  /// set the receive time
  void setReceiveTime() {recvTime = TimeVar().getValue();}
  /// get the receive time
  TimeVar getReceiveTime() const {return TimeVar(recvTime);}

  /// check if creation time is real time from outside
  PVSSboolean getRealTime() const { return realTime; }
  /// set the real time flag
  void setRealTime(PVSSboolean newRealTime)   { realTime = newRealTime; }
  /// set the real time flag by the getValue function
  void setRealTime(const BitVar &newRealTime) { realTime = newRealTime.getValue(); }
  
  /** Routing of a message. This leaves source and destination unchanged, 
      and sets peer to the new peer (next hop).
      This method is used to route a message from one system to another
  */
  void routeMsg(const ManagerIdentifier &newPeer);  

  /** Redirect a message to a new destination. 
      This leaves the source unchanged and sets peer and destination to the new destination.
      This method is used to redirect a dpGetPeriod message from the event to the data manager.
      The data manager will then send the answer directly to the originating manager.
  */
  void redirectMsg(const ManagerIdentifier &newTarget);

  /** Forward the message to a new destination.
      This sets source to an empty ManagerIdentifier (when sending the message this will
      be set to the actual Manager id), and destination to the new target. 
      This message will then appear as it was created by this manager.
      The event use this method to send a DP_MSG_DP_REQ and like to the data and will then
      receive the answer instead of the originating manager.
  */
  void forwardMsg(const ManagerIdentifier &newTarget);

  /// Set a status bit
  void setStatusBit(unsigned bitno)
  {
    if (bitno < 16)
      status |= (1 << bitno);
  }

  /// Clears a status bit
  void clearStatusBit(unsigned bitno)
  {
    if (bitno < 16)
      status &= ~(1 << bitno);
  }

  /// Gets a status bit
  PVSSboolean getStatusBit(unsigned bitno)
  {
    if (bitno < 16)
      return (status & (1 << bitno)) ? PVSS_TRUE : PVSS_FALSE;
    else
      return PVSS_FALSE;
  }

  /// get the version of the MSG
  PVSSushort getMsgVersion() const { return(version_); }

  /// Get origin user
  PVSSuserIdType getOriginUser() const { return originUserId; }

  /// Set the origin user
  void setOriginUser(PVSSuserIdType uid) { originUserId = uid; }

protected:
  /// Id of answer
  PVSSulong answerId;

private:
  // Sender / destination 
  ManagerIdentifier peer;
  // The sender for this hop
  ManagerIdentifier source;
  // The destination for this hop
  ManagerIdentifier destination;

  SimplePtrArray<ManagerIdentifier> destinationList;
  
  // The message id, unique and consecutive per connection
  PVSSulong peerMsgId;
  // The current message id, unique and consecutive per manager 
  PVSSulong currentMsgId;
  // The original message id
  PVSSulong origMsgId;
  
  PVSSTime    recvTime;   // Not transmitted
  
  PVSSTime    originTime;
  PVSSboolean realTime;

  bool        isSent;

  PVSSushort  status;

  PVSSushort  version_;   // the Msg-Version of this MSG.

  /// User id
  PVSSuserIdType originUserId;

  static PVSSulong   nextMsgId;

protected:
    /// puts message into ndrStream
    virtual void outNdrUb(itcNdrUbSend &ndrStream) const;
    /// gets message from ndrStream
    virtual void inNdrUb(itcNdrUbReceive &ndrStream);
};

// ================================================================================
// Inline-Funktionen :
inline void Msg::setSource(const ManagerIdentifier &newSource)
{
  source = newSource;
}

inline void Msg::setDestination(const ManagerIdentifier &newDestination)
{ 
  destination = newDestination; 
}

inline int Msg::operator!=(const Msg &rval) const
{
    return !(operator==(rval));
}


inline void Msg::addDestination(const ManagerIdentifier &manId) 
{
  destinationList.append(new ManagerIdentifier(manId));
}


inline const SimplePtrArray<ManagerIdentifier> & Msg::getDestinationList() const
{
  return destinationList;
}

inline void Msg::clearDestinationList() 
{
  destinationList.clear();
}


#endif /* _MSG_H_ */
