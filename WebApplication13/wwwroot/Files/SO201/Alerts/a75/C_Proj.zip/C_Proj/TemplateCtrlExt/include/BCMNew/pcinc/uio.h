#ifndef _UIO_H
#define _UIO_H

typedef char *caddr_t;

struct iovec {
        caddr_t iov_base;
        unsigned int iov_len;
};

#endif /* _UIO_H */
