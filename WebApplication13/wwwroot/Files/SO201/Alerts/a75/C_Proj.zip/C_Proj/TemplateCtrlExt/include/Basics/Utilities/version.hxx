// used for defining the version of a manager.
// THE FILE VersInfo.hxx MUST BE CHECKED IN AGAIN, BEFORE A NEW CM-CONFIGURATION IS MADE !!!

#include <VersInfo.hxx>

#ifdef __GNUG__
#	define UNUSED_ATTR	[[gnu::unused]]
#else
#	define UNUSED_ATTR
#endif

static char version[] UNUSED_ATTR = "$" "Revision: " PVSS_VERSION " " PVSS_VERS_COMMENT PVSS_VERS_WARNING " $";

