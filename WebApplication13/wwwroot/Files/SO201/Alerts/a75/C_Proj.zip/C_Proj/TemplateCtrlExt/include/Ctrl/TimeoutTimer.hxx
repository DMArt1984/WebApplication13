#ifndef _TimeoutTimer_H_
#define _TimeoutTimer_H_

class TimeVar;

/** A timer which monotonically checks if a given timespan has expired
    It is therefore immune against system clock changes
    @classification ETM internal use
*/

class DLLEXP_CTRL TimeoutTimer
{
  public:
    /// invalid timer; must use setTimeout() to make it valid
    TimeoutTimer();

    /// create a timer with the given timeout and start the timer
    TimeoutTimer(const TimeVar &theTimeout);

    /// create a timer with the given timeout and start the timer
    TimeoutTimer(int seconds, int milliSeconds = 0);

    ~TimeoutTimer();

    /// define the timeout
    void setTimeout(const TimeVar &theTimeout);

    /// check if the set timeout has already expired
    bool hasExpired() const;

    /** returns absolute timestamp when the timer expires,
        assuming no system time changes happen from now to endTime.
        Every call gets the current time and recalculates the new endTime
    */
    const TimeVar &getEndTime();

  private:
    TimeoutTimer(const TimeoutTimer &);  // disable copy ctor

    class TimeoutTimerPrivate *d;
};

#endif
