#ifndef CRYPTOSSLWRAPPER_H
#define CRYPTOSSLWRAPPER_H

#define USES_errno
#define USES_stdio
#define USES_string
#define USES_sockets
#include <ItcPrelude.h>

#define OPENSSL_API_COMPAT 0x10100000L
#include <openssl/ssl.h>
#include <openssl/err.h>
#include <openssl/pem.h>
#include <openssl/rand.h>
#include <openssl/aes.h>
#include <openssl/rsa.h>
#include <openssl/evp.h>
#include <openssl/x509.h>
#include <openssl/bn.h>
#include <openssl/stack.h>
#include <openssl/safestack.h>
#include <openssl/crypto.h>

#define OPENSSL_DES_LIBDES_COMPATIBILITY
#include <openssl/des.h>

#include <string>

class DLLEXP_OABASICS CryptoSslWrapper
{
public:
  enum CfTlsErrorCodes
  {
    // Unspecified error has appeared
    ERR_UNKNOWN = -1,

    // no error
    ERR_SSL_NONE = 0,

    // The registering of the available SSL/TLS ciphers and digests is failed.
    ERR_SSL_LIBRARY_INIT = 1,

    // Checking of the consistency of a private key with the corresponding
    // certificate loaded into ctx is failed.
    ERR_SSL_PRIVATE_KEY_CHECK = 2,

    // The loading of the certificates and private keys into the SSL_CTX or
    // SSL object is failed.
    ERR_SSL_PRIVATE_KEY_USE = 3,

    //  The loading of a certificate chain from file into ctx is failed.
    ERR_SSL_CERT_CHAIN_USE = 4,

    // The location for ctx, at which CA certificates for verification
    // purposes (or the CAFile) are located is wrong.
    ERR_SSL_LOAD_VERIFY_LOCATIONS = 5,

    // CRL file loading is failed.
    ERR_SSL_CRL_LOAD = 6,

    // Certificate lookup is failed.
    ERR_SSL_STORE_LOAD = 7,

    // The cipher list cannot be set.
    ERR_SSL_CIPHER_LIST_LOAD_FAIL = 8,

    // Creating of a new SSL_CTX object is failed.
    ERR_SSL_CTX_NEW = 9,

    // see: SslWrapper::InitStatus
    ERR_WRAPPER_VERSION_NOT_SUFFICIENT = 10,
    ERR_WRAPPER_FUNCTION_NOT_FOUND = 11,
    ERR_WRAPPER_LIBRARY_NOT_FOUND = 12,
    ERR_WRAPPER_NOT_INITIALIZED = 13,
    ERR_SSL_SET_TMP_DH = 14,
    ERR_SSL_SET_TMP_ECDH = 15
  };

  enum InitStatus
  {
    VERSION_NOT_SUFFICIENT = -3,
    FUNCTION_NOT_FOUND = -2,
    LIBRARY_NOT_FOUND = -1,
    NOT_INITIALIZED = 0,
    INIT_SUCCEEDED = 1
  };

  // type for functions that locate the SSL libraries
  typedef std::string (*FindLibraryCallback)(const std::string&);

public:
  static InitStatus initWrapper(std::string& errorMsg);
  static int initOpenSSL();



private:
  static InitStatus isWrapperInitialized;
  static bool isOpenSSLInitialized;
};

#endif  // CRYPTOSSLWRAPPER_H
