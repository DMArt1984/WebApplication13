// DATEIBESCHREIBUNG ==============================================================
// DATEINAME:     PathItem.hxx
//
//
// AENDERUNGS-HISTORIE
// Ver.  | Datum      | Aenderungen                            | ModNr.| Autor
// ------+------------+-----------------Anfang-----------------+-------+-----------
//   1.0 |            | 1.Erstellung mit Westmount-OMT         |     0 |
// ======================================Ende======================================
#ifndef _PATHITEM_H_
#define _PATHITEM_H_

#if defined(OS_FREEBSD) || defined(__APPLE__)
#include <stdlib.h>
#else
#include <malloc.h>
#endif
#include <string.h>
// Vorwaerts-Deklaration der Eigenen Klasse
class PathItem;


// ========== PathItemType ============================================================
// Art des PathItems.
enum PathItemType {
  PathItemNormal,
  PathItemNormalWildcard,
  PathItemIndex,
  PathItemIndexWildcard,
  PathItemAllIndexes,
  PathItemEndWildcard,
  PathItemAnyLevelWildcard,
  PathItemListWildcard
};


// ========== PathItem ============================================================
class PathItem
{

  // ..........................Anfang User-Klasseninterne-Definitionen..................
  // ...........................Ende User-Klasseninterne-Definitionen...................
public:
  friend class UNIT_TEST_FRIEND_CLASS;
  /// Constructor to create an empty PathItem.
  /// @warning Do not use the default copyconstructor or assigment.
  /// See destructor.
  PathItem();

  /// Destructor release name, and the list.
  ~PathItem();

  // Operatoren :

  // Spezielle Methoden :

  // Generierte Methoden :

  /// Get the type.
  /// @return the type, if set before. Otherwise an undefined value.
  PathItemType getType() const { return type; }

  /// Set the type.
  /// @param newType the type.
  void setType(const PathItemType newType) { type = newType; }

  /// Get the name.
  /// @return the name, if set before. 0 when not set before.
  const char *getName() const { return name; }

  /// Set the name.
  /// @warning if set a second time, the memory allocated for name is not
  ///   released at all. So read the name before and release it.
  /// @param newName the new name. The value is stored and freed in the
  ///    destructor.
  void setName(char *newName) { delete[] name; name = newName; }

  /// Read the value added with insertIdxList(unsigned int newIdxList).
  ///   @param at the index in the list.
  ///   @return the value. 0 when "at" is not a vaild index.
  unsigned int getIdxList(unsigned int at) const;

  /// Get the number of valid elemets in the list.
  ///   @return the number of elemts in the list.
  unsigned int length() const;

  /// Append a value to the list.
  ///   @param newIdxList the value to be appened.
  void insertIdxList(unsigned int newIdxList);

  /// Copyconstructor perform a deep copy.
  ///   @param x the value to copy from
  PathItem(const PathItem &x);

  /// Assignment perform a deep copy.
  ///   @param x the value to copy from
  PathItem & operator = (const PathItem &x);
protected:
private:
  PathItemType type;
  char *name;

  // Statt Collection nur eine einfache Liste
  unsigned int maxlen;
  unsigned int nofItems;
  unsigned int *list;

};

inline unsigned int PathItem::getIdxList(unsigned int at) const
{
  return (((at < nofItems) && (list != 0)) ? list[at] : 0);
}

inline unsigned int PathItem::length() const
{
  return nofItems;
}

inline void PathItem::insertIdxList(unsigned int newIdxList)
{
  if (nofItems >= maxlen)
  {
    // Resize Array
    maxlen += 32;
    unsigned int *oldPtr = list;
    list = (unsigned int *)realloc(list, maxlen * sizeof(unsigned int));
    if (!list)
      free(oldPtr);   // avoid memory leak
  }

  if (list != 0)
  {
    list[nofItems] = newIdxList;
    nofItems++;
  }
  else
  {
    nofItems = 0;
    maxlen = 0;
  }
}


inline PathItem::PathItem()
  : name(0), maxlen(32), nofItems(0)
{
  list = (unsigned int *)malloc(maxlen * sizeof(unsigned int));
}

// Destructor
inline PathItem::~PathItem()
{
  delete[] name;
  free(list);
}

inline PathItem::PathItem(const PathItem &x)
{
  unsigned int i;

  // Setup save values.
  type = x.type;
  nofItems = 0;
  maxlen = x.maxlen;
  name = 0;
  list = (unsigned int *)malloc(maxlen * sizeof(unsigned int));

  // Copy the data.
  if ((list != 0) && (x.list != 0))
  {
    for (i = 0; i < x.nofItems; i++)
    {
      list[i] = x.list[i];
    }
    nofItems = x.nofItems;
  }

  // Copy the name, when needed.
  if (x.name != 0)
  {
    name = new char[strlen(x.name) + 1];
    if (name != 0)
    {
      strcpy(name, x.name);
    }
  }
}

inline PathItem & PathItem::operator = (const PathItem &x)
{
  unsigned int i;

  if (this != &x)
  {
    // Setup save values.
    type = x.type;
    nofItems = 0;

    // Expand destination, when it is to small.
    if (maxlen < x.maxlen)
    {
      maxlen = x.maxlen;
      free(list);
      list = (unsigned int *)malloc(maxlen * sizeof(unsigned int));
    }

    if ((list != 0) && (x.list != 0))
    {
      // Copy the data.
      for (i = 0; i < x.nofItems; i++)
      {
        list[i] = x.list[i];
      }
      nofItems = x.nofItems;
    }

    // Copy the name, when need. Othwerwise delete the name.
    delete[] name;
    name = 0;
    if (x.name != 0)
    {
      name = new char[strlen(x.name) + 1];
      if (name != 0)
      {
        strcpy(name, x.name);
      }
    }
  }
  return(*this);
}
#endif /* _PATHITEM_H_ */
