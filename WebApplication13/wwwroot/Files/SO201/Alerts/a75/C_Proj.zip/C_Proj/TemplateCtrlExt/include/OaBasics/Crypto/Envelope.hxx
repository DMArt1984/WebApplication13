// -----------------------------------------------------------------------------
// creator: Andras Horvath - 09.04.2019
// purpose: Data structure to hold an encrypted envelope
// -----------------------------------------------------------------------------
#ifndef _ENVELOPE_HXX_
#define _ENVELOPE_HXX_

#include <Blob.hxx>

/**
  @class Envelope
  @brief The Envelope class
         stores information for an encrypted envelope.
         An Envelope can have multiple session keys, and an initialization
         vector for the AES encryption.
         The payload is the encrypted data of the Envelope.
*/
class DLLEXP_OABASICS Envelope
{
public:
  /// Constructs an empty Envelope
  Envelope();

  /** Constructs an Envelope from a Blob
   *  @param inputData the input Blob
   */
  Envelope(const Blob& inputData);

  /// Desctructs an Envelope
  ~Envelope();

  /** Converts the content of and Envelope to a Blob
   *  @return  the content of  the Envelope
   */
  explicit operator Blob();

  /** Check if an Envelope is valid
   *  @return the Envelope has all neccesary parts
   */
  operator bool();

  /** Adds a new session key to the Envelope
   *  @param key the session key
   */
  void addKey(const Blob& key);

  /** Gets a session key from the Envelope
   *  @param keyId the index of the session key
   *  @return the session key, or empty Blob
   */
  Blob getKey(size_t keyId);

  /** Returns the numner of session keys saved in the Envelope
   *  @return the number of session keys
   */
  size_t getNumKeys();

  /** Gets the payload of an Envelope
   *  @return the payload of the Envelope
   */
  Blob getPayload();

  /** Sets the payload on the Envelope
   *  @param payload the payload
   *  @param copy true if the payload should be copied, false if moved from
   */
  void setPayload(Blob& payload, bool copy = false);

  /** Gets the initialization vector of an Envelope
   *  @return the initialization vector of the Envelope
   */
  Blob getIV();

  /** Sets the initialization vector on the Envelope
   *  @param iv the initialization vector
   */
  void setIV(const Blob& iv);

  Envelope(const Envelope& rval) = delete;
  Envelope& operator=(const Envelope& rval) = delete;

private:
  class EnvelopeImpl;
  EnvelopeImpl* m_impl;
};

#endif  // _ENVELOPE_HXX_

