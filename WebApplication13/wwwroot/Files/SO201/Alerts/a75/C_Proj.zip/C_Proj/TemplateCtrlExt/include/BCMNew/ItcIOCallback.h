//
//  $RCSfile$
//  $Date$
//  $Revision$
//  $Author$
//  $Locker$
//  $State$
//  $Source$
//
// %Z%JESSI-COMMON-FRAMEWORK 2.0
// %Z%Copyright (C) by Siemens Nixdorf Informationssysteme AG 1992
// %Z%Copyright (C) by Universitaet GH Paderborn 1992
// %Z%Development of this software was partially funded by ESPRIT project 7364.
// %Z%BCM %M% %I% %E%

#ifndef ItcIOCallback_H
#define ItcIOCallback_H

//#ifdef __GNUG__
//#pragma interface
//#endif

/*
 * IOCallback allows a member function to be used as an IO handler
 * instead of requiring derivation of a subclass.
 */

#define USES_generic

#include "ItcPrelude.h"
#include "ItcIOHandler.h"

#define itcIOCallback(T) name2(T,_itcIOCallback)
#define IOReady(T) name2(T,_IOReady)
#define IOTimer(T) name2(T,_IOTimer)

#define itcIOCallbackdeclare(T) \
typedef int T::IOReady(T)(itcConnection *conn, char *data); \
typedef void T::IOTimer(T)(long sec, long usec); \
class DLLEXP_BCM itcIOCallback(T) : public itcIOHandler { \
public: \
    itcIOCallback(T)( \
	T*, IOReady(T)* in, IOReady(T)* out = nil, IOReady(T)* ex = nil \
    ); \
    itcIOCallback(T)( \
	T*, IOTimer(T)*, \
	IOReady(T)* in = nil, IOReady(T)* out = nil, IOReady(T)* ex = nil \
    ); \
\
    virtual int inputReady(itcConnection *conn, char *data); \
    virtual int outputReady(itcConnection *conn, char *data); \
    virtual int exceptionRaised(itcConnection *conn, char *data); \
    virtual void timerExpired(long sec, long usec); \
private: \
    T* _obj; \
    IOReady(T)* _input; \
    IOReady(T)* _output; \
    IOReady(T)* _except; \
    IOTimer(T)* _timer; \
};

#define itcIOCallbackimplement(T) \
itcIOCallback(T)::itcIOCallback(T)( \
    T* obj, IOReady(T)* in, IOReady(T)* out, IOReady(T)* ex \
) { \
    _obj = obj; _timer = nil; \
    _input = in; _output = out; _except = ex; \
} \
\
itcIOCallback(T)::itcIOCallback(T)( \
    T* obj, IOTimer(T)* t, IOReady(T)* in, IOReady(T)* out, IOReady(T)* ex \
) { \
    _obj = obj; _timer = t; \
    _input = in; _output = out; _except = ex; \
} \
\
int itcIOCallback(T)::inputReady(itcConnection *conn, char *data) { \
	return (_obj->*_input)(conn, data); } \
int itcIOCallback(T)::outputReady(itcConnection *conn, char *data) { \
	return (_obj->*_output)(conn, data); } \
int itcIOCallback(T)::exceptionRaised(itcConnection *conn, char *data) { \
	return (_obj->*_except)(conn, data); } \
void itcIOCallback(T)::timerExpired(long s, long u) { (_obj->*_timer)(s, u); }

#endif /* ItcIOCallback_H */
