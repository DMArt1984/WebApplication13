#ifndef _ALIASTABLE_H_
#define _ALIASTABLE_H_

/*
VERANTWORTUNG: Robert Trausmuth      
BESCHREIBUNG:  this class is used for managing dpidentifiers and aliases
               comments can be stored also, see AliasTableItem class
*/

#ifndef _DPTYPES_H_
#include <DpTypes.hxx>
#endif

#ifndef _ALIASTABLEITEM_H_
#include <AliasTableItem.hxx>
#endif

#ifndef _DPIDENTIFICATIONRESULTTYPE_H_
#include <DpIdentificationResultType.hxx>
#endif

#include <ostream>

typedef SimplePtrArray<AliasTableItem> AliasTableSet;

#ifdef WIN32
#pragma warning ( disable: 4231 )
#endif

#if defined(LIBS_AS_DLL)
  EXTERN_DATAPOINT template class DLLEXP_DATAPOINT SimplePtrArray<AliasTableItem>;
#endif

#ifdef WIN32
#pragma warning ( default: 4231 )
#endif


class DynVar;

/// This class holds an array of AliasTableItems. It maintains the known aliases and comments
/// for individual datapoint elements.
/// @see AliasTableItem
class DLLEXP_DATAPOINT AliasTable
{
  public:

    /// Constructor
    AliasTable();

    /// Destructor
    ~AliasTable();
    
    /// Assignment operator. Performs deep copy of all elements to create
    /// fully independent copy.
    /// @param at instance to be copied
    /// @return Reference to this
    AliasTable &operator=(AliasTable &at);    

    /// Reset the iterator to point to the first element in the table
    /// @return DpIdentOK
    DpIdentificationResult iteratorReset();

    /// Reset the iterator to point to the first element in the table
    /// @param lang Language id
    /// @return DpIdentOK
    IL_DEPRECATED("deprecated, use iteratorReset() instead, use of language is deprecated")
    DpIdentificationResult iteratorReset(LanguageIdType lang);

    /// Gets the next alias. See also AliasTable::iteratorReset().
    /// @param mask String mask to iterate only through matched aliases
    /// @param namePtrRef Reference to a pointer to the returned alias string
    /// @param dpId DpIdType related to the alias 
    /// @param elId DpElementId related to the alias
    /// @param fixPart [not clear what the purpose is]
    /// @return DpIdentNoMoreNames or DpIdentOK
    DpIdentificationResult iteratorNextName(const char *mask, const char * & namePtrRef, 
                                            DpIdType &dpId, DpElementId &elId, const char *fixPart = 0);

    DpIdentificationResult iteratorNextNameIgnoreCase(const char *mask, const char * & namePtrRef,
                                                      DpIdType &dpId, DpElementId &elId,
                                                      GlobalLanguageIdType langIdg = 0);

private:
  DpIdentificationResult iteratorNextNameCommon(const char *mask, const char * & namePtrRef,
                                                DpIdType &dpId, DpElementId &elId, const char *fixPart,
                                                GlobalLanguageIdType langIdg, bool ignoreCase);

public:

    /// Outputs the instance to the std::ostream
    /// @param to Output stream
    /// @param table Streamed AliasTable instance
    /// @return std::ostream stream
    friend DLLEXP_DATAPOINT std::ostream &operator <<(std::ostream &to, AliasTable &table);

    /// Receives the instance from the itcNdrUbReceive stream
    /// @param from Input stream
    /// @param table AliasTable instance receiving the value from the stream
    /// @return itcNdrUbReceive stream
    friend DLLEXP_DATAPOINT itcNdrUbReceive &operator >>(itcNdrUbReceive &from, AliasTable &table);

    /// Outputs the instance to the itcNdrUbSend stream
    /// @param to Output stream
    /// @param table Streamed AliasTable instance
    /// @return itcNdrUbSend stream
    friend DLLEXP_DATAPOINT itcNdrUbSend &operator <<(itcNdrUbSend &to, AliasTable &table);
    
    /// Set the alias for a given DpIdentifier
    /// @param dp DpIdentifier for which the alias will be set
    /// @param text Text of the alias
    /// @return DpIdentAliasExists if the alias already exists, DpIdentNoSuchAlias if it was not possible to
    /// set the alias, or DpIdentOK when success
    DpIdentificationResult setAlias(const DpIdentifier &dp, const CharString &text);
    
    /// Set the alias for a given DpIdentifier
    /// @param dp DpIdentifier for which the alias will be set
    /// @param text Text of the alias
    /// @param lang Language in which the alias will be set
    /// @return DpIdentAliasExists if the alias already exists, DpIdentNoSuchAlias if it was not possible to
    /// set the alias, or DpIdentOK when success
    IL_DEPRECATED("deprecated, use setAlias(DpIdentifier, CharString) instead, use of language is deprecated")
    DpIdentificationResult setAlias(const DpIdentifier &dp, const CharString &text, LanguageIdType lang );
    
    /// Set the alias for a given DpIdentifier
    /// @param dp DpIdentifier for which the alias will be set
    /// @param text Text of the alias
    /// @return DpIdentAliasExists if the alias already exists, DpIdentNoSuchAlias if it was not possible to
    /// set the alias, or DpIdentOK when success
    IL_DEPRECATED("deprecated, use setAlias(DpIdentifier, CharString) instead, use of language is deprecated")
    DpIdentificationResult setAlias(const DpIdentifier &dp, const LangText &text);
    
    /// Set the comment for a given DpIdentifier
    /// @param dp DpIdentifier for which the comment will be set
    /// @param text Text of the comment
    /// @return DpIdentNoComment if it was not possible to set the comment, or DpIdentOK when success
    DpIdentificationResult setComment(const DpIdentifier &dp, const CharString &text);

    /// Set the comment for a given DpIdentifier
    /// @param dp DpIdentifier for which the comment will be set
    /// @param text Text of the comment
    /// @param lang Language in which the comment will be set
    /// @return DpIdentNoComment if it was not possible to set the comment, or DpIdentOK when success
    IL_DEPRECATED("deprecated, use setComment(DpIdentifier, CharString) instead, use of language is deprecated")
    DpIdentificationResult setComment(const DpIdentifier &dp, const CharString &text, LanguageIdType lang);
    
    /// Set the comment for a given DpIdentifier
    /// @param dp DpIdentifier for which the comment will be set
    /// @param text Text of the comment
    /// @return DpIdentNoComment if it was not possible to set the comment, or DpIdentOK when success
    DpIdentificationResult setComment(const DpIdentifier &dp, const LangText &text);

    /// Internal use only
    DpIdentificationResult setAliasAndComment(const DpIdentifier &dp, const LangText &alias, const LangText &comment, int idx);
    
    /// Get the alias for a given DpIdentifier
    /// @param dp DpIdentifier for which the alias will be retrieved
    /// @param alias Reference where the result will be stored
    /// @param lang Language Id of the alias
    /// @return DpIdentOK if the alias exists, DpIdentNoSuchAlias otherwise
    DpIdentificationResult getAlias(const DpIdentifier &dp, CharString &alias);
    
    /// Get the alias for a given DpIdentifier
    /// @param dp DpIdentifier for which the alias will be retrieved
    /// @param alias Reference where the result will be stored
    /// @param lang Language Id of the alias
    /// @return DpIdentOK if the alias exists, DpIdentNoSuchAlias otherwise
    IL_DEPRECATED("deprecated, use getAlias(DpIdentifier, CharString) instead, use of language is deprecated")
    DpIdentificationResult getAlias(const DpIdentifier &dp, CharString &alias, LanguageIdType lang );
    
    /// Get the alias for a given DpIdentifier
    /// @param dp DpIdentifier for which the alias will be retrieved
    /// @param alias Reference where the result will be stored
    /// @return DpIdentOK if the alias exists, DpIdentNoSuchAlias otherwise
    IL_DEPRECATED("deprecated, use getAlias(DpIdentifier, CharString) instead, use of language is deprecated")
    DpIdentificationResult getAlias(const DpIdentifier &dp, LangText &alias);

    /// Get the DpIdentifier by the alias
    /// @param alias Text of the alias
    /// @param id Reference to the DpIdentifier which will receive the return value
    /// @param lang Language Id
    /// @return DpIdentNoSuchAlias if the alias doesn't exist, DpIdentOK if success
    DpIdentificationResult getId(const CharString &alias, DpIdentifier &id) const;

    /// Get the DpIdentifier by the alias
    /// @param alias Text of the alias
    /// @param id Reference to the DpIdentifier which will receive the return value
    /// @param lang Language Id
    /// @return DpIdentNoSuchAlias if the alias doesn't exist, DpIdentOK if success
    IL_DEPRECATED("deprecated, use getId(const char *, DpIdentifier) instead, use of language is deprecated")
    DpIdentificationResult getId(const CharString &alias, DpIdentifier &id, LanguageIdType lang) const;
    
    /// Get the DpIdentifier by the alias
    /// @param alias Text of the alias
    /// @param id Reference to the DpIdentifier which will receive the return value
    /// @param lang Language Id
    /// @return DpIdentNoSuchAlias if the alias doesn't exist, DpIdentOK if success
    DpIdentificationResult getId(const char *alias, DpIdentifier &id) const;
    
    /// Get the DpIdentifier by the alias
    /// @param alias Text of the alias
    /// @param id Reference to the DpIdentifier which will receive the return value
    /// @param lang Language Id
    /// @return DpIdentNoSuchAlias if the alias doesn't exist, DpIdentOK if success
    IL_DEPRECATED("deprecated, use getId(const char *, DpIdentifier) instead, use of language is deprecated")
    DpIdentificationResult getId(const char *alias, DpIdentifier &id, LanguageIdType lang) const;

    /// Get the comment for a given DpIdentifier
    /// @param dp DpIdentifier for which the alias will be retrieved
    /// @param comment Reference where the result will be stored
    /// @return DpIdentOK if the alias exists, DpIdentNoSuchAlias otherwise
    DpIdentificationResult getComment(const DpIdentifier &dp, CharString &comment);

    /// Get the comment for a given DpIdentifier
    /// @param dp DpIdentifier for which the alias will be retrieved
    /// @param comment Reference where the result will be stored
    /// @param lang Language Id of the alias
    /// @return DpIdentOK if the alias exists, DpIdentNoSuchAlias otherwise
    IL_DEPRECATED("deprecated, use getComment(DpIdentifier, CharString) instead, use of language is deprecated")
    DpIdentificationResult getComment(const DpIdentifier &dp, CharString &comment, LanguageIdType lang);

    /// Get the comment for a given alias
    /// @param alias Alias for which the comment will be retrieved
    /// @param comment Reference where the result will be stored
    /// @return DpIdentOK if the alias exists, DpIdentNoSuchAlias otherwise
    DpIdentificationResult getComment(const CharString &alias, CharString &comment);
    
    /// Get the comment for a given alias
    /// @param alias Alias for which the comment will be retrieved
    /// @param comment Reference where the result will be stored
    /// @param lang Language Id of the alias
    /// @return DpIdentOK if the alias exists, DpIdentNoSuchAlias otherwise
    IL_DEPRECATED("deprecated, use getComment(CharString, CharString) instead, use of language is deprecated")
    DpIdentificationResult getComment(const CharString &alias, CharString &comment, LanguageIdType lang);
    
    /// Get the comment for a given DpIdentifier
    /// @param dp DpIdentifier for which the alias will be retrieved
    /// @param comment Reference where the result will be stored
    /// @return DpIdentOK if the alias exists, DpIdentNoSuchAlias otherwise
    DpIdentificationResult getComment(const DpIdentifier &dp, LangText &comment);
    
    /// Get the number of defined aliases
    /// @return size of the idSet member
    unsigned long nofItems() const {return idSet.nofItems();}

    /// Get the AliasTableItem structure at the given position
    /// @param i Index to the array
    /// @return AliasTableItem structure
    const AliasTableItem & getAt(const DynPtrArrayIndex i) const;
    
    /// Sort the alias array
    void doSort();

    /// Get all defined aliases
    /// @param sys SystemNumType of DpIds which should be returned
    /// @param dps DynVar where the array of DpIds will be returned
    /// @param result Array or corresponding aliases
    /// @param mask Mask for DpSymIdentifier::match() method to sift out only certain comments
    /// @return DpIdentOK
    DpIdentificationResult getAllAliases(SystemNumType sys, DynVar &dps, DynVar &result, const char *mask);

    /// Get all defined aliases
    /// @param sys SystemNumType of DpIds which should be returned
    /// @param dps DynVar where the array of DpIds will be returned
    /// @param result Array or corresponding aliases
    /// @param mask Mask for DpSymIdentifier::match() method to sift out only certain comments
    /// @param oneLang Specifies if only comments in one language will be returned
    /// @return DpIdentOK
    IL_DEPRECATED("deprecated, use getAllAliases(SystemNumType, DynVar, DynVar) instead, use of language is deprecated")
    DpIdentificationResult getAllAliases(SystemNumType sys, DynVar &dps, DynVar &result, const char *mask,
                                         PVSSboolean oneLang);

    /// Get all defined aliases
    /// @param sys SystemNumType of DpIds which should be returned
    /// @param dps DynVar where the array of DpIds will be returned
    /// @param result Array or corresponding aliases
    /// @param mask Mask for DpSymIdentifier::match() method to sift out only certain comments
    /// @param oneLang Specifies if only comments in one language will be returned
    /// @param lang Language Id
    /// @return DpIdentOK
    IL_DEPRECATED("deprecated, use getAllAliases(SystemNumType, DynVar, DynVar) instead, use of language is deprecated")
    DpIdentificationResult getAllAliases(SystemNumType sys, DynVar &dps, DynVar &result, const char *mask,
                                         PVSSboolean oneLang, LanguageIdType lang);

    /// Get all defined comments
    /// @param sys SystemNumType of DpIds which should be returned
    /// @param dps DynVar where the array of DpIds will be returned
    /// @param result Array or corresponding comments
    /// @param mask Mask for DpSymIdentifier::match() method to sift out only certain comments
    /// @param commentPart if PVSS_TRUE, only the first token from the comments will be returned
    /// @param oneLang Specifies if only comments in one language will be returned
    /// @return DpIdentOK
    DpIdentificationResult getAllComments(SystemNumType sys, DynVar &dps, DynVar &result, const char *mask,
                                          PVSSboolean commentPart = PVSS_FALSE,
                                          PVSSboolean oneLang = PVSS_TRUE);

    /// Get all defined comments
    /// @param sys SystemNumType of DpIds which should be returned
    /// @param dps DynVar where the array of DpIds will be returned
    /// @param result Array or corresponding comments
    /// @param mask Mask for DpSymIdentifier::match() method to sift out only certain comments
    /// @param commentPart if PVSS_TRUE, only the first token from the comments will be returned
    /// @param oneLang Specifies if only comments in one language will be returned
    /// @param lang Language Id
    /// @return DpIdentOK
    DpIdentificationResult getAllComments(SystemNumType sys, DynVar &dps, DynVar &result, const char *mask,
                                          PVSSboolean commentPart,
                                          PVSSboolean oneLang, LanguageIdType lang);

    /// Output the basic statistics about the instance to the stream
    /// @param os Output stream
    /// @param summary The output will be streamed only if this variable is false
    /// @param bytes Will be set to total number of bytes this instance occupies
    void  reportStatus(std::ostream &os, bool summary, unsigned &bytes);

    // security plugin callbacks (cannot be caught in libManager)
    static void setSecurityPluginGetAllAliasesFct(bool (*fct)(const DpIdentifier &dpId));

  protected:

    /// Gets the AliasTableItem for the given DpIdentifier
    /// @param dp DpIdentifier
    /// @param image Reference to a pointer to the returned item
    /// @return DpIdentOK if the alias exists, DpIdentNoSuchAlias otherwise
    DpIdentificationResult findItem(const DpIdentifier &dp, AliasTableItem *&image) const
      { DynPtrArrayIndex i; return findItem(dp, i, image); }

    /// Gets the AliasTableItem for the given alias
    /// @param alias Alias string
    /// @param image Reference to a pointer to the returned item
    /// @return DpIdentOK if the alias exists, DpIdentNoSuchAlias otherwise   
    DpIdentificationResult findItem(const CharString &alias, AliasTableItem *&image) const;
    
    /// Gets the AliasTableItem for the given alias
    /// @param alias Alias string
    /// @param image Reference to a pointer to the returned item
    /// @param lang Language Id
    /// @return DpIdentOK if the alias exists, DpIdentNoSuchAlias otherwise   
    IL_DEPRECATED("deprecated, use findItem(CharString, AliasTableItem) instead, use of language is deprecated")
    DpIdentificationResult findItem(const CharString &alias, AliasTableItem *&image, LanguageIdType lang) const;

    /// Gets the AliasTableItem for the given alias
    /// @param dp DpIdentifier to find
    /// @param idx Index to the array of pointers
    /// @param image Reference to a pointer to the returned item
    /// @return DpIdentOK if the alias exists, DpIdentNoSuchAlias otherwise   
    DpIdentificationResult findItem(const DpIdentifier &dp, DynPtrArrayIndex &idx, AliasTableItem *&image) const;

    /// Gets the AliasTableItem for the given alias for modification. After modify use insertItem to change list entry.
    /// @param alias Alias string
    /// @param idx Index to the array of pointers
    /// @param image Reference to a pointer to the returned item
    /// @param lang Language Id
    /// @return DpIdentOK if the alias exists, DpIdentNoSuchAlias otherwise     
    DpIdentificationResult findItem(const CharString &alias, DynPtrArrayIndex &idx, AliasTableItem *&image) const;
    
    /// Gets the AliasTableItem for the given alias for modification. After modify use insertItem to change list entry.
    /// @param alias Alias string
    /// @param idx Index to the array of pointers
    /// @param image Reference to a pointer to the returned item
    /// @param lang Language Id
    /// @return DpIdentOK if the alias exists, DpIdentNoSuchAlias otherwise     
    IL_DEPRECATED("deprecated, use findItem(CharString, DynPtrArrayIndex, AliasTableItem) instead, use of language is deprecated")
    DpIdentificationResult findItem(const CharString &alias, DynPtrArrayIndex &idx, AliasTableItem *&image, LanguageIdType lang) const;
                                                     
    /// Check if the alias is a duplicate
    /// @param text Alias text
    /// @param dp DpIdentifier to check
    /// @return PVSS_TRUE if the alias is a duplicate, or PVSS_FALSE if not
    IL_DEPRECATED("deprecated, use isDuplicateAlias(CharString, DpIdentifier) instead, use of language is deprecated")
    PVSSboolean isDuplicateAlias(const LangText &text, const DpIdentifier &dp);

    /// Check if the alias is a duplicate
    /// @param text Alias text
    /// @param dp DpIdentifier to check
    /// @return PVSS_TRUE if the alias is a duplicate, or PVSS_FALSE if not
    PVSSboolean isDuplicateAlias(const CharString &text, const DpIdentifier &dp);

    /// Check if the alias is a duplicate
    /// @param text Alias text
    /// @param dp DpIdentifier to check
    /// @param lang Language Id
    /// @return PVSS_TRUE if the alias is a duplicate, or PVSS_FALSE if not
    IL_DEPRECATED("deprecated, use isDuplicateAlias(CharString, DpIdentifier) instead, use of language is deprecated")
    PVSSboolean isDuplicateAlias(const CharString &text, const DpIdentifier &dp,  LanguageIdType lang);
    
  private:

    /// copy constructor
    AliasTable(AliasTable &) {}

    /// assignment operator
    AliasTable & operator=(const AliasTableItem &) {return *this;}

    /// data members
    DynPtrArrayIndex currentIndex; 
    LanguageIdType iteratorLang;

    /// alias sorted by dp
    AliasTableSet idSet;                
    
    // AliasTableSet AliasActSet;          // alias sorted by Resources::getActiveLang()
    
    /// alias sorted by Resources::getParamLang()
    AliasTableSet aliasParamSet;        
    
    AliasTableItem dummy;

    /// number of aliases
    unsigned  nofAlias; 

    /// size of alias strings
    unsigned  strsizeAlias;             
    
    /// number of comments
    unsigned  nofComment; 

    /// size of comments strings
    unsigned  strsizeComment;           

    // security plugin callbacks (cannot be caught in libManager)
    static bool (*securityPluginGetAllAliasesFct)(const DpIdentifier &dpId);

friend class UNIT_TEST_FRIEND_CLASS;
};

//------------------------------------------------------------------------------
// inline methods:

inline void AliasTable::setSecurityPluginGetAllAliasesFct(bool (*fct)(const DpIdentifier &dpId))
{
  securityPluginGetAllAliasesFct = fct;
}

#endif /* _ALIASTABLE_H_ */
