#ifndef _OPEXPR_H_
#define _OPEXPR_H_

#include <CtrlExpr.hxx>


/*  author VERANTWORTUNG: Martin Koller       */
/** Klasse fuer div. Operationen */
class DLLEXP_CTRL OpExpr : public CtrlExpr
{
  public:
    /// Returns the type of the Expression
    virtual ExprType isA() const { return OP_EXPR; }

    /// Operatoren
    enum OpType
    {
      // ==
      EQUAL,                 
      // !=
      NOT_EQUAL,             
      // >
      GREATER,               
      // <
      LESS,               
      // >=
      GREATER_EQUAL,
      // <=
      LESS_EQUAL, 
      // &&
      AND_AND,       
      // ||
      OR_OR,

    /* ADD must be the first non-boolean opType */

      // +
      ADD,    
      // -
      SUB, 
      // *
      MULT, 
      // /
      DIV,
      // %
      MOD,
      // &
      BITAND,                
      // |
      BITOR,                 
      // ^
      BITXOR,                
      // <<
      LSHIFT,                
      // >>
      RSHIFT                 
    };

    /** Constructor: Wird beim Parsen aufgerufen.
      * @param  l   linker Ausdruck
      * @param type operator OpType
      * @param  r   rechter Ausdruck
      * @param line     In welcher Zeile des Sourcefiles steht diese Expr?
      * @param filenum  Wenn es ein Library-File war die Nr. der Library
                        Damit kann der Name ermittelt werden.
      */
    OpExpr(CtrlExpr *l, OpType type, CtrlExpr *r, int line, int filenum)
      : CtrlExpr(line, filenum), opType(type), left(l), right(r) 
    {
      // Always evaluate both expressions beforehand. 
      // Except in the case of '&&' and '||'.
      if (left && opType != AND_AND && opType != OR_OR)
        left->setNext(right);
    }
     
    /// Destructor
    virtual ~OpExpr();

    /// Get the first (left) expression to evaluate
    virtual const CtrlExpr * getFirstExpr(CtrlThread *) const;

    /** auswerten der Expr.
      * @return Ptr auf Variable die das Ergebnis zugewiesen bekommt
      *         tritt ein Fehler auf wird ein Ptr auf eine dummy IntegerVar 
      *         zur�ckgegeben -> immer != NULL
      * @param thread der Thread der dieses Statement ausf�hrt
      */
    virtual const Variable *evaluate(CtrlThread *thread) const;

    /// Execute this statement.
    virtual const CtrlSment *execute(CtrlThread *thread) const;
    
    /** auswerten der Expr.
      * @return Ptr auf Variable die das Ergebnis zugewiesen bekommt
      *         tritt ein Fehler auf wird ein Ptr auf eine dummy IntegerVar 
      *         zur�ckgegeben -> immer != NULL
      * @param lval    IN: linke Variable
      * @param opType  IN: operator
      * @param rval    IN: rechte Variable
      */
    static const Variable *evaluate(const Variable *lval, OpType opType, const Variable *rval, CtrlThread *thread = 0);

    /** returns the optimal CtrlExpr depending on the parameters. 
      * If left and right operands are constants, it evaluates the operation and
      * returns a new ConstExpr, otherwise a pointer to an OpExpr
      * (on division by zero, it returns a 0-pointer)
      */
    static CtrlExpr *getOptimized(CtrlExpr *l, OpType type, CtrlExpr *r);

    /// Gewichtung des CtrlSment
    virtual SmentWeight getWeight() const { return SM_WT_Low; }
    static const char * opTypeToName(OpType opType);

    virtual void writeTrace(CtrlThread *thread, bool writeValue = true) const;

    virtual bool checkIntegrity(const CharString &location, CtrlThread *) const;

  private:
    OpType    opType;
    CtrlExpr *left;
    CtrlExpr *right;
};

#endif /* _OPEXPR_H_ */
