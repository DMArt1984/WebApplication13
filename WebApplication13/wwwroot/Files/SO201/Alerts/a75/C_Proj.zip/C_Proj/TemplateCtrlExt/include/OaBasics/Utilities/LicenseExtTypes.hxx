#ifndef _LICENSEEXTTYPES_H_
#define _LICENSEEXTTYPES_H_

//------------------------------------------------------------------------------

#include <map>
#include <string>

namespace CodeMeter
{
namespace Types
{
  using DescriptorStatus = std::pair<int, std::string>;
  using DescriptorStatusMap = std::map<std::string, DescriptorStatus>;
}
}

/// The target of the license quest
enum class QuestTarget
{
  FREE_LICENSES,
  ALL_LICENSES,
  USED_LICENSES,
  USED_OWN_LICENSES,
  FEATURE_MAP
};

#endif /* _LICENSEEXTTYPES_H_ */
