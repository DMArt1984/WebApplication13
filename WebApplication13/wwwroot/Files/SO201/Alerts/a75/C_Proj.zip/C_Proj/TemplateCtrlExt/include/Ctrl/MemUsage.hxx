#ifndef _MemUsage_H_
#define _MemUsage_H_
//COVINFO FILE: engineering (for debugging only, mkoller)

#include <QHash>
#include <QByteArray>
#include <ostream>

class CtrlScript;
class CtrlVarList;
class Variable;
class CharString;

class DLLEXP_CTRL MemUsage
{
  public:
    void add(const CtrlScript *script);
    void add(const CtrlVarList *vars);
    void add(const CtrlVarList &vars) { add(&vars); }
    void add(const QByteArray &category, size_t size);

    void report(std::ostream &to) const;

    static size_t getSize(const Variable *var);
    static size_t getSize(const CharString &s);

  private:
    struct Item
    {
      Item(size_t c = 0, size_t s = 0) : count(c), size(s) { }
      size_t count;
      size_t size;
    };
    QHash<QByteArray, Item> memHash;  // key = category
};

#endif
