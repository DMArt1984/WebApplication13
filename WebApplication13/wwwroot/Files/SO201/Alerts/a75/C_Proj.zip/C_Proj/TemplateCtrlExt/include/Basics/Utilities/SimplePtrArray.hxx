#ifndef  _SIMPLEPTRARRAY_H_
#define  _SIMPLEPTRARRAY_H_

#include <stdlib.h>
#include <string.h>
#include <NewHandler.hxx>

/**
  Internal storage management for SimplePtrArray.

  Allocates only the requested number of items, thus requiring resizing
  for every added or removed item.
 */
template<typename Item>
class SimpleStorage
{
  public:
    SimpleStorage() : arrayPtr(0), count(0) {}
   ~SimpleStorage() { clear(); }

    /**
    Resize array with new 0-pointers.
    If the memory could not be allocated, execution of the process is terminated.

    @param    newSize    Size of the new array.
    @param    cutOnly    true to cut only.

    @return unsigned int Method returns the new size
    */
    unsigned int resize(unsigned int newSize, bool cutOnly = false);

    /**
    Clears this object to its blank/initial state. All array items are deleted too.
    */

    void  clear()
    {
      while (count)
        delete arrayPtr[--count];

      if (arrayPtr)
        free (arrayPtr);

      arrayPtr = 0;
    }

    void  grab(SimpleStorage<Item> &src)
    {
      arrayPtr = src.arrayPtr;
      count    = src.count;

      src.arrayPtr = 0;
      src.count    = 0;
    }

  protected:
    Item **arrayPtr;
    unsigned int count;
};

template <typename Item>
unsigned int SimpleStorage<Item>::resize(unsigned int newSize, bool cutOnly)
{
  if (newSize > count)
  {
    Item **tmpPtr = (Item **) NewHandler::reallocHandled(arrayPtr, newSize * sizeof(Item *));
    if (tmpPtr)
    {
      arrayPtr = tmpPtr;
      memset(arrayPtr + count, 0, (newSize - count) * sizeof(Item *));
      count = newSize;
    }
  }
  else
  {
    if (!cutOnly)
    {
      for (unsigned int idx = newSize; idx < count; idx++)
        delete arrayPtr[idx];
    }

    if (newSize)
    {
      Item **newPtr = (Item **)realloc(arrayPtr, newSize * sizeof(Item *));
      if (newPtr)
      {
        arrayPtr = newPtr;
        count = newSize;
      }
    }
    else
    {
      free(arrayPtr);
      arrayPtr = 0;
      count = 0;
    }
  }
  
  return count;
}


// -----------------------------------------------------------------------------------
/// A storage class which allocates memory in larger chunks
// GCC special: Members of the base class must be accessed with "this->"
template<typename Item>
class CapacityStorage : public SimpleStorage<Item>
{
  public:
    CapacityStorage() : SimpleStorage<Item>(), capacity(0) {}
    /**
    Resize array with new 0-pointers.
    If the memory could not be allocated, execution of the process is terminated.

    @param    newSize    Size of the new array.
    @param    cutOnly    true to cut only.

    @return unsigned int Method returns the new size
    */
    unsigned int resize(unsigned int newSize, bool cutOnly = false);

    void clear()
    {
      SimpleStorage<Item>::clear();
      capacity = 0;
    }

    void  grab(CapacityStorage<Item> &src)
    {
      SimpleStorage<Item>::grab(src);

      capacity = src.capacity;
      src.capacity = 0;
    }

  protected:

    unsigned int capacity;
};


template <typename Item>
unsigned int CapacityStorage<Item>::resize(unsigned int newSize, bool cutOnly)
{
  if (newSize > capacity)
  {
    if (capacity == 0)
      capacity = newSize;
    else if (capacity < 8)
      capacity = newSize;
    else
    {
      do
      {
        capacity += capacity / 2;
      } while (capacity < newSize);
    }

    Item **tmpPtr = (Item **) NewHandler::reallocHandled(this->arrayPtr, capacity * sizeof(Item *));
    if (tmpPtr)
    {
      this->arrayPtr = tmpPtr;
      memset(this->arrayPtr + this->count, 0, (newSize - this->count) * sizeof(Item *));
    }
  }
  else if (newSize < this->count)
  {
    if (!cutOnly)
    {
      for (unsigned int idx = newSize; idx < this->count; idx++)
        delete this->arrayPtr[idx];
    }

    if (newSize)
    {
      // Resize is with factor 1.5. But we don't want to resize twice when we add an
      // item (capacity => capacity x 1.5) and then remove one. Thus the factor here
      // has to be smaller than 1 / 1.5 == 0.666, so the new capacity will be the same.
      if (newSize < 8 || newSize < capacity * 0.6)
      {
        capacity = newSize;
        this->arrayPtr = (Item **) realloc(this->arrayPtr, capacity * sizeof(Item *));
      }
    }
    else
    {
      free(this->arrayPtr);
      this->arrayPtr = 0;
      capacity = 0;
    }
  }

  this->count = newSize;

  return newSize;
}



// -----------------------------------------------------------------------------------
/**
    A simple pointer array template class (without the overhead of the DynPtrArray)
*/

// GCC Members of the base class Storage must be accessed with "this->"
template<typename Item, class Storage = SimpleStorage<Item> >
class SimplePtrArray : public Storage
{
  friend class UNIT_TEST_FRIEND_CLASS;
  public:
    /**
        Comparator base class.
    */
    struct Comparator
    {

      /** Comparison method of the comparator
        @param Item* first pointer to be compared
        @param Item* second pointer to be compared
        @return Variable with assigned value.
     */
      virtual int compare(const Item *, const Item *) const = 0;

      /**
          virtual finalizer
          @n created to satisfy gcc under linux (trausm: IM 98082)
          @brief    Finaliser.
      */
      virtual ~Comparator() {}
    };

    /**
        Function Comparator

        Comparator to encapsulate a compare function
    */
    struct FunctionComparator : public Comparator
    {

        /**
            Constructor.
            @param  compareFunction    comparison method.
        */

        FunctionComparator( int (*compareFunction)(const Item *, const Item *) )
        {comp_ = compareFunction;}

        /**
          Compares two const Item * objects to determine their relative ordering.

          @param    p1    Constant item * to be compared.
          @param    p2    Constant item * to be compared.

          @return    Negative if 'p1' is less than 'p2', 0 if they are equal, or positive if it is greater.
        */
        int compare(const Item *p1, const Item *p2) const
        {return comp_ ? (*comp_)(p1, p2) : 0;}

        /**
            A pointer to the comparison method
        */

        int (*comp_)(const Item *, const Item *);
    };


    /**
    Default constructor.
    */

    SimplePtrArray() {}


   /**
    Finaliser.
   */
   ~SimplePtrArray()  {}


    /**
    An array is released without releasing the pointers. (see also clear method)
    */

    void cutAll()
    {
      this->resize(0, true);
    }


    /**
    Gets the number of items in the array.

    @return    The number of items.
    */
    unsigned int  getNumberOfItems() const {return this->count;}

    /**
    Length of array

    @return    The number of items.
    */
    unsigned int  nofItems() const         {return this->count;}

    /**
    [] casting operator.

    @param    idx    Zero-based index of the.

    @return    Item* The pointer to the item or 0 if the item was not found or index is invalid.
    */

    Item * operator[](unsigned int idx) const {return getAt(idx);}


    /**
    Returns pointer at given index or 0 if index is invalid

    @param    idx    Zero-based index of the.

    @return    Item* null if it fails, else pointer.
    */

    Item * getAt(unsigned int idx) const
    {
      return (idx < this->count ? this->arrayPtr[idx] : 0);
    }

    /**
    Gets the first pointer of the array.

    @return    Item* null if it fails, else the first.
    */
    Item * getFirst() const {return getAt(0);}

    /**
    Gets the last pointer of the array.

    @return    Item* null if it fails, else the last.
    */
    Item * getLast()  const {return getAt(this->count-1);}

    /**
    Cuts a pointer from the array and returns it

    @return    Item* null if it fails, else the cut pointer.
    */
    Item * cutPtr(unsigned int idx);

    /**
    Cuts the first pointer from the array and returns it

    @return    Item* null if it fails, else the first cut pointer.
    */
    Item * cutFirst()                      {return cutPtr(0);}

    /**
    Cuts the last pointer from the array and returns it

    @return    Item* null if it fails, else the last cut pointer.
    */
    Item * cutLast()                       {return cutPtr(this->count-1);}

    /**
    removes an item at given index
    */
    void  remove(unsigned int idx)         {removeRange(idx, idx);}


    /**
    remove an item range [start ... end]

    @param    start    The range start.
    @param    end        The rannge end.
    */
    void  removeRange(unsigned int start, unsigned int end);


    /**
    Replaces the given position with the given pointer and return the previously stored pointer

    @param    idx                Zero-based index of the pointer to be replaced.
    @param [in,out]    itemPtr    If non-null, the item pointer.

    @return    Item* null if it fails, else the previously stored pointer.
    */
    Item * replaceAt(unsigned idx, Item *itemPtr);

    /// replace the given position with the given pointer and return the previously stored pointer
    /// or if no ptr exists set the new ptr at the given position and return 0
    Item * replaceOrSetAt(unsigned idx, Item *itemPtr);

    // Set / insert functions ============================================================

    /**
    Set item at position, but do not delete old item there

    @param    where    Index where to insert a new pointer.
                    If -1 is specified, the pointer is appended.
    @param    ptr        A new pointer.

    @return    int     A position of the new pointer.
    */
    unsigned int setPtr(unsigned int where, const Item *ptr);

    /**
    Inserts item at position where, move where ff. upwards; where == -1 is append

    @param    where    Index where to insert a new pointer.
                    If -1 is specified, the pointer is appended.
    @param    ptr        A new pointer.

    @return    int     A position of the new pointer.
    */
    unsigned int insertPtr(unsigned int where, const Item *ptr);

    /**
    Appends item to the array

    @param    ptr        A new pointer.

    @return    int     A position of the new pointer.
    */
    unsigned int append(const Item *ptr)   {return setPtr(this->count, ptr);}

    /**
    Inserts item, the array is automatically sorted then. The method returns the position
    of the item.

    @param    ptr        A new pointer.
    @param    compareFunction        A comparison method.

    @return    int     A position of the new pointer.
    */
    unsigned int insertSortPtr(const Item *ptr, int(*compareFunction)(const Item *, const Item *) )
    { return insertSortPtr(ptr, FunctionComparator(compareFunction)); }

    /**
    Inserts item, the array is automatically sorted then. The method returns the position
    of the item.

    @param    ptr        A new pointer.
    @param    Comparator        An object that implements comparison method.

    @return    int     A position of the new pointer.
    */
    unsigned  int insertSortPtr(const Item *ptr, const Comparator &com);

    /**
    Inserts or appends item, the array is automatically sorted then. The method returns the position
    of the item. The item is inserted if the array is not empty and last item is not equal to the specified
    input item.

    @param    ptr        A new pointer.
    @param    compareFunction        A comparison method.

    @return    int     A position of the new pointer.
    */
    unsigned int appendOrInsertSorted(const Item *ptr, int(*compareFunction)(const Item *, const Item *) )
    { return appendOrInsertSorted(ptr, FunctionComparator(compareFunction)); }

    /**
    Inserts or appends item, the array is automatically sorted then. The method returns the position
    of the item.The item is inserted if the array is not empty and last item is not equal to the specified
    input item.

    @param    ptr        A new pointer.
    @param    Comparator        An object that implements comparison method.

    @return    int     A position of the new pointer.
    */
    unsigned int appendOrInsertSorted(const Item *ptr, const Comparator &comp)
    {
      if ( this->count == 0 || comp.compare(getLast(), ptr) <= 0)
        return append(ptr);
      else
        return insertSortPtr(ptr, comp);
    }

    /**
    Sorts the array

    @n The quick-sort method is used

    @param    compareFunction        A comparison method.
    */
    void  sort( int (*compareFunction)(const Item *, const Item *) )
    { sort(FunctionComparator(compareFunction)); }

    /**
    Sorts the array

    @n The quick-sort method is used

    @param    Comparator        An object that implements comparison method.
    */
    void  sort(const Comparator &com);

    /**
    Sorts the array such a way that two identical Items will maintain their order

    @n The merge-sort method is used

    @param    compareFunction        A comparison method.
    */
    void stableSort( int(*compareFunction)(const Item *, const Item *) )
    { stableSort(FunctionComparator(compareFunction)); }

    /**
    Sorts the array such a way that two identical Items will maintain their order

    @n The merge-sort method is used

    @param    Comparator        An object that implements comparison method.
    */
    void stableSort(const Comparator &comp);


    /**
    Finds the first occurance of a item and returns its index

    @param    ptr        A key to be searched for.
    @param    compareFunction        A comparison method.

    @return    int     A position of the searched pointer or -1 if not found.
    */
    unsigned int findItem(const Item *key, int (*compareFunction)(const Item *, const Item *), bool isAscending = true) const
    {
      unsigned int before, after; return findItem(key, before, after, compareFunction, isAscending);
    }

    /**
    Finds the first occurance of a item and returns its index

    @param    ptr        A key to be searched for.
    @param    Comparator        An object that implements comparison method.

    @return    int     A position of the searched pointer or -1 if not found.
    */
    unsigned int findItem(const Item *key, const Comparator &comp, bool isAscending = true) const
    {
      unsigned int before, after; return findItem(key, before, after, comp, isAscending);
    }

    /**
    Finds the first occurance of a item and returns its index

    @param    ptr        A key to be searched for.
    @param  before    The index of the item that is located before the searched item.
    @param     after    The index of the item that is located after the searched item.
    @param    compareFunction        A comparison method.

    @return    int        The index of the found item or -1 if not found.
    */
    unsigned int findItem(const Item *key, unsigned int &before, unsigned int &after,
                          int (*compareFunction)(const Item *, const Item *), bool isAscending = true) const
    {
      return findItem(key, before, after, FunctionComparator(compareFunction), isAscending);
    }

    /**
    Finds the first occurance of a item and returns its index

    @param    ptr        A key to be searched for.
    @param  before    The index of the item that is located before the searched item.
    @param     after    The index of the item that is located after the searched item.
    @param    Comparator        An object that implements comparison method.

    @return    int        The index of the found item or -1 if not found.
    */
    unsigned int findItem(const Item *key, unsigned int &before, unsigned int &after,
                          const Comparator &comp, bool isAscending = true) const;

    /**
    Finds the first occurance of a item and returns this item

    @param    ptr        A key to be searched for.
    @param  before    The index of the item that is located before the searched item.
    @param     after    The index of the item that is located after the searched item.
    @param    compareFunction        A comparison method.

    @return    int        The index of the found item or NULL if not found.
    */
    Item * findAndGetItem(const Item *key, int (*compareFunction)(const Item *, const Item *), bool isAscending = true) const
    {
      return getAt(findItem(key, compareFunction, isAscending));
    }

    /**
    Finds the first occurance of a item and returns this item

    @param    ptr        A key to be searched for.
    @param  before    The index of the item that is located before the searched item.
    @param     after    The index of the item that is located after the searched item.
    @param    Comparator        An object that implements comparison method.

    @return    int        The index of the found item or NULL if not found.
    */
    Item * findAndGetItem(const Item *key, const Comparator &comp, bool isAscending = true) const
    {
      return getAt(findItem(key, comp, isAscending));
    }

    /**
    Find the index of an item in the array

    @param    ptr        A key to be searched for.

    @return    int        The index of the found item or NULL if not found.
    */
    unsigned int findPtr(const Item *ptr) const;

    /**
    Removes duplicates from the array. The array may be unsorted but you need to supply a compare function.

    @param    compareFunction        A comparison method.
    @param     isSorted    indicates if the array is sorted

    */
    void unique(int (*compareFunction)(const Item *, const Item *), bool isSorted = false)
    { unique(FunctionComparator(compareFunction), isSorted); }


    /**
    Removes duplicates from the array. The array may be unsorted but you need to supply a Comparator.

    @param    Comparator        An object that implements comparison method.
    @param     isSorted    indicates if the array is sorted

    */
    void unique(const Comparator &comp, bool isSorted = false);

  private:
    // Different sort algorithms
    void insertionSort(unsigned int first, unsigned int last, const Comparator &comp);
    void quickSort(unsigned int first, unsigned int last, const Comparator &comp);
    void mergeSort(unsigned int first, unsigned int last, const Comparator &comp);

    // Item     **this->arrayPtr;
    // unsigned int  this->count;
};


// Implementierung von SimplePtrArray
#include  <string.h>

// -----------------------------------------------------------------------------------
template <typename Item, class Storage>
unsigned int SimplePtrArray<Item, Storage>::setPtr(unsigned int where, const Item *ptr)
{
  if (where == (unsigned) -1)
    return setPtr(this->count, ptr);

  if (where >= this->count)
    this->resize(where+1);

  // Kein delete, DPA macht auch keines
  // delete this->arrayPtr[where];
  this->arrayPtr[where] = (Item *) ptr;

  return where;
}


template <typename Item, class Storage>
unsigned int SimplePtrArray<Item, Storage>::insertPtr(unsigned int where, const Item *ptr)
{
  if (where == (unsigned) -1)
    return insertPtr(this->count, ptr);

  if (where >= this->count)
    return setPtr(where, ptr);

  this->resize(this->count+1);
  memmove(this->arrayPtr+where+1, this->arrayPtr+where, (this->count - where - 1) * sizeof(Item *));
  this->arrayPtr[where] = (Item *) ptr;

  return where;
}


template <typename Item, class Storage>
unsigned int SimplePtrArray<Item, Storage>::insertSortPtr(const Item *ptr, const Comparator &comp)
{
  // Index suchen, wo eingefuegt werden soll
  unsigned int  foundIdx, beforeIdx, afterIdx;

  foundIdx = findItem(ptr, beforeIdx, afterIdx, comp);
  if (foundIdx == (unsigned) -1)
    foundIdx = (afterIdx == (unsigned) -1 ?  this->count : afterIdx);
  else
  {
    while ( ++foundIdx, getAt(foundIdx) && !comp.compare(getAt(foundIdx), ptr) )
      ;
  }

  insertPtr(foundIdx, ptr);

  return foundIdx;
}


// -----------------------------------------------------------------------------------
template <typename Item, class Storage>
Item * SimplePtrArray<Item, Storage>::cutPtr(unsigned int idx)
{
  if (idx >= this->count)
    return 0;

  Item * ptr = this->arrayPtr[idx];

  if (idx < this->count-1)
    memmove( this->arrayPtr+idx, this->arrayPtr+idx+1, (this->count - idx - 1) * sizeof(Item *) );

  this->resize(this->count - 1, true);

  return ptr;
}


// -----------------------------------------------------------------------------------
template <typename Item, class Storage>
void SimplePtrArray<Item, Storage>::removeRange(unsigned int start, unsigned int end)
{
  if (start == (unsigned int) -1 || end == (unsigned int) -1)
    return;

  if (start >= this->count || end >= this->count)
    return;

  // One item only
  if (start == end)
  {
    delete cutPtr(start);
    return;
  }

  // Normalize range
  if (start > end)
  {
    unsigned int tmp = start;
    start = end;
    end = tmp;
  }

  // Remove from start to the very end: just resize
  if (end == this->count - 1)
  {
    this->resize(start);
    return;
  }

  // Delete items
  for (unsigned int idx = start; idx <= end; idx++)
    delete getAt(idx);

  // Move tail to start
  memmove(this->arrayPtr + start, this->arrayPtr + end + 1, (this->count - end - 1) * sizeof(Item *));

  // Resize array, don't delete
  this->resize(this->count - (end - start + 1), true);
}

// -----------------------------------------------------------------------------------
template<typename Item, class Storage>
Item * SimplePtrArray<Item, Storage>::replaceAt(unsigned idx, Item *itemPtr)
{
  if (idx >= this->count)
    return 0;

  Item *tmp = this->arrayPtr[idx];
  this->arrayPtr[idx] = itemPtr;

  return tmp;
}

template<typename Item, class Storage>
Item * SimplePtrArray<Item, Storage>::replaceOrSetAt(unsigned idx, Item *itemPtr)
{
  if (idx == (unsigned) -1)
    return replaceOrSetAt(this->count, itemPtr);

  if (idx >= this->count)
    this->resize(idx+1);

  Item *tmp = this->arrayPtr[idx];
  this->arrayPtr[idx] = itemPtr;

  return tmp;
}


// -----------------------------------------------------------------------------------
template<typename Item, class Storage>
unsigned int SimplePtrArray<Item, Storage>::findItem( const Item *itemPtr,
                                             unsigned int &before, unsigned int &after,
                                             const Comparator &comp, bool isAscending) const
{
  before = after = (unsigned int) -1;

  // Don't panic if there are no items in Array
  if (!this->count)
    return (unsigned int) -1;

  Item **p  = this->arrayPtr;

  int cond = 0;
  unsigned int mid  = 0;
  unsigned int low  = 0;
  unsigned int high = this->count - 1;

  while (low <= high)
  {
    mid = low + (high - low) / 2;
    cond = comp.compare(itemPtr, p[mid]);
    if ( (isAscending ? (cond < 0) : (cond > 0)) )
    {
      if (mid == low)
        break;
      high = mid - 1;
    }
    else if ( (isAscending ? (cond > 0) : (cond < 0)) )
    {
      if (mid == high)
        break;
      low = mid + 1;

      // if (low == 0)
      //   break;
    }
    else
    {
      // Goto first Item
      Item **ptr = (Item **) (p + mid - 1);

      while ( mid && ! comp.compare(itemPtr, *ptr) )
      {
        ptr--;
        mid--;
      }

      before = mid ? mid -1 : (unsigned int) -1;
      after  = mid < (this->count - 1) ? mid +1 : (unsigned int) -1;

      return mid;
    }
  }

  if ( (isAscending ? (cond < 0) : (cond > 0)) )
  {
    before = mid ? mid -1 : (unsigned int) -1;
    after  = mid;
  }
  else
  {
    before = mid;
    after  = mid < (this->count - 1) ? mid +1 : (unsigned int) -1;
  }

  return (unsigned int) -1;
}

// -----------------------------------------------------------------------------------
template <typename Item, class Storage>
unsigned int SimplePtrArray<Item, Storage>::findPtr(const Item *ptr) const
{
  for (unsigned int idx = this->count; idx--; )
  {
    if (getAt(idx) == ptr)
      return idx;
  }

  return  (unsigned int) -1;
}
// -----------------------------------------------------------------------------------

template <typename Item, class Storage>
void SimplePtrArray<Item, Storage>::insertionSort(unsigned int first, unsigned int last, const Comparator &comp)
{
  if (last <= first)
    return;

  Item *prevVal = this->arrayPtr[first];
  Item *curVal;

  for (unsigned int indx = first + 1; indx <= last; ++indx)
  {
    curVal = this->arrayPtr[indx];

    if ( comp.compare(prevVal, curVal) > 0 )
    {
      // Out of order: this->arrayPtr[indx-1] > this->arrayPtr[indx]
      unsigned int  indx2;
      this->arrayPtr[indx] = prevVal;  // Move up larger item first

      for (indx2 = indx - 1; indx2 > first; indx2--)
      {
        Item *tempVal = this->arrayPtr[indx2-1];

        if ( comp.compare(tempVal, curVal) > 0 )
        {
          // Still out of order, move 1 up
          this->arrayPtr[indx2] = tempVal;
        }
        else
          break;
      } // for (indx2)

      this->arrayPtr[indx2] = curVal;
    }
    else
    {
      // In order, advance to next element
      prevVal = curVal;
    }
  }
}


template <typename Item, class Storage>
void SimplePtrArray<Item, Storage>::quickSort(unsigned int first, unsigned int last, const Comparator &comp)
{
  if (last <= first)
    return;

  if (last - first <= 16)
  {
    insertionSort(first, last, comp);
    return;
  }

# define  swap(x, y) {Item *tmp = this->arrayPtr[x]; this->arrayPtr[x] = this->arrayPtr[y]; this->arrayPtr[y] = tmp;}

  unsigned int  up = last, down = first;
  unsigned int  med = (first + last) >> 1;

  // Choose pivot from first, last and median position
  if ( comp.compare(this->arrayPtr[first], this->arrayPtr[last]) > 0)
    swap(first, last);

  if ( comp.compare(this->arrayPtr[first], this->arrayPtr[med]) > 0 )
    swap(first, med);

  if ( comp.compare(this->arrayPtr[med], this->arrayPtr[last]) > 0)
    swap(med, last);

  Item *pivot = this->arrayPtr[med];

  for (;;)
  {
    while ( comp.compare(pivot, this->arrayPtr[++down]) > 0 );
    while ( comp.compare(this->arrayPtr[--up], pivot) > 0 );

    if (up > down)
      swap(down, up)
    else
      break;
  }

  // Sort smaller partition first, then the larger
  if ( (up - first + 1) >= (last - up) )
  {
    quickSort(up+1, last, comp);
    quickSort(first, up, comp);
  }
  else
  {
    quickSort(first, up, comp);
    quickSort(up+1, last, comp);
  }

# undef  swap
}


template<typename Item, class Storage>
void SimplePtrArray<Item, Storage>::mergeSort(unsigned int first, unsigned int last, const Comparator &comp)
{
  if (last <= first)
    return;

  const unsigned int INSERTION_SORT_BOUND = 16; // boundary point to use insertion sort

  unsigned int span;   // step width
  unsigned int lb;     // lower bound
  unsigned int ub;     // upper bound
  unsigned int indx;
  unsigned int indx2;
  unsigned int len = last - first + 1;

  span = INSERTION_SORT_BOUND;

  // insertion sort the first pass
  {
    for (lb = first; lb <= last; lb += span)
    {
      if ((ub = lb + span - 1) > last)
        ub = last;

      insertionSort(lb, ub, comp);
    }
  }

  // second pass merge sort
  {
    unsigned int median;
    Item** aux;

    aux = (Item**) new Item *[len / 2];

    while (span < len)
    {
      // median is the start of second file
      for (median = first + span; median <= last;)
      {
        indx2 = median - 1;
        if (comp.compare(this->arrayPtr[indx2], this->arrayPtr[median]) > 0)
        {
          // the two files are not yet sorted
          if ((ub = median + span) > last)
          {
            ub = last + 1;
          }

          // skip over the already sorted largest elements
          while (comp.compare(this->arrayPtr[--ub], this->arrayPtr[indx2]) >= 0)
          {
          }

          // copy second file into buffer
          for (indx = first; indx2 < ub; ++indx)
          {
            aux[indx - first] = this->arrayPtr[++indx2];
          }
          --indx;
          indx2 = median - 1;
          lb = median - span;
          // merge two files into one
          for (;;)
          {
            if (comp.compare(aux[indx - first], this->arrayPtr[indx2]) >= 0)
            {
              this->arrayPtr[ub--] = aux[indx - first];
              if (indx > first)
                --indx;
              else
              {
                // second file exhausted
                for (;;)
                {
                  this->arrayPtr[ub--] = this->arrayPtr[indx2];
                  if (indx2 > lb)
                   --indx2;
                  else
                    goto mydone; // done
                }
              }
            }
            else
            {
              this->arrayPtr[ub--] = this->arrayPtr[indx2];
              if (indx2 > lb)
                --indx2;
              else
              {
                // first file exhausted
                for (;;)
                {
                  this->arrayPtr[ub--] = aux[indx - first];
                  if (indx > first)
                    --indx;
                  else
                    goto mydone; // done
                }
              }
            }
          } // for (;;) merge two files into one
        }
        mydone:
        median += span + span;
      }
      span += span;
    }

    delete[] aux;
  }
}


template<typename Item, class Storage>
void SimplePtrArray<Item, Storage>::sort(const Comparator &comp)
{
  // That's easy
  if (this->count <= 1)
    return;

  quickSort(0, this->count-1, comp);
}


template<typename Item, class Storage>
void SimplePtrArray<Item, Storage>::stableSort(const Comparator &comp)
{
  // That's easy
  if (this->count <= 1)
    return;

  mergeSort(0, this->count-1, comp);
}

template<typename Item, class Storage>
void SimplePtrArray<Item, Storage>::unique(const Comparator &comp, bool isSorted)
{
  if (this->count <= 1 )
    return;

  unsigned int oneBeforeLast = this->count - 1;
  for (unsigned int i = 0; i < oneBeforeLast; i++ )
  {
    if (this->arrayPtr[i] == 0)
      continue;

    unsigned int j = 0;
    for (j = i+1; j <= oneBeforeLast; j++ )
    {
      if ( comp.compare(this->arrayPtr[i], this->arrayPtr[j]) == 0 )
      {
         remove(j);
         j--;
         oneBeforeLast--;
      }
      else if (isSorted)
      {
        break;
      }
    }
  }
}

#endif
