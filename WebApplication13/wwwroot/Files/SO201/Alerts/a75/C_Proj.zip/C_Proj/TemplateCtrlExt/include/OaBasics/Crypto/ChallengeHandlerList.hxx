// -----------------------------------------------------------------------------
// creator: Andras Horvath - 01.09.2017
// purpose: Holds a list of SSA Challenge Handlers
// -----------------------------------------------------------------------------
#ifndef _CHALLENGEHANDLERLIST_HXX_
#define _CHALLENGEHANDLERLIST_HXX_

#include <string>
#include <vector>
#include <ChallengeHandler.hxx>
#include <ChallengeHandlerFactory.hxx>

/**
  @class ChallengeHandlerList
  @brief The ChallengeHandlerList class
         is in charge of all Challengehandlers and keeps a list of them
         the Connection needs as well as the Factory which implements how
         to create them.
         Is serialized and transmitted between client and server via json.
*/
class DLLEXP_OABASICS ChallengeHandlerList
{
public:
  /**
    @brief Constructs a ChallengeHandlerList.
    @param factory  the ChallengeHandlerFactory to be used
  */
  explicit ChallengeHandlerList(const ChallengeHandlerFactory& factory);

  /**
    @brief Constructs a ChallengeHandlerList from JSON data.
    @param factory   the ChallengeHandlerFactory to be used
    @param jsonData  the JSON data containing the list information
  */
  ChallengeHandlerList(const ChallengeHandlerFactory& factory,
                       const std::string& jsonData);

  /**
    @brief   AddChallengeHandler function of ChallengeHandlerList
             adds a challengeHandler to the member variable
             m_challengeHandlerList
    @details The function is called by ServerSideAuth::getChallenge()
    @param challengeHandler  ChallengeHandler to be added to list
    @return                  true if challengenHandler has been added to list,
                             false if challengeHandler is nullptr and wasn't
                             added to list
  */
  bool addChallengeHandler(SmartChallengeHandler challengeHandler);

  /**
    @brief   getChallenge function of ChallengeHandlerList
             calls the getChallenge() function of each ChallengeHandler in its
             list
    @details It uses the private function callHandlers for this.
    @details This function is called by ServerSideAuth::getChallenge())
    @return  true if all ChallengeHandler returned true, otherwise false
  */
  bool getChallenge();

  /**
    @brief   getResponse function of ChallengeHandlerList
             calls the getResponse() function of each ChallengeHandler in its
             list
    @details It uses the private function callHandlers for this
    @details This function is called by ServerSideAuth::getResponse()
    @return  true if all ChallengeHandler returned true, otherwise false
  */
  bool getResponse();

  /**
    @brief   checkResponse function of ChallengeHandlerList
             calls the checkResponse() function of each ChallengeHandler in its
             list
    @details It uses the private function callHandlers for this
    @details This function is called by ServerSideAuth::checkResponse()
    @return  true if all ChallengeHandler returned true, otherwise false
  */
  bool checkResponse();

  /**
    @brief   serialize function of ChallengeHandlerList
             serializes all ChallegenHandlers in its list by calling their
             getSerialized() function.
    @details It is called by ServerSideAuth::getChallenge() and
             ServerSideAuth::getResponse()
    @return  a JSON string containing all serialized ChallengeHandler
             JSON objects
  */
  std::string serialize() const;

  /**
    @brief   getIdentification function of ChallengeHandlerList
    @details For each ChallengeHandler in its list the getIdentification()
             function is called and the return values are saved to a vector.
    @details Function is called by ServerSideAuth::getChallenge() and
             ServerSideAuth::checkResponse()
    @return  vector of strings containing the identification strings
  */
  std::vector<std::string> getIdentification();

  /**
    @brief   getUsername function of ChallengeHandlerList
    @details For each ChallengeHandler in its list the getUsername() function
             is called
             The return values are then compared and only if all
             ChallengeHandlers that have username handling return the same
             username this function returns true and the username.
    @param   username returning the username of the authenticated user
    @return           if there is a valid username: true, else false
  */
  bool getUsername(std::string& username);

private:
  enum FunctionType
  {
    GETCHALLENGE,
    GETRESPONSE,
    CHECKRESPONSE
  };

  /**
    @brief callHandlers function of ChallengeHandlerList
           the function iterates through all ChallengeHandlers in
           m_challengeHandlerList and calls the function based on FunctionType
           parameter.
    @param function  enum for switch case statement
    @return          false if at least one of the ChallengeHandler
                     returns false, if none do, then true
  */
  bool callHandlers(FunctionType function);

  using ChallengeHandlerList_t = std::vector<SmartChallengeHandler>;

#ifdef _WIN32
#  pragma warning(push)
#  pragma warning(disable : 4251)
#endif
  std::unique_ptr<ChallengeHandlerList_t> m_challengeHandlerList;
#ifdef _WIN32
#  pragma warning(pop)
#endif

  const ChallengeHandlerFactory& m_factory;
};

#endif  // _CHALLENGEHANDLERLIST_HXX_
