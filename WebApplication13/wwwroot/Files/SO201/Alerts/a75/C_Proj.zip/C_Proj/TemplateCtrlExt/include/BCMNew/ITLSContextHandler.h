#ifndef _ITLSContextHandler_HXX
#define _ITLSContextHandler_HXX

#define USES_sockets
#include "ItcPrelude.h"
#include <ItcTransport.h>
#include <openssl/ssl.h>
     
/*
 * ITLSContextHandler is an abstraction layer for different stream based communication channels.
 *
 * This interface allows to separate BCM communication from low level communication protocol.
*/
class DLLEXP_BCM ITLSContextHandler
{
public:
  /// Destructor
  ITLSContextHandler():mySSL(0) { }

  /// Destructor
  virtual ~ITLSContextHandler() { }

  /// Close the low level communication channel as "I have no more data to send".
  /// @param td is the socket handle
  /// @return failure code. return = 0 means OK  
  virtual int close(int td) = 0;
  
  /// Clients may call connect to establish connection to server
  /// @param td is the socket handle
  /// @param sockAddr is the destination address
  /// @param sizeOfSockAddr is size of stucture in sockAddr
  /// @param errorNumber is an additional result code [output]
  /// @return failure code. return = 0 means pending connection  
  /// @return failure code. return > 0 means OK
  virtual int connect(int td, const sockaddr* sockAddr, size_t sizeOfSockAddr, int *errorNumber) = 0;

  /// Server accepts incomming connection request
  /// @param td is the socket handle of server port
  /// @param new_td is the socket handle of new connection [output]
  /// @param sockAddr is the address of client [output]
  /// @param addrLen is the count of writen bytes in sockAddr [output]
  /// @param blocking flag reports non-blocking I/O issue that could be ignored [output]
  /// @return failure code. return = 0 means "Accept is in pending" 
  /// @return failure code. return > 0 means "Connection is established"
  virtual int accept(int td, int *new_td, sockaddr* sockAddr, int *addrLen, bool *blocking) = 0;

  /// Server accepts incomming connection request. Some protocols request longer handshake to establish connection
  /// @param td is the socket handle of new connection
  /// @param blocking flag reports non-blocking I/O issue that could be ignored [output]
  /// @return failure code. return = 0 means "Accept is in pending" 
  /// @return failure code. return > 0 means "Connection is established"
  virtual int accept2(int td, bool *blocking) = 0;
  
  /// Read application data from the communication channel
  /// @param td is the socket handle of connection
  /// @param buff is a buffer with read data [output]
  /// @param mlen is the maximal lenght of buff may be used
  /// @param tryAgain flag reports non-blocking I/O issue that could be ignored [output]
  /// @return failure code. return = 0 means "Connection is closed" 
  /// @return failure code. return > 0 count of bytes has been read.
  virtual int read(int td, void *buff, int mlen, bool *tryAgain) = 0;

  /// Write application data to communication channel
  /// @param td is the socket handle of connection
  /// @param buff is a buffer with data to write
  /// @param len is the lenght of buff to be written
  /// @param tryAgain flag reports non-blocking I/O issue that could be ignored [output]
  /// @return failure code. return > 0 count of bytes has been writen.
  virtual int send(int td, const void *buff, int len, bool *tryAgain) = 0;

  /// Receive information about pending bytes on the communication channel
  /// @param td is the socket handle of connection
  /// @return count of bytes on the channel
  virtual int getPending(int td) = 0;

  /// Set connection to non-blocking. This function has remained for compatibility reason.
  /// @param td is the socket handle of new connection
  /// @param connOption is the flag for non-blockign. It should be fix 1.
  /// @return failure code. return >= 0 means OK
  virtual int setConnOptions(int td, itcConnection::ConnOptions opt) = 0;

  /// Get the name of the used ciphersuite
  /// @param td is the socket handle
  /// @return ciphersuite's name 
  virtual const char *getCipherSuite(int td) = 0;
  
  /// Increase a reference count for TLSContextHandler
  virtual void acquire() = 0;
  
  /// Decrease a reference count for TLSContextHandler
  virtual bool release() = 0;

protected:
  SSL *mySSL;
};

#endif

