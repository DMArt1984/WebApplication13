#ifndef _ERRORVAR_H_
#define _ERRORVAR_H_

/*
VERANTWORTUNG: Heinz Meissl          
BESCHREIBUNG: Variablen-Klasse die einen Error enthaelt.
*/

#ifndef _VARIABLE_H_
#include <Variable.hxx>
#endif

#ifndef _CHARSTRING_H_
#include <CharString.hxx>
#endif

#ifndef _DYNVAR_H_
#include <DynVar.hxx>
#endif
 
class ErrClass;

/** The error variable. This class is designed to hold an error class instance for
    throwing errors in CtrlMan.
*/
class DLLEXP_BASICS ErrorVar : public Variable
{
  public:
    /** Constructor.
        @param aError Pointer to a variable of type ErrClass.
    */  
    ErrorVar( ErrClass *aError = 0 );
    
    /** Constructor.
        @param errVar Reference to a variable of type ErrorVar.
    */  
    ErrorVar( const ErrorVar &errVar );
    
    /** Destructor.
    */ 
    ~ErrorVar();

    /** Declares new and delete operator.
    */
    AllocatorDecl;
    
    /** Outputs ErrorVar value to the itcNdrUbSend stream.
        @param ndrStream Output stream.
        @param errVar Streamed ErrorVar variable.
        @return itcNdrUbSend stream.
    */
    friend DLLEXP_BASICS itcNdrUbSend &operator<<( itcNdrUbSend &ndrStream, const ErrorVar &errVar );
    
    /** Receives the ErrorVar value from the itcNdrUbReceive stream.
        @param ndrStream input stream.
        @param errVar ErrorVar variable receiving the value from the stream.
        @return itcNdrUbReceive stream.
    */    
    friend DLLEXP_BASICS itcNdrUbReceive &operator>>( itcNdrUbReceive &ndrStream, ErrorVar &errVar );
    
    /** Write value to the output stream.
        @param ofStream std::ostream to write to.
    */  
    virtual void outToFile( std::ostream &ofStream ) const;
    
    /** Read value from the input stream.
        @param ifStream std::istream to read the value from.
    */    
    virtual void inFromFile( std::istream &ifStream );
    
    /** Format the value acording to the format string.
        @param  format  The format string. If the string is not empty it is
                used as an argument to the sprintf function.
                Else a default is used.
        @return The string representation of the value.
    */
    virtual CharString formatValue(const CharString &format) const;
 
    /** Format the value according to a format string.
        @param format The format string. If the string is not empty is is
               used as an argument to the sprintf function.
               Else a default is used.
        @param target This is a buffer with length len, which is directly written to.
               This method is more performant than the one which returns a CharString,
               because no alloc is done.
        @param len Size of the output buffer.
        @return Number of bytes written into target without 0-byte,
                or a negative value on error (like buffer too small).
    */
    virtual int formatValue(const CharString &format, char *target, size_t len) const;

    /** Creates a new ErrorVar variable.
        @return Variable* pointer to a newly allocated ErrorVar created with the
        default contructor.
    */
    virtual Variable *allocate() const { return new ErrorVar; }

    /** Overloaded function returning ERROR_VAR.
        @return VariableType.
    */   
    virtual VariableType isAUncached() const { return ERROR_VAR; }
    
     /** Returns the VariableType for the specified type.
         @param varType VariableType.
         @return VariableType for this type.
    */   
    virtual VariableType isAUncached( VariableType varType ) const;
    
    /** Clone the current variable object.
        @return Variable* pointer to a newly created ErrorVar with the same value,
        created by the copy constructor.
    */
    virtual Variable *clone() const;
    
    /** Equality operator.
        @param errVar Compared value.
        @return int 1 if the values are equal, otherwise 0.
        @n Important: this operator checks the VariableType, so two objects are equal only if
        they also have the same class (no conversion is done; see other operators)
    */
    virtual int operator==( const Variable &errVar ) const;
    
    /** Overloaded assignment operator used for type conversions.
        @param errVar Assigned value.
        @return Variable with assigned value.
    */
    virtual Variable &operator=( const Variable &errVar );
    
    /** Assignment operator.
        @param errVar ErrorVar assigned value.
        @return ErrorVar with the assigned value.
    */
    ErrorVar &operator=( const ErrorVar &errVar );
    
    /** Get the internally stored ErrClass.
        @return ErrClass member variable.
    */
    ErrClass &getError() const { return *myError; }
    
    /** Set the internally stored ErrClass. Deep copy is performed.
        @param aError New ErrClass to be set.
    */
    void setError( const ErrClass &aError );
    
    /** Set the internally stored ErrClass, the ErrClass is captured (shallow copy).
        @param aError ErrClass* to a new data.
    */
    void setError( ErrClass *aError );

    /** Get the value of the variable.
        @return Reference to the internally stored ErrClass value.
    */
    ErrClass &getValue() const { return getError(); }
    
    /** Set the value of the variable.
        @param aError Reference to the ErrClass which will be copied to the private member.
    */
    void setValue(const ErrClass &aError) { setError(aError); }

    // Internal use only
    /** Set the stack trace.
        @param stack Reference to the DynVar.
    */
    void setStackTrace(const DynVar &stack) {stackTrace_ = stack;}
    
    /** Get the stack trace.
        @return Reference to the DynVar.
    */    
    const DynVar & getStackTrace() {return stackTrace_;}
    
  private:
  
    void outNdrUb( itcNdrUbSend &ndrStream ) const;
    void inNdrUb( itcNdrUbReceive &ndrStream );
    
    ErrClass *myError;

    DynVar stackTrace_;
};

// ----------------------------------------------------------------------------------


#endif /* _ERRORVAR_H_ */
