#ifndef _CHARSTRING_H_
#define _CHARSTRING_H_

#include <Types.hxx>

#include <iostream>

#include <string.h>
#include <vector>

#include <Codepoint.hxx>
#include <Allocator.hxx>

#ifndef NO_BCM
class itcNdrUbSend;
class itcNdrUbReceive;
#endif

#ifdef QT_NAMESPACE
namespace QT_NAMESPACE { class QString; } using QT_NAMESPACE::QString;
#else
class QString;
#endif

// ========== CharString ============================================================

/** PVSS implementation of a string class
    This class covers a performant string and a lot of utility functions
    as well as stream operators.
    @classification public use
*/
class DLLEXP_BASICS CharString
{
  public:
    friend class UNIT_TEST_FRIEND_CLASS;
    friend class LangTextParser;
    enum { UNKNOWN_SIZE = static_cast<size_t>(-1) };

    AllocatorDecl;

    /** constructor, initialisation with zero values
      */
    CharString();

    /** copy constructor
        @param newCharStr the CharString, which shall be copied from
      */
    CharString(const CharString &newCharStr);

    /** constructor
        @param newCharStr the array of char, which shall be copied from
        @param len the number of chars of newCharStr to copy, or -1 if all
      */
    CharString(const char *newCharStr, size_t len = (size_t)-1);

    /** copy constructor
        @param newCharStr the CharString, which shall be copied from
        @param len the number of chars of newCharStr to copy, or -1 if all
      */
    CharString(const CharString &newCharStr, size_t len);

    /** constructor, the character is converted into a string consisting of newCharStr and '\0'
        @param newCharStr the char, which shall be converted
      */
    CharString(char newCharStr);

    /** constructor, the Codepoint is converted to UTF-8 and a trailing '\0'
        @param newCP the Codepoint, which shall be converted
      */
    CharString(Codepoint newCP);

    /** constructor, the new class is the decimal representation of the argument
        @param newCharStr the int, which shall be converted
      */
    CharString(int newCharStr);

    /** constructor, the new class is the decimal representation of the argument
        @param newCharStr the unsigned int, which shall be converted
      */
    CharString(unsigned int newCharStr);

    /** constructor, the new class is the decimal representation of the argument
        @param newCharStr the long, which shall be converted
      */
    CharString(long newCharStr);

#ifndef _LP64 // Linux 64 bit uses 64bit size for long while windows long is 32bit
    /** constructor, the new class is the decimal representation of the argument
        @param newCharStr the unsigned long, which shall be converted
      */
    CharString(unsigned long newCharStr);
#endif

    /** constructor, the new class is the decimal representation of the argument
        @param newCharStr the PVSSulonglong; which shall be converted
      */
    CharString(PVSSulonglong newCharStr);
    
    /** constructor, the new class holds the argument converted to project language
        @param newCharStr the wchar_t*; which shall be converted
      */
    CharString(const wchar_t *newCharStr, size_t len = (size_t) -1);

    /** destructor
      */
    ~CharString();

    /** reserve space in the internal buffer
        @n This speeds up consecutive += or << operations etc., because no need for new/delete until this
        size is reached. Useful for sizes greater than 22 bytes, because
        this is the minimum size always available.
        This method keeps the current content intact.
        @param num the number of bytes, which shall be reserved
    */
    void reserve(size_t num);

    /** empty the string.
    */
    void clear() { setCharPtr(0); }

    /** @name Output stream operators
        @n The class behaves as an output stream.
        The argument is read from the string and then removed or set to 0 if the string length is 0
        or the string does not start with the proper representation of the argument. Integers must be
        stored as decimal numbers, floats must use a decimal point.
      */
    //@{

    /// read a char
    /// @param c the character to read
    CharString& operator>>(char &c);

    /// read an unsigned char
    /// @param c the unsigned char to read
    CharString& operator>>(unsigned char &c) { return operator>>((char&)c); }

    /// read a signed char
    /// @param c the signed character to read
    CharString& operator>>(signed char &c) { return operator>>((char&)c); }

    /// read a Codepoint
    CharString& operator>>(Codepoint &);

    /// read a long int
    CharString& operator>>(long &);

    /// read an int
    CharString& operator>>(int &);

    /// read a short int
    CharString& operator>>(short &);

    /// read an unsigned long
    CharString& operator>>(unsigned long &);

    /// read an unsigned int
    CharString& operator>>(unsigned int &);

    /// read an unsigned short int
    CharString& operator>>(unsigned short &);

    /// read a float
    CharString& operator>>(float &);

    /// read a double
    CharString& operator>>(double &);
    //@}

    /** @name Assignment operators
      */
    //@{

    /// assignment operator
    /// @param newCharStr the CharString to assign
    const CharString &operator=(const CharString &newCharStr);

    /// assignment operator, copy of the string is stored
    /// @param newCharStr the array of char to assign
    const CharString &operator=(const char* newCharStr)
      { setCharStr(newCharStr); return *this; }
    //@}
    /// compare function behaves like strcmp, but for CharString and hash
    /// TR 091210
    int compareWithHash(const CharString &str) const;

    /** @name Comparision operators
      */
    //@{

    /// compare for is equal
    /// @param str the CharString to compare with
    int operator==(const CharString &str) const
      { return (length == str.length) && (strcmp(c_str(), str.c_str()) == 0); }

    /// compare for is equal
    /// @param str the array of char to compare with
    int operator==(const char *str) const;

    /// compare for is greater
    /// @param str the array of char to compare with
    int operator> (const char *str) const;

    /// compare for is less
    /// @param str the array of char to compare with
    int operator< (const char *str) const;

    /// compare for is greater or equal
    /// @param str the array of char to compare with
    int operator>=(const char *str) const;

    /// compare for is less or equal
    /// @param str the array of char to compare with
    int operator<=(const char *str) const;

    /// compare for is not equal
    /// @param str the array of char to compare with
    int operator!=(const char *str) const { return !operator==(str); }

    /// compare for is not equal
    /// @param str the CharString to compare with
    int operator!=(const CharString &str) const { return !operator==((const CharString &)str); }

    // VC++ needs the following 5 operators!

    /// compare for is equal
    /// @param str the array of char to compare with
    int operator==(char *str) const { return operator==((const char *)str); }

    /// compare for is not equal
    /// @param str the array of char to compare with
    int operator!=(char *str) const { return !operator==((const char *)str); }

    // int operator==(      CharString &str) const { return  operator==((const CharString &)str); }

    // int operator!=(      CharString &str) const { return !operator==((const CharString &)str); }
    //@}

    /** @name Cast operators
        @n These operators cast this class to a 'char *'. You shall not append anything to the string
        because short strings are stored in the class itself and not as a pointer.
    */
    //@{

    /// cast to char *, always returns a non-0 pointer
    /// @n WARNING: if you give a '\0' to the char&, then you MUST call resetLen()
    // TODO: Make this operastor non-const
    operator char *() const;

    /// cast to const char *, always returns a non-0 pointer
    operator const char *() const;
    //@}

    /** return the string as char *, always returns a non-0 pointer
    @n WARNING: if you give a '\0' to the char&, then you MUST call resetLen()
    */
    char *data() { clearHash(); return isFixedValid() ? value.fixed : value.a.charStr; }

    /** return the string as const char *, always returns a non-0 pointer
        @n This is the same as the (const char *) cast operator,
        but simpler to write than static_cast<const char*>(myString).
    */
    const char *c_str() const { return isFixedValid() ? (value.fixed) : value.a.charStr; }

    /** @name Access operators
        @n These operators access single characters of the string. If you set the char to '\0'
        you shall call 'resetLen()'.
    */
    //@{

    /** access operator
        @return a reference to the char or to '\0' if index is beyond the string length
        This operator should only be used with integer literals as index.
        For variable indexes use size_t as type of index.
        If you set this character to '\0' you shall call 'resetLen()'.
    */
    char &operator[](int index) { return operator[]((size_t)index); }

    /** access operator
        @return a reference to the char or to '\0' if index is beyond the string length
        If you set this character to '\0' you shall call 'resetLen()'.
    */
    char &operator[](size_t index);

    /** access operator
        @return the character or '\0' if index is beyond the string length
        This operator should only be used with integer literals as index.
        For variable indexes use size_t as type of index.
    */
    char operator[](int index) const { return operator[]((size_t)index); }

    /** access operator
        @return the character or '\0' if index is beyond the string length
      */
    char operator[](size_t index) const;
    //@}

    /** check if this string is empty (has a length of 0)
        @n This is faster than comparing against "", so better use
        if ( str.isEmpty() ) ...   instead  if ( str == "" ) ...
        @return TRUE if empty, else FALSE
    */
    bool isEmpty() const { return (length == 0); }

    /** recalculates the internal stored length of the string
        @n If you put a 0-char in this you shall call this function afterwards.
    */
    void resetLen();

    /** change a character in the string
        @n This function takes care of string length if you set a '\0' with this method.
        @param pos the position, where shall be set, it must be less than the string length
        @param c the character to set
      */
    void setChar(size_t pos, char c);

    /** @name Append operators
        @n These operators append a string to the class.
      */
    //@{

    /// append a CharString
    /// @param add1 the CharString like first
    /// @param add2 the CharString to append
    friend DLLEXP_BASICS CharString operator+(const CharString &add1, const CharString &add2);

    /// append a const char*
    /// @param add1 the CharString like first
    /// @param add2 the array of char to append
    friend DLLEXP_BASICS CharString operator+(const CharString &add1, const char *add2);

    /// append to a const char*
    /// @param add1 the array of char like first
    /// @param add2 the CharString to append
    friend DLLEXP_BASICS CharString operator+(const char *add1, const CharString &add2);

    /// append a char
    /// @param add1 the CharString like first
    /// @param add2 the char to append
    friend DLLEXP_BASICS CharString operator+(const CharString &add1, char add2);

    /// append the decimal representation of an integer
    /// @param add1 the CharString like first
    /// @param add2 the int to append
    friend DLLEXP_BASICS CharString operator+(const CharString &add1, int add2);

    /// append the decimal representation of an unsigned
    /// @param add1 the CharString like first
    /// @param add2 the unsigned to append
    friend DLLEXP_BASICS CharString operator+(const CharString &add1, unsigned add2);

    /// append a string to this class
    /// @param add the array of char to append
    const CharString &operator+=(const char *add)
      { append(add); return *this; }

    /// append a CharString to this class
    /// @param add the CharString to append
    const CharString &operator+=(const CharString &add)
      { append((const char*)add, add.len()); return *this; }

    /// append a char to this class
    /// @param add the char to append
    const CharString &operator+=(char add);

    /// append a Codepoint to this class
    /// @param add the Codepoint to append
    const CharString &operator+=(const Codepoint& add);

    /// append the decimal representation of an integer to this class
    /// @param add the int to append
    const CharString &operator+=(int add);

    /// append the decimal representation of an unsigned to this class
    /// @param add the unsigned to append
    const CharString &operator+=(unsigned add);
    //@}

    /** replace a substring of this by a string.
        @param start the index of first character to be used for replaced substring
             @n It must be <= this->len() (if == len(), then it is the same as appending).
             @n If no more parameters are specified, it can be considered as truncating this
        @param removeLen the length of the substring to be replace
             @n if not given, it is determined with the this->size() - start
             @n if no more parameters are specified, it can be considered as cutting out a substring of this
             @n if removeLen is 0, it can be considered as inserting a substring into this
        @param str the string to be inserted
        @param insertLen the length of the given string
            @n If not given, it is determined with strlen(str).
    */
    void replace(size_t start, size_t removeLen = UNKNOWN_SIZE, const char* str = "", size_t insertLen = UNKNOWN_SIZE);

    /** replace a substring of this by a CharString.
        @param start the index of first character to be used for replaced substring
             @n It must be <= this->len() (if == len(), then it is the same as appending).
             @n If no more parameters are specified, it can be considered as truncating this
        @param removeLen the length of the substring to be replace
             @n if not given, it is determined with the this->size() - start
             @n if no more parameters are specified, it can be considered as cutting out a substring of this
             @n if removeLen is 0, it can be considered as inserting a substring into this
        @param str the CharString to be inserted
    */
    void replace(size_t start, size_t removeLen, const CharString &str)
    {
      replace(start, removeLen, (const char*)str, str.len());
    }

    /** insert an string into this
        @param start the index of first character to be used for inserted string
             @n It must be <= this->len() (if == len(), then it is the same as appending).
        @param str the string to be inserted
        @param len the length of the given string
            @n If not given, it is determined with strlen(str).
    */
    void insert(size_t start, const char* str, size_t len = (size_t)-1);

    /** insert a CharString into this
        @param start the index of first character to be used for inserted string
             @n It must be <= this->len() (if == len(), then it is the same as appending).
        @param str the CharString to be inserted
    */
    void insert(size_t start, const CharString &str)
      { insert(start, (const char*)str, str.len()); }

    /** append a string to this
        @param str the string to append
        @param len the length of the given string
            @n If not given, it is determined with strlen(str).
    */
    void append(const char* str, size_t len = (size_t)-1);

    /// append a CharString to this
    void append(const CharString &str) { append(str.c_str(), str.len()); }

    /** append a string to this
        @n Old compatibility method, use append() instead.
        @param str the string to append
        @param len the length of the given string
            @n If not given, it is determined with strlen(str).
    */
    void appendString(const char* str, size_t len = (size_t)-1) { append(str, len); }

    /** operator << for std stream
        @param to the stream, which to send to
        @param str the CharString, which to send
      */
    friend DLLEXP_BASICS std::ostream &operator<<(std::ostream &to, const CharString &str);

    /** operator >> for std stream
        @param from the stream, which to receive from
        @param str the CharString, which to send
      */
    friend DLLEXP_BASICS std::istream &operator>>(std::istream &from, CharString &str);

#ifndef NO_BCM
    /** operator << for itcNdrUbSend stream
        @param ndrStream the stream, which to send to
        @param str the CharString
      */
    friend DLLEXP_BASICS itcNdrUbSend &operator<<(itcNdrUbSend &ndrStream, const CharString &str);

    /** operator >> for itcNdrUbReceive stream
        @param ndrStream the stream, which to receive from
        @param str the CharString
      */
    friend DLLEXP_BASICS itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream, CharString &str);
#endif

    /** read a string from the input stream
        @n The same as operator>>(istream), but does not convert "\x" escape-sequences.
        The string must start and end with a double quote.
        @param from the stream, which to receive from
      */
    void readRawFromStream(std::istream &from);

    /** format arguments according to a format string
        @n This function is like 'sprintf' or 'CString::Format'.
        @param lpszFormat the format string
      */
    void format(const char * lpszFormat, ...);

    /** stores the given pointer
        @n The pointer shall not be deleted later.
        @param newPtr the pointer to a array of char allocated with new, a 0-pointer is allowed
        @param strLen the length of the given string
            @n If not given, it is determined with strlen(newPtr). <br>
               In this case, make sure that the array is 0-terminated.
        @param len the length of the given array (not necessarily the string up to the 0-byte)
            @n If not given, the length will be determined by strlen(newPtr). <br>
               In this case, make sure that the array is 0-terminated.
    */
    void setCharPtr(char *newPtr, size_t strLen = (size_t)-1, size_t len = (size_t)-1);

    /** get the string and set the internal string to a NULL pointer
        @n The pointer is created with 'new' and the caller is responsible to delete it.
    */
    char *cutCharPtr();

    /// return length of this CharString
    size_t len() const { return length; }

    /// return length of this CharString
    size_t size() const { return length; }

    /// return capacity of this CharString
    size_t capacity() const {return isFixedValid() ? size_t(ValueUnion::FIXLEN) : value.a.size - 2;}

    /** @name Compare functions
        @n The same as operator==.
      */
    //@{

    /// the strcmp function
    /// @param str the string to compare with
    int cmp(const char *str) const;

    /// the strncmp function
    /// @param str the string to compare with
    /// @param n the length of the string
    int ncmp(const char *str, size_t n) const;

    /// case insensitive string compare (stricmp, strcasecmp)
    /// @param str the string to compare with
    int icmp(const char *str) const;

    /** case insensitive string compare only up to n chars (strnicmp, strncasecmp)
     * @param str the string to compare with
     * @param n the length of the string
     * @remarks the length is in byte, not code points. Only complete code
     *          points are compared when Unicode support is enabled
     */
    int nicmp(const char *str, size_t n) const;
    //@}

    /** return a copy of the string
        @n The pointer is created with 'new' and the caller is responsible to delete it.
    */
    char *dup() const;

#ifndef NO_BCM
    /** return a copy of the string as a wide character string
        @n If the current language is UTF8, a conversion to UTF-16 (or UTF-32/UCS-4) is done.
        @n The pointer is created with 'new' and the caller is responsible to delete it.
        @return pointer to wide character string. Nullpointer is returned in case of a conversion error.
    */
    wchar_t *dupWCharStr() const;

#endif

    /** interpret and expand the current string to len characters
        @n The string is searched for a pattern. This pattern is then interpreted and expanded to len characters.
        The pattern may be one of the following:
        <ul>
          <li> \\fill{...}: the new string consists of repetitive copies of the argument. </li>
          <li> \\left{...}: the new string is the left aligned copy of the argument.
                Blanks are padded to the right. </li>
          <li> \\center{...}: the new string is a centered copy of the argument.
                Blanks are padded to the left and right. </li>
          <li> \\right{...}: the new string is the right aligned copy of the argument.
                Blanks are padded to the left. </li>
        </ul>
        @n Note: other characters except pattern are not passed to the output string.
        @param len the length of the new string
        @return the number of the pattern found (e.g. 1 for \\fill),
                 0 if no pattern was found, -1 in case of an error
    */
    int expand(size_t len);

    /** replace a substring with another string
        @n All occurences of the string 'what' are replaced wit the string 'with'.
        @param what the string searched for
        @param with the replacement string
        @return the number of occurences of what
    */
    int replace(const char *what, const char *with);

    /** Replaces the Codepoint at the given byte index with the given char value.
     *  This operation has worst-case complexity O(len())
     *  @param index the index of first byte to be used for inserted string,
     *               it should come from a CodepointIterator
     *  @param repl the char value to replace the Codepoint at the given index
     *  @remarks index is the byte offset in the string, not the number of codepoints
     */
    void replaceAt(size_t index, char repl) { replaceAt(index, Codepoint(repl)); }

    /** Replace the Codepoint at the given byte index with the given Codepoint.
     *  This operation has worst-case complexity O(len())
     *  @param index the index of first character to be used for inserted string,
     *               it should come from a CodepointIterator
     *  @param repl the Codepoint to replace the Codepoint at the given index
     *  @remarks index is the byte offset in the string, not the number of codepoints
     */
    void replaceAt(size_t index, const Codepoint& repl);

    /** convert each character of the string to a uppercase character
        @return the reference of the altered string, because modification is done in place
      */
    CharString &toUpper();

    /** convert each character of the string to a lowercase character
        @return the reference of the altered string, because modification is done in place
      */
    CharString &toLower();

    /** cut off leading and trailing blanks and tabs
        @param allWhiteSpaceChars if true, also remove vertical tabs, newlines, linefeeds...
        @return the reference to 'this'
    */
    CharString & trim(bool allWhiteSpaceChars = false);

    /** cut off leading and trailing blanks and tabs
        @param allWhiteSpaceChars if true, also remove vertical tabs, newlines, linefeeds...
        @return the length of the trimmed string
      */
    size_t trimLen(bool allWhiteSpaceChars = false) const;

    /** aearch for a substring starting from a given start index
        @param searchingFor the string searched for
        @param startIndex the index where to start the search
        @return the index where the string was found, or -1 if the string was not found
      */
    int indexOf(const char * searchingFor, int startIndex = 0) const;

    /** searches for a character or a code point (if current language is UTF-8) not in a character resp. code point set
        @param searchingFor the code point set searched for
        @param startIndex the byte index where to start the search
             @n If the index points in the middle of a code point, it is aligned to its beginning
             @n If the start index is out of range, -1 is returned
        @return the index where the code point was found, or -1 if the code point was not found
      */
    int indexOfOneOf(const char *searchingFor, int startIndex = 0) const;

    /** searches for a character or a code point (if current language is UTF-8) not in a character resp. code point set
        @param notSearchingFor the code point set searched for
        @param startIndex the byte index where to start the search
             @n If the index points in the middle of a code point, it is aligned to its beginning
             @n If the start index is out of range, 0 is returned
        @return the index where the code point was found, or -1 if the code point was not found
      */
    int indexOfNoneOf(const char *notSearchingFor, int startIndex = 0) const;

    /** splits a string into tokens delimited by a set of separator code points
        @param tokens collection of tokens found. Output parameter will be cleared first
        @param separators string containing a set of possible separator code points
        @return number of tokens found
    */
    unsigned tokenize(std::vector<CharString>& tokens, const char* separators) const;

    /** searches for the substring and checks if it is at the beginning
        @param prefix the substring to be expected at the beginning of the string
        @return 1 if the substring searchingFor is found at the beginning of the string,
                otherwise return 0
      */
    int startsWith(const char *prefix) const;

    /** searches for the substring and checks if it is at the end
        @param suffx the substring to be expected at the end of the string
        @return 1 if the substring searchingFor is found at the end of the string,
                otherwise return 0.
    */
    int endsWith(const char *suffx) const;

    /// check if equals
    /// @param string the string to check
    /// @return 1 if equals, else 0
    int equals(const char * string) const;

    /// check if equals
    /// @param string the string to check
    /// @param len the length of the string
    /// @return 1 if equals, else 0
    int equals(const char *string, size_t len) const;

    /** get a substring from this string [start..end], borders included
        @param start the 0 based start position of the subindex
            @n If start is larger than the string length an empty string is returned.
        @param len the length of the substring
        @return the string starting at start position and ending at the end position
    */
    CharString substring(size_t start, size_t len = UNKNOWN_SIZE) const;

    /** get the left most part of this string
        @param len the length of the substring
            @n if len exceed the current string length the whole string is returned.
        @return the left most part of this string with the specified length
    */
    CharString left(size_t len) const
      { return substring( 0, size() > len ? len : size() ); }

    /** get the right most part of this string
        @param len the length of the substring
            @n if len exceed the current string length the whole string is returned.
        @return the right most part of this string with the specified length
    */
    CharString right(size_t len) const
      { return substring( size() > len ? size() - len : 0 ); }
    /// get a hash value
    unsigned  getHashValue() const
    {
      if ( !hasValidHash() )
        setHashValue();

      return (unsigned) ( hashValue_ );
    }

    /// calculate and set the hashvalue
    void  setHashValue() const
    {
      ((CharString *) this)->hashValue_ = hash();
    }

    /// check if has valid hashvalue
    PVSSboolean  hasValidHash() const {return hashValue_ ? PVSS_TRUE : PVSS_FALSE;}

    /// share string
    void  shareString()    const;

    /// unshare string
    void  unshareString()  const;

    /** stores a COPY of the given parameter
        len .. (size_t)-1: strlen not known; else strlen(newCharStr)
        @internal
    */
    //ckneid: changed from private to public
    void setCharStr(const char *newCharStr, size_t len = (size_t)-1);

#ifndef NO_BCM
    /** conversion to QString.  
        @param out the content of the CharString is copied to the given QString 
        @return for convenience a reference to the out parameter is returned as well  
        @internal
    */
    QString &toQString(QString &out) const;
    
    /** converts the data of this CharString to a wide char string and copies it to the given buffer.
        Note: a wide char string is encoded in utf16 on platforms where wchar_t is 2 bytes wide (e.g. windows) 
        and in ucs4 on platforms where wchar_t is 4 bytes wide (most Unix systems).
        Note: This function also appends a null character to the string. 
        So the buffer allocated by the caller has to contain enough space to hold the complete string and the trailing 0 wchar_t.        
        @param outWChar the buffer that will be filled
        @return the actual length of the string in array        
        @internal
    */
    size_t toWCharStr(wchar_t *outWChar) const;

    /** stores a COPY of the given parameter
        len .. (size_t)-1: strlen not known; else wcslen(newWCharStr)
        @internal
    */
    void setWCharStr(const wchar_t *newWCharStr, size_t len = (size_t) -1);
#endif
#ifndef NO_BCM
    /** sensitive comparing: this to the given char* on the given local lang
        The global language may be multi-character encoded (UTF-8).
        In case of illegal character sequences (e.g. the string ends with a
        byte which would start a sequence), the comparison result is undefined. 
        @param lang the globale language id used for comparison
        @param str the string to compare with
        @return comparison result
    */
    int cmp(GlobalLanguageIdType lang, const char *str) const;

     /** insensitive comparing on the given local lang: compares this to the given str
        The global language may be multi-character encoded (UTF-8).
        In case of illegal character sequences (e.g. the string ends with a
        byte which would start a sequence), the comparison result is undefined. 
        @param lang the globale language id used for comparison
        @param str the string to compare with
        @return comparison result
    */
    int icmp(GlobalLanguageIdType lang, const char *str) const;

     /** sensitive comparing: this to the given char* on the given local lang
        The global language may be multi-character encoded (UTF-8).
        In case of illegal character sequences (e.g. the substring determined by parameter n
        ends with a byte which would start a sequence), the comparison result is undefined. 
        @param lang the globale language id used for comparison
        @param str the string to compare with
        @param n the byte length of the string
        @return comparison result
    */
    int ncmp(GlobalLanguageIdType lang, const char *str, size_t n) const;

    /** insensitive comparing on the given local lang: compares this to the given str
        The global language may be multi-character encoded (UTF-8).
        In case of illegal character sequences (e.g. the substring determined by parameter n
        ends with a byte which would start a sequence), the comparison result is undefined. 
        @param lang the globale language id used for comparison
        @param str the string to compare with
        @param n the byte length of the string
        @return comparison result
    */
    int nicmp(GlobalLanguageIdType lang, const char *str, size_t n) const;

    /** enum type to the normalize function - it is a copy from QT - QString::NormalizationForm
    */
    enum NormalizationForm
    {
      NormalizationFormD,
      NormalizationFormC,
      NormalizationFormKD,
      NormalizationFormKC
    };

    /** Normalize the string of this CharString. ActualLang must be an UTF8 string and this CharString must be an UTF8 string too, otherwise does it nothing.
        @param mode is the "normalize form" which is described in Unicode Standard Annex #15
    */
    PVSSboolean normalize(NormalizationForm mode);

    /** return a copy of the string as a STL wide character string
        @n If the current language is UTF8, a conversion to UTF-16 (or UTF-32/UCS-4) is done.
        @return STL wide character string. Empty string in case of a conversion error.
    */
    std::wstring getWString() const; 

#endif


  private:

#ifndef NO_BCM
    /** allocate a buffer on heap.
        If the length of the passed null-terminated string is at least n bytes,
        the buffer is filled with the first n bytes and a terminating null byte.
        Otherwise, the passed null-terminated string is copied to the buffer.
        @param str null-terminated string, which could have any encoding
        @param n the maximum length of the resulting string in the buffer
        @return the buffer with the character string.
                The caller is responsible to delete the buffer.
    */
    char *allocateStartString(const char *str, size_t n) const;

    /** allocate a buffer on heap.
        The buffer is filled with the the passed null-terminated string
        translated to lower letters.
        @param str null-terminated string, where the encoding is expected to be iso. 
        @return the buffer with the character string.
                The caller is responsible to delete the buffer.
    */
    char *allocateLowerString(const char *str) const;

    /** compare the given character strings using the given locale,
        either case-sensitive or case-insensitive.
        Posix function strcoll is used for comparison.
        @param lang the globale language id used for comparison
        @param str1 the first string to compare with
        @param str2 the second string to compare with
        @param caseSensitive flag whether to compare case-sensitive or case-insensitive
        @return comparison result
    */
    int cmpPosix(GlobalLanguageIdType lang, const char *str1, const char *str2, bool caseSensitive) const;

#if defined (_WIN32)
    /** compare the given character strings using the given locale,
        either case-sensitive or case-insensitive.
        Windows wide character functions are used for comparison.
        @param lang the globale language id used for comparison
        @param str1 the first string to compare with
        @param str2 the second string to compare with
        @param caseSensitive flag whether to compare case-sensitive or case-insensitive
        @return comparison result
    */
    int cmpWindows(GlobalLanguageIdType lang, const char *str1, const char *str2, bool caseSensitive) const;
#endif

    /** compare the given character strings using the given locale,
        either case-sensitive or case-insensitive.
        @param lang the globale language id used for comparison
        @param str1 the first string to compare with
        @param str2 the second string to compare with
        @param caseSensitive flag whether to compare case-sensitive or case-insensitive
        @return comparison result
    */
    int cmp(GlobalLanguageIdType lang, const char *str1, const char *str2, bool caseSensitive) const;

#endif

    enum
    {
      HASH_MASK   = 0x3FFFFFFF  // 30 bit bitte ;)
    };

    PVSSboolean isFixedValid() const
    {
      return fixedValid_;
    }

    PVSSboolean isFixedInvalid() const { return !fixedValid_; }

    void setFixedValid()    {fixedValid_ = 1;}
    void setFixedInvalid()  {fixedValid_ = 0;}

    void clearHash()        {hashValue_ = 0;}

    // calculate the has value
    unsigned hash() const 
    {
      unsigned val = 2166136261U;

      if (length == 0)
      {
        return 0;
      }
      else if (length <= 32)
      {
        for (const char *ptr = c_str(), *end = c_str() + 32; *ptr && ptr < end; ptr++)
          val = 16777619U * val ^ (unsigned) *ptr;
      }
      else
      {
        for (const char *ptr = c_str() , *end = c_str() + 16; *ptr && ptr < end; ptr++)
          val = 16777619U * val ^ (unsigned) *ptr;

        for (const char *ptr = c_str() + length - 16; *ptr; ptr++)
          val = 16777619U * val ^ (unsigned) *ptr;
      }

      return (val & HASH_MASK);
    }

    // Check / Modify refcount
    PVSSboolean isSharedString() const;
    PVSSuchar   decrementRefCount() const;
    PVSSuchar   getRefCount()    const;


    // helper to check if a char is considered white space;
    // all = false: space+tab; all = true: also newline, vertical tab, etc.
    bool isWhiteSpace(char c, bool all) const;

    mutable unsigned int  fixedValid_  :  1;  // string store in value.fixed
    mutable unsigned int  shareString_ :  1;  // share this string
    mutable unsigned int  hashValue_   : 30;  // hash value

    size_t length;        // strlen of this; stored for performance-reason

    // to save space, use either a fixed array up to FIXLEN chars, or if this
    // array is not used, use the memory of it to store a pointer to a
    // newly allocated char-array
    union ValueUnion
    {
      enum { FIXLEN = 23 };

      struct
      {
        char *charStr;        // pointer to a new allocated string, not using fixed[]
        size_t size;          // this holds the allocated size of *charStr (even if length is less)
      } a;
      char fixed[FIXLEN+1];   // for performance reason, do not malloc up to x chars
    } value;


    friend class CharStringTester;
};

// ----------------------------------------------------------------------------
// -- Templates using CharString
// ----------------------------------------------------------------------------

#ifdef WIN32
  #pragma warning ( push )
  #pragma warning ( disable: 4231 )
#endif

#ifdef LIBS_AS_DLL
  #include <SimplePtrArray.hxx>
  EXTERN_BASICS template class DLLEXP_BASICS SimplePtrArray<CharString>;
#endif

#ifdef WIN32
  #pragma warning ( pop )
#endif

// ----------------------------------------------------------------------------
// -- Inlines
// ----------------------------------------------------------------------------

//------------------------------------------------------------------------
// IM 97632: Camel edition (aus dem HEAD mitgenommen)
// Konstruktor; the fastest, as it does not involve calling setCharStr()

inline CharString::CharString()
 : fixedValid_(1), shareString_(0), hashValue_(0), length(0)
{
  value.fixed[0] = '\0';
  value.a.size = 0;
  value.a.charStr = 0;
}

//------------------------------------------------------------------------
// Konstruktor

inline CharString::CharString(const CharString &newCharStr)
 : fixedValid_(1), shareString_(newCharStr.shareString_),
   hashValue_(newCharStr.hashValue_), length(0)
{
  value.a.size = 0;
  value.a.charStr = 0;

  if (shareString_)
    operator=(newCharStr);
  else if (newCharStr.length <= ValueUnion::FIXLEN)
    strcpy(value.fixed, newCharStr.c_str());
  else
    setCharStr(newCharStr.c_str(), newCharStr.length);

  length = newCharStr.length;
}


//------------------------------------------------------------------------
// Konstruktor

inline CharString::CharString(const char *newCharStr, size_t len)
 : fixedValid_(1), shareString_(0), hashValue_(0), length(0)
{
  value.a.size = 0;
  value.a.charStr = 0;

  if (len == (size_t) -1)
    len = newCharStr ? strlen(newCharStr) : 0;

  if (len == 0)
  {
    value.fixed[0] = '\0';
    // length is already 0
  }
  else if (len <= ValueUnion::FIXLEN)
  {
    memcpy(value.fixed, newCharStr, len);
    value.fixed[len] = '\0';
    length = len;
  }
  else
    setCharStr(newCharStr, len);
}

//------------------------------------------------------------------------
// Destruktor

inline CharString::~CharString()
{
  if ( isFixedInvalid())
  {
    if (!decrementRefCount())
      delete [] value.a.charStr;
  }
}

//------------------------------------------------------------------------
inline PVSSboolean CharString::isSharedString() const
{
  return isFixedInvalid() && shareString_ &&
         value.a.charStr && value.a.size > length + 1;
}

//--------------------------------------------------------------------------------

inline void CharString::shareString() const
{
  // shareString ist unabhaengig davon, ob ein String ueberhaupt von
  // anderen mitverwendet werden kann. Es ist nur dieser Teil des Vertrages:
  // "Ich werden den String nicht aendern (ohne ihn vorher zu kopieren)".
  shareString_ = 1;
}

//--------------------------------------------------------------------------------

inline void CharString::unshareString() const
{
  if (!decrementRefCount())
  {
    // decrementRefCount prueft nach, ob der String ueberhaupt von
    // anderen mitverwendet wird und kann. Wenn es 0 liefert, kann
    // das sharing einfach aufgehoben werden.
    shareString_ = 0;
    return;
  }

  // Ansonsten String kopieren und Flag zuruecksetzen
  char *tmp = (char *) value.a.charStr;

  // copy string. Der Inhalt wird nicht geaendert, daher ist const OK
  ((CharString *) this)->value.a.charStr = new char[value.a.size];
  memcpy( ((CharString *) this)->value.a.charStr, tmp, value.a.size);

  shareString_ = 0;
  value.a.charStr[value.a.size-1] = 0;
}

//--------------------------------------------------------------------------------

inline PVSSuchar CharString::getRefCount() const
{
  if (!isSharedString())
    return 0;

  return value.a.charStr[value.a.size-1];
}

//--------------------------------------------------------------------------------
// decrement the ref count, return the old ref count

inline PVSSuchar CharString::decrementRefCount() const
{
  if (!isSharedString())
    return 0;

  // Just be sure ref count is not 0
  if (getRefCount() == 0)
    return 0;

  // Return OLD ref count
  return value.a.charStr[value.a.size-1]--;
}

// -----------------------------------------------------------------------
inline CharString::operator char * () const
{
  ((CharString *) this)->clearHash();  // Because a non-const pointer
  if (isSharedString())
  {
    unshareString();
    shareString();
  }

  return isFixedValid() ? (char*)(value.fixed) : value.a.charStr;
}

// -----------------------------------------------------------------------
inline CharString::operator const char * () const
{
#if 0
  // Paranoia: Someone might cast to (char *)
  ((CharString *) this)->clearHash();
  if (isSharedString())
  {
    unshareString();
    shareString();
  }
#endif
  return isFixedValid() ? value.fixed : value.a.charStr;
}

// -----------------------------------------------------------------------
inline CharString CharString::substring(size_t start, size_t len) const
{
  if (size() > start)
  { // Start position within string
    return CharString( (operator const char *()) + start, size() - start > len ? len : size() - start);
  }
  else
  { // Start position beyond string
    return CharString();
  }
}

#endif /* _CHARSTRING_H_ */

