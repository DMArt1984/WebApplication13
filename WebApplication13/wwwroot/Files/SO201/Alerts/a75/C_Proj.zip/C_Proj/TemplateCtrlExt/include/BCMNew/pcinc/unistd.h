#include <dos.h>
#include <io.h>

#define _SC_OPEN_MAX 5
