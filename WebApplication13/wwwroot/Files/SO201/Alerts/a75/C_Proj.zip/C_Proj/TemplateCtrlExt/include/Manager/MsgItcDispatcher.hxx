#ifndef _MSGITCDISPATCHER_H_
#define _MSGITCDISPATCHER_H_

#ifndef _TYPES_H_
#include <Types.hxx>
#endif

#ifndef _MANAGERIDENTIFIER_H_
#include <ManagerIdentifier.hxx>
#endif

#ifndef _DYNPTRARRAY_H_
#include <DynPtrArray.hxx>
#endif

#ifndef _PTRLIST_H_
#include <PtrList.hxx>
#endif

#ifndef _PTRLISTITEM_H_
#include <PtrListItem.hxx>
#endif

#include <TimeVar.hxx>
#include <DynVar.hxx>

#include <ItcDispatcher.h>
#include <ItcAddress.h>
#include <assert.h>
#include <ostream>
#include <set>

#define    MAXPEERS          PVSS_FD_SETSIZE
#define    MAXSERVERTYPES    8


#if defined (_WIN32)
  #include <process.h>
#elif defined (__HP)
#else
  #include <pthread.h>
#endif

class Msg;
class ErrClass;
class InitSysMsg;
class ServerItcIOHandler;
class AliveItcIOHandler;
class PeerItcIOHandler;
class itcConnection;
class Kerberos;
class itcInetSockStream;

/** Interface for Manager / Manager communication defined via ManagerIdentifier.
    Derived from the BCM itcDispatcher class.
*/

class DLLEXP_MANAGER MsgItcDispatcher : public itcDispatcher
{
  public:
  
    /// connection role types
    enum ConnectionRoleType
    {
      DATA_CONNECTION = 1,
      ALIVE_CONNECTION = 2
    };
  
    /// Access MsgItcDispatcher as singleton
    static MsgItcDispatcher *instance();

    /// Constructor
    MsgItcDispatcher();

    /// Destructor
    virtual ~MsgItcDispatcher();

    /// check the communication links
    virtual void dispatch();

    /// check the communication links but wait at maximum given time
    virtual int  dispatch(long &sec, long &usec);

    /// check the communication links but wait at maximum given time
    virtual int  dispatch(double timeout);

    virtual PVSSboolean connectAsClient(const CharString &connectString,
                                        const ManagerIdentifier &destMan,
                                        const ManagerIdentifier &hostMan);

    PVSSboolean checkConnection(const CharString &connectString,
                                const ManagerIdentifier &destMan,
                                const ManagerIdentifier &hostMan);

    /// Check if the connection to Manager man is still open and usable
    PVSSboolean isConnOpen(const ManagerIdentifier &man) const;
    /// Check if the manager is connected. The connection might not be finally established.
    PVSSboolean isConnected(const ManagerIdentifier &man) const;
    /// Check if the connection is the active one
    PVSSboolean isActiveConnection(const ManagerIdentifier &man) const;
    /// Return number of connected peers
    DynPtrArrayIndex getNumberOfConnections() const;
    /// Get manager of specified connection
    ManagerIdentifier getConnection(DynPtrArrayIndex index) const;
    /// Close connection to specified manager. Send remaining data if second parameter is true
    PVSSboolean closeConnection(const ManagerIdentifier &manager, bool doFlush = true);
    /// Abort connection to specified manager. Don't send remaining data.
    PVSSboolean abortConnection(const ManagerIdentifier &manager);

    /// Change source for connection to specified manager (Used for manager number set at runtime)
    PVSSboolean  setSource(const ManagerIdentifier &target, const ManagerIdentifier &newSource);
    /// Change target for connection to specified manager (Used for setting the replica number)
    PVSSboolean  setTarget(const ManagerIdentifier &target, const ManagerIdentifier &newTarget);

    /// Create socket for TCP communication and "identify" as mandId
    PVSSboolean installServer(const ManagerIdentifier &manId, unsigned short port);

    /// Close socket listening on port portNr. Default: close all server
    PVSSboolean closeServer(unsigned short portNr = 0);

    /// Close socket listening for alive messages on port portNr. Default: close all alive server
    PVSSboolean closeAliveServer(unsigned short portNr = 0);

    /// Create socket for Alive communication and "identify" as manId
    PVSSboolean  installAliveServer(const ManagerIdentifier &manId, unsigned short port);
    /// Set the alive timeout for a given connection
    PVSSboolean  setAliveTimeout(const ManagerIdentifier &manId, int timeout);
    /// Set the alive port of the receiver
    PVSSboolean  setAlivePort(const ManagerIdentifier &manId, unsigned short portNr);

    PVSSboolean  setVersion(const ManagerIdentifier &manId, unsigned short _version);

    PVSSboolean getVersion(const ManagerIdentifier &manId, unsigned short &version) const;

    /// Set message compression
    void  setMessageCompression(const ManagerIdentifier &manId, const CharString &type);
    CharString getMessageCompression(const ManagerIdentifier &manId) const;

    /// Check if managerId is a peer of us
    PVSSboolean  isPeer(const ManagerIdentifier &manId) const;
    /// Check if the redundant manger is a peer of us
    PVSSboolean  isRedundantPeer(const ManagerIdentifier &manId) const;
    // XXX Make private
    void removePeer(const ManagerIdentifier& managerId);

    /// Interface Manager <--> Dispatcher <--> ioHandler
    int  send(Msg &msg, PVSSushort &_msgVersion);
    void receive(const ManagerIdentifier &manId, Msg *msgPtr);
    void receive(const PeerItcIOHandler *receiver, const ManagerIdentifier &manId, Msg *msgPtr);
    void receiveAlive(const ManagerIdentifier &manId, Msg *msgPtr, itcInetAddress &ia);

    // Callbacks: new connection established
    // Client socket completed connection to server manId
    PVSSboolean connectFromClient(ManagerIdentifier &manId, itcConnection *conn);
    /// Server accepted new connection. Manager not yet known
    PVSSboolean acceptFromServer(itcConnection *conn);
    /// New connection from manId on server port completed
    PVSSboolean connectFromServer(
        ManagerIdentifier &man, itcConnection *conn,
        InitSysMsg *initSysMsg, PVSSushort msgVersion);

    /// Server get new connection for Alive mechanism
    PVSSboolean connectFromTcpAliveServer(itcInetSockStream *connPtr, bool sendCyclic, const ManagerIdentifier &dest, const ManagerIdentifier &host);
        
    /// Get the socket name of the manger manId, i.e. our own name
    CharString  getSockname(const ManagerIdentifier &manId) const;

    /// Get the sockets ip address of the manager manId, i.e. our own address
    CharString  getSockaddress(const ManagerIdentifier &manId) const;

    /// Get the next-hop peer's hostname of the manager manId
    CharString  getPeername(const ManagerIdentifier &manId) const;

    /// Get the next-hop peer's ip address of the manager manId
    CharString  getPeeraddress(const ManagerIdentifier &mandId) const;

    /// Get the end-to-end peer's hostname of the manager manId.
    CharString  getEndToEndPeername(const ManagerIdentifier &manId) const;

    /// Get the end-to-end peer's hostnames for all connections to the manager manId
    DynVar      getAllEndToEndPeernames(const ManagerIdentifier &manId) const;

    /// Get the socket name of this connection, i.e. our own name
    static CharString  getSockname(const itcConnection *connPtr);

    /// Get the socket port of this connection, i.e. our own port
    static int         getSockport(const itcConnection *connPtr);

    /// Get our own ip address of this connection
    static CharString  getSockaddress(const itcConnection *connPtr, bool withPort = false);

    /// Get the hostname of the endpoint of this connection
    static CharString  getPeername(const itcConnection *connPtr);

    /// Get the port of the endpoint of this connection
    static int         getPeerport(const itcConnection *connPtr);

    /// Get the ip address of the endpoint of this connection
    static CharString  getPeeraddress(const itcConnection *connPtr, bool withPort = false);

    // State of the manager / connection
    PVSSboolean getManagerState(const ManagerIdentifier &man) const;
    void        setManagerState(const ManagerIdentifier &man, PVSSboolean newState);

    PVSSboolean getConnectionState(const ManagerIdentifier &man) const;
    void        setConnectionState(const ManagerIdentifier &man, PVSSboolean newState);

    /// Get the timeout to send alive messages to this host
    int  getSendAliveTimeout(const ManagerIdentifier &man) const;

    /// Check peer list for alive timeouts due to the time ct
    void  checkAlive(const PVSSTime &ct);

    void  reportStatus(std::ostream &to, bool longFormat = true) const;

    PVSSboolean  handleBCMBufferOverflow(const ManagerIdentifier &manId);

     /// How many bytes are pending in the send buffer
    PVSSlong     getSendBufferLength(const ManagerIdentifier &manId);

    PVSSuserIdType getPeerUserId(const ManagerIdentifier &peerId) const;
    void         setPeerUserId(const ManagerIdentifier &peerId, PVSSuserIdType uid);
    void         clearPeerUserId(const ManagerIdentifier &peerId);

    PVSSboolean  hasKerberosSecurity(const ManagerIdentifier &peerId) const;
    int          getKerberosSecurity(const ManagerIdentifier &peerId) const;

    PVSSboolean  isSsaSecured(const ManagerIdentifier &peerId) const;

    void         setPeerDistributed(const ManagerIdentifier &peerId, bool distributed);
    bool         getPeerDistributed(const ManagerIdentifier &peerId) const;

    bool createConnection(CharString &hostname, unsigned short &portNr, itcConnection *&resConn);
    void addRowToMessage(CharString &message, const char * ns, const char * value);
    CharString createConnectionTelegram(const ConnectionRoleType connRoleType, const ManagerIdentifier &target);
    CharString createConnectionTelegramToServer(const ConnectionRoleType connRoleType, const ManagerIdentifier &target,
                                                const CharString &origHostname, unsigned short origPortNr,
                                                const CharString &myHostname);

    // Insert a new IO-Handler
    PVSSboolean insertPeer(PeerItcIOHandler* newPeer, const ManagerIdentifier &target, const ManagerIdentifier &source);

  protected:
    static void handleSignal(int in);

  private:
    static  MsgItcDispatcher *selfPtr;
    bool checkLangConfigurationRelaxed(const CharString& langs, const CharString& myLangs);

    // Mutex to access peer list
    static  PVSSboolean  acquireAliveMutex(long timeout);
    static  PVSSboolean  releaseAliveMutex();

#if defined (WIN32)
    // static HANDLE  aliveMutex;
    static CRITICAL_SECTION *aliveMutex;
#elif defined (__HP)
#else
    static pthread_mutex_t  aliveMutex;
#endif

    // Alive thread
# if defined (WIN32)
    static  void  __cdecl aliveThread(void *);
# else
    static  void *  aliveThread(void *);
# endif

    // this varibles store if a buffer overflow has appeared and the
    // corresponding manager identifier
    static PVSSboolean bufferOverflow_;
    static ManagerIdentifier bufferOverflowManId_;

    // Identifiy connected peers
    struct PeerListItem : public PtrListItem
    {
      // Interne Zusammenfassung der Daten einer Verbindung
      struct PeerListItemIntern
      {
        PeerItcIOHandler   *peerPtr;      // Connection to peer
        AliveItcIOHandler  *alivePtr;     // Alive connection to peer

        PVSSTime            recvTimeout;  // Timeout for receiving messages

        PVSSboolean         synced;       // Flag for synced connections

        PVSSboolean         aliveRecvd;   // Flag that UDP telegrams were received

        PeerListItemIntern() : peerPtr(0), alivePtr(0), synced(PVSS_FALSE), aliveRecvd(PVSS_FALSE) {}
       ~PeerListItemIntern();

        void  setPeer(PeerItcIOHandler *newPeer);
        void  checkAlive(const PVSSTime &ct);
      };

      PeerListItem(const ManagerIdentifier &dest,
                   const ManagerIdentifier &host)
        : target(dest), source(host),
          alivePort(0), recvAliveTimeout(0), sendAliveTimeout(0),
          manState(PVSS_TRUE), connState(PVSS_TRUE),
          sendPeerId(0), recvPeerId(0),
          userId(DEFAULT_USER),
          version(0),
          distributed(true),
          timeDifference(0)
      { }

      PVSSboolean  isEstablished() const;
      PVSSboolean  isConnected() const;
      PVSSboolean  sendCall(Msg &);

      void  setPeer(PeerItcIOHandler *newPeer);

      void  setSource(const ManagerIdentifier &newSource);
      void  setTarget(const ManagerIdentifier &newTarget);

      void  setMessageCompression(const CharString &type);
      CharString getMessageCompression() const;

      void  sendAliveMsg();
      void  setVersion(unsigned short _version);
      unsigned short getVersion() {return version;}
      void  setAliveTimeout(unsigned short timeout);
      void  restartReceiveTimeout(const ManagerIdentifier &manId, bool fromAlive);
      void  checkAlive(const PVSSTime &ct);
      void  closeConnection(PVSSboolean doFlush);

      void  reportStatus(std::ostream &os, bool longFormat = true) const;
      void  reportStatus(std::ostream &os, bool longFormat, const PeerListItemIntern &peer) const;
      // connected peer
      ManagerIdentifier target;
      // our identification
      ManagerIdentifier source;

      PeerListItemIntern  peer;
      PeerListItemIntern  redPeer;

      // Alive port
      unsigned short alivePort;
      // Receive alive timeout, identical for all connections
      int      recvAliveTimeout;
      // Send alive timeout, identical for all connections
      int      sendAliveTimeout;

      // Time at which alive timeout was checked last time
      PVSSTime lastChecked;

      // Time to send alive message via all connections (regular PVSS message)
      PVSSTime sendTimeout;

      // Manager state (active / passive)
      PVSSboolean  manState;
      // Connection state (active / passive)
      PVSSboolean  connState;

      // Last send peerId
      PVSSulong  sendPeerId;
      // Last recv peerId;
      PVSSulong  recvPeerId;

      // userId
      PVSSuserIdType userId;

      // Type of message compression. Must be "" if not initialized.
      CharString msgComp;

      unsigned short version;

      bool  distributed;

      double timeDifference;

      PVSSTime  nextTimeDiffCheck;
    };

    // Identify server ports
    struct DLLEXP_MANAGER ServerStruct
    {
      // Constructor
      ServerStruct() {portNr = 0; serverPtr = 0;}
      // Server role
      ManagerIdentifier serverId;
      // port no
      unsigned short    portNr;
      // Server handler
      itcIOHandler     *serverPtr;
    };

    
    // Keep-alive handling
    // "Connect" to the TCP server port of a given server
    PVSSboolean  connectAsTcpAliveClient(const CharString &connectString, bool sendCyclic, PeerListItem *itemPtr, bool isRedundant);
    
    // Keep-alive handling
    // "Connect" to the alive port of a given server
    PVSSboolean  connectAsAliveClient(const ManagerIdentifier &destId);

    // Find peer entry for a given manager
    PeerListItem * findPeer(const ManagerIdentifier &manId) const;

    // Find redundant peer entry for given manager
    PeerListItem * findRedundantPeer(const ManagerIdentifier &manId) const;

    // Remove peer entry
    void  removePeer(PeerListItem *itemPtr);

    void  checkTimeDifference(const ManagerIdentifier &manId, const Msg &msg);

    void insertServer(const ManagerIdentifier &manId, unsigned short portNr, itcIOHandler* newServer);
    void insertAlive(const ManagerIdentifier &manId, unsigned short portNr,  itcIOHandler* newServer);

    // Find the corresponding IO-Handler
    PeerItcIOHandler *getPeer(const ManagerIdentifier& managerId);
    const PeerItcIOHandler *getPeer(const ManagerIdentifier& managerId) const;

    itcIOHandler *getServer(const ManagerIdentifier &manId, unsigned short portNr);
    itcIOHandler *getAlive(const ManagerIdentifier &manId, unsigned short portNr);

    // Create a kerberos context from the ticket in context and fill in the responste into respMsg
    Kerberos * createKerberosContext(PeerItcIOHandler *pPeer,
        const CharString &context, InitSysMsg &respMsg, bool isServer);

    // Check if the peer is allowed to connect
    bool isAuthorizedToConnect(const ManagerIdentifier &target, Kerberos *krb5Ptr, PVSSuserIdType &uid);

    // Special handling of SYS_MSG_INIT
    bool handleInitSysMsg(const ManagerIdentifier &manId, InitSysMsg *msgPtr);

    bool handleSecurityChallengeResponseSysMsg(const ManagerIdentifier &manId, PeerItcIOHandler *pPeer, InitSysMsg *msgPtr, bool &integrityValidated);
    bool handleSecurityChallenge(const ManagerIdentifier &manId, PeerItcIOHandler *pPeer, InitSysMsg *respMsg, const CharString &secChallenge, bool &sendSecurityResponse);
    bool handleSecurityResponse(const ManagerIdentifier &manId, PeerItcIOHandler *pPeer, InitSysMsg *respMsg, const CharString &secResponse, bool &sendSecurityResponse, bool &requestSecurityResponse, bool &integrityValidated);
    bool handleSecurityAskNewChallenge(const ManagerIdentifier &manId, PeerItcIOHandler *pPeer, InitSysMsg *respMsg, bool &sendSecurityResponse, bool &requestSecurityResponse, bool &integrityValidated);
    
    // Send SHUTDOWN_MANAGER msg and close connection to a client not registered in MsgItcDispatcher
    void closeConnection(itcConnection *conn, const ManagerIdentifier &client, InitSysMsg &msg, const ErrClass &failureReason);

    // Signal that a connection context is fully established, call either Manager::newConnection or Manager::updateConnection
    void signalConnection(PeerListItem *itemPtr, const ManagerIdentifier &target);
    
    long  msgStatisticIntervall_;

    // XXX Todo: sorted array (DPA)
    PtrList  peerList;

    // Serverport for all managers
    ServerStruct  manServer;
    // Serverport for alive things
    ServerStruct  aliveServer;

    // Flag, ob wir im aliveCheck sind. Dann ist removePeer ein dummy
    PVSSboolean   inAliveCheck;

friend class UNIT_TEST_FRIEND_CLASS;
};

// ================================================================================
// Inline-Funktionen :

inline DynPtrArrayIndex MsgItcDispatcher::getNumberOfConnections() const
{
    return peerList.getNumberOfItems();
}

#endif /* _MSGITCDISPATCHER_H_ */
