// DATEIBESCHREIBUNG ==============================================================
// DATEINAME:       PollGroup.hxx
// VERANTWORTUNG:  Andreas Lugbauer
// BESCHREIBUNG:   Die Klasse PollGroupItem beinhaltet eine TimeVar = naechster
//                  Pollzeitpunkt und einen Zeiger auf eine PollGroup.

#ifndef _POLLGROUP_H_
#define _POLLGROUP_H_

#include <TimeVar.hxx>
#include <PollAddrItem.hxx>
#include <DynPtrArray.hxx>

/** This class holds all entries needed in the PollGroupList to execute one poll. 
  * The poll group items are held by the PollGroupList.
  * The poll is done via single requests.
  * This class operates with a TimeVar (the next poll time) and a valid
  * flag, which is used to inhibit multible error messages.
  */
class PollGroup
{
  friend class UNIT_TEST_FRIEND_CLASS;

  public:
    
  /// internal parameters of poll group
    enum {
      syncMode = 0,
      syncTime,
      pollInterval,
      active,
      trigger,
      maxConnect,  // number of DPEs to connect to
      maxDp = maxConnect,   // total number of DPEs
    };    
    
  /// type definition of enum for synchronisation mode
    typedef enum SyncMode_e { NoSync = 0, MultipleTime, TimeOfDay, DayOfWeek, DayOfMonth, OnDemand } SyncMode_t;

  /** Constructor
    * @param dpId dpId of poll group
    */
    PollGroup(DpIdType dpId);

  /** Destructor
    */
    virtual ~PollGroup ();
    
  /** Gets a polling time
    * @return actual polling time value
    */
    const TimeVar&   getPollTime() const { return pollTime_; }

  /** Gets a polling interval
    * @return actual polling interval value
    */
    const TimeVar&   getPollInterval() const { return pollInterval_; }

  /** Gets a synchronization time
    * @return actual synchronization time
    */
    const TimeVar&   getSyncTime() const { return syncTime_; }

  /** Gets a synchronization mode
    * @return actual synchronization mode
    */
    const SyncMode_t & getSyncMode() const { return syncMode_; }

  /** Sets the a polling time
    * @param tm new value of polling time to be set
    */
    void       setPollTime(const TimeVar& tm) { pollTime_ = tm; }
   
    /** Gets the name of the internal poll, where group == name of internal DP
    * @return the name of the internal poll group
    */
    const CharString & getName () const {return name_;}
    
    /** Gets the id of the internal poll, where group == id of internal DP
    * @return the id of the internal poll group
    */
    DpIdType getId () const {return dpId_;}

    /** Gets the actual polling item 
    * @return actual item in case of success otherwise return NULL
    */
    PollAddrItem * getPollItem ( );
    
    /** Get the next poll time for the group
      * after the time specified for oldPoll
      * @param oldPoll last poll time
      * @return next poll time
      */
    TimeVar getNextPollTime(TimeVar& oldPoll);
    
    /** Compare function for poll groups: compare first the polling times and if they are equal continue comparing names
      * @param g2  poll address item 2, must contain correct pointer, NULL is not handled
      * @return 0 if both items are equal(times and names of both groups)
      *         1 if > g2
      *         -1 if < g2
      */
    int compare (const PollGroup * g2) const;
    
    /** Set pollTime_ to the next poll time following after the current poll time.
      */
    void nextPollTime();
    
    /** Set pollTime_ to the next poll time after now.
      */
    void nextPollTimeFromNow();

    /** Loop over all DPEs and send name server sys message to the data manager 
    * to obtain DpIdentifier
      */
    void askDpIds ();

    /** we got a dpid, so lets get the name for it
      */
    void askDpName ();

    /** Sets the DpIdentifier for the given name
    * @param name dp name
    * @param dpId dp identifier
    * @return PVSS_TRUE if the assignment of identifier was successful otherwise return PVSS_FALSE
      */
    PVSSboolean setDpIdentifier (CharString & name, DpIdentifier & dpId);

    /** Sets the DP name for the given id
    * @param dpId dp identifier
    * @param name dp name
    * @return PVSS_TRUE if the assignment of name was successful otherwise return PVSS_FALSE
      */
    virtual PVSSboolean setDpName(DpIdentifier &dpId, CharString &name);

    /** Returns true when we have all DP Identifiers
    * @return PVSS_TRUE when all DP Identifiers are valid
    */
    PVSSboolean allIdsGot ();

    /** Connect to the poll group DPEs
    */
    void connect2Dps ();

    /** Connect to the poll group DPEs at initialisation
      * This function is called when we have a connection to the 
      * event manager. In the normal case we connect, when we have all
      * the DPIDs, but during initialisation we could not do this
      * because we have no connection to the event manager.
      */
    void connect2DpsAtInit ();
 
    /** Checks if this item is in this PollGroup
    * @param dpId DpIdentifier
    * @return PVSS_TRUE if dpId is in this PollGroup, otherwise PVSS_FALSE
    */
    PVSSboolean isPollGroupId(const DpIdentifier & dpId);

    /** Sets dp data from variable by type of data,
    * checks all groups for flag ready.
    * If we have all data, update this group. 
      * @param dpId reference to DpIdentifier
      * @param varPtr pointer to variable value
      * @return PVSS_TRUE if data were changed and group was updated
    */
    PVSSboolean answer4DpId(const DpIdentifier& dpId, Variable* varPtr );

    /** Sets dp data from variable by type of data and updates poll group list.
      * @param dpId reference to DpIdentifier
      * @param varPtr pointer to variable value
      * @return PVSS_TRUE if data were changed and group was updated
      */
    PVSSboolean hotLink2DpId(const DpIdentifier& dpId, Variable* varPtr );

    /** called when the active state of a poll group is changed,
        after the isReady flag is set. Can be overloaded to make
        certain actions, especially after a poll group is
        disabled
        @param active new active state of the poll group
    */
    virtual void activeChanged(const PVSSboolean& active ) { ; }

    /** called when the poll interval of a poll group is changed,
        after the isReady flag is set. Can be overloaded to make
        certain user defined actions
        @param pollInterval new poll interval of the poll group
    */
    virtual void pollIntervalChanged(const TimeVar& pollInterval ) { ; }

    /** Adds an address to an already existing poll group
      * @param adrPtr HWMapDpPa to add
    * @return PVSS_FALSE in case of append result = DYNPTRARRAY_INVALID, otherwise PVSS_TRUE
      */
    virtual PVSSboolean addItem (HWMapDpPa * adrPtr);

    /** Clears a poll item
      * @param idx index of poll item
      */
    virtual void clrItem (unsigned idx);

    /** Searches for the index in the addr list by HWMapDpPa
      * @param ptr pointer to HWMapDpPa
      * @return index if found
      *         -1 if not found
      */
    int findItem (HWMapDpPa * ptr);

    /** Gets address item on a certain position
      * @param idx index of position
      * @return pointer to HWMapDpPa,
      *        0 if the index does not exist
      */
    HWMapDpPa * getAt (const unsigned idx);

    /** Indicates if the group has received all data
    * @return PVSS_TRUE if poll group has received all data from internal DP
    */
    PVSSboolean isReady() {return ready_;}

  /** Indicates if the group is active
      * @return PVSS_TRUE if pollgroup is active
    */
    PVSSboolean getActive() const {return active_;}

    /** update subscription count for the given item
      * @param dpPaPtr the pointer to a HWMapDpPa object contained in the pollgroup
      * @param value the new subscription value
      */
    virtual void updateSubscriptionCount(HWMapDpPa *dpPaPtr, PVSSlong value);

    /** get the trigger state
      * @ return PVSS_TRUE if trigger has been set
      */
    PVSSboolean getTrigger() {return triggerNow_; }

    /** reset trigger flag
      */
    void resetTrigger() { triggerNow_ = PVSS_FALSE; }

    /** output debug info
      */
    void debugPrint() const;

    /** Report relevant data of a pollgroup
      */
    virtual void reportStatus(std::ostream &os);

  protected:

    /** Adds the item inactive, which means that this address is not polled.
    * @param adrPtr pointer to HWMapDpPa that is added 
    * @return PVSS_TRUE in case of success
    */
    PVSSboolean addInactiveItem ( HWMapDpPa * adrPtr);


  private:
    /** Compare function for the sorted DynPtrArray.
    * Compares poll addr item according to DpIdentifier
      * @param adr1  poll address item 1, NULL causes a crash
      * @param adr2  poll address item 2, NULL causes a crash
      * @return 0 if both items are equal
      *         1 if adr1 > adr2
      *         -1 if adr1 < adr2
      */
    static int compare (const PollAddrItem * adr1, const PollAddrItem * adr2);
    
  /** Sets dp data from variable by type of data
    * @param dpId dp identifier
    * @param varPtr pointer to variable cointains the data for setting
    */
    PVSSboolean setDataFromDp(const DpIdentifier& dpId, Variable* varPtr );
    
    // Copy constructor
    PollGroup(const PollGroup&);
    // Assignment operator
    PollGroup& operator=(const PollGroup&);

    TimeVar    pollTime_;
    TimeVar    pollInterval_;   // poll interval in ms
    TimeVar    syncTime_;
    SyncMode_t syncMode_;
    CharString name_;
    DpIdType dpId_;
    DynPtrArray<PollAddrItem> *adrList_;
    PVSSboolean active_;
    unsigned int actualItem_;

    struct IdpTag {
        CharString    dpName;     // DP-Name
        DpIdentifier  dpId;       // DP-ID
        PVSSboolean   dpIdValid;  // info if DP-ID has been set already
        PVSSboolean   ready;      // we have valid values for the DPE
    } pgIdent_[maxDp];

    PVSSboolean ready_;
    PVSSboolean needsName_;

    PVSSboolean triggerNow_;
};


#endif
