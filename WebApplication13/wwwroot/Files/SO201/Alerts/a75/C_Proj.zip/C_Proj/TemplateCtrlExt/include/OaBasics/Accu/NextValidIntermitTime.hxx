#ifndef _NEXTVALIDINTERMITTIME_H_
#define _NEXTVALIDINTERMITTIME_H_

// Author:        Wolfram Klebel
// Date:          18.8.2006

// +++++

// Description:   Functor class to retrieve times (TimeVar) meeting certain conditions
//                The conditions are passed as two lists of paired start/stop intervals.
// ---------------------------------------------------------------------------
// Usage:
// 1. Instantiate an object
//    The conditions are set to some default values
// 2. Call setConditions() to change the conditions to be met
//    Impossible conditions are not accepted and False is returned
//    Call the function-operator()() with a time to start the search
//    The search direction is an optional parameter, default is FORWARD
// ---------------------------------------------------------------------------
// Condition entry value ranges:
// 
// condition:    aWeekDayList      aDayTimeList
// VariableType: INTEGER_VAR       INTEGER_VAR
// entry range:  -2, -3, 1-7        0-86399
// default:          none               0
//
// 1-7 as aWeekDay corresponds to monday to sunday
// (-2) as aWeekDay means all days from monday to friday (mo, th, we, th, fr)
// (-3) as aWeekDay means saturday/sunday (weekend)
//
// DayTime is measured in seconds and corresponds to [00:00:00, 23:59:59]. See below! 
// ----------------------------------------------------------------------------
// A feature?!
// This functor works also with daylight saving periods. The seconds given by
// DayTime are directly mapped to a time of 24 hours, even, if a day has more
// or less than 24*3600 = 86400 seconds ( the first and last day of the daylight
// savings period ). For instance: 84600 means always 23:30:00 and 1800 means
// always 00:30:00.
// So, DayTime does not always mean the same as seconds past midnight!
// ----------------------------------------------------------------------------

#include <TimeVar.hxx>
#include <IntegerVar.hxx>
#include <DynVar.hxx>

class BC_CTime;

/// Functor class to retrieve times (TimeVar) meeting certain conditions.
/// The conditions are passed as two lists of paired start/stop intervals.
/// <p>
/// <b>Usage:</b>
/// <ol>
/// <li> Instantiate an object (the conditions are set to some default values)
/// <li> Call setConditions() to change the conditions to be met.
/// @n   Impossible conditions are not accepted and False is returned.
/// @n   Call the function-operator()() with a time to start the search.
/// @n   The search direction is an optional parameter, default is FORWARD
/// @n   Note: BACK is obsolete.
/// </ol>
/// <b>Condition entry value ranges:</b>
/// <p> aWeekDayList: DynVar array with IntegerVars representing days
/// @n -3 Weekend days (Saturday, Sunday)
/// @n -2 Work days (Monday..Friday)
/// @n 1..7 Monday..Sunday
/// <p> aDayTimeList: DynVar array with IntegerVars representing daytime in seconds
/// @n Range: 0-86399, default 0.
/// @n Note: DayTime is measured in seconds and corresponds to [00:00:00, 23:59:59]. See below! 
///
/// A feature?!
/// This functor works also with daylight saving periods. The seconds given by
/// DayTime are directly mapped to a time of 24 hours, even, if a day has more
/// or less than 24*3600 = 86400 seconds ( the first and last day of the daylight
/// savings period ). For instance: 84600 means always 23:30:00 and 1800 means
/// always 00:30:00.
/// So, DayTime does not always mean the same as seconds past midnight!
/// @classification ETM internal
class DLLEXP_OABASICS NextValidIntermitTime
{
  public:
    friend class UNIT_TEST_FRIEND_CLASS;
    /// Constructor.
    NextValidIntermitTime();
    
    /// Direction to search (now only FORWARD is valid)
    enum Direction { FORWARD /*, BACK */ };     // Back ist obsolete WOKL 30.1.08

    /// Set the conditions for the search algorithm. It is a list of intervals where
    /// days in a week and daytime (seconds past midnight) are specified.
    /// @param aWeekDayList DynVar containing pairs of IntegerVars, each pair representing
    /// a range of days (-3: weekend, -2: working days, 1-7: monday..sunday.
    /// @param aDayTimeList DynVar containing pairs of IntegerVars, each pair representing
    /// an time interval within a day, specified in seconds past midnight (0-86399).
    /// @return PVSS_TRUE if the condition can be met, PVSS_FALSE otherwise.
    PVSSboolean setConditions( const DynVar &aWeekDayList,
                               const DynVar &aDayTimeList );
  

    /// Finds a time >= startTime that meets the conditions set previously with setConditions.
    /// @param startTime Starting time.
    /// @param aDirection Direction to search (BACK is obsolete, so only the default value
    /// FORWARD is accepted.
    /// @return TimeVar containing the first time which meets the specified conditions.
    const TimeVar operator()( const TimeVar &startTime ,
                              const Direction aDirection = FORWARD );

    /// tell whether the last operator()-call was inside an interval or outside.
    /// @return PVSSboolean PVSS_TRUE if call was inside the interval.
    PVSSboolean isInInterval()  { return isInInterval_; }

  private:

    /// returns the desired TimeVar, this method is called by the TimeVar operator().
    const TimeVar getNextValidIntermitTime ( const TimeVar &startTime, const Direction aDirection = FORWARD);

    /// returns PVSS_TRUE if the condition is possible
    PVSSboolean isConditionPossible ( const DynVar &aWeekDayList,
                                      const DynVar &aDayTimeList );

    /// returns the weekdays numbers to their equivalent constants defined in the BCTime.h
    void convertToBooch( DynVar &aWeekDay );

    /// check if T is a DST change day (calls NextValidTime::getDSTChangeDay)
    PVSSboolean getChangeDay( BC_CTime &T, PVSSboolean &spring, PVSSboolean &autumn );

    /// handles the weekend days (-3) and working days (-2) pattern
    PVSSboolean dayMatch( const PVSSushort day, const IntegerVar &dayPattern );

    /// called from getNextValidIntermitTime, this method computes the desired time returned by the operator().
    PVSSboolean goNextValidListTime( TimeVar & theTime );

    /// uquivalent of getNextValidIntermitTime for backward direction (obsolete).
    PVSSboolean goPrevValidListTime( TimeVar & theTime );

    /// returns the matching TimeVar, takes the DST changes into consideration.
    TimeVar getNextMatch( const TimeVar time, long aWeekDay, long aDaySecond, bool &isAutumnMatchExact, bool &isSpringJump );
    
    /// equivalent of getNextMatch for backward direction (obsolete).
    TimeVar getPrevMatch( const TimeVar time, long aWeekDay, long aDaySecond );
    
    /// private member for the aWeekDayList condition DynVar.
    DynVar condWeekDayList_;

    /// private member for the aDayTimeList condition DynVar.
    DynVar condDayTimeList_;

    /// specifies whether the last operator()-call was inside an condition interval or outside.
    PVSSboolean  isInInterval_;
};

#endif /* _NEXTVALIDINTERMITTIME_H_ */
