#ifndef _CNSCONTAINER_H_
#define _CNSCONTAINER_H_

#include <DpIdentificationResultType.hxx>
#include <SystemNumType.hxx>
#include <CharString.hxx>
#include <ViewId.hxx>

class DpIdentification;
class CNSNodeDataHeap;
class CNSDataIdentifier;
class CNSNodeNames;
class CNSObject;
class CNSTreeNode;
class CNSViews;
class CNSView;
class CNSTree;
class CNSPath;
class ErrClass;

/**
 * Container for all CNS views of a system.
 *
 * @see CNSView
 * @internal
 */
class DLLEXP_DATAPOINT CNSContainer
{

public: 
  /**
   * Creates an empty CNSContainer 
   */
  CNSContainer();

  /// Destructor
  ~CNSContainer();

public:
  /** set the display names of a system.
   * @retval DpIdentOK
   * @retval DpIdentNoCNS If no CNS is available
   * @retval DpIdentNoSuchSystemHere The specified system does not exist
   */
  DpIdentificationResult setCNSSystemNames(SystemNumType sys, const LangText &names);

  /** get the display names of a system
   * @retval DpIdentOK
   * @retval DpIdentNoCNS If no CNS is available
   * @retval DpIdentNoSuchSystemHere The specified system does not exist
   */
  DpIdentificationResult getCNSSystemNames(SystemNumType sys, LangText &names);
  
  /* delete a view from the DpIdentification  
   * @retval DpIdentOK
   * @retval DpIdentNoCNS If no CNS is available
   * @retval DpIdentNoSuchSystemHere The specified system does not exist
   * @retval DpIdentNoSuchView The specified view does not exist
   */
  DpIdentificationResult deleteCNSView(SystemNumType sys, ViewId view);
  
  /* create a view for the DpIdentification  
   * @retval DpIdentOK
   * @retval DpIdentNoCNS If no CNS is available
   * @retval DpIdentNoSuchSystemHere The specified system does not exist
   * @retval DpIdentViewAlreadyExists The specified view already exists.
   * @retval DpIdentOutOfMemory.
   */
  DpIdentificationResult createCNSView(SystemNumType sys, const CNSView &view, ViewId viewId = 0);

  /* change the name of a view of the DpIdentification
   * @retval DpIdentOK
   * @retval DpIdentNoSuchSystemHere The specified system does not exist
   * @retval DpIdentViewAlreadyExists The new view name already exists.
   * @retval DpIdentNoSuchView The specified view does not exist
   */
  DpIdentificationResult changeCNSViewNames(SystemNumType sys, ViewId view, const CNSNodeNames &names);
  
  /* change the separators of a view of the DpIdentification
   * @retval DpIdentOK
   * @retval DpIdentNoSuchSystemHere The specified system does not exist
   * @retval DpIdentNoSuchView The specified view does not exist
   */
  DpIdentificationResult changeCNSViewSeparators(SystemNumType sys, ViewId view, const LangText &separators);
  
  /* delete a tree from the DpIdentification
   * @retval DpIdentOK
   * @retval DpIdentNoCNS If no CNS is available
   * @retval DpIdentNoSuchSystemHere The specified system does not exist
   * @retval DpIdentNoSuchView The specified view does not exist
   * @retval DpIdentNoSuchCNSNode If no node was found (wrong tree name)
   */
  DpIdentificationResult deleteCNSTree(const CNSPath &path);
  
  /* delete a tree from the DpIdentification and add a copy of the new one.
   * @retval DpIdentOK
   * @retval DpIdentNoCNS If no CNS is available
   * @retval DpIdentNoSuchSystemHere The specified system does not exist
   * @retval DpIdentNoSuchView The specified view does not exist
   * @retval DpIdentNoSuchCNSNode If no node was found (wrong tree name)
   * @retval DpIdentCNSNodeAlreadyExists If the name of newTree already exists
   * @retval DpIdentSyntaxError if newTree is NULL
   */
  DpIdentificationResult changeCNSTree(const CNSPath &del, const CNSTree &newTree);

  /* add a copy of newTree as (sub-)tree to the DpIdentification.
   * @retval DpIdentOK
   * @retval DpIdentNoCNS If no CNS is available
   * @retval DpIdentNoSuchSystemHere The specified system does not exist
   * @retval DpIdentNoSuchView The specified view does not exist
   * @retval DpIdentNoSuchCNSNode If no node was found (wrong tree name)
   * @retval DpIdentCNSNodeAlreadyExists If the name of newTree already exists
   * @retval DpIdentSyntaxError if newTree is NULL
   */
  DpIdentificationResult addCNSTree(const CNSPath &parent, const CNSTree &newTree);

  /* add a copy of tree to a view of the DpIdentification.
   * @retval DpIdentOK
   * @retval DpIdentNoCNS If no CNS is available
   * @retval DpIdentNoSuchSystemHere The specified system does not exist
   * @retval DpIdentNoSuchView The specified view does not exist
   * @retval DpIdentCNSNodeAlreadyExists If the name of newTree already exists
   * @retval DpIdentSyntaxError if tree is NULL
   */
  DpIdentificationResult createCNSTree(SystemNumType sys, ViewId view, const CNSTree &tree);

  /* add a copy of tree to a view of the DpIdentification.
   * @retval DpIdentOK
   * @retval DpIdentNoCNS If no CNS is available
   * @retval DpIdentNoSuchSystemHere The specified system does not exist
   * @retval DpIdentNoSuchView The specified view does not exist
   * @retval DpIdentCNSNodeAlreadyExists If the name of newTree already exists
   * @retval DpIdentSyntaxError if newTree is NULL
   */
  DpIdentificationResult addCNSTree(CNSView &view, const CNSTree &newTree);

  /* change the names of a CNS node in the DpIdentification.
   * @retval DpIdentOK
   * @retval DpIdentNoCNS If no CNS is available
   * @retval DpIdentNoSuchSystemHere The specified system does not exist
   * @retval DpIdentNoSuchView The specified view does not exist
   * @retval DpIdentCNSNodeAlreadyExists If the names already exists
   */
  DpIdentificationResult changeCNSNode(const CNSPath &path, const CNSNodeNames &names);

  /* change the CNSDataIdentifier of a CNS node in the DpIdentification.
   * @retval DpIdentOK
   * @retval DpIdentNoCNS If no CNS is available
   * @retval DpIdentNoSuchSystemHere The specified system does not exist
   * @retval DpIdentNoSuchView The specified view does not exist
   * @retval DpIdentNoSuchCNSNode If no node was found
   */
  DpIdentificationResult changeCNSNode(const CNSPath &path, const CNSDataIdentifier &data);

  /// get the list of all views of system sysNum.
  CNSViews *getCNSViews(SystemNumType sysNum);
  
  /// remove all views from system sysNum.
  void clearCNSViews(SystemNumType sysNum);
  
  /* get the specified view of the DpIdentification.
   * @retval DpIdentOK
   * @retval DpIdentNoCNS If no CNS is available
   * @retval DpIdentNoSuchSystemHere The specified system does not exist
   * @retval DpIdentNoSuchView The specified view does not exist
   */
  DpIdentificationResult getCNSView(SystemNumType sys, ViewId id, CNSView *&view);
  DpIdentificationResult getCNSView(const CNSPath &path, CNSView *&view);

  /**
   * Try to find a node in the local CNS structure by using as many
   * path segments from the specified path as possible.
   * Returns the last / farthest / deepest node found, and the index of
   * this node in path.getNodes().
   *
   * For example, if this method is called with the path
   * "System.View:Node1.Node2.Node3", where Node2 does exist but Node3 not,
   * it will return Node2 as node and 1 as farthestIndex.
   *
   * @param path The path used to find the node
   * @param [out] node Receives the found node
   *                   (only when DpIdentOK is returned)
   * @param farthestIndex Receives the index of the found node in path.getNodes()
   *                      (only when DpIdentOK is returned)
   *
   * @retval DpIdentOK If a node was found
   * @retval DpIdentNoCNS If no CNS is available
   * @retval DpIdentNoSuchSystemHere The specified system does not exist
   * @retval DpIdentNoSuchView The specified view does not exist
   * @retval DpIdentNoSuchCNSNode If no node was found (wrong tree name)
   */
  DpIdentificationResult getFarthestCNSTreeNode(const CNSPath &path, CNSTreeNode *&node,
                                                unsigned int &farthestIndex);

  /**
   * Returns the node at with the specified path.
   *
   * @param path The path used to find the node
   * @param [out] node Receives the found node (only when DpIdentOK is returned)
   *
   * @retval DpIdentOK If the node was found
   * @retval DpIdentNoCNS If no CNS is available
   * @retval DpIdentNoSuchSystemHere The specified system does not exist
   * @retval DpIdentNoSuchView The specified view does not exist
   * @retval DpIdentNoSuchCNSNode If the node was not found
   */
  DpIdentificationResult getCNSTreeNode(const CNSPath &path, CNSTreeNode *&node);

// validity checks
  /**
   * Checks whether the given LangText is a valid system name for the specified
   * system.
   *
   * Used criteria are:
   * - Is it a valid display name?
   * - Does it contain none of the separators of the views in the given system?
   */
  bool isValidSystemNames(const SystemNumType &sys, const LangText &systemNames);

  /**
   * Checks whether the given (sub-)tree would be valid in the specified view.
   *
   * Used criteria are:
   * - Are the names and display names of each node valid?
   * - Do none of them contain a separator of the given view?
   *
   * Duplicate names are not checked, but they will be rejected by the
   * creating methods.
   */
  bool isValidTree(const SystemNumType &sys, const ViewId &view, const CNSTree &tree);

  /**
   * Checks whether the given view would be valid in the specified system.
   *
   * Used criteria are:
   * - Are the name, display names and separators valid?
   * - Do none of the display names of the system contain their respective separator?
   *
   * Duplicate names or ids are not checked, but they will be rejected by the
   * create-method.
   */
  bool isValidView(const SystemNumType &sys, const CNSNodeNames &names,
                   const LangText &separators);

  /**
   * Similar to isValidView(), but returns an appropriate error object 
   * if the view is not valid.
   * The caller has to take ownership of the returned pointer.
   */
  ErrClass *validateView(const SystemNumType &sys, const CNSNodeNames &names,
                         const LangText &separators);

  /**
   * Prints a report of the number of elements and size of CNS to the given
   * stream.
   */
  void reportStatus(std::ostream &os);

public:
  /// Deletes all CNS names. Call only when shutting down a manager.
  static void cleanup();

  static CharString getAllSeparators();

  /// Returns true if the CNSNodeDataHeap exists
  static bool isValid() { return(cnsData_ != 0); }

  /// Returns the CNSNodeDataHeap. Call isValid() before to ensure that it exists.
  static CNSNodeDataHeap &getHeap() { return(*cnsData_); }

  /// Returns the number of instances of CNSContainer
  static PVSSulong getInstanceCount() { return(instanceCount_); }

private:
  // avoid generated default methods
  CNSContainer(const CNSContainer &);
  CNSContainer &operator=(const CNSContainer &);

  // copy the tree of the MSG to CNSContainer memory
  bool addToCNS(CNSObject &parent, const CNSTree &newTree);
  
private:
  /**
   * cnsData_ will be created with the first instance of CNSContainer and will
   * be deleted when the last instance of CNSContainer is deleted.
   */
  static CNSNodeDataHeap *cnsData_;

  /// Counts the number of instances of CNSContainer
  static PVSSulong instanceCount_;

};

#endif // _CNSCONTAINER_H_
