#ifndef _DPELEMENTTYPE_H_
#define _DPELEMENTTYPE_H_
// DATEIBESCHREIBUNG ==============================================================
// VERANTWORTUNG: Johannes Ertl
// BESCHREIBUNG:  Aufzaehlung aller Ellementtypen.
//
// ======================================Ende======================================

/// the DP Element Types
enum DpElementType {
/// (0).
  DPELEMENT_NOELEMENT,
/// (1).
  DPELEMENT_RECORD,
/// (2).
  DPELEMENT_ARRAY,
/// (3).
  DPELEMENT_DYNCHAR,
/// (4).
  DPELEMENT_DYNUINT,
/// (5).
  DPELEMENT_DYNINT,
/// (6).
  DPELEMENT_DYNFLOAT,
/// (7).
  DPELEMENT_DYNBIT,
/// (8).
  DPELEMENT_DYN32BIT,
/// (9).
  DPELEMENT_DYNTEXT,
/// (10).
  DPELEMENT_DYNTIME,
/// (11).
  DPELEMENT_CHARARRAY,
/// (12).
  DPELEMENT_UINTARRAY,
/// (13).
  DPELEMENT_INTARRAY,
/// (14).
  DPELEMENT_FLOATARRAY,
/// (15).
  DPELEMENT_BITARRAY,
/// (16).
  DPELEMENT_32BITARRAY,
/// (17).
  DPELEMENT_TEXTARRAY,
/// (18).
  DPELEMENT_TIMEARRAY,
/// (19).
  DPELEMENT_CHAR,
/// (20),
  DPELEMENT_UINT,
/// (21).
  DPELEMENT_INT,
/// (22).
  DPELEMENT_FLOAT,
/// (23).
  DPELEMENT_BIT,
/// (24).
  DPELEMENT_32BIT,
/// (25).
  DPELEMENT_TEXT,
/// (26).
  DPELEMENT_TIME,
/// (27).
  DPELEMENT_DPID,
/// (28).
  DPELEMENT_NOVALUE,
/// (29).
  DPELEMENT_DYNDPID,
/// (30).
  DPELEMENT_DYNCHARARRAY,
/// (31).
  DPELEMENT_DYNUINTARRAY,
/// (32).
  DPELEMENT_DYNINTARRAY,
/// (33).
  DPELEMENT_DYNFLOATARRAY,
/// (34).
  DPELEMENT_DYNBITARRAY,
/// (35).
  DPELEMENT_DYN32BITARRAY,
/// (36).
  DPELEMENT_DYNTEXTARRAY,
/// (37).
  DPELEMENT_DYNTIMEARRAY,
/// (38).
  DPELEMENT_DYNDPIDARRAY,
/// (39).
  DPELEMENT_DPIDARRAY,
/// (40).
  DPELEMENT_NOVALUEARRAY,
/// (41).
  DPELEMENT_TYPEREFERENCE,
/// (42).
  DPELEMENT_LANGTEXT,
/// (43).
  DPELEMENT_LANGTEXTARRAY,
/// (44).
  DPELEMENT_DYNLANGTEXT,
/// (45).
  DPELEMENT_DYNLANGTEXTARRAY,
/// (46).
  DPELEMENT_BLOB,
/// (47).
  DPELEMENT_BLOBARRAY,
/// (48).
  DPELEMENT_DYNBLOB,
/// (49).
  DPELEMENT_DYNBLOBARRAY,
// 18.07.08 esperrer IM87877: used in RDB manager
/// (50).
  DPELEMENT_64BIT,
/// (51).
  DPELEMENT_DYN64BIT,
/// (52).
  DPELEMENT_64BITARRAY,
/// (53).
  DPELEMENT_DYN64BITARRAY,
/// (54).
  DPELEMENT_LONG,
/// (55).
  DPELEMENT_DYNLONG,
/// (56).
  DPELEMENT_LONGARRAY,
/// (57).
  DPELEMENT_DYNLONGARRAY,
/// (58).
  DPELEMENT_ULONG,
/// (59).
  DPELEMENT_DYNULONG,
/// (60).
  DPELEMENT_ULONGARRAY,
/// (61).
  DPELEMENT_DYNULONGARRAY,
///
  DPELEMENT_COUNT    // Sentinel - must be last
};

#include <Types.hxx>
#include <iostream>


// ========== DpElType ============================================================

/** the Dp Element Type class. this class provides static functions for element type classification
*/
class DLLEXP_BASICS DpElType 
{
public:
  /// check if this is an array type (children of same type)
  static PVSSboolean isArrayType(DpElementType elType);
  /// check if this is a record type (children of different types)
  static PVSSboolean isRecordType(DpElementType elType);
  /// check if this is a leaf type (element has original config)
  static PVSSboolean isLeafType(DpElementType elType);
  /// check if this is a dynvar type
  static PVSSboolean isDynType(DpElementType elType);
  /// check if this is a DP reference type
  static PVSSboolean isReferenceType(DpElementType elType);
  /// get the type of the parent element containing subNodeType
  static DpElementType getArrayType(DpElementType subNodeType);
  // neben dem zurueckgelieferten Blatt-Typen kann IMMER auch arrayType
  // selbst wieder der subNodeType sein
  /// get the type of the child elements in the array
  static DpElementType getSubNodeType(DpElementType arrayType);
  
  /// check if this is a vaild type
  static PVSSboolean isValidType(DpElementType subNodeType);
  
  /// debug function. Write the element type to a given ostream; level must be >= 2
  static void debug(std::ostream &to, DpElementType el, int level);

  /** return a string identifying a given DpElementType - used in Ui DpTypeEditor/Tooltip
    @return pointer to static string or 0 if invalid el given
    @classification ETM internal
  */
  static const char *getName(DpElementType el);

  /** return a list of all strings formerly in teeltype.txt -
    used in Ui DpTypeEditor/Tooltip.

    Do not delete any of the returned list - they point to a static area.

    @param elementTypeNames [out] a pointer to a static allocated list
    @param elementTypeIds [out] a pointer to a static allocated list
    @param elementTypeCount [out] the number of elements in each of the two
        lists returned.
    @classification ETM internal
  */
  static void getAllNames(const char * const * &elementTypeNames, const DpElementType * &elementTypeIds, size_t &elementTypeCount);

private:
  // Konstruktor
  DpElType() {};  //COVINFO LINE: defensive (AP: no instance allowed)
};

#endif /* _DPELEMENTTYPE_H_ */
