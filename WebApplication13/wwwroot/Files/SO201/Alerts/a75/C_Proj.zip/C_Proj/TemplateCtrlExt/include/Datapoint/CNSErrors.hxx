#ifndef _CNSERRORS_H_
#define _CNSERRORS_H_

// forward declaration
class CNSPath;

#include <DpIdentificationResultType.hxx>
#include <ErrClass.hxx>


/// Errorcodes for Common Name Service.
class DLLEXP_DATAPOINT CNSErrors // class used as namespace
{
public:
  /// The corresponding error messages are defined in the "cns.cat" msg catalog
  static const char *CATALOG;

  enum
  {
    /// Common Name Service not available
    NO_CNS = 1,
    /// CNS View $1 not found
    VIEW_NOT_FOUND = 2,
    /// CNS View with ID $1 not found
    VIEW_ID_NOT_FOUND = 3,
    /// CNS Node $1 not found
    NODE_NOT_FOUND = 4,
    /// System $1 not found
    SYSTEM_NOT_FOUND = 5,
    /// CNS View $1 already exists
    VIEW_ALREADY_EXISTS = 6,
    /// CNS View with ID $1 already exists
    VIEW_ID_ALREADY_EXISTS = 7,
    /// CNS Node $1 already exists
    NODE_ALREADY_EXISTS = 8,
    /// New Display name separators collide with Display names of CNS Element $1
    SEPARATOR_COLLISION = 9,
    /// Illegal characters in name of CNS Element $1
    INVALID_CHARS_IN_NAME_OF_CNS_ELEMENT = 10,
    /// Illegal characters in Display name of CNS element $1
    INVALID_CHARS_IN_DISPNAME_OF_CNS_ELEMENT = 11,
    /// Illegal characters in Display name separators for View $1
    INVALID_SEPARATORS_FOR_VIEW = 12,
    /// Invalid DP $1 in CNS Node $2
    INVALID_DP_IN_NODE = 13,
    /// Invalid tree specified; error near line $1 of definition table
    INVALID_TREE_DEFINITION = 14
  };

  /**
   * Returns an error object with the CNS error code corresponding to the
   * given code in DpIdentificationResult, or ErrClass::UNEXPECTEDSTATE for
   * codes that are not related to CNS.
   *
   * @param res The DpIdentificationResult code.
   * @param note The path or name of a CNS element. Will be used in the error message.
   *
   * @return An ErrClass object.
   */
  static ErrClass fromDpIdentResult(DpIdentificationResult res, const char *note = 0);

  /**
   * Returns an error object with the CNS error code corresponding to the
   * given code in DpIdentificationResult, or ErrClass::UNEXPECTEDSTATE for
   * codes that are not related to CNS.
   *
   * @param res The DpIdentificationResult code.
   * @param path A CNSPath object. The function tries to pick the right part
   *             of the path for the error message (view or node).
   *
   * @return An ErrClass object.
   */
  static ErrClass fromDpIdentResult(DpIdentificationResult res, const CNSPath &path);

private:
  /// No constructor, since we are using the class only as a namespace
  CNSErrors();
};


#endif // _CNSERRORS_H_
