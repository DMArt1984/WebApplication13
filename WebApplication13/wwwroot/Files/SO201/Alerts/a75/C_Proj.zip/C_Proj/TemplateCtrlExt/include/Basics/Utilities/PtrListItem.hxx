// DATEIBESCHREIBUNG ==============================================================
// DATEINAME:     PtrListItem.hxx
// VERANTWORTUNG:	Thomas Koroschetz
// BESCHREIBUNG:	PtrListItem ist die Basisklasse fuer einfach verkettete Liste.
// ======================================Ende======================================
#ifndef _PTRLISTITEM_H_
#define _PTRLISTITEM_H_

// Vorwaerts-Deklaration der Eigenen Klasse
class PtrListItem;

// System-Include-Files
#include <Types.hxx>

/** The PtrListItem class. 
    Derive your classes from this one if you want to store them in a pointer list PtrList.
    @classification public use, overload
*/
class DLLEXP_BASICS PtrListItem 
{
  friend class PtrList;
  friend class DblPtrList;
  friend class DblPtrListItem;
  friend class UNIT_TEST_FRIEND_CLASS;

public:
  /// Constructor.
  PtrListItem() : nextPtr(0) {}
  /// Destructor.
  virtual ~PtrListItem();
  
  /// Access next item.
  PtrListItem *getNextItem() const {return nextPtr;}

  /** Access next item. 
      Obsoleted by getNext.
	  */
  PtrListItem * Next() const {return nextPtr;}

private:
  PtrListItem* nextPtr;
};

#endif /* _PTRLISTITEM_H_ */

