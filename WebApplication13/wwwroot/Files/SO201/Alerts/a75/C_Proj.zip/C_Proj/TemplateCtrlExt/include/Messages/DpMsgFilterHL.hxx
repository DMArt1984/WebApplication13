// DATEIBESCHREIBUNG ==============================================================
// DATEINAME:     DpMsgFilterHL.hxx
// VERANTWORTUNG: Robert Trausmuth
// BESCHREIBUNG:	DpMsgFilterHL ist die Aenderungsmeldung, welche fuer angemeldete
// 		Queries geschickt wird.
// 		
// 		Ein Manager kann sich beim Event-Manager mittels Query fuer bestimmte 
// 		Attribute anmelden und wird dann von jeder Aenderung dieser
// 		Attribute vom Event-Manager mit einer DpMsgFilterHL-Message
// 		informiert. Jede angemeldete Gruppe kann mehrere Attribute
// 		enthalten, die entsprechende Aenderungsmeldung wird in einer
// 		DpHLGroup geschickt, eine DpMsgFilterHL kann mehrere DpHLGroups
// 		enthalten. Eine Gruppe enthaelt das Ergebnis in Form einer DynDynAnyTypeVar
// 		
// 		Eine DpMsgFilterHL - Message hat nie eine Antwort-Message
// 
//
#ifndef _DPMSGFILTERHOTLINK_H_
#define _DPMSGFILTERHOTLINK_H_

// System-Include-Files
#include <DpMsgHotLink.hxx>
#include <PtrList.hxx>

// Vorwaerts-Deklarationen :
class DpHLGroup;
class ManagerIdentifier;
class Msg;

// ========== DpMsgFilterHL ============================================================

/** A manager may connect to some attributes with a query. 
    Whenver an attribute is changed, the manager is informed with this message. 
    This message is like a DpMsgHotLink but contains the query ID to identify the 
    query, which this message is related to.
*/
class DLLEXP_MESSAGES DpMsgFilterHL : public DpMsgHotLink 
{
  friend class UNIT_TEST_FRIEND_CLASS;    // ein Unit-Test braucht erweiterten zugriff auf diese Klasse

  // Operatoren :

  /// operator << for itcNdrUbSend stream
  /// @param ndrStream the stream, which to send to
  /// @param msg the DpMsgFilterHL
  friend DLLEXP_MESSAGES itcNdrUbSend &operator<<(itcNdrUbSend &ndrStream, const DpMsgFilterHL &msg);

  /// operator >> for itcNdrUbReceive stream
  /// @param ndrStream the stream, which to receive from
  /// @param msg the DpMsgFilterHL
  friend DLLEXP_MESSAGES itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream, DpMsgFilterHL &msg);
 
public:

  /// constructor
  /// @param newDestination the manager ID
  DpMsgFilterHL(const ManagerIdentifier &newDestination);

  /// default constructor, initialisation with zero values
  DpMsgFilterHL();

  /// copy constructor
  /// @param msg the DpMsgFilterHL to copy
  DpMsgFilterHL(const DpMsgFilterHL &msg);

  /// destructor
  ~DpMsgFilterHL();

  /// comparison operator ==
  /// @param rVal the DpMsgFilterHL to compare with
  /// @return 0 if not equal else 1
  int operator==(const DpMsgFilterHL &rVal) const;

  /// comparison operator !=
  /// @param rVal the DpMsgFilterHL to compare with
  /// @return 1 if not equal else 0
  int operator!=(const DpMsgFilterHL &rVal) const {return !operator==(rVal);}

  /// comparison operator ==
  /// @param rVal the message to compare with
  /// @return 0 if not equal else 1
  virtual int operator==(const Msg &rVal) const;

  /// assignment operator for DpMsgFilterHL
  /// @param rVal the DpMsgFilterHL to assign
  /// @return the resulting DpMsgFilterHL
  DpMsgFilterHL &operator=(const DpMsgFilterHL &rVal);

  /// assignment operator used for type conversion
  /// @param rVal the message to convert
  /// @return the resulting message
  virtual Msg &operator=(const Msg &rVal);

  /// send debug info to output stream
  /// @param to the output stream
  /// @param level the debug level
  virtual void debug(std::ostream &to, int level) const;

  /// get group ID
  /// @param idx the group index
  virtual DpIdentifier getGroupId(PVSSulong) const;
  
  /// allocate a new message
  Msg *allocate() const;
 
	/// check if own DP message type matches other DP message type
  /// @param dpMsgType the MsgType to check
  /// @return DpMsgFilterHL type if argument is DpMsgFilterHL else a DP message type
  MsgType isA(MsgType dpMsgType) const;

  /// get own message type, always returns DP_MSG_FILTER_HL
  MsgType isA() const;
};


// --------------------------------------------------------------------------------------
// Inline-Funktionen :
inline Msg *DpMsgFilterHL::allocate() const
{
	return new DpMsgFilterHL;
}


#endif /* _DPMSGFILTERHOTLINK_H_ */
