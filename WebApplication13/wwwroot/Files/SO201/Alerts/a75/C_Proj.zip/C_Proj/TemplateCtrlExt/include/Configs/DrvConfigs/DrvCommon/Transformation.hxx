// DATEIBESCHREIBUNG ==============================================================
// DATEINAME:     Transformation.hxx
#ifndef _TRANSFORMATION_H_
#define _TRANSFORMATION_H_

// Vorwaerts-Deklaration der Eigenen Klasse
class Transformation;
// System-Include-Files
#include <Types.hxx>
#include <ConfigTypes.hxx>
#include <RecVar.hxx>

// Vorwaerts-Deklarationen :
class DpIdentifier;
class DpMsg;
class Transformation;
class TimeVar;
class Variable;
 
// ========== Transformation ============================================================
/** The base class for the transformation objects used by the driver. 
    These objects are responsible to convert the data between the hardware and the PVSS 
    format. For every transformation type a driver uses an own class must be derived.
*/
class DLLEXP_CONFIGS Transformation 
{
public:
  /// Default constructor.
  Transformation();
  /// Destructor.
  virtual ~Transformation();

  /// Comparison operator.
  PVSSshort operator==(const Transformation &object) const;
  /// Assignment operator.
  Transformation &operator=(const Transformation &object);

  /** Get the transformation type.
      @return The transformation type represented by this object.
      @classification public use, overload
  */
  virtual TransformationType isA() const;
  /** @deprecated - don't use anymore, use TransformationType isA() instead
      Reason: unused as of 2016.05.11 (gstrauhs)
      Check the transformation type.
      @return The type if the transformation types are identical, else TransUndefinedType.
      @classification public use, overload.
  */
  virtual TransformationType isA(TransformationType type) const;

  // Standard Transformations
  // return 0 (ptr or bool) if not successful!
  /** The send transformation. 
      This transformation is called to convert data from the PVSS to the
      hardware specific transformation and pack the data into the data buffer.
      @param dataPtr A pointer to the data buffer to be sent
      @param len The size of the data buffer
      @param var The variable to pack into the data buffer
      @param subix The index of the variable object. This is used when handling arrays
      @return PVSS_TRUE if successful, else PVSS_FALSE.
      @classification public use, overload
  */
  virtual PVSSboolean toPeriph(PVSSchar *dataPtr, PVSSushort len,
                               const Variable &var, const PVSSushort subix) const;

  // Transformation for extended Attribs in HW direction
  /** The (extended) send transformation. 
      This transformation is called to convert data from the PVSS to the 
      hardware representation and pack the data into the data buffer.
      Additionally, the source time and user bits are available in a RecVar.
      @param dataPtr A pointer to the data buffer to be sent
      @param len The size of the data buffer
      @param var The variable to pack into the data buffer
      @param subix The index of the variable object. this is used when handling arrays
      @param more The additional information. the first var in the RecVar holds an 
             unsigned int with the bits set according to the received message
      @return PVSS_TRUE if successful, else PVSS_FALSE.
      @classification public use, overload
  */
  virtual PVSSboolean toPeriph(PVSSchar *dataPtr, PVSSushort len, const Variable &var,
                               const PVSSushort subix, const RecVar &more) const;

  /** The receive transformation. 
      This transformation is called to transform the data from the hardware representation
      as delivered in the data buffer to a PVSS variable.
      @param data A pointer to the received data buffer 
      @param dlen The size of the data buffer
      @param subix The index of the variable object. this is used when handling arrays
      @return A pointer to a new PVSS variable if successful, 0 otherwise.
      @classification public use, overload
  */
  virtual VariablePtr toVar(const PVSSchar *data, const PVSSushort dlen, const PVSSushort subix) const;

  // Transformation for extended Attribs in DP direction
  /** The (extended) receive transformation. 
      This transformation is called to transform the data from the hardware representation
      as delivered in the data buffer to a PVSS variable.
      Additionaly a reference to a boolean variable is given to mark the data as invalid, 
      e.g. if the data is out of range.
      @param data A pointer to the received data buffer 
      @param dlen The size of the data buffer
      @param subix The index of the variable object. this is used when handling arrays
      @param invalid The state of the invalid bit to set
      @return A pointer to a new PVSS variable if successful, 0 otherwise
      @classification public use, overload
  */
  virtual VariablePtr toVar(const PVSSchar *data, const PVSSushort dlen, const PVSSushort subix,
                PVSSboolean &invalid) const;

  /// The size of one item in bytes
  virtual int itemSize() const;
  // Die Zahl der Elemente in einem Item. Normalerweise 1, fuer Bitstrukturen wohl 8 pro Byte
  /** The number of elements in one item. 
      Usually one item represents one element and this function shall return 1. 
      If e.g. 16 bits are packed in a word, one item represents 16 elements and this 
      function shall return 16.
  */
  virtual int getNumberOfElements() const;
  /** Clone transformation. You must overload this function and return a copy of your object.
      @classification public use, overload
  */
  virtual Transformation * clone() const = 0;

  /** The preferred variable type. This function is used in the send direction
      to convert from the variable type of the datapoint the variable type expected 
      by this transformation. E.g. if a conversion is defined the datapoint may be a 
      float but the transformation may convert from PVSS integer to a hardware integer.
      @classification public use, overload
  */
  virtual VariableType  getVariableType() const;

  /// Swap the two bytes of a word, i.e. convert between little and big endian.
  static void cvt16( void *x );
  /// Swap the four bytes of a word, i.e. convert between little and big endian.
  static void cvt32( void *x );
  /// Swap the 8 bytes of a word, i.e. convert between little and big endian.
  static void cvt64( void *x );
  
  // Switch byte order from big endian to host. Does nothing if the host uses big endian.
  #ifdef IS_LITTLE_ENDIAN
  /// Switch byte order from big endian to host. Does nothing if the host uses big endian.
  static void bigEndianToHostShort( void *x) { cvt16(x); }
  /// Switch byte order from big endian to host. Does nothing if the host uses big endian.
  static void bigEndianToHostLong( void *x)  { cvt32(x); }
  /// Switch byte order from big endian to host. Does nothing if the host uses big endian.
  static void bigEndianToHostLong64( void *x)  { cvt64(x); }
  #else
  /// Switch byte order from big endian to host. Does nothing if the host uses big endian.
  static void bigEndianToHostShort(void *)   {};
  /// Switch byte order from big endian to host. Does nothing if the host uses big endian.
  static void bigEndianToHostLong(void *)    {};
  /// Switch byte order from big endian to host. Does nothing if the host uses big endian.
  static void bigEndianToHostLong64(void *)    {};
  #endif
  
  // Switch byteoder of a short von little endian to host. Does nothing if the host uses little endian.
  #ifdef IS_BIG_ENDIAN
  /// Switch byte order from little endian to host. Does nothing if the host uses little endian.
  static void littleEndianToHostShort( void *x) { cvt16(x); }
  /// Switch byte order from little endian to host. Does nothing if the host uses little endian.
  static void littleEndianToHostLong( void *x)  { cvt32(x); }
  /// Switch byte order from little endian to host. Does nothing if the host uses little endian.
  static void littleEndianToHostLong64( void *x)  { cvt64(x); }
  #else
  /// Switch byte order from little endian to host. Does nothing if the host uses little endian.
  static void littleEndianToHostShort(void *)   {};
  /// Switch byte order from little endian to host. Does nothing if the host uses little endian.
  static void littleEndianToHostLong(void *)    {};
  /// Switch byte order from little endian to host. Does nothing if the host uses little endian.
  static void littleEndianToHostLong64(void *)    {};
  #endif
  
  // Switch byte order from host to big endian. Does nothing if the host uses big endian.
  #ifdef IS_LITTLE_ENDIAN
  /// Switch byte order from host to big endian. Does nothing if the host uses big endian.
  static void hostToBigEndianShort(void *x)     { cvt16(x); }
  /// Switch byte order from host to big endian. Does nothing if the host uses big endian.
  static void hostToBigEndianLong(void *x)      { cvt32(x); }
  /// Switch byte order from host to big endian. Does nothing if the host uses big endian.
  static void hostToBigEndianLong64(void *x)    { cvt64(x); }
  #else
  /// Switch byte order from host to big endian. Does nothing if the host uses big endian.
  static void hostToBigEndianShort(void *)      {};
  /// Switch byte order from host to big endian. Does nothing if the host uses big endian.
  static void hostToBigEndianLong(void *)       {};
  /// Switch byte order from host to big endian. Does nothing if the host uses big endian.
  static void hostToBigEndianLong64(void *)     {};  
  #endif
  
  // Switch byte order from host to little endian. Does nothing if the host uses little endian.
  #ifdef IS_BIG_ENDIAN
  /// Switch byte order from host to little endian. Does nothing if the host uses little endian.
  static void hostToLittleEndianShort(void *x)  { cvt16(x); }
  /// Switch byte order from host to little endian. Does nothing if the host uses little endian.
  static void hostToLittleEndianLong(void *x)   { cvt32(x); }
  /// Switch byte order from host to little endian. Does nothing if the host uses little endian.
  static void hostToLittleEndianLong64(void *x) { cvt64(x); }
  #else
  /// Switch byte order from host to little endian. Does nothing if the host uses little endian.
  static void hostToLittleEndianShort(void *)   {};
  /// Switch byte order from host to little endian. Does nothing if the host uses little endian.
  static void hostToLittleEndianLong(void *)    {}; 
  /// Switch byte order from host to little endian. Does nothing if the host uses little endian.
  static void hostToLittleEndianLong64(void *)  {}; 
  #endif

  protected:
  /// Type definition used for byte order conversions.
  typedef char bit16[2];
  /// Type definition used for byte order conversions.
  typedef char bit32[4];
  /// Type definition used for byte order conversions.
  typedef char bit64[8];
  private:
};

#endif /* _TRANSFORMATION_H_ */

