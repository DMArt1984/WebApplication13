#ifndef _CASTEXPR_H_
#define _CASTEXPR_H_

#include <CtrlExpr.hxx>
#include <TypeSpec.hxx>

/*  author VERANTWORTUNG: Martin Koller */
/** Implements the cast expression, e.g. (int)1.23 */

class DLLEXP_CTRL CastExpr : public CtrlExpr
{
  public:
    /// Returns the type of the Expression
    virtual ExprType isA() const { return CAST_EXPR; }

    /** Constructor: Wird beim Parsen aufgerufen.
      * @param line     In welcher Zeile des Sourcefiles steht diese Zuweisung?
      * @param filenum  Wenn es ein Library-File war die Nr. der Library
      *                 Damit kann der Name ermittelt werden.
      */
    CastExpr(const TypeSpec &spec, CtrlExpr *e, int line, int filenum)
      : CtrlExpr(line, filenum), expr(e), typeSpec(spec) { }

    /// Destructor
    virtual ~CastExpr();

    virtual const CtrlSment *execute(CtrlThread *thread) const;

    /** Ist die Expr teil einer Komplexen Expr wird sie mit evaluate
      * ausgewertet.
      * @return Ptr auf Variable die das Ergebnis zugewiesen bekommt
      *         tritt ein Fehler auf wird ein Ptr auf eine dummy IntegerVar
      *         zurueckgegeben -> immer != NULL
      * @param thread der Thread der dieses Statement ausfuehrt
      * @see execute
      */
    virtual const Variable *evaluate(CtrlThread *thread) const;

    virtual const CtrlExpr *getFirstExpr(CtrlThread *) const;

    virtual void writeTrace(CtrlThread *thread, bool writeValue = true) const;

    virtual bool checkIntegrity(const CharString &location, CtrlThread *) const;

  private:
    CtrlExpr *expr;
    TypeSpec typeSpec;
};

#endif /* _CASTEXPR_H_ */
