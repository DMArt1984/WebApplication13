#ifndef _BREAKSMENT_H_
#define _BREAKSMENT_H_

#include <CtrlSment.hxx>

/*  author VERANTWORTUNG: Mark Probst */
/** the break statement */
class DLLEXP_CTRL BreakSment : public CtrlSment
{
  public:

    /** Constructor: Wird beim Parsen aufgerufen
      * @param line     In welcher Zeile des Sourcefiles steht das break
      * @param filenum  Wenn es ein Library-File war die Nr. der Library
                        Damit kann der Name ermittelt werden.
    */
    BreakSment(int line, int filenum) : CtrlSment(line, filenum), theLoop(0) {}

    /** Welche Schleife wird durch dieses break verlassen. Wird beim Parsen aufgerufen.
      * @param aLoop LoopSment der Schleife
      */
    void setLoop(const CtrlSment *aLoop) { theLoop = aLoop; }

    /** executes the "break" statement
      * @return pointer to loop which it breaks out of
      * @param thread executing thread
      * @return next CtrlSment to execute
      */
    virtual const CtrlSment *execute(CtrlThread *thread) const;

    virtual void writeTrace(CtrlThread *thread, bool writeValue = true) const;

    /** Is the statement of the specified type ?
      * @param type given type
      * @return 1 Sment is of type "type"
      * @return 0 Sment is not of type "type"
      */
    virtual int isA(SmentType type) const { return (type == SMENT_BREAK); }

  private:
   /// Loop break is leaving
   const CtrlSment *theLoop;
};

#endif // _BREAKSMENT_H_

