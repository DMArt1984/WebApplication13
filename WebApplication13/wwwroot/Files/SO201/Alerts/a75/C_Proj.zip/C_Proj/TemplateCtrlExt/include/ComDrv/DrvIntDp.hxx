#ifndef _DRVINTDP_H_
#define _DRVINTDP_H_

#ifndef _CHARSTRING_H_
#include <CharString.hxx>
#endif

#ifndef _DPIDENTIFIER_H_
#include <DpIdentifier.hxx>
#endif

#ifndef _VARIABLE_H_
#include <Variable.hxx>
#endif

class ErrClass;

/** A class for a driver internal DP interface.
  * This class should simplify the handling of internal DPs in a driver.
  * It must be overloaded for each internal DP.
  *
  * The overloading class must give the number of DPEs to handle (maxDp)
  * and the number of DPEs for a dpConnect (maxConnect) in the contructor
  * of this class.
  *
  * The first maxConnect entries are the entires, where a dpConnect
  * is executed, so getDpName4Query must return the names for dpConnect
  * first!
  *
  * The class does the retrieval of DPIDs via SYS_MSG_NAMESERVER.
  * It executes the dpConnect for the DPEs which should be connected.
  * It calls virtual functions in the case the answer or a hotlink
  * has been received.
  *
  * Check the error state of the object once the dpReady() callback has
  * been called. If there was an error during resolving one or more
  * DPEs might have only the system number set. This normally means the
  * DPE could not be found.
  *
  * Note: Such objects must be created after the resource object!!!
  *
  * Internal DPs are meant to control the driver instance and
  * therefore once created, the internal objects in the driver framework
  * MUST be kept alive until either the driver terminates or
  * the matching DP has been deleted
  * otherwise the driver may crash due to an unhandled hotlink
  */
class DrvIntDp
{
  public:

    /** Defines DrvIntDp status
     */
    typedef enum {Init, WaitForDpName, AskForDpIds, WaitForDpIds, WaitForAnswers, Ready} DrvIntDpState_t;

  /** Allocates the array for the DP table and inserts the object into
      * the list managed in the DrvResources class
      * @param maxDp number of DPEs
      * @param maxConnect max number of DPEs to be connect
    */
    DrvIntDp(int maxDp, int maxConnect, bool dpNameKnown = true);

    /** Deletes array and remove object from the DrvResources class list 
    */
    virtual ~DrvIntDp();

    /** get the internal DpName retrieved by using the DpId to DpName mechanism 
    */
    const CharString &getMyName() const {return myName_;}

    /** get the internal DpId used for the DpId to DpName mechanism 
    */
    DpIdType getMyDpId() const {return myDpId_;}

    /** Retrieves the DpId of the internal DP. The function must be overloaded if the DpId to DpName mechanism is to be used.
      * It should return the DP Id of an existing DP
      */
    virtual DpIdType getDpId4Query();

    /** Retrieves the names of the internal DPEs. The function must be overloaded.
      * It should return the proper DPE string for the corresponding index
    * @param index 
      */
    virtual const CharString& getDpName4Query(int index) = 0;

    /** This function is called if there is an answer to the dpConnect
      * for a certain index. The variable object should be captured or deleted.
      * @param index of the data point element
      * @param varPtr pointer to the variable object
     */
    virtual void answer4DpId(int index, Variable* varPtr);

    /** This function is called if there is a hotlink
      * for a certain index. The variable object should be captured or deleted.
      * @param index of the data point element
      * @param varPtr pointer to the variable object
     */
    virtual void hotLink2Internal(int index, Variable* varPtr);

    /** This function is called if this object is completely
      * initialised and all connects are done and values have been received
      */
    virtual void dpReady();

    /** This function is called if an error is in the hotlink message.
      * This gives the application the possibility to handle a deleted
      * DP.
    * @param err input error to be handle
      */
    virtual void handleError(const ErrClass * err);

    /** Function to retrieve the actual state of the internal DP
      * interface object. This function can be used to check if the
      * internal DP is properly initialized.
    * @return actual state
      */
    DrvIntDpState_t getState() const {return state_;}

    /** Access function returning the error state of the internal
    * DP interface
    * @return TRUE if error
    */
    bool getError() const {return iDpError_;}

  /** Function to retrieve the DpIdentifier for a certain index
    * @param index
    * @return DpIdentifier from Id table
    */
    const DpIdentifier & getId(int index) const {return simpleIdTab_[index].dpId;}

    
    // --------only internal use for internal DP handling-----------------------

    /** State machine for defined states
    * - Init - connect to DPs
    * - WaitForDpIds - wait if all DPs are connected
    * - WaitForAnswers - wait for answers from connected DPs
      */
    void workProc();

  /** Set dp identifier an config in Id table according name
    * when overloading, take care to call the base method
    * @param name input name for searching in table
      * @param dpId dp identifier
    * @return TRUE if dp of the appropriate name was assigned successfully
    */
    virtual PVSSboolean setDpIdentifier(CharString& name, DpIdentifier& dpId);

  /** Set dp name of internal DP if started in resolve-name mode
    * @param dpId dp identifier used for search
    * @param name input resulting dp name
    * @return TRUE if name of the appropriate dp was assigned successfully
    */
    virtual PVSSboolean setDpName(DpIdentifier& dpId, CharString& name);

    /** Search in Id table according to dp Id
      * @param dpId dp identifier
    * @return TRUE if dpId was found
    */
    PVSSboolean isInternal(DpIdentifier& dpId);

    /** If answer is true increases count of answers
    * and deletes pointer to variable for index i 
    * or deletes pointer to variable for hotlink to internal
    * @param dpId dp identifier
    * @param varPtr pointer to variable
    * @param answer
    * @param i
    * @return TRUE
    */
    bool value4DpId(const DpIdentifier &dpId, Variable* varPtr, bool answer, int i);
    // --------only internal use for internal DP handling end-----------------------

  protected:

    #ifdef _UNIT_TEST
      DrvIntDp() { };
    #endif // _UNIT_TEST

    /** DrvIntDp internal status
     */
    DrvIntDpState_t state_;

    // suppress message for DPEs not found - used by HmiConnection
    bool reportMissingDPEs_;

    // for debug purposes print out the internal table (name + id)
    void debugPrint(std::ostream &ostr);

    // to change name in case of redu
    CharString &getInternalName() { return myName_; }

  private:
    /** Check if all DPID got
    * @return FALSE if dp in table is null, else return TRUE
      */
    PVSSboolean allIdsGot() const;
    
  /** Return TRUE if dp error is true or count of answers is equal maxConnect
    * @return FALSE in other cases
    */
    PVSSboolean allIdsAnswered() const;

    /** Dp connection is failed when at least one DPE has error
    */
    void connectIdps();
      
    class IdTabItem
    {
      public:
        CharString dpName;
        DpIdentifier dpId;
    };

    IdTabItem *simpleIdTab_;
    int realConnect_;
    int answerCount_;
    bool iDpError_;

    int maxDp_;
    int maxConnect_;

    CharString myName_;
    DpIdType myDpId_;

friend class UNIT_TEST_FRIEND_CLASS;
};

#endif
