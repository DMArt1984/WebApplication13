#ifndef _AVERAGEACCU_H_
#define _AVERAGEACCU_H_

// Author: Heinz MEISSL
// Date:   14.4.1997
// Purpose: implement a statistic Accumulator to determine the sum of values

#ifndef _SIMPLEACCU_H_
#include <SimpleAccu.hxx>
#endif

#ifndef _SUMACCU_H_
#include <SumAccu.hxx>
#endif

#ifndef _COUNTACCU_H_
#include <CountAccu.hxx>
#endif

#ifndef _VARIABLE_H_
#include <Variable.hxx>
#endif

#ifndef _FLOATVAR_H_
#include <FloatVar.hxx>
#endif

#ifndef _TIMEVAR_H_
#include <TimeVar.hxx>
#endif

/** a value accumulator class. this class is used to determine a mean value of variables.
    the mean value is calculated over the number of elements.
    @classification ETM internal
*/
class DLLEXP_OABASICS AverageAccu: public SimpleAccu
{
  public:
    AverageAccu(const VariableType aVarType);
    
    virtual void accumulate(const Variable &theValue, const TimeVar &atTime );
    virtual const Variable &getResult();
    virtual void reset();
    
  protected:
  
  private:
    AverageAccu(const AverageAccu &);
    AverageAccu &operator=(const AverageAccu &);
  
    SumAccu mySumAccu;
    CountAccu myCountAccu;
    FloatVar theAverage;
};

#endif
