#ifndef _CtrlVariable_H_
#define _CtrlVariable_H_

// abstract baseclass for all Variables defined in Ctrl
// allowing additional common virtual methods (e.g. assign())
// which allow e.g. to create runtime CtrlThread exception

#include <Variable.hxx>

class CtrlThread;

class DLLEXP_CTRL CtrlVariable : public Variable
{
  public:
    // assign given Variable if possible, else return false (and optionally set an exception into thread)
    virtual bool assign(const Variable &rVal, CtrlThread *thread = 0) = 0;

    static bool isDerived(const Variable &var)
    {
      return (var.isA() == CLASS_VAR) ||
             (var.isA() == FUNCTION_VAR) ||
             (var.isA() == POINTER_VAR) ||
             (var.isA() == VECTOR_VAR);
    }

    // for targets which are derived from CtrlVariable use the virtual assign() method,
    // for all others the usual Variable::operator=()
    // returns false in case assignment is not possible
    static bool assign(Variable &target, const Variable &rVal, CtrlThread *thread)
    {
      if ( isDerived(target) )
        return static_cast<CtrlVariable &>(target).assign(rVal, thread);

      target = rVal;
      return true;
    }
};

#endif
