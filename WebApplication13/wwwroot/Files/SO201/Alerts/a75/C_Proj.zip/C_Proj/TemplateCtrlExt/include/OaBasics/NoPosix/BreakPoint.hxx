#ifndef _BREAKPOINT_H_
#define _BREAKPOINT_H_

#if !defined(_WIN32) || defined _WIN64

  #define DBG_BREAK         

#else

  #if defined(NO_DBG_BREAK)
    #define DBG_BREAK         
  #else
    #define DBG_BREAK         __asm { int 3 };
  #endif

#endif


#endif //_BREAKPOINT_H_
