// -----------------------------------------------------------------------------
// creator: Andras Horvath - 01.09.2017
// purpose: Basic crypto functionality
// -----------------------------------------------------------------------------
#ifndef _CRYPTO_H_
#define _CRYPTO_H_

#include <CharString.hxx>

/**
  @class Crypto
  @brief Collection of cryptoraphic functions
*/
struct DLLEXP_OABASICS Crypto
{
#if PVSS_VERS < 400000
  /**
    @brief Encrypt password for up to 8 chars
    @param passwd the password to encrypt
    @return pointer to static char array containing 11 chars
    @classification public use, call
  */
  static const char* crypt(const char * passwd);

  /**
    @brief  Encrypt password for arbitrary length
    @param  passwd the password to encrypt
    @return encrypted password starting with '_'
            (to mark the difference to crypt()) and length 12 chars
    @classification public use, call
  */
  static CharString crypt2(const char *passwd);
#endif

  /**
    @brief   Generate PKCS#5 password hash (PBKDF2)
    @details The number of iterations is randomized between 10000 and 20000
    @param   passwd  the password to encrypt
    @return          the generated format: #algorithm#salt#iterations#passhash
  */
  static CharString cryptHashPBKDF2(const char *passwd);

  /**
    @brief  Generate PKCS#5 password hash (PBKDF2)
    @param  passwd     the password to encrypt
    @param  iterations the number of iterations
    @return            the generated format: #algorithm#salt#iterations#passhash
  */
  static CharString cryptHashPBKDF2(const char *passwd, int iterations);

  /**
    @brief  Check PKCS#5 password hash (PBKDF2)
    @param  passwd     the password which we are comparing
    @param  pwdHash    the hash output from cryptHashPBKDF2()
    @return            true if the hash is valid for the password
  */
  static bool checkHashPBKDF2(const char* passwd, const char* pwdHash);
};

#endif
