#ifndef _PTREENODE_H_
#define _PTREENODE_H_

#include <iostream>

/*  author VERANTWORTUNG: Martin Koller */
/** Basisklasse fuer alle moeglichen Knoten im Parsetree.
  * Pointer auf diese Klasse wird als Uebergabeparameter im yacc (und lex)
  * source verwendet
    @classification internal use
*/

class DLLEXP_CTRL PTreeNode
{
  public:
    /// Constructor with line and script number
    PTreeNode(int line, int lib) : currentLine(line), fileNum(lib), counter(0), perfTime(0) {}

    virtual ~PTreeNode() { }

    /// returns script line the sments is on
    int getCurrentLine() const {return currentLine;}

    /// returns the lib-file number, the sment is from
    int getFileNumber() const {return fileNum;}

    /// increase execution counter (const as it modifies a mutable)
    void incExecCounter() const { counter++; }

    /// reset execution counter to zero (const as it modifies a mutable)
    void resetExecCounter() const { counter = 0; }

    /// return current execution counter value
    int getExecCounter() const { return counter; }

    /// increase performance counter
    void incPerfTime(int inc) const { if (perfTime >= 0) perfTime = -(perfTime + inc); }

    /// reset performance counter
    void resetPerfTime() const { perfTime = 0; }

    /// return current performance counter
    int getPerfTime() const { return perfTime; }

    /// reset mark
    void resetPerfMark() const { if (perfTime < 0) perfTime = -perfTime; }

    /** dump the whole tree for code coverage analysis
        @param to output stream
      */
    enum CoverageAction { DUMP, RESET, CREATE_DOT };
    virtual void dumpCoverageTree(std::ostream &to, CoverageAction action = DUMP) const;

  protected:
    /// return true in case this node was already dumped with dumpCoverageTree()
    bool wasAlreadyDumped(CoverageAction action) const;

  private:
    PTreeNode();    // not allowed

    int currentLine;
    int fileNum;
    mutable int counter;  // how often was this sment executed
    mutable int perfTime;     // performance data
};

#endif /* _PTREENODE_H_ */
