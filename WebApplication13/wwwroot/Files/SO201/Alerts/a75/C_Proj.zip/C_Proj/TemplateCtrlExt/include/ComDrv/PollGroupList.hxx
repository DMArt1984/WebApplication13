// DATEIBESCHREIBUNG ==============================================================
// DATEINAME:       PollGroupList.hxx
// VERANTWORTUNG:  Andreas Lugbauer
// BESCHREIBUNG:   Die Klasse PollGroupList beinhaltet dynamisches Array von Zeiger
//                  auf Klassen mit den zu pollenden Werten.
//                  Die Element der Liste sind PollGroupItems

#ifndef _POLLGROUPLIST_H_
#define _POLLGROUPLIST_H_

#include <DynPtrArray.hxx>
#include <PollGroup.hxx>

/** This class holds all the poll group item entries for the poll requests.
  * The poll group list is sorted by time.
  */
class PollGroupList
{
  public:
    /** Constructor
    */
    PollGroupList();
    
    /** Destructor
    */
    virtual ~PollGroupList();
    
    /** Adding a poll group, if does not exist creates a poll group.
    * Each poll group is generated with poll time.
    * Poll group is set to active when we have all info from the data points
      * @param pg name of the poll group
      * @return pointer to poll group
    */
    //PollGroup * addGroup (const CharString & pg);

    /** Adding a poll group, if does not exist creates a poll group.
    * Each poll group is generated with poll time.
    * Poll group is set to active when we have all info from the data points
      * @param dpId dpId of the poll group
      * @return pointer to poll group
    */
    PollGroup * addGroupById(DpIdType dpId);

    /** Deleting a poll group from the poll group list
    * Method is not defined.
    * @param idx index of group that to be removed
    * @return
    */
    PVSSboolean remGroup(PVSSlong idx);

    /** Set the DP Identifier for a DP Name.
      * This is called as a response to a NameServerSysMsg.
      * @param dpId dp identifier
    * @param name name of dp identifier
      * @return PVSS_TRUE in case of success
    */
    PVSSboolean setDpIdentifier (CharString &name, DpIdentifier &dpId);
    
    /** Set the DP Name for a DP Identifier.
      * This is called as a response to a NameServerSysMsg.
      * @param dpId dp identifier
      * @param name name of dp identifier
      * @return PVSS_TRUE in case of success
    */
    PVSSboolean setDpName (DpIdentifier &dpId, CharString &name);

    /** Check if the DPId belongs to the poll groups
    * @param dpId dp identifier
    * @return PVSS_TRUE if dp is included in poll group
    */
    PVSSboolean isPollGroupDpId (const DpIdentifier& dpId);

    /** This method is called when the connection to the event manager is established
    */
    void connect2PollGroupDps ();

    /** Check if group already exists and calls 
      * function PollGroup::answer4DpId()
      * @param dpId reference to DP Identifier
      * @param varPtr pointer to variable value
      * @return PVSS_TRUE when dpId was found and group was updated
      */
    PVSSboolean answer4DpId(const DpIdentifier& dpId, Variable* varPtr );

    /** Check if group already exists and calls 
      * function PollGroup::hotLink2DpId()
      * @param dpId reference to DP Identifier
      * @param varPtr pointer to variable value
      * @return PVSS_TRUE when dpId was found and group was updated
      */
    PVSSboolean hotLink2DpId(const DpIdentifier& dpId, Variable* varPtr );

    /** Returns an index of found item.
    * @param pg pointer to poll group to be found
    * @return an index of found item or DYNPTRARRAY_INVALID if item is not found
    */
    PVSSlong    findItem(PollGroup * pg);

    /** Returns the actual poll group to poll, if nothing is to poll
      * it return a NULL pointer
      * @param when returns the poll time for the group
      * @return pointer to the poll group, if something is to be polled
      *         0 nothing is to poll
      */
    PollGroup * pollNow( TimeVar &when);

    /** Sets the new poll time for a group.
      * @param idx Index of the poll group
      * @return PVSS_TRUE if poll time was set
      */
    PVSSboolean        setNewPollTime(PVSSlong idx);

    /** Updates the group when new data have been received
      * @param pg PollGroup to updated
      */
    void updateGroup (const PollGroup * pg);
    
    /** Find group by group name
      * @param pgName poll group name 
      * @return pointer to group or NULL if the group does not exist
      */
    //PollGroup * findGroup (const CharString * pgName);

    /** Find group by datapoint id
      * @param dpId poll group id 
      * @return pointer to group or NULL if the group does not exist
      */
    PollGroup * findGroupById (DpIdType dpId);
    
    /** Creates a new poll group object with name given by input parameter.
    * The caller is responsible for the pointer.
    * @param dpId poll group id 
    * @return pointer to new poll group
    */
    virtual PollGroup * getNewPollGroup(DpIdType dpId) const;

    /** Get poll group at certain index
    * @param idx index
    * @return pointer to poll group according to index
    */
    PollGroup * getPollGroup (const DynPtrArrayIndex idx);

    /// reset next poll times and resort the list
    void reset();

    /** output debug info
      */
    void debugPrint() const;

    /** Report relevant data of the pollgroups
    * @classification public use, overload
    */
    virtual void reportStatus(std::ostream &os);

  protected:
  private:

    // Copy constructor
    PollGroupList(const PollGroupList&);
    // Assignment operator
    PollGroupList& operator=(const PollGroupList&);

    static int compare (const PollGroup * g1, const PollGroup * g2);
  
    PVSSlong         pllMax;
    DynPtrArray<PollGroup> * pgList_;

friend class UNIT_TEST_FRIEND_CLASS;
};


#endif
