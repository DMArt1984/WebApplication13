#ifndef _OAUSERTABLE_HXX_
#define _OAUSERTABLE_HXX_

#include <Types.hxx>
#include <DpIdValueList.hxx>
#include <memory>

class DLLEXP_MANAGER OaUserTable
{
public:
  OaUserTable();
  ~OaUserTable();

  const char* getDeletedUserName(PVSSuserIdType id);

  // wait for user data to arrive
  void waitForData();

  // Check if the table is initialized
  bool isInitialized() const;

  // update the internal copy of the user-table
  bool dpValueChanged(const DpIdValueList &values);

  OaUserTable(const OaUserTable& rval) = delete;
  OaUserTable& operator=(const OaUserTable& rval) = delete;

private:

  class OaUserTableImpl;

  OaUserTableImpl* impl;
};

#endif  // _OAUSERTABLE_HXX_

