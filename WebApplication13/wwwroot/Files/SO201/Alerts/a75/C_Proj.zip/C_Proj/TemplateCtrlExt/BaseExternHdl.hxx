#ifndef _BASEEXTERNHDL_H_
#define _BASEEXTERNHDL_H_

#include <string.h>

#include <ErrHdl.hxx>
#include <Variable.hxx>
#include <Types.hxx>
#include <DynPtrArray.hxx>
#include <CharString.hxx>
#include <CtrlThread.hxx>
#include <IntegerVar.hxx>
#include <TextVar.hxx>
#include <BitVar.hxx>
#include <CtrlScript.hxx>
#include <ExprList.hxx>
#include <CtrlExpr.hxx>
#include <ExternData.hxx>
#include <LongVar.hxx>

class Controller;
class SelExpr;

#ifdef WIN32
#  define CTRLEXT_EXPORT  __declspec(dllexport)
#else
#  define CTRLEXT_EXPORT  DLLEXP_CTRL
#endif

/// @defgroup ctrl_api Control Scripting Language Extension API
///@{

#ifndef WCCOA_STATIC_PLUGINS

#define CTRL_EXTENSION_VERSION extern "C" \
        CTRLEXT_EXPORT const char *getVersionString() \
        { return PVSS_VERS_DLL; }

/// Macro needed to create a function the CTRL interpreter uses to create an instance of a CTRL extension
#define CTRL_EXTENSION(CLASS, funcList) extern "C" \
      { \
        CTRLEXT_EXPORT BaseExternHdl *newExternHdl(BaseExternHdl *nextHdl) \
        { \
          PVSSulong funcCount = sizeof(funcList)/sizeof(funcList[0]); \
          return new CLASS(nextHdl, funcCount, funcList); \
        } \
        CTRL_EXTENSION_VERSION \
      }

#else

// when all CTRL extensions are static libraries and linked
// into the main application

#define CTRL_EXTENSION(CLASS, funcList) \
        BaseExternHdl *CLASS##_newExternHdl(BaseExternHdl *nextHdl) \
        { \
          PVSSulong funcCount = sizeof(funcList)/sizeof(funcList[0]); \
          return new CLASS(nextHdl, funcCount, funcList); \
        }

#define CTRL_EXTENSION_REGISTER(PLUGIN, CLASS) \
    extern BaseExternHdl *CLASS##_newExternHdl(BaseExternHdl *nextHdl); \
    Controller::thisPtr->registerStaticExtension(PLUGIN, &CLASS##_newExternHdl);

#define CTRL_EXTENSION_VERSION

#endif

/// List of functions that is implemented with this ExternHdl
struct FunctionListRec
{
  /// This function returns a variable of type retType e.g. INTEGER_VAR
  VariableType retType;

  /// name of the function (used for parsing) e.g. "myStrSplit"
  const char * name;

  /** prototype of the function e.g. "(string txt, char splitChar)".
    If the function shall not be shown in the completion list in gedi's
    script editor (e.g. not publicly available), set this to 0
  **/
  const char * paramList;

  /// ignored for now.
  // is this function thread-save implemented ?
  // we possibly execute this Function within an additional thread
  bool threadCallPossible;
};



/*  author Andreas Pfluegl */
/** Base class to extend the CTRL-Language.
  * Derive your class from this class, implement a constructor and
  * the execute(ExecuteParamRec & param) method.
  * All Methods are called by the CTRL-Language framework.
  <br>
  Use the macro #CTRL_EXTENSION in your .cxx file to create the factory function
  which the Control Interpreter calls to instantiate your new class.
  <p>
  To quickly generate a new CTRL extension template, use the script newWCCILCtrlExt in
  the PVSS api installation directory.
  </p>
  */

class DLLEXP_CTRL BaseExternHdl
{
  public:

    // -----------------------------------------------------------------------------------------------------------------------
    // structs needed
    // -----------------------------------------------------------------------------------------------------------------------

    /// Parameters passed from CTRL-Lanaguage to execute
    struct ExecuteParamRec
    {
      /// Function (name) that should be called (only used for Error-Msgs)
      CharString funcName;

      /// Unique number identifies the function. Is used to call the function
      PVSSulong funcNum;

      /// Parameters passed by the CTRL-Language to your implementation
      ExprList *args;

      /// Infos for Error-Msgs (e.g. from where was the script started)
      ExternData *clientData;

      /// get Infos of the thread that wants to execute the specified Function
      CtrlThread *thread;
    };

    // -----------------------------------------------------------------------------------------------------------------------
    // Implement this functions
    // -----------------------------------------------------------------------------------------------------------------------
    /**
      * The Constructor
      * @param  hdl         IN pointer to the next ExternHdl. 0 if there is no next
      * @param  funcCount   IN tells the constructor how long the list fnList is.
      * @param  fnList      IN list that describes the functions you want to implement
      */
    BaseExternHdl(BaseExternHdl *hdl, PVSSulong funcCount, FunctionListRec fnList[]);

    /// implement your CTRL-extentions in this method
    virtual const Variable *execute(ExecuteParamRec & param) = 0;

    // -----------------------------------------------------------------------------------------------------------------------
    // already implemented functions
    // -----------------------------------------------------------------------------------------------------------------------
    /// destructor
    virtual ~BaseExternHdl() { delete funcNameList_; }

    /** returns the function-number corresponding to funcName.
      * if the function is implemented in this class, or 0 if not
      */
    virtual PVSSulong getFuncNum(const CharString &funcName) const;

    /// How many functions are Implemented by this ExternHdl
    virtual PVSSulong getFunctionCount() { return(funcCount_); }

    /// Std-ExternHdl needs to know its Controller
    void setController(Controller *c);

    /// set Pointer to the next ExternHdl (all ExternHdl are linked to a list)
    void setNextExtHdl(BaseExternHdl* hdl) { nextExtHdl_ = hdl; }

    /// get Pointer to the next ExternHdl (all ExternHdl are linked to a list)
    BaseExternHdl *getNextExtHdl() const { return nextExtHdl_; }

    ///
    void setFirstIdx(PVSSulong firstIdx) { firstIdx_ = firstIdx; }

    /** Std-ExternHdl implements its functions here
      * don't touch this method its for internal use
      */
    virtual const Variable *execute
      (
        const CharString &funcName,
        PVSSulong funcNum,
        ExprList *args,
        ExternData *clientData,
        CtrlThread *thread
      );

    virtual const Variable *evaluate(SelExpr *selExpr, CtrlThread *thread)
    {
      if (nextExtHdl_)
        return nextExtHdl_->evaluate(selExpr, thread);

       ErrHdl::error(ErrClass::PRIO_SEVERE,
                ErrClass::ERR_IMPL, ErrClass::UNEXPECTEDSTATE,
                thread->getLocation(), "can't evaluate");

       return &errorIntVar;
    }

    virtual const Variable *execute(SelExpr *selExpr, CtrlThread *thread)
    {
      if (nextExtHdl_)
        return nextExtHdl_->execute(selExpr, thread);

       ErrHdl::error(ErrClass::PRIO_SEVERE,
                     ErrClass::ERR_IMPL, ErrClass::UNEXPECTEDSTATE,
                     thread->getLocation(), "can't execute");

       return &errorIntVar;
    }

    virtual const Variable *assign(SelExpr *selExpr, CtrlThread *thread, const Variable *rVar)
    {
      if (nextExtHdl_)
        return nextExtHdl_->assign(selExpr, thread, rVar);

       ErrHdl::error(ErrClass::PRIO_SEVERE,
                     ErrClass::ERR_IMPL, ErrClass::UNEXPECTEDSTATE,
                     thread->getLocation(), "can't assign");

       return &errorIntVar;
    }

    // COVINFO BLOCK: engineering (syntaxcheck not performed at runtime, mkoller)
    virtual PVSSboolean checkIntegrity(const SelExpr *selExpr, const CharString &location, CtrlThread *thread) const
    {
      if (nextExtHdl_)
        return nextExtHdl_->checkIntegrity(selExpr, location, thread);

      return PVSS_TRUE;
    }
    // COVINFO BLOCKEND
    virtual void clearResources();

    // @internal used for script editor
    const FunctionListRec *getFunctionList(PVSSulong &count) const { count = funcCount_; return funcList_; }

    // @internal used for script editor
    void setFileName(const CharString &name) { fileName = name; }

    // @internal used for script editor
    const CharString &getFileName() const { return fileName; }

    /** Return the signature of given function number
        The signature is generated from the defined FunctionListRec
      */
    CharString signature(PVSSulong funcNum) const;

  protected:
    bool implError(const char *implFn, const char *calledFn);

    /// check if there are at least @num arguments given; if not, throw an ErrHdl::error
    bool hasNumArgs(unsigned int num, const ExecuteParamRec &param) const;

    /// get assignable target variable of @expr, unpack anytype/mixed and optionally check against @type
    Variable *getTarget(CtrlExpr *expr, const ExecuteParamRec &param, VariableType type = NO_VAR) const;

    /// return a pointer to one of these in case execute() needs to return an error/success condition
    static const IntegerVar errorIntVar;    // the -1 default error code
    static const IntegerVar successIntVar;  // the 0 default success code
    static const LongVar errorLongVar;     // (-1L);
    static const TextVar errorTextVar;      // empty string
    static const BitVar errorBitVar;        // false

    Controller *ctrl_;
    BaseExternHdl* nextExtHdl_;
    PVSSulong firstIdx_;

  private:
    struct FuncNameRec
    {
      const char *name;
      PVSSulong funcNum;
    };

    static int compare(const FuncNameRec *p1, const FuncNameRec *p2);
    PVSSulong getMyFuncNum(const CharString &funcName) const;

    PVSSulong funcCount_;
    const FunctionListRec *funcList_;

    DynPtrArray<FuncNameRec> *funcNameList_;

    CharString fileName;
};

// -----------------------------------------------------------------------------------------------------------------------
// -----------------------------------------------------------------------------------------------------------------------

typedef BaseExternHdl *(*newBaseExternHdlFunction)(BaseExternHdl *);


inline bool BaseExternHdl::implError(const char *implFn, const char *calledFn)
{
  if (strcmp(implFn, calledFn) != 0)
  {
    ErrHdl::error(ErrClass::PRIO_SEVERE,
                ErrClass::ERR_IMPL, ErrClass::UNEXPECTEDSTATE,
                calledFn, " called implementation of Function ", implFn);
    return(true);
  }

  return(false);
}

#ifdef WIN32
  #pragma warning ( push )
  #pragma warning ( disable: 4231 )
#endif

#if defined(LIBS_AS_DLL)
  EXTERN_CTRL template class DLLEXP_CTRL SimplePtrArray<BaseExternHdl>;
  EXTERN_CTRL template class DLLEXP_CTRL DynPtrArray<BaseExternHdl::FuncNameRec>;
#endif

#ifdef WIN32
  #pragma warning ( pop )
#endif

///@}

#endif /* _BASEEXTERNHDL_H_ */
