#ifdef _WIN32

#ifndef _STDSIGNALHANDLER_H_
#define _STDSIGNALHANDLER_H_

#include <SignalHandler.hxx>

/** The WIN32 standard signal handler. 
    This signal handler is used for communication with PVSSconsole.
    @classification ETM internal
*/
class DLLEXP_BASICS StdSignalHandler : public SignalHandler
{
public:
  /** Constructor.
        @param  sig The signal value which will be handled in this StdSignalHandler instance.
    */
  StdSignalHandler(int sig);
  /** Callback function of the worker thread.
        The implementation in this class raises the signal.
    */
  void callBack();
  /// Raise the SIGTERM signal.
  virtual void sigtermHandler();
};

#endif

#endif
