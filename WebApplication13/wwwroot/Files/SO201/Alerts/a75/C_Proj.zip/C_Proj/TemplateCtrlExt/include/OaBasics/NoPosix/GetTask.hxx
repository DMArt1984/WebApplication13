
/******************************************************************************\
*       This is a part of the Microsoft Source Code Samples. 
*		  Copyright (C) 1994-1995 Microsoft Corporation.
*       All rights reserved. 
*       This source code is only intended as a supplement to 
*       Microsoft Development Tools and/or WinHelp documentation.
*       See these sources for detailed information regarding the 
*       Microsoft samples programs.
\******************************************************************************/


#define PROCESS_SIZE        MAX_PATH


//
// task list structure
//
typedef struct _TASK_LIST {
    DWORD       dwProcessId;
    CHAR        ProcessName[PROCESS_SIZE];
} TASK_LIST, *PTASK_LIST;


DLLEXP_OABASICS DWORD GetTaskCount();

DLLEXP_OABASICS DWORD GetTaskId(const char* taskName);

