#ifndef _OPCBROWSER_H_
#define _OPCBROWSER_H_

#if defined (_WIN32) && !defined (_WIN32_WCE)

#include <ole2.h>
#include <DynVar.hxx>

class DLLEXP_OABASICS OPCBrowser
{
public:
  OPCBrowser(){}

  static int OPCEnumQuery( const int type, const DynVar &in,  DynVar &out);         // squirt, 25.3.2003, Projekt 061_2037
};

#endif _WIN32
#endif //_OPCBROWSER_H