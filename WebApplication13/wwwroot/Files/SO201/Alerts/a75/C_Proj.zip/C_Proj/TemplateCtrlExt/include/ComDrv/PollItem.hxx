// BESCHREIBUNG:   Die Klasse PollItem beinhaltet eine TimeVar = naechster
//                  Pollzeitpunkt und einen Zeiger auf HWMapDpPa.

#ifndef _POLLITEM_H_
#define _POLLITEM_H_

#ifndef _HWMAPPADP_H_
#include <HWMapDpPa.hxx>
#endif

#ifndef _TIMEVAR_H_
#include <TimeVar.hxx>
#endif

/** This class holds all entries needed in the PollList to execute one poll. 
  * The poll items are held by the PollList. The poll is done via single requests.
  * This class combines a HWMapDpPa object with a TimeVar (the next poll time) and a valid
  * flag, which is used to inhibit multible error messages.
  *  
  * @classification ETM internal
  */
class PollItem
{
  public:
    /** Constructor
    * @param tm time variable
    * @param rPtr ponter to HWMapDpPa
    */
    PollItem(const TimeVar& tm, HWMapDpPa* rPtr);

    /** Gets a polling time
    * @return the polling time
    */
    const TimeVar&   getPollTime() const { return pollTime; }

  /** Gets a reference pointer to HWMapDpPa
    * @return the reference pointer
    */
    HWMapDpPa* getRefPtr() const         { return refPtr; }

    /** Sets a polling time
    * @param tm new value of polling time to be set
    */
    void       setPollTime(const TimeVar& tm)  { pollTime = tm; }

  /** Indicates if an item is valid 
    * @return value of valid flag
    */
    PVSSboolean isValid() const {return valid;}

  /** Sets a item validity flag
    * @param state value of valid flag to be set
    */
    void        setValid(PVSSboolean state) {valid = state;}

  private:
    TimeVar    pollTime;
    HWMapDpPa* refPtr;
    PVSSboolean valid;
};


inline  PollItem::PollItem(const TimeVar &tm, HWMapDpPa *rPtr)
  : pollTime(tm), refPtr(rPtr), valid(PVSS_TRUE)
{
}


#endif
