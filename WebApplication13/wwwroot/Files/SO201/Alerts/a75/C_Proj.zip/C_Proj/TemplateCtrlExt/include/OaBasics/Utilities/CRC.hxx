#ifndef _CRC_H_
#define _CRC_H_

#include <Types.hxx>

class DLLEXP_OABASICS CRC32
{  
  public:
    /**
      Constructor
      @param polynomial: the polynomial in normal representation (least significant bit right) to be used
    */
    CRC32(PVSSulong polynomial);
   ~CRC32();

   /**
     Calculate the CRC
     @param data: the data, must not be NULL
     @param len: number of bytes
   */
   PVSSulong calculate(const void *data, size_t len, PVSSulong lastCRC = 0);

  public:
  /// Calculate the reverse form of a given polynomial
  static PVSSulong reverseForm(PVSSulong polynomial);

  private:
    void initTable();
    PVSSulong polynomial_; // in reversed notation
    PVSSulong lookupTable[8][256];
};


#endif