#ifndef _DPPROFIPERIPHADDRAUX_H_
#define _DPPROFIPERIPHADDRAUX_H_

// Vorwaerts-Deklaration der Eigenen Klasse
class PeriphAddrAux;

// System-Include-Files
#include <PeriphAddr.hxx>


// ................................Anfang User-Definitionen........................
// .................................Ende User-Definitionen.........................

// Vorwaerts-Deklarationen :
class CharString;
class DpConfig;
class PeriphAddrAux;

// ========== PeriphAddrAux ============================================================

/** The _address config class derived from the abstract PeriphAddr.
    This class enables to create an instance of _address config object.
    Currently not used.
    @classification ETM internal  
  */
class DLLEXP_CONFIGS PeriphAddrAux : public PeriphAddr 
{

  // Klassen-Enums:

// ..........................Anfang User-Klasseninterne-Definitionen..................
// ...........................Ende User-Klasseninterne-Definitionen...................
public:
  /// constructor, initialisation with zero values
  PeriphAddrAux();

  /// copy onstruktor
  /// @param profiAdr the PeriphAddr, which shall be copied from
  PeriphAddrAux(const PeriphAddrAux &profiAdr);

  /// destructor
  ~PeriphAddrAux();


  // Operatoren :

  /** operator << for itcNdrUbSend stream
      @param ndrStream the stream, which to send to
    */
  itcNdrUbSend &operator<<(itcNdrUbSend &ndrStream);

  /** operator >> for itcNdrUbReceive stream
      @param ndrStream the stream, which to receive from
    */
  itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream);

  /** non virtual assignment operator for PeriphAddrAux
      @param rVal the PeriphAddrAux to assign
      @return the resulting PeriphAddrAux
    */
  PeriphAddrAux &operator=(const PeriphAddrAux &rVal)
    { PeriphAddr::operator=((const PeriphAddr &) rVal); return *this; }

  // Spezielle Methoden :

  /// return type of DP config
  virtual DpConfigType isA() const;

  /// return size of DP config
  virtual unsigned long sizeOf() const;

	/** check if own DP config type matches other DP config type
      @param confType the DpConfigType to check
      @return DPCONFIG_PERIPH_ADDR if argument is PeriphAddr else the DP config type
    */
  virtual DpConfigType isA(DpConfigType confType) const;

  /// return type of DP config
  virtual DpConfigNrType getDpConfigNrUncached() const;

  /** allocate new PeriphAddrAux
      @return the new PeriphAddrAux
    */
  virtual DpConfig *allocate() const;

  // Generierte Methoden :
protected:
private:
};

// ================================================================================
// Inline-Funktionen :
inline unsigned long PeriphAddrAux::sizeOf() const
{
  return sizeof(PeriphAddrAux);
}

#endif /* _DPPROFIPERIPHADDRAUX_H_ */

