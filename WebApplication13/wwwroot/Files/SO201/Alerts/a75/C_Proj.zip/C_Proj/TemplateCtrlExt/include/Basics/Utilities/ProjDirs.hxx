#ifndef _PROJDIRS_H_
#define _PROJDIRS_H_

// VERANTWORTUNG: Andreas Pfluegl

#ifndef _CHARSTRING_H_
#include <CharString.hxx>
#endif

/** This class describes the relative path or filename, and then the action
  * which should be performed when creating a Project.
  * Each ProjDirs represents one line of the file (PVSS-Installation)\config\proj_dirs.
  * Used for example in PVSSConsole.
  * @n Note: Unit test for this class is included in the Pathes unit test.
  * @classification CoreTest
  */
class DLLEXP_BASICS ProjDirs
{
public:

protected:

  public:

    /// Enum representing what to do when creating a new Project.
    enum CreateProjectAction
    {
      /// copy file. Only Files have this action
      COPY_THIS_FILE,           

      /// create a empty Directory with the specified name
      CREATE_DIRECTORY,

      /// copy all Files of this Directory from Installation to the Project
      COPY_ALL_FILES,

      /// copy the whole tree from the Installation to the Project
      COPY_WHOLE_TREE,          

      /// rename file (used for update of old projects).
      /// - syntax for file name string: "newName<oldName", 
      /// - syntax in proj_dirs-file: "ren:newName<oldName"
      RENAME_FILE               
    };

    /// Constructor.
    /// @param fileName File or Directory (relative path).
    /// @param action CreateProjectAction specifying what to do with the fileName.
    ProjDirs(CharString fileName, CreateProjectAction action)
      : fileName_(fileName), action_(action) {}

    /// Destructor.
    ~ProjDirs() {}

    /// Get the project action specified in the constructor.
    /// @return CreateProjectAction.
    CreateProjectAction getAction() const;
    
    /// Get the file name specified in the constructor.
    /// @return CharString with the file name.
    CharString getFileName() const;
    
  private:

    /// private member for storing the file or directory name (relative path).
    CharString fileName_;

    /// private member specifying what to do when creating a new Project.
    CreateProjectAction action_;
};

// -----------------------------------------------------------------------------------------------
// -----------------------------------------------------------------------------------------------
// -----------------------------------------------------------------------------------------------
#ifdef WIN32
#pragma warning ( disable: 4231 )
#endif

#if defined(LIBS_AS_DLL)
  #include <DynPtrArray.hxx>
  EXTERN_BASICS template class DLLEXP_BASICS DynPtrArray<ProjDirs>;
#endif

#ifdef WIN32
#pragma warning ( default: 4231 )
#endif


// -----------------------------------------------------------------------------------------------
// -----------------------------------------------------------------------------------------------
// -----------------------------------------------------------------------------------------------
inline ProjDirs::CreateProjectAction ProjDirs::getAction() const
{
  return(action_);
}

// -----------------------------------------------------------------------------------------------
inline CharString ProjDirs::getFileName() const
{
  return(fileName_);
}

#endif /* _PROJDIRS_H_ */
