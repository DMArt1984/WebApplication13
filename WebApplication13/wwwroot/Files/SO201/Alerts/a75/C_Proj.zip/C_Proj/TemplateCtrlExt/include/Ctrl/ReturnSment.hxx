#ifndef _RETURNSMENT_H_
#define _RETURNSMENT_H_

#include <CtrlSment.hxx>

class CtrlExpr;

/*  author VERANTWORTUNG: Mark Probst */
/** the return statement */
class DLLEXP_CTRL ReturnSment : public CtrlSment
{
  public:
    ///called by YACC: theExpr will be deleted in the destructor, theFunc not.
    ReturnSment(CtrlExpr *theExpr, int line, int filenum)
      : CtrlSment(line, filenum), expr(theExpr) { }

    /// destructor
    virtual ~ReturnSment();

    /// set the returnvalue, returns NULL
    virtual const CtrlSment *execute(CtrlThread *thread) const;

    virtual const CtrlExpr *getFirstExpr(CtrlThread *thread) const;

    virtual void writeTrace(CtrlThread *thread, bool writeValue = true) const;

    virtual bool checkIntegrity(const CharString &location, CtrlThread *) const;

    /** Is the sment of the specified type ?
      * @param type given type
      * @return TRUE  Sment is of type "type"
      * @return FALSE Sment is not of type "type"
      */
    virtual int isA(SmentType type) const { return (type == SMENT_RETURN); }

  private:
    CtrlExpr *expr;
};

#endif // _RETURNSMENT_H_

