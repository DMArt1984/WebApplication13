// **************** PVSS VERSION INFO *************

// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
// do NOT CHANGE version number/patchstring in here,
// use the CMakeDefines.txt file
// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!


// PVSS version name, format: <n>.<n>[.<n>[.<n>]]
// used in CTRL constant VERSION
#ifndef PVSS_VERSION
#  define PVSS_VERSION     "3.17"
#endif

// might include SP1 etc., e.g. "3.7-SP1"
// used in CTRL constant VERSION_DISP
#ifndef PVSS_VERSION_DISP
#  define PVSS_VERSION_DISP "3.17"
#endif

// *** preliminary version *** - warning
// (default, except on version servers):
#ifndef PVSS_VERS_SERVER
#  ifndef PVSS_VERS_WARNING
#    define PVSS_VERS_WARNING ""
#  endif
#else
#  ifndef PVSS_VERS_WARNING
#    define PVSS_VERS_WARNING ""
#  endif
#endif




// [ <additional Text>]
#ifndef PVSS_VERS_COMMENT
#  define PVSS_VERS_COMMENT ""
#endif

#ifndef PVSS_PATCH
// must be exactly set != "" for branch-versions ( e.g. "SP") or at least to blank (" ")!:
#  define PVSS_PATCH        " "
#endif

//-------------------------------------------------------------------
// defines f. WIN32 - Versionsinfo, auch im C++ - Code verwendbar:
//

// PVI_VERSION_X may be overridden by some PVSS version independet utilities,
// e.g. RiClient.exe (Exe/RemoteInstall):
#ifndef PVI_VERSION_X
#  define PVI_VERSION_X  3
#endif

// PVI_VERSION_Y may be overridden by some PVSS version independet utilities,
// e.g. RiClient.exe (Exe/RemoteInstall):
#ifndef PVI_VERSION_Y
#  define PVI_VERSION_Y  17
#endif

// PVI_VERSION_Z may be overridden by daily build number
#ifndef PVI_VERSION_Z
#  define PVI_VERSION_Z  0
#endif

// PVI_PATCH_NUM is replaced by actual patch number in "make:" directive
// of patch generation (mkPatch.sh -gen):
#ifndef PVI_PATCH_NUM
#  define PVI_PATCH_NUM  0
#endif

#define MK_STR2(s)  #s
#define MK_STR(s) MK_STR2(s)

#define MK_STRINGLIST(x,y,z,p) MK_STR(x) ", " MK_STR(y) ", " MK_STR(z) ", " MK_STR(p)

#define PVI_VERSION_STRING MK_STRINGLIST(PVI_VERSION_X, PVI_VERSION_Y, PVI_VERSION_Z, PVI_PATCH_NUM)

#ifndef PVI_PRODUCT_NAME
#  define PVI_PRODUCT_NAME "PVSS " PVSS_VERSION " " PVSS_VERS_COMMENT
#endif

#ifndef PVI_COMPANY_NAME
#  define PVI_COMPANY_NAME "ETM professional control GmbH"
#endif

#ifndef PVI_COPYRIGHT
#  define PVI_COPYRIGHT "(c) 1997-2018 " PVI_COMPANY_NAME
#endif

#define PVI_COPYRIGHT_LONG "Copyright " PVI_COPYRIGHT

//-------------------------------------------------------------------


