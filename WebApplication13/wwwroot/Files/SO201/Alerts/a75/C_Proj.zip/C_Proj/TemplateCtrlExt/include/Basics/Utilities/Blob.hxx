#ifndef _BLOB_H_
#define _BLOB_H_

/*
VERANTWORTUNG: Robert Trausmuth
BESCHREIBUNG: binary large objects
*/

#ifndef _TYPES_HXX_
#include <Types.hxx>
#endif

#ifndef _ALLOCATOR_H_
#include <Allocator.hxx>
#endif

#include <iostream>

class itcNdrUbSend;
class itcNdrUbReceive;

/** The BLOB class. This class implements a raw data type used for binary data. The data is managed 
    like basic strings, for example the length of the buffer is stored. Therefore bytes with any value
    (including '\0') can be stored here.
*/
class DLLEXP_BASICS Blob
{
  public:
    /** Constructor.
    */ 
    Blob() : dataLen(0), dataPtr(0) {}

    /** Constructor. Take data as blob data and copy if requested.
        @param data The pointer to the data buffer. Keep in mind that data is captured depending on the 
        third parameter!
        @param len The length of the data pointed to.
        @param copy Set this to PVSS_TRUE when the blob object should copy the data buffer rather than capturing it.
   */
    Blob(PVSSuchar *data, PVSSulong len, PVSSboolean copy = PVSS_FALSE);
    
    /** Constructor. Read data and convert it to Blob. The data buffer holds a string which contains a hex 
        data description. Each byte for the blob is described by two hex digits. The string may look like "0A005F4423".
        @param data The string buffer containing the hex description for the blob to create.
    */
    Blob(const PVSSuchar *data);

    /** Destructor.
    */
    ~Blob();

    /** Copy constructor.
    */
    Blob(const Blob &);

    /** Declares new and delete operator.
    */
    AllocatorDecl;

    /** Assignment operator.
        @return Blob instance with assigned value.
    */
    Blob &operator=(const Blob &);

    /** Concatenation operator.
        @return Reference to the concatenated Blob.
   */
    const Blob & operator += (const Blob &);

    /** Equality operator using memcmp.
        @return int 1 if true, otherwise 0.
   */
    int operator == (const Blob &) const;

    /** The less than operator using memcmp.
        @return int 1 if true, otherwise 0.
   */
    int operator <  (const Blob &) const;

    /** The greater than operator using memcmp.
        @return int 1 if true, otherwise 0.
    */
    int operator >  (const Blob &) const;

    /** Non-equality operator using memcmp.
        @param b Blob to compare with this.
        @return int 1 if true, otherwise 0.
    */
    int operator != (const Blob &b) const { return (! operator==(b) );}

    /** Outputs the Blob to the std::ostream.
        @param to Output stream.
        @return std::ostream stream.
    */ 
    friend DLLEXP_BASICS std::ostream &operator<<(std::ostream &to, const Blob &);

    //    friend std::istream &operator>>(std::istream &from, Blob &);
    
    /** Outputs the Blob to the itcNdrUbSend stream.
        @param ndrStream Output stream.
        @return itcNdrUbSend stream.
    */    
    friend DLLEXP_BASICS itcNdrUbSend &operator<<(itcNdrUbSend &ndrStream, const Blob &);
    
    /** Receives the LongVar value from the itcNdrUbReceive stream.
        @param ndrStream Input stream.
        @return itcNdrUbReceive stream.
    */    
    friend DLLEXP_BASICS itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream, Blob &);

    /** Set the pointer to the data buffer. The pointer is captured if copy is PVSS_FALSE.
        @param data Pointer with data.
        @param len Length of the data in bytes.
        @param copy If PVSS_TRUE, data will be copied (deep copy), otherwise the pointer 
        will be captured (shallow copy).
    */
    void setData(PVSSuchar *data, PVSSulong len, PVSSboolean copy = PVSS_FALSE);

    /** Returns a pointer to the internal data buffer. Do not delete the pointer!
        @return PVSSuchar* to the data buffer.
    */
    const PVSSuchar *getData() const { return dataPtr; }
    
    /** Cut the data pointer (set it to zero without deleting).
        @return Original pointer to the data buffer (before cut).
    */
    PVSSuchar *cutData();

    /** Get the blob data buffer length.
        @return size_t Size of the buffer.
    */
    size_t getLen() const { return dataLen; }

    /** Get the blob data buffer length.
        @return size_t Size of the buffer.
    */
    size_t size() const { return dataLen; } 

    /** The convert to text function. This function creates a string which contains a hex description of the blob.
        Each byte of the blob is represented by two hex digits.
        Since this function dynamically allocates the string buffer, you are responsible for deleting it after use!
        @return PVSSuchar* pointer to the newly allocated string representation of the Blob.
    */
    PVSSuchar *toText() const;

    /** Same as toText() above, but writes up to len bytes to given buffer.
        Special case: if buffer is too small, content is truncated and ends with " ..."; returnvalue is then -2
        Buffersize must be 2*getLen()+1 to contain full Blob content including the ending 0-byte.
        @param target char* to the buffer.
        @param len Number of bytes to be copied. 2*getLen()+1 will copy the whole Blob data.
        @return Number of bytes written (without the trailing 0-byte), -1 on failure and -2 when the
        string was truncated.
    */
    int toText(char *target, size_t len) const;

    /** Static version of toText(char *, size_t).
        @param data An array of bytes that will be printed as hex digits into target.
        @param dataLen The number of bytes from data that will be printed.
        @param target pointer to the buffer into which the hex string will be written.
        @param targetLen Length of the target buffer. It is assumed to include
                         the terminating null character. 2*dataLen+1 will copy the whole Blob data.
        @return Number of bytes written (without the trailing 0-byte), -1 on failure and -2 when the
        string was truncated.
    */
    static int toText(const PVSSuchar *data, size_t dataLen, char *target, size_t targetLen);

    /** The convert from text function. This function fills the blob data buffer with bytes according to the
        hex description in the string parameter.
    */
    void fromText(const PVSSuchar *);

    /** Returns a writable pointer to the internal data buffer. Do not delete the pointer!
    @return char* to the data buffer.
    */
    char *getCharData() { return reinterpret_cast<char *>(dataPtr); }

    /** Returns a pointer to the internal data buffer. Do not delete the pointer!
    @return char* to the data buffer.
    */
    const char *getCharData() const { return reinterpret_cast<const char *>(dataPtr); }

  private:

    PVSSulong dataLen;
    PVSSuchar *dataPtr;
};

#endif /* _BLOB_H_ */
