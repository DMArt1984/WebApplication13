#ifndef _LOOPSMENT_H_
#define _LOOPSMENT_H_

#include <CtrlSment.hxx>

class CtrlExpr;

/*  author VERANTWORTUNG: Mark Probst */
/** abstract base class for all loop statements (do, while, for) */
class DLLEXP_CTRL LoopSment : public CtrlSment
{
  public:
    /// Constructor, called from parser
    LoopSment(int line, int filenum) : CtrlSment(line, filenum), expr(0), block(0) {}

    ~LoopSment();

    /// Get the expression to evaluate after the first loop.
    virtual const CtrlExpr *getIterationExpr(CtrlThread *) const = 0;

    virtual int isA(SmentType type) const;

    void setBlock(CtrlSment *list) { block = list; }

    virtual bool checkIntegrity(const CharString &location, CtrlThread *thread) const;

  protected:
    CtrlExpr  *expr;
    CtrlSment *block;

    friend class EditorWidget;
};

#endif // _LOOPSMENT_H_

