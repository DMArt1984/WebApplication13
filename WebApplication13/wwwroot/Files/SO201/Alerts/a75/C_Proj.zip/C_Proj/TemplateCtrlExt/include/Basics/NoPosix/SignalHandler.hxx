#ifndef _SIGNALHANDLER_H_
#define _SIGNALHANDLER_H_

#ifdef _WIN32
#  include <windows.h>
#endif

#include <signal.h>

#ifndef SIGTERM
#define SIGTERM 15
#endif

#ifndef SIGKILL
#define SIGKILL 9
#endif

#ifndef SIGINT
#define SIGINT 2
#endif

#ifndef SIGQUIT
#define SIGQUIT 3
#endif

/** A signal handler class.
    This class is used for WIN32 only, since there are no signals in the UNIX way.
    One exception: The static kill() method can also be used on UNIX.
    @classification ETM internal
*/
class DLLEXP_BASICS SignalHandler
{
  public:
#ifdef _WIN32
    /** Constructor.
        @param  sig The signal value which will be handled in this SignalHandler instance.
        @param  stack Stack size of the worker thread.
    */
    SignalHandler(int sig, unsigned int stack = 8192);
    /// Destructor.
    ~SignalHandler();
    /// Start worker thread.
    int start();
    /** Callback function of the worker thread.
        This is pure virtual function and must be overridden in the derived class.
        In this function, the derived class sends the signal to the process.
    */
    virtual void callBack() = 0;
    /// Returns the signal value to be handled.
    int getSignal() { return sigToCatch; }
#endif

    /** Kill the process.
        If SIGKILL signal value is used, the process is terminated using TerminateProcess API function. Otherwise, the signal is send to the process.
        @param  pid The process ID of the process to be killed.
        @param  sig The signal value to be used.
    */
    static int kill(int pid, int sig);

  protected:
#ifdef _WIN32
    /// The thread function.
    static DWORD waitThread(LPVOID arg);
    /** Set/remove SE_PRIVILEGE_ENABLED priviledge for this process.
        @param  bEnablePrivilege If TRUE, the priviledge is set, otherwise it is removed.
    */
    static BOOL SetDebugPrivilege(BOOL bEnablePrivilege);
#endif

  private:
#ifdef _WIN32
    static void makeEventName(char *eventName, int sig, int pid);

    int sigToCatch;
    unsigned int stackSize;
    HANDLE eventHandle;
    HANDLE threadHandle;
    char eventName[64];
#endif
};

#endif
