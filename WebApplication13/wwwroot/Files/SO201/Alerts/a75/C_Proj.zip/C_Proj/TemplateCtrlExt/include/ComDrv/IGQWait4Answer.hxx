// DATEIBESCHREIBUNG ==============================================================
// VERANTWORTUNG: Robert Trausmuth
// BESCHREIBUNG:  Klasse zur Abarbeitung einer PVSS-seitigen Generalabfrage
// ======================================Ende======================================

#ifndef _IGQWAIT4ANSWER_H_
#define _IGQWAIT4ANSWER_H_

#ifndef _WAITFORANSWER_H_
#include <WaitForAnswer.hxx>
#endif

class DpMsgAnswer;

/** The internal general query datapoint answer handler.
    This class handles the ComDrv PVSS-general query data values.
    @classification ETM internal
*/
class IGQWait4Answer : public WaitForAnswer
{
public:
  /** The callback function.
      This function will receive answer messages.

      @param answer The answer message received.
     */
  virtual void callBack(DpMsgAnswer &answer);
};

#endif /* _IGQWAIT4ANSWER_H_ */
