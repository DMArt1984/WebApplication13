// DATEIBESCHREIBUNG ==============================================================
// DATEINAME:     DpFlutterHdl.hxx
// 
//
// AENDERUNGS-HISTORIE
// Ver.  | Datum      | Aenderungen                            | ModNr.| Autor
// ------+------------+-----------------Anfang-----------------+-------+-----------
//   1.0 |            | 1.Erstellung mit Westmount-OMT         |     0 |
// ======================================Ende======================================
#ifndef _DPFLUTTERHDL_H_
#define _DPFLUTTERHDL_H_

// Vorwaerts-Deklaration der Eigenen Klasse
class DpFlutterHdl;

// System-Include-Files
#ifndef _DPCONVSMOOTHCONTAINER_H_
#include <DpConvSmoothContainer.hxx>
#endif

#ifndef _BITVAR_H_
#include <BitVar.hxx>
#endif

#ifndef _TIMEVAR_H_
#include <TimeVar.hxx>
#endif

// BCM header
#include <ItcIOHandler.h>

/** the flutter handler class.
    @classification ETM internal
*/
class DpFlutterHdl : public itcIOHandler 
{
public:

  /** Constructor
    * @param aSysNum system number type
    * @param aDpId dp identifier type
    * @param anElNo dp element identifier
    * @param aConvIndex dynamic pointer array index
    */
  DpFlutterHdl(SystemNumType aSysNum, DpIdType aDpId, DpElementId anElNo, DynPtrArrayIndex aConvIndex);

  /** Destructor
    */
  ~DpFlutterHdl();

  // Spezielle Methoden :
  /** Activities after timer expiration, callback function. 
    * fuction is called from the system whenever the timeout expires
    * @param sec
  * @param usec
    */
  void timerExpired(long int sec, long int usec) override;

  // Generierte Methoden :
  /** Get sysNum
    * @return sysNum
    */
  const SystemNumType &getSysNum() const;

  /** Get sysNum
    * @return sysNum
    */
  SystemNumType &getSysNum();
  
  /** Set sysNum
    * @param newSysNum new sysNum to set
    */
  void setSysNum(const SystemNumType &newSysNum);

  /** Get id of the datapoint
    * @return dpId id of the datapoint
    */
  const DpIdType &getDpId() const;

  /** Set id of the datapoint
    * @param newDpId new dp identifikacator to set
    */
  void setDpId(const DpIdType &newDpId);

  /** Get element id
    * @return element id
    */
  const DpElementId &getElNo() const;

  /** Get element id
    * @return element id
    */
  DpElementId &getElNo();

  /** Set element id
    * @param newElNo new element id
    */
  void setElNo(const DpElementId &newElNo);

  /** Get ConvIndex
    * @return convIndex
    */
  const DynPtrArrayIndex &getConvIndex() const;

  /** Set ConvIndex
    * @param newConvIndex
  */ 
  void setConvIndex(const DynPtrArrayIndex &newConvIndex);

  /** Get DueTime
    * @return dueTime
    */
  const TimeVar &getDueTime() const;
  
  /** Get DueTime
    * @return dueTime
    */
  TimeVar &getDueTime();

  /** Set DueTime
    * @param newDueTime 
    */
  void setDueTime(const TimeVar &newDueTime);

protected:
private:
  SystemNumType sysNum;
  DpIdType dpId;
  DpElementId elNo;
  DynPtrArrayIndex convIndex;
  TimeVar dueTime;

public:  
    /** Allocates a new DpFlutter handler
    * @param sys system type number
    * @param dp Dp type number
    * @param el Dp element id
    * @param idx index array
    * @param due expiration time
    */
  static itcIOHandler *allocate(const SystemNumType &sys, const DpIdType &dp, const DpElementId &el, const DynPtrArrayIndex &idx, const TimeVar &due);
                                
// ............................Anfang User-Attribut-Definitionen...................
// .............................Ende User-Attribut-Definitionen....................
};

// ================================================================================
// Inline-Funktionen :
inline const SystemNumType &DpFlutterHdl::getSysNum() const
{
  return sysNum;
}

inline SystemNumType &DpFlutterHdl::getSysNum()
{
  return sysNum;
}
inline void DpFlutterHdl::setSysNum(const SystemNumType &newSysNum)
{
  sysNum = (SystemNumType &) newSysNum;
}
inline const DpIdType &DpFlutterHdl::getDpId() const
{
  return dpId;
}

inline void DpFlutterHdl::setDpId(const DpIdType &newDpId)
{
  dpId = (DpIdType &) newDpId;
}
inline const DpElementId &DpFlutterHdl::getElNo() const
{
  return elNo;
}

inline DpElementId &DpFlutterHdl::getElNo()
{
  return elNo;
}
inline void DpFlutterHdl::setElNo(const DpElementId &newElNo)
{
  elNo = (DpElementId &) newElNo;
}
inline const DynPtrArrayIndex &DpFlutterHdl::getConvIndex() const
{
  return convIndex;
}

inline void DpFlutterHdl::setConvIndex(const DynPtrArrayIndex &newConvIndex)
{
  convIndex = (DynPtrArrayIndex &) newConvIndex;
}
inline const TimeVar &DpFlutterHdl::getDueTime() const
{
  return dueTime;
}

inline TimeVar &DpFlutterHdl::getDueTime()
{
  return dueTime;
}
inline void DpFlutterHdl::setDueTime(const TimeVar &newDueTime)
{
  dueTime = (TimeVar &) newDueTime;
}

// ............................Anfang User-Inlines.................................
// .............................Ende User-Inlines..................................

// ................................OMT-Regeneration................................

#endif /* _DPFLUTTERHDL_H_ */
