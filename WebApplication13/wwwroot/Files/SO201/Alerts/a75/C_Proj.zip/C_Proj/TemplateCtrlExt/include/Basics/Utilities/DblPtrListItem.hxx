// DATEIBESCHREIBUNG ==============================================================
// DATEINAME:     DblPtrListItem.hxx
// VERANTWORTUNG:	Thomas Koroschetz
// BESCHREIBUNG:	DblPtrListItem ist die Basisklasse fuer doppelt verkettete
// 		Liste von Objekten.
// ======================================Ende======================================

#ifndef _DBLPTRLISTITEM_H_
#define _DBLPTRLISTITEM_H_

// Vorwaerts-Deklaration der Eigenen Klasse
class DblPtrListItem;

// System-Include-Files
#ifndef _TYPES_HXX_
#include <Types.hxx>
#endif

#ifndef _PTRLISTITEM_H_
#include <PtrListItem.hxx>
#endif

/** the DblPtrListItem class. derive your classes from this one if you want to store them
    in a double pointer list.
    @classification public use, overload
*/
class DLLEXP_BASICS DblPtrListItem : public PtrListItem
{

  // Klassen-Enums:
  friend class DblPtrList;
  friend class UNIT_TEST_FRIEND_CLASS;

public:
  /// constructor
  DblPtrListItem();
  /// destructor
  virtual ~DblPtrListItem();

  DblPtrListItem * Next() const {return (DblPtrListItem *) nextPtr;}
  DblPtrListItem * Prev() const {return prevPtr;}

  DblPtrListItem * getNextItem() const     {return (DblPtrListItem *) nextPtr;}
  DblPtrListItem * getPreviousItem() const {return prevPtr;}

private:
  DblPtrListItem *prevPtr;
};

#endif /* _DBLPTRLISTITEM_H_ */
