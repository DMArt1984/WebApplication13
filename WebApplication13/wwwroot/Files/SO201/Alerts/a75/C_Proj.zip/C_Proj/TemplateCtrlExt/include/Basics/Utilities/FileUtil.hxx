#ifndef _FILEUTIL_H_
#define _FILEUTIL_H_

#ifndef _TYPES_HXX_
#include <Types.hxx>
#endif

#ifndef _CHARSTRING_H_
#include <CharString.hxx>
#endif

////////////////////////////////////////////////////////////////////
// useful cpp-macros:
#define UT_BASENAME FileUtil::baseName
#define UT_DIRNAME  FileUtil::dirName

#define UT_JOINPATH FileUtil::joinPathFile
#define UT_ADDLOG   FileUtil::addLog



/** 
 * The file utility class.
 * this class uses FileSys
 */
class DLLEXP_BASICS FileUtil
{
public:
 /** split path and file from pathname. Works with "\" or "/" like 'dirname' and 'basename'
  in the posix-shell. Following cases were testet:
  <P># --------------------
   <P>/a/b => /a + b
   <P>/a   => /  + a
   <P>a/b  => a  + b
   <P>a    => .  + a
   <P>./a  => .  + a
   <P>.    => .  + .
   <P>/    => /  + /
   <P>""   => "" + ""
  <P># --------------------
   <P>\a\b => \a + b
   <P>\a   => \  + a
   <P>a\b  => a  + b
   <P>a    => .  + a
   <P>.\a  => .  + a
   <P>.    => .  + .
   <P>\    => \  + \
   <P>""   => "" + ""
  <P># --------------------
   <P>/a/b/ => /a + b
   <P>/a/   => /  + a
   <P>a/b/  => a  + b
   <P>a/    => .  + a
   <P>./a/  => .  + a
   <P>./    => .  + .
   <P>//    => /  + /
   <P>/     => /  + /
  <P># --------------------
   <P>\a\b\ => \a + b
   <P>\a\   => \  + a
   <P>a\b\  => a  + b
   <P>a\    => .  + a
   <P>.\a\  => .  + a
   <P>.\    => .  + .
   <P>\\    => \  + \
   <P>\     => \  + \
   </P>
    @param fileWithPath  ... "/ABC/DEF/" is treated as "/ABC/DEF". Must be trimmed.
    @param pathName  ... can never be empty, but: ".", has NO trailing PATH_CHAR !
    @param fileName  ...
    @return new path name
  */
  static void splitPathFile( const char * fileWithPath, CharString &dirName, CharString &baseName );

  /** =~ posix-shell-"dirname". Works with "\" or "/".
  @see splitPathFile()
  @param fileWithPath  ... "/ABC/DEF/" is treated as "/ABC/DEF". Must be trimmed.
  @return $( dirname $fileWithPath ), NO trailing PATH_CHAR.
  */
  static CharString dirName( const char * fileWithPath )
  {
    CharString dn, bn;
    splitPathFile( fileWithPath, dn, bn );
    return dn;
  };


  /** gets any extension (characters following last "." in fileName)
  @param fileName ... with or without path
  @return extension of the file without leading dot
  */
  static CharString getExt( const char * fileName);


  /** removes any extension (last "." in fileName and following characters)
  @param fileName ... with or without path
  @return fileName without extension
  */
  static CharString delExt( const char * fileName);


  /** =~ posix-shell-"basename". Works with "\" or "/".
  @see splitPathFile()
  @param fileWithPath ... "/ABC/DEF/" is treated as "/ABC/DEF".
  @param extension    ... suffix to remove, or: "*" = remove any extension.
                          Suffix comparition is done by @see FileSys:cmpPathNames()
  @return $( basename $fileWithPath [$suffix] )
  */
  static CharString baseName( const char * fileWithPath, const char * suffix = 0 );


  /** concatenate path and file using FileSys::PATH_CHAR and form a new pathname
  @param pathName directory name to concatenate
  @param fileName file name to concatenate
  @return the new path name
  */
  static CharString joinPathFile(const char * dirName, const char * baseName );

  /** shift logfiles: [destPath/]logfile.<n> => [destPath/]logfile.<n+1>, logfile => [dest_path/]logfile.0
  @param fileWithPath ... source dir and file
  @param destPath     ... "" or 0 = shift + move in source dir
  @param maxKeep      ... how many versions do you want to keep ?
  @return 0 = success
  */
  static int addLog( const char *fileWithPath, const char *destPath,  int maxKeep );

  /** look for text according to key in catalog file; on error return error message
  @param catalogue ... catalog file
  @param msgKey    ... key for lookup the text
  @return found text
  */
  static CharString catgets(
    const CharString &catalogue,
    const CharString &msgKey);

  /** look for text according to key in catalog file; on error return error message
  @param catalogue ... catalog file
  @param msgKey    ... key for lookup the text
  @param found     ... indicates wether an error occured or not
  @return found text or error text
  */
  static CharString catgets(
    const CharString &catalogue,
    const CharString &msgKey,
    bool &found);

  /** get the size of a directory by adding (recursively) the sizes of all files
  @param dirname   ... directory name
  @param recursive ... do it recursively ?
  @return size in bytes
  */
  static PVSSdouble getDirSize ( const char *dirname, PVSSboolean recursive = PVSS_FALSE);

private:
  /** constructor. Private so no one instantiates this class
	*/
  FileUtil() {};  //COVINFO LINE: defensive (AP: no instance allowed)
};

#endif /* _FILEUTIL_H_ */
