#ifndef _TREEHWMAPPER_COMPARATORS_H_
#define _TREEHWMAPPER_COMPARATORS_H_

// TreeHWMapperComparators.hxx

#include <HWMapDpPa.hxx>
#include <HWObject.hxx>
#include <DrvManager.hxx>

#include <set>
using namespace std;

typedef HWMapDpPa * HWPA;

/// Wrapper for the HWMapDpPa class sorted by DpIdentifier
class HWPADP
{
public:
    /// constructor
    /// @param p Pointer to HWMapDpPa instance
    HWPADP(HWMapDpPa *p) : ptr_(p) {}

    /// const cast operator to HWMapDpPa*
    const HWMapDpPa * operator() () const {return ptr_;}
    
    /// cast operator to HWMapDpPa*
    HWMapDpPa * operator() () { return ptr_;}

private:
    /// internally stored pointer
    HWMapDpPa *ptr_;
};

/// Equal-to operator for the HWPADP wrapper
inline bool operator ==(const HWPADP &p1, const HWPADP &p2)
{
    if (! p1() || ! p2()) return false;
    // static DpIdentifier dp1, dp2;

    if (p1()->getDp() != p2()->getDp()) return false;
    if (p1()->getEl() != p2()->getEl()) return false;

    return true;

}

/// Less-than operator for the HWPADP wrapper
inline bool operator <(const HWPADP &p1, const HWPADP &p2)
{
    if (! p1() || ! p2()) return false;
    // static DpIdentifier dp1, dp2;

    if (p1()->getDp() < p2()->getDp()) return true;
    if ((p1()->getDp() == p2()->getDp()) && (p1()->getEl() < p2()->getEl())) return true;

    return false;

}

/// Wrapper for the HWMapDpPa class sorted by address
class HWPAAD
{
public:
    /// constructor
    /// @param p Pointer to HWMapDpPa instance
    HWPAAD(HWMapDpPa *p) : ptr_(p) {}

    /// const cast operator to HWMapDpPa*
    const HWMapDpPa * operator() () const {return ptr_;}

    /// cast operator to HWMapDpPa*
    HWMapDpPa * operator() () { return ptr_;}

private:
    /// internally stored pointer
    HWMapDpPa *ptr_;
};

/// Equal-to operator for the HWPAAD wrapper
inline bool operator ==(const HWPAAD &p1, const HWPAAD &p2)
{
    if (! p1() || ! p2()) return false;
    if (p1()->getConfigPtr()->getConnectionId() != p2()->getConfigPtr()->getConnectionId()) return false;

    return (p1()->getConfigPtr()->getName() == p2()->getConfigPtr()->getName());
}

/// Less-than operator for the HWPAAD wrapper
inline bool operator <(const HWPAAD &p1, const HWPAAD &p2)
{
    // for performance reasons use local vars
    const PeriphAddr *cp1, *cp2;

    if (! p1() || ! p2()) return false;
    cp1 = p1()->getConfigPtr();
    cp2 = p2()->getConfigPtr();

    long tmpId = (long)cp1->getConnectionId() - (long)cp2->getConnectionId();
    if (tmpId < 0) return true;
    if (tmpId > 0) return false;

    // same connectionId
    int rs = cp1->getName().compareWithHash(cp2->getName());
    return 
      (rs < 0) || 
      ((rs == 0) && (cp1->getSubindex() < cp2->getSubindex()));
}

/// Equal-to operator comparing elements of HWPADP and HWPAAD
inline bool operator ==(const HWPADP &p1, const HWPAAD &p2)
{
    if (! p1() || ! p2()) return false;
    if (p1()->getConfigPtr()->getConnectionId() != p2()->getConfigPtr()->getConnectionId()) return false;
    return (p1()->getConfigPtr()->getName() == p2()->getConfigPtr()->getName());
}

typedef set<HWPADP> DPSET;
typedef multiset<HWPAAD> PASET;
typedef DPSET::iterator DPSET_Iterator;
typedef PASET::iterator PASET_Iterator;

/// Class for comparing HWObject and HWMapDpPa class by address
class Compare_HWPA
{
public:
    /// cast operator
    /// @param data Pointer to HWObject
    /// @param ptr Pointer to HWMapDpPa
    bool operator() (const HWObject* data, const HWMapDpPa *ptr)
    {
        return ((data->getConnectionId() == ptr->getConfigPtr()->getConnectionId()) && (data->getAddress() == ptr->getConfigPtr()->getName()));
    }
};

//------------------------------------------------------------

// HWObject wrappers

/// Wrapper for the HWObject class sorted by periphaddr
class HWObjAS
{
public:
    /// constructor
    /// @param p Pointer to HWObject instance
    HWObjAS(HWObject *p) : ptr_(p) {}

    /// const cast operator to HWObject* 
    const HWObject * operator() () const {return ptr_;}

    /// cast operator to HWObject* 
    HWObject * operator() () { return ptr_;}

private:
    /// internally stored pointer
    HWObject *ptr_;
};

/// Equal-to operator for the HWObjAS wrapper
inline bool operator ==(const HWObjAS &p1, const HWObjAS &p2)
{
    if (! p1() || ! p2()) return false;
    if (p1()->getConnectionId() != p2()->getConnectionId()) return false;

    return (p1()->getAddress() == p2()->getAddress());
}

/// Less-than operator for the HWObjAS wrapper
inline bool operator <(const HWObjAS &p1, const HWObjAS &p2)
{
    if (! p1() || ! p2()) return false;
    long tmpId = (long)p1()->getConnectionId() - (long)p2()->getConnectionId();
    if (tmpId < 0) return true;
    if (tmpId > 0) return false;

    // same connectionId - use strcmp
    // return (p1()->getAddress().cmp(p2()->getAddress()) < 0);
    return (p1()->getAddress().compareWithHash(p2()->getAddress()) < 0);    // use same comparison func as for HWMapDpPa objects
}

/// Wrapper for the HWObject class sorted by HWAddr
class HWObjHW
{
public:
    /// constructor
    /// @param p Pointer to HWObject instance
    HWObjHW(HWObject *p) : ptr_(p) {}

    /// const cast operator to HWObject* 
    const HWObject * operator() () const {return ptr_;}

    /// cast operator to HWObject* 
    HWObject * operator() () { return ptr_;}

private:
    /// internally stored pointer
    HWObject *ptr_;
};

/// Equal-to operator for the HWObjHW wrapper
inline bool operator ==(const HWObjHW &p1, const HWObjHW &p2)
{
    if (! p1() || ! p2()) return false;
    return (! DrvManager::getHWMapperPtr()->compare_HWHW(p1(),p2()));
}

/// Less-than operator for the HWObjHW wrapper
inline bool operator <(const HWObjHW &p1, const HWObjHW &p2)
{
    if (! p1() || ! p2()) return false;
    return (DrvManager::getHWMapperPtr()->compare_HWHW(p1(),p2()) < 0);
}

/// Equal-to operator comparing elements of HWObjAS and HWObjHW
inline bool operator ==(const HWObjAS &p1, const HWObjHW &p2)
{
    if (! p1() || ! p2()) return false;
    if (p1()->getConnectionId() != p2()->getConnectionId()) return false;
    return (p1()->getAddress() == p2()->getAddress());
}

typedef multiset<HWObjAS> HWADSET;
typedef multiset<HWObjHW> HWHWSET;
typedef HWADSET::iterator HWADSET_Iterator;
typedef HWHWSET::iterator HWHWSET_Iterator;

#endif
