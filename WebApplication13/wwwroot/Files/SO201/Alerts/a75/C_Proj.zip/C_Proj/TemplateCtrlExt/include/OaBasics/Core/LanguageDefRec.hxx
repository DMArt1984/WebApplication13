#ifndef _LANGUAGEDEFREC_H_
#define _LANGUAGEDEFREC_H_

#ifndef _CHARSTRING_H_
#include <CharString.hxx>
#endif

#ifndef _TYPES_HXX_
#include <Types.hxx>
#endif

class OaLockedLocale;

/// Language definition record
///
/// The attributes are public, because it is used at many places as struct.
///
/// @osdiff the content of the fields staring with "os" depend on the
/// operating system. They may even contain null values, if they are not
/// used on the specific operating system.
///
/// @classification ETM internal
/// @reentrant
///
class DLLEXP_OABASICS LanguageDefRec
{
  // Normally the use will only have a "const languageDefRec *", so strictly
  // mark all methods, which do not modify the record as const.
  public:
    friend class OaLockedLocale;
    friend class UNIT_TEST_FRIEND_CLASS;

    /// The Constructor
    LanguageDefRec();

    /// assignment operator.
    LanguageDefRec & operator = (const LanguageDefRec &src);

    /// copy constructor.
    LanguageDefRec(const LanguageDefRec &src);

    /// Check whether the Language Definition Record describes an UTF8
    /// encoded language or not.
    ///
    ///   @return true when this is an UTF8 encoded language, false otherwise.
    ///
    bool isUtf8Encoded() const;

    /// Check canDetectAsciiBytewise(int mibEnum) for the current object.
    bool canDetectAsciiBytewise() const;

    /// Determine whether the encoding of the given language makes it possible to traverse a string bytewise
    /// to determine ASCII characters (0-127). In case of a SBCS (single byte character set), the result is true.
    /// In case of a MBCS (multibyte character set), it depends on the kind of encoding. Some encodings guarantee
    /// that all bytes within a multibyte sequence differ from ASCII characters, in some encodings, one cannot
    /// know from a single byte whether it is meant as an ASCII character or it is part of a multibyte sequence.
    /// This function examines only encodings (identified by MIB-enums) currently used in WinCC OA.
    ///
    ///   @param mibEnum The language to examine, see member mibEnum.
    ///   @return true if the encoding allows bytewise traversion to detect ASCII characters.
    ///           false, otherwise (also in case of unknown encoding)
    ///
    static bool canDetectAsciiBytewise(int mibEnumToCheck);

    /// get encoding for this language
    ///   @return encoding or empty string in error case
    ///
    const char * getEncoding() const;

    /// Update the content of the Language Definition Record
    ///
    ///   @param pvssLangId the OA Language Id.
    ///   @param pvssLocale the OA language name.
    ///   @param platformLocale the operating system dependent locale string
    ///   @param osLcid the locale culture identifier (LCID)
    ///   @param mibEnum, see http://www.iana.org/assignments/character-sets
    ///   @param comment the description of the language
    ///
    /// The content of each parameter, which is not a 0-pointer is
    /// copied into the corresponding field of the Language Definition
    /// Record.
    ///
    void update(
        const GlobalLanguageIdType * pvssLangId,
        const CharString * pvssLocale,
        const CharString * platformLocale,
        const int * osLcid,
        const int * mibEnum,
        const CharString * comment);

    /// unique OA language identifier
    GlobalLanguageIdType pvssLangId;
    /// unique OA language name
    CharString           pvssLocale;
    /// operating system dependent locale string
    CharString           platformLocale;
    /// only for Windows CE platform: locale culture identifier (LCID)
    /// NOTE: WinCE does not support locale_t, setlocale, etc.
    /// Instead, the Windows NLS API and LCIDs must be used.
    int                  osLcid;
    /// see http://www.iana.org/assignments/character-sets
    int                  mibEnum;
    /// describes the language
    CharString           comment;
};
#endif
