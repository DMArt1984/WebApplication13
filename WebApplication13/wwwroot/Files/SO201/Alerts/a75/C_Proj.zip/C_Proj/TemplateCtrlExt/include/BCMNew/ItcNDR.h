//
//  $RCSfile$
//  $Date$
//  $Revision$
//  $Author$
//  $Locker$
//  $State$
//  $Source$
//
// %Z%JESSI-COMMON-FRAMEWORK 2.0
// %Z%Copyright (C) by Siemens Nixdorf Informationssysteme AG 1992
// %Z%Copyright (C) by Universitaet GH Paderborn 1992
// %Z%Development of this software was partially funded by ESPRIT project 7364.
// %Z%BCM %M% %I% %E%

#ifndef ItcNDR_H
#define ItcNDR_H

//#ifdef __GNUG__
//#pragma interface
//#endif

#include "ItcStatus.h"
#include "ItcDataRep.def"

#if 0  // Not used by PVSS II
#include <string>
#endif

#include <cstdlib>

class itcConnection;
class itcNDRSend;
class itcNDRReceive;
class itcNdrUbReceive;


// NDR_range must be 4 byte (as htonl)
typedef uint32_t NDR_range;

typedef char *NDR_data;

const NDR_range Ndr_Min_Range_Init = 32;     // minimum and maximum INITIAL
#ifndef IS_MSWIN__
const NDR_range Ndr_Max_Range_Init = 1048576;  // size of NDR buffer
const NDR_range Ndr_Max_Range = 16777216;     // maximum size of NDR buffer
#else
const NDR_range Ndr_Max_Range_Init = 65536L;  // size of NDR buffer
const NDR_range Ndr_Max_Range = 16777216L;     // maximum size of NDR buffer
#endif

const NDR_range Ndr_Buffer_Extend = 4096;   // size for buffer extensions XXX Stano 13.6.1996
const NDR_range Ndr_Max_Alignment = sizeof(double); // used as alignment for opaque data

const char  NDR_Magic[] = {'B', 'C', 'M', '\0'};
const NDR_range NDR_Magic_Len = 4;

class DLLEXP_BCM itcBinData {
public:
  itcBinData(NDR_range newLen) : len(newLen), ptr(0), doDelete(1)
    { if (len) ptr = new unsigned char [len]; }
  itcBinData(NDR_range newLen, unsigned char *p) : len(newLen), ptr(p), doDelete(0)
    {}
  
  ~itcBinData() { if (doDelete) delete [] ptr; }
  
  unsigned char *cut() 
  { 
    unsigned char *tmpPtr = ptr; 
    len = 0; ptr = 0; 
    return tmpPtr; 
  }

  const unsigned char *getData() const { return ptr; }
  NDR_range getLen() const { return len; }

  // XXX unsigned char *getDataPtr() { return (doDelete) ? ptr : 0; }
  // XXX Stano 7. 4. 2000 - we sometimes allocate externally and want to store data there
  unsigned char *getDataPtr() { return ptr; }
  
private:
  NDR_range len;
  unsigned char *ptr;
  int doDelete;
};

class DLLEXP_BCM itcXNDR {
public:
  virtual ~itcXNDR() {}  // make gcc4 happy
  virtual void to_internal(itcNDRReceive &) = 0;
  virtual void to_external(itcNDRSend &) const = 0;
};


class DLLEXP_BCM itcNDR : public itcStatus {
public:
  enum NDR_endian {
    NdrBigEndian = 0,
    NdrLittleEndian = 1,
    NdrEndianUndef = 2
  };
   enum NDR_character {
    NdrASCII = 0,
    NdrEBCDIC = 1,
    NdrUTF8 = 2,			// < 3.16 systems don't care about the encoding value we send (remote_character)
	                        // so the enum's numeric values can be modified like this, without breaking compatibility
    NdrCharUndef = 3
  };
  enum NDR_floating {
    NdrIEEE = 0,
    NdrVAX = 1,
    NdrCray = 2,
    NdrIBM = 3,
    NdrFloatUndef = 4
  };

// TransactionSizeType: vorzeichenlose ganze Zahl mit 32 Bit Laenge!!!
#if defined(IS_MSWIN__)
  typedef NDR_range TransactionPos;
#else
  typedef NDR_range TransactionPos;
#endif

  itcNDR() : remote_encoding(NdrCharUndef) {} // TFS 24334
  virtual ~itcNDR() {}  // make gcc4 happy
  virtual void reset()=0;
  virtual char *raw_data()=0;
  virtual NDR_range raw_length() const=0;
  virtual void extend_buffer(NDR_range factor)=0;
  virtual NDR_range free_buffer_size() const=0;
  static NDR_endian    local_endian()    { return ndr_endian; };
  static NDR_character local_character() { return ndr_char; };
  static NDR_floating  local_floating()  { return ndr_float; };
  static void set_local_character(itcNDR::NDR_character enc) { ndr_char = enc; } // TFS 24334

  // number of bytes reserved for len of buffer at beginning of buffer  
  static NDR_range len_size() { return sizeof(double); }

  void set_remote_character(itcNDR::NDR_character enc) { remote_encoding = enc; } // TFS 24334
  itcNDR::NDR_character get_remote_character() const { return remote_encoding; } // TFS 24334

protected:
  virtual void create_buffer(NDR_range size) = 0;

private:
  static NDR_endian    ndr_endian;
  static NDR_character ndr_char;
  static NDR_floating  ndr_float;
  
  NDR_character remote_encoding; // TFS 24334

  friend class UNIT_TEST_FRIEND_CLASS;
};

// forward declaration
class itcNDRReceive;
///class used to send streamed data over itcConnection 
class DLLEXP_BCM itcNDRSend : public itcNDR {
//
// friends!
  friend class itcNDRReceive;
  friend DLLEXP_BCM itcConnection &operator<<(itcConnection &tr, itcNDRSend &ndr);
  friend DLLEXP_BCM int  operator<<(int tr, itcNDRSend &ndr); //output from file descriptor

  friend DLLEXP_BCM itcNDRSend &operator<<(itcNDRSend &, const itcXNDR &);
  friend DLLEXP_BCM itcNDRSend &operator<<(itcNDRSend &, char);
  friend DLLEXP_BCM itcNDRSend &operator<<(itcNDRSend &, unsigned char);
  friend DLLEXP_BCM itcNDRSend &operator<<(itcNDRSend &, signed char);
  friend DLLEXP_BCM itcNDRSend &operator<<(itcNDRSend &, int16_t);
  friend DLLEXP_BCM itcNDRSend &operator<<(itcNDRSend &, uint16_t); 
  friend DLLEXP_BCM itcNDRSend &operator<<(itcNDRSend &, int32_t);
  friend DLLEXP_BCM itcNDRSend &operator<<(itcNDRSend &, uint32_t);
  friend DLLEXP_BCM itcNDRSend &operator<<(itcNDRSend &, int64_t);
  friend DLLEXP_BCM itcNDRSend &operator<<(itcNDRSend &, uint64_t);
  friend DLLEXP_BCM itcNDRSend &operator<<(itcNDRSend &, float);
  friend DLLEXP_BCM itcNDRSend &operator<<(itcNDRSend &, double);
  friend DLLEXP_BCM itcNDRSend &operator<<(itcNDRSend &, const char*);
  friend DLLEXP_BCM itcNDRSend &operator<<(itcNDRSend &, const itcBinData &);
  
  // Not used in PVSS II
# if 0
  friend DLLEXP_BCM itcNDRSend &operator<<(itcNDRSend &, const std::string&);
#endif


public:
  ///ctor
  itcNDRSend();
  /**ctor(int size)
    @param size internal buffer size
    */
  itcNDRSend(int size);
  ///dtor
  virtual ~itcNDRSend();

  /**insert string data into sender
    @param ch_ptr data buffer, should be maintained by caller
    @param count buffer size
  */
  itcNDRSend &insert(const char *ch_ptr, int count); 
  /**put general data into sender
    @param opaque data buffer, should be maintained by caller
    @param count buffer size
    @param do_align true - compute alignment before writing buffer and write data to correctly aligned address
    @param add_count true - write size of data buffer first and the the buffer self
  */
  itcNDRSend &put_opaque(const void *opaque, int count, bool do_align = true, bool add_count = true); 
  
  ///reset the sender
  void reset(); // reset for adding
  /** init sender using buffer
    @param buffer initial buffer, should be maintained by caller
    @param size buffer size
    */
  void init(char *buffer, NDR_range size); // init application buffer
  ///return raw data
  char *raw_data();
  ///return raw length
  NDR_range raw_length() const;
  ///return current position in buffer
  NDR_range current_position() const {return (NDR_range) (end_data - const_cast<itcNDRSend *>(this)->raw_data_inline());}

  ///extend buffer (multiply size using factor)
  void extend_buffer(NDR_range factor);
  ///return free size
  NDR_range free_buffer_size() const;

  ///Stores the buffer state at the beginning of the sending sequence(more send calls)
  void start_transaction();
  ///In the case of error restores the buffer to the state stored in start_transaction. If no error has been occured(and data buffer contains previously written data entities), the current data buffer will be written to the connection.
  StatusType end_transaction();

protected:
  /** create buffer
  @param size
  */
  void create_buffer(NDR_range size);

private:
  // inline private versions
  ///reset inline
  void reset_inline(); // reset for adding
  ///raw data inline
  char *raw_data_inline();
  ///raw length inline
  NDR_range raw_length_inline() const;
  ///free buffer size inline
  NDR_range free_buffer_size_inline() const;

  // Startposition der Transaktionsdaten
  TransactionPos start_trans;

  // internal data  
  NDR_data  start_data;  // start of data
  NDR_data  end_data;  // pointer to next empty byte of buffer
  NDR_data  end_alloc;  // end of allocated buffer space
  char *ndr_buffer;  // internal send buffer

  friend class UNIT_TEST_FRIEND_CLASS;
};


///class used to receive streamed data from itcConnection 
class DLLEXP_BCM itcNDRReceive : public itcNDR {
//
// friends!
  // new friends, necessary for "unblocking extensions" of BCM, JF 940627
  friend DLLEXP_BCM NDR_range operator>>(itcConnection &conn, itcNdrUbReceive &ndr);
  friend DLLEXP_BCM int  operator>>(int tr, itcNdrUbReceive &ndr);
  friend DLLEXP_BCM NDR_range receive_rawdata(itcConnection &conn, itcNdrUbReceive &ndr);

  friend class itcNDRSend;
  friend DLLEXP_BCM itcConnection &operator>>(itcConnection &tr, itcNDRReceive &ndr);
  friend int operator>>(int tr, itcNDRReceive &ndr); //input on file descriptor

  friend DLLEXP_BCM itcNDRReceive &operator>>(itcNDRReceive &, itcXNDR &);
  friend DLLEXP_BCM itcNDRReceive &operator>>(itcNDRReceive &, char &);
  friend DLLEXP_BCM itcNDRReceive &operator>>(itcNDRReceive &, unsigned char &);
  friend DLLEXP_BCM itcNDRReceive &operator>>(itcNDRReceive &, signed char &);
  friend DLLEXP_BCM itcNDRReceive &operator>>(itcNDRReceive &, int16_t &);
  friend DLLEXP_BCM itcNDRReceive &operator>>(itcNDRReceive &, uint16_t &); 
  friend DLLEXP_BCM itcNDRReceive &operator>>(itcNDRReceive &, int32_t &);
  friend DLLEXP_BCM itcNDRReceive &operator>>(itcNDRReceive &, uint32_t &);
  friend DLLEXP_BCM itcNDRReceive &operator>>(itcNDRReceive &, int64_t &);
  friend DLLEXP_BCM itcNDRReceive &operator>>(itcNDRReceive &, uint64_t &);
  friend DLLEXP_BCM itcNDRReceive &operator>>(itcNDRReceive &, float &);
  friend DLLEXP_BCM itcNDRReceive &operator>>(itcNDRReceive &, double &);
  friend DLLEXP_BCM itcNDRReceive &operator>>(itcNDRReceive &, itcBinData &);
  
public:
  /// secure replacement of friend DLLEXP_BCM itcNDRReceive &operator>>(itcNDRReceive &, char*);
  itcNDRReceive &read_string(char*, size_t size);

public:
  ///ctor
  itcNDRReceive();
  /**ctor parametrizing only buffer size 
    @param size  size of buffer
  */
  itcNDRReceive(int size);
  /**ctor parametrizing buffer and its size
    @param buffer data buffer
    @param size size of buffer
  */
  itcNDRReceive(const char *buffer, unsigned int size);
  ///dtor
  virtual ~itcNDRReceive();

  /**extract string data
    @param ch_ptr input buffer
    @param count sizeof buffer
  */  
  itcNDRReceive &extract(char *ch_ptr, unsigned int &count); 
  /**extract string data
    @param ch_ptr in/out buffer can be reallocated internally
    @param size sizeof buffer
    @param count new size
  */  
  itcNDRReceive &extract(char *&ch_ptr, int size, int &count); 
  /**get general data
    @param opaque in/out buffer can be reallocated internally
    @param size sizeof buffer
    @param count new size
  */  
  itcNDRReceive &get_opaque(void *&opaque, int size, int &count); 

  /**skip to given position in buffer
    @param count byte count  to be skiped
    */
  itcNDRReceive &skip(int count);
  
  ///reset reader
  void reset(); // reset for reading
  
  /** init sender using buffer
    @param buffer initial buffer, should be maintained by caller
    @param size buffer size
    */
  void init(char *buffer, NDR_range size);
  ///get raw data
  char *raw_data();
  ///get current position
  NDR_range current_position() const {return (NDR_range) (outptr - const_cast<itcNDRReceive *>(this)->raw_data_inline());}
  ///get buffer length
  NDR_range raw_length() const;

  ///get free buffer size
  NDR_range free_buffer_size() const;
  
  /// More data pending, returns byte count of data ready for reading
  NDR_range pending_length() const;

  ///remote endian, returns byte order on target machine
  NDR_endian    remote_endian()    const { return rem_endian; };
  ///remote character, returns char representation on target machine
  NDR_character remote_character() const { return rem_char; };
  ///remote floating, returns float representation on target machine
  NDR_floating  remote_floating()  const { return rem_float;};

  ///Fills up the data buffer by the data of stored transaction. Now the buffer contains a sequence of data entities.
  void       start_transaction();
  ///In the case of error in readings in scope of transaction, the method restores the buffer to the state before start_transaction call. 
  StatusType end_transaction();

protected:
  /**create new buffer
    @param size new buffer size
    */
  void create_buffer(NDR_range size);
  /**extend the buffer by the factor
    @param factor 
    */
  void extend_buffer(NDR_range factor);

private:
  // inline private versions
  void reset_inline(); // reset for adding
  char *raw_data_inline();
  NDR_range raw_length_inline() const;
  NDR_range free_buffer_size_inline() const;

  // Endeposition der Transaktionsdaten + 1
  TransactionPos end_trans;

  // internal data  
  NDR_endian    rem_endian;  // remote byte order
  NDR_character rem_char;    // remote char representation
  NDR_floating  rem_float;   // remote float representation
  NDR_data  start_data;  // start of data
  NDR_data  outptr;  // pointer to current extract (output)
  NDR_data  end_data;  // end of the NDR data
  NDR_data  end_alloc;    // end of allocated buffer space
  char *ndr_buffer;  // internal receive buffer

  friend class UNIT_TEST_FRIEND_CLASS;
};


// -----------------------------------------------------------------------
inline void itcNDRSend::reset_inline() 
{
  if (ndr_buffer == NULL) 
    return;  // nothing to reset

  end_data = start_data + 2 + NDR_Magic_Len + len_size();
  start_trans = 0;
  
  if (free_buffer_size_inline() > Ndr_Max_Range_Init)
  {
    free(ndr_buffer);
    start_data = end_data = end_alloc = ndr_buffer = NULL;
  }
  
  ITC_STATUS_OK;
} // reset for adding


inline char* itcNDRSend::raw_data_inline() 
{ 
  return (char *) start_data + NDR_Magic_Len + len_size(); 
}


inline NDR_range itcNDRSend::raw_length_inline() const
{
  if (end_data == NULL && start_data == NULL)
    return (0);
  else
    return (NDR_range) (end_data - start_data - NDR_Magic_Len - len_size());
}


inline NDR_range itcNDRSend::free_buffer_size_inline() const 
{
  if ( ((end_alloc == NULL) && (end_data == NULL))
        || (end_data > end_alloc)) 
  {
      return(0);
  }
  else 
  {
      return (NDR_range) (end_alloc - end_data + 1);
  }
}


// -----------------------------------------------------------------------
inline void itcNDRReceive::reset_inline() {
  if (ndr_buffer == NULL) return;  // nothing to reset

  // (initial itcNDRReceive) JF 940621
  outptr = start_data + 2;
  end_trans = 0;
  
  if (free_buffer_size_inline() > Ndr_Max_Range_Init)
  {
    free(ndr_buffer);
    start_data = outptr = end_data = end_alloc = ndr_buffer = NULL;
  }
  
  ITC_STATUS_OK;
} // reset for reading

inline char* itcNDRReceive::raw_data_inline() 
{ 
  return start_data; 
}
 
 
inline NDR_range itcNDRReceive::raw_length_inline() const 
{
  return (start_data == end_data) ? 0 : (NDR_range) (end_data - start_data + 1);
}

 
inline NDR_range itcNDRReceive::free_buffer_size_inline() const 
{
  if ( ((end_alloc == NULL) && (start_data == NULL)) ||
      (start_data > end_alloc)) 
  {
    return(0);
  }
  else 
  {
    return (NDR_range) (end_alloc - start_data + 1);
  }
}



#endif /* ItcNDR_H */
