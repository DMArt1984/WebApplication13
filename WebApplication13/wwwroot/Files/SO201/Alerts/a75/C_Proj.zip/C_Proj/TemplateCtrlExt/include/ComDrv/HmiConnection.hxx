#ifndef _HMICONNECTION_H_
#define _HMICONNECTION_H_

#include <DrvIntDp.hxx>

class Variable;
class HWObject;

class HmiConnection : public DrvIntDp
{

public:

  // DPEs to connect to
  enum InternalCommandElements
  {
    ICE_ControllerId = 0,
    ICE_Address,
    ICE_Codepage,
    ICE_EstablishmentMode,
    ICE_CloseTimeout,
    ICE_ReconnectTimeout,
    ICE_LifebeatTimeout,
    ICE_Timezone,
    ICE_TimeSyncMode,
    ICE_DisableOnStartup,
    ICE_FSMEnable,
    ICE_GQ,
    ICE_IGQ,
    ICE_AcquireValuesOnConnect,	
    ICE_EnableStatistics,
    ICE_User,                       // important: ICE_User must always be the last entry
  };

  // DPEs to write to
  enum InternalStateElements
  {
    ISE_First = 500,                // important: ISE_First must always be the first entry
    ISE_ConnState = ISE_First,
    ISE_DrvType,
    ISE_Disabled,
    ISE_User,                       // important: ISE_User must always be the last entry
  };

  enum EstablishmentMode
  {
    FSM_NotActive = 0,
    FSM_AutomaticActive = 1,
    FSM_AutomaticPassive = 2,
    FSM_OnDemandActive = 4,
    FSM_OnDemandPassive = 8,
  };

  enum TimeSyncMode
  {
    TS_Ignore = 0,
    TS_Master,
    TS_Slave,
  };

  enum State_t
  {
    HMI_CS_Undefined = 0,
    HMI_CS_Disconnected,
    HMI_CS_Connecting,
    HMI_CS_Connected,
    HMI_CS_Disconnecting,
    HMI_CS_Failure,
    HMI_CS_Listening,
    HMI_CS_OpenServer,
    HMI_CS_CloseServer,
    HMI_CS_WaitForReconnect,
  };

    /** the HmiConnection constructor.
      * The HmiConnection objects needs a valid DP Id for initialization.
      * If a new HmiConnection wants to use additional DPEs it has to state the extra number.
      * @param id the dpId for the new HmiConnection object
      * @param additionalConnectDPE the number of additional elements to connect to
      * @param additionalWriteDPE the number of additional elements to write to
      */
    HmiConnection(DpIdType id, int additionalConnectDPE = 0, int additionalWriteDPE = 0);

    virtual ~HmiConnection();

    /** get the connection DpId
    */
    DpIdType getMyDpId() const {return myDpId_;}

    /** get the current FSM state (ConnState).
      * @return the current state
      */
    State_t getConnState() const { return connState_; }

    /** utility function to set all input DPEs to invalid. use with care since
      * calling this function might cause a lot of message traffic!
      * the default case is defined by the default parameters
      * @param conn_lost set the invalid bit (= connection lost)
      * @param out_of_service set the out_of_service bit
      */
    void setAllInputInvalid(bool conn_lost = true, bool out_of_service = false);

    /** the open connection callback.
      * possible state changes are HMI_CS_Failure and HMI_CS_Connected
      */
    virtual void open();

    /** the close connection callback.
      * there are no active state changes possible here
      */
    virtual void close();

    /** the open server side callback.
      * possible state changes are HMI_CS_Failure and HMI_CS_Listening
      */
    virtual void openServer();

    /** the close server side callback.
      * there are no active state changes possible here
      */
    virtual void closeServer();

    /** the general query callback.
      * this callback is triggered whenever a general query should be done.
      * the default implementation issues singleQuery calls for all input and IO elements.
      */
    virtual void doGeneralQuery();

    /** the internal general query callback.
      * this callback is triggered whenever an internal general query should be done.
      * the default implementation issues write requests calls for all output and IO elements.
      */
    virtual void doInternalGeneralQuery();

    /** the alert sync callback.
      * this callback is triggered whenever a general alert sync should be done.
      */
    virtual void doAlertSync();

    /** the connection error check callback.
      * this callback is triggered periodically to check for connection faults.
      * returning true will cause the connection to be closed.
      */
    virtual bool isConnError();

    /** get the name of additional DPEs of the derived class.
        the index follows the ICE_User and ISE_User constants, respectively
        @param index the index for the requested DPE name
        @return the full DPE name including _original.._value
      */
    virtual const CharString &getElementName(int index);

    /** the internal value change notification callback.
      * whenever a new value is received for HmiConnection internal DPEs this function will be called
      * for notification purposes.
      * additional command elements will be notified directly.
      * @param index the InternalCommandElements index of the concerned DPE
      */
    virtual void notifyInternalChange(int index);

    /** the answer callback function.
        this function will be called for DPEs additionally provided by the derived class.
        the varPtr object should be captured/deleted by the called entity
        @param index the DPE concerned
        @varPtr varPtr the variable pointer
      */
    virtual void answerCallback(int index, Variable* varPtr);

    /** the hotlink callback function.
        this function will be called for DPEs additionally provided by the derived class.
        the varPtr object should be captured/deleted by the called entity
        @param index the DPE concerned
        @varPtr varPtr the variable pointer
      */
    virtual void hotlinkCallback(int index, Variable* varPtr);

    // --------------------------------
    // standard interface according to HWService

    /** This function is called for a single data request or when polling data.
      * The HWObject contains the PeriphAddress string. Find the corresponding hardware address, ask
      * for the data. The objPtr must not be deleted.
      * @param objPtr the HWObject to fill with data
      * @classification public use, overload
      */
    virtual void singleQuery(HWObject *objPtr);

    /** This function is called for each fully converted HWObject. The data inside it has
      * been processed according to the choosen transformation. All you have to do is to determine the
      * corresponding hardware address and to transmit the data packet. The objPtr must not be deleted.
      * @param objPtr pointer to HW object
      * @classification public use, overload
      */
    virtual PVSSboolean writeData(HWObject *objPtr);

    /** Whenever a message is transformed and sent to the hw service layer completely,
      * this function is called to signal to the hw layer that the message has been fully processed.
      * You can use this function if you want to transmit larger blocks to the hardware at once.
      * @classification public use, overload
      */
    virtual void        flushHW();

    /** Working procedure. This function is called repeatedly by the DrvManager mainLoop() to check the
      * hardware for any incoming data. when data is ready for accepting you should pack the data into a HWObject and
      * use the DrvManager toDp() function to transmit the data to the pvss2 system.
      * @warning beware of staying inside this function too long because no messages can go in and
      * out of the driver as long as you keep control!
      * @classification public use, overload
      */
    virtual void workFunc();

    // the state machine worker function
    void doFSM();

    /** This function is called for a update notification on subscription count if the acquistition mode SpontaneousOnDemand is chosen.
      * The HWObject contains the PeriphAddress string. Find the corresponding hardware address and do anything needed to get data.
      * if (subscriptionCount - offset) > 0 the data retrieval should be started, otherwise be stopped.
      * The objPtr must not be deleted.
      * @param objPtr the HWObject providing the address for the item to retrieve
      * @param startAcquisition if true the HmiConnection should start getting data, otherwise stop
      * @classification public use, overload
      */
    virtual void notifyOnUseChange(HWObject *obj, bool startAcquisition);

    /** function used for name resolution
      * this one is for internal use
      * @param dpId the DpIdentifier
      * @param name the dpName
      * @classification internal use only
      */
    virtual PVSSboolean setDpName(DpIdentifier& dpId, CharString& name);

    /** Set dp identifier an config in Id table according name
    * @param name input name for searching in table
    * @param dpId dp identifier
    * @return TRUE if dp of the appropriate name was assigned successfully
    */
    virtual PVSSboolean setDpIdentifier(CharString& name, DpIdentifier& dpId);

    /** Report relevant data of the HmiConnection objects
    * @classification public use, overload
    */
    virtual void reportStatus(std::ostream &os);

    /** Virtual function 
    */
    virtual void notifyDisableCommands(PVSSboolean /* dc */);

    virtual void updateStatistics();

    // ---------------------------------------------------------
    // member access functions

    // COVINFO BLOCK: obsolete (actually: not used in WinCC OA Drivers, dhoegerl)
    const CharString &getControllerId() const      { return controllerID_; }
    // COVINFO BLOCKEND
    const CharString &getAddress() const           { return address_; }
    // COVINFO BLOCK: obsolete (actually: not used in WinCC OA Drivers, dhoegerl)
    unsigned getCodePage() const                   { return codepage_; }
    EstablishmentMode getEstablishmentMode() const { return estMode_; }
    unsigned getCloseTimeout() const               { return closeTimeout_; }
    unsigned getReconnectTimeout() const           { return reconnectTimeout_; }
    unsigned getLifebeatTimeout() const            { return LifebeatTimeout_; }
    // COVINFO BLOCKEND
    int getTimeZoneOffset() const                  { return timezone_; }
    TimeSyncMode getTimeSyncMode() const           { return timeSyncMode_; }
    // COVINFO BLOCK: obsolete (actually: not used in WinCC OA Drivers, dhoegerl)
    bool isDisableOnStartup() const                { return disableOnStartup_; }
    bool isFSMActive() const                       { return FSMActive_; }
    // COVINFO BLOCKEND

    void shutdown()                                { FSMActive_ = false; }

    bool getAcquireValuesOnConnect()               { return acquireValuesOnConnect_; }	

    bool getEnableStatistics()                     { return enableStatistics_; }

  protected:

    #ifdef _UNIT_TEST
      HmiConnection() : DrvIntDp() { };
    #endif // _UNIT_TEST

    // init members to default value
    void initDefaults();

    /** request state change.
      * use this function in the derived class to request a state change due to callback activities.
      * the state change request is verified against the FSM and dealt with.
      * @param newstate the requested state to change to
      * @return true if successful - the state has been changed
      */
    bool requestStateChange(State_t newstate);

    // wrapper for DrvIntDp index calculation
    int getInternalIndex(int idx);

    // --------------------------------------------------
    // DrvIntDp interface

    // --------------------------------------------------------------
    // internal dp handling

    // Retrieves the DpId of the internal DP. The function must be overloaded if the DpId to DpName mechanism is to be used.
    virtual DpIdType getDpId4Query() { return myDpId_; }

    // retrievs the names of the internal DPEs. The function must be overloaded.
    // It should return the proper DPE string for the corresponding index
    virtual const CharString& getDpName4Query(int index);

    // called if there is an answer to a certain index
    virtual void answer4DpId(int index, Variable* varPtr);

    // called if there is a hotlink to a certain index
    virtual void hotLink2Internal(int index, Variable* varPtr);

    // did we get all IDPs ?
    virtual void dpReady();

    virtual void createStatistics();

  private:

    // set new state and publish to DPE
    void setNewState(State_t newstate);

    // counter for dynamic DPE members
    int maxConnectDPE_;             // internal plus dynamic members
    int totalDPE_;                  // total count

    DpIdType myDpId_;

    // DPE members
    CharString controllerID_;       // unique controller id
    CharString address_;            // implementation specific address
    unsigned codepage_;             // uint16 codepage
    EstablishmentMode estMode_;     // FSM mode
    unsigned closeTimeout_;         // close timeout in secs
    unsigned reconnectTimeout_;     // reconnect timeout in secs
    unsigned LifebeatTimeout_;      // watchdog timeout in secs
    int timezone_;                  // timezone offset in minutes
    TimeSyncMode timeSyncMode_;     // timesync mode
    bool disableOnStartup_;         // disable on startup - if dpe is not found -> false
    bool FSMActive_;                // target state disabled if reset by enable command

    // FSM variables
    State_t connState_;             // current fsm state
    State_t reqConnState_;          // this state should become the next one

    time_t lastConnectRetry;        // internal timestamp for reconnectTimeout
    time_t lastUserCall;            // internal timestamp for maximum duration of user call (connecting, openServer)
    time_t lastAliveCheck;          // internal timestamp for last connection state check
    
    bool acquireValuesOnConnect_;           // is a General Query neccesary after a PLC connection	

    bool enableStatistics_;         // is Statistical Data needed?

    friend class UNIT_TEST_FRIEND_CLASS;
};

// wrapper for DrvIntDp index calculation
inline int HmiConnection::getInternalIndex(int idx)
{
  if (idx < ISE_First) return idx;
  return (idx - ISE_First + maxConnectDPE_);
}

#endif  // _HMICONNECTION_H_
