// DATEIBESCHREIBUNG ==============================================================
// DATEINAME:     DpNullSupConv.hxx
// VERANTWORTUNG:  Stanislav Meduna
// 
// BESCHREIBUNG:  Nullpunkt Unterdrueckung.
//
// AENDERUNGS-HISTORIE
// Ver.  | Datum      | Aenderungen                            | ModNr.| Autor
// ------+------------+-----------------Anfang-----------------+-------+-----------
//   1.0 |            | 1.Erstellung mit Westmount-OMT         |     0 |
// ======================================Ende======================================
#ifndef _DPNULLSUPCONV_H_
#define _DPNULLSUPCONV_H_

// Vorwaerts-Deklaration der Eigenen Klasse
class DpNullSupConv;

// System-Include-Files
#include <DpConversion.hxx>
#include <IntegerVar.hxx>
#include <FloatVar.hxx>

// Vorwaerts-Deklarationen :
class DpConvSmooth;
class DpNullSupConv;
class Variable;

class BitVec;

/// Conversion for zero suppression.
class DLLEXP_CONFIGS DpNullSupConv : public DpConversion 
{

  // Klassen-Enums:

// ..........................Anfang User-Klasseninterne-Definitionen..................
// ...........................Ende User-Klasseninterne-Definitionen...................
public:
  /// Default construktor.
  DpNullSupConv();
  /// Destructor.
  ~DpNullSupConv();

  // Operatoren :

  /// Write the object into itcNdrUbSend stream.
  friend DLLEXP_CONFIGS itcNdrUbSend &operator<<(itcNdrUbSend &ndrStream, const DpNullSupConv &aConv);
  /// Read the object from itcNdrUbReceive stream.
  friend DLLEXP_CONFIGS itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream, DpNullSupConv &aConv);
  /// Assignment operator.
  /// @return Reference to the DpConvSmooth object reference with the assigned value.
  virtual DpConvSmooth &operator=(const DpConvSmooth &aConv);

  // Spezielle Methoden :

  /// Returns conversion type of this class.
  virtual DpConversionType convType() const;
  /// Convert method. 
  /// @param inpVar Input variable.
  /// @param outVarPtr Pointer to the newly allocated output Variable.
  /// @param unused Not used.
  /// @return 
  /// - DpConversionOK if the conversion was successfull.
  /// - DpConversionError if it was not possible to performe the conversion.
  /// - DpConversionBadType if input variable is of not allowed type.
  virtual DpConversionResultType convert(const Variable &inpVar, Variable * & outVarPtr, const BitVec &unused);
  /// Allocates the new instance of DpNullSupConv.
  /// @return DpConvSmooth pointer to a newly allocated instance.  
  virtual DpConvSmooth *allocate() const;
  /// Set attribute.
  /// @param attrNr Attribute number.
  /// @param var Attribute value.
  virtual PVSSboolean setAttribut(DpAttributeNrType attrNr, const Variable &var);
  /// Get  attribute value.
  /// @param attrNr Attribute number.
  /// @return On success pointer to newly allocated variable is returned. On error, 0 is returned.
  virtual Variable *getAttribut(DpAttributeNrType attrNr) const;
  /// Check if the instance is correctly set-up.
  virtual PVSSboolean isConsistent() const;

  // Generierte Methoden :

  /// Get attribute representing the low limit of the range.
  const FloatVar &getAttrLow() const;
  /// Get attribute representing the low limit of the range.
  FloatVar &getAttrLow();
  /// Set attribute representing the low limit of the range.
  void setAttrLow(const FloatVar &newAttrLow);
  /// Get attribute representing the high limit of the range.
  const FloatVar &getAttrHigh() const;
  /// Get attribute representing the high limit of the range.
  FloatVar &getAttrHigh();
  /// Set attribute representing the high limit of the range.
  void setAttrHigh(const FloatVar &newAttrHigh);
  /// Get attribute representing the value.
  const FloatVar &getAttrValue() const;
  /// Get attribute representing the value.
  FloatVar &getAttrValue();
  /// Set attribute representing the value.
  void setAttrValue(const FloatVar &newAttrValue);
protected:
private:
  FloatVar attrLow;
  FloatVar attrHigh;
  FloatVar attrValue;

// ............................Anfang User-Attribut-Definitionen...................
// .............................Ende User-Attribut-Definitionen....................
};

// ================================================================================
// Inline-Funktionen :
inline const FloatVar &DpNullSupConv::getAttrLow() const
{
  return attrLow;
}

inline FloatVar &DpNullSupConv::getAttrLow()
{
  return attrLow;
}
inline void DpNullSupConv::setAttrLow(const FloatVar &newAttrLow)
{
  attrLow = (FloatVar &) newAttrLow;
}
inline const FloatVar &DpNullSupConv::getAttrHigh() const
{
  return attrHigh;
}

inline FloatVar &DpNullSupConv::getAttrHigh()
{
  return attrHigh;
}
inline void DpNullSupConv::setAttrHigh(const FloatVar &newAttrHigh)
{
  attrHigh = (FloatVar &) newAttrHigh;
}
inline const FloatVar &DpNullSupConv::getAttrValue() const
{
  return attrValue;
}

inline FloatVar &DpNullSupConv::getAttrValue()
{
  return attrValue;
}
inline void DpNullSupConv::setAttrValue(const FloatVar &newAttrValue)
{
  attrValue = (FloatVar &) newAttrValue;
}

// ............................Anfang User-Inlines.................................
// .............................Ende User-Inlines..................................

#endif /* _DPNULLSUPCONV_H_ */
