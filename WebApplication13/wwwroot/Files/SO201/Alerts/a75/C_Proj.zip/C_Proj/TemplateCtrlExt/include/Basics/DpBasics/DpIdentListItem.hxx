#ifndef _DPIDENTLISTITEM_H_
#define _DPIDENTLISTITEM_H_

/*
VERANTWORTUNG: Martin Koller
BESCHREIBUNG:
*/

#ifndef _PTRLISTITEM_H_
#include <PtrListItem.hxx>
#endif

#ifndef _DPIDENTIFIER_H_
#include <DpIdentifier.hxx>
#endif

#ifndef _ALLOCATOR_H_
#include <Allocator.hxx>
#endif

/** the DpItentListItem class. this clas is used internally by the DpIdentList class.
    @classification ETM internal
*/
class DLLEXP_BASICS DpIdentListItem : public PtrListItem
{
  public:
    DpIdentListItem(const DpIdentifier &dpId) : dp(dpId) {}

    ~DpIdentListItem() {}

    AllocatorDecl;

    int operator==(const DpIdentListItem &item) const { return (dp == item.dp); }
    int operator!=(const DpIdentListItem &item) const { return (dp != item.dp); }

    const DpIdentifier &getDp() const { return dp; }

  protected:

  private:
    DpIdentifier dp;
};

#endif /* _DPIDENTLISTITEM_H_ */
