// DATEIBESCHREIBUNG ==============================================================
// DATEINAME:     DpLinIntConv.hxx
// VERANTWORTUNG:	Stanislav Meduna
// 
// BESCHREIBUNG:	Stuetzpunktkurve Umrechnung.
//
// AENDERUNGS-HISTORIE
// Ver.  | Datum      | Aenderungen                            | ModNr.| Autor
// ------+------------+-----------------Anfang-----------------+-------+-----------
//   1.0 |            | 1.Erstellung mit Westmount-OMT         |     0 |
//   1.1 | 09.09.2010 | Adding doxygen comments                |       | psedik
// ======================================Ende======================================
#ifndef _DPLININTCONV_H_
#define _DPLININTCONV_H_

// forward declarations and includes
class DpLinIntConv;

#include <DpConversion.hxx>
#include <FloatVar.hxx>
#include <IntegerVar.hxx>

/// Maximum number of points
#define	MAX_POINTS	5

class DpConvSmooth;
class DpLinIntConv;
class Variable;
class BitVec;

// ========== DpLinIntConv ============================================================
/// Conversion class used to convert the input values using the linear interpolation. See method
/// convert() for more info.
///
/// From Online help:
///
/// In order to transfer input values to a point curve factor, the range of values of the 
/// datapoint element is divided into several sections. The edge points of these sections
/// are assigned to fixed output values and linked with linear functions so as to create
/// a continuous curve. It must explicitly assign output values to the input values. 
/// The result is a series of straight lines that meet at their ends, the fixed section 
/// edges (supporting points), and that share these points. Example: f(x)=x in the range
/// of 0-1, and f(x)=2x-1 in the range of 1-3. Supporting points are (0,0), (1,1) and (3,5).
class DLLEXP_CONFIGS DpLinIntConv : public DpConversion 
{
public:

  /// Constructor
  DpLinIntConv();
  
  /// Destructor
  ~DpLinIntConv();

  /// Outputs the instance to the itcNdrUbSend stream
  /// @param ndrStream Output stream
  /// @param aConv Streamed DpLinIntConv instance
  /// @return itcNdrUbSend stream
  friend DLLEXP_CONFIGS itcNdrUbSend &operator<<(itcNdrUbSend &ndrStream, const DpLinIntConv &aConv);

  /// Receives the instance from the itcNdrUbReceive stream
  /// @param ndrStream Input stream
  /// @param aConv DpLinIntConv instance receiving the value from the stream
  /// @return itcNdrUbReceive stream
  friend DLLEXP_CONFIGS itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream, DpLinIntConv &aConv);
  
  /// Assignment operator
  /// @param aConv assigned value
  /// @return DpConvSmooth reference with the assigned value   
  virtual DpConvSmooth &operator=(const DpConvSmooth &aConv);

  /// Returns conversion type of this class
  /// @return DpConvLinInt
  virtual DpConversionType convType() const;

  /// Convert method. Converts the input value using the linear interpolation.
  /// @param inpVar Input Variable, which can be of type FLOAT_VAR, INTEGER_VAR, UINTEGER_VAR or CHAR_VAR
  /// @param outVarPtr Pointer to the newly allocated output FloatVar. The value is computed
  /// using a attrCoords array of points. With the input value (inpVar) regarded as an X coordinate,
  /// the method loops through the points and finds the two adjacent ones X(i) and X(i+1), where 
  /// X(i) <= inpVar < X(i+1). Then the outVar will be set to the Y coordinate of the point [inpVar, outVar],
  /// which lie on the line [X(i),Y(i)] - [X(i+1),Y(i+1)].
  /// @return 
  /// - DpConversionOK if the call was successfull
  /// - DpConversionError if the instance is not consistent, or it was not possible to allocate new FloatVar
  /// - DpConversionBadType if inpVar is not of the supported type
  virtual DpConversionResultType convert(const Variable &inpVar, Variable * & outVarPtr, const BitVec &);

  /// Allocates the new DpLinIntConv instance with default constructor.
  /// @return DpConvSmooth pointer to a newly allocated instance. 
  virtual DpConvSmooth *allocate() const;

  /// Set the attribute.
  /// @param attrNr Attribute number. The supported attributes are:
  /// - LIN_INTERP_NO_OF_POINTS_ATTR: set the attrNoPoints member
  /// - LIN_INTERP_POINT0_X_ATTR .. LIN_INTERP_POINT4_Y_ATTR: coordinate of the particular point stored in attrCoords
  /// @param var Variable to be set
  /// @return PVSS_TRUE is successfull, PVSS_FALSE in case of unsupported attribute number
  virtual PVSSboolean setAttribut(DpAttributeNrType attrNr, const Variable &var);

  /// Gets the attribute.
  /// @param attrNr Attribute number. The supported attributes are:
  /// - DpConfig::TYPE_ATTR - returns DpConvLinInt
  /// - for other attributes, see method setAttribut()
  /// @return Pointer to the Variable with the attribute value, or 0 in case of unsupported attribute number
  virtual Variable *getAttribut(DpAttributeNrType attrNr) const;
  
  /// Check if the instance is consistent (can be used for convert()).
  /// @return
  /// - PVSS_FALSE if the number of points is less than 2 or greater than 5, or if for some value i,
  /// coordinate X(i) > X(i+1).
  /// - PVSS_TRUE otherwise (instance is consistent)
  virtual PVSSboolean isConsistent() const;

  /// Gets the number of points (valid values are 2..MAX_POINTS)
  /// @return attrNoPoints member
  const IntegerVar &getAttrNoPoints() const;

  /// Gets the number of points (valid values are 2..MAX_POINTS)
  /// @return attrNoPoints member
  IntegerVar &getAttrNoPoints();

  /// Set the number of points
  /// @param newAttrNoPoints New value to be assigned to attrNoPoints member
  void setAttrNoPoints(const IntegerVar &newAttrNoPoints);

  /// Gets the point coordinate according to the zero-based idx
  /// @param idx Index of the coordinate. The coordinates are ordered from
  /// X0,Y0,X1,X2...Xn,Yn, where n == getAttrNoPoints()
  /// @return FloatVar with the requested coordinate
  const FloatVar &getAttrCoords(int idx) const;

  /// Gets the point coordinate according to the zero-based idx
  /// @param idx Index of the coordinate. The coordinates are ordered from
  /// X0,Y0,X1,X2...Xn,Yn, where n == getAttrNoPoints()
  /// @return FloatVar with the requested coordinate
  FloatVar &getAttrCoords(int idx);

  /// Set the coordinate for the given idx. See getAttrCoords() for more info.
  /// @param idx Index of the coordinate to be set
  /// @param newAttrCoords New coordinate value
  void setAttrCoords(int idx, const FloatVar &newAttrCoords);

  /// Maximum number of coordinates
  /// @return 2*MAX_POINTS
  int lengthAttrCoords();

protected:
private:
  /// number of points (valid values are 2..5)
  IntegerVar attrNoPoints;

  /// coordinates of each point (X0, Y0, X1, ... Y5)
  FloatVar attrCoords[2*MAX_POINTS];
};

// ================================================================================
// Inline methods:

inline const IntegerVar &DpLinIntConv::getAttrNoPoints() const
{
  return attrNoPoints;
}

inline IntegerVar &DpLinIntConv::getAttrNoPoints()
{
  return attrNoPoints;
}
inline void DpLinIntConv::setAttrNoPoints(const IntegerVar &newAttrNoPoints)
{
  attrNoPoints = (IntegerVar &) newAttrNoPoints;
}
inline const FloatVar &DpLinIntConv::getAttrCoords(int idx) const
{
  return attrCoords[idx];
}

inline FloatVar &DpLinIntConv::getAttrCoords(int idx)
{
  return attrCoords[idx];
}
inline void DpLinIntConv::setAttrCoords(int idx,const FloatVar &newAttrCoords)
{
  attrCoords[idx] = (FloatVar &) newAttrCoords;
}
inline int DpLinIntConv::lengthAttrCoords()
{
  return 2*MAX_POINTS;
}

#endif /* _DPLININTCONV_H_ */
