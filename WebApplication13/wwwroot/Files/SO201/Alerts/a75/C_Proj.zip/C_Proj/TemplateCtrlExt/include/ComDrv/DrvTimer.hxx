// ///////////////////////////////////////
//
//  DrvTimer.hxx
//
//  Base class for the implementation of arbitrary timers (e.g. alive mechanism
//  for a connection)
//  A timer, for which the seconds and usecs can be set
//  is used for the alive check
//  usec granularity is deprecated. Use milisecond granualarity.
//
// ///////////////////////////////////////
#ifndef _DRVTIMER_H_
#define _DRVTIMER_H_

#include <Types.hxx>
#include <PVSSBcm.hxx>

/** This is a base class for implementing a timer mechanism.
 *
 * It can be used e.g. for providing an alive timer on top of a driver connection. However, resolution is
 * limited due to the operating system capabilities.
 *
 * <p>this is per default a one run timer which means that whenever the timeout expires you have to
 * restart the timer by yourself. For this simply call the restartTimer() func inside your
 * overloaded timerExpired() func. 
 * @classification public use, overload
 **/
class DrvTimer : public itcIOHandler
{
  public:
    /** Default Constructor
      */ 
    DrvTimer();
    
    /** Constructor
     *
     * @param msTimeout the timeout in milliseconds used by the timer
     * @param oneShot determines whether the timer will fire exactly once or multiple times
     **/
    DrvTimer(unsigned msTimeout, bool oneShot = true);

    /** Destructor
     *
     * Stop and destroy the timer.
     **/
    virtual ~DrvTimer();

    /** Use this function to (re)start the timer. don't forget to set the
      * timeout value(s) before doing this for the first time!
      * The possibility to overload this mehtod is deprecated.
      * @classification public use, call
      */
    void  startTimer();

    /** Use this function to (re)start the timer. don't forget to set the
      * timeout value(s) before doing this for the first time!
      * The possibility to overload this method is deprecated.
      * @classification public use, call
      */
    IL_DEPRECATED("deprecated, use startTimer() instead")
    virtual void  restartTimer() { startTimer(); }

    /** Use this function to stop the timer.
      * The possibility to overload this method is deprecated.
      * @classification public use, call
      */
    virtual void  stopTimer();

    /** Retrieve the timeout used by the timer in milliseconds. **/
    unsigned getTimeout() const;

    /** Set the timeout used by the timer in milliseconds.
     *
     * @param timeout The new timeout used by the timer. If the timer is already running, it will be
     *                applied next time the timer is started.
     **/
    void setTimeout(unsigned msTimeout);

    /// get sec
    IL_DEPRECATED("deprecated, use getTimeout() by use of milliseconds instead")
    PVSSlong getSec() { return sec; }

    /** This function is used to set a timeout in the resolution of seconds. 
      * @param theSec time in sec for timeout setting
      *  @classification public use, call
      */
    IL_DEPRECATED("deprecated, use setTimeout() by use of milliseconds instead")
    void  setSec( PVSSlong theSec ){ sec = theSec; }

    /// get usec
    IL_DEPRECATED("deprecated, use getTimeout() by use of milliseconds instead")
    PVSSlong getUsec() { return usec; }

    /** This function is used to set a timeout in the resolution of microseconds. 
      * @param theUsec time in microseconds for timeout setting
      * @classification public use, call
      */
    IL_DEPRECATED("deprecated, use setTimeout() by use of milliseconds instead")
    void  setUsec( PVSSlong theUsec ){ usec = theUsec; }

    /** Determine whether the timer is running right now. **/
    bool isRunning() const { return m_running; }
    
  protected:

    /** Callback function. This fuction is called from the system whenever the timeout expires.
     *
     * You should overload this function in your class to do whatever is needed when a timeout
     * occurs.
     *
     * @warning Any operations conducted in this method will block the Manager's main thread.
     *
     * @classification public use, overload
     **/
    virtual void timerExpired() { /* empty */ }

  private:
    
    /// seconds
    PVSSlong sec;
    /// microseconds
    PVSSlong usec;
    
    // indicates whether this is a one-shot or cyclic timer
    bool m_oneShot;

    // indicates whether the timer is running
    bool m_running;

    // the timerExpired method provided by the itcIOHandler.
    // we use it to call our own timerExpired, user must not overload it
    void  timerExpired(long sec, long usec) override;

    friend class UNIT_TEST_FRIEND_CLASS;
};

#endif




