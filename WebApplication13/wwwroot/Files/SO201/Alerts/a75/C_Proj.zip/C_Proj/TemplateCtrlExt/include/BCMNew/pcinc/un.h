/*
 * Definitions for UNIX IPC domain.
 */

#ifndef _sys_un_h
#define _sys_un_h

struct	sockaddr_un {
	short	sun_family;		/* AF_UNIX */
	char	sun_path[108];		/* path name (gag) */
};

#ifdef KERNEL
int	unp_discard();
#endif

#endif /*!_sys_un_h*/
