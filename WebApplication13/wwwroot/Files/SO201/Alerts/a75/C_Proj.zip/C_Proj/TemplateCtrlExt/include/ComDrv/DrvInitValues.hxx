#ifndef _DRVINITVALUES_H_
#define _DRVINITVALUES_H_

#ifndef _HWOBJECT_H_
#include <HWObject.hxx>
#endif

#ifndef _DPMSGANSWER_H_
#include <DpMsgAnswer.hxx>
#endif

#ifndef _WAITFORANSWER_H_
#include <WaitForAnswer.hxx>
#endif

/** Class for initialisation of value attributes.
  * It is used to retrieve the initial time stamps for input data,
  * which can be used to check timestamps and discard older values.
  * @classification ETM internal
  */
class DrvInitValues
{
  public:
    /** Constructor
      */
    DrvInitValues();

    /** Destructor
      */
  virtual ~DrvInitValues();

    /** Retrievs all initial values, where the DRV_CHECK_INIT_VALUE bit is set.
      */
    void getAllInitialValues();

    /** Retrieve initial value for a specific address
      * @param hwo pointer to HW object to be retrieved
      */
    void getInitialValue(HWObject *hwo);

    /** Status of initial values is pending
    *  @return TRUE if some initial values are currently outstanding
      */
    bool initialValuesPending() const;

    /** Process the answer to the dpGet for hw object, it sets the original time of the HW object
    * @param answer dp answer message
    */
    void processAnswer(DpMsgAnswer &answer);

  protected:

  private:
    class DrvInitValuesWFA : public WaitForAnswer
    {
      public:
        DrvInitValuesWFA(DrvInitValues *iv) : initValues_(iv) {};
        virtual void callBack(DpMsgAnswer &answer);

      private:
        DrvInitValues *initValues_;
    };

  /** Check if the config pointer is an output and iterate
    * until it gets an input
      * @param hwo HW object
    * @param dpId dp identifier
      * @return TRUE if input is found
    */
    bool getDpId4HWObject(HWObject *hwo, DpIdentifier &dpId) const;

  /** Find HW address according tor dp identifier from config
    * until it gets an input
    * @param dpId dp identifier
      * @return pointer to HW object
    */
    HWObject* getHWObject4DpId(DpIdentifier &dpId) const;

    static const unsigned dpGetBlockSize = 64;
    int outstandingCount_;
    DrvInitValuesWFA *wait_;

    // no copying
    DrvInitValues(const DrvInitValues &);
    DrvInitValues & operator=(const DrvInitValues &);

friend class UNIT_TEST_FRIEND_CLASS;
};

#endif
