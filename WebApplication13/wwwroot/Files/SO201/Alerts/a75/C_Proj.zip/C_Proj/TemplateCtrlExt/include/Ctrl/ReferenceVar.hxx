// Eine Anytype, die eine weitere Variable referenziert

#ifndef  _REFERENCEVAR_H_
#define  _REFERENCEVAR_H_

#include <AnyTypeVar.hxx>

class DLLEXP_CTRL ReferenceVar : public AnyTypeVar
{
  public:
    /// constructor
    ReferenceVar(Variable *v = 0) { cachedIsA = REFERENCE_VAR; setVar(v); };
    ReferenceVar(const ReferenceVar &rVal) { cachedIsA = REFERENCE_VAR; setVar(rVal.getVar()); }
   ~ReferenceVar() { setVar(0); }

    virtual Variable *allocate() const { return new ReferenceVar(); }

    virtual Variable *clone() const { return new ReferenceVar(var); }

    /// overloaded function returns variable type
    virtual VariableType isAUncached() const { return REFERENCE_VAR; }

    /// overloaded function returns variable type
    virtual VariableType isAUncached(VariableType varType) const
    {
      if (varType == REFERENCE_VAR)
        return varType;

      return AnyTypeVar::isAUncached(varType);
    }

    virtual Variable &operator=(const Variable &rVal)
    {
      if (rVal.isA() == REFERENCE_VAR)
        setVar( ((ReferenceVar &) rVal).getVar());

      return *this;
    }

    int operator==(const Variable &rVal) const
    {
      if (rVal.isA() == REFERENCE_VAR)
        return AnyTypeVar::operator==(rVal);

      return 0;
    }

    virtual void setVar(Variable *v) { var = v; }
};

#endif
