#ifndef _DPMSGANSWERWITHALERTSITERATOR_H_
#define _DPMSGANSWERWITHALERTSITERATOR_H_

#include <MsgGroupIterator.hxx>

// forward declarations
class DpMsgAnswer;
class AnswerGroup;
class AlertList;
class AlertAttrList;
class DpIdentifier;
class DpVCItem;


/**
 * A MsgGroupIterator-implementation for DpMsgAnswer messages that contain
 * AlertAttrLists. Use only with answers to alertGet, alertGetPeriod
 * and alertConnect.
 *
 * Some notes on the implementation:
 * - The message can be changed group-wise, and values can be changed per item.
 * - Items of a group in the iterator always belong to the same DPE.
 * - This iterator steps through the AlertAttrLists of the message. If getNextGroup()
 *   reaches the end of an AnswerGroup, it jumps to the next AnswerGroup.
 *   It will also skip AnswerGroups that do not contain any AlertAttrLists.
 * - Calling getFirstGroup() / getNextGroup() changes the internal cursor of the message.
 *
 * @internal
 */
class DLLEXP_MESSAGES DpMsgAnswerWithAlertsIterator : public MsgGroupIterator
{
public:
  /**
   * Creates a new iterator for the given message.
   *
   * Be aware that the iterator uses the getFirst*() / getNext*() methods
   * of the message, so you cannot rely on the position in the list
   * during and after usage of the iterator.
   */
  DpMsgAnswerWithAlertsIterator(DpMsgAnswer &msg);

  /**
   * Resets the position of the iterator to the first non-empty group (AlertAttrList).
   *
   * @return False if the message is empty, otherwise true.
   */
  virtual bool getFirstGroup() const;

  /**
   * Advances the position of the iterator to the next non-empty group (AlertAttrList).
   *
   * @return False if there is no next group, otherwise true.
   */
  virtual bool getNextGroup() const;

  /**
   * Resets the position in the current group (AlertAttrList) to the first item.
   *
   * @return Returns the item, or null if the group is empty.
   */
  virtual const DpIdentifier *getFirst() const;

  /**
   * Advances the position of the iterator in the current group to the next item.
   *
   * @return Returns the item, or null if there are no more items in the group.
   */
  virtual const DpIdentifier *getNext() const;

  /**
   * Returns the item at the current position of the iterator.
   */
  virtual const DpIdentifier *getCurrent() const;

  /**
   * Remove the current group (AlertAttrList) from the message.
   *
   * @param errorPtr If not null, this sets the error message of the AnswerGroup.
   *                 When an error message is already set in the current AnswerGroup,
   *                 it will be overwritten.
   */
  virtual bool removeCurrentGroup(ErrClass *errorPtr = 0);

  virtual const Variable *getCurrentValue() const;

  virtual Variable *getCurrentValue();

  virtual bool replaceCurrentValue(Variable *newValue);

  /**
   * A group will always belong to a single DPE, because the groups are
   * AlertAttrLists.
   */
  virtual bool hasSameDpePerGroup() const { return true; }

private:
  // avoid copy construction and copy assignment
  DpMsgAnswerWithAlertsIterator(const DpMsgAnswerWithAlertsIterator &);
  DpMsgAnswerWithAlertsIterator &operator=(const DpMsgAnswerWithAlertsIterator &);

  DpMsgAnswer &msg_;
  mutable AnswerGroup *answerGroup_;
  mutable AlertAttrList *currentGroup_;
  mutable DpVCItem *currentItem_;

};

#endif // _DPMSGANSWERWITHALERTSITERATOR_H_
