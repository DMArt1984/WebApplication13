
#ifndef  _KERBEROS_H_
#define  _KERBEROS_H_

#include <Blob.hxx>
#include <CharString.hxx>
#include <DynVar.hxx>


#ifdef WIN32
# define SECURITY_WIN32
# include <windows.h>
# include <sspi.h>
#elif defined (NO_KERBEROS)
// android, iPhone has no Kerberos; make just an empty shell
# define OM_uint32 int
# define gss_name_t int
# define gss_cred_id_t int
# define gss_ctx_id_t int
#elif defined(OS_LINUX) || defined(__APPLE__)
// OpenVision (Linux) wants gssapi_krb5 instead of gssapi
// Or both ...
# include <gssapi/gssapi.h>
# include <gssapi/gssapi_krb5.h>
#elif defined (OS_SOLARIS)
# include <gssapi/gssapi.h>
#elif defined (OS_FREEBSD)
# ifdef __cplusplus
extern "C" {
# endif
# include <gssapi/gssapi.h>
# ifdef __cplusplus
}
# endif
#else
# error "Unknown platform"
#endif

/** Handles common client and server functionalities of the Kerberos protocol
 * @see Kerberos documentation
 */
class DLLEXP_BASICS Kerberos
{
  friend class UNIT_TEST_FRIEND_CLASS;

  public:
    /** Register the SPN &lt;service&gt;/&lt;host&gt;
     * @see Kerberos documentation
     */
    static bool registerSPN(const CharString &service);

  public:
    /// Default constructor
    Kerberos();

    /// Konstruct a authentication for the specfied package
    Kerberos(const char *package);

    /// Destructor
    virtual ~Kerberos();

  public:
    /** Sets flag for requesting an anonymous context
     * @see Kerberos documentation
     */
    bool isAnonymitySet() const;

    /** Context flag for mutual authentication, necessary for
     *  signing/verifying messages
     * @see Kerberos documentation
     */
    bool isMutualAuthenticationSet() const;

    /** Context flag for encryption, necessary for encrypting/decrypting messages
     * @see Kerberos documentation
     */
    bool isEncryptionSet() const;

    /** Context flag for integrity
     * @see Kerberos documentation
     */
    bool isIntegritySet() const;

    /** Context for detection
     * @see Kerberos documentation
     */
    bool isRequestDetectionSet() const;

    /** Context flag for sequence checking
     * @see Kerberos documentation
     */
    bool isSequenceCheckingSet() const;

    /** Context flag for replay detection
     * @see Kerberos documentation
     */
    bool isReplayDetectionSet() const;

    /** Context flag for delegation
     * @see Kerberos documentation
     */
    bool isDelegationSet() const;

    /** Creates a signature. A context has to be established before.
     * @see isEstablished()
     *
     * @param [in] message the message, which shall be signed
     * @param [out] signature the resulting signature
     *
     * @return <tt>true</tt> iff the message was signed successfully
     */
    bool makeSignature(const Blob &message, Blob &signature) const;

    /** Verifies a signature. A context has to be established before.
     * @see isEstablished()
     *
     * @param [in] message the message, which shall be verified against signature
     * @param [out] signature the signature of message
     *
     * @return <tt>true</tt> iff the message matches its signature
     */
    bool verifySignature(const Blob &message, const Blob &signature) const;

    /** Encrypts a message so that only the communication partner can decrypt it.
     *  A context has to be established before.
     * @see isEstablished()
     *
     * @param [in] in the cleartext
     * @param [out] out the ciphertext
     *
     * @return <tt>true</tt> iff the message was encrypted successfully
     */
    bool encryptMessage(const Blob &in, Blob &out) const;

    /** Decrypts a message that the communication partner has encrypted.
     *  A context has to be established before.
     * @see isEstablished()
     *
     * @param [in] in the ciphertext
     * @param [out] out the cleartext
     *
     * @return <tt>true</tt> iff the message was decrypted successful
     */
    bool decryptMessage(const Blob &in, Blob &out) const;

    /// Is a the context with the communication partner fully established
    bool isEstablished() const {return contextState_ == Established;}

    /** Get the name (UPN) of the client, this method is only useful on the
     *  Kerberos server
     * @see Kerberos documentation
     *
     * @param [out] upn the UPN of the client
     * @return <tt>true</tt> if the UPN could be retrieved,
     *         <tt>false</tt> if not (e.g. if no client is connected)
     */
	  bool getSourceName(CharString &upn) const;

    /** Get the groups of the client, this method is only useful on the Kerberos
     *  server. There may be different entries in the MappingVar items of
     *  groupList, but at least the key "Name" is defined on all platforms
     * @see Kerberos documentation
     * 
     * @param [out] groupList the list will consist of MappingVar variables,
     *              which contain TextVar values as keys and values.
     */
    bool getGroupList(DynVar &groupList) const;

    /// Print Debug information about credentials and context (platform specific)
    void debug(std::ostream &os) const;

  public:
    /** Initializes the package. Parameter is the SPN
     *
     * @param [in] serviceName the SPN of the client or server
     * @return <tt>false</tt> iff initialization was not successful,
     *         <tt>true</tt> might be returned altough establishContext()
     *         will not be able to establish a context with the given SPN
     *
     * @see Kerberos documentation
     */
    virtual bool init(const char *serviceName) = 0;

    /** Establishes a Kerberos security context with the corresponding
     *  communication partner (client or server)
     *
     * @param [in] in the input token (may be from the communication partner)
     * @param [out] out the output token for the communication partner
     * @return indicates if the current step was successful, but the context
     *         is not fully established until isEstablished() returns <tt>true</tt>
     *
     * @see Kerberos documentation
     */
    virtual bool establishContext(const Blob &in, Blob &out) = 0;

    /// Return <tt>true</tt> iff this is a server context
    virtual bool isServer() const = 0;

    /// Returns an error string for the given message (platform specific)
    CharString getLastError(const char *msg) const;

    /** The package name given to the constructor
     * @see Kerberos documentation
     */
    const CharString & getPackageName() const  {return packageName_;}

    /** The SPN given to init()
     * @see Kerberos documentation
     */
    const CharString & getServiceName() const {return serviceName_;}

  protected:
#ifdef WIN32
    /// Windows-specific implementation of getLastError(const char*)
    CharString getLastError(const char *msg, SECURITY_STATUS ss) const;
#else
    /// Linux-/Solaris-specific implementation of getLastError(const char*)
    CharString getLastError(const char *msg, OM_uint32 majorStatus, OM_uint32 minorStatus) const;
#endif

    /// The package name given to the constructor
    CharString packageName_;

    /// The SPN given to init()
    CharString serviceName_;

    /// The current state of the Kerberos security context
    enum  ContextState 
    {
      /// No initialization started
      None,
      /// Initialization started, further handshake steps needed
      Initializing,
      /// Kerberos security context fully established
      Established
    } contextState_;

#ifdef WIN32
    /** windows-specific return value of all Kerberos functions
     * @see WIN32 API documentation
     */
    mutable SECURITY_STATUS  ss_;

    /// indicates if credentials_ has been allocated and must be freed
    bool          haveCredentials_;

    /// indicates if context_ has been allocated and must be freed
    bool          haveContext_;

    /** windows-specific credentials handle
     * @see WIN32 API documentation
     */
    CredHandle    credentials_;

    /** windows-specific security context handle
     * @see WIN32 API documentation
     */
    CtxtHandle    context_;

    /** windows-specific security context flags
     * @see WIN32 API documentation
     */
    ULONG         returnFlags_;

    /** windows-specific message size indicator
     * @see WIN32 API documentation
     */
    SecPkgContext_Sizes sizes_;

    /** windows-specific message stream size indicator
     * @see WIN32 API documentation
     */
    SecPkgContext_StreamSizes streamSizes_;
#else
    /** GSSAPI-specific major status flag
     * @see GSSAPI documentation
     */
    mutable OM_uint32     majorStatus_;

    /** GSSAPI-specific minor status flag
     * @see GSSAPI documentation
     */
    mutable OM_uint32     minorStatus_;

    /** GSSAPI-specific principal name
     * @see GSSAPI documentation
     */
    gss_name_t    principalName_;

    /** GSSAPI-specific credentials handle
     * @see GSSAPI documentation
     */
    gss_cred_id_t credentials_;

    /** GSSAPI-specific security context handle
     * @see GSSAPI documentation
     */
    gss_ctx_id_t  context_;

    /** GSSAPI-specific security context flags
     * @see GSSAPI documentation
     */
    OM_uint32     returnFlags_;
#endif

  private:
    // Do not copy
    // Else we must export and import the context
    Kerberos & operator=(const Kerberos &) {return *this;}  //COVINFO LINE: defensive (AP: disallow =operator)
};

/** Implements a Kerberos client
 * @see Kerberos documentation
 */
class DLLEXP_BASICS KerberosClient : public Kerberos
{
  friend class UNIT_TEST_FRIEND_CLASS;

  public:
    /// Uses the default package
    KerberosClient();

    /** Uses the given package for Kerberos operations
     *
     * @param [in] package the package name for Kerberos operations
     * @see Kerberos documentation
     */
    KerberosClient(const char *package);

  public:
    /** Initializes the package. Parameter is the SPN
     *
     * @param [in] serviceName the SPN of the client
     * @return <tt>false</tt> iff initialization was not successful,
     *         <tt>true</tt> might be returned altough establishContext()
     *         will not be able to establish a context with the given SPN
     * @see Kerberos documentation
     */
    bool init(const char *serviceName);

    /** Sets flag for requesting an anonymous context
     * @see Kerberos documentation
     */
    void requestAnonymity();

    /** Sets flag for requesting mutual authentication when establishing the
     *  context with the server, necessary for signing/verifying messages
     * @see Kerberos documentation
     */
    void requestMutualAuthentication();

    /** Sets flag for requesting encryption when establishing the
     *  context with the server, necessary for encrypting/decrypting messages
     * @see Kerberos documentation
     */
    void requestEncryption();

    /** Sets flag for requesting integrity
     * @see Kerberos documentation
     */
    void requestIntegrity();

    /** Sets flag for requesting sequence checking
     * @see Kerberos documentation
     */
    void requestSequenceChecking();

    /** Sets flag for requesting replay detection
     * @see Kerberos documentation
     */
    void requestReplayDetection();

    /** Sets flag for requesting delegation
     * @see Kerberos documentation
     */
    void requestDelegation();

    /** Establish a security context with a Kerberos server. This is always
     *  initiated by the client with some input token; the output token may
     *  have to be transfered to the server for negotiation. Depending on the
     *  requested flags, this handshake may have to be repeated several times,
     *  until Kerberos::isEstablished() returns <tt>true</tt>
     * @see Kerberos documentation
     *
     * @param [in] in any input token
     * @param [out] out a token for the server
     * @return <tt>true</tt> iff no error occurred, but the context is established
     *         only when Kerberos::isEstablished() returns <tt>true</tt>
     */
    bool establishContext(const Blob &in, Blob &out);

    /// Returns <tt>false</tt>, since this is a client context
    bool isServer() const {return false;}

  private:
#ifdef WIN32
    ULONG      requestFlags_;
#else
    OM_uint32  requestFlags_;
#endif

  private:
    // Do not copy
    KerberosClient & operator=(const KerberosClient &) {return *this;} //COVINFO LINE: defensive (AP: disallow =operator)
};

/** Implements a Kerberos server
 * @see Kerberos documentation
 */
class DLLEXP_BASICS KerberosServer : public Kerberos
{
  friend class UNIT_TEST_FRIEND_CLASS;

  public:
    /// Uses the default package
    KerberosServer();

    /** Uses the given package
     *
     * @param [in] package the package name for Kerberos operations
     * @see Kerberos documentation
     */
    KerberosServer(const char *package);

  public:
    /** Initializes the package. Parameter is the SPN
     *
     * @param [in] serviceName the SPN of the server
     * @return <tt>false</tt> iff initialization was not successful,
     *         <tt>true</tt> might be returned altough establishContext()
     *         will not be able to establish a context with the given SPN
     * @see Kerberos documentation
     */
    bool init(const char *serviceName);

    /** Establish a security context with a Kerberos client. This is always
     *  initiated by the client with a specialized security token; the output
     *  token may have to be transfered back to the client for negotiation.
     *  Depending on the requested flags, this handshake may have to be repeated
     *  several times, until Kerberos::isEstablished() returns <tt>true</tt>
     * @see Kerberos documentation
     *
     * @param [in] in an input security token from a Kerberos client
     * @param [out] out the answer token for the client
     * @return <tt>true</tt> iff no error occurred, but the context is established
     *         only when Kerberos::isEstablished() returns <tt>true</tt>
     */
    bool establishContext(const Blob &in, Blob &out);

    /// Returns <tt>true</tt>, since this is a server context
    bool isServer() const {return true;}

  private:
    // Do not copy
    KerberosServer operator=(const KerberosServer &) {return *this;}  //COVINFO LINE: defensive (AP: disallow =operator)
};

#endif
