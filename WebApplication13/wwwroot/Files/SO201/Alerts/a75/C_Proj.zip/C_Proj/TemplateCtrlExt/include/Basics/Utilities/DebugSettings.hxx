// This class manages the debug flags
#ifndef  _DEBUGSETTINGS_H_
#define  _DEBUGSETTINGS_H_

#ifndef  _TYPES_HXX_
#include <Types.hxx>
#endif

#ifndef  _CHARSTRING_H_
#include <CharString.hxx>
#endif

#ifndef  _BITVEC_H_
#include <BitVec.hxx>
#endif

#ifndef _SIMPLEPTRARRAY_H_
#include <SimplePtrArray.hxx>
#endif


#include <iostream>


/// Simple struct to store information about a debug flag
struct  DLLEXP_BASICS  DebugNameId 
{
  DebugNameId(const CharString &name, PVSSshort id) : dbgName_(name), dbgId_(id) {} 
  DebugNameId(const CharString &name, PVSSshort id, const CharString &desc) :
    dbgName_(name), dbgId_(id), dbgDesc_(desc) {}
  CharString  dbgName_;
  PVSSshort   dbgId_;
  CharString  dbgDesc_;
};


#ifdef WIN32
#pragma warning ( push )
#pragma warning ( disable: 4231 )
#endif

#if defined(LIBS_AS_DLL)
  EXTERN_BASICS template class DLLEXP_BASICS SimplePtrArray<DebugNameId>;
#endif

#ifdef WIN32
#pragma warning ( pop )
#endif


/**
  Administration of debug flags.
  This class holds a list debug flags, which can be set and queried by number or name.
  This class is intended to manage the debug and report levels, which the user can switch  
  on / off with the command "killdbg pid -dbg flag,..." or "killdbg pid -report flag,...".
  The programmer can query these flags at runtime and print debug information.
*/ 

class  DLLEXP_BASICS DebugSettings
{
  public:

    /**
    Default constructor. 
    */
    DebugSettings() {};
  
  public:

    /**
    Registers a new debug flag. 
    
    @param  name    The name of the debug flag. 
    
    @return  Returns the new id, or the old one if there was already a flag with this name. Otherwise -1 is returned
    */
    PVSSshort registerFlag(const CharString &name)
    { return registerFlag(name, ""); }

    /**
    Registers a new debug flag with a description. 
    
    @param  name    The name of the debug flag. 
    @param  name    The description of the debug flag. 
    
    @return  Returns the new id, or the old one if there was already a flag with this name. Otherwise -1 is returned
    */
    PVSSshort registerFlag(const CharString &name, const CharString &desc);

    /**
    Checks if given flag is set
    
    @param  id  The flag identifier. 
    
    @return True, if the given flag is set. 
    */
    PVSSboolean  getFlag(PVSSshort id) const;
    
    /**
    Looks up the flag first and then checks if it is set
    
    @param  name    The name of the debug flag. 
    
    @return True, if the given flag is set. 
    */
    PVSSboolean  getFlag(const CharString &name) const;

    /**
    Looks up the flag

    @param  name    The name of the debug flag.

    @return the id of the given flag.
    */
    PVSSshort  getFlagId(const CharString &name) const;
    
    /**
    Sets / resets the given flag
  
    @param  id      The flag identifier. 
    @param  state   The new state of the debug flag. 
    */
    void  setFlag(PVSSshort id, PVSSboolean state);

    /**
    Looks up the flag first and Sets / resets the given flag
  
    @param  name    The name of the debug flag. 
    @param  state   The new state of the debug flag. 
    */
    void  setFlag(const CharString &name, PVSSboolean state);
    
    /**
    Sets a list of flags. nameList is a comma separated list of names / ids
  
    @param  name    the list of debug flag pairs  [name,id]. 
    */
    void setFlagList(const CharString &name);

    /**
    Sets all configured debug flags
    */    
    void  setAllFlags();

    /**
    Clears all configured debug flags
    */    
    void  clearAllFlags();


    /**
    Checks if any flag is set

    @return True, if any debug flag is set. 
    */    
    PVSSboolean anySet() const;

    /**
    Gets the list of all configured debug flags 

    @return The list of the debug flags. 
    */    
    CharString  getList() const;

    /**
    Gets the name of a flag
    
    @param  id  The flag identifier. 
    
    @return The flag name or empty string if the id is out of the range. 
    */
    CharString getFlagName(PVSSshort id) const;

    /**
    Changes the name of a flag
    
    @param  name    The new name of the debug flag. 
    @param  id      The flag identifier. 
    */
    void  setFlagName(const CharString &name, PVSSshort id);

    /**
    Gets the description of a flag
    
    @param  id  The flag identifier. 
    
    @return The flag description or empty string if the id is out of the range. 
    */
    CharString getFlagDesc(PVSSshort id) const;

    /**
    Prints all debug names and their coresponding ids
    
    @param [in,out] os  The output stream to be written to. 
    */
    void debugPrint(std::ostream &os) const;

    /**
    Prints all debug names and ids in a format suitable for help output
    
    @param [in,out] os  The output stream to be written to. 
    */
    void helpPrint(std::ostream &os) const;

  private:
    SimplePtrArray<DebugNameId> dbgList_;   // A very simple list to lookup ids
    BitVec   dbgFlags_;
};


// ----------------------------------------------------------------------------------------
inline  PVSSboolean  DebugSettings::getFlag(PVSSshort id) const
{
  return dbgFlags_.get(id);
}

inline  void  DebugSettings::setFlag(PVSSshort id, PVSSboolean state)
{
  // Id must be registered. The registered range is a list of ids
  // from 0 to dbgList_.getLast->dbgId_. There are no holes in this list,
  // because new IDs are always at the end and you cannot delete from this list
  if (!dbgList_.getLast() || id < 0 || id > dbgList_.getLast()->dbgId_)
    return;

  if (state)
    dbgFlags_.set(id); 
  else
    dbgFlags_.clear(id);
}


inline  PVSSboolean  DebugSettings::anySet() const
{
  return dbgFlags_.anySet();
}


inline  CharString DebugSettings::getFlagName(PVSSshort id) const
{
  if (!dbgList_.getLast() || id < 0 || id > dbgList_.getLast()->dbgId_)
    return CharString();

  // Ids are consecutive
  return dbgList_.getAt(id)->dbgName_;
}


inline  void  DebugSettings::setFlagName(const CharString &name, PVSSshort id)
{
  if (!dbgList_.getLast() || id < 0 || id > dbgList_.getLast()->dbgId_)
    return;

  // Ids are consecutive
  dbgList_.getAt(id)->dbgName_ = name;
}


inline  CharString DebugSettings::getFlagDesc(PVSSshort id) const
{
  if (!dbgList_.getLast() || id < 0 || id > dbgList_.getLast()->dbgId_)
    return CharString();

  return dbgList_.getAt(id)->dbgDesc_;
}

#endif
