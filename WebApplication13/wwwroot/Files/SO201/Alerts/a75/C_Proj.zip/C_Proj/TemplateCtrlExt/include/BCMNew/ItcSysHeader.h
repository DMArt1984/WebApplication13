//
//  $RCSfile$
//  $Date$
//  $Revision$
//  $Author$
//  $Locker$
//  $State$
//  $Source$
//
// %Z%JESSI-COMMON-FRAMEWORK 2.0
// %Z%Copyright (C) by Siemens Nixdorf Informationssysteme AG 1992
// %Z%Copyright (C) by Universitaet GH Paderborn 1992
// %Z%Development of this software was partially funded by ESPRIT project 7364.
// %Z%BCM %M% %I% %E%


/*
 * used for uniuqe include of system include files
 *
 */


#ifdef   USES_sys_types
#ifndef  SYS_TYPES_H
#define  SYS_TYPES_H
#include <sys/types.h>
#endif
#endif

#ifdef   USES_sys_acct
#ifndef  SYS_ACCT_H
#define  SYS_ACCT_H
#include <sys/acct.h>
#endif
#endif

#ifdef   USES_sys_asynch
#ifndef  SYS_ASYNCH_H
#define  SYS_ASYNCH_H
#include <sys/asynch.h>
#endif
#endif

#ifdef   USES_sys_audit
#ifndef  SYS_AUDIT_H
#define  SYS_AUDIT_H
#include <sys/audit.h>
#endif
#endif

#ifdef   USES_sys_bk
#ifndef  SYS_BK_H
#define  SYS_BK_H
#include <sys/bk.h>
#endif
#endif

#ifdef   USES_sys_bootconf
#ifndef  SYS_BOOTCONF_H
#define  SYS_BOOTCONF_H
#include <sys/bootconf.h>
#endif
#endif

#ifdef   USES_sys_buf
#ifndef  SYS_BUF_H
#define  SYS_BUF_H
#include <sys/buf.h>
#endif
#endif

#ifdef   USES_sys_callout
#ifndef  SYS_CALLOUT_H
#define  SYS_CALLOUT_H
#include <sys/callout.h>
#endif
#endif

#ifdef   USES_sys_clist
#ifndef  SYS_CLIST_H
#define  SYS_CLIST_H
#include <sys/clist.h>
#endif
#endif

#ifdef   USES_sys_conf
#ifndef  SYS_CONF_H
#define  SYS_CONF_H
#include <sys/conf.h>
#endif
#endif

#ifdef   USES_sys_core
#ifndef  SYS_CORE_H
#define  SYS_CORE_H
#include <sys/core.h>
#endif
#endif

#ifdef   USES_sys_debug
#ifndef  SYS_DEBUG_H
#define  SYS_DEBUG_H
#include <sys/debug.h>
#endif
#endif

#ifdef   USES_sys_des
#ifndef  SYS_DES_H
#define  SYS_DES_H
#include <sys/des.h>
#endif
#endif

#ifdef   USES_sys_dir
#ifndef  SYS_DIR_H
#define  SYS_DIR_H
#include <sys/dir.h>
#endif
#endif

#ifdef   USES_sys_dirent
#ifndef  SYS_DIRENT_H
#define  SYS_DIRENT_H
#include <sys/dirent.h>
#endif
#endif

#ifdef   USES_sys_dk
#ifndef  SYS_DK_H
#define  SYS_DK_H
#include <sys/dk.h>
#endif
#endif

#ifdef   USES_sys_dkbad
#ifndef  SYS_DKBAD_H
#define  SYS_DKBAD_H
#include <sys/dkbad.h>
#endif
#endif

#ifdef   USES_sys_dnlc
#ifndef  SYS_DNLC_H
#define  SYS_DNLC_H
#include <sys/dnlc.h>
#endif
#endif

#ifdef   USES_sys_domain
#ifndef  SYS_DOMAIN_H
#define  SYS_DOMAIN_H
#include <sys/domain.h>
#endif
#endif

#ifdef   USES_sys_dumphdr
#ifndef  SYS_DUMPHDR_H
#define  SYS_DUMPHDR_H
#include <sys/dumphdr.h>
#endif
#endif

#ifdef   USES_sys_errno
#ifndef  SYS_ERRNO_H
#define  SYS_ERRNO_H
#include <sys/errno.h>
#endif
#endif

#ifdef   USES_sys_exec
#ifndef  SYS_EXEC_H
#define  SYS_EXEC_H
#include <sys/exec.h>
#endif
#endif

#ifdef   USES_sys_fcntl
#ifndef  SYS_FCNTL_H
#define  SYS_FCNTL_H
#include <sys/fcntl.h>
#endif
#endif

#ifdef   USES_sys_fcntlcom
#ifndef  SYS_FCNTLCOM_H
#define  SYS_FCNTLCOM_H
#include <sys/fcntlcom.h>
#endif
#endif

#ifdef   USES_sys_file
#ifndef  SYS_FILE_H
#define  SYS_FILE_H
#include <sys/file.h>
#endif
#endif

#ifdef   USES_sys_filio
#ifndef  SYS_FILIO_H
#define  SYS_FILIO_H
#include <sys/filio.h>
#endif
#endif

#ifdef   USES_sys_gprof
#ifndef  SYS_GPROF_H
#define  SYS_GPROF_H
#include <sys/gprof.h>
#endif
#endif

#ifdef   USES_sys_ieeefp
#ifndef  SYS_IEEEFP_H
#define  SYS_IEEEFP_H
#include <sys/ieeefp.h>
#endif
#endif

#ifdef   USES_sys_init_audit
#ifndef  SYS_INIT_AUDIT_H
#define  SYS_INIT_AUDIT_H
#include <sys/init_audit.h>
#endif
#endif

#ifdef   USES_sys_ioccom
#ifndef  SYS_IOCCOM_H
#define  SYS_IOCCOM_H
#include <sys/ioccom.h>
#endif
#endif

#ifdef   USES_sys_ioctl
#ifndef  SYS_IOCTL_H
#define  SYS_IOCTL_H
#include <sys/ioctl.h>
#endif
#endif

#ifdef   USES_sys_ipc
#ifndef  SYS_IPC_H
#define  SYS_IPC_H
#include <sys/ipc.h>
#endif
#endif

#ifdef   USES_sys_kernel
#ifndef  SYS_KERNEL_H
#define  SYS_KERNEL_H
#include <sys/kernel.h>
#endif
#endif

#ifdef   USES_sys_kmem_alloc
#ifndef  SYS_KMEM_ALLOC_H
#define  SYS_KMEM_ALLOC_H
#include <sys/kmem_alloc.h>
#endif
#endif

#ifdef   USES_sys_label
#ifndef  SYS_LABEL_H
#define  SYS_LABEL_H
#include <sys/label.h>
#endif
#endif

#ifdef   USES_sys_limits
#ifndef  SYS_LIMITS_H
#define  SYS_LIMITS_H
#include <sys/limits.h>
#endif
#endif

#ifdef   USES_sys_lock
#ifndef  SYS_LOCK_H
#define  SYS_LOCK_H
#include <sys/lock.h>
#endif
#endif

#ifdef   USES_sys_map
#ifndef  SYS_MAP_H
#define  SYS_MAP_H
#include <sys/map.h>
#endif
#endif

#ifdef   USES_sys_mbuf
#ifndef  SYS_MBUF_H
#define  SYS_MBUF_H
#include <sys/mbuf.h>
#endif
#endif

#ifdef   USES_sys_mman
#ifndef  SYS_MMAN_H
#define  SYS_MMAN_H
#include <sys/mman.h>
#endif
#endif

#ifdef   USES_sys_mount
#ifndef  SYS_MOUNT_H
#define  SYS_MOUNT_H
#include <sys/mount.h>
#endif
#endif

#ifdef   USES_sys_msg
#ifndef  SYS_MSG_H
#define  SYS_MSG_H
#include <sys/msg.h>
#endif
#endif

#ifdef   USES_sys_msgbuf
#ifndef  SYS_MSGBUF_H
#define  SYS_MSGBUF_H
#include <sys/msgbuf.h>
#endif
#endif

#ifdef   USES_sys_mtio
#ifndef  SYS_MTIO_H
#define  SYS_MTIO_H
#include <sys/mtio.h>
#endif
#endif

#ifdef   USES_sys_param
#ifndef  SYS_PARAM_H
#define  SYS_PARAM_H
#ifndef IS_MSWIN__
#include <sys/param.h>
#endif
#endif
#endif

#ifdef   USES_sys_pathconf
#ifndef  SYS_PATHCONF_H
#define  SYS_PATHCONF_H
#include <sys/pathconf.h>
#endif
#endif

#ifdef   USES_sys_pathname
#ifndef  SYS_PATHNAME_H
#define  SYS_PATHNAME_H
#include <sys/pathname.h>
#endif
#endif

#ifdef   USES_sys_poll
#ifndef  SYS_POLL_H
#define  SYS_POLL_H
#include <sys/poll.h>
#endif
#endif

#ifdef   USES_sys_proc
#ifndef  SYS_PROC_H
#define  SYS_PROC_H
#include <sys/proc.h>
#endif
#endif

#ifdef   USES_sys_protosw
#ifndef  SYS_PROTOSW_H
#define  SYS_PROTOSW_H
#include <sys/protosw.h>
#endif
#endif

#ifdef   USES_sys_ptrace
#ifndef  SYS_PTRACE_H
#define  SYS_PTRACE_H
#include <sys/ptrace.h>
#endif
#endif

#ifdef   USES_sys_ptyvar
#ifndef  SYS_PTYVAR_H
#define  SYS_PTYVAR_H
#include <sys/ptyvar.h>
#endif
#endif

#ifdef   USES_sys_reboot
#ifndef  SYS_REBOOT_H
#define  SYS_REBOOT_H
#include <sys/reboot.h>
#endif
#endif

#ifdef   USES_sys_time
#ifndef  SYS_TIME_H
#define  SYS_TIME_H
#include <sys/time.h>
#endif
#endif

#ifdef   USES_sys_timeb
#ifndef  SYS_TIMEB_H
#define  SYS_TIMEB_H
#include <sys/timeb.h>
#endif
#endif

#ifdef   USES_sys_times
#ifndef  SYS_TIMES_H
#define  SYS_TIMES_H
#include <sys/times.h>
#endif
#endif

#ifdef   USES_sys_resource
#ifndef  SYS_RESOURCE_H
#define  SYS_RESOURCE_H
#include <sys/resource.h>
#endif
#endif

#ifdef   USES_sys_sem
#ifndef  SYS_SEM_H
#define  SYS_SEM_H
#include <sys/sem.h>
#endif
#endif

#ifdef   USES_sys_session
#ifndef  SYS_SESSION_H
#define  SYS_SESSION_H
#include <sys/session.h>
#endif
#endif

#ifdef   USES_sys_shm
#ifndef  SYS_SHM_H
#define  SYS_SHM_H
#include <sys/shm.h>
#endif
#endif

#ifdef   USES_sys_signal
#ifndef  SYS_SIGNAL_H
#define  SYS_SIGNAL_H
#include <sys/signal.h>
#endif
#endif

#ifdef   USES_sys_socket
#ifndef  SYS_SOCKET_H
#define  SYS_SOCKET_H
#include <sys/socket.h>
#endif
#endif

#ifdef   USES_sys_socketvar
#ifndef  SYS_SOCKETVAR_H
#define  SYS_SOCKETVAR_H
#include <sys/socketvar.h>
#endif
#endif

#ifdef   USES_sys_sockio
#ifndef  SYS_SOCKIO_H
#define  SYS_SOCKIO_H
#include <sys/sockio.h>
#endif
#endif

#ifdef   USES_sys_stat
#ifndef  SYS_STAT_H
#define  SYS_STAT_H
#include <sys/stat.h>
#endif
#endif

#ifdef   USES_sys_stdtypes
#ifndef  SYS_STDTYPES_H
#define  SYS_STDTYPES_H
#include <sys/stdtypes.h>
#endif
#endif

#ifdef   USES_sys_stream
#ifndef  SYS_STREAM_H
#define  SYS_STREAM_H
#include <sys/stream.h>
#endif
#endif

#ifdef   USES_sys_stropts
#ifndef  SYS_STROPTS_H
#define  SYS_STROPTS_H
#include <sys/stropts.h>
#endif
#endif

#ifdef   USES_sys_strstat
#ifndef  SYS_STRSTAT_H
#define  SYS_STRSTAT_H
#include <sys/strstat.h>
#endif
#endif

#ifdef   USES_sys_syscall
#ifndef  SYS_SYSCALL_H
#define  SYS_SYSCALL_H
#include <sys/syscall.h>
#endif
#endif

#ifdef   USES_sys_syslog
#ifndef  SYS_SYSLOG_H
#define  SYS_SYSLOG_H
#include <sys/syslog.h>
#endif
#endif

#ifdef   USES_sys_sysmacros
#ifndef  SYS_SYSMACROS_H
#define  SYS_SYSMACROS_H
#include <sys/sysmacros.h>
#endif
#endif

#ifdef   USES_sys_systm
#ifndef  SYS_SYSTM_H
#define  SYS_SYSTM_H
#include <sys/systm.h>
#endif
#endif

#ifdef   USES_sys_termio
#ifndef  SYS_TERMIO_H
#define  SYS_TERMIO_H
#include <sys/termio.h>
#endif
#endif

#ifdef   USES_sys_termios
#ifndef  SYS_TERMIOS_H
#define  SYS_TERMIOS_H
#include <sys/termios.h>
#endif
#endif

#ifdef   USES_sys_tihdr
#ifndef  SYS_TIHDR_H
#define  SYS_TIHDR_H
#include <sys/tihdr.h>
#endif
#endif

#ifdef   USES_sys_trace
#ifndef  SYS_TRACE_H
#define  SYS_TRACE_H
#include <sys/trace.h>
#endif
#endif

#ifdef   USES_sys_ttold
#ifndef  SYS_TTOLD_H
#define  SYS_TTOLD_H
#include <sys/ttold.h>
#endif
#endif

#ifdef   USES_sys_tty
#ifndef  SYS_TTY_H
#define  SYS_TTY_H
#include <sys/tty.h>
#endif
#endif

#ifdef   USES_sys_ttychars
#ifndef  SYS_TTYCHARS_H
#define  SYS_TTYCHARS_H
#include <sys/ttychars.h>
#endif
#endif

#ifdef   USES_sys_ttycom
#ifndef  SYS_TTYCOM_H
#define  SYS_TTYCOM_H
#include <sys/ttycom.h>
#endif
#endif

#ifdef   USES_sys_ttydev
#ifndef  SYS_TTYDEV_H
#define  SYS_TTYDEV_H
#include <sys/ttydev.h>
#endif
#endif

#ifdef   USES_sys_ucred
#ifndef  SYS_UCRED_H
#define  SYS_UCRED_H
#include <sys/ucred.h>
#endif
#endif

#ifdef   USES_sys_uio
#ifndef  SYS_UIO_H
#define  SYS_UIO_H
#ifndef IS_MSWIN__
#include <sys/uio.h>
#else
#include <pcinc/uio.h>
#endif
#endif
#endif

#ifdef   USES_sys_un
#ifndef  SYS_UN_H
#define  SYS_UN_H
#include <sys/un.h>
#endif
#endif

#ifdef   USES_sys_unistd
#ifndef  SYS_UNISTD_H
#define  SYS_UNISTD_H
#include <sys/unistd.h>
#endif
#endif

#ifdef   USES_sys_unpcb
#ifndef  SYS_UNPCB_H
#define  SYS_UNPCB_H
#include <sys/unpcb.h>
#endif
#endif

#ifdef   USES_sys_user
#ifndef  SYS_USER_H
#define  SYS_USER_H
#include <sys/user.h>
#endif
#endif

#ifdef   USES_sys_utsname
#ifndef  SYS_UTSNAME_H
#define  SYS_UTSNAME_H
#include <sys/utsname.h>
#endif
#endif

#ifdef   USES_sys_vadvise
#ifndef  SYS_VADVISE_H
#define  SYS_VADVISE_H
#include <sys/vadvise.h>
#endif
#endif

#ifdef   USES_sys_var
#ifndef  SYS_VAR_H
#define  SYS_VAR_H
#include <sys/var.h>
#endif
#endif

#ifdef   USES_sys_varargs
#ifndef  SYS_VARARGS_H
#define  SYS_VARARGS_H
#include <sys/varargs.h>
#endif
#endif

#ifdef   USES_sys_vcmd
#ifndef  SYS_VCMD_H
#define  SYS_VCMD_H
#include <sys/vcmd.h>
#endif
#endif

#ifdef   USES_sys_vfs
#ifndef  SYS_VFS_H
#define  SYS_VFS_H
#include <sys/vfs.h>
#endif
#endif

#ifdef   USES_sys_vfs_stat
#ifndef  SYS_VFS_STAT_H
#define  SYS_VFS_STAT_H
#include <sys/vfs_stat.h>
#endif
#endif

#ifdef   USES_sys_vlimit
#ifndef  SYS_VLIMIT_H
#define  SYS_VLIMIT_H
#include <sys/vlimit.h>
#endif
#endif

#ifdef   USES_sys_vm
#ifndef  SYS_VM_H
#define  SYS_VM_H
#include <sys/vm.h>
#endif
#endif

#ifdef   USES_sys_vmmac
#ifndef  SYS_VMMAC_H
#define  SYS_VMMAC_H
#include <sys/vmmac.h>
#endif
#endif

#ifdef   USES_sys_vmmeter
#ifndef  SYS_VMMETER_H
#define  SYS_VMMETER_H
#include <sys/vmmeter.h>
#endif
#endif

#ifdef   USES_sys_vmparam
#ifndef  SYS_VMPARAM_H
#define  SYS_VMPARAM_H
#include <sys/vmparam.h>
#endif
#endif

#ifdef   USES_sys_vmsystm
#ifndef  SYS_VMSYSTM_H
#define  SYS_VMSYSTM_H
#include <sys/vmsystm.h>
#endif
#endif

#ifdef   USES_sys_vnode
#ifndef  SYS_VNODE_H
#define  SYS_VNODE_H
#include <sys/vnode.h>
#endif
#endif

#ifdef   USES_sys_vtimes
#ifndef  SYS_VTIMES_H
#define  SYS_VTIMES_H
#include <sys/vtimes.h>
#endif
#endif

#ifdef   USES_sys_wait
#ifndef  SYS_WAIT_H
#define  SYS_WAIT_H
#include <sys/wait.h>
#endif
#endif

#ifdef   USES_a_out
#ifndef  A_OUT_H
#define  A_OUT_H
#include <a.out.h>
#endif
#endif

#ifdef   USES_alloca
#ifndef  ALLOCA_H
#define  ALLOCA_H
#include <alloca.h>
#endif
#endif

#ifdef   USES_ar
#ifndef  AR_H
#define  AR_H
#include <ar.h>
#endif
#endif

#ifdef   USES_assert
#ifndef  ASSERT_H
#define  ASSERT_H
#include <assert.h>
#endif
#endif

#ifdef   USES_auevents
#ifndef  AUEVENTS_H
#define  AUEVENTS_H
#include <auevents.h>
#endif
#endif

#ifdef   USES_colorbuf
#ifndef  COLORBUF_H
#define  COLORBUF_H
#include <colorbuf.h>
#endif
#endif

#ifdef   USES_common
#ifndef  COMMON_H
#define  COMMON_H
#include <common.h>
#endif
#endif

#ifdef   USES_complex
#ifndef  COMPLEX_H
#define  COMPLEX_H
#include <complex.h>
#endif
#endif

#ifdef   USES_ctype
#ifndef  CTYPE_H
#define  CTYPE_H
#include <ctype.h>
#endif
#endif

#ifdef   USES_curses
#ifndef  CURSES_H
#define  CURSES_H
#include <curses.h>
#endif
#endif

#ifdef   USES_dbm
#ifndef  DBM_H
#define  DBM_H
#include <dbm.h>
#endif
#endif

#ifdef   USES_des_crypt
#ifndef  DES_CRYPT_H
#define  DES_CRYPT_H
#include <des_crypt.h>
#endif
#endif

#ifdef   USES_dirent
#ifndef  DIRENT_H
#define  DIRENT_H
#include <dirent.h>
#endif
#endif

#ifdef   USES_disktab
#ifndef  DISKTAB_H
#define  DISKTAB_H
#include <disktab.h>
#endif
#endif

#ifdef   USES_dlfcn
#ifndef  DLFCN_H
#define  DLFCN_H
#include <dlfcn.h>
#endif
#endif

#ifdef   USES_errno
#ifndef  ERRNO_H
#define  ERRNO_H
#include <errno.h>
#endif
#endif

#ifdef   USES_exportent
#ifndef  EXPORTENT_H
#define  EXPORTENT_H
#include <exportent.h>
#endif
#endif

#ifdef   USES_fcntl
#ifndef  FCNTL_H
#define  FCNTL_H
#include <fcntl.h>
#endif
#endif

#ifdef   USES_floatingpoint
#ifndef  FLOATINGPOINT_H
#define  FLOATINGPOINT_H
#include <floatingpoint.h>
#endif
#endif

#ifdef   USES_frame
#ifndef  FRAME_H
#define  FRAME_H
#include <frame.h>
#endif
#endif

#ifdef   USES_fstab
#ifndef  FSTAB_H
#define  FSTAB_H
#include <fstab.h>
#endif
#endif

#ifdef   USES_fstream
#ifndef  FSTREAM_H
#define  FSTREAM_H
#include <fstream>
#endif
#endif

#ifdef   USES_ftw
#ifndef  FTW_H
#define  FTW_H
#include <ftw.h>
#endif
#endif

#ifdef   USES_generic
#ifndef  GENERIC_H
#define  GENERIC_H
#define name2(a,b) gEnErIc2(a,b)
#define gEnErIc2(a,b) a ## b

#define name3(a,b,c) gEnErIc3(a,b,c)
#define gEnErIc3(a,b,c) a ## b ## c

#define name4(a,b,c,d) gEnErIc4(a,b,c,d)
#define gEnErIc4(a,b,c,d) a ## b ## c ## d

#define GENERIC_STRING(a) gEnErIcStRiNg(a)
#define gEnErIcStRiNg(a) #a

#define declare(clas,t)        name2(clas,declare)(t)
#define declare2(clas,t1,t2)   name2(clas,declare2)(t1,t2)

#define implement(clas,t)      name2(clas,implement)(t)
#define implement2(clas,t1,t2) name2(clas,implement2)(t1,t2)

//extern genericerror(int,char*);
typedef int (*GPT)(int,char*);

#define set_handler(gen,type,x) name4(set_,type,gen,_handler)(x)

#define errorhandler(gen,type)  name3(type,gen,handler)

#define callerror(gen,type,a,b) (*errorhandler(gen,type))(a,b)
#endif
#endif

#ifdef   USES_grp
#ifndef  GRP_H
#define  GRP_H
#include <grp.h>
#endif
#endif

#ifdef   USES_grpadj
#ifndef  GRPADJ_H
#define  GRPADJ_H
#include <grpadj.h>
#endif
#endif

#ifdef   USES_kvm
#ifndef  KVM_H
#define  KVM_H
#include <kvm.h>
#endif
#endif

#ifdef   USES_langinfo
#ifndef  LANGINFO_H
#define  LANGINFO_H
#include <langinfo.h>
#endif
#endif

#ifdef   USES_lastlog
#ifndef  LASTLOG_H
#define  LASTLOG_H
#include <lastlog.h>
#endif
#endif

#ifdef   USES_libc
#ifndef  LIBC_H
#define  LIBC_H
#include <libc.h>
#endif
#endif

#ifdef   USES_limits
#ifndef  LIMITS_H
#define  LIMITS_H
#include <limits.h>
#endif
#endif

#ifdef   USES_link
#ifndef  LINK_H
#define  LINK_H
#include <link.h>
#endif
#endif

#ifdef   USES_locale
#ifndef  LOCALE_H
#define  LOCALE_H
#include <locale.h>
#endif
#endif

#ifdef   USES_malloc
#ifndef  MALLOC_H
#define  MALLOC_H
#include <malloc.h>
#endif
#endif

#ifdef   USES_malloc_debug
#ifndef  MALLOC_DEBUG_H
#define  MALLOC_DEBUG_H
#include <malloc_debug.h>
#endif
#endif

#ifdef   USES_math
#ifndef  MATH_H
#define  MATH_H
#include <math.h>
#endif
#endif

#ifdef   USES_memory
#ifndef  MEMORY_H
#define  MEMORY_H
#include <memory.h>
#endif
#endif

#ifdef   USES_mntent
#ifndef  MNTENT_H
#define  MNTENT_H
#include <mntent.h>
#endif
#endif

#ifdef   USES_mon
#ifndef  MON_H
#define  MON_H
#include <mon.h>
#endif
#endif

#ifdef   USES_mp
#ifndef  MP_H
#define  MP_H
#include <mp.h>
#endif
#endif

#ifdef   USES_nan
#ifndef  NAN_H
#define  NAN_H
#include <nan.h>
#endif
#endif

#ifdef   USES_ndbm
#ifndef  NDBM_H
#define  NDBM_H
#include <ndbm.h>
#endif
#endif

#ifdef   USES_netdb
#ifndef  NETDB_H
#define  NETDB_H
#include <netdb.h>
#endif
#endif

#ifdef   USES_new
#ifndef  NEW_H
#define  NEW_H
#include <new.h>
#endif
#endif

#ifdef   USES_nlist
#ifndef  NLIST_H
#define  NLIST_H
#include <nlist.h>
#endif
#endif

#ifdef   USES_osfcn
#ifndef  OSFCN_H
#define  OSFCN_H
#include <osfcn.h>
#endif
#endif

#ifdef   USES_poll
#ifndef  POLL_H
#define  POLL_H
#include <poll.h>
#endif
#endif

#ifdef   USES_prof
#ifndef  PROF_H
#define  PROF_H
#include <prof.h>
#endif
#endif

#ifdef   USES_pwd
#ifndef  PWD_H
#define  PWD_H
#include <pwd.h>
#endif
#endif

#ifdef   USES_pwdadj
#ifndef  PWDADJ_H
#define  PWDADJ_H
#include <pwdadj.h>
#endif
#endif

#ifdef   USES_rand48
#ifndef  RAND48_H
#define  RAND48_H
#include <rand48.h>
#endif
#endif

#ifdef   USES_ranlib
#ifndef  RANLIB_H
#define  RANLIB_H
#include <ranlib.h>
#endif
#endif

#ifdef   USES_rasterfile
#ifndef  RASTERFILE_H
#define  RASTERFILE_H
#include <rasterfile.h>
#endif
#endif

#ifdef   USES_regcmp
#ifndef  REGCMP_H
#define  REGCMP_H
#include <regcmp.h>
#endif
#endif

#ifdef   USES_regexp
#ifndef  REGEXP_H
#define  REGEXP_H
#include <regexp.h>
#endif
#endif

#ifdef   USES_resolv
#ifndef  RESOLV_H
#define  RESOLV_H
#include <resolv.h>
#endif
#endif

#ifdef   USES_search
#ifndef  SEARCH_H
#define  SEARCH_H
#include <search.h>
#endif
#endif

#ifdef   USES_setjmp
#ifndef  SETJMP_H
#define  SETJMP_H
#include <setjmp.h>
#endif
#endif

#ifdef   USES_sgtty
#ifndef  SGTTY_H
#define  SGTTY_H
#include <sgtty.h>
#endif
#endif

#ifdef   USES_signal
#ifndef  SIGNAL_H
#define  SIGNAL_H
#include <signal.h>
#endif
#endif

#ifdef   USES_stab
#ifndef  STAB_H
#define  STAB_H
#include <stab.h>
#endif
#endif

#ifdef   USES_stdarg
#ifndef  STDARG_H
#define  STDARG_H
#include <stdarg.h>
#endif
#endif

#ifdef   USES_stddef
#ifndef  STDDEF_H
#define  STDDEF_H
#include <stddef.h>
#endif
#endif

#ifdef   USES_stdio
#ifndef  STDIO_H
#define  STDIO_H
#include <stdio.h>
#endif
#endif

#ifdef   USES_stdlib
#ifndef  STDLIB_H
#define  STDLIB_H
#include <stdlib.h>
#endif
#endif

#ifdef   USES_string
#ifndef  STRING_H
#define  STRING_H
#include <string.h>
#endif
#endif

#ifdef   USES_strings
#ifndef  STRINGS_H
#define  STRINGS_H
#include <strings.h>
#endif
#endif

#ifdef   USES_stropts
#ifndef  STROPTS_H
#define  STROPTS_H
#include <stropts.h>
#endif
#endif

#ifdef   USES_struct
#ifndef  STRUCT_H
#define  STRUCT_H
#include <struct.h>
#endif
#endif

#ifdef   USES_syscall
#ifndef  SYSCALL_H
#define  SYSCALL_H
#include <syscall.h>
#endif
#endif

#ifdef   USES_sysent
#ifndef  SYSENT_H
#define  SYSENT_H
//#include <sysent.h>
#endif
#endif

#ifdef   USES_sysexits
#ifndef  SYSEXITS_H
#define  SYSEXITS_H
#include <sysexits.h>
#endif
#endif

#ifdef   USES_syslog
#ifndef  SYSLOG_H
#define  SYSLOG_H
#include <syslog.h>
#endif
#endif

#ifdef   USES_tar
#ifndef  TAR_H
#define  TAR_H
#include <tar.h>
#endif
#endif

#ifdef   USES_task
#ifndef  TASK_H
#define  TASK_H
#include <task.h>
#endif
#endif

#ifdef   USES_termcap
#ifndef  TERMCAP_H
#define  TERMCAP_H
#include <termcap.h>
#endif
#endif

#ifdef   USES_termio
#ifndef  TERMIO_H
#define  TERMIO_H
#include <termio.h>
#endif
#endif

#ifdef   USES_termios
#ifndef  TERMIOS_H
#define  TERMIOS_H
#include <termios.h>
#endif
#endif

#ifdef   USES_time
#ifndef  TIME_H
#define  TIME_H
#include <time.h>
#endif
#endif

#ifdef   USES_tiuser
#ifndef  TIUSER_H
#define  TIUSER_H
#include <tiuser.h>
#endif
#endif

#ifdef   USES_ttyent
#ifndef  TTYENT_H
#define  TTYENT_H
#include <ttyent.h>
#endif
#endif

#ifdef   USES_tzfile
#ifndef  TZFILE_H
#define  TZFILE_H
#include <tzfile.h>
#endif
#endif

#ifdef   USES_unistd
#ifndef  UNISTD_H
#define  UNISTD_H
#ifndef IS_MSWIN__
#include <unistd.h>
#else
#include "pcinc/unistd.h"
#endif
#endif
#endif

#ifdef   USES_usercore
#ifndef  USERCORE_H
#define  USERCORE_H
#include <usercore.h>
#endif
#endif

#ifdef   USES_ustat
#ifndef  USTAT_H
#define  USTAT_H
#include <ustat.h>
#endif
#endif

#ifdef   USES_utime
#ifndef  UTIME_H
#define  UTIME_H
#include <utime.h>
#endif
#endif

#ifdef   USES_utmp
#ifndef  UTMP_H
#define  UTMP_H
#include <utmp.h>
#endif
#endif

#ifdef   USES_values
#ifndef  VALUES_H
#define  VALUES_H
#include <values.h>
#endif
#endif

#ifdef   USES_varargs
#ifndef  VARARGS_H
#define  VARARGS_H
#include <varargs.h>
#endif
#endif

#ifdef   USES_vector
#ifndef  VECTOR_H
#define  VECTOR_H
#include <vector.h>
#endif
#endif

#ifdef   USES_vfont
#ifndef  VFONT_H
#define  VFONT_H
#include <vfont.h>
#endif
#endif

#ifdef   USES_vfork
#ifndef  VFORK_H
#define  VFORK_H
#include <vfork.h>
#endif
#endif

#ifdef   USES_arpa_ftp
#ifndef  ARPA_FTP_H
#define  ARPA_FTP_H
#include <arpa/ftp.h>
#endif
#endif

#ifdef   USES_arpa_inet
#ifndef  ARPA_INET_H
#define  ARPA_INET_H
#include <arpa/inet.h>
#endif
#endif

#ifdef   USES_arpa_nameser
#ifndef  ARPA_NAMESER_H
#define  ARPA_NAMESER_H
#include <arpa/nameser.h>
#endif
#endif

#ifdef   USES_arpa_telnet
#ifndef  ARPA_TELNET_H
#define  ARPA_TELNET_H
#include <arpa/telnet.h>
#endif
#endif

#ifdef   USES_arpa_tftp
#ifndef  ARPA_TFTP_H
#define  ARPA_TFTP_H
#include <arpa/tftp.h>
#endif
#endif

#ifdef   USES_net_af
#ifndef  NET_AF_H
#define  NET_AF_H
#include <net/af.h>
#endif
#endif

#ifdef   USES_net_if
#ifndef  NET_IF_H
#define  NET_IF_H
#include <net/if.h>
#endif
#endif

#ifdef   USES_net_if_arp
#ifndef  NET_IF_ARP_H
#define  NET_IF_ARP_H
#include <net/if_arp.h>
#endif
#endif

#ifdef   USES_net_if_ieee802
#ifndef  NET_IF_IEEE802_H
#define  NET_IF_IEEE802_H
#include <net/if_ieee802.h>
#endif
#endif

#ifdef   USES_net_netisr
#ifndef  NET_NETISR_H
#define  NET_NETISR_H
#include <net/netisr.h>
#endif
#endif

#ifdef   USES_net_nit
#ifndef  NET_NIT_H
#define  NET_NIT_H
#include <net/nit.h>
#endif
#endif

#ifdef   USES_net_nit_buf
#ifndef  NET_NIT_BUF_H
#define  NET_NIT_BUF_H
#include <net/nit_buf.h>
#endif
#endif

#ifdef   USES_net_nit_if
#ifndef  NET_NIT_IF_H
#define  NET_NIT_IF_H
#include <net/nit_if.h>
#endif
#endif

#ifdef   USES_net_nit_pf
#ifndef  NET_NIT_PF_H
#define  NET_NIT_PF_H
#include <net/nit_pf.h>
#endif
#endif

#ifdef   USES_net_packetfilt
#ifndef  NET_PACKETFILT_H
#define  NET_PACKETFILT_H
#include <net/packetfilt.h>
#endif
#endif

#ifdef   USES_net_raw_cb
#ifndef  NET_RAW_CB_H
#define  NET_RAW_CB_H
#include <net/raw_cb.h>
#endif
#endif

#ifdef   USES_net_route
#ifndef  NET_ROUTE_H
#define  NET_ROUTE_H
#include <net/route.h>
#endif
#endif

#ifdef   USES_netinet_icmp_var
#ifndef  NETINET_ICMP_VAR_H
#define  NETINET_ICMP_VAR_H
#include <netinet/icmp_var.h>
#endif
#endif

#ifdef   USES_netinet_if_ether
#ifndef  NETINET_IF_ETHER_H
#define  NETINET_IF_ETHER_H
#include <netinet/if_ether.h>
#endif
#endif

#ifdef   USES_netinet_in
#ifndef  NETINET_IN_H
#define  NETINET_IN_H
#ifndef  IS_MSWIN__
#include <netinet/in.h>
#endif
#endif
#endif

#ifdef   USES_netinet_in_pcb
#ifndef  NETINET_IN_PCB_H
#define  NETINET_IN_PCB_H
#include <netinet/in_pcb.h>
#endif
#endif

#ifdef   USES_netinet_in_systm
#ifndef  NETINET_IN_SYSTM_H
#define  NETINET_IN_SYSTM_H
#include <netinet/in_systm.h>
#endif
#endif

#ifdef   USES_netinet_in_var
#ifndef  NETINET_IN_VAR_H
#define  NETINET_IN_VAR_H
#include <netinet/in_var.h>
#endif
#endif

#ifdef   USES_netinet_ip
#ifndef  NETINET_IP_H
#define  NETINET_IP_H
#include <netinet/ip.h>
#endif
#endif

#ifdef   USES_netinet_ip_icmp
#ifndef  NETINET_IP_ICMP_H
#define  NETINET_IP_ICMP_H
#include <netinet/ip_icmp.h>
#endif
#endif

#ifdef   USES_netinet_ip_var
#ifndef  NETINET_IP_VAR_H
#define  NETINET_IP_VAR_H
#include <netinet/ip_var.h>
#endif
#endif

#ifdef   USES_netinet_tcp
#ifndef  NETINET_TCP_H
#define  NETINET_TCP_H
#include <netinet/tcp.h>
#endif
#endif

#ifdef   USES_netinet_tcp_debug
#ifndef  NETINET_TCP_DEBUG_H
#define  NETINET_TCP_DEBUG_H
#include <netinet/tcp_debug.h>
#endif
#endif

#ifdef   USES_netinet_tcp_fsm
#ifndef  NETINET_TCP_FSM_H
#define  NETINET_TCP_FSM_H
#include <netinet/tcp_fsm.h>
#endif
#endif

#ifdef   USES_netinet_tcp_seq
#ifndef  NETINET_TCP_SEQ_H
#define  NETINET_TCP_SEQ_H
#include <netinet/tcp_seq.h>
#endif
#endif

#ifdef   USES_netinet_tcp_timer
#ifndef  NETINET_TCP_TIMER_H
#define  NETINET_TCP_TIMER_H
#include <netinet/tcp_timer.h>
#endif
#endif

#ifdef   USES_netinet_tcp_var
#ifndef  NETINET_TCP_VAR_H
#define  NETINET_TCP_VAR_H
#include <netinet/tcp_var.h>
#endif
#endif

#ifdef   USES_netinet_tcpip
#ifndef  NETINET_TCPIP_H
#define  NETINET_TCPIP_H
#include <netinet/tcpip.h>
#endif
#endif

#ifdef   USES_netinet_udp
#ifndef  NETINET_UDP_H
#define  NETINET_UDP_H
#include <netinet/udp.h>
#endif
#endif

#ifdef   USES_netinet_udp_var
#ifndef  NETINET_UDP_VAR_H
#define  NETINET_UDP_VAR_H
#include <netinet/udp_var.h>
#endif
#endif

