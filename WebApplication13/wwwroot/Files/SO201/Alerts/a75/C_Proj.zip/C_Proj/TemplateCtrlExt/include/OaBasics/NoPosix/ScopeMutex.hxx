#ifndef _SCOPEMUTEX_H_
#define _SCOPEMUTEX_H_

#include <Mutex.hxx>

/**
 * A scoped wrapper that automatically locks and unlocks a Mutex.
 *
 * Locks the passed Mutex automatically on creation
 * and keeps it locked for the lifetime of the object.
 * If the specified Mutex is already locked by another thread,
 * the constructor call will block until the Mutex is unlocked.
 *
 * @code
 * // example code
 * 
 * void Foo::synchronizedFoo()
 * {
 *   ScopeMutex lock(Foo::mutex); // automatically locked here
 *
 *   // critical code that needs synchronization ...
 *
 * } // automatically unlocked here (at the end of the function)
 *
 * // works with every kind of scope
 * void Foo::otherSynchronizedFoo()
 * {
 *   if (Foo::needsLocking)
 *   {
 *     ScopeMutex lock(Foo::mutex); // locked here
 *
 *     // critical code
 *
 *   } // unlocked here (at the end of the if statement)
 *   else
 *   {
 *     // nothing locked or unlocked here
 *   }
 *
 *   // also works with a custom scope
 *   {
 *     ScopeMutex lock(Foo::mutex); // locked here
 *
 *     // critical code
 *
 *   } // unlocked here
 * }
 * @endcode
 * @threadsafe
 */
class DLLEXP_OABASICS ScopeMutex
{
  public:
    /**
     * Constructor. Automatically locks the passed Mutex.
     *
     * If the specified Mutex is already locked by another thread,
     * the constructor call will block until the Mutex is unlocked.
     */
    ScopeMutex(Mutex &mutex);

    /**
     * Destructor. Automatically unlocks the Mutex.
     */
    ~ScopeMutex();

  private:
    Mutex &mutex_;
};

#endif
