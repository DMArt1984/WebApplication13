#ifndef _FCALL_H_
#define _FCALL_H_

#include <CtrlExpr.hxx>
#include <CtrlFunc.hxx>
#include <FuncNamesStruct.hxx>
#include <CharString.hxx>
#include <Types.hxx>
#include <SimplePtrArray.hxx>
#include <Socket.hxx>
#include <BitVar.hxx>
#include <IntegerVar.hxx>
#include <TextVar.hxx>
#include <FloatVar.hxx>
#include <LongVar.hxx>
#include <QHash>

class ExprList;
class TimeVar;
class DynVar;
class CtrlVar;
class ClassVar;
class VectorVar;
class MappingVar;
class LangTextVar;

#define MAX_SOCKETS 255

#ifdef LIBS_AS_DLL
  template class DLLEXP_CTRL SimplePtrArray<Socket>;
#endif

/*  author VERANTWORTUNG: Martin Koller                        */
/** Definiert einen Function-Call mit dazugehoerigen Parametern
    @classification internal use
 */
class DLLEXP_CTRL FCall : public CtrlExpr
{
  // FCall interface
  public:
    static const double Pi;

    static void getFuncNames(const FuncNamesStruct * &fn, int &count);

    struct FuncDefinition
    {
      FuncDefinition(int num = -1, const char *sig = nullptr, bool ic = false) : funcNum(num), signature(sig), isConst(ic) { }
      int funcNum;
      const char *signature;
      bool isConst;
    };

    using FuncHash = QHash<CharString, FuncDefinition>;

    static const FuncHash &getFuncHash(VariableType varType);

    /// Returns PVSS_TRUE if the function is defined
    static PVSSboolean isFunctionDefined(const CharString &name)
    { return isFunctionDefined(name.c_str(), static_cast<unsigned int>(name.len())); }

    static PVSSboolean isFunctionDefined(const char *funcName, unsigned nameLen);

    /// Format a variable for output with the ctrl Debug function (DebugN, DebugTN, ...)
    static void formatDebug(unsigned tab, const Variable *varPtr, std::ostream &os);

    // Internal use: Try to convert this to something simpler like a ConstExpr
    static CtrlExpr *getOptimized(FCall *call);

    // called before UserTypes are deleted so that the internal static Variable instances
    // can be deleted to avoid having dangling pointers in ClassVar objects to the then
    // deleted UserTypes
    static void cleanupStatics();

    // get first arguments for startThread and all *connect* functions allowing for
    // [class object,] string|function_ptr callback, ...
    static bool getObjectAndCallback(ClassVar *&object, CtrlFunc *&func,
                                     const CharString &funcName, const ExprList *args, CtrlThread *thread);

  // CtrlExpr
  public:
    /// wird vom YACC auf gerufen (captures CharString)
    FCall(CharString *theName, int line = -1, int filenum = -1);

    ///
    FCall(const CtrlFunc *funcPtr, int line = -1, int filenum = -1);

    /// delete aller private member
    ~FCall();

    ///
    void setArgList(ExprList *theList) { funcArgs = theList; }

    ///
    ExprList *getArgList() const { return funcArgs; }

    ///
    const CharString &getName() const { return funcName ? *funcName : userFunc->getName(); }

    /// if the Function is a Sment execute is called
    virtual const CtrlSment *execute(CtrlThread *thread) const;

    /// if the Function is part of a CtrlSment evaluate is called
    virtual const Variable *evaluate(CtrlThread *thread) const;

    ///
    virtual const CtrlExpr *getFirstExpr(CtrlThread *thread) const;

    /// Returns the type of the Expression
    virtual ExprType isA() const { return FCALL_EXPR; }

    ///
    virtual int isA(SmentType type) const;

    ///
    virtual SmentWeight getWeight() const { return SM_WT_High; }

    virtual void writeTrace(CtrlThread *thread, bool writeValue = true) const;

    virtual void dumpCoverageTree(std::ostream &to, CoverageAction action = DUMP) const;

    virtual CharString toString() const;

    virtual bool checkIntegrity(const CharString &location, CtrlThread *) const;

    // Set type to SELEXPR
    void  setToSelExpr() {funcType = SELEXPR;}

    // special handling when this is a function call inside a class ctor calling the base class ctor
    void markAsBaseClassCtorCall() { funcType = BASECLASS_CTOR; }

    // Get pointer to the user defined function
    const CtrlFunc *getUserFunc() const { return userFunc; }
    void setUserFunc(CtrlFunc *func);

    // synchronized access
    virtual void setSynchronized(CtrlExpr *);
    virtual bool isSynchronized(CtrlThread *t) const;

    virtual CtrlThread *getCurrentThread(CtrlThread *t) const;
    virtual bool lock(CtrlThread *t) const;
    virtual bool unlock(CtrlThread *t) const;
    virtual bool isLocked(CtrlThread *t) const;

    const CtrlSment *userdefdFunc(const CtrlFunc *userFunc, const ExprList *args, CtrlThread *thread, CtrlVar *thisVar = 0) const;

    static bool hasCppInterface(const Variable *var);
    const Variable *executeClassFunc(Variable *var, const CtrlExpr *expr, CtrlThread *thread, Variable *&out) const;
    Variable *getTargetFromClassFunc(Variable *var, CtrlThread *thread) const;
    static IntegerVar *getStdTypeEnum(VariableType type, const CharString &name);

  private:
    enum FuncType
    {
      UNKNOWN,
      INTERNAL,
      EXTERNAL,
      USERDEFD,
      BASECLASS_CTOR,
      SELEXPR
    };

    enum RefCount { DO_REFCOUNT, DONT_REFCOUNT };
    void resolve(const CharString &name, CtrlThread *thread,
                 FuncType &type, PVSSulong &num, const CtrlFunc *&ctrlFunc, RefCount refCount = DO_REFCOUNT) const;

    // ctrl internal functions like time-handling
    const Variable * internalFunc(CtrlThread *thread) const;

    const CtrlSment *callFunction(const CharString &name, FuncType type, PVSSulong num,
                                  const CtrlFunc *ctrlFunc,
                                  const ExprList *args, CtrlThread *thread) const;

    CharString *funcName;
    ExprList  *funcArgs;

    mutable FuncType funcType;
    mutable PVSSulong funcNum;   // function number for hardcoded functions; 0 ... userdefd function
    mutable const CtrlFunc *userFunc;  // pointer to user-defd function
    mutable int userFuncLibIdx;        // lib number (index) to which userFunc points to

  public:
    // constants used in ctrl.gperf for getFileNames()
    // The values are masks and can be combined with binary or
    // internal only (as getFileNames() is private)
    enum
    {
      FILTER_FILES = 1,
      FILTER_DIRS  = 2
    };

    // sorry, but it must not be private to be seen in the generated hash-function
    enum
    {
      // time funcs
      F_hour = 1,
      F_minute,
      F_second,
      F_milliSecond,
      F_month,
      F_day,
      F_year,
      F_daylightsaving,
      F_quarter,
      F_yearDay,
      F_weekDay,
      F_daySecond,
      F_period,
      F_setPeriod,
      F_setTime,
      F_makeTime,
      F_formatTime,
      F_formatTimeUTC,
      F_scanTimeUTC,
      F_timeFromGMT,
      F_getACount,
      F_setACount,
      F_getAIdentifier,
      F_setAIdentifier,
      F_makeATime,
      F_makeMapping,
      F_makeVector,  // NOT for getOptimized(), which expects only DynVar results

      // math funcs
      BEGIN_MATH,  // for getOptimized
      // [ if you add functions make sure they can be called with thread == 0
      F_sin,
      F_cos,
      F_tan,
      F_sinh,
      F_cosh,
      F_tanh,
      F_asin,
      F_acos,
      F_atan,
      F_atan2,
      F_rad2deg,
      F_deg2rad,
      F_exp,
      F_log,
      F_log10,
      F_sqrt,
      F_ceil,
      F_floor,
      F_fabs,
      F_abs,
      F_isnan,
      F_isinf,
      F_pow,
      F_fmod,
      F_ldexp,
      // ]
      END_MATH,  // for getOptimized

      // string functions
      F_strlen,
      F_strltrim,
      F_strrtrim,
      F_substr,
      F_strpos,
      F_strtok,
      F_strreplace,
      F_strchange,
      F_strexpand,
      F_strformat,
      F_strwalk,
      F_strtoupper,
      F_strtolower,

      // unicode string functions
      F_uniStrLen,
      F_uniSubStr,
      F_uniStrPos,
      F_uniStrToUpper,
      F_uniStrToLower,
      F_uniStrTok,
      F_uniStrChange,
      F_uniStrExpand,
      F_uniStrFormat,
      F_uniPatternMatch,
      F_uniDynPatternMatch,
      F_uniStrReplace,

      // other functions
      F_getenv,
      F_setenv,
      F_tmpnam,
      F_delay,
      F_srand,
      F_rand,
      F_secureRandom,
      F_patternMatch,
      F_dynPatternMatch,
      F_numberMatch,
      F_cryptoHash,
      F_getFileCryptoHash,
      F_createUuid,
      F_getType,
      F_getTypeName,
      F_checkScript,
      F_Debug,
      F_DebugN,
      F_DebugTN,
      F_DebugFN,
      F_DebugFTN,
      F_DebugBreak,
      F_formatDebug,
      F_addGlobal,
      F_removeGlobal,

      // functions for dyn_vars
      F_dynlen,

      BEGIN_MAKEDYN,  // for getOptimized
      // [ If you add functions make sure they can be called with thread == 0 and return a DynVar
      F_makeDynInt,
      F_makeDynUInt,
      F_makeDynFloat,
      F_makeDynTime,
      F_makeDynString,
      F_makeDynBool,
      F_makeDynChar,
      F_makeDynAnytype,
      F_makeDynMixed,
      F_makeDynLong,
      F_makeDynULong,
      F_makeDynBit32,
      F_makeDynBit64,
      F_makeDynShape,
      F_makeDynMapping,
      F_makeDynATime,
      // ]
      END_MAKEDYN,  // for getOptimized

      F_getDynInt,
      F_getDynUInt,
      F_getDynFloat,
      F_getDynTime,
      F_getDynString,
      F_getDynBool,
      F_getDynChar,
      F_getDynAnytype,
      F_getDynMixed,
      F_getDynLong,
      F_getDynULong,
      F_getDynBit32,
      F_getDynBit64,
      F_getDynATime,

      F_dynMin,
      F_dynMax,
      F_dynSum,
      F_dynAvg,
      F_dynAvgWT,
      F_dynAppend,
      F_dynAppendConst,
      F_dynInsertAt,
      F_dynInsertAtConst,
      F_dynContains,
      F_dynUnique,
      F_dynSortAsc,
      F_dynSort,
      F_dynDynSort,
      F_dynDynTurn,
      F_dynClear,
      F_dynRemove,
      F_dynCount,
      F_dynIntersect,

      // mapping
      F_mappinglen,
      F_mappingKeys,
      F_mappingHasKey,
      F_mappingGetKey,
      F_mappingGetValue,
      F_mappingRemove,
      F_mappingClear,

      // error handling functions
      F_errorText,

      // thread-functions
      F_startThread,
      F_stopThread,
      F_getThreadId,
      F_waitThread,

      // bit32 manipulation
      F_getBit,
      F_setBit,
      F_checkPattern,
      F_setPattern,

      // language information
      F_getAllLangIds,
      F_getNoOfLangs,
      F_getProjectLangIds,
      F_getActiveLang,
      F_getActiveLangId,
      F_getParamLang,
      F_getMetaLang,
      F_getGlobalLangId,
      F_getLangId,
      F_getLangIdx,
      F_getLocale,
      F_setLangString,

      // ls [pattern [dir]]
      F_getFileNames,
      F_getFileNamesRev,
      F_recodeFileName,

      // redundancy
      F_isLightRedundant,
      F_copyFile,
      F_copyAllFiles,
      F_copyAllFilesRecursive,
      F_getYoungerFiles,
      F_eventHost,
      F_dataHost,
      F_eventPort,
      F_dataPort,
      F_myReduHostNum,
      F_myReduHost,

      F_pmonPort,

      //
      F_strsplit,
      F_strjoin,
      F_setTrace,
      F_removeDoneCB,
      //
      BEGIN_TYPES,  // for getOptimized
      // [ if you add functions make sure they can be called with thread == 0
      F_maxUINT,
      F_minUINT,
      F_maxINT,
      F_minINT,
      F_maxFLOAT,
      F_minFLOAT,
      F_maxULONG,
      F_minULONG,
      F_maxLONG,
      F_minLONG,
      // ]
      END_TYPES,   // for getOptimized
      //
      F_evalScript,
      F_execScript,
      F_evalScriptRestricted,
      F_execScriptRestricted,
      F_startScript,
      F_stopScript,
      //
      F_getFileSize,

      // tcp functions
      F_tcpOpen,
      F_tcpRead,
      F_tcpWrite,
      F_tcpClose,
      F_tcpShutdownOutput,

      // higher level network access functions
      F_netGet,
      F_netHead,
      F_netDelete,
      F_netPost,
      F_netPut,
      F_httpParseDate,

      // udp functions
      F_udpOpen,
      F_udpRead,
      F_udpWrite,
      F_udpClose,

      // v24 functions
      F_v24Open,
      F_v24Read,
      F_v24Write,
      F_v24Close,

      // blob functions
      F_blobZero,
      F_blobSetValue,
      F_blobGetValue,
      F_blobAppendValue,
      F_bloblen,
      F_blobWrite,
      F_blobRead,

      // pmon access functions
      F_pmonGetCount,
      F_pmonGetName,
      F_pmonGetNum,
      F_pmonGetOptions,
      F_pmonGetState,
      F_pmonGetStartTime,
      F_pmonGetPID,
      F_pmonGetStartMode,
      F_pmonGetSecondsToKill,
      F_pmonGetRestartCount,
      F_pmonGetResetMinutes,
      F_pmonStartModeToStr,

      //OPCBrowser
      F_OPCEnumQuery,

      // user info functions
      F_getOSUser,
      F_getCurrentOSUserLocal,
      F_verifyOSUser,
      F_getAllOSGroups,
      F_getAllOSUsers,
      F_getOSUserGroups,
      F_getOSUserGroupsMembership,
      F_getOSGroupUsers,
      F_getOSUsers,
      F_getOSGroups,
      F_getOSGroupName,
      F_getOSUserName,
      F_getOSGroupInfo,
      F_getOSUserInfo,
      F_getOSUserID,
      F_getOSGroupID,
      F_getOSDomainName,
      F_checkOSPassword,
      F_getCurrentDomainName,
      F_getWindowsEvents,
      F_setUserNameSSO,

      F_getHostByName,
      F_getHostByAddr,
      F_getNetworkDevices,

      F_va_start,
      F_va_arg,
      F_va_end,

      F_registerDbgFlag,
      F_isDbgFlag,
      F_setDbgFlag,

      F_getFileModificationTime,
      F_setFileModificationTime,
      F_makeUnixPath,
      F_makeNativePath,
      F_mkdir,
      F_rmdir,
      F_isdir,
      F_isfile,
      F_moveFile,
      F_baseName,
      F_dirName,
      F_getExt,
      F_delExt,
      F_findExecutable,
      F_fswAddPath,
      F_fswRemovePath,

      F_sizeof,
      F_getStackTrace,
      F_throw,
      F_getLastException,
      F_setThrowErrorAsException,

      F_getVariable,
      F_setVariable,

      F_callFunction,
      F_enumValues,
      F_enumKeys,
      F_isInstanceOf,

      F_jsonDecode,
      F_jsonEncode,
      F_base64Decode,
      F_base64Encode,

      F_getComponentName,
      F_getVersionInfo,

      F_regexpSplit,
      F_regexpIndex,
      F_regexpLastIndex,

      // semaphore
      F_semAcquire,
      F_semRelease,
      F_semAvailable,

      F_equalPtr,
      F_assignPtr
    };

    static PVSSulong getFuncNum(const CharString &name);

  private:
    /// calls builtin function
    static const Variable *internalFunc(
        const char *name, PVSSulong funcNum, const ExprList *args, CtrlThread *thread);

    static bool hasNumArgs(unsigned int num, const char *name, const ExprList *args, CtrlThread *thread);
    static bool hasNumArgs(unsigned int min, unsigned int max, const CharString &name, const ExprList *args, CtrlThread *thread);

    static Variable *getTarget(CtrlExpr *expr, const char *name,
                               const ExprList *args, CtrlThread *thread, VariableType type = NO_VAR);

    static Variable *getTarget(const CtrlExpr *expr, CtrlThread *thread);
    const Variable *executeClassFunc(MappingVar *map, const CtrlExpr *expr, CtrlThread *thread) const;
    const Variable *executeClassFunc(TextVar *str, const CtrlExpr *expr, CtrlThread *thread) const;
    const Variable *executeClassFunc(LangTextVar *str, const CtrlExpr *expr, CtrlThread *thread) const;

    // helper functions
    static void strltrim(char *source, const char *trimstr);
    static void strrtrim(char *source, const char *trimstr);
    static void strreverse(char *source);
    static int expandUni(const CharString source, PVSSulong len, CharString &result);

    static void getFileNames(bool match, DynVar &var, const char *dir, const char *pattern, int filter);

    static void getYoungerFilesRecursive(const CharString &dirForm, const TimeVar &from, DynVar &result);

    static void getNetworkDevices(DynVar &dyn);

    static SimplePtrArray<Socket> sockets_;

    /// return a pointer to one of these in case execute() needs to return an error/success condition
    static const IntegerVar errorIntVar;    // the -1 default error code
    static const IntegerVar successIntVar;  // the 0 default success code
    static const TextVar errorTextVar;      // empty string
    static const BitVar errorBitVar;        // false
    static const FloatVar errorFloatVar;    // 0.0
    static const LongVar errorLongVar;      // the -1L error code
};

#endif /* _FCALL_H_ */
