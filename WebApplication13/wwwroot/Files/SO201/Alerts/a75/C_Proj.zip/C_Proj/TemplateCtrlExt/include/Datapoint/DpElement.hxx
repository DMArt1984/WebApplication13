#ifndef _DPELEMENT_H_
#define _DPELEMENT_H_

// VERANTWORTUNG: Johannes Ertl, Martin Koller
// BESCHREIBUNG:  Ein DpElement ist ein echter Knoten in einer Datenpunktvariablen
//                und entspricht einem Knoten (DpTypeNode) im Datenpunkttypen.
//                Welcher Vater und welche Soehne das Element hat, ist im
//                Datenpunkt nicht feststellbar, aber die ElementId enstpricht der
//                id im DpTypeNode des Datenpunkttypen im DpTypContainer. Dort gibt es
//                Funktionen, die Vater und Soehne ermitteln koennen. (Es gibt
//                allerdings entsprechende Funktionen im Datapoint, die einen
//                DpType als Parameter haben).
// ZU BEACHTEN:   Bevor man eine neue Konfiguration anlegt, sollte immer mit checkConfigType
//                ueberprueft werden, ob man diese Konfiguration ueberhaupt einfuegen darf
//                (das wird naemlich bei den "insert" Funktionen nicht getestet!).
//                Ausser man verwendet die insert-Funktionen mit dem DpElementType
//                als Parameter.
//
//                Es darf nur eine Konfiguration eines DpConfigNrTypes existieren
//                (wird intern sichergestellt)

#ifndef  _DPCONFIG_H_
#include <DpConfig.hxx>
#endif

#ifndef  _DPCONFIGNRTYPE_H_
#include <DpConfigNrType.hxx>
#endif

#ifndef  _DPELEMENTTYPE_H_
#include <DpElementType.hxx>
#endif

#ifndef  _DPTYPECONTAINER_H_
#include <DpTypeContainer.hxx>
#endif

#ifndef  _DPTYPES_H_
#include <DpTypes.hxx>
#endif
/**
  DpElement class acts as an instance of DpTypeNode. The link between DpTypeNode
  and DpElement is estabilished via ElementId. The class has no information about
  the structure, but that can be reached via ElementId.
*/
class DLLEXP_DATAPOINT DpElement
{
  friend class UNIT_TEST_FRIEND_CLASS;

  public:
    /// Constructor
    DpElement(DpElementId theId = 0);

    ///destructor
    ~DpElement();

    /**operator <
      @param rVal the element to compare to
      @return nonzero if this is lower rVal, zero otherwise
    */
    int operator<(const DpElement &rVal) const  { return id<rVal.id; }

    /** is element leaf of the tree?
      @param elType DpElementType to check
    */
    static PVSSboolean elementIsLeaf(DpElementType elType)
      {return DpElType::isLeafType(elType);}

    /** is element an array?
      @param elType DpElementType to check
    */
    static PVSSboolean elementIsArray(DpElementType elType)
      {return DpElType::isArrayType(elType);}

    /** is element a record?
      @param elType DpElementType to check
    */
    static PVSSboolean elementIsRecord(DpElementType elType)
      {return DpElType::isRecordType(elType);}

    /** is element a dynamic type
      @param elType DpElementType to check
    */
    static PVSSboolean elementIsDyn(DpElementType elType)
      {return DpElType::isDynType(elType);}

    /** get array type for the element type
      @param subNodeType DpElementType to check
    */
    static DpElementType getArrayType(DpElementType subNodeType)
      {return DpElType::getArrayType(subNodeType);}

    // neben dem zurueckgelieferten Blatt-Typen kann IMMER auch arrayType
    // selbst wieder der subNodeType sein
    /** get subnode type for the array type
      @param arrayType DpElementType to check
    */
    static DpElementType getSubNodeType(DpElementType arrayType)
      {return DpElType::getSubNodeType(arrayType);}

    // Stellt fest, ob der Konfigurationstyp beim angegebenen Manger liegen kann
    // und ob sie fuer den Elementtypen geeignet ist (z.B. DpIntValue bei einem IntElement)
    /**check if the config type fits to the element type
      @param confType
      @param elementType
      @return PVSS_TRUE when the config type fits the element type, PVSS_FALSE otherwise
    */
    static PVSSboolean checkConfigType(DpConfigType confType, DpElementType elementType);

    /**return variable type for given element type
      @param elType
      @return the corresponding VariableType, if elType doesn't match NOTYPE_VAR is returned
    */
    static VariableType getVariableType(DpElementType elType);

    /** add DpConfig of this type if not already existent.
     @param confType
     @return 0 when confType already exists, otherwise a pointer to the new config
     */
    DpConfigPtr insertConfig(DpConfigType confType);

    /** Add a copy (deep copy) of this config
     @param newConfig DpConfig&
     @return 0 when confType already exists, otherwise a pointer to the new config
     */
    DpConfigPtr insertConfig(const DpConfig &newConfig);

    /** add the given DpConfig. Now we are responsible for the given DpConfig -> do NOT delete it
     @param newConfig DpConfigPtr
     @return 0 when confType already exists, otherwise a pointer to the new config
     */
    DpConfigPtr insertConfig(DpConfigPtr newConfig);

    /** Add DpConfig of this type but test if this is allowed for the given element type
     @param type DpElementType
     @param confType DpConfigType
     @return 0 when confType is not allowed, otherwise a pointer to the new config
     */
    DpConfigPtr insertConfig(DpElementType type, DpConfigType confType);

    /** Add acopy (deep copy) of this DpConfig but test if this is allowed
     @param type
     @param newConfig DpConfigPtr
     @return 0 when confType is not allowed, otherwise a pointer to the new config
     */
    DpConfigPtr insertConfig(DpElementType type, const DpConfig &newConfig);

    /**Add the given DpConfig. Now we are responsible for the given DpConfig -> not NOT delete it
     test if this config is allowed
     @param type
     @param newConfig DpConfigPtr
     @return 0 when newConfig is not allowed, otherwise a pointer to the new config
     */
    DpConfigPtr insertConfig(DpElementType type, DpConfigPtr newConfig);

    /**Returns a pointer to the requested config or 0 if not existent, slow version, complexity O(n)
     @param confType
     @return the requested pointer or 0 if not found
     */
    DpConfigPtr getConfig(DpConfigType confType) const;      // slow

    /**Returns a pointer to the requested config or 0 if not existent, fast version, complexity O(1)
     @param confNrType
     @return the requested pointer or 0 if not found
     */
    DpConfigPtr getConfig(DpConfigNrType confNrType) const;  // fast!

    /** Deletes all configs of the given type number
      @param confNrType DpConfigNrType type number of the config
      @return PVSS_FALSE if the config was not found
    */
    PVSSboolean deleteConfig(DpConfigNrType confNrType);

    /** Deletes all configs of the given type
      @param confType DpConfigNrType type of the config
      @return PVSS_FALSE if the config was not found
    */
    PVSSboolean deleteConfig(DpConfigType confType);

    /// delete all configs
    void deleteConfig();
    
    /** cut out a config.
      @param confNrType
      @return DpConfigPtr, the caller is responsible for it
      */
    DpConfigPtr  cutConfig(DpConfigNrType confNrType);

    // Liefert den Typ des Elements, wenn der richtige DpType (bzw. DpTypeNode)
    // uebergeben wird. Funktion mit DpTypeNode ist schneller!
    /** Returns Type of the element, slow version, complexity O(n)
      @param theDpType DpType
      @return DpElementType
      */
    DpElementType getType(const DpType *theDpType) const
      { return getType(theDpType->getTypeNodePtr(id)); }
    /** Returns Type of the element, fast version, complexity O(1)
      @param theDpTypeNode DpTypeNode
      @return DpElementType
      */
    DpElementType getType(const DpTypeNode *theDpTypeNode) const
      { return theDpTypeNode->getElementType(); }

    /**returns type node of the type
      @param theType DpType
      @return DpTypeNode
      */
    const DpTypeNode *getDpTypeNode(const DpType *theType) const { return theType->getTypeNodePtr(id); }

    ///get element id
    DpElementId getId() const     { return id; }

    /** set element id
      @param newId DpElementId
      */
    void setId(DpElementId newId) { id = newId; }

    /// return overall number of instances of this class
    static unsigned int getNumOfInstances() { return numOfInstances; }

  protected:

  private:
    static const int CONFIG_NR_IDX[];
    static unsigned int numOfInstances;  // for statistical reason

    DpElementId id; // ElementId entspricht der Id im DpType!

    short items;             // number of currently allocated pointers in dpConfigArr
    DpConfig** dpConfigArr;  // pointer to array of Config pointers

    /** check if we have space in the pointer-array to be able to store the
     given config type. If not, resize the pointer-array
     @param configNr DpConfigNrType
     */
    void resize(DpConfigNrType configNr);

    /**copy ctor
      @param src
      */
    DpElement(const DpElement &src) {} // COVINFO LINE: defensive (copy c'tor defined private so no one can use it)
    /**= operator
      @param src
      */
    DpElement & operator=(const DpElement &src) {return *this;} // COVINFO LINE: defensive (assignemnt operator defined private so no one can use it)
    
};

// ================================================================================

inline DpConfigPtr DpElement::getConfig(DpConfigType confType) const
{
  for (short i = 0; i < items; i++)
    if ( dpConfigArr[i] && (dpConfigArr[i]->isA(confType) == confType) )
      return dpConfigArr[i];

  return 0;

  /*  does not work because of DPCONFIG_CONFIG and maybe something else ...
  // convert confType to the corresponding DpConfigNr and see if we have it
  return getConfig(DpConfig::getConfigNrType(confType));
  */
}

// --------------------------------------------------------------------------------

inline DpConfigPtr DpElement::getConfig(DpConfigNrType confNr) const
{
  // if this is a config number which is not possible or
  // we do not have this config in our array (either the array has not been extended
  // to handle it or the pointer to the config is 0), we return 0
  return ((CONFIG_NR_IDX[confNr] == -1) || (CONFIG_NR_IDX[confNr] >= items))
          ? 0 : dpConfigArr[CONFIG_NR_IDX[confNr]];
}


// --------------------------------------------------------------------------------

#endif /* _DPELEMENT_H_ */
