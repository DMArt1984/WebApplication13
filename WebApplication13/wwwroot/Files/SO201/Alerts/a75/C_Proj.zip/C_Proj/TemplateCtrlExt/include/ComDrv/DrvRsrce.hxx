#pragma once

#include <DrvResources.hxx>

IL_DEPRECATED("deprecated, DrvRsrce renamed to DrvResources")
typedef DrvResources DrvRsrce;