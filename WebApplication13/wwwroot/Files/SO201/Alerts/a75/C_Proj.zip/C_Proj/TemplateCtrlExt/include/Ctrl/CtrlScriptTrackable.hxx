#ifndef _CtrlScriptTrackable_H_
#define _CtrlScriptTrackable_H_

// Qt trackable object (for QPointer<CtrlScriptTrackable>)
// which is not needed by customer API
// @classification ETM internal

#include <QObject>
class CtrlScript;

class CtrlScriptTrackable : public QObject
{
  public:
    CtrlScriptTrackable(CtrlScript *s) : script(s) { }
    CtrlScript *script;
};

#endif
