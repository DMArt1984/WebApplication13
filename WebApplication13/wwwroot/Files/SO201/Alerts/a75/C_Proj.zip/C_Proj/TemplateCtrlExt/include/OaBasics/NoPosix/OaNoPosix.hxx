//----------------------------------------------------------------------------
//  Copyright (C) Siemens AG 2018. All Rights Reserved.
//----------------------------------------------------------------------------

#pragma once

#include <NoPosix.hxx>
#include <NetUtil.hxx>
#include <fstream>
#include <vector>
#include <stdio.h>

/** the non-POSIX wrapper. this class covers all the non-posix system calls used by WinCC OA.
    whenever using system calls try to use these members to maintain platform compatibility.
*/
namespace OaNoPosix
{
  // network-related functions moved to NetUtil namespace
  using namespace NetUtil;

  // some functions are defined in IOWA NoPosix namespace
  using namespace NoPosix;

  /// lock a file by the given file descriptor
  DLLEXP_OABASICS int lockFile(int fildes);

  /// unlock a file by the given file descriptor
  DLLEXP_OABASICS int unlockFile(int fildes);

  // don't use - they are NOPs as we have no access to their file descriptors
  /// lock a file by the given stream - should not be used
  IL_DEPRECATED("obsolete, don't use")
  DLLEXP_BASICS inline int lockFile(const std::ofstream &ofs) { return 0; }
  
  /// unlock a file by the given stream - should not be used
  IL_DEPRECATED("obsolete, don't use")
  DLLEXP_BASICS inline int unlockFile(const std::ofstream &ofs) { return 0; }

  /** play a simple beep with the given frequency [Hz] and the duration [milli seconds]
      No soundcard is needed. The beep is played with the internal speaker
  */
  DLLEXP_OABASICS void beep(long frequency, long duration);

  /** play a sound file
      @param fileName ... filename including absolute path to the .wav file
      @param loop ... set this to true, if the soundfile shall be played in an endless loop
      @return 0 if everything worked, -1 on error
  */
  DLLEXP_OABASICS int startSound(const char *fileName, bool loop = false);

  /** stop the sound currently being played
      @return 0 if everything worked, -1 on error
  */
  DLLEXP_OABASICS int stopSound();
  
  /** replace access standard function with method that treats encoding
      @param fname filename in project encoding
      @param access mode as used for ::access() (::_waccess() under Windows)
      @return return value from ::access() (::_waccess() under Windows) function
  */
  DLLEXP_OABASICS int access(const char *fname, int accessMode);

  /** replace fopen standard function with method that treats encoding
      @param fname filename in project encoding
      @param openMode as used for std::fopen
      @return NULL on error, file pointer on success
  */
  DLLEXP_OABASICS FILE* fopen(const char *fname, const char *openMode);

  /** replace std::ifstream::open standard function with method that treats encoding of filename
      @param ifstream stream object reference
      @param fname filename in project encoding
      @param openMode as used for std::open
  */
  DLLEXP_OABASICS void open(std::ifstream &stream, const char *filename, std::ios_base::openmode mode = std::ios_base::in);

  /** replace std::ofstream::open standard function with method that treats encoding of filename
      @param ofstream stream object
      @param fname filename in project encoding
      @param openMode as used for std::open
  */
  DLLEXP_OABASICS void open(std::ofstream &stream, const char *filename, std::ios_base::openmode mode = std::ios_base::out);

  /** replace std::ofstream::open standard function with method that treats encoding of filename
      @param ofstream stream object
      @param fname filename in project encoding
      @param openMode as used for std::open
  */
  DLLEXP_OABASICS int stat(const char *filename, struct ::stat* statBuf);


  /**
  * platform independent abstraction for strcpy_s()
  *
  * @param dest the target buffer
  * @param destsize the maximum number of bytes to write into the target buffer
  *                 (including terminating null), i.e. target buffer size
  * @param src the source string to copy from
  */
  DLLEXP_OABASICS void strcpy(char *dest, size_t destsize, const char *src);

  /*
  * platform independent abstraction for strncpy_s()
  *
  * @param dest the target buffer
  * @param destsize the maximum number of bytes to write into the target buffer
  *                 (including terminating null), i.e. target buffer size
  * @param src the source string to copy from
  * @param count the maximum number of bytes to copy from the source string
  */
  DLLEXP_OABASICS void strncpy(char *dest, size_t destsize, const char *src, size_t count);

  /**
  * platform independent abstraction for memcpy_s()
  *
  * @param dest the target buffer
  * @param destsize the length of the target buffer
  * @param src the source buffer to copy from
  * @param copySize the maximum number of bytes to write into dest
  */
  DLLEXP_OABASICS void memcpy(void *dest, size_t destSize, const void *src, size_t copySize);

  /**
  * platform independent abstraction for memmove()
  *
  * @param dest the target buffer
  * @param destsize the length of the target buffer
  * @param src the source buffer to copy from
  * @param copySize the maximum number of bytes to write into dest
  */
  DLLEXP_OABASICS void memmove(void *dest, size_t destSize, const void *src, size_t copySize);
}  //namespace OaNoPosix

