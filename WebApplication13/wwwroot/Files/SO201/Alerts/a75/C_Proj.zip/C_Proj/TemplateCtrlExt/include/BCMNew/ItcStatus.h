//
//  $RCSfile$
//  $Date$
//  $Revision$
//  $Author$
//  $Locker$
//  $State$
//  $Source$
//
// %Z%JESSI-COMMON-FRAMEWORK 2.0
// %Z%Copyright (C) by Siemens Nixdorf Informationssysteme AG 1992
// %Z%Copyright (C) by Universitaet GH Paderborn 1992
// %Z%Development of this software was partially funded by ESPRIT project 7364.
// %Z%BCM %M% %I% %E%

#ifndef ItcStatus_H
#define ItcStatus_H

//#ifdef __GNUG__
//#pragma interface
//#endif

// ---------------
//  INCLUDE FILES
// ---------------

#define  USES_errno
#define  USES_stdio
#define  USES_string
#define  USES_sockets
#include "ItcPrelude.h"

#if defined(IS_MSWIN__)
#  define ITC_SYSTEM_ERROR     static_cast<int>(WSAGetLastError())
#else
#  define ITC_SYSTEM_ERROR     errno
#endif

// ---------------
//  GLOBAL MACROS
// ---------------

#define  ITC_LOG_ERROR             STATUS_log()
#define  ITC_LOG_SYSTEM_ERROR      STATUS_log()
#define  ITC_SET_LOG(code,type)    STATUS_set(code,type)
#define  ITC_SET_LOG_ERR(code)     STATUS_set(code,itcStatus::ItcError)
#define  ITC_SET_FILE
#define  ITC_SET_FCT(fct_name)


#define  ITC_STATUS_OK  STATUS_set(Itc_Ok,ItcSuccess,0)

// ------------------
//  GLOBAL VARIABLES
// ------------------

/// The one and only Itc_Ok.
const int  Itc_Ok = 0  ;

/// There is a maximum of N status values per module (e.g. Transport)
const int  Itc_Max_Status_Table_Size = 100;


/** Status class.
    itcStatus is the base class of all Itc classes and holds the status of the Itc object.
*/
class  DLLEXP_BCM itcStatus
{
  friend class  itcStatusLog;

public:
  /// Status type.
  enum  StatusType {
    /// Everything is fine.
    ItcSuccess,
    /// Warning when calling fct. on object, program probably can continue after checking error code.
    ItcWarning,
    /// Error when calling fct. on object, check for error code, action probably can not continue.
    ItcError,
    /// A system call has caused an error, check for error code if program should continue.
    ItcSystemError,
    /// Fatal error when calling fct. on object, program should NOT continue.
    ItcFatalError   
  };

private:
  int         code;
  StatusType  type;
  int         errorno;

public:
  /// Constructor.
  itcStatus()
  { 
    code = Itc_Ok; 
    type = ItcSuccess;
    errorno = 0;
  }

  /** Set status.
      @param code_ Itc Error code.
      @param type_ Type of the error. For more information about the possible values see StatusType enumeration.
      @param errorno_ Error number. By default, it equals to GetLastError() on Windows and errno on UNIX systems.
  */
  void  STATUS_set(
    int         code_,
    StatusType  type_,
    int         errorno_ = ITC_SYSTEM_ERROR)
  {
    this->code = code_;
    this->type = type_;
    this->errorno = errorno_;
  }  

  /// Clear the status.
  void  STATUS_clear( )
  {
    this->code = Itc_Ok; 
    this->type = ItcSuccess;
    this->errorno = 0;
  }

  /** Write the status into the log.
  Dummy function if logging is disabled.
  */
  void  STATUS_log( ) {}

  /** Conversion to void*
      @return The object pointer if the status of the object is ItcSuccess. Otherwise it returns NULL.
      */      
  operator void*() const
  {
    // return STATUS_ok() ? (void*)this : (void*)0;
    return (type < ItcWarning) ? (void*)this : (void*)0;
  }

  /** Logical NOT operator.
      @return true if there was an error in the object. Otherwise it returns false.
      */
  int operator!() const
  {
    // return STATUS_fail();
    return (type >= ItcWarning);
  }

  // -----------------------------------------------------------------------

  /// Checks if the status is OK.
  int         STATUS_ok()           const { return type <  ItcWarning; }
  /// Checks if the status is failed.
  int         STATUS_fail()         const { return type >= ItcWarning; }

  /// Checks if the status is ItcSuccess.
  int         STATUS_success()      const { return type == ItcSuccess; }
  /// Checks if the status is ItcWarning.
  int         STATUS_warning()      const { return type == ItcWarning; }
  /// Checks if the status is ItcSuccess.
  int         STATUS_error()        const { return type == ItcError; }
  /// Checks if the status is ItcFatalError.
  int         STATUS_fatal_error()  const { return type == ItcFatalError; }

  /// Returns the type of the status.
  StatusType  STATUS_type()         const { return type; }
  /// Returns the code of the status.
  int         STATUS_code()         const { return code; }
  /// Returns the errorno of the status.
  int         STATUS_errorno()      const { return errorno; }
};

#endif /*ItcStatus_H */

