// DATEIBESCHREIBUNG ==============================================================
// DATEINAME:     InitItcIOHandler.hxx
// VERANTWORTUNG : Gerhard Fellrieser
// BESCHREIBUNG : Hilfsklasse um Manageridentifier von Client zu lesen.
//
// AENDERUNGS-HISTORIE
// Ver.  | Datum      | Aenderungen                            | ModNr.| Autor
// ------+------------+-----------------Anfang-----------------+-------+-----------
//   1.0 |            | 1.Erstellung mit Westmount-OMT         |     0 |
// ======================================Ende======================================
#ifndef _INITITCIOHANDLER_H_
#define _INITITCIOHANDLER_H_

// Vorwaerts-Deklaration der Eigenen Klasse
class InitItcIOHandler;

// System-Include-Files
#include <Types.hxx>

// BCM include
#include <PVSSBcm.hxx>

class MsgItcDispatcher;


// Vorwaerts-Deklarationen :
class itcConnection;

// ========== InitItcIOHandler ============================================================
class DLLEXP_MANAGER InitItcIOHandler : public itcIOHandler 
{
  friend class UNIT_TEST_FRIEND_CLASS;
   
  public:
    // Konstruktor
    InitItcIOHandler(itcConnection *);
    // Destruktor
    ~InitItcIOHandler();

    // Spezielle Methoden :
    virtual int inputReady(itcConnection *conn, char *data);

    // Ablauf des Connect timers
    virtual void timerExpired(long sec, long usec) override;

  private:
    int inputReady(itcConnection *conn, itcNdrUbReceive &recv);

  private:
    itcNdrUbReceive receiver;
    itcNdrUbSend    sender;
    itcConnection  *connectPtr;
  };

#endif /* _INITITCIOHANDLER_H_ */
