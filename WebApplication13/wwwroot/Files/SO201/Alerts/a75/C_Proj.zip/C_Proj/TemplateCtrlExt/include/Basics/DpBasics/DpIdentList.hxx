#ifndef _DPIDENTLIST_H_
#define _DPIDENTLIST_H_

/*
VERANTWORTUNG: Martin Koller
BESCHREIBUNG: List of DpIdentifiers
*/

#ifndef _PTRLIST_H_
#include <PtrList.hxx>
#endif

#ifndef _DPIDENTLISTITEM_H_
#include <DpIdentListItem.hxx>
#endif

#ifndef _DPIDENTIFIER_H_
#include <DpIdentifier.hxx>
#endif

class DpIdValueList;

/** A list of dp identifiers. The DpIentifiers are stored in a pointer list and may 
    accessed sequentially only, starting with the first.
*/
class DLLEXP_BASICS DpIdentList
{
  public:
    /// Constructor
    DpIdentList() {}

    /// Copy constructor, makes deep copy
    DpIdentList(const DpIdentList &theList);

    /// Append a new dp identifier to the list
    void append(const DpIdentifier &dpId) { list.append(new DpIdentListItem(dpId)); }

    /// Append a new dp identifier to the list. The pointer is grabbed.
    void append(DpIdentListItem *ptr) { list.append(ptr); }

    /** Compare two identifier lists.
        The number of DpIdentifiers in both lists must match and every DpIdentifier is compared with
        the corresponding one according to compareKey.
        @return PVSS_TRUE if both list are identical, PVSS_FALSE else.
    */
# if 0
    // DOC++ Deklaration fuer dpCompFlags
    PVSSboolean isEqual(const DpIdentList &theList,
                        DpIdentifier::dpCompFlags compareKey = DpIdentifier::compAll) const;
# endif
    PVSSboolean isEqual(const DpIdentList &theList,
                        PVSSushort compareKey = DpIdentifier::compAll) const;

    /** Compare the identifier lists with a DpIdValueList.
        The DpIdValueList is like a DpIdentList, but instead of DpIdentifiers pairs of DpIdentifier
        and their value are stored.
        The number of DpIdentifiers in both lists must match and every DpIdentifier is compared with
        the corresponding one according to compareKey.
        @return PVSS_TRUE if both list are identical, PVSS_FALSE else.
    */
# if 0
    // DOC++ Deklaration fuer dpCompFlags
    PVSSboolean isEqual(const DpIdValueList &theList,
                        DpIdentifier::dpCompFlags compareKey = DpIdentifier::compAll) const;
# endif
    PVSSboolean isEqual(const DpIdValueList &theList,
                        PVSSushort compareKey = DpIdentifier::compAll) const;

    /// Copy assignment operator, makes deep copy
    DpIdentList &operator=(const DpIdentList &rVal);

    /// Comparison operator
    int operator==(const DpIdentList &theList) const;
    /// Comparison operator
    int operator!=(const DpIdentList &theList) const { return ! (*this == theList); }
    /// Access operator. Not very performant for long lists
    const DpIdentifier * operator[](unsigned idx) const;

    /// Get the number of items in the list
    unsigned int getNumberOfItems() const { return list.getNumberOfItems(); }

    /** Access the first DpIdentifier in the list.
        @return A pointer to the first DpIdentifer or 0 if the list is empty
        @param  lastAcc  An opaque pointer to the last accessed list item. 
                Use this pointer to access the following DpIdentifier later.
    */
    const DpIdentifier *getFirst(DpIdentListItem * &lastAcc) const
    { return ( (lastAcc = (DpIdentListItem*)(list.getFirst())) ? &(lastAcc->getDp()) : 0 ); }
    
    /** Access first DpIdentifier in the list
        @return A pointer to the first DpIdentifier or 0, if the list is empty
    */
    const DpIdentifier *getFirst() const;
    
    /** Cut the first item from the list. 
        You are responsible to delete the pointer. You may access the DpIdentifier
        via itemPtr->getDp().
        @return A pointer to the first DpIdentifier or 0, if the list is empty
    */
    DpIdentListItem *cutFirst() {return (DpIdentListItem *) list.cutFirst();}
    

    /** Access the next DpIdentifier in the list.
        @return A pointer to the next DpIdentifier or 0 if there are no more items.
        @param  lastAcc  An opaque pointer to the last accessed list item. 
                Use this pointer to access the following DpIdentifier later.
    */
    const DpIdentifier *getNext(DpIdentListItem * &lastAcc) const
    { return ( (lastAcc = (DpIdentListItem*)(list.getNext(lastAcc))) ? &(lastAcc->getDp()) : 0 ); }

    /** Access next DpIdentifier in the list
        @return A pointer to the next DpIdentifier or 0, if there are no more items
    */
    const DpIdentifier *getNext() const;

    /// Get the last accessed element again
    const DpIdentifier *getLastAccessed() const;
      
   /// Check if the given identifier is in the list
    PVSSboolean inList(const DpIdentifier &dpId) const;
    /// Clear the list, all identifiers are discarded
    void clear() {list.clear();}
    /// Check for dpId and remove it from the list if found. Returns PVSS_TRUE if the item was found.
    PVSSboolean delDpId(const DpIdentifier &dpId);

    /// Removes the item at the current position, and jumps to the next item.
    void removeCurrent();
    
    /// reverts the list order (needed by EvDpManager)
    void reverseOrder();

  private:
    PtrList list;
};


// ------------------------------------------------------------------------------------------
// Inline-Funtionen
inline const DpIdentifier * DpIdentList::operator[](unsigned idx) const
{
  DpIdentListItem *itemPtr = (DpIdentListItem *) list[idx];
  return (itemPtr ? &(itemPtr->getDp()) : 0);
}


inline const DpIdentifier * DpIdentList::getFirst() const
{
  DpIdentListItem *itemPtr = (DpIdentListItem *) list.getFirst();
  return (itemPtr ? &(itemPtr->getDp()) : 0);
}


inline const DpIdentifier * DpIdentList::getNext() const
{
  DpIdentListItem *itemPtr = (DpIdentListItem *) list.getNext();
  return (itemPtr ? &(itemPtr->getDp()) : 0);
}


inline void DpIdentList::removeCurrent()
{
  if (list.getLastAccessed())
  {
    list.remove(list.getLastAccessed());
  }
}


inline const DpIdentifier *DpIdentList::getLastAccessed() const
{
  if (list.getLastAccessed())
  {
    const DpIdentListItem *item = static_cast<const DpIdentListItem *>(list.getLastAccessed());
    return &(item->getDp());
  }

  return 0;
}

#endif /* _DPIDENTLIST_H_ */
