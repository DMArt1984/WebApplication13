#ifndef _DOSMENT_H_
#define _DOSMENT_H_

#include <LoopSment.hxx>
#include <CtrlSmentList.hxx>

class CtrlExpr;

/*  author VERANTWORTUNG: Mark Probst   */
/** the do-while statement */
class DLLEXP_CTRL DoSment : public LoopSment
{
  public:
    /// wird vom YACC auf gerufen
    DoSment(int line, int filenum) : LoopSment(line, filenum) {}

    /** Beim Parsen: Expression der Schleife die nach jedem Durchlauf getestet wird.
      * @param theExpr IN: wird von ~DoSment frei gegeben.
      */
    void setExpr (CtrlExpr *theExpr) { expr = theExpr; }
    /** Legt einen Block am Stack an und returns CtrlSmentList der Schleife.
      */
    virtual const CtrlSment *execute (CtrlThread *thread) const;

    // Liefert die erste Expression. Ein Dummy, das nur initialisiert
    virtual const CtrlExpr * getFirstExpr(CtrlThread *) const;

    // Liefert die Bedingung, die bei vor einer Wiederholung ausgefuehrt werden soll
    virtual const CtrlExpr * getIterationExpr(CtrlThread *) const;

    /// Gewichtung des CtrlSment
    virtual SmentWeight getWeight() const { return SM_WT_Low; }

    virtual void writeTrace(CtrlThread *thread, bool writeValue = true) const;

    virtual bool checkIntegrity(const CharString &location, CtrlThread *) const;

    /** dump the whole tree for code coverage analysis
        @param to output stream
      */
    virtual void dumpCoverageTree(std::ostream &to, CoverageAction action = DUMP) const;
};

#endif // _DOSMENT_H_

