#pragma once

#include <OaFileSys.hxx>

IL_DEPRECATED("deprecated, PVSSFileSys renamed to OaFileSys")
typedef OaFileSys PVSSFileSys;