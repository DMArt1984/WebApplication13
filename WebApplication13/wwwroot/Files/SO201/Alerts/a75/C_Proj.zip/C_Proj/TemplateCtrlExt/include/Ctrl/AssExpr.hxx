#ifndef _ASSEXPR_H_
#define _ASSEXPR_H_

#include <CtrlExpr.hxx>


/*  author VERANTWORTUNG: Martin Koller  */
/** assignment expression
    @classification ETM internal
 */
class DLLEXP_CTRL AssExpr : public CtrlExpr
{
  public:
    /// Returns the type of the Expression
    virtual ExprType isA() const { return ASS_EXPR; }

    /// Zuweisungsoperatoren
    enum OpType
    {
      /// =
      ASSIGN,
      /// *=
      MULT_ASS,
      /// /=
      DIV_ASS,
      /// %=
      MOD_ASS,
      /// +=
      PLUS_ASS,
      /// -=
      MINUS_ASS,
      /// &=
      AND_ASS,
      /// |=
      OR_ASS,
      /// ^=
      XOR_ASS,
      /// <<=
      LS_ASS,
      /// >>=
      RS_ASS,
      /// int i = sin(180)
      INIT,
      /// init of class instance member
      MEMBER_INIT
    };

    /** Constructor: Wird beim Parsen aufgerufen.
      * @param  t Ausdruck dem das Ergebnis von e Zugewiesen wird
      * @param op Zuweisungsoperator @see OpType
      * @param  e Ausdruck der ausgewertet und an t zugewiesen wird
      * @param line     In welcher Zeile des Sourcefiles steht diese Zuweisung?
      * @param filenum  Wenn es ein Library-File war die Nr. der Library
                        Damit kann der Name ermittelt werden.
    */
    AssExpr(CtrlExpr *t, OpType op, CtrlExpr *e, int line, int filenum);

    /// Destructor
    virtual ~AssExpr();

    /** Load the result of a former execute. The value is not taken from the target
        (the target might have been changed in the meantime) but from a hidden variable)
      */
    virtual const Variable *evaluate(CtrlThread *thread) const;

    /// Execute the statement and stores the result in a hidden variable for evalute
    virtual const CtrlSment * execute(CtrlThread *thread) const;

    /// Returns the assignment target
    virtual const CtrlExpr *getFirstExpr(CtrlThread *) const;

    /// Gewichtung des CtrlSment
    virtual SmentWeight getWeight() const { return SM_WT_Low; }

    /// OpType of the expression
    OpType getOpType() const {return opType;}

    /// Returns the expr to evaluate
    CtrlExpr *getExpr() const { return expr; }

    CtrlExpr *cutExpr() { CtrlExpr *exp = expr; expr = nullptr; return exp; }

    virtual void writeTrace(CtrlThread *thread, bool writeValue = true) const;

    virtual bool checkIntegrity(const CharString &location, CtrlThread *) const;

    virtual void dumpCoverageTree(std::ostream &to, CoverageAction action = DUMP) const;

  private:
    // Fuehrt die eigentliche Zuweisung aus.
    const Variable * eval(CtrlThread *) const;

    static const char *opTypeToName(OpType opType);

    /// Ausdruck dem das Ergebnis von expr Zugewiesen wird
    CtrlExpr *target;

    /// Zuweisungsoperator
    OpType opType;

    /// Ausdruck der ausgewertet und an target zugewiesen wird
    CtrlExpr *expr;
};

#endif /* _ASSEXPR_H_ */
