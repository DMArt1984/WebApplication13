#ifndef _CNSNAMESHEAP_H_
#define _CNSNAMESHEAP_H_

#include <SimplePtrArray.hxx>

// forward declaration
class EmptyRangeSet;


#ifdef WIN32
#pragma warning ( disable: 4231 )
#endif

#if defined(LIBS_AS_DLL)
  EXTERN_DATAPOINT template class DLLEXP_DATAPOINT  SimplePtrArray<char>;
  EXTERN_DATAPOINT template class DLLEXP_DATAPOINT  SimplePtrArray<const char>;
#endif

// size of a single buffer. strings cannot be larger than this.
#define CNS_NAMES_HEAP_SIZE 1024*32

// compact() will be called after <x> invocations of add() or remove()
#define CNS_NAMES_HEAP_COMPACT_INTERVAL 2000

/**
 * A container to store Names and DisplayNames of the CNS nodes.
 * @internal
 */
class DLLEXP_DATAPOINT CNSNamesHeap
{
  public:
    /// string storage of unique strings
    CNSNamesHeap(size_t _bufferSize = CNS_NAMES_HEAP_SIZE);

    ///
    virtual ~CNSNamesHeap();

    /// heap size
    size_t size() const;

    /// replace the string with 0 char
    bool remove(const char *str);

    /// add a string to the string heap
    const char *add(const char *str);

    /** find the occurence of the substring str in all strings of the heap.
     * @param str The substring to find.
     * @param caseSensitive if true care about case.
     * @param res holds a reference to all strings that contain the substring str.
     * @return false on error.
     */
    bool find(const char *str, bool caseSensitive, SimplePtrArray<const char> &res) const;

  private:
    /** find the occurence of the substring str in all strings of the heap.
     * for caseinsensitive search the public find calls this method twice.
     * the first time find(lowercase(str), uppercase(str), res)
     * the second time find(uppecase(str), lowercase(str), res)
     * so all versions of str are found.
     * @param str The substring to find (lower/upper case).
     * @param otherCase if true care about case (the opposite of str).
     * @param res holds a reference to all strings that contain the substring str.
     * @return false on error.
     */
    bool find(const char *str, const char *otherCase, SimplePtrArray<const char> &res) const;

    /// @return true if heapStr[1..n] matches either searchStr[1..n] or otherCase[1..n]
    bool match(const char *heapStr, const char *searchStr, const char *otherCase) const;

    /// merge all adjacent empty ranges
    void compact();

  private:
    size_t bufferSize_;
    SimplePtrArray<char> pool_;
    EmptyRangeSet *emptyRanges_;
    unsigned int compactCount_;
};

//------------------------------------------------------------------------------
//--
//------------------------------------------------------------------------------
inline size_t CNSNamesHeap::size() const
{
  size_t s = sizeof(CNSNamesHeap);
  s += pool_.getNumberOfItems() * sizeof(void *);
  s += bufferSize_ * pool_.getNumberOfItems();

  return(s);
}

#endif // _CNSNAMESHEAP_H_
