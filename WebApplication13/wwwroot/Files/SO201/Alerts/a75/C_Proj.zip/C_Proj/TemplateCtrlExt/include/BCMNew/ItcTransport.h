//
//  $RCSfile$
//  $Locker$
//  $State$
//  $Source$
//
// %Z%JESSI-COMMON-FRAMEWORK 2.0
// %Z%Copyright (C) by Siemens Nixdorf Informationssysteme AG 1992
// %Z%Copyright (C) by Universitaet GH Paderborn 1992
// %Z%Development of this software was partially funded by ESPRIT project 7364.
// %Z%BCM %M% %I% %E%

// This is a -*- C++ -*- file ! 

#ifndef ItcTransport_H
#define ItcTransport_H

//#ifdef __GNUG__
//#pragma interface
//#endif


#define USES_unistd
#define USES_sys_param

#include "ItcPrelude.h"
#include "ItcStatus.h"
#include "ItcTransport.def"

struct iovec;
class itcInetAddress;
class itcUnixAddress;
class itcNdrUbSend;

// no. of retries for connect()
#define BCM_CONNECT_RETRIES 0


// timeout values for OS_select within OpenConnection(), AcceptConnection()
#define BCM_SELECT_TIMEOUT_SEC  90
#define BCM_SELECT_TIMEOUT_USEC 90

const int Bcm_Open_Conn_Normal  = 0;
const int Bcm_Open_Conn_Monitor = 1;
const int Bcm_Open_Conn_Failure = 2;


// forward declaration of nested type to force C++2.1 and C++3.0.1
// compatibility (concerning function names using nested type)
#if (defined(ATT_VERSION__) && (ATT_VERSION__ > 20))
enum ConnOptions {};
enum ConnType {};
enum ConnStatus {};
#endif

class DLLEXP_BCM ICBBcmReady
{
  public:
    ICBBcmReady();
    virtual ~ICBBcmReady();
    virtual void bcmReady(int result, void *params) = 0;
};


/// This class encapsulates the socket library. It represents one connection
/// point in the socket communication and serves as a base class for more
/// specific types of connection.
class DLLEXP_BCM itcConnection : public itcStatus {
public:
  /// Connection options
  enum ConnOptions {ItcBlocking=0, ItcNonBlocking = 1, ItcStrictBlocking = 2};
  
  /// Connection type
  enum ConnType    {ItcNone = 0, ItcActive = 1, ItcPassive = 2};

  /// Connection status
  enum ConnStatus  {ItcNotConn = 0, ItcConnected = 1, ItcBoundToAddr = 3, 
                          ItcListening = 4, ItcConnecting = 5, ItcClosing = 6};
  
  /// Default constructor
  itcConnection();

  /// Constructor
  /// @param opt Connection options
  itcConnection(ConnOptions opt);

  /// Constructor
  /// @param fd Socket descriptor
  /// @param opt Connection options
  itcConnection(int fd, ConnOptions opt);

  /// Constructor
  /// @param fd Socket descriptor
  /// @param typ Connection type
  itcConnection(int fd, ConnType typ);

  /// Destructor
  virtual ~itcConnection();
  
  /// Get the connection status
  /// @return ConnStatus Current connection status
  ConnStatus  getState() const { return state; }

  /// Set the connection status
  /// @param newState New connection status
  void  setState(ConnStatus newState) {state = newState;}
  
  /// Get the connection options
  /// @return ConnOptions Current connection options
  ConnOptions getOption() const { return options; }
  
  /// Get the socket descriptor
  /// @return int Socket descriptor
  int Descriptor() const  { return td; }

  /// Check if the socket is of server type
  /// @return Nonzero if connection type is ItcPassive, zero otherwise
  int isServer() const   { return type == ItcPassive; }

  /// Check if the socket is of client type
  /// @return Nonzero if connection type is ItcActive, zero otherwise  
  int isClient() const   { return type == ItcActive; }

  /// Statistical functions. Clears member variables for counting
  /// transferred bytes and read/write calls.
  void clearStatData() { bytesRead = bytesWritten = 0; readCalls = writeCalls = 0; }

  /// Get the number of bytes read. Only successful I/O is counted.
  /// @return INT64 Number of bytes read
  INT64 getBytesRead() const { return bytesRead; }

  /// Get the number of bytes written. Only successful I/O is counted.
  /// @return INT64 Number of bytes written
  INT64 getBytesWritten() const { return bytesWritten; }

  /// Get number of read calls.
  /// @return INT64 Number of calls.
  INT64 getReadCalls() const { return readCalls; }
  
  /// Get number of write calls.
  /// @return INT64 Number of calls.  
  INT64 getWriteCalls() const { return writeCalls; }
  
  /// Calls ioctl socket method with the FIONREAD parameter
  virtual int Pending();

  /// Reads the data from the socket and stores them in the internal buffer
  /// @return int Returns 0 (base class implementation does nothing)
  virtual int InitRead();

  /// Read the data from the socket
  virtual int Read(void *, int);

  /// Writing data to the socket
  virtual int Write(const void *, int);

  /// Set connection options (using fcntl or ioctl socket methods)
  /// @param opt New connection options to be set
  virtual int SetOption(ConnOptions opt);

  /// Set the socket to the accept state
  /// @return Pointer to the itcConnection class
  virtual int AcceptConnection(itcConnection **newConnection, ICBBcmReady *pcbFunc, void *pcbParams);
  // Wrapper function for compatibility reason
  virtual int AcceptConnection(itcConnection **newConnection) { return AcceptConnection(newConnection, 0, 0); }

  /// Close the connection
  /// @return 1 if success, 0 in case of failure
  virtual int Close();
 
  /// Shutdowns the socket communication
  /// @param how Parameter for the socket shutdown method
  /// @return 1 if success, 0 in case of failure
  virtual int Shutdown(OS_shutdown_mode how);
  // Wrapper function for compatibility reason
  virtual int Shutdown(int how) { return Shutdown(static_cast<OS_shutdown_mode>(how)); }
  
  /// Flush the data (The implementation does nothing and the method
  /// is not implemented in the derived classes)
  /// @return 0 
  virtual int flush();

  /// Flush the data (The implementation does nothing and the method
  /// is not implemented in the derived classes)
  /// @param i Reserved parameter
  /// @return Parameter 'i' passed to the method
  virtual int flush(unsigned int i);

  /// Reset the internal buffer
  /// Note: The implementation does nothing and the derived classes
  /// do not implement it
  virtual void reset();

  /// Empty the internal buffer
  /// Note: The implementation does nothing and the derived classes
  /// do not implement it
  /// @return 0
  virtual int empty();

  /// items method (does nothing and the derived classes do not
  /// implement it)
  /// @return 0
  virtual int items();

  /// bytes method (returns the number of bytes in internal buffers of the itcNetConnection)
  virtual long bytes();
  
  /// get maximum number of allowed concurrent connections.
  /// this is used to avoid exhausting the maximum allowed number of open files.
  /// the default number is OS_availablefds() minus a small reserve.
  static int getMaxConnectionCount() { return maxConns; }

  /// set maximum number of allowed concurrent connections.
  /// the limit can be disabled by setting count <= 0.
  static void setMaxConnectionCount(int count) { maxConns = count; }

  /// get the current number of connections.
  static int getConnectionCount();

protected:
  /// the transport descriptor
  int       td;    
  
  /// registry for options
  ConnOptions   options;

  /// client or server
  ConnType   type;    

  /// connected or not
  ConnStatus   state;   
  
  /// WaitForProtMsg (this method is not implemented)
  /// @param p Pointer to itcConnection
  /// @return int
  int WaitForProtMsg(itcConnection * p);

  /// check if the connection limit has been reached
  static bool hasMaxConnCount()
  {
    return maxConns > 0 && getConnectionCount() >= maxConns;
  }

  static void incConnCount();
  static void decConnCount();

  // Statistical functions (SM 13.10.98)
  /// number of bytes read
  INT64 bytesRead;
  /// number of bytes written
  INT64 bytesWritten;
  /// number of successful read calls
  INT64 readCalls;
  /// number of successful write calls
  INT64 writeCalls;

  /// max number of connections.
  static int maxConns;
  /// current number of connections.
  static int currentConns;

friend class UNIT_TEST_FRIEND_CLASS;
};

/// Derived from itcConnection, this class facilitates the communication
/// using internet protocols. The connection is established between two points
/// by virtual methods OpenConnection and CreateEndpoint, while the connection
/// is represented by the itcInetAddress class. 
class DLLEXP_BCM itcNetConnection : public itcConnection {
public:

  /// Default constructor
  itcNetConnection() {}

  /// Constructor
  /// @param opt Connection options
  itcNetConnection(ConnOptions opt) : itcConnection(opt) {}

  /// Constructor
  /// @param fd Socket descriptor
  /// @param type Connection type
  itcNetConnection(int fd, itcConnection::ConnType conntype) : itcConnection(fd, conntype) {}

  /// Destructor
  virtual ~itcNetConnection();

  /// Open the connection (pure virtual method). The derived class should
  /// create a socket and establish a connection to the specified address.
  /// @param ia Address to which the connection should be established
  /// @return Success code
  virtual int OpenConnection(itcInetAddress &ia, ICBBcmReady *pcbFunc, void *pcbParams) = 0;

  /// Create endpoint (pure virtual method). The derived class should
  /// create a socket, bind it to and address and listen for an incoming
  /// connection.
  /// @param ua Address to assign to the bound socket.
  /// @return Success code
  virtual int CreateEndpoint(itcInetAddress &ua) = 0;

  /// Sets the nodelay option for the current connection to on or off
  /// if an nonblocking connect is performed, this function fails if called
  /// before the connection is established 
  /// @param on Nodelay option
  /// @return Return value of the setsockopt method setting the option
  virtual bool setTcpNodelay(bool on);

  /// Get the name of the used ciphersuite
  /// @return ciphersuite's name 
  virtual const char *getCipherSuite() { return("none"); };

};

/// This class is an implementation of the itcNetConnection abstract class,
/// it facilitates the communication between two internet addresses using
/// sockets.
class DLLEXP_BCM itcInetSockStream : public itcNetConnection {
public:

  /// Constructor
  itcInetSockStream();

  /// Constructor
  /// @param opt Connection options
  itcInetSockStream(ConnOptions opt);

  /// Constructor
  /// @param ia Address to be bound to this socket
  itcInetSockStream(itcInetAddress &ia);

  /// Constructor
  /// @param fd Socket descriptor
  /// @param type Connection type
  itcInetSockStream(int fd, itcConnection::ConnType type) : itcNetConnection (fd,type), connTimo(0) {}

  /// Destructor
  virtual ~itcInetSockStream();

  /// Open the connection
  /// @param ia Address to which the connection should be established   
  /// @return 1 if successful, other value otherwise
  virtual int OpenConnection(itcInetAddress &ia, ICBBcmReady *pcbFunc, void *pcbParams);

  /// Create the endpoint
  /// @param ia Address to assign to the bound socket.
  /// @return 1 if successful, 0 if failure
  virtual int CreateEndpoint(itcInetAddress &ia);

  /// Accept the connection
  /// @return Pointer to the itcConnection
  virtual int AcceptConnection(itcConnection **newConnection, ICBBcmReady *pcbFunc, void *pcbParams);

  /// Get the peername (calls the getpeername socket method)
  /// @param ia Receives the address of the peer
  /// @return 1 if successful, 0 if failure
  int GetPeername(itcInetAddress &ia);

  /// Get the sockname (calls the getsockname socket method)
  /// @param ia Receives the socket name
  /// @return 1 if successful, 0 if failure
  int GetSockname(itcInetAddress &ia);
  
  /// Opens the connection
  /// @param ia Address to which the connection should be established   
  /// @return 1 if successful, other value if failure
  int OpenConnNormal(itcInetAddress &ia);
  
  /// Set connection timeout
  /// @param timo Connection timeout in milliseconds
  void setConnTimeout(unsigned int timo); 

  /// Sets the lingering option for the current connection to on or off
  /// @param on Lingering option
  /// @return Return value of the setsockopt method setting the option
  bool setLingering(bool on);

protected:
  /// connection timeout
  unsigned int connTimo;
  
  /// flag for connection timeout
  static int intrFlag;  

private:
  /// calls the connect method from the socket library
  int OpenConn(itcInetAddress &);
  
  /// sets intrFlag to 1
  static void alrmSigHdl(int);

friend class UNIT_TEST_FRIEND_CLASS;
};

/// This class is an implementation of the itcNetConnection abstract class,
/// it facilitates the communication between two internet addresses using
/// datagrams.
class DLLEXP_BCM itcInetSockDgram : public itcNetConnection {
public:

  /// Default constructor
  itcInetSockDgram();

  /// Constructor
  itcInetSockDgram(itcInetAddress &);

  /// Constructor
  /// @param fd Socket descriptor
  /// @param type Connection type
  itcInetSockDgram(int fd, itcConnection::ConnType type) : itcNetConnection (fd,type) {}

  /// Destructor
  virtual ~itcInetSockDgram();

  /// Open connection
  /// @param ia Address to which the connection should be established 
  /// @return 1 if successful, other value otherwise
  virtual int OpenConnection(itcInetAddress &ia, ICBBcmReady *pcbFunc, void *pcbParams);

  /// Create the endpoint
  /// @param ia Address to assign to the bound socket.
  /// @return 1 if successful, 0 if failure
  virtual int CreateEndpoint(itcInetAddress &ia);

  /// Get the peername (calls the getpeername socket method)
  /// @param ia Receives the address of the peer
  /// @return 1 if successful, 0 if failure
  int GetPeername(itcInetAddress &ia);

  /// Get the sockname (calls the getsockname socket method)
  /// @param ia Receives the socket name
  /// @return 1 if successful, 0 if failure
  int GetSockname(itcInetAddress &ia);

  /// Init read - calls the recvfrom socket function (receives a datagram
  /// and stores the source address). The data is stored in the member
  /// variable buffer
  /// @return -1 on error, positive value if success
  virtual int InitRead();

  /// Copy the data from the member variable buffer to the location specified
  /// in the first parameter. (see InitRead() for more info).
  /// @param buf Pointer to the buffer where the read data will be copied.
  /// @param mlen Length of the local buffer
  /// @return Number of bytes copied
  virtual int Read(void *buf, int mlen);

  /// Sets the nodelay option for the current connection to on or off
  /// @param on Nodelay option
  /// @return Return value of the setsockopt method setting the option
  virtual bool setTcpNodelay(bool on);

private:

  /// internal buffer for storing datagram (see method InitRead()).
  char *buffer;

  /// number of bytes loaded into the buffer
  int  buflen;

  /// socket address
  struct sockaddr_storage from;

friend class UNIT_TEST_FRIEND_CLASS;
};

#endif /* ItcTransport_H */
