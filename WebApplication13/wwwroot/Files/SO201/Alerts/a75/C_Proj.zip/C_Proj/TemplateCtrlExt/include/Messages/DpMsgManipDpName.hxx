#ifndef _DPMSGMANIPDPNAME_H_
#define _DPMSGMANIPDPNAME_H_

#include <DpMsg.hxx>


class DLLEXP_MESSAGES DpMsgManipDpName : public DpMsg
{
  /// Write the instance into the itcNdrUbSend stream.
  friend DLLEXP_MESSAGES itcNdrUbSend &operator<<(itcNdrUbSend &ndrStream, const DpMsgManipDpName &msg);
  /// Read the instance from the itcNdrUbReceive stream.
  friend DLLEXP_MESSAGES itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream, DpMsgManipDpName &msg);


  public:
    /** Constructor to rname a datapoint.
    @param dpId A DpIdentifier that must contain the datapoint type and shall contain the system id.
    @param name The new datapoint name.
    @param req If PVSS_TRUE construct a request message (DP_MSG_DPNAME_REQ), else construct a notification message.
    */
    DpMsgManipDpName(const DpIdentifier &dpId, const CharString &name, PVSSboolean req = PVSS_TRUE);

    /// The copy constructor.
    DpMsgManipDpName(const DpMsgManipDpName &newMsg) { *this = newMsg; }

    /** The default constructor.
    This constructs an empty request message (DP_MSG_DPNAME_REQ) to delete a datapoint.
    */
    DpMsgManipDpName();

    /// Destructor.
    ~DpMsgManipDpName();


    // Operatoren :
    /// Comparison operator.
    int operator==(const DpMsgManipDpName &rVal) const;
    /// Comparison operator.
    virtual int operator==(const Msg &rVal) const;
    /// Assignment operator.
    DpMsgManipDpName &operator=(const DpMsgManipDpName &rVal);
    /// Assignment operator.
    virtual Msg &operator=(const Msg &rVal);

    /// Get own type.
    MsgType isA() const { return type; }
    /// Check if own type matches other type.
    MsgType isA(MsgType dpMsgType) const
    {
      return (type == dpMsgType ? type : DpMsg::isA(dpMsgType));
    }

    /// Get flag indicating whether answer is required.
    PVSSboolean needsAnswer() const { return (type == DP_MSG_DPNAME_REQ); }

    /// Create new instance.
    virtual Msg *allocate() const { return new DpMsgManipDpName; }

    /** Get number of groups.
    This always returns 1.
    */
    virtual PVSSulong getNrOfGroups() const { return 1; };
    /// Get GroupId.
    virtual DpIdentifier getGroupId(PVSSulong) const { return dpId; }

    /// Get system number.
    SystemNumType  getSystem() const { return dpId.getSystem(); }

    /** Print the contents of the list to an output stream.
    Level controls the amount of debug information printed and shall be > 0.
    */
    virtual void debug(std::ostream &to, int level) const;

    /// Change type to DP_MSG_MANIP_DPNAME.
    PVSSboolean changeToManipMsg();

    /// Get UserID.
    PVSSuserIdType getUserId() const   { return userId; }
    /// Set UserID.
    void setUserId(PVSSuserIdType uId) { userId = uId; }

    /// Get the new name of the datapoint.
    IL_DEPRECATED("deprecated, use getName() instead")
      const CharString & getDpName() const {return name;}

    /// Get the new name of the datapoint.
    const CharString & getName() const { return name; }

    /// Get the datapoint id
    IL_DEPRECATED("deprecated, use getId() instead")
    const DpIdentifier & getDpId() const {return dpId;}

    /// Get the datapoint id
    const DpIdentifier& getId() const { return dpId; }

    /// Write the instance into the itcNdrUbSend stream.
    virtual void outNdrUb(itcNdrUbSend &ndrStream) const override;
    /// Read the instance from the itcNdrUbReceive stream.
    virtual void inNdrUb(itcNdrUbReceive &ndrStream) override;

private:
    PVSSuserIdType  userId;
    MsgType         type;
    DpIdentifier    dpId;
    CharString      name;
};


#endif