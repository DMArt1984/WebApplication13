#ifndef _CTRLCB_H_
#define _CTRLCB_H_

#include <Types.hxx>
#include <CharString.hxx>
#include <ScriptId.hxx>
#include <iostream>

class Variable;
class DynVar;
class ExternData;
class Controller;
class DoneCB;

//--------------------------------------------------------------------------------

/*  author Martin Koller */
/** holds a CTRL-Script source */
class DLLEXP_CTRL CtrlCB
{
public:
  /// Constructors
  CtrlCB();

  // copy-ctor does NOT copy the ExternData object
  CtrlCB(const CtrlCB &newCtrlCB);

  ~CtrlCB();

  /// reads a ctrl-script file (language is unchanged)
  bool readFromFile(const CharString &fileName, bool onlyCheck = false);

  /// search for the file to open: 1)as given, 2)<name>.ctl, 3)<name>.ctc
  static CharString findScriptPath(const CharString &fileName);

  /// Show the line with the syntax error.
  static void showSyntaxError(const CharString &file, const CharString &script, long errPos, bool onlyCheck = false);

  bool read(std::istream &from, PVSSshort version);
  bool write(std::ostream &to, PVSSshort version) const;

  /** @name Operatoren */
  //@{
  /// = does NOT copy the ExternData object
  const CtrlCB &operator=(const CtrlCB &newCtrlCB);
  /// ==
  bool operator==(const CtrlCB &CB) const;
  /// !=
  bool operator!=(const CtrlCB &CB) const;
  //@}

  /** Tries to set the script to this and therefore checks the syntax of the script.
    * @return If OK, returns PVSS_TRUE else PVSS_FALSE.
    * @param errpos On false, errpos points to the char, which produced the error
    */
  bool setScript(const CharString &s, PVSSlong &errpos);

  /** Tries to set the script to this and therefore checks the syntax of the script.
    * @param s script content
    * @param errpos On false, errpos points to the char, which produced the error
    * @param filename file name of file that contains script
    * @return If OK, returns PVSS_TRUE else PVSS_FALSE.
    */
  bool setScript(const CharString &s, PVSSlong &errpos, const CharString &filename);

  // set script without any check
  void setScript(const CharString &s);

  ///
  const CharString &getScript() const;

  ///
  void deleteScript();

  // copy the script from given @from into this
  void copyScript(const CtrlCB &from);

  /// is there a Ctrl-Script ? - deprecated. Use hasScript() instead
  operator int () const;

  /// is there a CTRL script
  bool hasScript() const;

  /** links this object with given ExternData. The ExternData object will then also point back to this
    * After setting the ExternData object, one can use the simpler start*() etc. methods without the
    * need to explicitely pass another ExternData object. It will use the stored one.
    * The given ExternData object will be deleted in the destructor.
    * If the given pointer == 0, it simply unsets the internal pointer and does not delete the
    * previous object which it pointed to.
    */
  void setExternData(ExternData *xd);

  /// return the ExternData pointer which was set with setExternData()
  ExternData *getExternData() const { return extData; }

  /** start the main() function in the script.
      @return false if no main() function was found, else true
    */
  bool start(const DynVar &subst, const Variable *args = 0);

  /** starts a specific function.
      if singleThread=TRUE, the function will start only if any thread of the script does not process
      this function at this time
      if doExecDone = TRUE the thread will be fully executed (EXEC_DONE), so you can get the Results back
      @return false if no main() function was found, else true
  */
  bool startFunc(const CharString &funcName,
                 const DynVar &subst,
                 const Variable *args,
                 PVSSboolean singleThread = PVSS_FALSE,
                 PVSSboolean doExecDone = PVSS_FALSE);

  /** start the main() function in the script.
      Don't use the ctrl argument any more - the method uses the static Controller pointer.
      @return false if no main() function was found, else true
  */
  bool start(Controller *ctrl,
             const DynVar &subst,
             ExternData *cData,
             const Variable *args = 0,
             PVSSboolean holdClientData = PVSS_FALSE);

  /* starts a specific function.
     Don't use the ctrl argument any more - the method uses the static Controller pointer
     if singleThread=TRUE, the function will start only if any thread of the script does not process
     this function at this time
     if doExecDone = TRUE the thread will be fully executed (EXEC_DONE), so you can get the Results back
     @return false if no main() function was found, else true
  */
  bool startFunc(Controller *ctrl,
                 const CharString &funcName,
                 const DynVar &subst,
                 ExternData *cData,
                 const Variable *args,
                 PVSSboolean singleThread = PVSS_FALSE,
                 PVSSboolean doExecDone = PVSS_FALSE,
                 DoneCB *doneCB = 0);

  /// stop the script and check it out from Controller
  void stop();
  ///
  ScriptId getId() const;
  void setId(ScriptId newId);
  ///
  bool getDollarList(DynVar &list) const;

  // internal use (e.g. User Interface to store registered attribute script name index)
  void setClientData(int cd);
  int getClientData() const;

  /// if ExternData not given, it uses the internally stored one
  void syntaxCheck(ExternData *cData = 0);

  /// semantic check
  bool checkIntegrity(DynVar &errors, const DynVar &subst, ExternData *cData = 0);

  bool hasConnection();

  void setDefaultScript(const CharString &defScript);
  CharString getDefaultScript() const;

  // parse the script and return function's name, parameters and implementation
  // arrays shoul be freed by calling this function with script = ""
  static void getFunctions(const CharString &script, CharString *&fNameArray, CharString *&fParamsArray,
                           CharString *&fScriptArray,  int &numOfFunctions);

  bool isCoded() const;

  // don't use
  PVSSshort getLanguage() const;
  void setLanguage(PVSSshort i);

  size_t memUsage() const;

private:
  int clientData;
  ExternData *extData;
  class CtrlCBPrivate *d;
};

#endif /* _CTRLCB_H_ */
