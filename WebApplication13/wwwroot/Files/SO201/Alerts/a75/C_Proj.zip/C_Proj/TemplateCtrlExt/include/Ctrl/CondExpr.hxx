#ifndef _CONDEXPR_H_
#define _CONDEXPR_H_

#include <CtrlExpr.hxx>


/*  author VERANTWORTUNG: Heinz Meissl */
/** conditional erpression, operator ?: */
class DLLEXP_CTRL CondExpr : public CtrlExpr
{
  public:
    /// Returns the type of the Expression
    virtual ExprType isA() const { return COND_EXPR; }

    /** Constructor f�r e1 ? e2 : e3
      * @param e1 != NULL
      * @param e2 != NULL
      * @param e3 != NULL
      */
    CondExpr(CtrlExpr *e1, CtrlExpr *e2, CtrlExpr *e3, int line, int file) 
      : CtrlExpr(line, file), expr1(e1), expr2(e2), expr3(e3) {}

    /// Destructor
    virtual ~CondExpr();

    /// CtrlSment nach der Bedingung
    virtual void setNext(CtrlSment *n);

    /** Ist CondExpr ein eigenes Statement, wird sie mit execute ausgef�hrt.
      * Ist sie Teil einer komplexen Expr wird sie mit 
      * evaluate ausgewertet.
      * @return NULL | Ptr auf n�chstes CtrlSment. NULL bedeutet das aktuelle Sment
      *        ist das letzte Sment einer CtrlSmentList.
      * @param thread der Thread der dieses Statement ausf�hrt
    */
    virtual const CtrlSment *execute(CtrlThread *) const;

    /** Ist CondExpr Teil einer Komplexen Expr wird sie mit evaluate
      * ausgewertet. 
      * @return immer != NULL, Ptr auf static Variable einer von 
      *         CtrlExpr abgeleiteten Klasse 
      *         -> wird beim n�chsten CtrlExpr.evaluate �berschrieben
      *         -> sofort Kopieren                  
      * @param thread der Thread der dieses Statement ausf�hrt
    */
    virtual const Variable *evaluate(CtrlThread *thread) const;

    // Es gibt genau eine Expr, die ausgewertet werden muss.
    // Die naechste haengt vom Ergebnis dieser Bedingung ab und kann erst
    // danach bestimmt werden!
    virtual const CtrlExpr *getFirstExpr(CtrlThread *thread) const;
 
    /// Gewichtung des CtrlSment
    virtual SmentWeight getWeight() const { return SM_WT_Medium; }

    virtual void writeTrace(CtrlThread *thread, bool writeValue = true) const;

    virtual bool checkIntegrity(const CharString &location, CtrlThread *) const;

  private:
    CtrlExpr *expr1;
    CtrlExpr *expr2;
    CtrlExpr *expr3;
};

#endif /* _CONDEXPR_H_ */

