#ifndef _CNSVIEW_H_
#define _CNSVIEW_H_

#include <CNSObject.hxx>
#include <CNSTree.hxx>
#include <CNSNodeNames.hxx>
#include <CNSPath.hxx>
#include <ViewId.hxx>

// forward declaration
class CNSViews;
class CNSTreeVisitor;

/**
 * A container for one or more CNSTree objects.
 *
 * @internal
 */
class DLLEXP_DATAPOINT CNSView : public CNSObject
{
public:
  // needs access to setViews()
  friend class CNSViews;

  /**
   * Default constructor. Creates an empty view.
   * Use only for BCM streaming.
   */
  CNSView() : separators(CNSPath::PATH_SEPARATOR), id(0), views(0) { }

  /**
   * Creates a new empty view with the specified name, display names,
   * path separators and id, and the CNSViews collection it is contained in.
   * The names and the id have to be unique from other views of a system.
   *
   * @param viewNames The names of the view
   * @param viewSeparators The separator characters to use for building
   *                       paths in the defined display languages.
   * @param viewId The id of this view.
   */
  CNSView(const CNSNodeNames &viewNames, const LangText &viewSeparators, const ViewId &viewId)
    : names(viewNames), separators(viewSeparators), id(viewId), views(0)
  {
  }

  /**
   * Creates a new empty view with the specified name, display names,
   * path separators and id, and the CNSViews collection it is contained in.
   * The names and the id have to be unique from other views of a system.
   *
   * @param viewNames The names of the view
   * @param viewSeparators The separator characters to use for building
   *                       paths in the defined display languages.
   * @param viewId The id of this view.
   * @param parentViews A pointer to the CNSViews-object this view belongs to.
   */
  CNSView(const CNSNodeNames &viewNames, const LangText &viewSeparators,
          const ViewId &viewId, CNSViews &parentViews)
    : names(viewNames), separators(viewSeparators), id(viewId), views(&parentViews)
  {
  }

  /// Destructor
  ~CNSView() { }

public:
  /** Equality operator (virtual). 
      @return int 1 if the values are equal, otherwise 0.
  */
  virtual int operator==(const CNSObject &rVal) const;
  
  /** Check if own type matches or is derived from a given type.
      @param type CNSObjectType to check.
      @return true if the type does match, false if the type does not match.
   */
  virtual bool isA(CNSObjectType type) const { return(type == CNS_VIEW); }

  /// @return the CNSObjectType of the object.
  virtual CNSObjectType isA() const { return(CNS_VIEW); }

  /// BCM stream output method
  virtual void outNdrUb(itcNdrUbSend &ndrStream) const;

  /// BCM stream input method
  virtual void inNdrUb(itcNdrUbReceive &ndrStream);

  /**
   * Returns the view this tree belongs to.
   */
  virtual const CNSView *getView() const;

  /**
   * Adds an existing tree node.
   * If the node is successfully added, the parent view takes ownership of it.
   *
   * Empty pointers or nodes with existing names will not be added.
   *
   * @return True if the node was successfully added, otherwise false.
   */
  virtual bool addChild(CNSTreeNode *newChild);

  /**
   * Returns the names of this view.
   */
  const CNSNodeNames &getNames() const { return names; }

  /**
   * Returns the name of this view.
   */
  const char *getNamePtr() const { return(names.getNamePtr()); }

public:
  /**
   * Returns the names of this view.
   */
  CNSNodeNames &getNames() { return names; }

  /**
   * Changes the names of this view.
   *
   * If this view is owned by a CNSViews object, and its technical name is
   * changed, it has to be re-inserted into the CNSViews object, to preserve
   * the alphabetical sort order.
   */
  void setNames(const CNSNodeNames &newNames) { names = newNames; }

  /**
   * Returns the separators for this view.
   */
  const LangText &getSeparators() const { return separators; }

  /**
   * Returns the separators for this view.
   */
  LangText &getSeparators() { return separators; }

  /**
   * Changes the separators for the display paths of this view.
   */
  void setSeparators(const LangText &newSeparators) { separators = newSeparators; }

  /**
   * Returns the number of trees in this view.
   */
  unsigned int getNumberOfTrees() const { return trees.getNumberOfItems(); }

  /**
   * Returns the tree at the specified index, or null if the index does not exist.
   * Do not delete the returned pointer.
   */
  CNSTree *getTreeAt(unsigned int index) { return trees.getAt(index); }

  /**
   * Returns the tree at the specified index, or null if the index does not exist.
   */
  const CNSTree *getTreeAt(unsigned int index) const { return trees.getAt(index); }

  /**
   * Returns the tree with the specified name, or null if no such tree was found.
   * Do not delete the returned pointer.
   */
  CNSTree *getTree(const char *treeName);

  /**
   * Returns the tree with the specified name, or null if no such tree was found.
   */
  const CNSTree *getTree(const char *treeName) const;

  /**
   * Adds an existing tree to the trees in this view.
   * If the tree is successfully added, the view takes ownership of it.
   *
   * Empty pointers or trees with existing names will not be added.
   *
   * @return True if the tree was successfully added, otherwise false.
   */
  bool addTree(CNSTree *tree);

  /**
   * Removes and deletes the specified tree. Be aware that the specified pointer
   * cannot be used after a successful removal.
   *
   * @return False if the tree was not found, otherwise true.
   */
  bool removeTree(const CNSTree *tree);

  /**
   * Removes the specified tree, but does not delete it.
   *
   * @return False if the tree was not found, otherwise true.
   */
  bool cutTree(const CNSTree *tree);

  /**
   * Deletes all trees.
   */
  void clearTrees() { trees.clear(); }

  /**
   * Returns the id of this view.
   */
  ViewId getViewId() const { return id; }

  /**
   * Changes the id of this view.
   */
  void setViewId(const ViewId &newViewId) { id = newViewId; }

  /**
   * Returns a pointer to the CNSViews-object this view belongs to.
   * Do not delete the returned pointer.
   */
  CNSViews *getViews() { return views; }

  /**
   * Returns a pointer to the CNSViews-object this view belongs to.
   */
  const CNSViews *getViews() const { return views; }

  /**
   * Returns the path of this view, in the format
   * 'System.View:'.
   *
   * @param [out] path Stores the computed path. The path will be appended to
   *                   the existing text, if there is any.
   * @param withSystem Controls whether the path should include the system name
   */
  void getPath(CharString &path, bool withSystem = true) const;

  /**
   * Computes the display paths of this view for each display language.
   * The paths have the same format as in getPath(),
   * with the separators ('.') replaced by the language-specific separator
   * character defined in this view.
   *
   * @param [out] paths Stores the computed display paths. The path will
   *                    be appended to the existing text, if there is any.
   * @param withSystem Controls whether the path should include the system name
   */
  void getDisplayPaths(LangText &paths, bool withSystem = true) const;

  /**
   * Compute the display path of this view for a single language.
   * The path has the same format as in getPath(),
   * with the separators ('.') replaced by the language-specific separator
   * character defined in this view.
   *
   * @param [out] path Stores the computed display path. The path will
   *                   be appended to the existing text, if there is any.
   * @param lang The language for which the display path will be computed.
   * @param withSystem Controls whether the path should include the system name
   */
  void getDisplayPath(CharString &path, LanguageIdType lang, bool withSystem = true) const;

  /**
   * Invokes the specified visitor for every node in this view.
   *
   * @return PVSS_TRUE if every invocation of the functor returned PVSS_TRUE,
   *         otherwise PVSS_FALSE
   */
  PVSSboolean visitEveryCNSNode(CNSTreeVisitor &visitor) const;

  /// The debug function. Print out the contents according to format level (1 - 3)
  void debug(std::ostream &to, int level) const;

  /** The clone function is used to create an exact copy of the current object.
      The whole view with all its trees is cloned.
      This copy should be deleted after use.
      @return CNSView* pointer to a newly cloned CNSView (deep copy).
  */
  CNSView *clone() const;

private:
  // avoid generated default methods
  CNSView &operator=(const CNSView &);
  CNSView(const CNSView &);

  /**
   * Changes the link to the CNSViews-object this view belongs to.
   * Note that this does not change the ownership of a view,
   * it is still owned by the views collection where it is stored.
   */
  void setViews(CNSViews &newViews) { views = &newViews; }

  CNSNodeNames names;
  LangText separators;
  SimplePtrArray<CNSTree> trees;
  ViewId id;
  CNSViews *views;
};

//------------------------------------------------------------------------------
// inline-methods:


//------------------------------------------------------------------------------

inline bool CNSView::addChild(CNSTreeNode *newChild)
{
  return(addTree(newChild));
}

//------------------------------------------------------------------------------

inline bool CNSView::addTree(CNSTree *tree)
{
  if ((tree                        != 0) && // no nullpointer
      (tree->getNamePtr()          != 0) && // has name
      (*(tree->getNamePtr())       != 0) && // no empty name
      (getTree(tree->getNamePtr()) == 0))   // unique name
  {
    trees.appendOrInsertSorted(tree, CNSTree::compare);
    tree->setView(*this);

    return true;
  }

  return false;
}

//------------------------------------------------------------------------------

inline bool CNSView::removeTree(const CNSTree *tree)
{
  bool found = cutTree(tree);

  if (found)
  {
    delete tree;
    return true;    
  }

  return false;
}

//------------------------------------------------------------------------------

inline bool CNSView::cutTree(const CNSTree *tree)
{
  unsigned int index = trees.findPtr(tree);

  if (index == (unsigned int)(-1))
  {
    return false;
  }

  trees.cutPtr(index);
  return true;
}


#endif // _CNSVIEW_H_
