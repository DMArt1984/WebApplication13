#ifndef _SELEXPR_H_
#define _SELEXPR_H_

#include <CtrlExpr.hxx>

class ExprList;
class ClassVar;

/** member selection erpression  postfix-expression.identifier
    or postfix-expression->identifier - not yet implemented)
    @classification ETM internal
*/
class DLLEXP_CTRL SelExpr : public CtrlExpr
{
  public:
    /// Returns the type of the Expression
    virtual ExprType isA() const { return SEL_EXPR; }

    /** Constructor f�r e1.e2
      * @param e1 != NULL
      * @param e2 != NULL
      */
    SelExpr(CtrlExpr *e1, CtrlExpr *e2, int line, int filenum);

    /// Destructor
    virtual ~SelExpr();

    /** Ist SelExpr ein eigenes Statement, wird sie mit execute ausgef�hrt.
      * Ist sie Teil einer komplexen Expr wird sie mit
      * evaluate ausgewertet.
      * @return NULL | Ptr auf n�chstes CtrlSment. NULL bedeutet das aktuelle Sment
      *        ist das letzte Sment einer CtrlSmentList.
      * @param thread der Thread der dieses Statement ausf�hrt
    */
    virtual const CtrlSment *execute(CtrlThread *) const;

    /** Ist SelExpr Teil einer Komplexen Expr wird sie mit evaluate
      * ausgewertet.
      * @return immer != NULL, Ptr auf static Variable einer von
      *         SelExpr abgeleiteten Klasse
      *         -> wird beim n�chsten CtrlExpr.evaluate �berschrieben
      *         -> sofort Kopieren
      * @param thread der Thread der dieses Statement ausf�hrt
    */
    virtual const Variable *evaluate(CtrlThread *thread) const;

    /// Variable that can be written (L-Value)
    virtual Variable *getTarget(CtrlThread *thread) const;

    const Variable *assign(const Variable *rVar, CtrlThread *thread);

    virtual const CtrlExpr * getFirstExpr(CtrlThread *thread) const;

    /// Gewichtung des CtrlSment
    virtual SmentWeight getWeight() const { return SM_WT_Medium; }

    virtual void writeTrace(CtrlThread *thread, bool writeValue = true) const;

    virtual bool checkIntegrity(const CharString &location, CtrlThread *) const;

    /// First CtrlExpr in the List
    CtrlExpr *getFirstMember() const;
    ///
    CtrlExpr *getNextMember() const;
    ///
    //CtrlExpr *getPrevMember() const;

    // Internal use: Set Flag for nested SelExpr
    void  setDontExecute() { dontExecute = true; }

    // Internal use
    void setArgList(ExprList *args);
    void appendExpr(CtrlExpr *expr);

    /** return a representation of this as a string, used in error output
      @internal
    */
    virtual CharString toString() const;

  private:
    void recursResetPointerToCurrentExpr() const;
    bool isStruct(CtrlThread *thread, const Variable **first = nullptr) const;
    const Variable *resolveStruct(CtrlThread *thread, bool getTarget, ClassVar **userType = 0) const;
    CharString toStringUpTo(const CtrlExpr *upTo) const;

    CtrlExpr *expr1;
    CtrlExpr *expr2;
    mutable CtrlExpr *act;

    bool dontExecute;
};

#endif /* _SELEXPR_H_ */
