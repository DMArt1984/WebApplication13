#ifndef _DELETE_WRAPPER_H_
#define _DELETE_WRAPPER_H_

#include <algorithm>
using namespace std;

// delete objects inside the wrapper
// we keep this a template to be used in principle for all our pointer containers
struct DrvDeleteObject
{
    template<typename T>
    void operator()(const T & obj) const
    {
        delete obj();
    }
};

#endif

