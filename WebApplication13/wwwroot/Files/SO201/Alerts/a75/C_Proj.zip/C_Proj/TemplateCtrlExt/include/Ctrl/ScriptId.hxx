#ifndef _SCRIPTID_H_
#define _SCRIPTID_H_

/* Dies koennte erweitert werden, wenn ausser der Id ev. noch ein Error-Code
  zurueckgegeben werden soll */

#include <Types.hxx>

typedef PVSSlong ScriptId;

#endif /* _SCRIPTID_H_ */
