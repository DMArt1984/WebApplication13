#ifndef _CtrlClass_H_
#define _CtrlClass_H_

// 9.11.2015 MK: a user defined class definition
// @classification ETM internal

#include <UserType.hxx>
class CtrlVarList;
class CtrlVar;
class ClassVar;
class CtrlFunc;
class CtrlThread;
class CtrlSmentList;
class FCall;

class DLLEXP_CTRL CtrlClass : public UserType
{
  public:
    CtrlClass(CharString *theName, const CtrlClass *theBaseClass, int lineNum, int fileNum);

    virtual ~CtrlClass();

    virtual bool isA(Type type) const { return type == CLASS_TYPE; }

    virtual ClassVar *createInstance(bool doRefCount) const;

    // makes sure the given instance has all members.
    // while parsing and using a userType class as declaration/parameter in a function inside the
    // class itself, the class is not yet completely known with all members. Therefore this method ensures
    // that the given ClassVar matches the definition of the class
    void ensureInstance(ClassVar *instance) const;

    // from parser: pass a list of member variables and member funcs
    void setMembers(CtrlVarList *v);

    // return a pointer to named member of instance or a pointer to the single
    // static member in this class
    CtrlVar *getMemberCtrlVar(const CharString &which, const ClassVar *instance, CtrlThread *thread) const;

    // returns own or baseclass pointer, or 0 if not found
    CtrlFunc *getMemberFunc(const CharString &which) const;

    CtrlVar *getMemberCtrlVar(const CharString &which) const;

    unsigned int getMemberCount() const;  // includes vars and funcs
    unsigned int getMemberVarCount() const;  // number of vars
    unsigned int getMemberFuncCount() const; // number of funcs

    // idx 0 .. getMemberVarCount() ... member vars; else member funcs
    CtrlVar *getMemberCtrlVar(unsigned int idx) const;

    CtrlFunc *getMemberFunc(unsigned int idx) const;  // 0 .. getMemberFuncCount()

    // the name of a member variable.
    // The index is the one corresponding to the createInstance() result in the ClassVar
    const CharString &getNameFromInstanceIndex(unsigned int idx) const;

    // the static value of a member variable with index from instance
    CtrlVar *getMemberCtrlVarFromInstanceIndex(unsigned int idx) const;

    // in derived classes, the base class members are stored in instances after this members
    // Get the index for a specific class member inside an instance of this class
    unsigned int getInstanceIndex(const UserType *type, unsigned int idx) const;

    bool isDerivedFrom(const CtrlClass *theClass) const;

    const CtrlClass *getBaseClass() const;

    // called from parser ctrl.y
    void setBaseClassCtorCall(FCall *fcall);

    CtrlFunc *getCtor() const;
    CtrlFunc *getDtor() const;

    // is there any member referenced (from a CtrlVar via Class::Member from ctrl.y)
    bool isMemberReferenced() const;

  private:
    // return sum of all variable members from this and all base classes upwards
    unsigned int sumVarCount() const;
    void setInstanceVars(ClassVar *var, unsigned int startIdx) const;

    CtrlVar *getMemberCtrlVarWithBase(const CharString &which, const ClassVar *instance,
                                      unsigned int startIdx, CtrlThread *thread) const;

  private:
    class CtrlClassPrivate *d;
};

#endif
