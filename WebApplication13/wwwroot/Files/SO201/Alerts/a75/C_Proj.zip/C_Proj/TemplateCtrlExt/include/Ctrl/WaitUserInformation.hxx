#ifndef _WAITUSERINFORMATION_H_
#define _WAITUSERINFORMATION_H_

#ifdef _WIN32
#include <WaitCond.hxx>

#include <CharString.hxx>
#include <Windows.h>

class DynVar;
class TextVar;
class BitVar;
class CtrlThread;

/*  author VERANTWORTUNG: Milos Marusiak        */
/** Ctrl-Functions to get user account, computer, or group account information.
  */

class WaitUserInformation;
class DLLEXP_CTRL WaitUserInformation : public WaitCond
{
  public:
    ///  
    WaitUserInformation();
    ~WaitUserInformation();

    /// wann soll thread das naechste mal ausgefuehrt werden.
    virtual const TimeVar &nextCheck() const;

    virtual int checkDone();

    virtual void setValues() = 0;

  public:
    // FCall interface
    //
    // This function looks up the domain name for the user account
    // associated with the calling thread.
    static WaitUserInformation* getCurrentDomainName(CtrlThread *theThread, TextVar *domain);

    static WaitUserInformation* verifyWindowsUser(CtrlThread *theThread, const CharString &password, const CharString &username, int level, BitVar *result);
    
    static WaitUserInformation* getAllWindowsGroups(CtrlThread *theThread,  const CharString &domainName, DynVar *groups);
    
    static WaitUserInformation* getAllWindowsUsers(CtrlThread *theThread,  const CharString &domainName, PVSSboolean bShowAll, DynVar *users);

    static WaitUserInformation* getCurrentWindowsUser( CtrlThread *theThread,
                                                       TextVar *username,
                                                       TextVar *fullname,
                                                       TextVar *description,
                                                       DynVar  *groups,
                                                       const TextVar *password);


    static void getCurrentDomainName(CharString &domain);
    static PVSSboolean verifyWindowsUser(const CharString &password, const CharString &username, int level);
    static void getAllWindowsGroups(const CharString &domain, DynVar &groups);
    static void getAllWindowsUsers( const CharString &domain, PVSSboolean bShowAll, DynVar &users);
    static void getCurrentWindowsUser(CharString &username,
                                      CharString &fullname,
                                      CharString &description,
                                      DynVar     &groups,
                                      const CharString &password,
                                      PVSSboolean bPasswordValid);


    static void initCriticalSection();
    // classes used in the critical section
    struct Domain
    {
      PVSSboolean valid;  // Wait class is valid -> the script is running
      PVSSboolean busy;   // thread is running
      PVSSboolean result; // the result. If the thread function succeeds, the value is true
      CharString  domain;
    };

    struct  CurrentUser
    {
      PVSSboolean valid;  // Wait class is valid -> the script is running
      PVSSboolean busy;   // thread is running
      PVSSboolean result; // the result. If the thread function succeeds, the value is true
      CharString    username;
      CharString    fullname;
      CharString    description;
      DynVar        groups;
      CharString    password;
      PVSSboolean   bPasswordValid;
    };

    struct VerifyUser
    {
      PVSSboolean valid;  // Wait class is valid -> the script is running
      PVSSboolean busy;   // thread is running
      PVSSboolean result; // the result. If the thread function succeeds, the value is true
      CharString    username;
      CharString    password;
      int           level;
      PVSSboolean   verifyUserResult;
    };

    struct Groups
    {
      PVSSboolean valid;  // Wait class is valid -> the script is running
      PVSSboolean busy;   // thread is running
      PVSSboolean result; // the result. If the thread function succeeds, the value is true
      CharString  domain;
      DynVar      groups;
    };

    struct Users
    {
      PVSSboolean valid;  // Wait class is valid -> the script is running
      PVSSboolean busy;   // thread is running
      PVSSboolean result; // the result. If the thread function succeeds, the value is true
      CharString  domain;
      PVSSboolean bShowAll; // false = check UF_ACCOUNTDISABLE and UF_LOCKOUT flags
      DynVar      users;
    };

    
    static Domain      *domain;
    static VerifyUser  *verifyUser;
    static Groups      *groups;
    static Users       *users;
    static CurrentUser *currentUser;

    HANDLE hProcess;

  protected:
  private:
    // The getServerList function lists all servers 
    // that are visible in a domain.
    static PVSSboolean getServerList(DynVar &list, const CharString &domain);

    // The function retrieves a list of global groups to which a specified user belongs.
    static PVSSboolean getUserGroups(const CharString &servername, const CharString &username, DynVar &groups);

    // The function returns the name of each local groups to which a specified user belongs.
    static PVSSboolean getUserLocalGroups(const CharString &servername, const CharString &username, DynVar &groups);

    // The function returns user account information
    static PVSSboolean queryUserInformation(const CharString &servername, 
                                            const CharString &username,
                                            CharString &fullname,
                                            CharString &description);

    // The function retrieves a list of users on the specified server
    static PVSSboolean getServerUsers(const CharString &servername, PVSSboolean bShowAll, DynVar &users);

    // The function returns the name of each local group account on the specified server�
    static PVSSboolean getServerLocalGroups(const CharString &servername, DynVar &groups);

    // The function returns the name of each group account on the specified server
    static PVSSboolean getServerGroups(const CharString &servername, DynVar &groups);

    // the function just converts encoding from system to actLang for sake 
    // of SEH and C++ unwinding incompatibility in the calling function
    static void convertDomainName(TCHAR *cdn, CharString &csdn);

    PVSSboolean m_done;

    static PVSSboolean m_bInitCriticalSection;
};

class DLLEXP_CTRL WaitUIDomainName : public WaitUserInformation
{
  public:
    WaitUIDomainName( TextVar *&domainName);
    ~WaitUIDomainName();

    virtual void setValues();
  private:
    TextVar *mDomainName;
};

class DLLEXP_CTRL WaitUIVerifyUser : public WaitUserInformation
{
  public:
    WaitUIVerifyUser(const CharString &password, const CharString &username, int level, BitVar *result);
    ~WaitUIVerifyUser();

    virtual void setValues();

  private:
    BitVar *mResult;
};

class DLLEXP_CTRL WaitUIGroups : public WaitUserInformation
{
  public:
    WaitUIGroups(const CharString &domainName, DynVar *groups);
    ~WaitUIGroups();

    virtual void setValues();
  private:
    DynVar *mGroups;
};
    
class DLLEXP_CTRL WaitUIUsers : public WaitUserInformation
{
  public:
    WaitUIUsers( const CharString &domainName, PVSSboolean bShowAll, DynVar *users);
    ~WaitUIUsers();

    virtual void setValues();
  private:
    DynVar *mUsers;
};
    
class DLLEXP_CTRL WaitUICurrentUser : public WaitUserInformation
{
  public:
    WaitUICurrentUser(TextVar *userName, TextVar *fullName, TextVar *descriptoin, DynVar *groups, const TextVar *password);
    ~WaitUICurrentUser();

    virtual void  setValues();
  private:
    TextVar *mUserName;
    TextVar *mFullName;
    TextVar *mDescription;
    DynVar *mGroups;
};

class WaitEventInformation;
class DLLEXP_CTRL WaitEventInformation : public WaitCond
{
  public:
    ///  
    WaitEventInformation( const TimeVar &start, const TimeVar &end, int category, DynVar *events);
    ~WaitEventInformation();

    /** Waitobjetct: Warte bis Thread beendet ist.
      * @param theThread   IN: thread der warten muss. wird nicht frei gegeben!
      */
  friend DWORD _getEvents(LPVOID arg);
  private:
    WaitEventInformation(){}

  public:

    /// wann soll thread das naechste mal ausgefuehrt werden.
    virtual const TimeVar &nextCheck() const;

    virtual int checkDone();

    virtual void setValues();

  public:
    // FCall interface
    //
    // This function looks up the domain name for the user account
    // associated with the calling thread.
    static WaitEventInformation* getEvents( CtrlThread *theThread, const TimeVar &start, const TimeVar &end, int category, DynVar *events);
    static void initCriticalSection();

    // classes used in the critical section
    HANDLE hProcess;

    struct Events
    {
      PVSSboolean valid;  // Wait class is valid -> the script is running
      PVSSboolean busy;   // thread is running
      PVSSboolean result; // the result. If the thread function succeeds, the value is true
      TimeVar start;
      TimeVar end;
      int category;
      DynVar events;
    };

    static Events *events;
    DynVar        *mEvents; 

  private:
    static void getEvents(const TimeVar &start, const TimeVar &end, int category, DynVar &events);

    PVSSboolean m_done;

    static PVSSboolean m_bInitCriticalSection;
};


#endif //_WIN32

#endif /* _WAITUSERINFORMATION_H_ */
