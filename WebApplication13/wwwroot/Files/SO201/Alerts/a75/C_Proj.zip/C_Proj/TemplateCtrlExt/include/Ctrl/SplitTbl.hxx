// VERANTWORTUNG: Andras Horvath

/* Message splitting table  */

#ifndef _SPLITTBL_H_
#define _SPLITTBL_H_

#include <Types.hxx>
#include <map>

class CtrlFunc;
class SplitTblEntry;

//--------------------------------------------------------------------------------

class DLLEXP_CTRL SplitTbl
{
public:
  SplitTbl();
  ~SplitTbl();

  void append(SplitTblEntry *entry);
  void remove(SplitTblEntry *entry);
  void clear();
  SplitTblEntry* find(PVSSulong reqId);


private:
  std::map<PVSSulong, SplitTblEntry*>* m;
};

#endif /* _SPLITTBL_H_ */
