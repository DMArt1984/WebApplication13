//----------------------------------------------------------------------------
//  Copyright (C) Siemens AG 2016. All Rights Reserved.
//----------------------------------------------------------------------------

#ifndef _PATTERNMATCH_HXX_
#define _PATTERNMATCH_HXX_

#include <Types.hxx>

#ifndef FNM_NOESCAPE
///Disable backslash escaping.
#define FNM_NOESCAPE    0x01
#endif

#ifndef FNM_PATHNAME
///Slash in string only matches slash in pattern.
#define FNM_PATHNAME    0x02
#endif

#ifndef FNM_PERIOD
///Leading period in string must be matched exactly by period in
///pattern.
#define FNM_PERIOD      0x04
#endif

#ifndef FNM_CASEINSENSITIVE
///Matching is not case sensitive
#define FNM_CASEINSENSITIVE      0x08
#endif

#ifndef FNM_NOMATCH
#define FNM_NOMATCH     -1
#endif

// forward declarations
class Bit8;
class Bit16;
class Bit32;
class Bit64;
class Blob;

/**
 * @threadsafe
 */ 
class DLLEXP_BASICS PatternMatch
{
  friend class UNIT_TEST_FRIEND_CLASS;

public:

  /// platform-dependent path separator ('/', '\\', ...)
  static const char PATH_CHAR;

  /** Pattern matching. Handles '*' and '?' characters, '[]' sets, and escaping with '\'.
      @param pattern Pattern to match.
      @param string String which will be compared agains a pattern.
      @return true if the string matches the pattern.
    */
  static bool patternMatch(const char *pattern, const char *string);
  
  /** Almost the same as ::patternMatch above, but without case sensitivity
  */
  static bool patternMatchCaseInsensitive(const char *pattern, const char *string);

  /** Checks if the given number matches the pattern.
      The function always returns false if the pattern cannot be evaluated.
      This happens if:
        * a number in the pattern has more than 32 digits (or '-'/'+' and 31 digits)
        * after the '-' or '+' is no digit (except the '-' after a digit (range))
      @param pattern Pattern to match. It is a string with numeric intervals
      and/or concrete numbers, delimited by a comma, for example "1-5,8,10,15-20".
      @param number Matched number.
      @return true, if the number is listed in the pattern string or belongs
      to an interval specified in the pattern string or false if not,
      or the pattern cannot be evaluated.
  */
  static bool numberMatch(const char *pattern, PVSSlonglong number);

  /** Checks if Bit32 matches pattern from right to left.
      @param pattern can contain '1' and '0' for positions that should match exactly
             or other characters like 'x' to ignore that position in Bit32.
             If pattern is shorter than 32 characters only the positions available are relevant for the matching.
      @param var Bit32 to check.
      @return true, if Bit32 matches pattern.
  */
  static bool bit32Match(const char *pattern, const Bit32 &var);

  /** checks If Bit64 matches pattern from right to left.
      @param pattern Pattern can contain '1' and '0' for positions that should match exactly
             or other characters like 'x' to ignore that position in Bit64.
             If pattern is shorter than 64 characters only the positions available are relevant for matching.
      @param var Bit64 to check.
      @return true, if Bit64 matches pattern
  */
  static bool bit64Match(const char *pattern, const Bit64 &var);


  /** Pattern matching. Same as above but the parameters are of type const char*.
      @param pattern Pattern to match.
      @param dpName String which will be compared agains a pattern.
      @return PVSS_TRUE if the string matches the pattern.
  */
  static bool dpMatch(const char *pattern, const char *dpName);

  /** Pattern matching. This method calls fnmatch (like patternMatch()), but the
      slash characters are handled specifically, as if they represent a file name.

      @note This function will only recognize the platform specific path separator,
            other path separators will be matched like any other character.

      @param pattern Pattern to match.
      @param string String which will be compared agains a pattern.
      @return PVSS_TRUE if the string matches the pattern.
  */
  static bool fileNameMatch(const char *pattern, const char *string);

private:
  /// used in the dpMatch() method
  static bool doMatchLoop(const char *pattern, const char *str);
};

#endif // _PATTERNMATCH_HXX_
