#ifndef _COUNTACCU_H_
#define _COUNTACCU_H_

// Author: Heinz MEISSL
// Date:   14.4.1997
// Purpose: implement a statistic Accumulator to count the number of values
// passed within a period

#ifndef _SIMPLEACCU_H_
#include <SimpleAccu.hxx>
#endif

#ifndef _VARIABLE_H_
#include <Variable.hxx>
#endif

#ifndef _UINTEGERVAR_H_
#include <UIntegerVar.hxx>
#endif

#ifndef _TIMEVAR_H_
#include <TimeVar.hxx>
#endif

/// A value accumulator class. This class is used to count the number of accumulate() calls.
/// The internal counter is increased every time the accumulate function is called.
/// @classification ETM internal
class DLLEXP_OABASICS CountAccu: public SimpleAccu
{
  public:
    /// constructor
    CountAccu() : theCount (0) { validFlag = PVSS_TRUE; }
    
    /// Accumulate method. Any Variable type can be passed to the method, while after
    /// each call, the internet counter is increased by one. If the counter overflows
    /// (more than 0xFFFFFFFF entries were accumulated), isValid() will return false.
    /// @param theValue Parameter is not used.
    /// @param atTime Parameter is not used.
    virtual void accumulate(const Variable &theValue, const TimeVar &atTime );
    
    /// Get the internal counter with number of accumulate() calls.
    /// @return UIntegerVar with the counter.
    virtual const Variable &getResult();

    /// This method resets the internal counter to zero and valid flag to PVSS_TRUE.
    virtual void reset();
    
  protected:
  
  private:

    /// prevents the copy constructor to be called.
    CountAccu(const CountAccu &);

    /// prevents the assignment operator to be called.
    CountAccu &operator=(const CountAccu &);
  
    /// internal counter counting the number of accumulate() calls.
    /// Can be reset to zero with reset() call.
    UIntegerVar theCount;
};

#endif
