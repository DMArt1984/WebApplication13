// DATEIBESCHREIBUNG ==============================================================
// DATEINAME:     DpDateTimeConv.hxx
// VERANTWORTUNG:	Stanislav Meduna
// 
// BESCHREIBUNG:	Umrechnung der Zeit/Datum-Wert.
//
// AENDERUNGS-HISTORIE
// Ver.  | Datum      | Aenderungen                            | ModNr.| Autor
// ------+------------+-----------------Anfang-----------------+-------+-----------
//   1.0 |            | 1.Erstellung mit Westmount-OMT         |     0 |
//   1.1 | 08.09.2010 | Adding doxygen comments                |       | psedik
// ======================================Ende======================================
#ifndef _DPDATETIMECONV_H_
#define _DPDATETIMECONV_H_

// forward declarations and includes
class DpDateTimeConv;

#include <DpConversion.hxx>

class DpConvSmooth;
class DpDateTimeConv;
class Variable;
class BitVec;

// ========== DpDateTimeConv ============================================================
/// Conversion class used for converting date and time. Current implementation does nothing.
class DLLEXP_CONFIGS DpDateTimeConv : public DpConversion 
{
public:

  /// Constructor
  DpDateTimeConv();
  
  /// Destructor
  ~DpDateTimeConv();

  /// Outputs the instance to the itcNdrUbSend stream
  /// @param ndrStream Output stream
  /// @param unused Streamed DpCounterConv instance
  /// @return itcNdrUbSend stream
  friend DLLEXP_CONFIGS itcNdrUbSend &operator<<(itcNdrUbSend &ndrStream, const DpDateTimeConv &unused);

  /// Receives the instance from the itcNdrUbReceive stream
  /// @param ndrStream Input stream
  /// @param unused DpCounterConv instance receiving the value from the stream
  /// @return itcNdrUbReceive stream
  friend DLLEXP_CONFIGS itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream, DpDateTimeConv &unused);
  
  /// Assignment operator
  /// @param aConv assigned value
  /// @return DpConvSmooth reference with the assigned value  
  virtual DpConvSmooth &operator=(const DpConvSmooth &aConv);

  /// Returns conversion type of this class
  /// @return DpConvDateTime
  virtual DpConversionType convType() const;

  /// Convert method. Current implementation just calls allocate() on inpVar and pass the new
  /// pointer to the outVarPtr
  /// @param inpVar Input Variable
  /// @param outVarPtr Pointer to the newly allocated output Variable.
  /// @param unused BitVec value, not used in the code
  /// @return 
  /// - DpConversionOK if the call was successfull
  /// - DpConversionError if it was not possible to allocate the new outVarPtr
  virtual DpConversionResultType convert(const Variable &inpVar, Variable * & outVarPtr, const BitVec &unused);
  
  /// Allocates the new DpDateTimeConv instance with default constructor.
  /// @return DpConvSmooth pointer to a newly allocated instance.  
  virtual DpConvSmooth *allocate() const;

  /// Set the attribute (current implementation does nothing).
  /// @param attrNr Attribute number (not used)
  /// @param var Variable to be set (not used)
  /// @return PVSS_FALSE
  virtual PVSSboolean setAttribut(DpAttributeNrType attrNr, const Variable &var);

  /// Gets the attribute.
  /// @param attrNr Attribute number, supported value is DpConfig::TYPE_ATTR
  /// @return DpConvDateTime from DpConfig::TYPE_ATTR attribute, 0 otherwise 
  virtual Variable *getAttribut(DpAttributeNrType attrNr) const;

protected:
private:
};

// ================================================================================
// Inline methods :

#endif /* _DPDATETIMECONV_H_ */
