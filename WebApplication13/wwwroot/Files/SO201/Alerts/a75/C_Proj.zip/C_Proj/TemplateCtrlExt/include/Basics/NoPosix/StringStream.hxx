#ifndef _STRINGSTREAM_H_
#define _STRINGSTREAM_H_

#include <sstream>

typedef std::stringstream StringStreamSuper;

#include <CharString.hxx>

/**
 * Wrapper for the std::stringstream class.
 *
 * Masked some misbehaviours of the old iostream implementation
 * in earlier versions. Now it is only an empty wrapper around std::stringstream.
 *
 * @internal
 * @deprecated Empty wrapper around std::stringstream, should only be used
 *             when necessary for an interface.
 */
class StringStream : public StringStreamSuper
{
public:
  /**
   * Construct the StringStream for reading and writing with the stream operators << and >> 
   */
  explicit StringStream();

  /**
   * Construct the StringStream for reading and writing with the stream operators << and >> 
   *
   * @param _s initialize the StringStream with the given string
   */
  explicit StringStream(const char *_s);

  /**
   * Get a copy of the StringStream's current buffer.
   */
  CharString str();
};

// -----------------------
// --   A C H T U N G   --
// -----------------------
// mit VC++ 6.0 muss die klasse unbedingt inline implementiert werden.
//------------------------------------------------------------------------------

inline StringStream::StringStream()
: StringStreamSuper() 
{}

//------------------------------------------------------------------------------

inline StringStream::StringStream(const char *_s)
: StringStreamSuper()
{
  if (_s)
  {
    (*this) << _s;
  }
}

//------------------------------------------------------------------------------

inline CharString StringStream::str()
{
  return(CharString(StringStreamSuper::str().c_str())); 
}

#endif /* _STRINGSTREAM_H_ */
