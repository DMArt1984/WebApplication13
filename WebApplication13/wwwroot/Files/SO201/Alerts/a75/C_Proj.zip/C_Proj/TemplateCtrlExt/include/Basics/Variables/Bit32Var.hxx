#ifndef _BIT32VAR_H_
#define _BIT32VAR_H_

// VERANTWORTUNG: Johannes Ertl
// BESCHREIBUNG:  32-bit-Variable im PVSS-2.

#ifndef _VARIABLE_H_
#include <Variable.hxx>
#endif

#ifndef _CHARSTRING_H_
#include <CharString.hxx>
#endif

#ifndef _BIT32_H_
#include <Bit32.hxx>
#endif

/** The 32 bit variable. this class can hold up to 32 bit states in one object.
*/
class DLLEXP_BASICS Bit32Var : public Variable
{
  public:
    /// Constructor, sets the value to 'init'
    Bit32Var(const Bit32 &init = 0) : value(init)                       { cachedIsA = BIT32_VAR; }
	/// Copy constructor
    Bit32Var(const Bit32Var &rVal)  : Variable(rVal), value(rVal.value) { cachedIsA = BIT32_VAR; }

	/// Own allocations depending on USE_OWN_ALLOCATOR
    AllocatorDecl;

	/// Friend stream operator write into itcNdrUbSend
    friend DLLEXP_BASICS itcNdrUbSend &operator<<(itcNdrUbSend &ndrStream, const Bit32Var &bVar);
	/// Friend stream operator read from itcNdrUbReceive
    friend DLLEXP_BASICS itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream, Bit32Var &bVar);

	/// Friend stream operator write into std::ostream 
    friend DLLEXP_BASICS std::ostream &operator<<(std::ostream &os, const Bit32Var &bVar);
	/// Friend stream operator read from std::istream
    friend DLLEXP_BASICS std::istream &operator>>(std::istream &is, Bit32Var &bVar);

    /** Comparison operator
        Important: this operator checks the VariableType, so two objects are only equal, if
        they also have the same class (no conversion is done; see other operators)
    */
    virtual int operator==(const Variable &rVal) const;

    /** Comparison operator
        Important: this operator also converts the given rVal to its own class-type if needed
    */
    virtual int operator<(const Variable &rVal) const;

    /** Comparison operator
        Important: this operator also converts the given rVal to its own class-type if needed
    */
    virtual int operator>(const Variable &rVal) const;

    /// Overloaded assignment operator used for type conversions
    virtual Variable &operator=(const Variable &rVal);

    /// Assignment operator
    Bit32Var &operator=(const Bit32 &rVal);

    /// Set one bit to a new state
    void setBit(unsigned bitNr = 0, PVSSboolean val = PVSS_TRUE) {value.setBit(bitNr, val);}

    /// Get the state of one bit
    PVSSboolean getBit(unsigned bitNr = 0) const {return value.getBit(bitNr);}

    /// Checks if the object is logically true, i.e. if any bit is set
    virtual PVSSboolean isTrue() const {return ((PVSSulong) value) ? PVSS_TRUE : PVSS_FALSE;}

    /// Create a clone of the 32 bit object
    virtual Variable *clone() const {return new Bit32Var(value);}
    
    /** Returns the value as PVSSulong
	  * For compatibility don't return as Bit32
	  */
    PVSSulong getValue() const {return (PVSSulong) value;}

    /// Sets the value with Bit32
    void setValue(const Bit32 &val) {value = val;}

    /// Set the state of 32 bits according to a given ulong
    void setValue(const PVSSulong newValue) { value = newValue; }

    /// Cast operator to PVSSulong. Due to this you can use the 32 bit variable as ulong
    operator PVSSulong () const { return value; }

    /// Cast operator to Bit32
    operator const Bit32 () const { return Bit32(value); }

	/// Create new instance
    virtual Variable *allocate() const { return new Bit32Var; }

    /// Overloaded function returns variable type
    virtual VariableType isAUncached() const { return BIT32_VAR; }
	/// Overloaded function returns variable type or NOTYPE_VAR if it's another type
    virtual VariableType isAUncached(VariableType varType) const;

	/// Write to file
    virtual void outToFile(std::ostream &ofStream) const;\
	/// Read from file
    virtual void inFromFile(std::istream &ifStream);

	/** Format the value according to a format string.
        If format is an empty string, the value will be printed as
        "FALSE" or "TRUE", else a sprintf-style formatting will be used.
        @return A string representation of the value
        @param  format  The format string. It may be empty or any
                appropriate sprintf format string.
    */
    virtual CharString formatValue(const CharString &format) const;

    /** Format the value according to a format string.
        @param format The format string. If the string is not empty is is
               used as an argument to the sprintf function (if useful).
               Else a default is used.
        @param target This is a buffer with length len, which is directly written to.
               This method is more performant than the one which returns a CharString,
               because no alloc is done.
	    @param len Indicates the length of the output buffer.
        @return Number of bytes written into target without 0-byte,
                or a negative value on error (like buffer too small)
    */
    virtual int formatValue(const CharString &format, char *target, size_t len) const;

    /** Tries to convert itself to a variable out from the type to.
	   @param to  Target type
	   @param out Output variable
       @return    @retval OK - Conversion succesfull "out" is allocated
                  @retval OUT_OF_RANGE - Conversion possible but the value from "in" is
				  out of the value range of type "to" but "out" will be allocated as well
				  and contains Min or Max of the possible value range
                  @retval CONV_NOT_DEFINED - Type conversion not possible, "out" is set to 0
	*/
    virtual ConvertResult convert(VariableType to, VariablePtr &out) const;

  protected:
  private:
    /// Write to itcNdrUbSend stream
    void outNdrUb(itcNdrUbSend &ndrStream) const;
	/// Read from itcNdrUbSend stream
    void inNdrUb(itcNdrUbReceive &ndrStream);
	/// The value
    Bit32     value;
};

//------------------------------------------------------------------------------

inline Bit32Var &Bit32Var::operator=(const Bit32 & rVal)
{
  value = rVal;
  return *this;
}

//------------------------------------------------------------------------------

#endif /* _BIT32VAR_H_ */
