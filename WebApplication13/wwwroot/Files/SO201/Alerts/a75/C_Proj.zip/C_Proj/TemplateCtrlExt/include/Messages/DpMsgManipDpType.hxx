// DATEIBESCHREIBUNG ==============================================================
// DATEINAME:     DpMsgManipDpType.hxx
// VERANTWORTUNG: Johannes Ertl
// BESCHREIBUNG:  Diese Message ist zum manipulieren (anlegen, veraendern, loeschen,
//                siehe ActionType) eines DpTypes (samt Identifikation) in PVSS.
//                Sie kann sowohl als Anforderung (MsgType==DP_MSG_DPTYPE_REQ) oder
//                auch als Befehl (MsgType==DP_MSG_MANIP_DPTYPE) geschickt werden.
//                Siehe dazu Designdokument "Datenpunkt und Typen anlegen,...").
//                Folgende Daten werden geschickt:
//                - neuer Typ anlegen:
//                     Systemnummer
//                     der DpType
//                     Liste der Identifikationen (DpIdentifierItem)
//                -Typ veraendern:
//                     Systemnummer
//                     der DpType
//                     Identifikationen der neuen Typelementknoten
//                     bei einem Befehl:
//                        Liste der Datenpunkte (die den Typ haben) mit den zu
//                        loeschenden Elementnummern
//                - Typ loeschen XXX:
//                     Systemnummer
//                     DpTypeId
// SCHNITTSTELLE: Es gibt zwei Konstruktoren:
//                DpMsgManipDpType(SystemNumType,DpType,ActionType,PVSSboolean theRequest)
//                   Wenn es sich um Typanlegen oder Typaendern handelt, diesen Konstruktor verwenden.
//                DpMsgManpiDpType(SystemNumType,DpTypeId theTypeId,PVSSboolean theRequest)
//                   Wenn man einen Typen loeschen will, diesen Konstruktor verwenden
//
// AENDERUNGS-HISTORIE
// Ver.  | Datum      | Aenderungen                            | ModNr.| Autor
// ------+------------+-----------------Anfang-----------------+-------+-----------
//   1.0 |            | 1.Erstellung mit Westmount-OMT         |     0 |
// ======================================Ende======================================
#ifndef _DPMSGMANIPDPTYPE_H_
#define _DPMSGMANIPDPTYPE_H_

// Vorwaerts-Deklaration der Eigenen Klasse
class DpMsgManipDpType;

// ========== ActionType ============================================================
// Dieser enum gibt an, was mit dem uebergebenen Daten gemacht werden soll
// (neu anlegen, aendern, loeschen).
// Ein Beispiel:
// Wird in einer DpMsgManipDpType ein Typ geschickt, so kann man mit diesem enum
// angeben, ob man ihn anlegen, aendern oder loeschen soll.
enum ActionType {
  NEW_ACTION,
  CHANGE_ACTION,
  DELETE_ACTION
};

// System-Include-Files
#include <DpMsg.hxx>
#include <DpTypes.hxx>
#include <PtrList.hxx>

// Vorwaerts-Deklarationen :
class DpIdentifierItem;
class DpIdListItem;
class DpMsgManipDpType;
class DpType;
class ElIdListItem;
class Msg;

/** This message is used for manipulation (create, modify, delete) of datapoint types.
 *  It is either a request message (DP_MSG_DPTYPE_REQ) or a manipulation message
 *  (DP_MSG_MANIP_DPTYPE).
 *
 *  The following data elements are sent:
 *    - for type creation:
 *      - system number
 *      - the DpType
 *      - a list of DpIdentifierItem objects holding the names and ids
 *    - for type modification:
 *      - system number
 *      - the DpType
 *      - a list of DpIdentifierItem objects holding the names and ids of
 *        the new type element nodes
 *      - for a manipulation request:
 *        - a list of the datapoints to delete
 *    - for type deletion:
 *      - system number
 *      - DpType
 */
class DLLEXP_MESSAGES DpMsgManipDpType : public DpMsg 
{
  /// Needs to change the type.
  friend class DataManager;
  /// Write the instance into the itcNdrUbSend stream.
  friend DLLEXP_MESSAGES itcNdrUbSend &operator<<(itcNdrUbSend &ndrStream, const DpMsgManipDpType &msg);
  /// Read the instance from the itcNdrUbReceive stream.
  friend DLLEXP_MESSAGES itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream, DpMsgManipDpType &msg);

  public:
    /// Default constructor.
    DpMsgManipDpType() : request(PVSS_FALSE), action(NEW_ACTION), sysNum(0), typePtr(0) {}    
    /// Construct a create / change message.
    DpMsgManipDpType(SystemNumType theSysNum, DpType *theTypePtr, ActionType theAction, 
        PVSSboolean theRequest = PVSS_FALSE);    
    /// Construct a delete message.
    DpMsgManipDpType(SystemNumType theSysNum, DpTypeId theTypeId, PVSSboolean theRequest = PVSS_FALSE);
    /// Copy constructor.
    DpMsgManipDpType(const DpMsgManipDpType &rVal):typePtr(0){operator=(rVal);}
    /// Destructor.
    ~DpMsgManipDpType();


    // Operatoren :

    /// Comparison operator.
    int operator==(const DpMsgManipDpType &rVal) const;
    /// Comparison operator.
    virtual int operator==(const Msg &rVal) const;
    /// Assignment operator.
    DpMsgManipDpType &operator=(const DpMsgManipDpType &rVal);
    /// Assignment operator.
    virtual Msg &operator=(const Msg &rVal);

    /// changes the request message into a manipulation message
    PVSSboolean changeToManipMsg();
    /// Set new typeID.
    PVSSboolean setNewTypeId(DpTypeId theNewTypeId);

    /// Sets the names of the type.
    PVSSboolean setTypeNames(const char * const* namePtrs);

    /// Sets the names of the element.
    PVSSboolean setElementNames(DpElementId elId, const char * const* namePtrs);

    /// Adds a affected datapoint for type manipulation.
    PVSSboolean addChangedDp(DpIdType dpId);

    /// Adds a affected element for type deletion.
    PVSSboolean addDeletedEl(DpElementId elId);
    /// Get action type.
    ActionType  getActionType() const;

    /** Get type pointer.
        @return Returns NULL, if the action type is not "NEW_ACTION".
        */
    const DpType *getNewDpTypePtr(SystemNumType &theSysNum) const;
    /** Get type pointer, the caller has to take responsibility.
        @return Returns NULL, if the action type is not "NEW_ACTION".
        */
    DpType *cutNewDpTypePtr(SystemNumType &theSysNum);

    /** Get type pointer.
        @return Returns NULL, if the action type is not "CHANGE_ACTION".
        */
    const DpType *getChangedDpTypePtr(SystemNumType &theSysNum) const;
    /** Get type pointer, the caller has to take responsibility.
        @return Returns NULL, if the action type is not "CHANGE_ACTION".
        */
    DpType *cutChangedDpTypePtr(SystemNumType &theSysNum);

    /** Get type pointer.
        @return Returns NULL, if the action type is not "DELETE_ACTION".
        */
    DpTypeId getDeletedTypeId(SystemNumType &theSysNum) const;
    
    /// Get the first DpIdentifierItem.
    DpIdentifierItem *getFirstDpIdentifierItem() const;
    /// Get next DpIdentifierItem.
    DpIdentifierItem *getNextDpIdentifierItem() const;

    /// Get the first changed DP.
    DpIdType getFirstChangedDp() const;
    /// Get next changed DP.
    DpIdType getNextChangedDp() const;

    /// Get the first deleted element.
    DpElementId getFirstDeletedEl() const;
    /// Get next deleted element.
    DpElementId getNextDeletedEl() const;
    /// Check if own type matches other type.
    MsgType isA(MsgType dpMsgType) const;
    /// Get own type.
    MsgType isA() const;

    /** Check whether answer is required.
        Only request messages require an answer.
        */
    PVSSboolean needsAnswer() const;

    /// Create new instance.
    Msg *allocate() const;
    /** Get number of groups.
        This always returns 1.
        */
    virtual PVSSulong getNrOfGroups() const {return 1;}

    /** Get the group DpIdentifier.
        The returned instance has the type set.
        */
    virtual DpIdentifier getGroupId(PVSSulong) const;

    /** Print the contents of the list to an output stream.   
      Level controls the amount of debug information printed and shall be > 0.
    */
    virtual void debug(std::ostream &to, int level) const;

    // Generierte Methoden :

    /// Get the system number.
    SystemNumType getSystem() const;
    /// Get type pointer.
    const DpType *getTypePtr() const;
    /// Get type pointer.
    DpType *getTypePtr();
    /// Get type pointer and delete it.
    DpType * cutTypePtr();
    
    /// Get user ID.
    PVSSuserIdType getUserId() const { return userId; }
    /// Set user ID.
    void setUserId(PVSSuserIdType uId) { userId= uId; }
    
    // obsolete Funktionen

    /// Get the system number.
    IL_DEPRECATED("deprecated, use getSystem() instead")
    SystemNumType  getSysNum() const;

    /// Write the instance into the itcNdrUbSend stream.
    virtual void outNdrUb(itcNdrUbSend &ndrStream) const;
    /// Read the instance from the itcNdrUbReceive stream.
    virtual void inNdrUb(itcNdrUbReceive &ndrStream);

  private:
    PVSSuserIdType userId;
    PVSSboolean    request;
    ActionType     action;
    SystemNumType  sysNum;
    DpType  *typePtr;
    PtrList  dpIdentifierItemList;
    PtrList  dpIdList;
    PtrList  elIdList;
};

// ================================================================================
// Inline-Funktionen :
inline  SystemNumType DpMsgManipDpType::getSystem() const
{
  return sysNum;
}


inline  SystemNumType DpMsgManipDpType::getSysNum() const
{
  return getSystem();
}


inline const DpType * DpMsgManipDpType::getTypePtr() const
{
  return typePtr;
}


inline DpType * DpMsgManipDpType::getTypePtr()
{
  return typePtr;
}


inline  DpType * DpMsgManipDpType::cutTypePtr()
{
  DpType * tmpPtr = typePtr;
  typePtr = 0;
  return tmpPtr;
}


inline DpType * DpMsgManipDpType::cutNewDpTypePtr(SystemNumType &sys)
{
  DpType *tmpPtr = (DpType *) getNewDpTypePtr(sys);
  if (tmpPtr != 0)
    typePtr = 0;
  return tmpPtr;
}


inline DpType * DpMsgManipDpType::cutChangedDpTypePtr(SystemNumType &sys)
{
  DpType *tmpPtr = (DpType *) getChangedDpTypePtr(sys);
  if (tmpPtr != 0)
    typePtr = 0;
    
  return tmpPtr;
}


inline  ActionType DpMsgManipDpType::getActionType() const
{
  return action;
}

inline DpIdentifierItem *DpMsgManipDpType::getFirstDpIdentifierItem() const
{
  return (DpIdentifierItem *)(dpIdentifierItemList.getFirst());
}


inline DpIdentifierItem *DpMsgManipDpType::getNextDpIdentifierItem() const
{
  return (DpIdentifierItem *)(dpIdentifierItemList.getNext());
}


inline PVSSboolean DpMsgManipDpType::needsAnswer() const
{
  return request;
}


inline Msg *DpMsgManipDpType::allocate() const
{
  return new DpMsgManipDpType;
}


#endif /* _DPMSGMANIPDPTYPE_H_ */
