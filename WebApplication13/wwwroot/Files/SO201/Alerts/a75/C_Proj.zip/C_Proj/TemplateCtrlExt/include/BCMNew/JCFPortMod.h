/* %Z%JESSI-COMMON-FRAMEWORK 2.0
 * %Z%Copyright (C) by Siemens Nixdorf Informationssysteme AG 1992
 * %Z%Copyright (C) by Universitaet GH Paderborn 1992
 * %Z%Development of this software was partially funded by ESPRIT project 7364.
 * %Z%PORT %M% %I% %E%
 */
/*
*  $RCSfile$
*  $Locker$
*  $State$
*  $Source$
*/

/* This file contains the includes, inlines and defines for all
 * known portability modules. Each module is guarded against multiple 
 * occurence. 
 */

/*************** common include files   ****************/

#if defined(HAS_POSIX__) /* && defined(__cplusplus) */

# if defined(IS_AIX__)
#  define _BSD 44
# endif

# ifndef STDLIB_H
# define STDLIB_H
# include <stdlib.h>
# endif

# ifndef  STDDEF_H
# define  STDDEF_H
# include <stddef.h>
# endif

# ifndef UNISTD_H
# define UNISTD_H
# include <unistd.h>
# endif

# ifndef STRING_H
# define STRING_H
# include <string.h>
# endif
#endif /* HAS_POSIX__ */

/* ======================================================================
* the C++ compilers and the GNU C compiler 'gcc' have different notions about
* 'real' inline functions. gcc, especially, has some options how far inlining
* goes. since 'inline' is not a blessed ANSI keyword, one should use '__inline__'
* instead. so we use 'extern __inline__' for gcc; that guarantees that references
* that that could not be inlined (address of function, e.g.) are still properly
* handled by using an 'out-of-line' function instead. refer to the GNU gcc
* documentation.
*/

#ifndef INLINE__
# if defined(__cplusplus) && !defined(__GNUC__)
/* first the case for pure C++ */
#  define INLINE__ inline
# else
#  if defined(__GNUC__)
/* this is for gcc and g++ */
#   define INLINE__ inline
#  else
/* and this one for 'boring' compilers... */
#   define INLINE__
#  endif
# endif
#endif /* INLINE__ */

#ifdef IS_MSWIN__

# ifndef STDINT_H
# define STDINT_H
# include <stdint.h>
# endif

# define OS_SOCKET        SOCKET

#else

# ifndef INTTYPES_H
# define INTTYPES_H
# include <inttypes.h>
# endif

# define OS_SOCKET        int

#endif

#define INT64   int64_t
#define UINT64  uint64_t

#if defined(__cplusplus)

//# ifndef LIBC_H
//# define LIBC_H
//#ifndef IS_MSWIN__
//# include <libc.h>
//#endif
//# endif

//# ifndef OSFCN_H
//# define OSFCN_H
//#ifndef IS_MSWIN__
//# include <osfcn.h>
//#endif
//# endif

#if !defined(__HP)
# if !defined(__GNUG__)
# ifndef SYSENT_H
# define SYSENT_H
#ifndef IS_MSWIN__
//# include <sysent.h>
#endif
# endif
# endif
# endif
#endif /* __cplusplus */

/********** Beginning of the modules *********************/

/********** Module memory ********************************/

#if defined(USES_memory) && !defined(SEEN_memory__)
#define SEEN_memory__

#if defined(IS_SVR__) || defined(HAS_SVR__) || defined(IS_MSWIN__)

# ifndef  MEMORY_H
# define  MEMORY_H
# include <memory.h>
# endif

# ifndef STRING_H
# define STRING_H
# include <string.h>
# endif
#ifdef __HP
#include <stddef.h>
#endif

#endif /* IS_SVR__ */

#ifdef __cplusplus
extern "C" {
#endif
  DLLEXP_BCM int OS_bcmp(const void*, const void*, int);
  DLLEXP_BCM void OS_bcopy(const void*, void*, int);
  DLLEXP_BCM void OS_bzero(void*, int);

  DLLEXP_BCM void* OS_memcpy(void*, const void*, size_t);
  DLLEXP_BCM void* OS_memccpy(void*, const void*, int, size_t);
  DLLEXP_BCM void* OS_memchr(const void*, int, size_t);
  DLLEXP_BCM int   OS_memcmp(const void*, const void*, size_t);
  DLLEXP_BCM void* OS_memmove(void*, const void*, size_t);
  DLLEXP_BCM void* OS_memset(void*, int, size_t);
#ifdef __cplusplus
}
#endif

#if defined(IS_BSD__) 

#if defined(__cplusplus) || defined(__GNUC__) /* has inline functions */

#if defined(MISSING_BSD_PROTOS__)

#if defined(__cplusplus)
extern "C" {
#endif
   DLLEXP_BCM int bcmp(const void*, const void*, int);
   DLLEXP_BCM void bcopy(const void*, void*, int);
   DLLEXP_BCM void bzero(void*, int);
#if defined(__cplusplus)
}
#endif

#endif /* MISSING_BSD_PROTOS__ */

INLINE__ int OS_bcmp(const void* from, const void* to, int n)
    { return bcmp(from,to,n); }

INLINE__ void OS_bcopy(const void* from, void* to, int n)
    { bcopy(from, to, n); }

INLINE__ void OS_bzero(void* from, int n)
    { bzero(from, n); }

INLINE__ void* OS_memmove(void* to, const void* from, size_t n)
    { 
    #ifndef IS_MSWIN__
  bcopy(from,to,n); return to; 
    #else
  memmove(to,from,n);
    #endif
    }

#if !defined(HAS_SVR__)

INLINE__ void* OS_memcpy(void* to, const void* from, size_t n)
    { bcopy(from,to,n); return to; }

INLINE__ int OS_memcmp(const void* to, const void* from, size_t n)
    { return bcmp(from,to,n);}

#else

INLINE__ void* OS_memcpy(void* to, const void* from, size_t n)
    { return memcpy(to, from, n); }

INLINE__ void* OS_memccpy(void* to, const void* from, int c, size_t n)
    { return memccpy(to, from, c, n); }

INLINE__ int OS_memcmp(const void* to, const void* from, size_t n)
    { return memcmp(to, from, n);}

INLINE__ void* OS_memchr(const void* p, int b, size_t n)
   { return (void *)(memchr(p, b, n)); }

INLINE__ void* OS_memset(void* p, int c, size_t n)
    { return memset(p, c, n); }

#endif /* HAS_SVR__ */

#endif /* inline functions */

#endif /* IS_BSD__ */

#if defined(IS_SVR__)

#if defined(__cplusplus) || defined(__GNUC__)

#if 0
#if defined(__cplusplus)
extern "C" {
#endif
    void *memmove(void*, const void*, size_t);
#if defined(__cplusplus)
}
#endif
#endif

INLINE__ void* OS_memcpy(void* to, const void* from, size_t n)
    { return memcpy(to, from, n); }

INLINE__ void* OS_memccpy(void* to, const void* from, int c, size_t n)
    { return memccpy(to, from, c, n); }

INLINE__ void* OS_memmove(void* to, const void* from, size_t n)
    { return memmove(to, from, n); }

INLINE__ int OS_memcmp(const void* to, const void* from, size_t n)
   { return memcmp(to, from, n);}

#ifndef IS_MSWIN__
INLINE__ void* OS_memchr(const void* p, int b, size_t n)
   { return (void *)(memchr(p, b, n)); }
#else
INLINE__ void* OS_memchr(void* p, int b, size_t n)
   { return memchr(p, b, n); }
#endif

INLINE__ void* OS_memset(void* p, int c, size_t n)
   { return memset(p, c, n); }

#if !defined(HAS_BSD__)

INLINE__ int OS_bcmp(const void* from, const void* to, int n)
   { return memcmp(to, from, n); }

INLINE__ void OS_bcopy(const void* from, void* to, int n)
   { memmove(to, from, n); }

INLINE__ void OS_bzero(void* from, int n)
   { memset(from, 0, n); }

#else

#if defined(MISSING_BSD_PROTOS__)

#if defined(__cplusplus)
extern "C" {
#endif
  DLLEXP_BCM int bcmp(const void*, const void*, int);
  DLLEXP_BCM void bcopy(const void*, void*, int);
  DLLEXP_BCM void bzero(void*, int);
#if defined(__cplusplus)
}
#endif

#endif /* MISSING_BSD_PROTOS__ */
INLINE__ int OS_bcmp(const void* from, const void* to, int n)
    { return bcmp(from,to,n); }

INLINE__ void OS_bcopy(const void* from, void* to, int n)
   { bcopy(from, to, n); }

INLINE__ void OS_bzero(void* from, int n)
   { bzero(from, n); }

#endif
#endif /* __cplusplus */
#endif /* IS_SVR__ */
   
#endif /* USES_memory */

/********** Module unixio ********************************/

#if defined(USES_unixio) && !defined(SEEN_unixio__)
#define SEEN_unixio__

#ifndef  SYS_TYPES_H
#define  SYS_TYPES_H
#include <sys/types.h>
#endif
    
#ifndef  SYS_UIO_H
#define  SYS_UIO_H

#ifndef IS_MSWIN__
#include <sys/uio.h>
#else

#ifdef IS_MSWIN__
#define MAXHOSTNAMELEN 17
struct  iovec {
  char    *iov_base;
  int     iov_len;
};
#endif


#endif
#endif

#ifdef __cplusplus
extern "C" {
#endif
  DLLEXP_BCM int OS_writev(int, const struct iovec *, int);
  DLLEXP_BCM int OS_readv(int, const struct iovec *, int);
#ifdef __cplusplus
}
#endif


#endif /* USES_unixio */

/********** Module filioctl ********************************/

#if defined(USES_filiocntl) && !defined(SEEN_filiocntl)
#define SEEN_filiocntl

#ifndef  SYS_TYPES_H
#define  SYS_TYPES_H
#include <sys/types.h>
#endif

#ifndef  SYS_IOCTL_H
#define  SYS_IOCTL_H
#ifndef IS_MSWIN__
#include <sys/ioctl.h>
#endif
#endif

#ifndef  FCNTL_H
#define  FCNTL_H
#include <fcntl.h>
#endif

#ifndef  SYS_FILE_H
#define  SYS_FILE_H
#ifndef IS_MSWIN__
#include <sys/file.h>
#endif
#endif


#if !defined(IS_SVR__) && !defined(IS_SVR4__) && !defined(IS_MSWIN__) && !defined(OS_LINUX) && \
    !defined(__HP) && !defined(OS_FREEBSD) && !defined(__EMSCRIPTEN__)
# ifndef  SYS_FILIO_H
# define  SYS_FILIO_H
# include <sys/filio.h>
# endif
#endif

#ifdef __cplusplus
extern "C" {
#endif
   DLLEXP_BCM int OS_ioctl(int, int, ...);
   DLLEXP_BCM int OS_fcntl(int, int, ...);
#ifndef IS_MSWIN__
   DLLEXP_BCM int OS_ftruncate(int, off_t);
   DLLEXP_BCM int OS_truncate(const char*, off_t);
#else
   DLLEXP_BCM int OS_ftruncate(int, long);
   DLLEXP_BCM int OS_truncate(const char*, long);
#endif

#ifdef __cplusplus
}
#endif


#endif /* USES_filiocntl */

/********** Module sockets ********************************/

#if defined(USES_sockets) && !defined(SEEN_sockets__)
#define SEEN_sockets__

#ifndef  SYS_TYPES_H
#define  SYS_TYPES_H
#include <sys/types.h>
#endif
#ifndef  SYS_SOCKET_H
#define  SYS_SOCKET_H
#ifndef IS_MSWIN__
#include <sys/socket.h>
#else
#include <winsock2.h>
#include <ws2tcpip.h>
#endif
#endif

#ifndef  SYS_UN_H
#define  SYS_UN_H
#ifndef  IS_MSWIN__
#include <sys/un.h>
#else
#include "pcinc/un.h"
#endif
#endif

#ifndef  NETINET_IN_H
#define  NETINET_IN_H
#ifndef IS_MSWIN__
#include <netinet/in.h>
#endif
#endif

#ifdef  IS_MSWIN__
  enum OS_shutdown_mode
  {
    OS_SHUT_RD = SD_RECEIVE,
    OS_SHUT_WR = SD_SEND,
    OS_SHUT_RDWR = SD_BOTH
  };

  typedef unsigned long OS_socketOptions;

  #define OS_EBADF(__err__)           (__err__ == WSAEBADF)
  #define OS_ENOTSOCK(__err__)        (__err__ == WSAENOTSOCK)
  #define OS_NOTINITIALISED(__err__)  (__err__ == WSANOTINITIALISED)
    
  #define OS_EINTR(__err__)           (__err__ == WSAEINTR)
  #define OS_EWOULDBLOCK(__err__)     (__err__ == WSAEWOULDBLOCK || __err__ == WSAENOBUFS) 
  #define OS_CONNECT_RETRY(__err__)   (__err__ == WSAEWOULDBLOCK) 
#else
  enum OS_shutdown_mode
  {
    OS_SHUT_RD = SHUT_RD,
    OS_SHUT_WR = SHUT_WR,
    OS_SHUT_RDWR = SHUT_RDWR
  };

  typedef int OS_socketOptions;

  #define OS_EBADF(__err__)           (__err__ == EBADF)
  #define OS_ENOTSOCK(__err__)        (__err__ == ENOTSOCK)
  #define OS_NOTINITIALISED(__err__)  (1 == 2)              // only existst on windows

  #define OS_EINTR(__err__)         (__err__ == EINTR) 
  #define OS_EWOULDBLOCK(__err__)   (__err__ == EWOULDBLOCK)   
  #define OS_CONNECT_RETRY(__err__) (__err__ == EWOULDBLOCK || __err__ == EINPROGRESS) 
#endif

#ifdef __cplusplus
extern "C" {
#endif
  DLLEXP_BCM int OS_accept(int, struct sockaddr *, int *);
  DLLEXP_BCM int OS_bind(int, const struct sockaddr *, int);
  DLLEXP_BCM int OS_connect(int, const struct sockaddr *, int);
  DLLEXP_BCM int OS_getpeername(int, struct sockaddr *, int *);
  DLLEXP_BCM int OS_getsockname(int, struct sockaddr *, int *);
  DLLEXP_BCM int OS_getsockopt(int, int, int, char *, int *);
  DLLEXP_BCM int OS_listen(int, int);
  DLLEXP_BCM int OS_recv(int, char *, int, int);
  DLLEXP_BCM int OS_recvfrom(int, char *, int, int, struct sockaddr *, int *);
  DLLEXP_BCM int OS_send(int, const char *, int, int);
  DLLEXP_BCM int OS_sendto(int, const char *, int, int, const struct sockaddr *, int);
  DLLEXP_BCM int OS_setsockopt(int, int, int, const char *, int);
  DLLEXP_BCM int OS_socket(int, int, int);
  DLLEXP_BCM int OS_recvmsg(int, struct msghdr *, int);
  DLLEXP_BCM int OS_sendmsg(int, struct msghdr *, int);
  DLLEXP_BCM int OS_socketpair(int, int, int, int *);

  DLLEXP_BCM int OS_shutdown(int, enum OS_shutdown_mode);
  DLLEXP_BCM int OS_closesocket(int);
  DLLEXP_BCM int OS_setBlocking(int);
  DLLEXP_BCM int OS_setNonBlocking(int);
#ifdef __cplusplus
}
#endif
#endif /* USES_sockets */

/********** Module available_fds ********************************/

#if defined(USES_available_fds) && !defined(SEEN_available_fds__)
#define SEEN_available_fds__

#ifdef IS_MSWIN__
#include <winsock2.h>
#endif

#ifdef __cplusplus
extern "C" {
#endif
  DLLEXP_BCM int OS_availablefds();
#ifdef __cplusplus
}
#endif

#endif /* USES_available_fds */

/********** Module timestuff ********************************/

#if defined(USES_timestuff) && !defined(SEEN_timestuff__)
#define SEEN_timestuff__

#ifndef  SYS_TIME_H
#define  SYS_TIME_H
#ifndef IS_MSWIN__
#include <sys/time.h>
#endif
#endif
#ifndef  SYS_TIMES_H
#define  SYS_TIMES_H
#ifndef IS_MSWIN__
#include <sys/times.h>
#endif
#endif
#ifndef  TIME_H
#define  TIME_H
#include <time.h>
#endif
#ifndef  SYS_TYPES_H
#define  SYS_TYPES_H
#include <sys/types.h>
#endif

#if defined(IS_AIX__)
# ifndef SYS_SELECT
# define SYS_SELECT
# include <sys/select.h>
# endif
#endif /* IS_AIX__ */

#if defined(ultrix) && defined(bsd4_2)  /* ultrix 1.2 (vax) */
# ifndef NBBY
# define NBBY    8               /* number of bits in a byte */
# endif
# define FD_SETSIZE 64           /* two longs */
# define NFDBITS (2*NBBY*sizeof(int))

#ifndef IS_MSWIN__
# define FD_SET(n,p)    ((p)->fds_bits[(n)/NFDBITS] |= (1 << ((n) % NFDBITS)))
# define FD_CLR(n,p)    ((p)->fds_bits[(n)/NFDBITS] &= ~(1 << ((n) % NFDBITS)))
# define FD_ISSET(n,p)  ((p)->fds_bits[(n)/NFDBITS] & (1 << ((n) % NFDBITS)))
# define FD_ZERO(p)     bzero((char *)(p), sizeof (*(p)))
#endif
#endif


#ifdef IS_MSWIN__
# ifndef NBBY
# define NBBY    8               /* number of bits in a byte */
# endif
/*# define NFDBITS (2*NBBY*sizeof(int))*/
#define fds_bits fd_array
#endif

#ifdef __cplusplus
extern "C" {
#endif

#ifndef __ANDROID__
  DLLEXP_BCM int OS_adjtime(const struct timeval*, struct timeval*);
#endif
  DLLEXP_BCM int OS_getitimer(int, struct itimerval*);
  DLLEXP_BCM int OS_setitimer(int, const struct itimerval*, struct itimerval*);
  DLLEXP_BCM int OS_gettimeofday(struct timeval*, struct timezone*);
  DLLEXP_BCM int OS_settimeofday(const struct timeval*, const struct timezone*);
  DLLEXP_BCM int OS_utimes(const char*, struct timeval*);
  DLLEXP_BCM clock_t OS_times(struct tms *);
  DLLEXP_BCM int OS_select(int, fd_set*, fd_set*, fd_set*, const struct timeval*);
  DLLEXP_BCM int OS_getuptime(struct timeval *);
  DLLEXP_BCM int OS_gettimer(struct timespec *);

  struct wm_cache;
  DLLEXP_BCM int OS_wminit(struct wm_cache **wmPar);
  DLLEXP_BCM int OS_wmselect(struct wm_cache *wmPar, fd_set*, fd_set*, fd_set*, const struct timeval*);
  DLLEXP_BCM int OS_wmclosesocket(struct wm_cache *wmPar, int sockFd);
  DLLEXP_BCM int OS_wmclose(struct wm_cache **wmPar);
  DLLEXP_BCM int OS_wmabort(struct wm_cache *wmPar, int chId);
  DLLEXP_BCM int OS_wmqueryabort(struct wm_cache *wmPar);
#ifdef __cplusplus
}
#endif
#endif /* USES_timestuff */

/********** Module byteorder ********************************/

#if defined(USES_byteorder) && !defined(SEEN_byteorder__)
#define SEEN_Byteorder__

#ifndef  SYS_TYPES_H
#define  SYS_TYPES_H
#include <sys/types.h>
#endif
#ifndef  NETINET_IN_H
#define  NETINET_IN_H
#ifndef IS_MSWIN__
#include <netinet/in.h>
#endif
#endif

#ifdef __cplusplus
extern "C" {
#endif
  DLLEXP_BCM unsigned short OS_ntohs(unsigned short);
  DLLEXP_BCM unsigned short OS_htons(unsigned short);
  DLLEXP_BCM unsigned long  OS_htonl(unsigned long);
  DLLEXP_BCM unsigned long  OS_ntohl(unsigned long);
#ifdef __cplusplus
}
#endif
#endif /* USES_byteorder */

/********** Module netaddress ********************************/

#if defined(USES_netaddress) && !defined(SEEN_netaddress__)
#define SEEN_netaddress__

#ifndef NETDB_H
#define NETDB_H
#ifndef IS_MSWIN__
#include <netdb.h>
#endif
#endif

#ifndef NETINET_IN_H
#define NETINET_IN_H
#ifndef IS_MSWIN__
#include <netinet/in.h>
#endif
#endif

struct rpcent;
struct hostent;
struct netent;
struct protoent;
struct servent;

#ifdef __cplusplus
extern "C" {
#endif
  DLLEXP_BCM int               OS_gethostname(char*, int);
  DLLEXP_BCM int               OS_getdomainname(char*, int);

  DLLEXP_BCM struct hostent*   OS_gethostbyname(const char*);
  DLLEXP_BCM struct hostent*   OS_gethostbyaddr(const char*, int, int);
  DLLEXP_BCM struct hostent*   OS_gethostent();

#ifndef __ANDROID__
  DLLEXP_BCM void              OS_sethostent(int);
  DLLEXP_BCM void              OS_endhostent();
#endif
    
  DLLEXP_BCM struct netent*    OS_getnetbyname(const char*);
  DLLEXP_BCM struct netent*    OS_getnetbyaddr(long, int);
  DLLEXP_BCM struct netent*    OS_getnetent();
  DLLEXP_BCM void              OS_setnetent(int);
  DLLEXP_BCM void              OS_endnetent();

  DLLEXP_BCM struct servent*   OS_getservbyname(const char*, const char*);
  DLLEXP_BCM struct servent*   OS_getservbyport(int, const char*);
  DLLEXP_BCM struct servent*   OS_getservent();
  DLLEXP_BCM void              OS_setservent(int);
  DLLEXP_BCM void              OS_endservent();
    
  DLLEXP_BCM struct protoent*  OS_getprotobyname(const char*);
  DLLEXP_BCM struct protoent*  OS_getprotobynumber(int);
  DLLEXP_BCM struct protoent*  OS_getprotoent();
  DLLEXP_BCM void              OS_setprotoent(int);
  DLLEXP_BCM void              OS_endprotoent();

  DLLEXP_BCM int               OS_getaddrinfo(const char *hostname, const char *servname, 
                                              const struct addrinfo *hints, struct addrinfo **res);
  DLLEXP_BCM void              OS_freeaddrinfo(struct addrinfo *ai);
  DLLEXP_BCM int               OS_getnameinfo(const struct sockaddr *sa, socklen_t salen,
                                              char *host, size_t hostlen, char *serv, size_t servlen, int flags);

  DLLEXP_BCM struct rpcent*    OS_getrpcent();
  DLLEXP_BCM struct rpcent*    OS_getrpcbyname(const char *);
  DLLEXP_BCM struct rpcent*    OS_getrpcbynumber(int);
  DLLEXP_BCM void              OS_setrpcent(int);
  DLLEXP_BCM void              OS_endrpcent();

  DLLEXP_BCM unsigned long     OS_inet_addr(const char*);
  DLLEXP_BCM char*             OS_inet_ntoa(struct in_addr);
#ifndef __ANDROID__
  DLLEXP_BCM struct in_addr    OS_inet_makeaddr(int, int);
  DLLEXP_BCM unsigned long     OS_inet_network(const char*);
  DLLEXP_BCM void              OS_inet_lnaof(struct in_addr);
  DLLEXP_BCM void              OS_inet_netof(struct in_addr);
#endif
  DLLEXP_BCM const char *      OS_inet_ntop(int af, const void *src, char *dst, int size);
  DLLEXP_BCM int               OS_inet_pton(int af, const char *src, void *dst);
#ifdef __cplusplus
}
#endif
#endif /* USES_netaddress */

/********** Module signals ********************************/

#if defined(USES_signals) && !defined(SEEN_signals__)
#define SEEN_signals__

#ifndef SIGNAL_H
#define SIGNAL_H
#include <signal.h>
#endif

#ifdef __cplusplus
extern "C" {
#endif
    typedef void (*OS_SigType)(int);

    DLLEXP_BCM OS_SigType OS_signal(int, OS_SigType);
#ifdef __cplusplus
}
#endif
#endif /* USES_signals */

/********** Module strerror ********************************/

#if defined(USES_strerror) && !defined(SEEN_strerror__)
#define SEEN_strerror__

#ifndef  ERRNO_H
#define  ERRNO_H
#include <errno.h>
#endif

#ifdef IS_MSWIN__
#include <winsock2.h> // for WSAGetLastError()
#endif

#ifdef __cplusplus
extern "C" {
#endif
   DLLEXP_BCM const char *OS_getStrError(int, char *, size_t);
   DLLEXP_BCM const char *OS_strerror(int);
   DLLEXP_BCM int OS_getLastError();
#ifdef __cplusplus
}
#endif


inline int OS_getLastError()
{
#ifdef IS_MSWIN__
  return(WSAGetLastError());
#else
  return(errno);
#endif
}

#endif /* USES_sterror */

/********** Module daemons ********************************/

#if defined(USES_daemons) && !defined(SEEN_daemons__)
#define SEEN_daemons__

#ifdef __cplusplus
extern "C" {
#endif
    DLLEXP_BCM void OS_detach_from_tty();
    DLLEXP_BCM void OS_daemonize(int go_to_root);
#ifdef __cplusplus
}
#endif
#endif /* USES_daemons */

/********** Module malloc ********************************/

#if defined(USES_malloc) && !defined(SEEN_malloc__)
#define SEEN_malloc__

#if defined(IS_SVR__) || defined(HAS_SVR__) || defined(HAS_POSIX__) || defined(IS_MSWIN__)
#ifndef MALLOC_H
#define MALLOC_H
#if defined(OS_FREEBSD) || defined(__APPLE__)
#include <stdlib.h>
#else
#include <malloc.h>
#endif   // OS_FREEBSD
#endif   // MALLOC_H
#endif   // HAS_POSIX ...

#ifdef __cplusplus
extern "C" {
#endif
  DLLEXP_BCM void* OS_malloc(size_t size);
  DLLEXP_BCM void* OS_calloc(size_t nelem, size_t elsize);
  DLLEXP_BCM void* OS_realloc(void *ptr, size_t size);
  DLLEXP_BCM void OS_free(void *ptr);
#ifdef __cplusplus
}
#endif
#endif /* USES_malloc */

/************ Module fileops *************************************/

#if defined(USES_fileops) && !defined(SEEN_fileops__)
#define SEEN_fileops__

#ifndef STDIO_H
#define STDIO_H
#include <stdio.h>
#endif

#ifndef SYS_TYPES_H
#define SYS_TYPES_H
#include <sys/types.h>
#endif

#ifndef SYS_STAT_H
#define SYS_STAT_H
#include <sys/stat.h>
#endif

#ifndef FCNTL_H
#define FCNTL_H
#include <fcntl.h>
#endif

#ifndef UNISTD_H
#define UNISTD_H
#include <unistd.h>
#endif

#ifdef __cplusplus
extern "C" {
#endif
    DLLEXP_BCM size_t OS_fread(void *, size_t, size_t, FILE *); /* Sun C++ 2.1 bug! */
    DLLEXP_BCM size_t OS_fwrite(const void *, size_t, size_t, FILE *);
#ifdef __cplusplus
}
#endif
#endif /* USES_fileops */

/************** Module asciistuff ***************************/

#if defined(USES_asciistuff) && !defined(SEEN_asciistuff__)
#define SEEN_asciistuff__

#if defined(HAS_POSIX__)
# ifndef STDLIB_H
# define STDLIB_H
# include <stdlib.h>
# endif
#endif

#ifdef __cplusplus
extern "C" {
#endif
    DLLEXP_BCM double OS_atof(const char *);
    DLLEXP_BCM unsigned long OS_strtoul(const char*, char**, int); /* Sun C++ 2.1 bug ! */
    DLLEXP_BCM int OS_sprintf(char *, const char *, ...);
#ifdef __cplusplus
}
#endif

#if defined(__cplusplus) || defined(__GNUC__)


INLINE__ double OS_atof ( const char *str )
  { return atof ( (char*)str ); }

#endif /* __cplusplus */

#endif /* USES_asciistuff */
