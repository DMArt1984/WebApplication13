#ifndef INCLUDE_CONFIG_HXX
#define INCLUDE_CONFIG_HXX  // [

#include <iostream>

#include <time.h>

#include <CharString.hxx>
#include <DynPtrArray.hxx>
class QLockFile;

// ========== ConfigItem ============================================================

/** This class represents the PVSS config item
    @classification internal use
*/
class DLLEXP_BASICS ConfigItem
{
public:
  friend class UNIT_TEST_FRIEND_CLASS;
  /// type enumerator
  enum { SECTION, ENTRY, EMPTY, COMMENT, TEXT_ENTRY, BIN_ENTRY }
    type;
  
  /// sectiom  
  CharString section;

  /// host
  CharString host;

  /// key value
  CharString key;

  /// vconfig alue
  CharString value;

  /// comment
  CharString comment;

  /// search flag
  int searchFlag; 
};


#ifdef WIN32
# pragma warning ( push )
# pragma warning ( disable: 4231 )
#endif

#if defined(LIBS_AS_DLL)
  EXTERN_BASICS template class DLLEXP_BASICS DynPtrArray<ConfigItem>;
#endif

#ifdef WIN32
# pragma warning ( pop )
#endif

// ========== Config ============================================================

/** This class handles the PVSS Config file, 
    reads config file into internal structure to search for keys, 
    modifies internal and writes back to file.
*/
class DLLEXP_BASICS Config
{
public: 
  friend class UNIT_TEST_FRIEND_CLASS;
  /// enumerator of insert operations
  enum
  {
    START_SECTION     = 1,
    END_SECTION       = 2,
    // BEFORE_KEY        = 3,    // not for future use
    BEFORE_FIRST_KEY  = 3,
    AFTER_FIRST_KEY   = 4,
    // AFTER_KEY         = 5,    // not for future use
    AFTER_LAST_KEY    = 5,
    BEFORE_LAST_KEY   = 6,
    BEFORE_VALUE      = 7,
    AFTER_VALUE       = 8
  };

  /// enumerator of errors
  enum
  {
    E_CFG_FILE_NOT_FOUND = 20,
    E_CFG_REG_NOT_FOUND,
    E_CFG_INT_OVERFLOW,
    E_CFG_ILL_PARAM,
    E_CFG_FILE_ERROR,
    E_CFG_REG_ERROR,
    E_CFG_NOT_FOUND,
    E_CFG_CONFIG_SYNTAX,
    E_CFG_CONFIG_NOT_OPEN,
    E_CFG_CONFIG_OPEN,
    E_CFG_NO_SECTION,
    E_CFG_ALREADY_LOCKED,
    E_CFG_LOCK_ERROR,
    E_CFG_NOT_LOCKED,
    E_CFG_UNLOCK_ERROR
  };

  /// configuration lock suffix
  static const char* CFG_LOCK_SUFFIX;


  /// constructor, config filename will be taken from the enviroment (PVSS_II)
  /// @param debugWorkFlag the flag analogical to PVSS: 2 (DBG_WORK)
  Config( int debugWorkFlag = 0 );

  /// constructor
  /// @param cfgName the config filename is either the config file itself or the project installation directory
  /// @param debugWorkFlag the flag analogical to PVSS: 2 (DBG_WORK)
  Config( const CharString cfgName, int debugWorkFlag = 0 );

  /// destructor
  ~Config();

  /** change the filename of config object
      @param name the new filename
      @return: 0 - OK
               E_CFG_ALREADY_LOCKED - if locked, you may not change the filename!
  */
  int setFileName( const CharString &name );
  
  /** get the filename of config object
      @return the filename
  */
  CharString getFileName( ) const { return( configName_ );  };
  
  /** open and load the file into internal structure 
      @param mode the mode 'r' or 'w' or 'g' for read, write or generate
      @return: 0 on success
               E_CFG_FILE_NOT_FOUND - specified config file not found
               E_CFG_FILE_ERROR - no filename or specified config file couldn't be opened for some reason
               E_CFG_CONFIG_OPEN - file is already open
               E_CFG_CONFIG_SYNTAX - the data couldn't be read 
  */
  int open( int mode = 'r' );      // alternate: 'w'
  
  /** return wether the file was modified since last access
      @return: false - if file was not changed
               true - if file was changed, reread is necessary
  */
  bool fileHasChanged( );
  
  /** finish open action
      @n After read option internal data are simply removed, 
      after write option data are written to config file. Original file
      is left in .bak.
      @param abort the abort flag, if true, nothing is written
      @return: 0 on success
               E_CFG_CONFIG_NOT_OPEN - file was not opened
               E_CFG_FILE_ERROR - move or write operation failed
              
  */
  int close( bool abort = false );

  /** flush data
      @n After write action data are written to config file. Original file
      is left in .bak, config file keeps open.
      @return: 0 on success
               E_CFG_CONFIG_NOT_OPEN - file was not opened
               E_CFG_FILE_ERROR - move or write operation failed
  */
  int flush( bool abort = false, bool close = false );

  /** lock the config file using QT lockfile method
      @return: 0 on success
               E_CFG_ALREADY_LOCKED - file can not be locked newly
               E_CFG_LOCK_ERROR - no lock possible
  */
  int lock();

  /** unlock the config file using QT lockfile method
      @return: 0 on success
               E_CFG_NOT_LOCKED - file was not previously locked
  */
  int unlock();

  /** return wether the config file is actually locked
      @return true - if locked
              false - if not
  */
  bool isLocked() const { return( isLocked_ ); };

  /** @name Navigation
    */
  //@{

  /** check wether config file was opened
      @return: true - if was opened
               false - if not
  */
  bool isOpen( int mode = 'r' ) const;

  /** set actual line to the first position
  */
  void first() const;

  /** set actual line to the next position, skip empty lines
  */
  void next() const;

  /** set actual line to the previous position, skip empty lines
  */
  void prev() const;

  /** set actual line to the last position
  */
  void last() const;

  //@}

  /** @name Read & find functions
    */
  //@{

  /** return the last read section
      @return the last read section (with braces "[]")
  */
  CharString actSection() const;  // with '[',']'

  /** check if the last read section
      @param section the section to compare with (with and without braces "[]")
      @return: true - if sections match
               false - if not
  */
  bool isSection( CharString section ) const;


  /** read actual line and return key and value 
      @param key the keyword
          @n If section, then with "[]", and there is no value.
      @param value the value as string (regardless of original type)
      @return: 0 on success
               E_CFG_CONFIG_NOT_OPEN - file was not opened
               E_CFG_NOT_FOUND - no matching line found
  */
  int read ( CharString &key, CharString &value ) const;

  /** read actual line and return host, key and value
      @param host the hostname (without "()")
      @param key the keyword
          @n If section, then with "[]", and there is no value.
      @param value the value as string (regardless of original type)
      @return: 0 on success
               E_CFG_CONFIG_NOT_OPEN - file was not opened
               E_CFG_NOT_FOUND - no matching line found
  */
  int read ( CharString &host, CharString &key, CharString &value ) const;

  /** read actual line and return host, key, value and comment
      @param host the hostname (without "()")
      @param key the keyword
          @n If section, then with "[]", and there is no value.
      @param value the value as string (regardless of original type)
      @param comment the comment of the file (all text after "#")
      @return: 0 on success
               E_CFG_CONFIG_NOT_OPEN - file was not opened
               E_CFG_NOT_FOUND - no matching line found
  */
  int read ( CharString &host, CharString &key, CharString &value, CharString &comment ) const;

  /** look for the first section, host and key and return value
      @param section the section (without "[]")
      @param host the hostname (without "()")
      @param key the keyword
      @param value the value returned as string (regardless of original type)
      @return: 0 on success
               E_CFG_CONFIG_NOT_OPEN - file was not opened
               E_CFG_NOT_FOUND - no matching line found
  */
  int findValue ( const CharString &section, const CharString &host, const CharString &key, CharString &value ) const;

  /** look for the last section, host and key and return value
      @param section the section (without "[]")
      @param host the hostname (without "()")
      @param key the keyword
      @param value the value returned as string (regardless of original type)
      @return: 0 on success
               E_CFG_CONFIG1_NOT_OPEN - file was not opened
               E_CFG_NOT_FOUND - no matching line found
  */
  int findValueReverse ( const CharString &section, const CharString &host, const CharString &key, CharString &value ) const;

  /** look for the first section, host, key and value and put actual line marker there
      @n If just to look for a section, take only first param.
      @n Start for lookup loop is the actual line (the last successfull search).
      @param section the section (without "[]"), "" by default
      @param host the hostname (without "()"), "" by default
      @param key the keyword, "" by default
      @param value the value as string (regardless of original type)
      @return: 0 fitting line was found
               E_CFG_NOT_FOUND - no matching line found
  */
  int find ( CharString section, CharString host = CharString(), CharString key = CharString(), CharString value = CharString()) const;

  /** look for the last section, host, key and value and put actual line marker there
      @n If just to look for a section, take only first param.
      @n Start for lookup loop is the actual line (the last successfull search).
      @n If actual line doesn't fit, it looks for the previous ('reverse') line.
      @param section the section (without "[]"), "" by default
      @param host the hostname (without "()"), "" by default
      @param key the keyword, "" by default
      @param value the value as string (regardless of original type)
      @return: 0 fitting line was found
               E_CFG_NOT_FOUND - no matching line found
  */
  int findReverse ( CharString section, CharString host = CharString(), CharString key = CharString(), CharString value = CharString()) const;

  /** go forward from actual line until the next section is reached
      @n A similar goal can be reached using find for a defined section.
      @see find
      @return: the section that was found
               "" if no more section was found
  */
  CharString readNextSection() const;

  /** remove specified section(s) including all key/value pairs
      @return: 0 on success
               E_CFG_NOT_FOUND if no section was found
  */
  int removeSection( const CharString &section );

  //@}

  /** @name Write functions
    */
  //@{

  /// All write operations work with internal cache (dynPtrArray)
  /// and data will be witten to the file by close operation. Original will be
  /// written for testing purposes to .bak.

  /** insert line into internal buffer of config file
      @param section the section where to put new line
      @param host the hostname, "" if not applicable
      @param key the key, it must be entered
      @param value the value, it must be entered, valid types are CharString, int and double
      @param op the operation
          @n Possible values are:
          @n START_/END_SECTION - insert at the beginning/end of given section
          @n BEFORE_/AFTER_KEY - insert before/after given key
          @n BEFORE_/AFTER_VALUE - insert before/after given key/value pair
      @param refValue the reference value needed for operations BEFORE_/AFTER_KEY or BEFORE_/AFTER_VALUE
      @return: 0 on success
               E_CFG_NOT_FOUND - one or more sections, keys or reference values were not found
               E_CFG_CONFIG_NOT_OPEN - config file wasn't opened for write
  */
  int insert ( CharString section, CharString host, CharString key, CharString value, int op = START_SECTION, CharString refValue = CharString() );
  int insert ( CharString section, CharString host, CharString key, int value, int op = START_SECTION, int refValue = 0 );
  int insert ( CharString section, CharString host, CharString key, int value, int op, CharString refValue );
  int insert ( CharString section, CharString host, CharString key, double value, int op = START_SECTION, double refValue = 0.0 );
  int insert ( CharString section, CharString host, CharString key, double value, int op, CharString refValue );
  //@}

  /** remove actual key/value pair (line)
      @n If there is empty value (only at CharString), then all lines of  
         the section and key will be deleted.
      @n If there is empty section (only at CharString), then all lines of  
         the key and value will be deleted.
      @n If there is empty section and value (only at CharString), then all lines of  
         the key will be deleted.
      @return 0 on success
              E_CFG_NOT_FOUND - if there is no actual line 
              
  */
  int remove(); // loescht die aktuelle Zeile

  /** comment one actual key/value pair (line)
      @return: 0 on success
               E_CFG_NOT_FOUND - if there is no actual line 
  */
  int commentLine(); // Kommentiert die aktuelle Zeile aus

  /** remove line previously found by find()
      @see find()
      @return: 0 on success
               E_CFG_NOT_FOUND - if line not found
              
  */
  int remove( CharString section, CharString host, CharString key, CharString value = CharString() );
  int remove( CharString section, CharString host, CharString key, int value );
  int remove( CharString section, CharString host, CharString key, double value );

  /** replace the value of the actual key/value pair (line), any comment of that line is removed'
      @see find()
      @return: 0 on success
              E_CFG_NOT_FOUND - if there is no actual line 
  */
  int replace( CharString valNew );  // aktuelle Zeile

  /** replaces line previously found by find(), any comment of that line is removed
      @see find()
      @return: 0 on success
               E_CFG_NOT_FOUND if line could not found
              
  */
  int replace( CharString section, CharString host, CharString key, CharString valOld, CharString valNew );
  int replace( CharString section, CharString host, CharString key, int valOld, int valNew );
  int replace( CharString section, CharString host, CharString key, double valOld, double valNew );

  /** set switch for use of lock file used in method ::flush()
      default for use is true
  */
  static void useLockFile( bool useIt );   // IM 105277 f. WebCLient

  /** get filename of lockfile for error message purpose
      @return: name of lockfile 
  */
  // IM 112806 WOKL 9.10.13
  CharString getLockFileName() const;

private:
  // not for use
  Config( Config &ref );

  /// Lese- und Schreib-funktionen 
  int readFile(std::istream &cfgIStream);
  int writeItem( const ConfigItem &item, std::ostream &cfgOStream );
  int writeFile(std::ostream &cfgOStream);

  /// interne insert-Funktionskapsel
  int insert( ConfigItem *itemPtr, int op = START_SECTION, CharString refValue = CharString() );

  /// zum eigenen Sortieren
  int compareCfgItems(const ConfigItem *li1, const ConfigItem *li2) const;

  /// interne Lesepruefung
  bool locScanf( char *line, ConfigItem &itemPtr );

  // private members
  CharString configName_;

  bool  debugWorkFlag_;
  char  openMode_;      // 'r', 'w' or '\0'
  bool  isLocked_;
  time_t  mTime_;         // modification time when read

  QLockFile *lockFile_;

  DynPtrArray<ConfigItem> data_;
};

// Inlines ---------------------------------------------------

#endif // INCLUDE_CONFIG_HXX ]

