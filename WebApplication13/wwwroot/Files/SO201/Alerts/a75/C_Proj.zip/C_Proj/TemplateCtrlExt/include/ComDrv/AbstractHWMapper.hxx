#ifndef _ABSTRACTHWMAPPER_HXX
#define _ABSTRACTHWMAPPER_HXX

#ifndef _HWMAPPADP_H_
#include <HWMapDpPa.hxx>
#endif

#ifndef _HWOBJECT_H_
#include <HWObject.hxx>
#endif

#ifndef _DPPERIPHADDR_H_
#include <PeriphAddr.hxx>
#endif

#ifndef _DPIDENTIFIER_H_
#include <DpIdentifier.hxx>
#endif

/** Abstract class - tool for handling with HW objects
    @classification public use
*/
class AbstractHWMapper
{
public:

  /** Constructor
      */
    AbstractHWMapper() {}

    /** Destructor
      */
    virtual ~AbstractHWMapper() {}

  /** Add new dpId with config. this is a sorted insert algorhithm.
    * @param dpId the new dpIdentifier
    * @param confPtr the new config entry; this object is captured by the list
    * @return PVSS_TRUE on success
    * @classification ETM internal
    */
  virtual  PVSSboolean  addDpPa(DpIdentifier& dpId, PeriphAddr *confPtr) = 0;
  
  /** Add new HWObject in a sorted manner.
    * @param objPtr an object derived from HWObject with all needed HW information; this object is captured by the list
    * @return PVSS_TRUE on success
    * @classification public use, overload
    */
  virtual PVSSboolean          addHWObject(HWObject *objPtr) = 0;
  
  /** Remove a HWMapDpPa entry from the list.
    * @param dpId the dpIdentifier to search for
    * @param confPtr the config to search for
    * @return PVSS_TRUE if found and deleted, else PVSS_FALSE
    * @classification ETM internal
    */
  virtual  PVSSboolean  clrDpPa(DpIdentifier& dpId, PeriphAddr *confPtr) = 0;

  /** Find a HWObject and remove it from the list. the HWObject is not deleted
    * since there is the possibility of external reference to this object. the caller of this
    * function is responsible for deleting the removed object.
    * @param objPtr the object which to search for - PeriphAddr and HW addr are compared
    * @return PVSS_TRUE if the object is found, otherwise PVSS_FALSE
    * @classification ETM internal
    */
  virtual PVSSboolean          clrHWObject(HWObject *objPtr) = 0;

  /** Clear all registered HWObjects. the HWObjects are deleted by this function.
    * @classification ETM internal
    */
  virtual void                 delHWObjects() = 0;
  
  /** Searches for all DpPa objects for a given HW address.
    * @param hwAdr HWObject containing a known PeriphAddr string
    * @return the index of the first DpPa object matching the PeriphAddr
    * @classification ETM internal
    */ 
  virtual HWMapDpPa * getFirstMatch(HWObject *hwAdr) = 0;

  /** Searches for all DpPa objects for a given HW address.
    * @param hwAdr HWObject containing a known PeriphAddr string
    * @return the index of the next DpPa object matching the PeriphAddr
    * @classification ETM internal
    */ 
  virtual HWMapDpPa * getNextMatch(HWObject *hwAdr) = 0;
  
  /** Searches for all DpPa objects for a given DpId.
    * caution: do not mix with getFirst(), getNext() because they use the same iterator.
    * @param dpId contains a DpIdentifier
    * @return the index of the first DpPa object matching the dpId
    * @classification ETM internal
    */ 
  virtual HWMapDpPa * getFirstMatch(const DpIdentifier &dpId) = 0;

  /** Searches for all DpPa objects for a given DpId.
    * caution: do not mix with getFirst(), getNext() because they use the same iterator.
    * @param dpId contains a DpIdentifier
    * @return the index of the next DpPa object matching the dpId
    * @classification ETM internal
    */ 
  virtual HWMapDpPa * getNextMatch(const DpIdentifier &dpId) = 0;

  /** This is the standard iterator (First) over HWMapDpPa objects in DpId order.
    * this function reuses the DpIdentifier iterator!
    * @return the corresponding objects
    * @classification ETM internal
    */
  virtual HWMapDpPa *getFirstDpPa() = 0;

  /** This is the standard iterator (Next) over HWMapDpPa objects in DpId order.
    * this function reuses the DpIdentifier iterator!
    * @return the corresponding objects
    * @classification ETM internal
    */
  virtual HWMapDpPa *getNextDpPa() = 0;

  /** This function searches for an entry in the HW list matching the
    * given hardware address.  This function does not change the iterator.
    * @param hwAdr derived HWObject which holds the hardware address for incoming data
    * @return HWObject from the mapper which holds the corresponding PeriphAddr
    * @classification public use, call 
    */
  virtual HWObject*            findHWObject(HWObject* hwAdr) = 0;

  /** This functions returns a given entry in the HW list sorted by 
    * hardware address.
    * @param hwAdr derived HWObject which holds the hardware address
    * @return the HWObject at the specified position in the HW list (First).
    */
  virtual HWObject *             getFirstHWObjMatch(HWObject *hwAdr) = 0;

  /** This functions returns a given entry in the HW list sorted by 
    * hardware address.
    * @param hwAdr derived HWObject which holds the hardware address
    * @return the HWObject at the specified position in the HW list (Next).
    */
  virtual HWObject *             getNextHWObjMatch(HWObject *hwAdr) = 0;

  /** Iterate through all HWObjects sorted by hardware address.
    * @return the HWObject at the first position in the HW list.
    */
  virtual HWObject *             getFirstHWObj() = 0;

  /** Iterate through all HWObjects sorted by hardware address.
    * @return the HWObject at the next position in the HW list.
    */
  virtual HWObject *             getNextHWObj() = 0;

  /** This function searches for an entry in the HW list matching the
    * given periph address. This function does not change the iterator.
    * @param adrObj HWObject which holds the periph address for outgoing data
    * @return derived HWObject from the mapper which holds the corresponding HW address
    * @classification public use, call 
    */
  virtual HWObject*            findHWAddr(HWObject* adrObj) = 0;

  /** This function returns a given entry in the HW list sorted by periph
    * address.
    * @param hwAdr derived HWObject which holds the hardware address
    * @return the HWObject at the specified position (First)
    */
  virtual HWObject *             getFirstHWAdrMatch(HWObject *hwAdr) = 0;

  /** This function returns a given entry in the HW list sorted by periph
    * address.
    * @param hwAdr derived HWObject which holds the hardware address
    * @return the HWObject at the specified position (Next)
    */
  virtual HWObject *             getNextHWAdrMatch(HWObject *hwAdr) = 0;

  /** Search first hardware components according to given hardware address.
    * this function uses the compare_HWcomponent() function.
    * @param hwAdr derived HWObject containing a valid hardware address
    * @return first stored HWObject for this hardware component
    * @classification ETM internal
    */
  virtual HWObject *             getFirstComponentMatch(HWObject *hwAdr) = 0;

  /** Search next hardware components according to given hardware address.
    * this function uses the compare_HWcomponent() function.
    * @param hwAdr derived HWObject containing a valid hardware address
    * @return next stored HWObject for this hardware component
    * @classification ETM internal
    */
  virtual HWObject *             getNextComponentMatch(HWObject *hwAdr) = 0;

  /** Search first hardware components according to given hardware address.
    * this function uses the compare_HWcomponent2() function.
    * @param hwAdr derived HWObject containing a valid hardware address
  * @return first stored HWObject for this hardware component
    * @classification ETM internal
    */
  virtual HWObject *             getFirstComponent2Match(HWObject *hwAdr) = 0;

  /** Search next hardware components according to given hardware address.
    * this function uses the compare_HWcomponent2() function.
    * @param hwAdr derived HWObject containing a valid hardware address
  * @return next stored HWObject for this hardware component
    * @classification ETM internal
    */
  virtual HWObject *             getNextComponent2Match(HWObject *hwAdr) = 0;

  /** Search first hardware components according to given connection id.
    * @param hwAdr derived HWObject containing a valid connection id
    * @return first stored HWObject for this hardware component
    * @classification ETM internal
    */
  virtual HWObject *             getFirstConnectionMatch(HWObject *hwAdr) = 0;

  /** Search next hardware components according to given connection id.
    * @param hwAdr derived HWObject containing a valid connection
    * @return next stored HWObject for this hardware component
    * @classification ETM internal
    */
  virtual HWObject *             getNextConnectionMatch(HWObject *hwAdr) = 0;

  /** Get the number of stored datapoints.
    * @return number of datapoints in mapper
    * @classification public use, call
    */
  virtual PVSSlong             getNumberOfDpIds() const = 0;

  /** Get the config for a specific dpId
    * @param dpId is a DpIdentifier.
    * @return config on that index or 0 if dpId was not found
    * @classification public use, call
    */
  virtual PeriphAddr*          getConfigPtr(DpIdentifier const &dpId) = 0;

  /** The purpose of this function is the adjustment of the transformation objects
    * to match either the HWObject side or the pvss2 side type of the data to transform.
    * It is also used to check whether or not a specific periph address or hardware address is known
    * by the driver. The third purpose is to adjust a newly created HWObject with the preset values 
    * from the HWObject template in the mapper (i.e. datalen, nofElements, periphAddr,...)
    * @param dpId the datapoint concerned
    * @param confPtr pointer to the config with actual subix
    * @param hwaPtr pointer to HWObject which should contain the data
    * @param fConfPtr pointer to the config with subix 0
    * @return PVSS_TRUE if object is found and adjustment was succesful, otherwise PVSS_FALSE
    * @classification public use, overload
    */
  virtual PVSSboolean  actualize(DpIdentifier& dpId, PeriphAddr *confPtr, HWObject *hwaPtr, PeriphAddr *fConfPtr) = 0;

  /** When a datapoint is deleted, his config entries are removed, too.
    * @param dpNum the internal datapoint number
    * @classification ETM internal
    */
  virtual void  deleteDpPaByDpNumber(const DpIdType &dpNum) = 0;

  /** Debug function. Print all registered HWObjects
    * sorted by hardware address
    * @classification public use, call
    */
  virtual void  debugPrintHWObjects() = 0;

  /** Debug function. Print all registered HWMapDpPa objects
    * @classification public use, call
    */
  virtual void  debugPrintHWMapDpPa() = 0;

  /** Compare the registered HWMapDpPa instances against
    * a given mask and update the internal driver DP.
    * @param pa mask to match against the registered periphaddr strings.
    * @classification ETM internal
    */
  virtual void reportDpPa(const CharString & pa) = 0;

  /** Compare the registered HWObject instances against
    * a given mask and update the internal driver DP.
    * @param pa mask to match against the registered periphaddr strings.
    * @classification ETM internal
    */
  virtual void reportHWObjects(const CharString & pa) = 0;
  
  /** Compare HWMapDpPa against a given mask;
    * the comparison looks at the periphaddress string. 
    * it uses the compare_PaMatch() function
    * @param mask a wildcard mask to match against the registered periphaddress strings.
    * @param conn optional connection id
    * @return pointer to first object or 0 if not found
    * @classification public use, call
    */
  virtual PeriphAddr *getFirstHWMatch(const char *mask, DpIdType conn = 0) = 0;        // used for doPVSSGQ

  /** Compare HWMapDpPa against a given mask;
    * the comparison looks at the periphaddress string. 
    * it uses the compare_PaMatch() function
    * @param mask a wildcard mask to match against the registered periphaddress strings.
    * @param conn optional connection id
    * @return pointer to to next object or 0 if not found
    * @classification public use, call
    */
  virtual PeriphAddr *getNextHWMatch (const char *mask, DpIdType conn = 0) = 0;

  /** Compare two HW objects; 
    * the comparison looks at the hardware address.
    * this function has to be overloaded for derived drivers.
    * @param obj1 first HW object
    * @param obj2 second HW object
    * @return -1 if o1 < o2, 0 if o1 == o2 or +1 if o1 > o2
    * @classification public use, overload
    */
  virtual int compare_HWHW(const HWObject* obj1, const HWObject* obj2) = 0;
  
  /** Compare two HW objects; 
    * The comparison looks at the component specific part of hardware address.
    * This function has to be overloaded for derived drivers.
    * @param obj1 first HW object
    * @param obj2 second HW object
    * @return -1 if o1 < o2, 0 if o1 == o2 or +1 if o1 > o2
    * @classification public use, overload
    */
  virtual int compare_HWcomponent(const HWObject* obj1, const HWObject* obj2) = 0;

  /** Second version of compare_HWcomponent for future use
    * the comparison looks at the component specific part of hardware address.
    * this function has to be overloaded for derived drivers.
    * @param obj1 first HW object
    * @param obj2 second HW object
    * @return -1 if o1 < o2, 0 if o1 == o2 or +1 if o1 > o2
    * @classification public use, overload
    */
  virtual int compare_HWcomponent2(const HWObject* obj1, const HWObject* obj2) = 0;

  /** Get number of address HWObjects in the HWMapper
      @return number of address
    */
  virtual PVSSlong getHwaCnt() = 0;

protected:
  
  /** Compare the periphAdr string against a pattern, i.e. a string with wildcards.
    * This function is used in getFirstHWMatch and getNextHWMatch.
    * You may use PatternMatch::patternMatch to perform the actual match.
    * @param ptr The HWMapDpPa object with the PeriphAddr config
    * @param pattern The pattern to match against
    * @return PVSS_TRUE if the pattern matches, else PVSS_FALSE
    * @classification public use, overload
    */
  virtual PVSSboolean  compare_PaMatch(HWMapDpPa *ptr, const char *pattern) = 0;
  
  /** Compare the address string in a HWObject against a pattern, i.e. a string
    * with wildcards. This function is used in reportHWObjects.
    * You may use PatternMatch::patternMatch to perform the actual match.
    * @param ptr The HWObject to be compared
    * @param pattern The pattern to match against
    * @return PVSS_TRUE if the pattern matches, else PVSS_FALSE
    * @classification public use, overload
    */
  virtual PVSSboolean  compare_HWMatch(HWObject *ptr, const char *pattern) = 0;

  /** compare the connectionIds
    * the comparison looks at the component specific part of hardware address.
    * this function has to be overloaded for derived drivers.
    * @param obj1 first HW object
    * @param obj2 second HW object
    * @return -1 if o1 < o2, 0 if o1 == o2 or +1 if o1 > o2
    * @classification public use, overload
    */
  virtual int compare_connection(const HWObject* obj1, const HWObject* obj2) = 0;

};

#endif
