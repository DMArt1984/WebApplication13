#ifndef _NOTIFICATIONOBJECT_H_
#define _NOTIFICATIONOBJECT_H_

/*
VERANTWORTUNG: Heinz Meissl          
BESCHREIBUNG: Abstract base class. DpConfig may hold a reference to a
NotificationObject. On destruction of the DpConfig the NotificationObject
will be deleted and may perform a notification task, like checking out a
control script.
*/

class DLLEXP_CONFIGS NotificationObject
{
  public:
  NotificationObject() {};
  virtual ~NotificationObject() {};

  protected:

  private:
};

#endif /* _NOTIFICATIONOBJECT_H_ */
