#ifndef _CTRLSMENT_H_
#define _CTRLSMENT_H_

#include <PTreeNode.hxx>
#include <SmentWeight.hxx>
#include <iostream>

class CtrlExpr;
class CtrlThread;
class CharString;

/*  author VERANTWORTUNG: Martin Koller */
/** abstract base-class for all statements
    @classification internal use
*/

class DLLEXP_CTRL CtrlSment : public PTreeNode
{
  public:
    /** Construct a new statement.
        This constructor is called from the parser.
        @param line The current line number
        @param file The current ctrl lib or -1 if in a script in a panel.
      */
    CtrlSment(int line = -1, int file = -1) : PTreeNode(line, file), next(0) { }

    /// wird von jedem Statement implementiert
    virtual const CtrlSment *execute(CtrlThread *thread) const = 0;

    /** @return NULL | naechstes CtrlSment */
    CtrlSment *getNext() const { return next; }

    virtual const CtrlSment *getNext(CtrlThread *) const { return next; }

    /// beim Parsen einhaengen des naechsten CtrlSment
    virtual void setNext(CtrlSment *n) { next = n; }

    /// Gewichtung des CtrlSment
    virtual SmentWeight getWeight() const { return SM_WT_None; }

    /// Get the first argument for this statement
    virtual const CtrlExpr *getFirstExpr(CtrlThread *) const { return nullptr; }

    /// Syntax check
    virtual bool checkIntegrity(const CharString &location, CtrlThread *) const { return true; }

    ///
    enum SmentType
    {
      ///
      SMENT,
      ///
      SMENT_EXPR,
      ///
      SMENT_LIST,
      ///
      SMENT_SWITCH,
      ///
      SMENT_LOOP,
      ///
      SMENT_FCALL,
      ///
      SMENT_IF,
      ///
      SMENT_BREAK,
      ///
      SMENT_CONTINUE,
      ///
      SMENT_RETURN,
      ///
      SMENT_TRY,
      ///
      SMENT_VARLIST
    };

    /// Evaluate the type of this statement. Returns 1 if type is SMENT.
    virtual int isA(SmentType type) const;

    // synchronized access
    virtual void setSynchronized(CtrlExpr *)  {}
    virtual bool isSynchronized(CtrlThread *) const { return false; }

    virtual bool lock(CtrlThread *t) const { return true; }
    virtual bool unlock(CtrlThread *t) const { return true; }
    virtual bool isLocked(CtrlThread *t) const { return false; }
    virtual CtrlThread *getCurrentThread(CtrlThread *t) const { return nullptr; }

    /** Write Sment specific Trace
      * @param thread     current Thread
      * @param writeValue true : If Expr is a Variable write the value
      *                   false:                       write the name of the variable
    */
    virtual void writeTrace(CtrlThread *thread, bool writeValue = true) const { };

    /** dump the whole tree for code coverage analysis
        This method also prints the execution counter
        @param to output stream
      */
    virtual void dumpCoverageTree(std::ostream &to, CoverageAction action = DUMP) const;

  protected:
    CtrlSment *next;
};

#endif /* _CTRLSMENT_H_ */
