// DATEIBESCHREIBUNG ==============================================================
// DATEINAME:     DpIdentifierItem.hxx
// VERANTWORTUNG: Johannes Ertl
// BESCHREIBUNG:  Dieses Item kann verschiedene Identifier (inklusive ihrer
//                              Bezeichner in mehreren Sprachen) schicken. Welche das
//                sein koennen wird im DpIdentifierItemType festgelegt.
//                Fuer jeden DpIdentifierItemType gibt es einen entsprechenden
//                Konstruktor (macht kopien von den NamePtrs!) und getXXXNames-
//                Funktionen die die entsprechenden Daten liefern. Die getXXXNames
//                Funktionen liefern den Pointer auf den NamePtrs oder 0, wenn
//                der DpIdentifierItemType nicht XXX entspricht (Bsp: 
//                getDatapointNames liefert 0, wenn es sich um einen Systemnamen
//                handelt).
// ERWEITERUNGEN: Fuer jeden neuen DpIdentifierItemType neuen Konstruktor und neue
//                getXXNames Funktion!
// ======================================Ende======================================
#ifndef _DPIDENTIFIERITEM_H_
#define _DPIDENTIFIERITEM_H_

// Vorwaerts-Deklaration der Eigenen Klasse
class DpIdentifierItem;

// ========== DpIdentifierItemType ============================================================
// Im DpIdentifierItem koennen verschiedene Identifier geschickt
enum DpIdentifierItemType {
  IDENTIFIERITEM_NONE,
  IDENTIFIERITEM_ALIASNAME,
  IDENTIFIERITEM_SYSNAME,
  IDENTIFIERITEM_TYPENAME,
  IDENTIFIERITEM_DPNAME,
  IDENTIFIERITEM_ELNAME,
  IDENTIFIERITEM_CFNAME,
  IDENTIFIERITEM_DTNAME,
  IDENTIFIERITEM_ATNAME,
  IDENTIFIERITEM_CNS
};

// System-Include-Files
#include <DpTypes.hxx>
#include <PtrListItem.hxx>
#include <DpIdentifier.hxx>
#include <LangText.hxx>
#include <CharString.hxx>
#include <Resources.hxx>
#include <CNSDataIdentifier.hxx>

#include <ostream>

class itcNdrUbSend;
class itcNdrUbReceive;

/** This item holds an identifier and its description, possibly in multiple languages.
 *  What identifier an instance holds is defined by the pair isA() and setItemType().
 *  There are special constructors for each DpIdentifierItemType and corresponding
 *  description getter methods.
 */
class DLLEXP_MESSAGES DpIdentifierItem : public PtrListItem 
{
  /// Friend class definition
  friend class UNIT_TEST_FRIEND_CLASS;

  public:
    /// Default constructor.
    DpIdentifierItem() : itemType(IDENTIFIERITEM_NONE) {}
    /** Constructor. 
        Depending on the values set in the dpId, it holds system-name or type-name or DP-name or element-name string.
    */
    DpIdentifierItem(const DpIdentifier &dpId, const CharString &dpName);
    /// Constructor for storing a LangText.
    DpIdentifierItem(const LangText &text);
    /// Constructor for storing a CNSDataIdentifier.
    DpIdentifierItem(const CNSDataIdentifier &id, const CharString &dpName);
    /// Copy constructor.
    DpIdentifierItem(const DpIdentifierItem &rVal);
    /// Destructor.
    ~DpIdentifierItem();

    /** Old type constructor.
        Stores the DP-name.
    */
    DpIdentifierItem(DpIdType theDpId, DpTypeId theTypeId, const char * const *theNamePtrs, 
        SystemNumType theSysNum);
    /** Old type constructor.
        Stores the element-name.
    */
    DpIdentifierItem(DpTypeId theTypeId, DpElementId theElId, const char * const *theNamePtrs,
        SystemNumType theSysNum);
    /** Old type constructor.
        Stores the type-name.
    */
    DpIdentifierItem(DpTypeId theTypeId, const char * const *theNamePtrs, SystemNumType theSysNum);

    // Operatoren :

    /// Write the instance into the itcNdrUbSend stream.
    friend DLLEXP_MESSAGES itcNdrUbSend &operator<<(itcNdrUbSend &ndrStream, const DpIdentifierItem &item);
    /// Read the instance from the itcNdrUbReceive stream.
    friend DLLEXP_MESSAGES itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream, DpIdentifierItem &item);
    /// Read the instance from the itcNdrUbReceive stream.
    friend DLLEXP_MESSAGES itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream, DpIdentifierItem * & itemPtr);

    /// Comparison operator.
    int operator==(const DpIdentifierItem &rVal) const;
    /// Comparison operator.
    int operator!=(const DpIdentifierItem &rVal) const {return !operator==(rVal);}

    // Spezielle Methoden :

    /// Get own type.
    DpIdentifierItemType isA() const;

    /** Get the datapoint names in all languages, if this item has the correct type.
        Use if getDatapointName is preferred, since the names will be the same in all languages.
        Never delete the return value.
    */  
    char ** getDatapointNames(DpIdType &theDpId, DpTypeId &theTypeId, SystemNumType &theSysId) const;
    /** Get the element name in all languages, if this item has the correct type.
        Use if getElementName is preferred, since the names will be the same in all languages.
        Never delete the return value.
    */  
    char ** getElementNames(DpTypeId &theTypeId, DpElementId &theElId, SystemNumType &theSysId) const;
    /** Get the type name in all languages, if this item has the correct type.
        Use if getTypeName is preferred, since the names will be the same in all languages.
        Never delete the return value.
    */  
    char ** getTypeNames(DpTypeId &theTypeId, SystemNumType &theSysId) const;

    /// Get the datapoint name or NULL, if the item is not a datapoint name / id pair.
    const char * getDatapointName() const;
    /// Get the element name or NULL, if the item is not an element name / id pair.
    const char * getElementName() const;
    /// Get the type name or NULL, if the item is not a type name / id pair.
    const char * getTypeName() const;

    /// Get the name as LangText.
    const LangText & getName() const { return dpName;}

    /** Get the id as a DpIdentifier. 
        Only the values needed will be set.
        */
    const DpIdentifier & getDpId() const {return dpId;}

    /// Get the id and type as CNSDataIdentifier.
    CNSDataIdentifier getCNSDataIdentifier() const;

    /** Print the contents of the list to an output stream.   
      Level controls the amount of debug information printed and shall be > 0.
    */
    void debug(std::ostream &to, int level) const;

  private:
    DpIdentifierItemType itemType;
    DpIdentifier         dpId;
    CNSDataIdentifierType cnsType;

    // the names
    LangText dpName;

  public:
    /// Set DpID of the associated DpIdentifier.
    void setDpId(DpIdType theDpId)      {dpId.setDp(theDpId);}
    /// Set DpTypeID of the associated DpIdentifier.
    void setTypeId(DpTypeId theTypeId)  {dpId.setDpType(theTypeId);}
    /// Set DpIdentifierItemType of this item.
    void setItemType(DpIdentifierItemType type) {itemType = type;}
};

// ================================================================================
// Inline-Funktionen :

inline DpIdentifierItemType DpIdentifierItem::isA() const
{
  return itemType;
}


// Konstruktor
inline DpIdentifierItem::DpIdentifierItem(const DpIdentifierItem &rVal) 
  : itemType(rVal.itemType), dpId(rVal.dpId), cnsType(rVal.cnsType), dpName(rVal.dpName)
{
}


// ---------------------------------------------------------------------------

inline char ** DpIdentifierItem::getDatapointNames(
    DpIdType &theDpId, DpTypeId &theTypeId, SystemNumType &theSysId) const
{
  if (itemType == IDENTIFIERITEM_DPNAME)
  {
    theDpId   = dpId.getDp();
    theTypeId = dpId.getDpType();
    theSysId = dpId.getSystem();

    return (char **) (const char **) dpName;
  }
  else
    return 0;                        // das ist kein Datenpunktname
}



inline char ** DpIdentifierItem::getElementNames(
    DpTypeId &theTypeId, DpElementId &theElId, SystemNumType &theSysId) const
{
  if (itemType == IDENTIFIERITEM_ELNAME)
  {
    theTypeId = dpId.getDpType();
    theElId   = dpId.getEl();
    theSysId  = dpId.getSystem();

    return (char **) (const char **) dpName;
  }
  else
    return 0;                        // das ist kein Elementname
}

inline char ** DpIdentifierItem::getTypeNames(DpTypeId &theTypeId, SystemNumType &theSysId) const
{
  if (itemType == IDENTIFIERITEM_TYPENAME)
  {
    theTypeId = dpId.getDpType();
    theSysId  = dpId.getSystem();

    return (char **) (const char **) dpName;
  }
  else
    return 0;                        // das ist kein Typname
}

inline CNSDataIdentifier DpIdentifierItem::getCNSDataIdentifier() const
{
  return CNSDataIdentifier(dpId.getSystem(), dpId.getDp(), cnsType);
}

#endif /* _DPIDENTIFIERITEM_H_ */
