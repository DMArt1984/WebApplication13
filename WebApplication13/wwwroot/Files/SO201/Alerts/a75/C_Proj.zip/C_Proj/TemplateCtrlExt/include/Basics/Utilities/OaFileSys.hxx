#ifndef _PVSSFILESYS_H_
#define _PVSSFILESYS_H_

/*
VERANTWORTUNG: Andreas Pfluegl
BESCHREIBUNG: wrapper class for file system related functions
*/

#ifndef _TYPES_HXX_
#include <Types.hxx>
#endif

#ifndef _CHARSTRING_H_
#include <CharString.hxx>
#endif

#ifndef _FILESYS_H_
#include <FileSys.hxx>
#endif

#include <DynVar.hxx>

#ifdef QT_NAMESPACE
namespace QT_NAMESPACE { class QWidget; } using QT_NAMESPACE::QWidget;
#else
class QWidget;
#endif

// We use this macros to get the source position where the function is called if we are debugging.
#define PVSSfopen(a, b)     OaFileSys::fileOpen(a, b)
#define PVSSstat(a, b)      OaFileSys::fileStat(a, b, __FILE__, __LINE__)
#define getFirstFound(a)    OaFileSys::getFirstFile(a, __FILE__,__LINE__)
 

/** Managing the PVSS II file system.
  * Since PVSS-II searches Panels, Pixmaps ... in several Directories
  * we need a set of file system operations that extend with this capacity.
*/
class DLLEXP_BASICS OaFileSys
{
public:
  friend class UNIT_TEST_FRIEND_CLASS;
  /// Read directory flags.
  enum PVSSReadDirModus
  {
    /// Read all files of the search path
    READ_ALL_FILES,          
    /// If a file exists more than once overload the more general version with the more specific one
    OVERLOAD_EXISTING_FILES                           
  };

  /// Constructor.
  OaFileSys();

  /// Destructor.
  ~OaFileSys();

  /** Compare two fileNames and ignore "\" "/" mismatches.
      OBSOLETE / DEPRECATED Function. Call FileSys::cmpPathNames() instead.
      @param fileName1 First filename to compare.
      @param fileName2 Second filename to compare.
      @return calls FileSys::cmpPathNames().
  */
  IL_DEPRECATED("deprecated, call FileSysSlim::cmpPathNames() instead")
  static int FileNameCmp(const char *fileName1, const char *fileName2);

  /** Compare the first "count" character of two filenames.
      Duplicate path separators are not removed. Use cleanPath() to remove any duplicate
      path separators.
      OBSOLETE / DEPRECATED Function. Call FileSys::ncmpPathNames() instead
      @param fileName1 First filename to compare.
      @param fileName2 Second filename to compare.
      @param count Number of chars to compare.
      @return calls FileSys::cmpPathNames().
  */
  IL_DEPRECATED("deprecated, call FileSysSlim::ncmpPathNames() instead")
  static int FileNameNCmp(const char *fileName1, const char *fileName2, unsigned int count);

  /** fopen extended with the capacity to search along the searchpath.
    * If you open a file for reading it searches along the searchpath.
    * If you open it for writing or update it only searches in the projDir
    * @param getPath  pointer to a function that returns searchpath(i)
    *                 where i is in the range from 1 to n
    *                 and   searchpath(1) is in the projDir
    *                 and   searchpath(n) is in the pvssDir
    * @param subPath  rest of the path + filename
    * @param mode     open the file for mode (see fopen)
    * @return         filepointer of the opened file or
    *                 0 if the file is not opened.
    * <p>
    * Example: fileOpen(Resources::getPanelDir, "vision\redundanz.pnl" "rb")
    *          opens the first found panel with the name redundanz.pnl that is 
    *          located in the subdir vision of one of the panel directories.
    */
  static FILE* fileOpen(
    CharString (*getPath)(int),   
    const CharString &subPath, 
    const char *mode);

  /** fileOpen with an other interface, that splits the paths with string 
    * manipulation (not that performant as the interface above) please 
    * use it only if you get a anonymous string as filename.
    * @param filename Path to file which should be opened.
    * @param mode Opening mode (see fopen).
    * @return Filepointer of the opened file or 0 if the file is not opened.
    * @see fileOpen
    */
  static FILE* fileOpen(
    const char *filename, 
    const char *mode);

  /** fstat extended with the capacity to search along the searchpath.
    * @param filename  if the file is in one of the directories of the 
    *                  searchpath we search the first file that fits
    *                  fileStat starts in projDir and searches to pvssDir
    * @param statb     (see fstat)
    * @param source    Debug only, use macro __FILE__
    * @param lineNo    Debug only, use macro __LINE__
    * @return          0 if the file-status information is obtained, -1 in case of error
    * @osdiff          On Win32, a path ending with a path separator is considered as an error
    */
  static int fileStat( 
    const char *filename, 
    struct stat *statb, 
    const char *source = 0, 
    long lineNo = 0);

  /** Searches a file along the searchpath (from projDir to pvssDir).
    * @param filename  path+filename of a file.
    *                  If the file is in one of the directories of the 
    *                  searchpath we search the first file that fits
    *                  fileStat starts in projDir and searches to pvssDir
    * @param source    Debug only, use macro __FILE__
    * @param lineNo    Debug only, use macro __LINE__
    * @return The complete filename (path+filename) of the first file found.
    */
  static CharString getFirstFile( 
    const char *filename, 
    const char *source = 0, 
    long lineNo = 0);

  //----------------------------------------------------------------------------------
  //-- Liegt das File in einem der geg. Directories des Suchpfades (z.B. in einem Panel-Dir)     
  //----------------------------------------------------------------------------------
  /** Check if the filename is in of one of the secified directories.
    * It does not test if the file exists, it only checks syntax.
    * @param filename path+filename of a file
    * @param getPath  pointer to a function that returns searchpath(i)
    *                 where i is in the range from 1 to n
    *                 and   searchpath(1) is in the projDir
    *                 and   searchpath(n) is in the pvssDir
    * @return PVSS_TRUE  if filename is a file of searchpath(1) .. searchpath(n) else
    *          PVSS_FALSE 
    */
  static PVSSboolean matchPath(
    const char *filename, 
    CharString (*getPath)(int)
  );

  /** Checks if the file is in one of the specified directories.
    * @param filename path+filename of a file
    * @param getPath  pointer to a function that returns searchpath(i)
    *                 where i is in the range from 1 to n
    *                 and   searchpath(1) is in the projDir
    *                 and   searchpath(n) is in the pvssDir
    * @param path     OUT: the path that matches or ""
    * @param subPath  OUT: the rest of the filename or ""
    * @return PVSS_TRUE  if filename is a file of searchpath(1) .. searchpath(n) else
    *          PVSS_FALSE 
    * <p>
    * Example:
    * matchPath("c:\tmp\myProj\panels\vision\redundanz.pnl", Resources::getPanelDir, path subPath);
    *   returns PVSS_TRUE, 
    *   path    == "c:\tmp\myProj\panels"
    *   subpath == "vision\redundanz.pnl"
    */
  static PVSSboolean matchPath(
    const char *filename, 
    CharString (*getPath)(int), 
    CharString &path, 
    CharString &subPath
  );

  /** Returns the pointer to the relative path beginning after @p getPath.
    * If the file is not in one of the directories specified by @p getPath,
    * returns the @p fullPath given.
    * @param getPath Pointer to a function that returns searchpath(i)
    * @param fullPath Full path to the file.
    * @return pointer to start of relative path component inside given @p fullPath
    */
  static const char * splitPath(CharString (*getPath)(int), const char *fullPath);

  /** Checks if file exists in one of the specified directories.
    * @param getPath  pointer to a function that returns searchpath(i)
    *                 where i is in the range from 1 to n
    *                 and   searchpath(1) is in the projDir
    *                 and   searchpath(n) is in the pvssDir
    * @param subPath  the rest of the filename eq. "vision\redundanz.pnl"
    * @param langName look for a file in given PVSS language subdir.
    *                 If the file is not found, it is searched for fallback languages.
    *                 If the languages are not yet set (in early stage),
    *                 the product fallback languages are searched in following order:
    *                 (en_US.utf8, en_US.iso88591, de_AT.utf8, de_AT.iso88591)
    * @param searchedMibEnum [OUT] the MIB enum of the encoding of the searched language
                                   if the search path is language dependent,
                                   otherwise undefined.
                                   If a product fallback language was found,
                                   searchedMibEnum will equal to foundMibEnum.
    * @param foundMibEnum [OUT] the MIB enum of the encoding of the found language
                                if the search path is language dependent and if a file has been found,
                                otherwise undefined.
    * @param contextWidget The originating context widget
             (this is only passed to fileUpdateFunction and not used in this method)
    * @return filename of the existing file or "" if the file does not exist.
    */
  static CharString fileExists(
    CharString (*getPath)(int), 
    const CharString &subPath,
    int& searchedMibEnum,
    int& foundMibEnum,
    const char *langName = 0,
    QWidget *contextWidget = 0
  );

  /** Checks if file exists in one of the specified directories.
    * @param getPath  pointer to a function that returns searchpath(i)
    *                 where i is in the range from 1 to n
    *                 and   searchpath(1) is in the projDir
    *                 and   searchpath(n) is in the pvssDir
    * @param subPath  the rest of the filename eq. "vision\redundanz.pnl"
    * @param langName look for a file in given PVSS language subdir
    *                 If the file is not found, it is searched for fallback languages.
    *                 If the languages are not yet set (in early stage),
    *                 the product fallback languages are searched in following order:
    *                 (en_US.utf8, en_US.iso88591, de_AT.utf8, de_AT.iso88591)
    * @param contextWidget The originating context widget
            (this is only passed to fileUpdateFunction and not used in this method)
    * @return filename of the existing file or "" if the file does not exist.
    */
  static CharString fileExists(
    CharString (*getPath)(int), 
    const CharString &subPath,
    const char *langName = 0,
    QWidget *contextWidget = 0
  );

  /// if set it's called whenever fileExists() is called (to allow to fetch the file e.g. from an HTTP server)
  static void setFileUpdateFunction(void (*fileUpdate)(const CharString &relFilePath, QWidget *context));

  /**
   * Searches for a library with the specified name in the subdirectory 'bin'
   * of the PVSS project directory.
   *
   * Example:
   * Assuming that the platform is Linux x86_64 and the given name is "QtCore",
   * the following paths are checked in the project hierarchy, in the given order:
   * (note that the more typical usage is to include the "lib" prefix in the given name)
   * - bin/linux-64/QtCore.so
   * - bin/linux-64/QtCore
   * - bin/QtCore.so
   * - bin/QtCore
   * - bin/linux-64/libQtCore.so
   * - bin/libQtCore.so
   *
   * @param libBaseName The basename of the library (without path; file extension optional),
   *                    e.g. 'libssl.so.1.0.0', 'libssl.dll', 'libssl'.
   *                    The file extension should be specified if it is not
   *                    one of '.dll' or '.so'.
   * @param os Only considered when the library was not found in the directory
   *           'bin' of the project directory. If false, an empty string will
   *           be returned, if true, the specified libBaseName suffixed with
   *           '.dll' or '.so' depending on the OS will be returned.
   *
   * @return If the library was found, the full path of the library, otherwise
   *         when os is specified as false, an empty string,
   *         or when os is true, the specified library name appended with
   *         an appropriate file extension.
   *
   * @remarks os == true allows the return value to be used afterwards in
   *          SharedLib::getFuncPtr() when the lib was not found.
   */
  static CharString findSharedLibrary(const CharString &libBaseName, bool os = false);

  /**
   * Searches for an executable with the specified name in the subdirectory 'bin'
   * of the PVSS project directory.
   *
   * Example:
   * Assuming that the platform is Windows x64 and the given name is "WCCILevent",
   * the following paths are checked in the project hierarchy, in the given order:
   * - bin/windows-64/WCCILevent.exe
   * - bin/windows-64/WCCILevent
   * - bin/WCCILevent.exe
   * - bin/WCCILevent
   *
   * @param libBaseName The basename of the executable (without path; file extension optional),
   *                    e.g. 'WCCILevent', 'WCCILevent.exe'.
   * @param os Only considered when the executable was not found in the directory
   *           'bin' of the project directory. If false, an empty string will
   *           be returned, if true, the specified baseName (suffixed with
   *           '.exe' on Windows) will be returned.
   *
   * @return If the executable was found, the full path of it, otherwise
   *         when os is specified as false, an empty string,
   *         or when os is true, the specified name appended with
   *         an appropriate file extension.
   */
  static CharString findExecutable(const CharString &baseName, bool os = false);

  /** Directory Walker
      Lists all files of the directories specified by getPath
  */
  //@{
  /**
    * Initialize the reading of all the files in the specified directories
    * save all found files in a list.
    * @param getPath  pointer to a function that returns searchpath(i)
    *                 where i is in the range from 1 to n
    *                 and   searchpath(1) is in the projDir
    *                 and   searchpath(n) is in the pvssDir
    * @param subPath  the rest of the filename eq. "vision\redundanz.pnl"
    * @param modus    defines how to handle files with equal subPath: 
    *                 <ul>
    *                 <li>READ_ALL_FILES    Read all files of the search path </li>
    *                 <li>OVERLOAD_EXISTING_FILES  // if a file exists more than once overload it </li>
    *                 </ul>
    * @return PVSS_TRUE if the directory was successfully opened, PVSS_FALSE otherwise.
    */
  PVSSboolean openDir(
    CharString (*getPath)(int),
    const char *subPath,
    PVSSReadDirModus modus
  );

  /**
    * Initialize the reading of all the files in the specified directories and all their subdirectories
    * save all found files in a list.
    * @param getPath  pointer to a function that returns searchpath(i)
    *                 where i is in the range from 1 to n
    *                 and   searchpath(1) is in the projDir
    *                 and   searchpath(n) is in the pvssDir
    * @param subPath  the rest of the filename eq. "vision\redundanz.pnl"
    * @param modus    defines how to handle files with equal subPath: 
    *                 <ul>
    *                 <li>READ_ALL_FILES    Read all files of the search path </li>
    *                 <li>OVERLOAD_EXISTING_FILES  // if a file exists more than once overload it </li>
    *                 </ul>
    * @return PVSS_TRUE if the directory was successfully opened, PVSS_FALSE otherwise.
    */
  PVSSboolean openTree(
    CharString (*getPath)(int),
    CharString subPath,
    PVSSReadDirModus modus
  );

  /** Get the first file of the list you created with openDir.
    * You can call firstFile as often as you like.
    * @param path  OUT: path without filename
    * @param level OUT: 1..n where 1 is the projDir and n is the pvssDir
    * @return filename without path or "" if no file was found
    */
  CharString firstFile(CharString &path, int *level = nullptr);
  
  /** Get the first file of the list you created with openDir.
    * You can call firstFile as often as you like.
    * @param path  OUT: path without filename
    * @param level OUT: 1..n where 1 is the projDir and n is the pvssDir
    * @return filename without path or "" if no file was found
    */  
  IL_DEPRECATED("deprecated, use firstFile(CharString&) instead")
  const char *firstFile(char *path, int &level);

  /** Get the first file of the list you created with openDir.
    * You can call firstFile as often as you like.
    * @param path  OUT: path without filename
    * @return filename without path or "" if no file was found
    */ 
  IL_DEPRECATED("deprecated, use firstFile(CharString&) instead")
  const char *firstFile(char *path);

  /**
    * Get the next file of the list you created with openDir
    * @param path  OUT: path without filename
    * @param level OUT: 1..n where 1 is the projDir and n is the pvssDir
    * @return filename without path or "" if you reached the end of the list
    */
  CharString nextFile(CharString &path, int *level = nullptr);
  IL_DEPRECATED("deprecated, use nextFile(CharString&) instead")
  const char *nextFile(char *path, int &level);
  IL_DEPRECATED("deprecated, use nextFile(CharString&) instead")
  const char *nextFile(char *path);

  /**
    * Get the number of files got with openDir.
    * @return Number of files.
    */
  int getFileCount();

  /**
    * Delete the filelist you got with openDir.
    * Now you can call openDir again.
    */
  void closeDir();
  //@}

private:

  /// common implementation for findSharedLibrary and findExecutable
  static CharString findInBinDir(const CharString &baseName, bool isSharedLib, bool os);

  /// split <projDir> from the path 
  static const char *splitPath(const char *path);
  
  /// part of the implementation of the openDir 
  PVSSboolean openDirIntern(CharString (*getPath)(int), const char *subPath = "");
  
  /// part of the implementation of the nextFile
  const char *nextFileIntern(char *path, int &level);

  /// used in openDir()
  FileSys dirWalker_;            // mein dirWalker verwendet FileSys::dirWalker

  /// used in openDir(), remembers the paths there
  DynVar pathList_;                // suchpfad Nr   
  
  /// used in openDir(), remembers the filenames there
  DynVar fileList_;                // filename ohne pfad

  //// keeps track about index in firstFile/nextFile operations 
  unsigned int currentIndex_;
  
  /// subpath without the filename
  CharString projRelativPath_;     // subPath ohne filename

  /// callback called in firstFile/nextFile
  CharString (*dirPath_)(int);     // filepointer suchpfad(1..n)
  
  /// stores Resources::getSearchPathLen()
  int level_;                      // interner standort speicher

  /// if set it's called whenever fileExists() is called (to allow to fetch the file e.g. from an HTTP server)
  static void (*fileUpdateFunction_)(const CharString &relFilePath, QWidget *context);
};

//--------------------------------------------------------------------------------

inline int OaFileSys::getFileCount() 
{ 
  return(fileList_.getArrayLength());
}

#endif /* _PVSSFILESYS_H_ */
