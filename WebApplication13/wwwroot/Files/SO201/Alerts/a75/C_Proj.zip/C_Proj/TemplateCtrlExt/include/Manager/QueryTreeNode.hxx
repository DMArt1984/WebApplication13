#ifndef _QUERYTREENODE_H_
#define _QUERYTREENODE_H_

/*
VERANTWORTUNG: Robert Trausmuth      
BESCHREIBUNG:
*/

#include <QueryList.hxx>
#include <DpIdentifier.hxx>
#include <set>

typedef long QueryTreeNodeIndex;

class QueryTreeNode;

/** the query condition tree node types */
enum QTNodeType
      {
      /// (0). check for leaf nodes
      QTN_LEAF,       
      /// (1). check if no data - simply returns NULL
      QTN_NODATA,      
      /// (2). text: system name 
      QTN_SYS, 
      /// (3). text: datapoint name
      QTN_DP, 
      /// (4). text: element name
      QTN_EL,
      /// (5). text: config name
      QTN_CF,
      /// (6). text: detail name
      QTN_DT, 
      /// (7). text: attribute name
      QTN_AT,
      /// (8). text: datapoint type name
      QTN_DPT,
      /// (9). text: element type name    
      /// deleted - do not use! (use QTN_ELC instead)
      QTN_ELT,
      /// (10). int: element type constant
      QTN_ELC, 
      /// (11). variable: common data
      QTN_DATA, 
      /// (12). dynvar: data item list
      QTN_DATA_LIST, 
      /// (13). variable: return value for contained identifier
      QTN_DATA_DP, 
      /// (14). variable: return value for contained identifier
      QTN_DATA_DP2,    // contains DpIdentifierVar, DATA_DP was [[DP].EL]:CF.DT.AT and was fully converted
      /// (15). text: integer range string
      QTN_DATA_RANGE,
      /// (16). text: datapoint element alias
      QTN_ALIAS,
      /// (17). text: datapoint element comment in current language
      QTN_COMMENT,
      
      // operators, result typedep.
      QTN_ADD = 100,
      QTN_SUB,
      QTN_MUL,
      QTN_DIV,
      QTN_AND,
      QTN_OR,
      QTN_EXOR,
      
      // logical operators, result 1 or 0 in IntegerVar
      QTN_LOGAND = 200,
      QTN_LOGOR,
      QTN_EQUAL,
      QTN_NEQUAL,
      QTN_LT,
      QTN_LE,
      QTN_GT,
      QTN_GE,
      QTN_INLIST,
      QTN_NINLIST,
      QTN_STRWILDC,
      QTN_NSTRWILDC,
      QTN_INRANGE,
      QTN_NINRANGE,
      };
      
/** the query condition tree node class. query conditions are converted to a tree structure consisting of objects of this class.
    each node has a specific type and evaluates to a predefined variable type. the tree is recursed on evaluation.
*/
class DLLEXP_MANAGER QueryTreeNode
{
  friend class UNIT_TEST_FRIEND_CLASS;

  public:
    /// constructor for simple leaf node
    QueryTreeNode(QTNodeType t = QTN_NODATA) : 
        IAm(t), data(0), left(0), right(0), myIndex(lastIndex++) {};
    /// constructor for leaf node holding data
    QueryTreeNode(QTNodeType t, void *d) :
        IAm(t), data(d), left(0), right(0), myIndex(lastIndex++) {}; 
    /// constructor for branch node
    QueryTreeNode(QTNodeType t, QueryTreeNode *l, QueryTreeNode *r) :
        IAm(t), data(0), left(l), right(r), myIndex(lastIndex++) {};
    /// destructor
    ~QueryTreeNode();
    
    /// copy constructor
    QueryTreeNode(const QueryTreeNode &);
    /// assignment operator
    QueryTreeNode &operator=(const QueryTreeNode &);

    /** Check tree for a specific node type; Used to extract nodes for SYS, EL, DP,...
     *  @param type  The type which should be searched.
     *  @param ignOr If set to true the function will ingore a QTN_LOGOR rooted sub trees.
     *  @return The index if found or -1 (invalid idx) if not found.
     */
    QueryTreeNodeIndex contains(const QTNodeType type, bool ignOr = false);

    /** Check tree for an std::set of node types; Used to check nodes for SYS, EL, DP,...
     *  @param types The types which should be searched.
     *  @return Returns true if one of the given types was found, else false.
     */
    bool contains(const std::set<QTNodeType> &types);

    /// get pointer to specified node
    QueryTreeNode * getNode(const QueryTreeNodeIndex);
    /// get first tree node
    QueryTreeNode * getFirstNode(const QTNodeType);
    /// get next tree node, recurse down, left before right
    QueryTreeNode * getNextNode(const QTNodeType, const QueryTreeNodeIndex startAfter); 
    /// get parent for given tree node
    QueryTreeNode * getParent(const QueryTreeNodeIndex);
  
    /// get left node
    QueryTreeNode * getLeft() {return left;}
    /// get right node
    QueryTreeNode * getRight() {return right;}
    QueryTreeNode * setLeft(QueryTreeNode *l) {QueryTreeNode *ret = left; left = l; return ret;};
    QueryTreeNode * setRight(QueryTreeNode *r) {QueryTreeNode *ret = right; right = r; return ret;};

    /// get data pointer, normally pointer to variable
    void * getData() {return data;}
    void * setData(void *d) {void *ret = data; data = d; return ret;} 
  
    int addToList(Variable *);
    unsigned int itemsInList() 
      {return ((IAm == QTN_DATA_LIST && (data)) ? ((DynVar *)data)->getArrayLength() : 0);}

    void resetLevel() {level = 0;}
  
    /// get node type
    QTNodeType getType() {return IAm;}
    /// get node index
    QueryTreeNodeIndex getIndex() {return myIndex;}

    /// get level of tree node
    int getLevel(const QueryTreeNodeIndex &idx);
    
    /// reduce DATA_DP2 types
    void reduceDataDp();

    void reduceDataDp(DpTypeId typeId);
  
    DpIdentificationResult getIdFromText(DpIdentifier &id, PVSSushort &flags, DpSymIdLevel &);
    
    /// evaluate condition tree. returned variable has to be deleted after use
    Variable *evaluate(LineSet &line, const GlobalLanguageIdType &filterLang);
    /// evaluate condition tree. returned variable has to be deleted after use
    Variable *evaluate(const DpIdentifier &id, const GlobalLanguageIdType &filterLang);

    /// check if value is in the list of allowed values
    int isIn(const Variable *var, const DynVar *list);
    
    /// print out tree for debug purposes
    void debug();
    
  private:

    static QueryTreeNodeIndex lastIndex;
    static int level;
    static int compNow;
  
    QTNodeType IAm;
    void *data;
    
    QueryTreeNode *left;
    QueryTreeNode *right;
  
    QueryTreeNodeIndex myIndex;
};

#endif /* _QUERYTREENODE_H_ */
