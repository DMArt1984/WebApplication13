#ifndef _UTF8_CONVERTER_H_
#define _UTF8_CONVERTER_H_

#include <Resources.hxx>
#include <memory>
#include <map>

#ifdef USE_QT
#include <QString>
#include <QTextCodec>
#endif

class CharString;
class LangText;

/** Utility class to convert to / from UTF8
    @classification ETM internal
*/

class DLLEXP_BASICS UTF8Converter
{
  public:
    friend class UNIT_TEST_FRIEND_CLASS;
    friend struct QtUtils;

    /** Convert from specific language to UTF8.
        src and dest may be the same.
        */
    static void convertToUTF8(const char *src, CharString &dest);

    static void convertToUTF8(const char *src, CharString &dest, LanguageIdType lang);

    static CharString toUTF8(const char *src);

    static CharString toUTF8(const char *src, LanguageIdType lang)
    { CharString ret; convertToUTF8(src, ret, lang); return ret; }

    /** Convert all texts in src from each language to its UTF8 version in dest.
        */
    static void convertToUTF8(const LangText &src, LangText &dest, bool srcIsAltEncoded = false);

    /** Convert from UTF8 to specific language.
        src and dest may be the same.
        */
    static void convertFromUTF8(const char *src, CharString &dest);

    static void convertFromUTF8(const char *src, CharString &dest, LanguageIdType lang);

    static CharString fromUTF8(const char* src);

    static CharString fromUTF8(const char* src, LanguageIdType lang)
    { CharString ret; convertFromUTF8(src, ret, lang); return ret; }

    /** Convert all texts in src from UTF8 to its local encoded version in dest.
        */
    static void convertFromUTF8(const LangText &src, LangText &dest, bool srcIsAltEncoded = false);

    /** setup internal data, intended to be called after setup of language lists
      * default for active language before setup is utf8 
      */
    static void reset()     { setup(); }

    /** Converts a given string from one encoding to a second one.
     *  Source and destination encoding must be passed as MIB enumeration.
     *  src and dst may be the same.
     * @param src the string, which shall be converted.
     * @param[out] dst the destination string.
     * @param srcMibEnum MIB identifying the encoding of the source string
     * @param dstMibEnum MIB identifying the encoding of the destination string
     * @return true if encoding conversion has been successful
     *         false otherwise
     */
    static bool convertEncodingByMibEnum(const CharString &src, CharString &dst,
                                int srcMibEnum, int dstMibEnum);

    /** Converts a given string from one encoding to a second one.
     *  Source and destination encoding must be passed as global language identifiers.
     *  src and dst may be the same.
     * @param src the string, which shall be converted.
     * @param[out] dst the destination string.
     * @param srcLang global language id identifying the encoding of the source string
     * @param dstLang global language id identifying the encoding of the destination string
     * @return true if encoding conversion has been successful
     *         false otherwise
     */
    static bool convertEncodingByLanguage(const CharString &src, CharString &dst,
                                GlobalLanguageIdType srcLang, GlobalLanguageIdType dstLang);

    /** Returns the number of wchar_t elements needed to hold the converted
     *  version of the UTF-8 encoded input string.
     * @param src the UTF-8 encoded string, whose converted size shall be calculated
     * @return the number of wchar_t items that are needed to hold the transcoding of src
     */
    static size_t getWcharLen(const char *src);

    /** Converts the given UTF-8 encoded string into its wchar_t-array equivalent.
     * @param src the UTF-8 encoded string, which shall be converted
     * @param[out] dest the destination, the buffer is allocated by this function
     *             and must be deleted by the caller.
     */
    static size_t convertToWchar(const char *src, wchar_t*& dest);

    /** Converts the given wchar_t array to its UTF-8 equivalent.
     * @param src the wchar_t array, which shall be converted, this
     *           function does not take ownership
     * @param[out] dest the CharString, where the UTF-8 encoded version of
     *             the input shall be stored
     */
    static void convertFromWchar(const wchar_t* src, CharString& dest);

    /** Converts the given language name to its corresponding mib enum
     * @param langName one of the language names that can be handeld by
     *                 QTextCodec (eg. "UTF-8", see qt documentation)
     * @return mib enum that fits best to language name
     */
    static int mibForEncoding(const char* encoding);

   /** Converts a given string from specified encoding to active project encoding.
     *  Source encoding must be passed as mib enum.
     *  src and dst may be the same.
     * @param src the string, which shall be converted.
     * @param srcMibEnum MIB identifying the encoding of the source string
     * @param[out] dst the destination string.
     * @return true if encoding conversion has been successful
     *         false otherwise
     */
    static bool convertToActiveLang(const CharString &src, int srcMibEnum, CharString &dst);

   /** Converts a given string from active project encoding to specified encoding.
     *  Destination encoding must be passed as mib enum.
     *  src and dst may be the same.
     * @param src the string, which shall be converted.
     * @param[out] dst the destination string.
     * @param srcMibEnum MIB identifying the encoding of the source string
     * @return true if encoding conversion has been successful
     *         false otherwise
     */
    static bool convertFromActiveLang(const CharString &src, CharString &dst, int dstMibEnum);

#ifdef USE_QT
    /** convert QString to CharString via the encoding of the active language
      * @param str source QT unicode string
      * @return conversion result in project language
      */
    static CharString actLangEncoded(const QString &str);

    /** convert bytearray to QString via the encoding of the active language
      * API: compiles only with #define USE_QT
      * @param str encoded source string
      * @return conversion result as unicode QT string
      */
    static QString actLangDecoded(const CharString &str);
#endif 

    /** converts a given string from active project encoding to (windows) wide character string
        IM 115346 implemented first for webClient & cyrillic encoding 
      * @param src the string which shall be converted
      * @param dest 
      * @param[out] dest the destination, the buffer is allocated by this function
      *             and must be deleted by the caller using array delete operator.    
      * @return size of the wchar_t string
      */
    static size_t actLangToWchar(const char* src, wchar_t*& dest);

    /** converts a given string from active project encoding to (windows) wide character string
        IM 115346 implemented first for webClient & cyrillic encoding 
      * @param src the string which shall be converted
      * @param dest 
      * @param[out] dest the destination, the buffer is allocated by this function
      *             and must be deleted by the caller.    
      * @return size of the wchar_t string
      */
    static void wcharToActLang(const wchar_t* src, CharString &dest);

    /** converts a given string from active project encoding to system encoding
      * @param src the string which shall be converted
      * @return conversion result
      */
    static CharString actLangToSystem(const char* str);

   /** converts a given string from system encoding to active project encoding
      * @param src the string which shall be converted
      * @return conversion result
      */
    static CharString systemToActLang(const char* str);

#ifdef USE_QT
    /** delivers the appropriate codec to lang identifier
      * Note that you should not delete codecs yourself: once created they become Qt's responsibility.
      * returned pointer will never be zero
      * @param id WinCC_OA lang identifier
      * @return codec for this language
      */
    static QTextCodec *codecForLang(GlobalLanguageIdType id);
#endif

  private:
    // No instance may exist
    UTF8Converter() {} //COVINFO LINE: defensive (AP: disallow ctor)

    // fill internal codecs array with codecs for current project languages
    static void setup();

    // direction in which we want the conversion
    enum Direction { FROM_UTF8, TO_UTF8 };

#ifdef USE_QT
    /* do the conversion.
       When called with FROM_UTF8, codec is the destionation codec.
       When called with TO_UTF8, codec is the source codec.
    */
    static void convert(const char *src, CharString &dst, QTextCodec *codec, Direction dir);

    // Note that you should not delete codecs yourself: once created they become Qt's responsibility.
    // returned pointer will never be zero
    static QTextCodec *codecForActiveLang();

    static std::map<GlobalLanguageIdType, QTextCodec*>codecs;
    static std::map<GlobalLanguageIdType, QTextCodec*>altCodecs;
    static QTextCodec *codecForLocale;
#endif

    static LanguageIdType numOfLangs_;
};

#endif
