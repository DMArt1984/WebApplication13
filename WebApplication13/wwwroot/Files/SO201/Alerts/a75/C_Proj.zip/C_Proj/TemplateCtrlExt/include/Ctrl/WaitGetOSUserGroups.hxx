#ifndef _WAITGETOSUSERGROUPS_H_
#define _WAITGETOSUSERGROUPS_H_

//--------------------------------------------------------------------------------------
// WOKL 26.3.15 IM 115991 built in threading for long lasting function
//                        source taken from WaitGetHostByName / ctheis
//--------------------------------------------------------------------------------------

#include <WaitCond.hxx>
#include <CtrlThread.hxx>
#include <TextVar.hxx>
#include <TimeVar.hxx>
#include <Mutex.hxx>
#include <PVSSBcm.hxx>

#include <string>
#include <list>

class WaitGetOSUserGroups : public WaitCond
{
  public:
    WaitGetOSUserGroups(CtrlThread *thread, const TextVar &name, const DynVar &filterGroupOSIDs, const TextVar &domain, bool membership);

   ~WaitGetOSUserGroups();

    virtual const TimeVar & nextCheck() const;

    virtual int checkDone();

  private:
    static Mutex mutex_;  // protects ThreadStruct::waitCond_

    struct ThreadStruct
    {
      // Backpointer of wait condition for the thread.
      // End of thread sets this to 0.
      // Protected by WaitGetHostByAddr::mutex_
      WaitGetOSUserGroups *waitCond_;  
      TextVar name_;
      DynVar  filterGroupOSIDs_;
      TextVar domain_;
      CharString error_;
      bool membership_;
    };

    // Pointer to thread arguments. End of thread sets this to 0.
    ThreadStruct *threadStruct_;
    CtrlThread *thread_;
    DynVar *result_;
    mutable TimeVar nextCheck_;
  
    CharString error_;

#ifdef _WIN32
   static void __cdecl func(void *arg);
#else
   static void * func(void *arg);
#endif
};

#endif
