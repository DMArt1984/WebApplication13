// DATEIBESCHREIBUNG ==============================================================
// DATEINAME:     DpPrecConv.hxx
// VERANTWORTUNG:	Stanislav Meduna
// 
// BESCHREIBUNG:	Einstellbare Genauigkeit.
//
// AENDERUNGS-HISTORIE
// Ver.  | Datum      | Aenderungen                            | ModNr.| Autor
// ------+------------+-----------------Anfang-----------------+-------+-----------
//   1.0 |            | 1.Erstellung mit Westmount-OMT         |     0 |
// ======================================Ende======================================
#ifndef _DPPRECCONV_H_
#define _DPPRECCONV_H_

// Vorwaerts-Deklaration der Eigenen Klasse
class DpPrecConv;

// System-Include-Files
#include <BitVar.hxx>
#include <DpConversion.hxx>
#include <IntegerVar.hxx>

// Vorwaerts-Deklarationen :
class DpConvSmooth;
class DpPrecConv;
class Variable;

class BitVec;

// ========== DpPrecConv ============================================================
/** Precision conversion class. performs rounding with specified precision
*/
class DLLEXP_CONFIGS DpPrecConv : public DpConversion 
{

  // Klassen-Enums:

// ..........................Anfang User-Klasseninterne-Definitionen..................
// ...........................Ende User-Klasseninterne-Definitionen...................
public:
  ///constructor
  DpPrecConv();
  ///Destructor
  ~DpPrecConv();


  // Operatoren :
  /**streaming send operator
    @param ndrStream itcNdrUbSend stream
    @param aConv DpPrecConv conversion object
    @return ndr stream
    */
  friend DLLEXP_CONFIGS itcNdrUbSend &operator<<(itcNdrUbSend &ndrStream, const DpPrecConv &aConv);
  /**streaming receive operator
    @param ndrStream itcNdrUbSend stream
    @param aConv DpPrecConv conversion object
    @return ndr stream
    */
  friend DLLEXP_CONFIGS itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream, DpPrecConv &aConv);
  /**assignment operator
    @param aConv DpConvSmooth conversion object
    @return DpConvSmooth object
    */
  virtual DpConvSmooth &operator=(const DpConvSmooth &aConv);

  // Spezielle Methoden :
  ///returns DpConvPrec conversion type
  virtual DpConversionType convType() const;
  /**An input variable is rounded with specified precision and the result is written in a new floatvar. The outVarPtr pointer is set to the floatvar. The caller is responsible for deletion. In case of an invalid variable a nullpointer is returned.
    @param inpVar input variable
    @param outVarPtr [out] points to the output, null if input variable was invalid
    @param unused BitVec value, not used in the code
    @return DpConversionResultType error code
    */
  virtual DpConversionResultType convert(const Variable &inpVar, Variable * & outVarPtr, const BitVec &unused);
  ///allocates instance of DpConvSmooth
  virtual DpConvSmooth *allocate() const;
  /**set attribute
    @param attrNr DpAttributeNrType attribute number
    @param var Variable& value
    @return PVSSboolean true if succeeded otherwise false
    */
  virtual PVSSboolean setAttribut(DpAttributeNrType attrNr, const Variable &var);
  /**get attribute
    @param attrNr DpAttributeNrType attribute number
    @return Variable* attribute value
    */
  virtual Variable *getAttribut(DpAttributeNrType attrNr) const;

  // Generierte Methoden :
  ///returns precision(const)
  const IntegerVar &getAttrPrecision() const;
  ///returns precision
  IntegerVar &getAttrPrecision();
  /**sets precision 
    @param newAttrPrecision IntegerVar precision
  */
  void setAttrPrecision(const IntegerVar &newAttrPrecision);
  ///returns if inverse mode set(const)
  const BitVar &getAttrInverse() const;
  ///returns if inverse mode set
  BitVar &getAttrInverse();
  /**sets/resets inverse mode 
    @param newAttrInverse BitVar inverse mode
  */
  void setAttrInverse(const BitVar &newAttrInverse);
protected:
private:
  IntegerVar attrPrecision;
  BitVar attrInverse;

// ............................Anfang User-Attribut-Definitionen...................
// .............................Ende User-Attribut-Definitionen....................
};

// ================================================================================
// Inline-Funktionen :
inline const IntegerVar &DpPrecConv::getAttrPrecision() const
{
  return attrPrecision;
}

inline IntegerVar &DpPrecConv::getAttrPrecision()
{
  return attrPrecision;
}
inline void DpPrecConv::setAttrPrecision(const IntegerVar &newAttrPrecision)
{
  attrPrecision = (IntegerVar &) newAttrPrecision;
}
inline const BitVar &DpPrecConv::getAttrInverse() const
{
  return attrInverse;
}

inline BitVar &DpPrecConv::getAttrInverse()
{
  return attrInverse;
}
inline void DpPrecConv::setAttrInverse(const BitVar &newAttrInverse)
{
  attrInverse = (BitVar &) newAttrInverse;
}

// ............................Anfang User-Inlines.................................
// .............................Ende User-Inlines..................................

#endif /* _DPPRECCONV_H_ */
