#ifndef _BITVEC_H_
#define _BITVEC_H_

#include <memory.h>
#include <Types.hxx>

#ifndef NO_BCM
class itcNdrUbSend;
class itcNdrUbReceive;
#endif

/**
 * The ComDrv specific assignment of the bit numbers.
 * The ComDrv uses this numbers to address the invalid, GA and the user bits in a BitVec.
 * PA quality code is located in byte 7.
 */
enum DriverBits {
  DRV_NULL = 0,
  /// The out of range bit
  DRV_OUT_OF_RANGE,
  /// The invalid bit
  DRV_INVALID,
  /// The General Query bit
  DRV_GQ,
  DRV_GA = DRV_GQ,
  /// The Single Query bit
  DRV_SQ,
  /// Time comes from device
  DRV_TIME_OF_PERIPH,
  /// driver wants explicit answer on value change
  DRV_WANT_ANSWER,
  /// driver needs initial data for input
  DRV_GET_INIT_DATA,

  /// The userbit 1 must be modulo 8
  DRV_USERBIT1 = 8,
  /// The userbit 2
  DRV_USERBIT2,
  /// The userbit 3
  DRV_USERBIT3,
  /// The userbit 4
  DRV_USERBIT4,
  /// The userbit 5
  DRV_USERBIT5,
  /// The userbit 6
  DRV_USERBIT6,
  /// The userbit 7
  DRV_USERBIT7,
  /// The userbit 8
  DRV_USERBIT8,
  /// The userbit 32
  DRV_USERBIT32 = 39,
  // according to drvbits there are validation-bits
  // only if these bits are set the values above are valid

  /// status bit 'out of service'
  DRV_OUT_OF_SERVICE,
  /// driver sends PA quality code
  DRV_HAS_QUALITY_CODE,
  /// uncertain bit for acquisition mode "xxx on use"
  DRV_VALUE_UNCERTAIN,

  /// reserved area for PA quality bits, Byte 7
  DRV_PA_BIT1 = 56,
  DRV_PA_BIT2,
  DRV_PA_BIT3,
  DRV_PA_BIT4,
  DRV_PA_BIT5,
  DRV_PA_BIT6,
  DRV_PA_BIT7,
  DRV_PA_BIT8,  // 63

  DRV_VALID_NULL = 64,
  /// The out of range bit is valid
  DRV_VALID_OUT_OF_RANGE,
  /// The invalid bit is valid
  DRV_VALID_INVALID,
  /// The GA bit is valid
  DRV_VALID_GQ,
  /// Alias for DRV_VALID_GQ
  DRV_VALID_GA = DRV_VALID_GQ,
  /// The SQ bit is valid
  DRV_VALID_SQ,
  /// Time of periph bit is valid
  DRV_VALID_TIME_OF_PERIPH,
  /// Want answer bit is valid
  DRV_VALID_WANT_ANSWER,
  /// Get init data bit is valid
  DRV_VALID_GET_INIT_DATA,
  /// The user bit 1 is valid

  DRV_VALID_USERBIT1 = 72,
  /// The user bit 2 is valid
  DRV_VALID_USERBIT2,
  /// The user bit 3 is valid
  DRV_VALID_USERBIT3,
  /// The user bit 4 is valid
  DRV_VALID_USERBIT4,
  /// The user bit 5 is valid
  DRV_VALID_USERBIT5,
  /// The user bit 6 is valid
  DRV_VALID_USERBIT6,
  /// The user bit 7 is valid
  DRV_VALID_USERBIT7,
  /// The user bit 8 is valid
  DRV_VALID_USERBIT8,
  /// The user bit 32 is valid
  DRV_VALID_USERBIT32 = 103,

  /// status bit 'out of service' is valid
  DRV_VALID_OUT_OF_SERVICE,
  /// driver PA quality code bit valid
  DRV_VALID_HAS_QUALITY_CODE,
  /// uncertain bit for acquisition mode "xxx on use"
  DRV_VALID_VALUE_UNCERTAIN,


  // reserved area for PA quality bits
  DRV_VALID_PA_BIT1 = 120,
  DRV_VALID_PA_BIT2,
  DRV_VALID_PA_BIT3,
  DRV_VALID_PA_BIT4,
  DRV_VALID_PA_BIT5,
  DRV_VALID_PA_BIT6,
  DRV_VALID_PA_BIT7,
  DRV_VALID_PA_BIT8,  // 127

  /// The upper limit of enum values
  DRV_MAXBITS = 128   // must be the last!
  };

/**
 * A class storing any number of bits. Individual bits can be set, cleared and queried.
 *
 * @remarks Driver specific:
 * The state and a validation bit are stored for each bit used by the driver.
 * This is necessary because we want to know which bits are set to 0 due to
 * initialisation or due to driver interaction.
 */
class DLLEXP_BASICS BitVec
{
  friend class UNIT_TEST_FRIEND_CLASS;

  public:

  /**
   * Size of the internal buffer in units (see BITS_PER_UNIT).
   */
  static const int FIX_LEN = 4;

  /**
   * Number of bits that fit into the internal buffer.
   */
  static const int MAX_FIX_BITS = FIX_LEN * sizeof(PVSSulong) * 8;

  /**
   * Number of bits in a unit (unit = 4 byte).
   */
  static const int BITS_PER_UNIT = sizeof(PVSSulong) * 8;

  /**
   * Creates a new instance with the specified number of bits.
   *
   * @param size The number of bits that this object will be able to store.
   */
  BitVec(PVSSushort size = DRV_MAXBITS);

  /**
   * Destructor
   */
  ~BitVec();

  /**
   * Creates a copy of the specified instance.
   */
  BitVec(const BitVec &bv);

  /**
   * Copies the state of the specified instance to the current instance.
   */
  BitVec &operator =(const BitVec &);

  /**
   * Resize the vector to a new size.
   *
   * @remarks If you decrease and then increase the size of a BitVec,
   *          there might be bits retained in the increased range
   *          that were set before decreasing.
   *
   * @param newSize the new number of bits.
   */
  void reSize(PVSSushort newSize);

  /**
   * Set the bit with the specified index.
   *
   * @param bitno The index of the bit to set. Indices start from zero.
   *
   * @return True if the bit was successfully set, otherwise false
   * (only for invalid indices).
   */
  PVSSboolean set(PVSSushort bitno);

  /**
   * Clears the bit with the specified index.
   *
   * @param bitno The index of the bit to clear. Indices start from zero.
   *
   * @return True if the bit was successfully cleared, otherwise false
   * (only for invalid indices).
   */
  PVSSboolean clear(PVSSushort bitno);

  /**
   * Returns the state of the bit with the specified index.
   *
   * @param bitno The index of the bit to query. Indices start from zero.
   *
   * @return True if the queried bit is set, otherwise false. Will always
   * return false for invalid indices.
   */
  PVSSboolean get(PVSSushort bitno) const;

  /**
   * Checks whether any bit is set.
   *
   * @return True if at least one bit is set, otherwise false.
   */
  PVSSboolean anySet() const;

  /**
   * Clears all bits.
   *
   * @return False if the instance is missing its storage memory, otherwise true
   * (should always return true).
   */
  PVSSboolean clearAll();

  /**
   * Sets a range of bits.
   *
   * @param bitstart The first bit to set
   * @param len The number of bits to set
   *
   * @return True if all bits were set, otherwise false
   * (only if the range does not fit inside the BitVec).
   */
  PVSSboolean setRange(PVSSushort bitstart, PVSSushort len);

  /**
   * Check if any of the bits set in the specified instance are set in our vector.
   *
   * @param bv The vector to compare with this instance.
   *
   * @return True if at least one bit position is set in both instances,
   * otherwise false.
   */
  PVSSboolean commonSet(BitVec &bv) const;
  
  /**
   * Returns the capacity of this instance in bits.
   */
  PVSSushort getSize() const { return blen; }

  /**
   * Compares two instances for equality.
   */
  int operator==(const BitVec &rVal) const;

  /**
   * Compares two instances for inequality.
   */
  int operator!=(const BitVec &rVal) const { return ! (*this == rVal); }

  /**
   * Compares only the bits for which the valid-flag (DRV_VALID_xxx) is set
   * in @b this instance.
   *
   * @return Returns 1 if the values are equal, otherwise 0.
   */
  int compareDrvBits(const BitVec &rVal) const;

  /**
   * Sets a full byte in the vector to the specified value.
   *
   * @param byteno The index of the byte in the vector. Indices start from zero.
   * @param vl The value to which the byte will be set
   *
   * @return True if the byte was successfully set, otherwise false
   * (only for invalid index).
   */
  PVSSboolean setByte (PVSSushort byteno, PVSSuchar vl);

  /**
   * Returns a 16bit value starting from the specified bit index.
   *
   * @param bitno The index of the first bit of the queried 16bit value.
   * Indices start from zero.
   */
  PVSSushort get16Bits(PVSSushort bitno) const;

  /**
   * Returns an 8bit value starting from the specified bit index.
   *
   * @param bitno The index of the first bit of the queried 8bit value.
   * Indices start from zero.
   */
  PVSSuchar get8Bits(PVSSushort bitno) const;

  /**
   * Returns a value with the specified number of bits read starting from
   * the specified bit index.
   *
   * @remarks Since the return type is a 32bit number, reading more than 32bit
   * will not return a meaningful value.
   *
   * @param bitno The bit index from which to start reading. Indices start from zero.
   * @param n The number of bits to read. Should not be greater than 32 (size of PVSSulong).
   */
  PVSSulong getNBits(PVSSushort bitno, PVSSushort n) const;

  /**
   * Masks uer bits accoring to given mask.
   * This is a utility function for ComDrv.
   *
   * @params mask The mask for user bits
   */
  void maskUserBits(const BitVec &mask);

#ifndef NO_BCM // [
  friend DLLEXP_CONFIGS itcNdrUbSend &operator<<(itcNdrUbSend &ndrStream, const BitVec &vec);
  friend DLLEXP_CONFIGS itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream, BitVec &vec);
  friend DLLEXP_CONFIGS itcNdrUbSend &operator<<(itcNdrUbSend &ndrStream, const BitVec *vecPtr);
  friend DLLEXP_CONFIGS itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream, BitVec *&vecPtrRef);
#endif // NO_BCM ]

  private:

    union
    {
        PVSSulong *data;
        PVSSulong  fix[FIX_LEN]; // buffer for 128 bits (16 bytes)
    } val;

    PVSSushort blen;

};

#endif
