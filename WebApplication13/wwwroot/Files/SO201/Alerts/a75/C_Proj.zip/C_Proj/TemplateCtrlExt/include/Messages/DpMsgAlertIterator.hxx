#ifndef _DPMSGALERTITERATOR_H_
#define _DPMSGALERTITERATOR_H_

#include <MsgGroupIterator.hxx>

#include <AlertAttrList.hxx>

// forward declarations
class DpMsgAlert;
class DpVCItem;


/**
 * A MsgGroupIterator-implementation for DpMsgAlert messages.
 *
 * Some notes on the implementation:
 * - Groups cannot be removed from DP_MSG_ALERT_VC, and DP_MSG_ALERT_HL only
 *   has a single group. Thus, when removeCurrentGroup() is called, it cannot
 *   remove anything, it just acts like an empty iterator.
 * - Items of a group in the message always belong to the same DPE.
 * - This iterator does not try to skip empty groups, like some other iterators,
 *   because the AlertAttrLists in a DpMsgAlert shouldn't be empty.
 * - Calling getFirstGroup() / getNextGroup() changes the internal cursor of the message.
 *
 * @internal
 */
class DLLEXP_MESSAGES DpMsgAlertIterator : public MsgGroupIterator
{
public:
  /// Constructor for DP_MSG_ALERT_VC.
  DpMsgAlertIterator(DpMsgAlert &msg);

  /// Constructor for DP_MSG_ALERT_HL. Always has a single group.
  DpMsgAlertIterator(AlertAttrList &group);

  virtual ~DpMsgAlertIterator() { delete copyGroup_; }

  virtual bool getFirstGroup() const;

  virtual bool getNextGroup() const;

  virtual const DpIdentifier *getFirst() const;

  virtual const DpIdentifier *getNext() const;

  virtual const DpIdentifier *getCurrent() const;

  /**
   * Groups cannot be removed from DP_MSG_ALERT_VC, and DP_MSG_ALERT_HL only
   * has a single group. Thus, when removeCurrentGroup() is called, it cannot
   * remove anything, it just acts like an empty iterator.
   */
  virtual bool removeCurrentGroup(ErrClass *errorPtr = 0);

  virtual const Variable *getCurrentValue() const;

  virtual Variable *getCurrentValue();

  virtual bool replaceCurrentValue(Variable *newValue);

  virtual bool hasSameDpePerGroup() const { return true; }

  /**
   * Returns the copied hotlink group, or null if no copy has been made.
   * Do not delete the returned pointer, it belongs to the iterator object.
   */
  AlertAttrList *getCopyGroup() { return copyGroup_; }  

  /// Returns true if removeCurrentGroup() has been called.
  bool isEmpty() const { return isEmpty_; }

private:
  // avoid copy construction and copy assignment
  DpMsgAlertIterator(const DpMsgAlertIterator &);
  DpMsgAlertIterator &operator=(const DpMsgAlertIterator &);

  /**
   * If copyGroup_ is not yet created, copy the alert group to copyGroup_ and
   * set group_ to the newly created copy.
   * Does nothing when copyGroup_ already exists.
   */
  void copyOnWrite();  
  
  DpMsgAlert *msg_;
  mutable AlertAttrList *currentGroup_;
  mutable DpVCItem *currentItem_;


  // The index of the current item. Necessary to transfer the position from
  // the old to the new group in copyOnWrite().
  mutable unsigned int currentIdx_;

  // when getCurrentValue() or replaceCurrentValue() are used, the group will be
  // copied to avoid changing the hotlinks of other users.
  AlertAttrList *copyGroup_;

  // this value is true after removeCurrentGroup() has been called
  bool isEmpty_;

};

#endif // _DPMSGALERTITERATOR_H_
