#ifndef _DPMSGANSWERITERATOR_H_
#define _DPMSGANSWERITERATOR_H_

#include <MsgGroupIterator.hxx>

// forward declarations
class DpMsgAnswer;
class AnswerGroup;
class AnswerItem;


/**
 * A MsgGroupIterator-implementation for DpMsgAnswer messages that contain
 * AnswerGroups. Does not work with messages that contain AlertAttrLists,
 * like the answer on alertGet().
 * For these messages, use DpMsgAnswerWithAlertsIterator instead.
 *
 * Some notes on the implementation:
 * - The message can be changed group-wise, and values can be changed per item.
 * - Items of a group in the message may belong to multiple DPEs (e.g. dpConnect).
 * - getFirstGroup() / getNextGroup() will skip AnswerGroups that do not have any AnswerItems.
 * - Calling getFirstGroup() / getNextGroup() changes the internal cursor of the message.
 *
 * @internal
 */
class DLLEXP_MESSAGES DpMsgAnswerIterator : public MsgGroupIterator
{
public:
  DpMsgAnswerIterator(DpMsgAnswer &msg);

  virtual bool getFirstGroup() const;

  virtual bool getNextGroup() const;

  virtual const DpIdentifier *getFirst() const;

  virtual const DpIdentifier *getNext() const;

  virtual const DpIdentifier *getCurrent() const;

  /**
   * Remove the current group from the message.
   */
  virtual bool removeCurrentGroup(ErrClass *errorPtr = 0);

  virtual const Variable *getCurrentValue() const;

  virtual Variable *getCurrentValue();

  virtual bool replaceCurrentValue(Variable *newValue);

  /**
   * Most of the time, a group should only belong to a single DPE,
   * but answers on dpConnect() might have multiple DPEs in a single group.
   */
  virtual bool hasSameDpePerGroup() const { return sameDpePerGroup; }

private:
  // avoid copy construction and copy assignment
  DpMsgAnswerIterator(const DpMsgAnswerIterator &);
  DpMsgAnswerIterator &operator=(const DpMsgAnswerIterator &);

  DpMsgAnswer &msg_;
  bool sameDpePerGroup;
  mutable AnswerGroup *currentGroup_;
  mutable AnswerItem *currentItem_;

};

#endif // _DPMSGANSWERITERATOR_H_
