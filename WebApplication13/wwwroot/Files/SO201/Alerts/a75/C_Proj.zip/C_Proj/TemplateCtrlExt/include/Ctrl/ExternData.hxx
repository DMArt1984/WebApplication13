#ifndef _EXTERNDATA_H_
#define _EXTERNDATA_H_

class CharString;
class Variable;
class CtrlCB;
class CtrlScript;
class CtrlThread;

#include <SimplePtrArray.hxx>

typedef void* ScopeId;

/*  author Martin Koller  */
/** abstract baseclass for data used in ExternHandler */
class DLLEXP_CTRL ExternData
{
  public:

    /// runtime type information
    enum DataType
    {
      FILE_DATA,
      SHAPE_DATA,
      ATTR_DATA,
      ALERT_DATA,
      REPORT_DATA,
      SCRIPT_EDITOR_DATA,
      USER_DATA = 1000
    };

    /// destructor
    virtual ~ExternData();

    /** runtime type information. Must return either one of the defined DataType enum values
        or a user defined value > USER_DATA.
      */
    virtual int isA() const = 0;

    /// returns a location information which is used on runtime-error output
    virtual CharString getLocation(const CtrlThread *thread = 0) const = 0;

    /// returns the file with the definition of this script. 
    virtual CharString getFilename(int lib) const = 0;

    ///
    int getClientData() const {return clientData;}
    ///
    void setClientData(int cd) {clientData = cd;}

    // the scopeId defines, in which scope the script, which has this object, is in
    // used for panel-global functions, variables
    void setScopeId(ScopeId id) { scopeId = id; }
    virtual ScopeId getScopeId() const { return scopeId; }

    void setCtrlCBPtr(CtrlCB *p) { ctrlCBPtr = p; }
    CtrlCB *getCtrlCBPtr() const { return ctrlCBPtr; }

    // returns a Variable instance, which will be integrated into the script
    // as a script-global variable with the name "this"
    // Per default, it returns 0, meaning: no "this" variable will be created
    virtual Variable *getThisVariable();

    // a property is just a list of tokens - to be interpreted and used by the derived class
    // returns false when some unknown tokens were given
    typedef SimplePtrArray<CharString> Property;
    virtual bool appendProperty(const Property &p, CtrlScript *parsedScript);

  protected:
    ExternData() : clientData(0), ctrlCBPtr(0), scopeId(0) {}

    int clientData;
    CtrlCB *ctrlCBPtr;    // pointer back to CtrlCB for getting the sourcecode
    ScopeId scopeId;      // It is used in comparison between two ExternData objects

  private:
};

#endif /* _EXTERNDATA_H_ */
