#ifndef _ERRCLASS_H_
#define _ERRCLASS_H_

// AUTHOR: Thomas Koroschetz, Martin Koller

#ifndef _TYPES_HXX_
#include <Types.hxx>
#endif

#ifndef _DPIDENTIFIER_H_
#include <DpIdentifier.hxx>
#endif

#ifndef _MANAGERIDENTIFIER_H_
#include <ManagerIdentifier.hxx>
#endif

#ifndef _PTRLISTITEM_H_
#include <PtrListItem.hxx>
#endif

#ifndef _DYNVAR_H_
#include <DynVar.hxx>
#endif

#ifndef _CHARSTRING_H_
#include <CharString.hxx>
#endif

#ifndef _TIMEVAR_H_
#include <TimeVar.hxx>
#endif

// this shall be removed; it is no more necessary, but other files depend on the included file
#ifndef _TEXTVAR_H_
#include <TextVar.hxx>
#endif

#include <iostream>
#include <string>

#include <BcmDebug.h>


typedef void (*OutStreamCB)(void *clientData, const char *output);

#define    ERR_UB_DPID     1
#define    ERR_UB_MANID    2
#define    ERR_UB_USERID   4
// obsolete
#define    ERR_UB_TEXT1    0
#define    ERR_UB_TEXT2    0
#define    ERR_UB_TEXT3    0

/** The PVSS-II error class. This class holds the values for error types and codes
    as well as the management functions for reading and providing
    multi-language error texts. Since these functions are used
    for internal purposes only, simply look at the constructors and the
    enum values and ignore the rest.
    Different elements of an ErrClass can be represented in the error text when it is
    created, whereby some substitutions are made:
    $DP     ... replaced with given DpIdentifier
    $MAN    ... replaced with given ManagerIdentifier
    $USER   ... replaced with given userId
    $1 - $9 ... replaced with the given notes
    @osdiff The methods getEventViewerHandle and reportEvent are windows only.
    Used to write the error to the EventViewer.
    @classification public use, constructors and enums
*/
class DLLEXP_BASICS ErrClass : public PtrListItem
{
  public:

    /// error classification
    enum ErrType
    {
      /// implementation error
      ERR_IMPL,
      /// parametrisation error
      ERR_PARAM,
      /// system error
      ERR_SYSTEM,
      /// control runtime error
      ERR_CONTROL,
      /// redundancy error
      ERR_REDUNDANCY,
      // just a short name for "redundancy"
      ERR_REDU = ERR_REDUNDANCY
    };

    /// error priority
    enum ErrPrio
    {
      /// fatal error. kill the program instance!
      PRIO_FATAL,
      /// now obsolete
      PRIO_FATAL_NO_RESTART = PRIO_FATAL,
      /// severe error, but we can continue
      PRIO_SEVERE,
      /// warning message, something is not as it should be
      PRIO_WARNING,
      /// info message - hello, here I am!
      PRIO_INFO
    };

    /** Error code.
        The text for these constants can be found in the errors.cat file.
        The numbers defined here are standard errors often used.
    */
    typedef PVSSulong ErrCode;

    enum
    {
      // KEIN FEHLER!!! (wird leider fuer EvDpManager benoetigt)
      /// (0) no error
      NOERR = 0,

      /// (1) manager is starting
      MANAGER_START = 1,    // Manager gestartet
      /// (2) manager is stopping
      MANAGER_STOP = 2,     // Manager beendet
      /// (3) manager is trying to connect
      TRYING_CONNECT = 3,
      /// (4) manager is connected
      CONNECTED = 4,
      /// (5) connect failed
      CANT_CONNECT = 5,
      /// (6) manager is initialized, switched to STATE_RUNNING
      MANAGER_INITIALIZED = 6,   // Manager in STATE_RUNNING

      // Datenpunkt existiert nicht!
      /// (7) datapoint not found
      DPNOTEXISTENT = 7,

      // Element existiert nicht!
      /// (8) datapoint element not found
      ELNOTEXISTENT = 8,

      // Konfiguration existiert nicht!
      /// (9) datapoint config not found
      CONFIGNOTEXISTENT = 9,

      // Attribut-Adresse fehlerhaft!
      /// (10) wrong attribute address
      WRONGATTRIBADRESS = 10,

      // Datentypumwandlung falsch - Datentypen stimmen nicht ueberein!
      /// (11) data conversion not possible - incompatible datatypes
      ILLEGALCONVERSION = 11,

      // Fehler bei Glaettung aufgetreten!
      /// (12) smoothing error
      SMOOTHINGERR = 12,

      // Fehler bei Konvertierung zu Ingenieur-Wert aufgetreten!
      /// (13) error on conversion to ing value
      CONVERSION2ING = 13,

      // Fehler bei Konvertierung zu Roh-Wert aufgetreten!
      /// (14) error on conversion to raw value
      CONVERSION2RAW = 14,

      // Fehlende Peripherie-Adressen-Konfiguration!!!
      /// (15) no periphery configuration found
      MISSINGCONFIG = 15,

      // Angefordertes Modul existiert nicht oder hat falschen Typ!
      /// (16) this module is unknown
      MISSINGMODULE = 16,

      // Angefordertes Panel existiert nicht!
      /// (17) this panel is unknown
      MISSINGPANEL = 17,

      // Wert ausserhalb der Meldungsbereiche!
      /// (18) value out of alert ranges
      OUTOFALERTRANGES = 18,

      // Das Attribut existiert in der Konfiguration nicht!
      /// (19) attribute not existent
      ATTRIBUTENOTEXISTENT = 19,

      // Quellzeit ausserhalb der erlaubten Grenzen (Resource: validTimeDiff)
      /// (20) origin time out of valid range
      ORIGINTIMEINCORRECT = 20,

      // Config mit diesem Typ kann in angegebenem Element nicht eingefuegt werden!
      /// (21) wrong config type for this dp element
      CONFIGTYPEINCORRECT = 21,

      // Der interne Konsistenz-Check der Konfiguration ging schief!
      /// (22) internal check error - config not created
      NOCONSISTENCE = 22,

      // Das Setzen/Aendern des Attributes ging nicht in Ordnung!
      /// (23) attribute not set / changed
      CHANGEATTRIBUTEFAILED = 23,

      // Die Konfiguration ist gesperrt!
      /// (24) this config is locked by someone else
      CONFIGLOCKED = 24,

      // Beim Aufheben eines Locks: Konfiguration ist nicht gelockt!
      /// (25) this config is not locked
      CONFIGISNOTLOCKED = 25,

      // Beim Aufheben eines Locks: Konfiguration ist von anderem User gelockt!
      /// (26) this config is not locked by you
      OTHERUSERLOCKED = 26,

      // Beim Aendern des Lock-Attributes: uebergebene Variable muss BitVar sein!
      /// (27) wrong variable type for lock config
      INCORRECTLOCKVARIABLE = 27,

      // Erzeugen der Konfiguration ging nicht in Ordnung!
      /// (28) creation of config failed
      CREATECONFIGFAILED = 28,

      // Wert liegt ausserhalb des PVSS-Wertebereichs!
      /// (29) value out of PVSS-II range
      OUTOFPVSSRANGE = 29,

      // Der Wert liegt ausserhalb des User-Wertebereichs!
      /// (30) value out of user range
      OUTOFUSERRANGE = 30,

      // An der angegebenen Konfiguration kann keine derartige Typaenderung vorgenommen werden.
      /// (31) config type cannot be changed
      TYPECHANGEFAILED = 31,

      // abzumeldende Anmeldung existiert nicht!
      /// (32) connection not existent
      CONNECTIONNOTEXISTENT = 32,

      // Fehler in DM
      /// (33) common error in data manager
      DM = 33,

      // DM: DP existiert!
      /// (34) this datapoint already exists
      DPEXISTS = 34,

      // DM: DP-Type existiert!
      /// (35) this datapoint type already exists
      TYPEEXISTS = 35,

      // DM: Name fehlerhaft!
      /// (36) check the spelling of this name
      SYNTAX = 36,

      // DM: anderer Manager aendert dieses Objekt!
      /// (37) concurrent access tried on object
      CONCURRENT = 37,

      // Message konnte nicht gesendet werden
      /// (38) message send error
      MSGSENDERROR = 38,

      // Verbindung unterbrochen
      /// (39) connection broken
      BROKENCONNECTION = 39,

      // Angefordertes Elternpanel existiert nicht!
      /// (40) parent panel missing
      MISSINGPARENTPANEL = 40,

      // DP-Variable ist inaktiv (original..aktiv = 0)
      /// (41) this datapoint element is inactive
      DPVARIABLEINACTIVE = 41,

      // Ersatzwert ist nicht definiert und kann daher nicht gesetzt werden
      /// (42) no default value defined
      NODEFAULTVALUE = 42,

      // Quellzeit aelter als vorherige Quellzeit
      /// (43) new origin time is older than last change
      ORIGINTIMEOLDER = 43,

      // kam-Meldung bei sinkender Prioritaet (Meldungsklasse wurde geaendert)
      /// (44) alert class has changed
      ALERTPRIORITY = 44,

      // Attributinhalt ist kein gueltiges Ctrl-Script
      /// (45) this is no valid control script
      CTRL = 45,

      // das Attribut wurde nicht archiviert
      /// (46) no archived values available
      NOTARCHIVED = 46,

      // Fuer diesen Ausgang wurde bereits eine Peripherie-Adresse parametriert!
      /// (47) duplicate peripheral address for output channel
      DUPLICATEOUTPUTPA = 47,

      // Originalwert mit der angegebenen Zeit konnte nicht korrigiert werden!
      /// (48) value not corrected
      NOTCORRECTED = 48,

      // Fehler bei Schreiben aufgetreten! Falsche Adresse?
      /// (49) write failed due to wrong address
      NOTEXISTINGADDRESS = 49,

      // Default-Zweig aufgerufen!
      /// (50) default branch called
      DEFAULTBRANCH = 50,

      // Uebergabeparameter falsch! (z.B. Pointer an Konstruktor ist null)
      /// (51) parameter error
      PARAMETERERROR = 51,

      // Falscher Message-Typ!
      /// (52) wrong message type
      WRONGMSGTYPE = 52,

      // Illegaler Funktionsaufruf! (z.B. wenn Funktion nur Aufgrund von Vererbung existiert.)
      /// (53) illegal function call
      ILLEGALFUNCALL = 53,

      // Unerwarteter Zustand!
      /// (54) unexpected state
      UNEXPECTEDSTATE = 54,

      // Falscher Fehlerbeschreibungstyp!
      /// (55) wrong error description type
      WRONGERRDESCR = 55,

      // Ungueltige Datenpunkt-Systemnummer!
      /// (56) invalid system number for datapoint
      INVALIDSYSNUM = 56,

      // Datenpunkt-Typ existiert nicht!
      /// (57) unknown datapoint type
      TYPENOTEXISTENT = 57,

      // Datenpunkt konnte nicht allokiert werden!
      /// (58) datapoint has not been allocated
      DPALLOCFAIL = 58,

      // Element existiert nicht!
      /// (59) unknown datapoint element
      ELEMENTNOTEXISTENT = 59,

      // Config konnte nicht allokiert werden!
      /// (60) config allocation failed
      CONFIGALLOCFAIL = 60,

      // Kann File nicht oeffnen!
      /// (61) cannot open file
      FILEOPEN = 61,

      // AlertClass geloescht, auf welche noch ein Verweis existiert
      /// (62) referred alert class deleted
      USEDALERTCLASSFREED = 62,

      // Verbindungsfehler!
      /// (63) error on manager connection
      CONNECTIONFAILURE = 63,

      // Falscher IPC-Typ!
      /// (64) wrong IPC type
      WRONGIPCTYPE = 64,

      // Falsche Zieladresse!
      /// (65) wrong destination
      WRONGDESTINATION = 65,

      // Fehler bei Verbindungsaufbau!
      /// (66) error on connection startup
      STARTCONNECT = 66,

      // Fehler bei send aufgetreten!
      /// (67) error on sending message
      SENDFAILURE = 67,

      // Prozess gestorben! - Bitte beerdigen.
      /// (68) process died
      PROCESSDIED = 68,

      // Datenbankfehler!
      /// (69) database error
      DBERROR = 69,

      // Problem mit X11!
      /// (70) problem with the window system
      X11 = 70,

      // DP nicht vorhanden
      /// (71) datapoint not known
      DP_NOT_EXISTENT = 71,

      // Undefinierte Funktion
      /// (72) undefined function called
      UNDEFD_FUNC = 72,

      // Undefinierte Variable
      /// (73) undefined variable
      UNDEFD_VAR = 73,

      // Ausdruck ist keine Variable
      /// (74) this is not a variable
      NOT_A_VARIABLE = 74,

      // Argument fehlt bei Funktion
      /// (75) argument missing
      ARG_MISSING = 75,

      // Ungueltiges Argument bei Funktion
      /// (76) invalid argument
      ILLEGAL_ARG = 76,

      // Ausdruck ist kein Array
      /// (77) this is no array
      NO_ARRAY = 77,

      // Zuweisung zu diesem Ausdruck nicht moeglich
      /// (78) assignment not allowed to RVALUE
      NO_LVALUE = 78,

      // Index ausserhalb der Grenzen
      /// (79) index out of range
      INDEX_OUT_OF_RANGE = 79,

      // Division durch null
      /// (80) division by zero
      DIVISION_BY_ZERO = 80,

      // Syntax error
      /// (81) syntax error
      SYNTAX_ERROR = 81,

      // Datei nicht geoeffnet
      /// (82) file not open
      FILE_NOT_OPEN = 82,

      // Kein Data-Background-Manager
      /// (83) no data-BG running
      DM_NOBG = 83,

      // Kann Library nicht neu laden, wird soeben verwendet
      /// (84) cannot reload lib, lib in use
      LIB_IN_USE = 84,

      // Library wird neu geladen
      /// (85) reloading lib
      REREADING_LIB = 85,

      // ungueltiger Wert
      /// (86) illegal value
      ILLEGAL_VALUE = 86,

      // Ungueltige Zeitangabe fuer bearbeitenden Dateisatz
      /// (87) invalid time stamp
      DM_INVALID_STAMP = 87,

      // Operation mit diesen Argumenten nicht erlaubt
      /// (88) illegal operation
      ILLEGAL_OP = 88,

      // Fehler bei DP anlegen/loeschen
      /// (89) error on inserting / deleting datapoint
      DP_INSERT_OR_DELETE = 89,

      // DP-Attribut wurde zweimal angemeldet
      /// (90) second connect retry for already connected attribute
      DP_ATTR_TWICE = 90,

      // DP-Attribut kann nicht fuer alle Dp-Elemente angemeldet werden
      /// (91) cannot connect this attribute for all elements
      CONNECT_ALL_DPS = 91,

      // Dp-Funktionen: Endlosschleife erkannt
      /// (92) endless loop in datapoint function encountered
      ENDLESS_LOOP = 92,

      // Config wurde nicht veraendert (altes Config == neues Config)
      /// (93) config not changed
      CONFIG_NOT_CHANGED = 93,

      // Fehler in der Treiberkommunikation
      /// (94) driver communication failure
      COMMUNICATION_FAILURE = 94,

      // Unbekanntes Keyword in Resource
      /// (95) unknown resource keyword
      ILLEGAL_KEYWORD = 95,

      // Berechtigung nicht vorhanden
      /// (96) permission missing
      PERMISSION_MISSING = 96,

      // adressierte Meldung nicht vorhanden
      /// (97) alert not known
      ALERT_NOT_EXISTENT = 97,

      // Meldung ist nicht quittierbar
      /// (98) nothing to acknowledge
      NOTHING_TO_ACK = 98,

      // Transformation ging schief
      /// (99) driver transformation error
      TRANSFORM_ERROR = 99,

      // unbekannte Peripherieadresse
      /// (100) unknown peripheral address
      UNKNOWN_PERIPHADDR = 100,

      // Verbindungsaufbau nicht moeglich, erneuter Versuch
      /// (101) connect failed, retrying
      CONNECT_AGAIN = 101,

      // Warte auf Benutzernamen/Passwoerter
      /// (102) wait for user/password information
      WAIT_FOR_USER = 102,

      // Benutzernamen/Passwoerter initialisiert
      /// (103) user/password info ok
      USER_PASS_INITIALIZED = 103,

      // Benutzername oder Passwort falsch
      /// (104) wrong user/password combination
      ILLEGAL_USER_PASSWORD = 104,

      // Lizenz ungueltig
      /// (105) invalid license
      LICENSE_INVALID = 105,

      // Datenbankreparatur
      /// (106) database repair in progress
      DM_REPAIR = 106,

      // angemeldete Attribute des Configs wurden wegen Typaenderung automatisch abgemeldet
      /// (107) automatic disconnect due to config change
      AUTOMATIC_DISCONNECT = 107,

      // Lizenzdaten
      /// (108) license information
      LICENSE_INFO = 108,

      // Ein dpConnect/queryConnect/alertConnect wird abgebrochen bevor die Antwort eintrifft.
      /// (109) aborting a pending dpConnect/queryConnect/alertConnect
      CONNECT_ABORTED = 109,

      // Query-Connect wurde vom Event-Manager wegen Aktiv/Passiv-Umschaltung abgemeldet
      /// (110) query connect has been disconnected by event manager due to active/passive switch
      QUERY_CONNECT_ABORTED_BY_EVENT = 110,

      // Distribution-Manager hat eine von 2 Verbindungen verloren! Query-Connect wurde abgemeldet.
      /// (111) lost one of two connections, query connect has been disconnected by distribution manager
      QUERY_CONNECT_ABORTED_BY_DIST = 111,

      // Datamanager laeuft im Emergency Modus
      /// (112) DM is running in emergency mode
      DM_EMERGENCY_MODE = 112,

      // Datamanger laeuft im Backup Modus
      /// (113) DM is running in backup mode
      DM_BACKUP_MODE = 113,

      /// (114) Values discarded  (e.g. CTRL too much pending runs)
      VALUES_DISCARDED = 114,

      /// (115) Message discarded due to a active/passive switch
      REDU_CHANGES_ABORTED = 115,

      /// (116) Variable already defined
      LIB_VAR_ALREADY_DEFINED = 116,

      /// (117) Libraray defined as #uses xxx does not exist
      LIB_NOTEXIST_USES = 117,

      /// (118) Last error already repeated
      SUPPRESS_ERROR_START = 118,

      /// (119) Last error repeated
      SUPPRESS_ERROR_END = 119,

      /// (120) pmontable: cannot get semaphore access
      PMON_NO_GET_SEM = 120, 

      /// (121) pmontable: cannot get shared memory access with shmget
      PMON_NO_GET_SHM = 121,

      /// (122) pmontable: cannot attach shared-memory
      PMON_NO_ATT_SHM = 122,

      /// (123) pmontable: cannot get shared-memory access with CreateFileMapping
      PMON_NO_GET_SHM_FILEMAPPING = 123,

      /// (124) pmontable: cannot map shared memory
      PMON_NO_MAP_SHM = 124,

      /// (125) pmontable: too many lines in progs-file, truncating
      PMON_PROGS_TOO_MANY_LINES = 125,

      /// (126) pmontable: could not open progs-file for writing
      PMON_PROGS_NO_WRITE = 126,

      /// (127) pmontable: did not find the progs-file
      PMON_PROGS_NOT_FOUND = 127,

      /// (128) pmontable: could not open progs-file for reading
      PMON_PROGS_NO_READ = 128,

      /// (129) pmontable: progs file is not version 1, trying to read old version
      PMON_PROGS_WRONG_VERSION_TRY_OLD = 129,

      /// (130) pmontable: progs file is not version 1, can not proceed
      PMON_PROGS_WRONG_VERSION = 130,

      /// (131) pmontable: illegal entry in progs file
      PMON_PROGS_ILLEGALENTRY = 131,

      /// (132) pmontable: illegal startmode in progs file
      PMON_PROGS_ILLEGALSTARTMODE = 132,

      /// (133) could not load shared library
      SHAREDLIB_NOTFOUND = 133,

      /// (134) could not find function in shared library
      SHAREDLIB_NOFUNCTION = 134,

      /// (135) ASCII export cannot be started, PVSS project start possibly in progress
      ASCII_NOSTART = 135,

      /// (136) Error in SSL FUNCTION
      SSL_FUNC_ERROR = 136,

      /// (137) server cert could not be found in any config directory
      SSL_SERVERCERT_NOTFOUND = 137,

      /// (138) server cert can not be used
      SSL_SERVERCERT_UNKNOWNERROR = 138,

      /// (139) the private key could not be found in any config directory
      SSL_PRIVKEY_NOTFOUND = 139,

      /// (140) the private key can not be used
      SSL_PRIVKEY_UNKNOWNERROR = 140,

      /// (141) connection to client could not be encrypted
      SSL_CLIENTCONNECTION_NOENCRYPT = 141,

      /// (142) pmontable: the loaded project is not the just started one
      PMON_PROJ_CUR_NOT_STARTED = 142,

      /// (143) query aborted with error
      QUERY_ABORTED_WITH_ERROR = 143,

      /// (144) Connection to PVSS System lost
      DIST_SYSTEM_DISCONNECTED = 144,

      /// (145) driver output queue to EV manager exceeded xx
      DRV_QUEUE_FULL = 145,

      /// (146) number of VC xx without sent to ev manager
      DRV_TOO_MANY_VC = 146,

      /// (147) driver queue empty
      DRV_QUEUE_EMPTY = 147,

      /// (148) this function is marked as deprecated
      FUNCTION_DEPRECATED = 148,

      /// (149) license information for fixed UI licenses invalid
      LICENSE_FIXED_UI_INVALID = 149,

      /// (150) license number for code x can not be set to x because x are in use
      LICENSE_CODE_IN_USE = 150,

      /// (151) data point type error in data point type '_Event'
      DP_ERROR_DPT_EVENT = 151,

      /// (152) modification count for fixed ui licenses exceeded
      LICENSE_FIXED_UI_EXCEEDED = 152,

      /// (153) cannot occupy fixed license 
      LICENSE_HWCODE_USAGE = 153,

      /// (154) cannot open license shield file
      LICENSE_SHIELD_NOTFOUND = 154,

      /// (155) license in fixed license shield file invalid
      LICENSE_SHIELD_INVALID = 155,

      /// (156) driver initialization finished
      DRIVER_INIT_FINISHED = 156,

      /// (157) dpQueryConnect was refreshed tue to an active/passive switch in system
      DPQUERYCONNECT_REFRESHED = 157,

      /// (158) could not create the server socket on port xx
      SERVERSOCKET_OPEN_ERROR = 158,

      /// (159) could not create the alive-server socket on port xx
      ALIVESOCKET_OPEN_ERROR = 159,

      /// (160) lost connection to system
      CON_DISC_SYSTEM = 160,

      /// (161) lost connection to all systems
      CON_DISC_ALL = 161,

      /// (162) got connection to system $1
      CON_SYSTEM_OK = 162,

      /// (163) some log messages will be lost
      LOGMSG_LOST = 163,

      /// (164) maxLogFileSize limit reached, unable to rename
      LOGLIMIT_REACHED_NORENAME = 164,

      /// (165) maxLogFileSize limit reached, renamed to xxx
      LOGLIMIT_REACHED_RENAME = 165,

      /// (166) Could not open alive connection to $1: $2
      ERR_OPEN_ALIVE_CONNECTION = 166,

      /// (167) received number of languages does not match with number in config file
      INVALID_LANG_COUNT = 167,

      /// (168) initialize xx alerts
      INIT_ALERTS = 168,

      /// (169) initialize xx dp functions
      INIT_DPFUNCS = 169,

      /// (170) signal xx received - exiting
      SIG_RECEIVED = 170,

      /// (171) delaying exit for xx seconds
      EXIT_DELAYED = 171,

      /// (172) Request canceled 
      REQUEST_CANCELED = 172,          // the answer of a aborted Request should contain this error code

      // Setze Message Format f�r die Verbindung zu $1 auf Vers.$2
      /// (173) Set the message format for the connection from $1 to $2.
      SET_MSG_VERSION = 173,

      /// (174) Authorization error
      AUTH_ERROR = 174,

      // dpSet/dpGet*/dpConnect MSGs sind nur "systemrein" m�glich.
      /// (175) this request cannot address more than one system 
      INVALID_DIST_REQUEST = 175,

      /// (176) uncaught_exception in thread
      UNCAUGHT_EXCEPTION = 176,

      /// (177) could not start xx: xxx
      CANNOT_START = 177,

      /// (178) executed xx
      EXECUTED = 178,
      
      /// (179) Alarm Reduction: The alert $1 is also referenced in the sum alerts $2 Multiple references are not allowed.
      MULTI_REFERRED_ALERT = 179,

      /// (180) Alarm Reduction: The alert $1 is also referenced in the sum alerts $2 Specify an alert class to avoid multiple references.
      SPECIFY_ALERT_CLASS = 180,

      /// (181) Closing Connection
      CLOSINGCONNECTION = 181,

      /// (182) the config _alert_class doesnt exist in DP
      NO_ALERTCLASS_DP = 182,
      
      /// (183) Aborted value change
      DP_SET_ABORTED = 183,

      /// (184) time differences between $1 and $2 are to big, please correct this!
      CORRECT_TIME_DIFFERENCES = 184,

      /// (185) Config file entry $1 found. Please move this entry to section $2
      MOVE_CONFIG_ENTRY = 185,

      /// (186) AlertPair not found
      ALERT_PAIR_NOT_FOUND = 186,

      /// (187) no gone between two came
      NO_GONE_BETWEEN_TWO_CAME = 187,

      /// (188) alert not visible and not gon
      ALERT_NOT_VISIBLE_AND_NOT_GONE = 188,

      /// (189) obsolete bit not set, repaired
      OBSOLETE_BIT_NOT_SET = 189,

      /// (190) eldest ack bit not set, repaired
      ELDEST_ACK_BIT_NOT_SET = 190,

      /// (191) (De-)Escalation error: $DP. $1 must not differ
      ESCALATION_ALERTCLASS_DIFFERENCE = 191,

      // Rekursive Parametrierung von Summenalarmen: $DP ist auch in $1 enthalten
      /// (192) Recursive configuration for summary alarms : $DP is stored in $1
      SUMALERT_RECURSION = 192,

      /// (193) alert $DP has no alert class.
      NO_ALERT_CLASS = 193, 

      // AlertClass $1 geloescht, auf welche noch ein Verweis existiert
      /// (194) referred alert class $1 deleted
      USED_ALERT_CLASS_DELETED = 194,

      /// (195) received SysMsg(SHUT_DOWN_MANAGER), exiting ...
      SHUTDOWN_MSG_RECEIVED = 195,

      /// (196) Illegal byte ($1) in UTF-8 string
      ILLEGAL_UTF8_BYTE = 196,

      /// (197) Error, during creating endpoint
      CREATING_END_POINT = 197,

      /// (198) Creating secure connection is failed. Error code: ($1)
      CERT_FILE_ERROR = 198,
			
      /// (199) SSL wrapper init failed.
      INIT_SSL_WRAPPER_ERROR = BcmError::BCM_INIT_SSL_WRAPPER_ERROR,
			
      /// (200) Cert file error, the given values are failed at the initialization: ($1)
      INIT_CERT_FILES_ERROR = BcmError::BCM_INIT_CERT_FILES_ERROR,
			
      /// (201) SSL library error. Problem with creating objects or calling functions.
      SSL_LIBRARY_ERROR = BcmError::BCM_SSL_LIBRARY_ERROR,			
			
  	  /// (202) Unknown error when creating SSL context.
      SSL_UNKNOWN_ERROR = BcmError::BCM_SSL_UNKNOWN_ERROR,

      /// (203) Connected to wrong host $1
      CONNECT_TO_WRONG_HOST = 203,

      /// (204) Not a redundant system, exiting ...
      NOT_REDUNDANT_SYSTEM = 204,

      /// (205) Not a distributed system, exiting ...
      NOT_DISTRIBUTED_SYSTEM = 205,
      
      /// (206) Required SSL version : ($1)
      SSL_VERSION_MISMATCH = BcmError::BCM_SSL_VERSION_MISMATCH,
      
      /// (207) Cannot load SSL ($1) library.
      INIT_SSL_LOAD_LIBRARY_ERROR = BcmError::BCM_INIT_SSL_LOAD_LIBRARY_ERROR,
      
      /// (208) Cannot load SSL function ($1).
      LOAD_SSL_FUNCTION_ERROR = BcmError::BCM_LOAD_SSL_FUNCTION_ERROR,
      
      /// (209) Cannot find the host in the allowed host list ($1).
      CANNOT_FIND_HOST_IN_HOSTLIST = 209,

      /// (210) The $1 connection from client ($2) to server ($3) is established.
      CONNECTION_ESTABLISHED = 210,

      /// (211) Could not find any certificat matching $1.
      BCM_ERR_WINCERT_NOMATCHING = BcmError::BCM_ERR_WINCERT_NOMATCHING,

      /// (212) No valid certificate matching subject string ($1) found.
      BCM_ERR_WINCERT_NOVALIDBYSUBJECT = BcmError::BCM_ERR_WINCERT_NOVALIDBYSUBJECT,

      /// (213) Could not open certificate store <store>. + getLastError() fehlermeldung
      BCM_ERR_OPENSTORE = BcmError::BCM_ERR_OPENSTORE,

      /// (214) Certificate with X509_ASN_ENCODING is required.
      BCM_ERR_REQ_X509 = BcmError::BCM_ERR_REQ_X509,

      /// (215) Private key for Certificate $1 is required
      BCM_ERR_CRYPT_ACQ = BcmError::BCM_ERR_CRYPT_ACQ,

      /// (216) Certificates $1 private key has to be exportable.
      BCM_ERR_CRYPT_EXPKEY = BcmError::BCM_ERR_CRYPT_EXPKEY,

      /// (217) Cipher $1 cannot be set.
      BCM_ERR_WRAP_CIPHER = BcmError::BCM_ERR_WRAP_CIPHER,

      /// (218) Certificate $1 is expired.
      BCM_ERR_CERT_EXPIRED = BcmError::BCM_ERR_CERT_EXPIRED,
      
      /// (219) Certificate $1 verification failed, due to: $2.
      BCM_ERR_CERT_VERIFICATION_FAILED = BcmError::BCM_ERR_CERT_VERIFICATION_FAILED,
      
      /// (220) Multiplexing proxy starts.
      MXPROXY_START = 220,
      
      /// (221) Multiplexing proxy stops.
      MXPROXY_STOP = 221,
	  
      /// (222) Accepting $1 connection from host $2
      ACCEPT_CONNECTION = 222,
	  
      /// (223) The localhost configuration in the hosts file is missing. localhost $1 assumed.
      LOCALHOST_MISSING = 223,

      /// (224) Username or password entri in config file
      CONFIG_SEC_ISSUE = 224,

      /// (225) Language configuration on client ($1) differs from server ($2).
      LANG_CONFIG_MISMATCH = 225,

      /// (226) Cannot send DP_MSG_MANIP_DPNAME to $MAN of an unpachted 3.12 or 3.13. Sending the entire identification instead.
      DPRENAME_UNPATCHED = 226,
      
      /// (227) $1 file cache $2 not found. Requesting the $1 from Data-Manager.
      FILE_CACHE_NOT_FOUND = 227

      /// (228) Dynamic manager number pool exhausted - connection denied.
      ,NO_MAN_NUM_FREE = 228
    
      /// (229) This Manager is already connected.
      ,MAN_ALREADY_CONNECTED = 229
    
      /// (230) Maximum number of managers licensed reached
      ,LICENSE_INVALID_MAX_MAN = 230

      /// (231) No common message compression for $1
      ,NO_COMMON_MSG_COMPRESSION = 231

      /// (237) A Challenge/Response handshake is still in progress
      ,CR_HANDSHAKE_IN_PROGRESS = 237
    };

    /** Constructor (generic).
        Use this constructor:
        1) if you want to place your error message texts into a special message catalog and/or
        2) if you want to easily pass arguments to the message text.
        @param prio  The severity of the error (information only, severe error, ...)
        @param type  The error type (parametrization, implementation, ...)
        @param catalog The message catalog filename (without the .cat extension) located
          in one of the project_path/msg/language directories.
          If this is an empty string or a 0-pointer, the PVSS standard catalog errors.cat is used.
        @param code  The error number (== line number in message catalog file).

        You can pass up to 9 notes.
        The arguments are then used to replace the argument-placeholders given in the
        error-message text from the catalog, whereby $1 is replaced with the first note,
        $2 with the second, and so on.

        All arguments, which are not used for $-substitution, will also be printed when writing
        an ErrClass onto the error stream.
        @param note1 An additional note (can be used as $1).
        @param note2 An additional note (can be used as $2).
        @param note3 An additional note (can be used as $3).
        @param note4 An additional note (can be used as $4).
        @param note5 An additional note (can be used as $5).
        @param note6 An additional note (can be used as $6).
        @param note7 An additional note (can be used as $7).
        @param note8 An additional note (can be used as $8).
        @param note9 An additional note (can be used as $9).
    */
    ErrClass(ErrPrio prio, ErrType type, const char *catalog, ErrCode code,
             const char *note1 = 0, const char *note2 = 0,  const char *note3 = 0,
             const char *note4 = 0, const char *note5 = 0,  const char *note6 = 0,
             const char *note7 = 0, const char *note8 = 0,  const char *note9 = 0);

    /** Constructor.
        Use if you have a DpIdentifier for $DP.
        @param prio  The severity of the error (information only, severe error, ...).
        @param type  The error type (parametrization, implementation, ...).
        @param catalog The message catalog filename.
        @param code  The error number (== line number in message catalog file).
        @param dpId  The datapoint related to the error.
        @param note1 An additional note (can be used as $1).
        @param note2 An additional note (can be used as $2).
        @param note3 An additional note (can be used as $3).
        @param note4 An additional note (can be used as $4).
        @param note5 An additional note (can be used as $5).
        @param note6 An additional note (can be used as $6).
        @param note7 An additional note (can be used as $7).
        @param note8 An additional note (can be used as $8).
        @param note9 An additional note (can be used as $9).
    */
    ErrClass(ErrPrio prio, ErrType type, const char *catalog, ErrCode code,
             const DpIdentifier & dpId,
             const char *note1 = 0, const char *note2 = 0,  const char *note3 = 0,
             const char *note4 = 0, const char *note5 = 0,  const char *note6 = 0,
             const char *note7 = 0, const char *note8 = 0,  const char *note9 = 0);

    /** Constructor (general).
        @param bits  PVSSulong.
        @param prio  The severity of the error (information only, severe error, ...).
        @param type  The error type (parametrization, implementation, ...).
        @param code  The error number (== line number in message catalog file).
        @param dpId  The datapoint related to the error.
        @param manId Our own manager identifier.
        @param usrId PVSSuserIdType.
        @param note1 An additional note (can be used as $1).
        @param note2 An additional note (can be used as $2).
        @param note3 An additional note (can be used as $3).
    */
    ErrClass(PVSSulong bits, ErrPrio prio, ErrType type, ErrCode code,
             const DpIdentifier & dpId, const ManagerIdentifier & manId,
             PVSSuserIdType usrId,
             const char* note1 = 0, const char* note2 = 0, const char* note3 = 0);

    /** Constructor (implementation).
        Use this constructor to report an error caused by the implementation of the manager.
        You may report all other types of errors, too.
        @param prio  The severity of the error (information only, severe error, ...).
        @param type  The error type (parametrization, implementation, ...).
        @param code  The error number (unexpected state, ...).
        @param note1  An additional note (can be used as $1).
        @param note2  An additional note (can be used as $2).
        @param note3  An additional note (can be used as $3).
    */
    ErrClass(ErrPrio prio, ErrType type, ErrCode code,
             const char* note1 = 0, const char* note2 = 0, const char* note3 = 0);

    /** Constructor (parametrization).
        Use this constructor to report an error caused by the parametrization.
        @param prio  The severity of the error (information only, severe error, ...).
        @param type  The error type (parametrization, implementation, ...).
        @param code  The error number (unexpected state, ...).
        @param dpId  The datapoint related to the error.
        @param manId Our own manager identifier. Get it with Manager::getMyManagerId().
        @param usrId Our own user ud. Get it with Manager::getUserId().
        @param note1  An additional note (can be used as $1).
        @param note2  An additional note (can be used as $2).
        @param note3  An additional note (can be used as $3).
   */
    ErrClass(ErrPrio prio, ErrType type, ErrCode code, const DpIdentifier & dpId,
             const ManagerIdentifier & manId, PVSSuserIdType usrId,
             const char *note1 = 0, const char *note2 = 0, const char *note3 = 0);

    /** Constructor (system).
        Use this constructor to report an error caused by the system, such as no memory.
        @param prio  The severity of the error (information only, severe error, ...).
        @param type  The error type (parametrization, implementation, ...).
        @param code  The error number (unexpected state, ...).
        @param catalog The message catalog filename.
        @param manId Our own manager identifier. Get it with Manager::getMyManagerId().
        @param note1  An additional note (can be used as $1).
        @param note2  An additional note (can be used as $2).
        @param note3  An additional note (can be used as $3).
    */
    ErrClass(ErrPrio prio, ErrType type, const char *catalog, ErrCode code, const ManagerIdentifier & manId,
             const char *note1 = 0, const char *note2 = 0, const char *note3 = 0);

    /** Constructor (system).
        Use this constructor to report an error caused by the system, such as no memory.
        @param prio  The severity of the error (information only, severe error, ...).
        @param type  The error type (parametrization, implementation, ...).
        @param code  The error number (unexpected state, ...).
        @param manId Our own manager identifier. Get it with Manager::getMyManagerId().
        @param note1  An additional note (can be used as $1).
        @param note2  An additional note (can be used as $2).
        @param note3  An additional note (can be used as $3).
    */
    ErrClass(ErrPrio prio, ErrType type, ErrCode code, const ManagerIdentifier & manId,
             const char *note1 = 0, const char *note2 = 0, const char *note3 = 0);

    /** Constructor.
        Use this constructor to report an error caused by a datapoint.
        @param prio  The severity of the error (information only, severe error, ...).
        @param type  The error type (parametrization, implementation, ...).
        @param code  The error number (unexpected state, ...).
        @param dpId  The datapoint element that caused the error.
        @param note1  An additional note (can be used as $1).
        @param note2  An additional note (can be used as $2).
        @param note3  An additional note (can be used as $3).
    */
    ErrClass(ErrPrio prio, ErrType type, ErrCode code, const DpIdentifier &dpId,
             const char *note1 = 0, const char *note2 = 0, const char *note3 = 0);

    /// Default constructor. Creates an ErrClass with a type of NOERR
    ErrClass();

    /// Copy Constructor
    ErrClass(const ErrClass &other);

    /** Destructor.
    */
    virtual ~ErrClass();

#if defined (_WIN32) && !defined (_WIN32_WCE)
    /** Write FATAL and SEVERE errors in the NT-EventLog.
        @osdiff Only available for Windows.
    */        
    void reportEvent() const;
    
    /** Get the event viewer.
        @osdiff Only available for Windows.
        @return HANDLE Event Viewer Handle.
    */     
    static HANDLE getEventViewerHandle()
    {
      return eventViewerHandle;
    }
#endif // _WIN32

    /** Get the error type.
        @return ErrType ERR_IMPL, ERR_PARAM, etc.
    */
    virtual ErrType isA() const { return kind; }

    /** Writes error text to the output stream.
        @param erroutStream Output stream.
    */
    virtual void outStream(std::ostream &erroutStream) const;

    /** write the content if this class into a string.
        @return a string in the format of outStream() used e.g. in the log file
    */
    std::string toString() const;

    /** Set the static variables outStreamCB and outStreamClientData.
        @param cbFunc Set to the static variable OutStreamCB.
        @param clientData Set to the static variable outStreamClientData to be set.
    */
    static void setOutStreamCB(OutStreamCB cbFunc, void *clientData);

    /// Internal use only (by ErrHdl)
    static OutStreamCB getOutStreamCB() { return outStreamCB; }

    /// Internal use only (by ErrHdl)
    static void *getOutStreamClientData() { return outStreamClientData; }

    /** Get the time of the creation of this object,
        If the errorClass object was received from a message stream,
        it holds the timestamp from the original creator.
        @return TimeVar with the creation time.
    */
    const TimeVar & getErrorTime() const { return errTime; }

    /// Get the error text as written in the log file.
    /// @param langidx Language index.
    /// @return CharString with the error text.
    CharString getErrorText(int langidx = -1) const;

    /// Get the error priority.
    /// @return ErrPrio PRIO_FATAL, PRIO_SEVERE, PRIO_WARNING or PRIO_INFO.
    ErrPrio getPriority() const {return prio; }

    /// Get the error type.
    /// @return ErrType ERR_SYSTEM, ERR_CONTROL, etc. 
    ErrType getErrorType() const {return kind; }

    /// Get the name of the catalog. Returns empty for the std. PVSS catalog (_errors.cat)
    /// @return CharString with the catalog name.
    const CharString &getCatalog() const { return catName; }

    /// Get the error code.
    /// @return ErrCode error code.
    ErrCode getErrorId() const {return code; }

    /// Get the DpIdentifier, if it was set.
    /// @return DpIdentifier Const reference to the dp identifier.
    const DpIdentifier& getDpId() const  {return dpId; }

    const DpIdentifier& getDpIdf() const { return getDpId(); }

    /// Set the Priority
    /// @param _p new Priority to be set.
    void setPriority(ErrPrio p) { prio = p; }

    /// Set the DpIdentifier
    /// @param _dpId DpIdentifier to be set.
    void setDpId(const DpIdentifier &_dpId) { dpId = _dpId; ubits |= ERR_UB_DPID; }

    /// Get ManagerIdentifier, if it was set.
    /// @return ManagerIdentifier Const.
    const ManagerIdentifier& getManagerId() const { return manId; }
    
    /// Set ManagerIdentifier.
    /// @param _m ManagerIdentifier to be set.
    void setManagerId(const ManagerIdentifier &_m) { manId = _m; ubits |= ERR_UB_MANID; }

    /// Get user id, if set.
    /// @return PVSSuserIdType user id.
    PVSSuserIdType getUserId() const { return userId; }
    
    /// Set user id.
    /// @param _u User Id to be set.
    void setUserId(const PVSSuserIdType &_u) { userId = _u; ubits |= ERR_UB_USERID; }

    /// Internal use only (by ErrHdl)
    /// @param path CharString.
    static void init(const CharString &path);

    /// Assignment operator.
    /// @param rVal ErrClass reference to be assigned to this.
    /// @return ErrClass with the new value.
    ErrClass &operator=(const ErrClass &rVal);

    /// Equal to operator.
    /// @param rVal ErrClass with the compared value.
    /// @return int 1 if the values are equal, otherwise 0.
    int operator==(const ErrClass &rVal) const;
    
    /// Non equal to operator.
    /// @param rVal ErrClass with the compared value.
    /// @return int 1 if true, otherwise 0.
    int operator!=(const ErrClass &rVal) const {return !operator==(rVal);}

    /** Outputs this to the itcNdrUbSend stream.
        @param ndrStream Output stream.
        @param error Streamed ErrClass variable.
        @return itcNdrUbSend stream.
    */
    friend DLLEXP_BASICS itcNdrUbSend &operator<<(itcNdrUbSend &ndrStream, const ErrClass &error);
    
    /** Receives the ErrClass value from the itcNdrUbReceive stream.
        @param ndrStream input stream.
        @param errorPtr Pointer to the ErrClass variable which will receive the value
        from the stream. This method will create new instance of the ErrClass.
        @return itcNdrUbReceive stream.
    */    
    friend DLLEXP_BASICS itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream, ErrClass *&errorPtr);

    /** Set the catalog name and return reference to this.
        Therefore you can use a constructor which has no catalog parameter e.g.
        ErrClass(<arguments>).setCatalog("xxx")
        @param cat CharString with the catalog name.
        @return Reference to this.
    */
    ErrClass& setCatalog(const CharString &cat) { catName = cat; return *this; }

  protected:
#ifdef _WIN32
    /// EventViewer handle
    /// @osdiff Available only for windows.
    static HANDLE eventViewerHandle;
#endif // _WIN32

    /// cached error tests
    static DynVar     texts;

    /// catalog Name; "" == std. PVSS (_errors.cat)
    CharString        catName;

    /// used-marker
    PVSSulong         ubits;

    /// priority
    ErrPrio           prio;
    
    /// error type
    ErrType           kind;

    /// error code
    ErrCode           code;

    /// DpIdentifier associated with this error
    DpIdentifier      dpId;

    /// Manager Id
    ManagerIdentifier manId;

    /// User Id
    PVSSuserIdType    userId;

    /// List of strings, which will replace the $1,$2...$9 jokers, if specified
    DynVar            notes;

    /// time when the instance was created
    TimeVar           errTime;

  private:

    /// static output stream used in outStream method
    static OutStreamCB       outStreamCB;

    /// static buffer used in outStream method
    static void *            outStreamClientData;

    /// return text from catalog matching current catName + code in a given language
    CharString getCatText(int langidx = 0) const;
    void setNotes(const char* note1 = 0, const char* note2 = 0, const char* note3 = 0,
                  const char *note4 = 0, const char *note5 = 0, const char *note6 = 0,
                  const char *note7 = 0, const char *note8 = 0, const char *note9 = 0);
};

#endif /* _ERRCLASS_H_ */
