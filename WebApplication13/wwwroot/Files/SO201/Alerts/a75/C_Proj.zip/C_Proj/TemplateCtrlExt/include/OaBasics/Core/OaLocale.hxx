#ifndef _OALOCALE_HXX_
#define _OALOCALE_HXX_

#include <ctime>
#include <CharString.hxx>
#include <SimplePtrArray.hxx>
#include <Types.hxx>
#include <vector>

class LanguageFallbackTable;


namespace OaLanguage
{
  enum : GlobalLanguageIdType
  {
    DeAt = 10000,
    EnUs = 10001,
    HuHu = 10002,
    JpJp = 10003,
    ZhCn = 10004,
    EnGb = 10005,
    NlNl = 10006,
    TrTr = 10007,
    ItIt = 10008,
    FrFr = 10009,
    EsEs = 10010,
    DeDe = 10011,
    ElGr = 10012,
    IwIl = 10013,
    FrCa = 10014,
    DaDk = 10015,
    FiFi = 10016,
    NoNo = 10017,
    PtPt = 10018,
    SvSe = 10019,
    IsIs = 10020,
    CsCz = 10021,
    PlPl = 10022,
    RoRo = 10023,
    HrHr = 10024,
    SkSk = 10025,
    SlSi = 10026,
    RuRu = 10027,
    BgBg = 10028,
    ArSa = 10029,
    ZhTw = 10030,
    KoKr = 10031,
    JaJp = 10032,
    ThTh = 10033,
    DeCh = 10034,
    FrCh = 10035,
    ItCh = 10036,
//    FaIr = 10037
    ViVn = 10038,
    IdId = 10039,
    LtLt = 10040,
    KaGe = 10041,
    MsMy = 10042,
    SrRs = 10043,
    PtBr = 10044,
    EsAr = 10045,
    EsBo = 10046,
    EsCl = 10047,
    EsCo = 10048,
    EsCr = 10049,
    EsCu = 10050,
    EsDo = 10051,
    EsEc = 10052,
    EsGt = 10053,
    EsHn = 10054,
    EsMx = 10055,
    EsNi = 10056,
    EsPa = 10057,
    EsPe = 10058,
    EsPr = 10059,
    EsPy = 10060,
    EsSv = 10061,
    EsUy = 10062,
    EsVe = 10063,
    MyMm = 10064,
    KmKh = 10065,
    UkUa = 10066,
    SqAl = 10067,
    MkMk = 10068,
    LvLv = 10069,
    KnIn = 10070,
    HiIn = 10071
  };
}

namespace OaIsoLanguage
{
  enum : GlobalLanguageIdType
  {
    DeAt = 0,
    EnUs = 1,
    HuHu = 2,
    JpJp = 3,
    ZhCn = 4,
    EnGb = 5,
    NlNl = 6,
    TrTr = 7,
    ItIt = 8,
    FrFr = 9,
    EsEs = 10,
    DeDe = 11,
    ElGr = 12,
    IwIl = 13,
    FrCa = 14,
    DaDk = 15,
    FiFi = 16,
    NoNo = 17,
    PtPt = 18,
    SvSe = 19,
    IsIs = 20,
    CsCz = 21,
    PlPl = 22,
    RoRo = 23,
    HrHr = 24,
    SkSk = 25,
    SlSi = 26,
    RuRu = 27,
    BgBg = 28,
    ArSa = 29,
    ZhTw = 30,
    KoKr = 31,
    JaJp = 32,
    ThTh = 33,
    DeCh = 34,
    FrCh = 35,
    ItCh = 36,
    FaIr = 37,
    ViVn = 38,
    IdId = 39,
    LtLt = 40,
//    KaGe = 10041,
    Posix = 254, 
    Meta = 255, 
    Neutral = 65535
  };
}

/// Flags for definition of language locale format
enum LangNameFormatOptions
{
  BEGIN_WITH_LOWER_CASE = 0x1,
  BEGIN_WITH_UPPER_CASE = 0x2,
  HAS_DASH_SEPARATOR = 0x4,
  HAS_UNDERLINE_SEPARATOR = 0x8,
  END_WITH_UPPER_CASE = 0x10,
  END_WITH_LOWER_CASE = 0x20,
  HAS_UTF8_SUFFIX = 0x40
};

inline constexpr LangNameFormatOptions operator|(LangNameFormatOptions a, LangNameFormatOptions b)
{
  return static_cast<LangNameFormatOptions>(static_cast<unsigned>(a) | static_cast<unsigned>(b));
}

/// Enum specifying the format for the language locale
enum class LangNameFormat
{
  /// ISO conform encoding including the encoding.
  /// Format: language_country.codeset
  /// language is a lowercase, two-letter, ISO 639 language code
  /// country is an uppercase, two-letter, ISO 3166 country code
  /// codeset is always utf8 as we support only utf8 codecs
  /// e.g.: en_US.utf8
  IsoWithEncoding = LangNameFormatOptions::BEGIN_WITH_LOWER_CASE | LangNameFormatOptions::HAS_UNDERLINE_SEPARATOR | LangNameFormatOptions::END_WITH_UPPER_CASE | LangNameFormatOptions::HAS_UTF8_SUFFIX,

  /// ISO conform encoding
  /// Format: language_country
  /// language is a lowercase, two-letter, ISO 639 language code
  /// country is an uppercase, two-letter, ISO 3166 country code
  /// e.g.: en_US
  Iso = LangNameFormatOptions::BEGIN_WITH_LOWER_CASE | LangNameFormatOptions::HAS_UNDERLINE_SEPARATOR | LangNameFormatOptions::END_WITH_UPPER_CASE,

  /// WinCC OA/HMI default format
  /// Format: language-country
  /// language is a lowercase, two-letter, ISO 639 language code
  /// country is an uppercase, two-letter, ISO 3166 country code
  /// e.g.: en-US
  Hmi = LangNameFormatOptions::BEGIN_WITH_LOWER_CASE | LangNameFormatOptions::HAS_DASH_SEPARATOR | LangNameFormatOptions::END_WITH_UPPER_CASE,

  /// Format as specified for HTTP.
  /// See also: https://www.w3.org/Protocols/rfc2616/rfc2616-sec3.html#sec3.10
  /// e.g. en-US
  Http = Hmi,

  /// Format as specified by OPC UA
  /// See also: http://www.hb-softsolution.com/comet/doc/stack/org/opcfoundation/ua/builtintypes/LocalizedText.html
  /// e.g. en-US
  OpcUa = Hmi,

  /// Format as used by QT
  /// See also: http://doc.qt.io/qt-5/qlocale.html#QLocale-1
  /// e.g. en_US.utf8
  Qt = IsoWithEncoding,

  /// Format of the language folder names used e.g. by msg catalogs
  OaLangFolder = IsoWithEncoding,

  /// Format use din XML-PNL format for writing
  XmlPnl = IsoWithEncoding
};

/// the Locale class of OA
/// Get access and information to all available languages in OA
/// A language definition in OA has following information
/// +ID (of type GlobalLanguageIdType): Unique ID in OA
/// +LangName: Unique string representing language in OA
/// +OsLocale: Operating system dependent locale string
/// +OsLcid: The locale culture identifier (LCID), only relevant on Windows CE
/// +MibEnum: see http://www.iana.org/assignments/character-sets
/// +Comment: The description of the language
/// 
/// @classification public
class DLLEXP_OABASICS OaLocale
{
  friend class UNIT_TEST_FRIEND_CLASS;
  friend class Resources;

  public:

    static const GlobalLanguageIdType UNDEFINED_LANGUAGE;

    enum
    {
      /// MIB enumeration value for UTF-8 encoding.
      UTF8_MIB_ENUM = 106,
      /// MIB enumeration value for ISO88591 encoding.
      ISO88591_MIB_ENUM = 4
    };

    /// get list of all possible languages.
    static const std::vector<GlobalLanguageIdType> getAllLanguageIds();

    ///Checks if a given id is valid.
    ///@param id The ID of the language
    ///@return true if ID is valid otherwise false
    static bool isIdValid(GlobalLanguageIdType id);

    ///Gets the unique lang name string for a given language
    ///@param id The ID of the language
    ///@param format The format of the language
    ///@return string representing in OA (e.g. "en-US") according its format, or in case of error empty string
    static CharString getLangName(GlobalLanguageIdType id, LangNameFormat format = LangNameFormat::Hmi);

    ///Get a comment describing a given language
    ///@param id The ID of the language
    ///@return String with a description of the language (e.g. English, US), or in case of error empty string
    static CharString getComment(GlobalLanguageIdType id);

    ///Get a comment describing a given language
    ///@param langName The string representing language in OA
    ///@return String with a description of the language (e.g. English, US), or in case of error empty string
    static CharString getComment(const CharString &langName);

    //Converts the encoding name to its corresponding mib enum
    //@param encoding one of the encoding that can be handeld by QTextCodec (eg. "UTF-8", see qt documentation)
    //@return mib enum that fits best to encoding
    static int getMibEnumForEncoding(const char* encoding);

    ///Gets the operating system locale string for a given language
    ///@param id The ID of the language
    ///@return string representing the language in operating system (e.g. en-US on windows), or in case of error empty string
    static CharString getOsLocale(GlobalLanguageIdType id);

    ///Gets the operating system locale string for a given language
    ///@param langName The string representing language in OA
    ///@return string representing the language in operating system (e.g. en-US on windows), or in case of error empty string
    static CharString getOsLocale(const CharString &langName);

    ///Gets the operating system locale id for a given language
    /// only for Windows CE platform: locale culture identifier (LCID)
    /// NOTE: WinCE does not support locale_t, setlocale, etc.
    /// Instead, the Windows NLS API and LCIDs must be used.
    ///@param id The ID of the language
    ///@return number representing the language in operating system, or in case of error OaLocale::UNDEFINED_LANGUAGE;
    static int getWinLcid(GlobalLanguageIdType id);

    ///Gets the language id for a given lang name string
    ///@param langName The string representing language in OA
    ///@return The ID of the language, or in case of error OaLocale::UNDEFINED_LANGUAGE;
    static GlobalLanguageIdType getIdByLangName(const CharString &langName);

    /// get the record of global language table by the starting part of global language string and 
    /// whether the locale uses UTF8 encoding or not
    /// @param partialLangString the starting substring of the global language string, e.g. de_AT
    /// @param isUTF8 if the locale uses UTF8 encoding or not
    /// @return The ID of the language, or in case of error OaLocale::UNDEFINED_LANGUAGE;
    static GlobalLanguageIdType getIdByLangName(const CharString &partialPvssLocale, PVSSboolean isUTF8);

    ///Gets the language id for a given OS locale string
    ///@param osLocale The string representing language on current operating system
    ///@return The ID of the language, or in case of error OaLocale::UNDEFINED_LANGUAGE;
    static GlobalLanguageIdType getIdByOsLocale(const CharString &osLocale);

    ///Gets the language id for current OS locale
    ///@return The ID of the language, or in case of error OaLocale::UNDEFINED_LANGUAGE;
    static GlobalLanguageIdType getIdOfCurrentOsLocale();

    /** get a list of all matching languages
    @n This list tells you in what order you have to search through the language subdirectories
    of msg and help. The list contains at least two entries (US English and Austrian German).
    @param res the result
    @param lang the ID of the global language you are looking for
    @return true if OK
    */
    static PVSSboolean getAllFallbackLangs(GlobalLanguageIdType lang, std::vector<GlobalLanguageIdType> &res);

    /// get encoding for given language
    /// @param idx the ID of the language
    /// @return encoding or empty string in error case
    static CharString getEncoding(GlobalLanguageIdType id);

    /// get MIB enum for given language
    /// @param id the ID of the language
    /// @return MIB enum or -1 in error case
    static int getMibEnum(GlobalLanguageIdType id);

    /// Defines whether the internal encoding is UTF-8
    /// default before initialization of language tables is UTF-8
    /// @param id the ID of the language
    static PVSSboolean isUtf8Encoded(GlobalLanguageIdType id);

    /// Determine whether the encoding of the given language makes it possible to traverse a string bytewise
    /// to determine ASCII characters (0-127). In case of a SBCS (single byte character set), the result is true.
    /// In case of a MBCS (multibyte character set), it depends on the kind of encoding. Some encodings guarantee
    /// that all bytes within a multibyte sequence differ from ASCII characters, in some encodings, one cannot
    /// know from a single byte whether it is meant as an ASCII character or it is part of a multibyte sequence.
    /// This function examines only encodings (identified by MIB-enums) currently used in WinCC OA.
    ///
    ///   @param mibEnum The language to examine, see Resources::getMibEnum().
    ///   @return PVSS_TRUE if the encoding allows bytewise traversion to detect ASCII characters.
    ///           PVSS_FALSE, otherwise (also in case of unknown encoding)
    ///
    static PVSSboolean mibCanDetectAsciiBytewise(int mibEnum);

    /// set locale according to language table
    /// @param id the global language id
    static PVSSboolean setAppLocale(GlobalLanguageIdType id);

    /// set locale according to language table
    /// @param cat the language
    /// @param id the global language id
    static PVSSboolean setAppLocale(int cat, GlobalLanguageIdType id);

    /// set locale according to language table
    /// @param name the language name
    static PVSSboolean setAppLocale(const CharString &name);

    /// save current locale to internal memory
    static void saveAppLocale() { saveAppLocale(LC_ALL, savedLocale); }

    /// save current locale to supplied string
    /// @n The locale saved into string by saveAppLocale()is nonportable - use for subsequent restoreAppLocale() only!
    /// @param cat the cat
    /// @param csRef the supplied string
    static void saveAppLocale(int cat, CharString &csRef);

    /// restore current locale from internal memory
    static void restoreAppLocale() { restoreAppLocale(LC_ALL, savedLocale); }

    /// restore current locale from supplied string
    /// @param cat the cat
    /// @param cs the supplied string
    static void restoreAppLocale(int cat, const CharString &cs);

  private:

    static CharString savedLocale;

    static LanguageFallbackTable *globLangFallbackTable;

    static CharString getLangNameLongByShort(const CharString &langName);
    static CharString getLangNameShortByLong(const CharString &langName);

    static const CharString LANG_NAME_LONG_SUFFIX;
    static const CharString LANG_NAME_LONG_SEPERATOR;
    static const CharString LANG_NAME_LONG_SYMBOL;
    static const CharString LANG_NAME_SHORT_SYMBOL;
};


#endif
