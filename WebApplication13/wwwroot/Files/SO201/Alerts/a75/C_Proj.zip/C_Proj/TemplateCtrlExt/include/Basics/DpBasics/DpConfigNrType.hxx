// DATEIBESCHREIBUNG ==============================================================
// DATEINAME:     DpConfigNrType.hxx
// VERANTWORTUNG: Johannes Ertl
// BESCHREIBUNG:  Das ist die Parametrierungsnummer (die 4.) der 6-stelligen
//                Adressierungsnummer (siehe Doku "DpConfigs und deren Adressierung")
//
// AENDERUNGS-HISTORIE
// Ver.  | Datum      | Aenderungen                            | ModNr.| Autor
// ------+------------+-----------------Anfang-----------------+-------+-----------
//   1.0 |            | 1.Erstellung mit Westmount-OMT         |     0 |
// ======================================Ende======================================
#ifndef _DPCONFIGNRTYPE_H_
#define _DPCONFIGNRTYPE_H_
// System-Include-Files
#include <Types.hxx>

// ========== DpConfigNrType ============================================================
/** the internal config number 
*/
enum DpConfigNrType {
  /// (0). no valid config
  DPCONFIGNR_NOCONFIGNR,
  /// (1). 
  DPCONFIGNR_DPVALUE,
  /// (2).
  DPCONFIGNR_DEFVALUE,
  /// (3).
  DPCONFIGNR_CONNDISPATCHINFO,
  /// (4).
  DPCONFIGNR_UIDISPATCHINFO,
  /// (5).
  DPCONFIGNR_UIINTERN,
  /// (6).
  DPCONFIGNR_PERIPH_ADDR_MAIN,
  /// (7).
  DPCONFIGNR_PERIPH_ADDR_AUX,
  // (8).
  DPCONFIGNR_PROFI_DRIVER,
  // (9).
  DPCONFIGNR_PROFI_KBLHDR,
  // (10).
  DPCONFIGNR_PROFI_KBL,
  // (11).
  DPCONFIGNR_PROFI_OVHDR,
  // (12).
  DPCONFIGNR_PROFI_OVSIMPLE,
  // (13).
  DPCONFIGNR_PROFI_OVARRAY,
  /// (14).
  DPCONFIGNR_CONVERSION_RAW_TO_ING_MAIN,
  /// (15).
  DPCONFIGNR_CONVERSION_RAW_TO_ING_AUX,
  /// (16).
  DPCONFIGNR_CONVERSION_ING_TO_RAW_MAIN,
  /// (17).
  DPCONFIGNR_CONVERSION_ING_TO_RAW_AUX,
  /// (18).
  DPCONFIGNR_SMOOTH_MAIN,
  /// (19).
  DPCONFIGNR_SMOOTH_AUX,
  /// (20).
  DPCONFIGNR_PVSS_RANGECHECK,
  /// (21).
  DPCONFIGNR_USER_RANGECHECK,
  /// (22).
  DPCONFIGNR_ALERT_STATEBITS,
  /// (23).
  DPCONFIGNR_ALERT_VALUE,
  /// (24).
  DPCONFIGNR_ALERT_CLASS,
  /// (25).
  DPCONFIGNR_MAN,
  /// (26).
  DPCONFIGNR_DB_ARCHIVEINFO,
  /// (27).
  DPCONFIGNR_CONNECTIONINFO,
  /// (28).
  DPCONFIGNR_CONNECTCOUNT,
  /// (29).
  DPCONFIGNR_ONLINEVALUE,
  /// (30).
  DPCONFIGNR_FIRST_ARCHIVE,
  /// (31).
  DPCONFIGNR_DISTRIBUTION_INFO,
  /// (32).
  DPCONFIGNR_LOGGER_INFO,
  /// (33).
  DPCONFIGNR_DB_ARCHIVECLASS,
  /// (34).
  DPCONFIGNR_CORRECTIONVALUE,
  /// (35).
  DPCONFIGNR_OFFLINEVALUE,
  /// (36).
  DPCONFIGNR_DP_FUNCTION,
  /// (37).
  DPCONFIGNR_DPLOCK,
  /// (38).
  DPCONFIGNR_AUTH,
  /// (39).
  DPCONFIGNR_COMMON,
  /// (40).
  DPCONFIGNR_GENERAL,
  /// (41).
  DPCONFIGNR_ALERT_PAIR,
  // this item must always be the last, because it defines how many
  // items there are
  DPCONFIGNR_LAST_ITEM
};

#endif /* _DPCONFIGNRTYPE_H_ */
