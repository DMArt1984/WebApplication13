// -----------------------------------------------------------------------------
// creator: Andras Horvath - 01.09.2017
// purpose: Interface for creating an SSA Challenge Handler
// -----------------------------------------------------------------------------
#ifndef _CHALLENGEHANDLERFACTORY_HXX_
#define _CHALLENGEHANDLERFACTORY_HXX_

#include <ChallengeHandler.hxx>

class QJsonObject;

typedef std::unique_ptr<ChallengeHandler> SmartChallengeHandler;

/**
  @class ChallengeHandlerFactory
  @brief The ChallengeHandlerFactory class
         is the abstract base class for other ChallengeHandlerFactories
         only function createFromJSON is implemented as it is the same for all
         ChallengeHandlerFactories.
*/
class DLLEXP_OABASICS ChallengeHandlerFactory
{
public:
  /// destructor
  virtual ~ChallengeHandlerFactory() = default;

  /**
    @brief Factory function to create a challenge handler
    @param challengeHandlerType the type of the handler
    @param jsonObj the JSON object
    @return smart pointer to a ChallengeHandler
  */
  virtual SmartChallengeHandler getChallengeHandler(
    const std::string& challengeHandlerType,
    const QJsonObject& jsonObj) const = 0;

  /**
    @brief createFromJSON function of ChallengeHandlerFactory
    @details The function parses the given json object and verifies it's
             validity.
    @details After that, it then calls get getChallengeHandler() function of the
             concrete ChallengeHandlerFactory implementation and returns the
             returned SmartChallengeHandler.
    @details The function throws an error if "base", "type", "data" and "version
             are not part of json object.
             The function throws an error if "base", "type" and "version" are
             not of type string or "data" is not of type object.
             The function throws an error if value of "version" is not "1" or
             value of "base" is not ChallengeHandler.
             The function throws an error if SmartChallengeHandler returned by
             getChallengeHandler() is null.
    @param   jsonObj  JSON object containing "base", "type", "data" and "version"
                      data
    @return  a ChallengeHandler defined by the type of concrete
             ChallengeHandlerFactory
  */
  SmartChallengeHandler createFromJSON(const QJsonObject& jsonObj) const;
};

#endif  // _CHALLENGEHANDLERFACTORY_HXX_
