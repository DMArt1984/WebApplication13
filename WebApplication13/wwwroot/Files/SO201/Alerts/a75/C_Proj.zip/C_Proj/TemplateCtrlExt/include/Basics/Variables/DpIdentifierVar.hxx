#ifndef _DPIDENTIFIERVAR_H_
#define _DPIDENTIFIERVAR_H_

// VERANTWORTUNG: Johannes Ertl
// BESCHREIBUNG:  Das ist die Bezeicher-Variable (siehe DP-Analyse 2.2)
//                Der Bezeichner ist ein DpIdentifier.

#ifndef _DPIDENTIFIER_H_
#include <DpIdentifier.hxx>
#endif

#ifndef _VARIABLE_H_
#include <Variable.hxx>
#endif

#ifndef _CHARSTRING_H_
#include <CharString.hxx>
#endif
 
/** The dp identifier variable. this class is designed to hold a dp identifier.
*/
class DLLEXP_BASICS DpIdentifierVar : public Variable
{
    /** Outputs DpIdentifierVar value to the itcNdrUbSend stream.
        @param ndrStream Output stream.
        @param dpIdVar Streamed DpIdentifierVar variable.
        @return itcNdrUbSend stream.
    */
  friend DLLEXP_BASICS itcNdrUbSend &operator<<(itcNdrUbSend &ndrStream, const DpIdentifierVar &dpIdVar);
  
  /** Receives the DpIdentifierVar value from the itcNdrUbReceive stream.
      @param ndrStream Input stream.
      @param dpIdVar DpIdentifierVar variable receiving the value from the stream.
      @return itcNdrUbReceive stream.
  */  
  friend DLLEXP_BASICS itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream, DpIdentifierVar &dpIdVar);

  public:
    /** Constructor.
    */ 
    DpIdentifierVar() { cachedIsA = DPIDENTIFIER_VAR; }

    /** Constructor.
        @param init Reference to a variable of type DpIdentifier.
    */  
    DpIdentifierVar(const DpIdentifier &init) : value(init) { cachedIsA = DPIDENTIFIER_VAR; }
    
    /** Copy constructor.
        @param rVal Source DpIdentifierVar value to be copied.
    */    
    DpIdentifierVar(const DpIdentifierVar &rVal) : Variable(rVal),value(rVal.value) { cachedIsA = DPIDENTIFIER_VAR; }

    /** Declares new and delete operator.
    */
    AllocatorDecl;

    /** Equality operator.
        @param rVal Compared value.
        @return int 1 if the values are equal, otherwise 0.
        @n Important: this operator checks the VariableType, so two objects are equal only if
        they also have the same class (no conversion is done; see other operators).
    */
    virtual int operator==(const Variable &rVal) const;

    /** The less than operator.
        @param rVal Compared value.
        @return int 1 if true, otherwise 0.
        @n Important: this operator also converts the given rVal to its own class-type if needed.
    */
    virtual int operator<(const Variable &rVal) const;

    /** The greater than operator.
        @param rVal Compared value.
        @return int 1 if true, otherwise 0.
        @n Important: this operator also converts the given rVal to its own class-type if needed.
    */
    virtual int operator>(const Variable &rVal) const;

    /** Overloaded assignment operator used for type conversions.
        @param rVal Assigned value.
        @return Variable with assigned value.
    */
    Variable &operator=(const Variable &rVal);

    /** Overloaded assignment operator used for type conversions.
        @param rVal Assigned value.
        @return DpIdentifierVar with assigned value.
    */
    DpIdentifierVar &operator=(const DpIdentifier &rVal);
    
    /** Check if variable is logically true (if the dpIdentifier is set).
        @return PVSS_TRUE or PVSS_FALSE.
    */
    virtual PVSSboolean isTrue() const {return !value.isNull();}

    /** Clone the current variable object.
        @return Variable* pointer to a newly created DpIdentifierVar with the same value,
        created by the copy constructor.
    */
    virtual Variable *clone() const {return new DpIdentifierVar(value);}

    /** Cast to DpIdentifier.
    */
    operator DpIdentifier () { return value; }
    
    /** Creates a new DpIdentifierVar variable.
        @return Variable* pointer to a newly allocated DpIdentifierVar created with the
        default contructor.
    */    
    Variable *allocate() const { return new DpIdentifierVar; }
    
    /** Overloaded function returning the type of the variable.
        @return DPIDENTIFIER_VAR.
    */
    VariableType isAUncached() const { return DPIDENTIFIER_VAR; }
    
    /** Returns the VariableType for the specified type.
        @param varType VariableType.
        @return VariableType for this type.
    */    
    VariableType isAUncached(VariableType varType) const;

    /** Write value to output stream.
        @param o std::ostream to write to.
    */  
    void outToFile(std::ostream &o) const;
    
    /** Read value from the input stream.
    */    
    void inFromFile(std::istream &);

    /** Format the value acording to the format string
        @param  format  The format string. If the string is not empty it is
                used as an argument to the sprintf function.
                Else a default is used.
        @return The string representation of the value.
    */
    virtual CharString formatValue(const CharString &format) const;
 
    /** Format the value according to a format string.
        @param format The format string. If the string is not empty is is
               used as an argument to the sprintf function.
               Else a default is used.
        @param target This is a buffer with length len, which is directly written to.
               This method is more performant than the one which returns a CharString,
               because no alloc is done.
        @param len Size of the output buffer.
        @return Number of bytes written into target without 0-byte,
                or a negative value on error (like buffer too small).
    */
    virtual int formatValue(const CharString &format, char *target, size_t len) const;

    /** Get the value of the variable.
        @return Reference to the internally stored DpIdentifier value.
    */
    const DpIdentifier &getValue() const { return value; }

    /** Set the value of the variable.
        @param newValue Reference to the DpIdentifier which will be assigned to the private member.
    */
    void setValue(const DpIdentifier &newValue) { value = newValue; }

  private:
    void outNdrUb(itcNdrUbSend &ndrStream) const;
    void inNdrUb(itcNdrUbReceive &ndrStream);

    DpIdentifier value;
};

#endif /* _DPIDENTIFIERVAR_H_ */
