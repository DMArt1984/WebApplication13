#ifndef _CTRLDBG_H_
#define _CTRLDBG_H_
//COVINFO FILE: engineering (for debugging only, mkoller)

#include <HotLinkWaitForAnswer.hxx>
#include <DpIdentifier.hxx>
#include <ScriptId.hxx>
#include <CtrlScript.hxx>
#include <CtrlThread.hxx>
#include <VectorVar.hxx>

class CtrlDbgWait;
class UserType;

/*  author VERANTWORTUNG: Martin Koller */
/** This is the CTRL-Debugger class. It receives commands via a "Command"
  * Text-DPE and sends results back on a "Result" dyn-String DPE
  * The Name of the Datapoint has to be "_CtrlDebug_<Manager>_<num>", e.g. _CtrlDebug_UI_2
  * Send "help" for getting a list of available commands.
  @classification internal use
  */
class DLLEXP_CTRL CtrlDbg
{
  public:
    CtrlDbg();
    ~CtrlDbg();

    // quick check if we shall call debugWait (since debugWait() is a non-inlined function call)
    // numSteps == -1 ... running-mode
    // !bpoints ... no breakpoints defined
    bool mightWait() const { return (numSteps != -1) || bpoints; }

    // This method decides wheter the next statement should be executed
    // return: false ... do not wait, so execute the next statement
    //         true  ... yes, wait. So do not execute the next statment
    bool debugWait(CtrlThread *thread);

    void breakThread(CtrlThread *thread);

    // make sure to no longer refer to the internally held ids
    void threadAboutToDie(const CtrlThread *thread)
    {
      if ( (thread->getId() == threadId) && (thread->getScript()->getId() == scriptId) )
        threadId = -1;
    }

    // make sure to no longer refer to the internally held ids
    void scriptAboutToDie(ScriptId id)
    {
      if ( scriptId == id )
      {
        scriptId = -1;
        threadId = -1;
      }
    }

    // This has to be called after the Manager has already got the DpIdentification,
    // because it converts the DP-Name to an id.
    // It does then connect to the "Command" DPE
    // the class stores the information wheter it is already initialized, so
    // subsequent calls to that function do not hurt
    void init();

    // This method is called from the WaitForAnswer Object whenever there is
    // a command to be executed
    void execute(CharString cmd);

    // return the string representation of a VariableType as used in CTRL
    static CharString getVarType(const Variable *var);

    // return the string representation of a VariableType as used in CTRL
    static CharString getVarType(VariableType type, const UserType *userType = 0);

    // return the string representation of a type as used in CTRL
    static CharString getVarType(const TypeSpec &spec);

    // format variable
    static CharString formatVar(const CtrlVar *var);

    enum { FULL = 0, COMPACT = 1 };
    static CharString formatVariable(const Variable *var, int style = COMPACT);

  private:
    // get the type the vector contains, e.g. "int" in case of a vector<int>
    // especially adding space around vector/shared_ptr
    static CharString getVectorTypeName(const TypeSpec &spec);

  private:
    int numSteps;
    int initDone;
    ScriptId scriptId;
    ThreadId threadId;
    DpIdentifier dpResult;
    PVSSboolean lastStep;
    CharString commandId;

    void sendJsonError(const CharString &error);
    void sendText(const CharString &text);
    void sendTextList(const DynVar &list);
    void sendLine(CtrlThread *thread);
    CtrlScript *getScript();
    CtrlThread *getThread();
    void executeInfo(CharString cmd);
    void help();
    Variable *getVar(const char *name);
    CharString getConnType(ConnTblEntry *ptr);

    class Breakpoint
    {
      public:
        Breakpoint(ScriptId theScriptId = -1,
                   int theLine = 0, int theLib = -1) : next(0)
          { scriptId = theScriptId; line = theLine; lib = theLib; };

        ScriptId scriptId;
        int line;
        int lib;
        Breakpoint *next;
    };

    Breakpoint *bpoints;
};

class CtrlDbgWait : public HotLinkWaitForAnswer
{
  public:
    CtrlDbgWait(CtrlDbg *dbg) : debugger(dbg) {};
    virtual void hotLinkCallBack(DpHLGroup &group);
    virtual void hotLinkCallBack(DpMsgAnswer &);

  private:
    CtrlDbg *debugger;
};

#endif /* _CTRLDBG_H_ */
