#ifndef SSLWRAPPER_H
#define SSLWRAPPER_H

#define  USES_errno
#define  USES_stdio
#define  USES_string
#define  USES_sockets
#include <ItcPrelude.h>

#include <openssl/ssl.h>
#include <openssl/bn.h>
#include <openssl/dh.h>
#include <openssl/err.h>
#include <openssl/pem.h>
#include <openssl/rand.h>
#include <openssl/aes.h>

#include <string>

class DLLEXP_BCM SslWrapper {

  public:
    enum InitStatus
    {
      VERSION_NOT_SUFFICIENT = -3,
      FUNCTION_NOT_FOUND = -2,
      LIBRARY_NOT_FOUND = -1,
      NOT_INITIALIZED = 0,
      INIT_SUCCEEDED = 1
    };

    // type for functions that locate the SSL libraries
    typedef std::string (*FindLibraryCallback)(const std::string &);

  public:
    static void setFindLibraryCallback(FindLibraryCallback func);
    static InitStatus initWrapper(std::string &errorMsg);
    static int initOpenSSL();

    // true if EC_KEY_new_by_curve_name, EC_KEY_free have been loaded.
    // OpenSSL 1.0.0-fips, as distributed in CentOS 6, does not have them.
    static bool hasEcKeyFunctions();

    // PEM
    static DH *PEM_read_bio_DHparams(BIO *bp, DH **x, pem_password_cb *cb, void *u);
    static EVP_PKEY *PEM_read_bio_PrivateKey(BIO *bp, EVP_PKEY **x, pem_password_cb *cb, void *u);

    // BIO
    static BIO *BIO_new_mem_buf(const void *buf, int len);
    static long	BIO_ctrl(BIO *bp,int cmd,long larg,void *parg);
    static BIO *BIO_new_file(const char *filename, const char *mode);
    
    // ERR
    static void ERR_clear_error(void );
    static void ERR_print_errors(BIO *bp);

    static int PKCS5_PBKDF2_HMAC_SHA1(const char *pass, 
                                      int passlen,
			                                const unsigned char *salt, 
			                                int saltlen, 
			                                int iter,
			                                int keylen, 
			                                unsigned char *out);

    // SSL
    static BIO *  SSL_get_rbio(const SSL *s);
    static BIO *  SSL_get_wbio(const SSL *s);
    static SSL *  SSL_new(SSL_CTX *ctx);
    static SSL *  SSL_dup(SSL *ssl);        // IM 115842
    static SSL_CTX *SSL_CTX_new(const SSL_METHOD *meth);
    static void	SSL_CTX_free(SSL_CTX *);
    static X509_STORE *SSL_CTX_get_cert_store(const SSL_CTX *);
    static const SSL_METHOD *TLS_method(void);
    static const SSL_METHOD * TLS_server_method(void);   // IM 115842
    static const SSL_METHOD * TLS_client_method(void);   // IM 115842
    static const char *SSL_alert_desc_string_long(int value);
    static const char *SSL_alert_type_string_long(int value);
    static const char *SSL_state_string_long(const SSL *s);
    static int	SSL_CTX_set_cipher_list(SSL_CTX *,const char *str);
    static int	SSL_CTX_use_PrivateKey_file(SSL_CTX *ctx, const char *file, int type);
    static int  SSL_CTX_use_certificate_file(SSL_CTX *ctx, const char *file, int type);   // IM 115842
    static int	SSL_CTX_use_certificate_chain_file(SSL_CTX *ctx, const char *file);
    static int	SSL_get_error(const SSL *s,int ret_code);
    static int	SSL_pending(const SSL *s);
    static int	SSL_set_fd(SSL *s, int fd);
    static int 	SSL_accept(SSL *ssl);
    static int 	SSL_connect(SSL *ssl);
    static int 	SSL_read(SSL *ssl,void *buf,int num);
    static int 	SSL_write(SSL *ssl,const void *buf,int num);
    static int SSL_CTX_check_private_key(const SSL_CTX *ctx);
    static int SSL_CTX_load_verify_locations(SSL_CTX *ctx, const char *CAfile, const char *CApath);
    static int OPENSSL_init_ssl(uint64_t opts, const OPENSSL_INIT_SETTINGS *settings);
    static int SSL_shutdown(SSL *s);
    static void	SSL_free(SSL *ssl);
    static void SSL_CTX_set_info_callback(SSL_CTX *ctx, void (*cb)(const SSL *ssl,int type,int val));
    static void SSL_CTX_set_verify(SSL_CTX *ctx,int mode, int (*callback)(int, X509_STORE_CTX *));
    static long SSL_CTX_ctrl(SSL_CTX *ctx,int cmd, long larg, void *parg);
	static unsigned long SSL_CTX_set_options(SSL_CTX *ctx, unsigned long options);
	static long SSL_ctrl(SSL *ssl, int cmd, long larg, void *parg);
    static const SSL_CIPHER *SSL_get_current_cipher(const SSL *s);
    static const char *	SSL_CIPHER_get_name(const SSL_CIPHER *c);

    // X509
    static X509_NAME *	X509_get_subject_name(const X509 *a);
    static char *		X509_NAME_oneline(const X509_NAME *a,char *buf,int size);
    static X509 *	X509_STORE_CTX_get_current_cert(X509_STORE_CTX *ctx);
    static X509_LOOKUP *X509_STORE_add_lookup(X509_STORE *v, X509_LOOKUP_METHOD *m);
    static X509_LOOKUP_METHOD *X509_LOOKUP_file(void);
    static int	X509_STORE_CTX_get_error(X509_STORE_CTX *ctx);
    static int X509_STORE_set_flags(X509_STORE *ctx, unsigned long flags);
    static int X509_load_crl_file(X509_LOOKUP *ctx, const char *file, int type);


    static int SSL_CTX_use_certificate(SSL_CTX *ctx, X509 *x);
    static int SSL_CTX_use_PrivateKey(SSL_CTX *ctx, EVP_PKEY *pkey);    
    static EVP_PKEY *b2i_PrivateKey(const unsigned char **in, long length);    
    static void EVP_PKEY_free(EVP_PKEY *pkey);
    static void X509_free(X509 *pcert);
    static X509 *d2i_X509(X509 **a, const unsigned char **in, long len);
    static void SSL_CTX_set_cert_verify_callback(SSL_CTX *ctx, int (*cb)(X509_STORE_CTX *,void *), void *arg);
    
    static int i2d_X509(X509 *a, unsigned char **out); 
    static int BIO_free(BIO *b);
    static int X509_NAME_print_ex(BIO *out, const X509_NAME *nm, int indent, unsigned long flags);
    static int SSL_get_ex_data_X509_STORE_CTX_idx(void );
	static X509 *X509_STORE_CTX_get0_cert(X509_STORE_CTX *ctx);
	static void *	X509_STORE_CTX_get_ex_data(X509_STORE_CTX *ctx,int idx);
    static void	X509_STORE_CTX_set_error(X509_STORE_CTX *ctx,int s);
	static STACK_OF(X509) *X509_STORE_CTX_get0_chain(X509_STORE_CTX *ctx);
 
    static unsigned long OpenSSL_version_num(void);
    static const char *OpenSSL_version(int t);
        
    static const char *ERR_reason_error_string(unsigned long e);
    static unsigned long ERR_get_error(void);
    
    static STACK_OF(X509) *SSL_get_peer_cert_chain(const SSL *s);
    
    static int OPENSSL_sk_num(const OPENSSL_STACK *); 
    static void * OPENSSL_sk_value(const OPENSSL_STACK *, int);
    static const char *X509_verify_cert_error_string(long n);
    static int OBJ_sn2nid(const char *s); 

    // DH
    static DH *DH_new(void);
    static void	DH_free(DH *dh);
	static DH *DH_get_2048_256(void);

    static BIGNUM *BN_bin2bn(const unsigned char *s, int len, BIGNUM *ret);

    //EC
    static EC_KEY *EC_KEY_new_by_curve_name(int nid);
    static void EC_KEY_free(EC_KEY *key);

    //AES
    static int AES_set_encrypt_key(const unsigned char *userKey, const int bits, AES_KEY *key);
    static int AES_set_decrypt_key(const unsigned char *userKey, const int bits, AES_KEY *key);
    static void AES_cbc_encrypt(const unsigned char *in, unsigned char *out, size_t length, const AES_KEY *key, unsigned char *ivec, const int enc);
    
    // RAND
    static int RAND_status(void);
    //static int RAND_egd(const char *path);

  private:
    static unsigned long getCurrentThreadId();
    static void mutex___(int mode, int type, const char *file, int line);
    
    static struct CRYPTO_dynlock_value *dynLockCreate(const char *file, int line);
    static void dynLockDestroy(struct CRYPTO_dynlock_value *lock, const char *file, int line);
    static void dynLockLock___(int mode, struct CRYPTO_dynlock_value *lock, const char *file, int line);

  
  private:
    static InitStatus isWrapperInitialized;
    static bool isOpenSSLInitialized;
  
  friend class UNIT_TEST_FRIEND_CLASS;

};

#endif // SSLWRAPPER_H

