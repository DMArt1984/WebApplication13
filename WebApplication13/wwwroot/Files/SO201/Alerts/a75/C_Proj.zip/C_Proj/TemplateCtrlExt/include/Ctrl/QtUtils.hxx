#ifndef _QT_UTILS_H_
#define _QT_UTILS_H_

#include <Types.hxx>
#include <CharString.hxx>
#include <IpAcl.hxx>

#include <QByteArray>
#include <QTextCodec>
#include <QUrl>
#include <QNetworkAccessManager>
#include <QMetaEnum>
#include <QDebug>

struct tm;
class PVSSTime;

// wrapper for Qt functions which do not need to be used for a customer
// compiling with the API as we do not deliver the Qt header files

inline uint qHash(const CharString &key) { return key.getHashValue(); }

inline QDebug operator<<(QDebug dbg, const CharString &str) { dbg << str.c_str(); return dbg; }

inline bool operator==(const QByteArray &ba, const CharString &cs)
{ return ba == QByteArray::fromRawData(cs.c_str(), static_cast<int>(cs.len())); }

inline bool operator==(const CharString &cs, const QByteArray &ba)
{ return ba == QByteArray::fromRawData(cs.c_str(), static_cast<int>(cs.len())); }

struct DLLEXP_CTRL QtUtils
{
  // Note that you should not delete codecs yourself: once created they become Qt's responsibility.
  // returned pointer will never be zero
  static QTextCodec *codecForActiveLang();

  // Note that you should not delete codecs yourself: once created they become Qt's responsibility.
  // returned pointer will never be zero
  static QTextCodec *codecForLang(GlobalLanguageIdType id);

  // convert QString to CharString via the encoding of the active language
  static CharString actLangEncoded(const QString &str);

  // convert bytearray to QString via the encoding of the active language
  static QString actLangDecoded(const CharString &str);

  // Converts a given string from one encoding to a second one.
  // Source and destination encoding must be passed as global language identifiers.
  // src and dst may be the same.
  static bool convertEncoding(const CharString &src, CharString &dst, GlobalLanguageIdType srcLang, GlobalLanguageIdType dstLang);

  // return the time formatted like strftime but return a QString already
  // the format is supposed to be in the activeLang's encoding
  static QString formatTime(const char *format, const struct tm *time);

  // return the time formatted like strftime but return a QString already
  // the format is supposed to be in the activeLang's encoding
  // showMilli = true adds " (mmm)" to the resulting string
  static QString formatTime(const char *formatStr, bool showMilli, const PVSSTime &time, bool inUTC = false);

  // return the time formatted according to ISO-8601
  // YYYY-MM-DDTHH:MM:SS.mmm+HH:MM or (when UTC) YYYY-MM-DDTHH:MM:SS.mmmZ
  static CharString formatTimeISO(const PVSSTime &time, bool inUTC = false);

  // when set to true, we use QLocale to generate formatted time instead strftime/wcsftime
  static void setUseQtLocale(bool on);

  /** get URL of the HTTP proxy server to be used
      @return URL or an invalid URL if no server was defined
  */
  static const QUrl &getHttpProxy();

  /// set the HTTP proxy server to be used
  /// @param url the URL to set
  static void setHttpProxy(const QUrl &url);

  // configure the application proxy factory to be used (either from -proxy or from system)
  // returns false if there was an error when parsing -proxy option
  static bool initNetworkProxyFactory(int &argc, char *argv[]);

  // get access to a global QNetworkAccessManager object singleton
  static QNetworkAccessManager *getNetworkAccessManager();

  // delete the global QNetworkAccessManager object singleton
  static void deleteNetworkAccessManager();

  static inline QByteArray toQByteArray(const CharString &cs)
  { return QByteArray(cs.c_str(), static_cast<int>(cs.len())); }

  static inline CharString toCharString(const QByteArray &ba)
  { return CharString(ba.constData(), ba.length()); }

  // for error output, produce a string holding all possible enum keys as string
  static CharString enumKeysAsString(const QMetaEnum &metaEnum);

  private:
    /** check if the HTTP proxy server shall be used
        @n The list of hosts which bypass the proxy is currently retrieved from the
        current execution environment directly (we try to auto-detect the settings).
        @param hostName the name of the host which we are trying to contact
        @return true if OK or false if no proxy server shall be used for given hostName or no proxy is defined
    */
    static bool useHttpProxyFor(const CharString &hostName);

    static QNetworkAccessManager *nam;
    static QUrl httpProxy;
    static IpAcl proxyAcl;
    static bool useQtLocale;
};

#endif
