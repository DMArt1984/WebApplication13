#ifndef _DPIDSETCACHE_H_
#define _DPIDSETCACHE_H_

/*
VERANTWORTUNG: Robert Trausmuth; Modified 9.8.2004 by Martin Koller
BESCHREIBUNG: temporary cache used in DpIdentification during pattern matching in getIdSetLoc()
*/

#include <DpTypes.hxx>
#include <DynPtrArray.hxx>

/// This class represents the array of cached DpElementId items.
class DLLEXP_DATAPOINT DpCacheSet
{
  public:
    /** Constructor.
        @param type Type of the DpElementId items in the cache.
        @param array Flag indicating whether the cache array should be allocated. If the array is not allocated, the items cannot be appended into the cache.
    */
    DpCacheSet(DpTypeId type, bool array = true);
    /// Destructor.
    ~DpCacheSet();

    /// Get the number of DpElementId items in the cache.
    size_t nofItems() const { return num; }
    /** Get the DpElementId item at the specified index.
        For the speed purpose no range check is performed.
        @param idx Index of the item.
    */
    DpElementId getAt(size_t idx) const { return ids[idx]; }
    /// Get the type of the DpElementId items in the cache.
    DpTypeId getTypeId() const { return dpTypeId; }

    /// Add DpElementId item into the cache.
    void append(DpElementId id);

  private:
    DpTypeId dpTypeId;

    size_t num;        // num of valid entries
    size_t length;     // length of array allocated
    DpElementId *ids;
};

#if defined(LIBS_AS_DLL)
  template class DLLEXP_DATAPOINT DynPtrArray<DpCacheSet>;
#endif

/// This class represents the cache of the DpCacheSet items.
class DLLEXP_DATAPOINT DpIdSetCache
{
  public:
    /// Default constructor.
    DpIdSetCache();
    
    /** Insert the DpElementId item into the cache.
        @param type Type of the DpElementId.
        @param elem DpElementId to be cached.
    */
    void insert(DpTypeId type, DpElementId elem);
    /** Get the DpCacheSet set for the specified DpElementId type.
        @param type Type of the DpElementId in the DpCacheSet set.
    */
    const DpCacheSet *getTypeEntry(DpTypeId type);

    /// Comparison function used to compare DpCacheSet objects.
    static int sortFunc(const DpCacheSet *s1, const DpCacheSet *s2);

  protected:

  private:
    DynPtrArray<DpCacheSet> list;

    // so that the compiler does not define them itself !!

    // copy constructor
    DpIdSetCache(const DpIdSetCache &) {} // COVINFO LINE: defensive (defined private so no one can use it)
    // assignment operator
    DpIdSetCache &operator=(const DpIdSetCache &) { return *this; } // COVINFO LINE: defensive (defined private so no one can use it)
};

#endif /* _DPIDSETCACHE_H_ */
