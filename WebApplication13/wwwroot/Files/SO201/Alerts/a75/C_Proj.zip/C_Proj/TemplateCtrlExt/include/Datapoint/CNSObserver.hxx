#ifndef _CNSOBSERVER_H_
#define _CNSOBSERVER_H_

class CharString;
class DpMsgManipCNS;

/**
 * A pure abstract base class, containing the callback function update()
 * which is called on CNS changes.
 *
 * @see CommonNameService::addObserver(), CommonNameService::removeObserver()
 */
class CNSObserver
{
public:
  /// The different types of changes reported to an observer
  enum CNSChanges
  {
    /// The display names of the system have been changed
    SYSTEM_NAMES_CHANGED,
    /// The separators of the view have been changed
    VIEW_SEPARATOR_CHANGED,
    /**
     * Display names or name of a CNSView/CNSNode have been changed.
     * The trees of the view / subtrees of the node are not affected
     * by this change.
     *
     * @see STRUCTURE_CHANGED
     */
    NAMES_CHANGED,
    /// The CNSDataIdentifier of a CNSNode has been changed
    DATA_CHANGED,
    /// The changes affect the whole given view ,(sub)tree or node
    STRUCTURE_CHANGED
  };

public:

  /// Destructor
  virtual ~CNSObserver() { }

public:
  /**
   * This method is invoked after a change to the CNS structure of the
   * current manager has been applied.
   * 
   * @param path The CNS path of this node.
   *             e.g. System1:
   *                  System1.securityView:
   *                  System1.securityView:EITC.entranceCam
   * @param what The type of change.
   * @param msg The incoming message that triggered the change.
   */
  virtual void update(const CharString &path, CNSChanges what, const DpMsgManipCNS &msg) = 0;

};

#endif // _CNSOBSERVER_H_
