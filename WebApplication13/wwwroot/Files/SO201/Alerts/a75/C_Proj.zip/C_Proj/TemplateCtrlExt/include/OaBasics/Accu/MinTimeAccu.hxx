#ifndef _MINTIMEACCU_H_
#define _MINTIMEACCU_H_

#ifndef _SIMPLEACCU_H_
#include <SimpleAccu.hxx>
#endif

#ifndef _VARIABLE_H_
#include <Variable.hxx>
#endif

#ifndef _TIMEVAR_H_
#include <TimeVar.hxx>
#endif

/**
 * A statistical accumulator to determine the associated time of the minimum value
 * in a series of values.
 *
 * @internal
*/
class DLLEXP_OABASICS MinTimeAccu: public SimpleAccu
{
  public:
    /**
     * Creates a new instance for the specified Variable type.
     * 
     * @param aVarType The variable type of the accumulator. Valid types are
     * INTEGER_VAR, UINTEGER_VAR and FLOAT_VAR. If you specify an invalid
     * type, FLOAT_VAR is used.
     */
    MinTimeAccu(const VariableType aVarType);

    /**
     * Destructor
     */
    virtual ~MinTimeAccu();
    
    /**
     * Sets the specified TimeVar, if the specified value is smaller than
     * the current value.
     *
     * If the specified value is less than the value of this instance,
     * the specified time will become the new time of this instance.
     * Otherwise, it will be ignored.
     *
     * @param theValue The value to accumulate
     * @param atTime The time associated with @p theValue
     */
    virtual void accumulate(const Variable &theValue, const TimeVar &atTime );

    /**
     * Returns the associated time of the current value of the accumulator.
     *
     * @remarks The return value may be invalid, e.g. when no value was added
     * to a new instance. Use isValid() to check the validity of the value.
     *
     * @return The associated time of the current minimum value of all
     * accumulated values.
     */
    virtual const Variable &getResult();

    /**
     * Resets the accumulator.
     *
     * After reset, the value of the accumulator will be invalid (isValid()),
     * and the first added value will be the new minimum value.
     */
    virtual void reset();
    
  protected:
  
  private:
    /// Avoids copy
    MinTimeAccu(const MinTimeAccu &);

    /// Avoids assignment
    MinTimeAccu &operator=(const MinTimeAccu &);
  
    /// Current minimum value
    Variable *theMin;

    /// The associated time of the current value
    TimeVar theMinTime;
};

#endif
