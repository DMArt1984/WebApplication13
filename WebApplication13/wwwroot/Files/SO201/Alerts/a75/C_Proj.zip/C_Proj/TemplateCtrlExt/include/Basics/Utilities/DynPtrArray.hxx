// DATEIBESCHREIBUNG ==============================================================
// DATEINAME:       DynPtrArray.hxx
// VERANTWORTUNG:   Laszlo Szakony
// BESCHREIBUNG:    Dynamic Pointer Array
//
//              Item  Item  Item                    Item  Item        Item  Item  Item
//               0     1     2                       6     7           9     10    11
//               ^     ^     ^                       ^     ^           ^     ^     ^
//               |     |     |                       |     |           |     |     |
//  Dynamic   +--|--+--|--+--|--+-----+-----+-----+--|--+--|--+-----+--|--+--|--+--|--+-----+-----+-----+
//  Pointer   |  o  |  o  |  o  | NULL| NULL| NULL|  o  |  o  | NULL|  o  |  o  |  o  |  -  |  -  |  -  |
//   Array    +-----+-----+-----+-----+-----+-----+-----+-----+-----+-----+-----+-----+-----+-----+-----+
//            |                             |                             |                             |
//            |\                           /|                             |          /                / |
//              \<-Number Of Ptr Boundle->/                                         /                /
//               \                                                                 /                /
//                \                                                               /                /
//                 \<---------------   Number Of Items in Array  --------------->/                /
//                  \                                                                            /
//                   \<---------------------  Size Of Array ----------------------------------->/
//
//
//                                Size Of Array = (Number Of Ptr Boundle) * k
//
// ======================================Ende======================================

#ifndef _DYNPTRARRAY_H_
#define _DYNPTRARRAY_H_

#ifndef _TYPES_HXX_
#include <Types.hxx>
#endif

#include <cstddef>


// ========== DynPtrArray ============================================================

typedef unsigned int DynPtrArrayIndex;

const DynPtrArrayIndex DYNPTRARRAY_INVALID = ((DynPtrArrayIndex)-1);

/** The DynPtrArray class. The Dynamic Pointer Array can be regarded as an array of pointers.
    The size of the array can vary dynamically. The internal allocation of the array is
    optimized. Holes (e.g. NULL pointers) are allowed. Referencing an index outside of the array
    will cause a reallocation of the array. Reallocation is done in certain units (e.g. 10 pointers
    at once), but details are hidden to the user. The pointer array can be sorted (like qsort)
    and searched (like bsearch). An unsorted array will be searched after it is sorted.
    Pointer arrays can be copied. The copy of Pointer Array will expand like the
    original. Pointed objects are freed only if all copies of the pointer array is removed.

    Each DynPtrArray can hold object specific user data (i.e. window handle,...)
    and a debug flag. If the debug flag is set, additional info on internal DynPtrArray operations
    is printed on stderr.
*/
template<class Item> class DynPtrArray
{
public: 
  friend class UNIT_TEST_FRIEND_CLASS;
  /// Constructor
  DynPtrArray();
  /// Destructor
  ~DynPtrArray();

  /** Copy constructor.
      Copy is allowed only if the object is empty, and there are no copies of this object.
      @param arr Array to be copied.
  */
  DynPtrArray(DynPtrArray<Item> &arr);
  /** Assignment operator.
      This operator is used to combine more DynPtrArray objects
      to point at the same data objects. With this you can create a multi-indexed data set.
      @param arr Array to be copied.
  */
  DynPtrArray<Item>& operator =(DynPtrArray<Item>&arr);

  /** Create deep copy of the input array.
      Enclosed items are also copied. This means that enslosed items need copy-constructor.
      Only the elemtents will be copied. No copy of issorted and compareFunction and other members will be made.
      @param arr Array to be copied.
      @return Number of items in the array.
  */
  DynPtrArrayIndex deepCopy(const DynPtrArray<Item> &arr);

  /** Create deep copy of the input array, issorted and compareFunction will be copied as well.
      Enclosed items are also copied. This means that enslosed items need copy-constructor.
      Only the elemtents will be copied. No copy of issorted and compareFunction and other members will be made.
      @param arr Array to be copied.
      @return Number of items in the array.
  */
  DynPtrArrayIndex deepCopySorted(const DynPtrArray<Item> &arr);

  /** Take over the array of myFriend.
      It is not allowed to grab if 'myFriend' or 'this' have copies.
      @return The size of the array (>=0) grabbed on success, DYNPTRARRAY_INVALID on error.
  */
  DynPtrArrayIndex grab(DynPtrArray<Item> &myFriend);

  /// Set the array to unsorted.
  void invalidateSort() { isSorted = 0; };
  /// Check if array is sorted.
  int isSortArray() const { return isSorted; };

  /// Get the number of items in array (historical name).
  DynPtrArrayIndex getNumberOfItems() const { return nofItemsInArray; };
  /// Get the number of items in array.
  DynPtrArrayIndex nofItems() const { return nofItemsInArray; };
  /// get the size in bytes of the array
  size_t size() const { return(sizeof(*this) + sizeOfTheArray * sizeof(void *)); }

  // Direct access.
  // ============================================================

  /** Access operator.
      If the Pointer Array is sorted, you should use the search function.
      The [] operator can be only an rvalue (not lvalue).

      @param index Zero based index of the item in the array.
      @return The return value is NULL if the index is out of range or the stored ptr is a NULL pointer.
  */
  Item *operator[](DynPtrArrayIndex index) const
  {
    return getAt(index);
  };

  /** Get the item pointer at the given index. If the Pointer Array is sorted, you should use the search function.

      @param index Zero based index of the item in the array.
      @return The return value is NULL if the index is out of range or the stored ptr is a NULL pointer.
  */
  Item *getAt(DynPtrArrayIndex index) const
  {
    ((DynPtrArray<Item> *) this)->lastAccessedIndex = index;
    return index < nofItemsInArray ? arrayPtr[index] : 0;
  };

  /** Find the pointer in the array. Search for the given pointer in the pointer array.
      Since only the pointer is compared, this pointer should point to an element in the list.
      This is simple a linear search function.

      @param itemPtr Pointer to the allocated object.
      @return Index of the found pointer, or DYNPTRARRAY_INVALID if not found.
  */
  DynPtrArrayIndex findPtr(const Item *itemPtr) const;

  /** Set the item pointer at the given index.
      If index is greater than the array size, the array is expanded.
      The object will be not copied, but will be grabbed (deleting the array will remove the objec as well).
      It is the Programmers responsibility, that itemPtr points to an allocated object.
      If a pointer is replaced, it is the programmers responsibility the remove the old object.

      @param index Zero based index of the item pointer.
      @param itemPtr Pointer to the allocated object.
      @return If the array can NOT be expanded, the return value is DYNPTRARRAY_INVALID, otherwise the index itself.
  */
  DynPtrArrayIndex setPtr(DynPtrArrayIndex index, const Item * itemPtr);

  /** Insert the item pointer before the elements pointed by index.
      If index is greater than the # of Items, setPtr is called.
      Otherwise the array is expanded if neccessary, and the corresponding pointers are moved to the right.
      The object will be not copied, but will be grabbed (deleting the array will remove the objec as well).
      It is the programmers responsibility, that itemPtr points to an allocated object.

      @param index Zero based index of the item before which the new item pointer should be inserted.
      @param itemPtr Pointer to the allocated object.
      @return If the array can NOT be expanded, the return value is DYNPTRARRAY_INVALID, otherwise the index itself.
  */
  DynPtrArrayIndex insertPtr(DynPtrArrayIndex index, const Item *itemPtr);

  /** Insert an unique item. If one identical item exists, it will be removed.
      If several identical items exist this function will fail.
      The item must be unique in all copies. If this is not the case use the function updateItemOrInsertIfNotFound().
      The items are inserted sorted so all copies will stay sorted.

      @param itemPtr Pointer to the allocated object.
      @return Zero based index of the item in the array or DYNPTRARRAY_INVALID in case of error.
  */
  DynPtrArrayIndex insertSortPtrUnique(const Item *itemPtr);

  /** Inserting an item pointer into the array.
      On inserting the compare-function is used to maintain sort.
      The object is grabbed. Multiple items according to the compare func are allowed. The new item is inserted
      behind equal ones. For more information see insertPtr function description.

      @param itemPtr Pointer to the allocated object.
      @param check Zero based index of the item in the array. If check is not DYNPTRARRAY_INVALID check for insertion here first
  */
  DynPtrArrayIndex insertSortPtr(const Item *itemPtr, DynPtrArrayIndex check = DYNPTRARRAY_INVALID);

  /** Cut an item pointer out of the array.
      The item pointer is removed from the array. It is the programmers responsibility, that pointed object will be deleted.

      @param index Zero based index of the item to cut out
      @return If index is greater than the # of Items, NULL is returned. Otherwise the item pointer at the specified index is returned.
  */
  Item * cutPtr(DynPtrArrayIndex index);


  /** Set a compare function, turn sorting ON and OFF.
      If the input parameter is not zero sorting is ON, otherwise if the input parameter
      is zero (NULL pointer) the sorting is OFF.
      The input parameter is a pointer to a function called
      "int compare(const Item1 *, const Item 2 *)" which will be used for sorting the array.
      Keep in mind that in C++ you should use a static member function for this or you will get
      the implicit this-Ptr, too.
      NULL pointers are allowed as parameters in the 'compare funciton'.
      A NULL pointer should be regarded as a pointer to the the largest object.
      So they will be sorted to the end of the array.
      The reason for using a function and not the comparasion operators is that different
      arrays can point tho the same objects, and the different arrays can have their
      own compare function. So its possible to have several sorting criteria for the
      same set of objects. This is analogous to the database terminology -
      the records are now objects, and the keys are now the pointer arrays.

      @param compFunction Compare function
      @return The return value is zero, if the two Items are equal or both pointers are NULL pointers, a negative value if  the 'Item1' is smaller than 'Item2' or pointer to Item2 is NULL,
      a positive value if  the 'Item1' is greater than 'Item2' or pointer to Item1 is NULL.
  */
  void setCompareFunction( int (*compFunction)(const Item *, const Item *))
  {
    if (compareFunction != compFunction)
      isSorted = 0;

    compareFunction = compFunction;
  };


  /** Explicit sorting of the array.
      This function will be called implicitly if the array is unsorted and a search function is called.
      This is actually a specialised qsort function.
      You do NOT have to call this Function at all. But if you have an idle cycle, and you are
      sure that program has nothing else to do, you can call sort.
      It will sort only if the array is needed to be sorted, otherwise it does nothing.
  */
  void sort();

  /// Sort using mergeSort, so identical items will retain their order.
  void stableSort();

  /// Sort only part of the array
  void sort(DynPtrArrayIndex start, DynPtrArrayIndex end);

  /// Sort only part of the array, using mergeSort
  void stableSort(DynPtrArrayIndex start, DynPtrArrayIndex end);

  /** This is our general bsearch function.
      It will not only find our key, but it returns
      the index of the previous and next Item pointer. If an index can not be found, for that
      index DYNPTRARRAY_INVALID is returned.
      <P> E.g. return value = DYNPTRARRAY_INVALID, indexAfter = DYNPTRARRAY_INVALID,
      indexBefore = 7 means that item has not been found in the array, but it should be the
      last in the array, which contains 8 Item pointers (0 .. 7).
      <P> If the item is not found and indexAfter is NOT DYNPTRARRAY_INVALID, you can insert the
      itemPtr at 'indexAfter'. The next sorting will be a bit faster.
  */
  DynPtrArrayIndex findItem(const Item *itemPtr, DynPtrArrayIndex & indexBefore, DynPtrArrayIndex &indexAfter);

  /** Exact search function.
      Find the itemPtr in the array. Then the pointer can be fetched by getAt();

      @return If the Item is not found, the return value is DYNPTRARRAY_INVALID, otherwise the index in the array.
  */
  DynPtrArrayIndex findItem(const Item *itemPtr)
  {
    DynPtrArrayIndex indexBefore, indexAfter;
    return findItem(itemPtr, indexBefore, indexAfter);
  };

  /** Find and get an item.
      This is NOT const, because sorted state can change.
      @return NULL if the Item is NOT found or the stored ptr is a NULL pointer.
  */
  Item *findAndGetItem(const Item *itemPtr)
  {
    return getAt(findItem(itemPtr));
  };

  /** Find the item in the array.
      Works like findItem function, but returns DynPtrArrayInvalid if not sorted
    */
  DynPtrArrayIndex findItemIfSorted(const Item *itemPtr, DynPtrArrayIndex &indexBefore,
                                    DynPtrArrayIndex &indexAfter) const;

  /** Find the item in the array.
      Works like findItem function, but returns DynPtrArrayInvalid if not sorted
    */
  DynPtrArrayIndex findItemIfSorted(const Item *itemPtr) const
  {
    DynPtrArrayIndex indexBefore, indexAfter;
    return findItemIfSorted(itemPtr, indexBefore, indexAfter);
  }

  /** Find and get an item.
      Works like findAndGetItem function, but returns DynPtrArrayInvalid if not sorted
    */
  Item * findAndGetItemIfSorted(const Item *itemPtr) const
  {
    return getAt(findItemIfSorted(itemPtr));
  }

  /** Insert item using binary insert if possible.
      Sort is maintained in all arrays, but equal items according to the sort func are allowed.
      The new item is inserted as last of equal items.
  */
  DynPtrArrayIndex insertSorted(const Item *itemPtr)
  {
    return itemPtr ? insertSortPtr(itemPtr, DYNPTRARRAY_INVALID) : DYNPTRARRAY_INVALID;
  };


  /// For special purposes checks the last element first.
  DynPtrArrayIndex appendOrInsertSorted(const Item *itemPtr)
  {
    return itemPtr ? insertSortPtr(itemPtr, nofItemsInArray) : DYNPTRARRAY_INVALID;
  };

  /** Insert by search function.
      If the Item is found, the return value is DYNPTRARRAY_INVALID,
      otherwise the index into the array where the itemPtr was inserted.
      Only THIS array, not the copies, is checked for existance of this item.
      The Array (but only THIS array, and NOT the copies) stays sorted, so prefer this function to append.
  */
  DynPtrArrayIndex insertItemOnlyIfNotFound(const Item *itemPtr);

  /** Update by search function.
      If the item is found, the new item will be inserted
      in that position and the old item will be deleted. If the item is not found the
      new item will be inserted in the right place according to the compare function.
      <P> The item is inserted with setPtr / insertPtr, so only this array will stay
      sorted, not the others.
      <P> If several identical items are in the array only the first will be replaced.
      <P> See also insertSortPtrUnique for differences.
  */
  DynPtrArrayIndex updateItemOrInsertIfNotFound(const Item *itemPtr);

  /** Update by search function.
      The item is handled like above.
      All arrays (even the copies) remain sorted, so prefer this function for insert.
      Keep in mind that a unique sort function is demanded in each sorted copy and that
      the item must not exist more than once in all copies.
      Otherwise use another insert function and perform explicit sort() on the copies when ready
  */
  DynPtrArrayIndex updateOrInsertAndMaintainSort(const Item *itemPtr)
  {
    return itemPtr ? insertSortPtrUnique(itemPtr) : DYNPTRARRAY_INVALID;
  };

  /** Linear search function.
      The bsearch like Functions are not const, because they may change
      the order of the array (If the array was not sorted, it will be sorted first).
      @return DYNPTRARRAY_INVALID if Item is not found, otherwise the index in the array.
              The pointer can be fetched by getAt();
  */
  DynPtrArrayIndex findItemByLinearSearch(const Item *itemPtr) const;

  // List-Like Access functions
  // ======================================================================

  /// Append at the End. The item is captured
  DynPtrArrayIndex append(const Item* itemPtr)
  {
    return setPtr(nofItemsInArray, itemPtr);
  }

  /// Insert at the first index [0] in the array. If pointer is NULL, the array is simply shifted to the right.
  DynPtrArrayIndex insertAsFirst(Item* itemPtr)
  {
    return insertPtr(0, itemPtr);
  };

  /** Insert at a given position.
      The array is shifted to the right.

      @return DYNPTRARRAY_INVALID if item wasn't found or the new position otherwise.
  */
  DynPtrArrayIndex insertAfter(Item* thisItemPtr, Item* itemPtr)
  {
    DynPtrArrayIndex i = findPtr(thisItemPtr);
    if (i != DYNPTRARRAY_INVALID)
      return insertPtr( i+1, itemPtr );
    else
      return DYNPTRARRAY_INVALID;
  }

  /// Get the first item
  Item* getFirst() const { return getAt( ((DynPtrArray<Item> *) this)->lastAccessedIndex = 0); };

  /// Get next item
  Item* getNext() const
  {
    return (++( ((DynPtrArray<Item> *) this)->lastAccessedIndex) < nofItemsInArray) ? getAt(lastAccessedIndex) : 0;
  };

  /** Get next item without affecting the lastAccessed index

      @param itemPtr Current item pointer.
      @return Previous item pointer or NULL in case of error.
  */
  Item *getNext(Item *itemPtr) const
  {
    DynPtrArrayIndex i = findPtr(itemPtr);
    return ( ((i != DYNPTRARRAY_INVALID) && (i < nofItemsInArray - 1) ) ? arrayPtr[i+1] : 0);
  };

  /// Get previous item
  Item * getPrev() const
  {
    if (lastAccessedIndex == DYNPTRARRAY_INVALID)
      return 0;
    else if (lastAccessedIndex == 0)
    {
      ((DynPtrArray<Item> *) this)->lastAccessedIndex = DYNPTRARRAY_INVALID;
      return 0;
    }
    else
      return getAt(lastAccessedIndex - 1);
  };

  /** Get previous item without affecting lastAccesedIndex

      @param itemPtr Current item pointer.
      @return Previous item pointer or NULL in case of error.
  */
  Item * getPrev(Item *itemPtr) const
  {
    DynPtrArrayIndex i = findPtr(itemPtr);
    return ( ((i != DYNPTRARRAY_INVALID) && (i > 0)) ? arrayPtr[i-1] : 0);
  };

  /// Get the last item in the array.
  Item*  getLast() const { return getAt(nofItemsInArray-1); };

  /// Get the last accessed item.
  Item*  getLastAccessed() const { return getAt(lastAccessedIndex); };

  /// Get the last accessed item index.
  DynPtrArrayIndex getLastAccessedIndex() const { return lastAccessedIndex; };

  /** Replace the value with another one.
    If idx is not existing no replace! You can use replaceOrSetAt instead
    @param idx Zero based index of the item to be replaced.
    @param itemPtr New item pointer to be set.
    @return Previous item pointer or NULL in case of error.
  */
  Item * replaceAt(DynPtrArrayIndex idx, Item *itemPtr);

  /** Replaces or sets the value with another one.
    @param idx Zero based index of the item to be replaced or set.
    @param itemPtr New item pointer to be set.
    @return Previous item pointer or NULL if new index or in case of error.
  */
  Item * replaceOrSetAt(DynPtrArrayIndex idx, Item *itemPtr);

  /** Remove the last accessed item from the array.
      Item is deleted.
  */
  DynPtrArrayIndex remove() { return remove(lastAccessedIndex); } // last accessed
  /** Remove the item at the given index.
      Item is deleted.

      @param index Zero based index ot the item to be deleted.
      @return The function returns the index itself.
    */
  DynPtrArrayIndex remove(DynPtrArrayIndex index) { delete cutPtr(index); return index; }
  /** Remove the given item.
      The pointer must point to an item in the list. Item is deleted.

      @param itemPtr Item to be deleted.
      @return The function returns the zero based index of the removed item.
    */
  DynPtrArrayIndex remove(Item* itemPtr)
  {
    DynPtrArrayIndex i = findPtr(itemPtr);

    delete cutPtr(i);

    return i;
  }

  /** Remove range of items.
      This function is optimized for single DPAs
    */
  void  removeRange(DynPtrArrayIndex start, DynPtrArrayIndex end);

  /// Remove the first element.
  DynPtrArrayIndex removeFirst() { return remove((DynPtrArrayIndex)0); }
  /// Remove the last element.
  DynPtrArrayIndex removeLast() { return remove(nofItemsInArray-1); }

  /// Delete all objects from the array.
  void clear();

  /** Delete all objects from the array an resize to new length.

      @param newLen Requested size of the array.
  */
  void reinit(DynPtrArrayIndex newLen);

  /** Resize array to new size.
      The returned size may be larger than requested because memory is allocated in blocks.

      @param newSize Requested size of the array.
      @return New size of the array.
  */
  DynPtrArrayIndex resize(DynPtrArrayIndex newSize)
  {
    if ( newSize != DYNPTRARRAY_INVALID )
      resizeArray(newSize);
    return sizeOfTheArray;
  }

  /** Cut the last accessed item pointer from the array.
      Removes pointer without deleting the pointed object. The programmer is responsible for deleting the object.
  */
  Item* cut() { return cutPtr(lastAccessedIndex); }
  /** Cut the item pointer at the given position.
      Removes pointer without deleting the pointed object. The programmer is responsible for deleting the object.
  */
  Item* cut(DynPtrArrayIndex i) { return cutPtr(i); }
  /** Cut the given item pointer.
      Removes pointer without deleting the pointed object. The programmer is responsible for deleting the object.
  */
  Item* cut(Item* itemPtr) { return cutPtr(findPtr(itemPtr)); }
  /** Cut the first item pointer from the array.
      Removes pointer without deleting the pointed object. The programmer is responsible for deleting the object.
  */
  Item* cutFirst() { return cutPtr((DynPtrArrayIndex)0); }
  /** Cut the last item pointer from the array.
      Removes pointer without deleting the pointed object. The programmer is responsible for deleting the object.
  */
  Item*  cutLast() { return cutPtr(nofItemsInArray-1); }

  /** Removes duplicities from the array.
      You have to set a compare function, but sorting is not necessary.

      @return PVSS_TRUE if successfull, PVSS_FALSE if unsuccessfull (no compare function is set)
  */
  PVSSboolean unique();

private:

/*
  static int (*wcompFunction)(const void *, const void *);
  static int wrapcomp(const void *i1, const void *i2)
    { return (*wcompFunction)(*((const Item **)i1), *((const Item **)i2)); }
*/
  /// insertionSort sorting algorithm
  void insertionSort(DynPtrArrayIndex first, DynPtrArrayIndex last);
  /// quickSort sorting algorithm
  void quickSort(DynPtrArrayIndex first, DynPtrArrayIndex last);
  /// mergeSort sorting algorithm
  void mergeSort(DynPtrArrayIndex first, DynPtrArrayIndex last);

  /** Expands or tighten the array to the new size.
      The input parameter is the number of Item pointers requested. If the new size is greater than the array size
      or the size is smaller than (arraysize - 2 * pointer boundle), the the array is reallocated.
      the return value is the new size (in pointers. e.g. # of ptrs). If the reallocation
      was unsuccessfull, DYNPTRARRAY_INVALID is returned. If the array was expanded, the expanded area
      is initialised to zero (NULL pointer)

      @param newSize Requested size of the array.
      @return New size of the array or DYNPTRARRAY_INVALID in case of error.
    */
  DynPtrArrayIndex resizeArray(DynPtrArrayIndex newSize);

  // Pointers to maintain copies. The copy ctor and the assignement operator makes only a
  // copy of the pointer array, and not the objects itself. Changes in one object will cause
  // changes in other object as well.
  DynPtrArray<Item> *firstArrayPtr;
  DynPtrArray<Item> *nextArrayPtr;

  Item **arrayPtr;

  DynPtrArrayIndex sizeOfTheArray;
  DynPtrArrayIndex nofItemsInArray;

  DynPtrArrayIndex lastAccessedIndex;
  DynPtrArrayIndex lastFoundIndex;

  int (*compareFunction)(const Item *, const Item *);

  unsigned short isSorted;
};


#endif /* _DYNPTRARRAY_H_ */
