// DATEIBESCHREIBUNG ==============================================================
// DATEINAME:     DpConfigManager.hxx
// VERANTWORTUNG: Johannes Ertl
// BESCHREIBUNG:  Das ist eine abstrakte Klasse, jeder Manger muss eine abgeleitete
//                Klasse implementieren, und beim DpElement eintragen.
//                ConfigManager erlaubt das allokieren von managerspezifischen
//                Konfigurationen, und legt fuer jeden Manager fest, welche
//
// AENDERUNGS-HISTORIE
// Ver.  | Datum      | Aenderungen                            | ModNr.| Autor
// ------+------------+-----------------Anfang-----------------+-------+-----------
//   1.0 |            | 1.Erstellung mit Westmount-OMT         |     0 |
// ======================================Ende======================================
#ifndef _DPCONFIGMANAGER_H_
#define _DPCONFIGMANAGER_H_

// System-Include-Files
#include <Types.hxx>
#include <DpConfig.hxx>
#include <DpConfigNrType.hxx>
#include <DpElementType.hxx>
#include <ManagerIdentifier.hxx>


// ................................Anfang User-Definitionen........................
// .................................Ende User-Definitionen.........................

// Vorwaerts-Deklarationen :
class DpConfigManager;

// ========== DpConfigManagerPtr ============================================================
typedef DpConfigManager* DpConfigManagerPtr;

// ========== DpConfigManager ============================================================

/** This is a abstract class - an interface that every Manager must implement and register for a DpElement
 *   DpConfigManager defines which configuration is valid for a defined manager type, and also provides methods to allocate the configuration.
 *
 *   @classification public use
 */
class DLLEXP_CONFIGS DpConfigManager 
{

// ..........................Anfang User-Klasseninterne-Definitionen..................
// ...........................Ende User-Klasseninterne-Definitionen...................
public:
  /// Constructor
  DpConfigManager();

  /// Destructor
  virtual ~DpConfigManager();


  // Operatoren :

  // Spezielle Methoden :
  
   /** Checks if the specified configuration type is valid for the given manager type.
       
       @param confType configuration type number.
       @param manType manager type. Following types are supported : EVENT_MAN, DB_MAN and DRIVER_MAN
       @return PVSS_TRUE if the configuration type is valid for the given manager type, otherwise PVSS_FALSE.
   */
  static PVSSboolean isManagerConfig(DpConfigNrType confType, ManagerType manType);

   /** Gets the manager type for the given configuration type.
       
       @param confType configuration type number.
       @return A manager type, or NO_MAN if the configuration number type is not valid. Following types are supported : EVENT_MAN, DB_MAN and DRIVER_MAN 
   */
  static ManagerType getManagerType(DpConfigNrType confType);

  /** Allocates a DpConfig instance based on the given configuration type.
       This method should be overridden in all implementations of the DpConfigManager interface.
       
       @param configType configuration type.
       @return A pointer to a new configuration instance or NULL if the assertion fails.
   */
  virtual DpConfigPtr allocate(DpConfigType configType) = 0;

   /** Checks if the specified configuration type within specified DpElement node are valid for the manager.
       This method should be overridden in all implementations of the DpConfigManager interface!
       
       @param configType configuration type.
       @param elementType element type.
       @return A PVSS_TRUE if the types are valid, otherwise PVSS_FALSE.
   */
  virtual PVSSboolean checkConfigType(DpConfigType configType, DpElementType elementType) = 0;

  // Generierte Methoden :
protected:
private:

// ............................Anfang User-Attribut-Definitionen...................
// .............................Ende User-Attribut-Definitionen....................
};

// ================================================================================
// Inline-Funktionen :

// ............................Anfang User-Inlines.................................
// .............................Ende User-Inlines..................................

#endif /* _DPCONFIGMANAGER_H_ */
