// DATEIBESCHREIBUNG ==============================================================
// VERANTWORTUNG: Andreas Pfluegl
// BESCHREIBUNG : pattern matching for numbers
//                
//
// AENDERUNGS-HISTORIE
// Ver.  | Datum      | Aenderungen                            | ModNr.| Autor
// ------+------------+-----------------Anfang-----------------+-------+-----------
//   1.0 |            | 1.inital                               |     0 |
//   1.1 | 04.03.2010 | doxygen comments added                 |     0 | mrosen
// ======================================Ende======================================
#ifndef _NUMBERMATCH_H_
#define _NUMBERMATCH_H_

#include <Variable.hxx>
#include <CharString.hxx>

class UIntegerVar;
class IntegerVar;
class FloatVar;
class BitVar;

/** Range pattern for numeric Variables.
    e.g.
     - (-99) - (-9)    
     - (-99)-(-9)
     - (-9) - 22
     - (-9)-22
     - 22 - 88
     - 22.5-88.2
     - * (to match every numeric Variable)
  */
class DLLEXP_BASICS NumberMatch
{
  friend class UNIT_TEST_FRIEND_CLASS;
  
  public:
    NumberMatch();

  public:
    /** Parses the pattern to provide a faster match.
        @param pattern a string containing one of the following pattern forms
                       - @e LB-UB to match numbers in range [@e LB, @e UB]
                       - @e N to match only number @e N
                       - * to match every number
        @param variableType the VariableType, for which the pattern shall be
                            evaluated in subsequent calls of NumberMatch::match
        @return  false if the pattern is not supported.
    */
    bool setPattern(const char *pattern, VariableType variableType);

    /** Checks if the given Variable matches the stored pattern
        @param _value the Variable to check
        @return true iff _value matches the last valid pattern given to setPattern
        @see setPattern
    */
    bool match(const Variable &_value) const;

  private:
    bool setPattern(const char *pattern);

    bool match(const BitVar &_value) const;
    bool match(const FloatVar &_value) const;

    CharString getNumber(const char *_str, size_t &_pos, bool &_ok);
    
  private:
    CharString number1_;
    CharString number2_;
};

#endif /* _NUMBERMATCH_H_ */

