#ifndef _JSONCONVERTER_H_
#define _JSONCONVERTER_H_

class CharString;
class Variable;

/** This methods are used to convert JSON to WinCC_OA and vice-versa
    @author M.Wallner, Martin Koller
 */
namespace JSONConverter
{
  /** Decode a json string to a mapping or a dyn variable
      The json string must be UTF-8 encoded as defined by the JSON standard
              http://tools.ietf.org/html/rfc7159#page-9
      @param json The json string that will be decoded.
      @param error Error description if given json is not valid
      @return Variable*: Either a MappingVar or a DynVar
        If an error occurs during parsing the return value will be 0
   */
  DLLEXP_CTRL Variable *decode(const CharString &json, CharString &error);

  /** Encode a mapping or a dyn variable to json
      @param any The variable to encode. Mappings are expected to have only strings as keys,
        keys with different types will be omitted.
        Unsupported values will be formatted with var.formatValue()
      @return The JSON string always in UTF-8 as defined by the JSON standard
              http://tools.ietf.org/html/rfc7159#page-9
              When a 0 pointer is given, the result is an empty string
   */
  DLLEXP_CTRL CharString encode(const Variable *any, bool compactFormat = true);
};

#endif //_JSONCONVERTER_H_
