#ifndef _STATDONECB_H_
#define _STATDONECB_H_

#include <DoneCB.hxx>

class Variable;

/*  author VERANTWORTUNG: Andreas Pfl�gl */
/** Informiert CTRL ob das Script der Stat-Funktion abgebrochen worden ist oder nicht.
  *                  
  */
class DLLEXP_CTRL StatDoneCB: public DoneCB
{
  public:
    inline StatDoneCB(bool &done) :statFuncDone(done) { }
    ///
    virtual ~StatDoneCB() { }

    // return a copy of this
    virtual DoneCB *clone() const { return new StatDoneCB(statFuncDone); }

    /// this is the Callback-function
    virtual void execute(const Variable *var = 0) { statFuncDone = true; }

  protected:

  private:

  bool &statFuncDone; 
};

#endif /* _STATDONECB_H_ */
