#ifndef _CNSTREE_H_
#define _CNSTREE_H_

#include <SimplePtrArray.hxx>

#include <CNSObject.hxx>
#include <CNSContainer.hxx>
#include <CNSNodeNames.hxx>
#include <CNSNodeDataHeap.hxx>
#include <CNSDataIdentifier.hxx>

#include <vector>
#include <utility> // for std::pair

// forward declarations
class CNSView;
class CNSTree;
class CNSTreeNode;
class CNSTreeVisitor;

// explicit instantiation of templates
#ifdef WIN32
#pragma warning ( disable: 4231 )
#endif

#if defined(LIBS_AS_DLL)
EXTERN_DATAPOINT template class DLLEXP_DATAPOINT SimplePtrArray<CNSTree>;
EXTERN_DATAPOINT template class DLLEXP_DATAPOINT SimplePtrArray<CNSTreeNode>;
#endif

#ifdef WIN32
#pragma warning ( default: 4231 )
#endif


/**
 * The root node of a tree of CNS nodes. See CNSTreeNode for details.
 *
 * @see CNSTreeNode
 * @internal
 */
class  DLLEXP_DATAPOINT CNSTree : public CNSObject
{
public:
  // necessary for fetchPathPtrs()
  typedef std::pair<const char *, size_t> StrWithLen;

  /// BCM stream input operator
  friend DLLEXP_DATAPOINT itcNdrUbReceive &operator>>(itcNdrUbReceive &from, CNSTree &tree);
  /// BCM stream output operator
  friend DLLEXP_DATAPOINT itcNdrUbSend &operator<<(itcNdrUbSend &to, const CNSTree &tree);
  // To access setParent()
  friend class CNSView;

public:
  /**
   * Default constructor. Creates an empty node without names, data
   * and parent view.
   * Use only for BCM streaming.
   */
  CNSTree();

  /**
   * Creates a new root node of a CNS tree. If you do not specify a view here,
   * be aware that the node might not work correctly as long as you do not
   * supply a parent view.
   *
   * @param nodeNames The technical name and display names of this node
   * @param nodeData The data to be saved inside this node
   * @param view A reference to the view that contains this tree.
   */
  CNSTree(const CNSNodeNames &nodeNames, const CNSDataIdentifier &nodeData);
  CNSTree(const CNSNodeNames &nodeNames, const CNSDataIdentifier &nodeData, CNSObject &parent);

  /// Destructor
  virtual ~CNSTree();

  /** Equality operator (virtual).
      @return int 1 if the values are equal, otherwise 0.
  */
  int operator==(const CNSTree &rVal) const;

public:
  /** Equality operator (virtual).
      @return int 1 if the values are equal, otherwise 0.
  */
  virtual int operator==(const CNSObject &rVal) const;

  /** Check if own type matches or is derived from a given type.
      @param type CNSObjectType to check.
      @return true if the type does match, false if the type does not match.
   */
  virtual bool isA(CNSObjectType type) const { return(type == CNS_TREE); }

  /// @return the CNSObjectType of the object.
  virtual CNSObjectType isA() const { return(CNS_TREE); }

  /**
   * BCM stream output method.
   * Only writes a single node, not the entire sub-tree.
   */
  virtual void outNdrUb(itcNdrUbSend &ndrStream) const;

  /**
   * BCM stream input method.
   * Only reads a single node, not the entire sub-tree.
   */
  virtual void inNdrUb(itcNdrUbReceive &ndrStream);

  /**
   * Returns the view this tree belongs to.
   */
  virtual const CNSView *getView() const;

  /**
   * Adds an existing tree node.
   * If the node is successfully added, the parent tree takes ownership of it.
   *
   * Empty pointers or nodes with existing names will not be added.
   *
   * @return True if the node was successfully added, otherwise false.
   */
  virtual bool addChild(CNSTreeNode *newChild);

  /// The debug function. Print out the contents according to format level (1 - 3)
  void debug(std::ostream &to, int level, unsigned int indent = 0) const;

public:
  /**
   * Returns the view this tree belongs to.
   * Do not delete the returned pointer.
   */
   // TODO: has this function vanished?

  /**
   * Changes the link to the parent view of this tree.
   * Note that this does not change the ownership of a root node,
   * it is still owned by the view where it is stored.
   *
   * Use only for BCM streaming.
   */
  void setView(CNSView &newView);

  /**
   * Returns the names of this node.
   */
  CNSNodeNames getNames() const;

  /**
   * Returns the names of this node.
   */
   // TODO: has this function vanished?

  /**
   * Changes the names of this node.
   *
   * If this node has a parent, and its technical name is changed,
   * it has to be re-inserted into the parent, to preserve the alphabetical
   * sort order.
   */
  void setNames(const CNSNodeNames &newNames);

  /**
   * Returns the data container of this node.
   */
  const CNSDataIdentifier &getDataIdentifier() const;

  /**
   * Changes the data container of this node.
   */
  void setDataIdentifier(const CNSDataIdentifier &newData);

  /**
   * Computes the path of this node, in the format
   * 'System.View:RootNode.Node1.Node2'.
   *
   * @param [out] path Stores the computed path. The path will be appended to
   *                   the existing text, if there is any.
   * @param withSystem Controls whether the path should include the system name
   */
  void getPath(CharString &path, bool withSystem = true) const;

  /**
   * Returns the path of this node, in the format
   * 'System.View:RootNode.Node1.Node2'.
   * @param withSystem Controls whether the path should include the system name
   */
  CharString getPath(bool withSystem = true) const;

  /**
   * Computes the display paths of this node for each display language.
   * The paths have the same format as in getPath(),
   * with the separators ('.') replaced by the language-specific separator
   * character defined in CNSView.
   *
   * @param [out] paths Stores the computed display paths. The path will
   *                    be appended to the existing text, if there is any.
   * @param withSystem Controls whether the path should include the system name
   */
  void getDisplayPaths(LangText &paths, bool withSystem = true) const;

  /**
   * Compute the display path of this node for a single language.
   * The path has the same format as in getPath(),
   * with the separators ('.') replaced by the language-specific separator
   * character defined in CNSView.
   *
   * @param [out] path Stores the computed display path. The path will
   *                   be appended to the existing text, if there is any.
   * @param lang The language for which the display path will be computed.
   * @param withSystem Controls whether the path should include the system name
   */
  void getDisplayPath(CharString &path, LanguageIdType lang, bool withSystem = true) const;

  /**
   * Returns a pointer to the parent node.
   *
   * Must return null for the root node of a tree,
   * for all other nodes which are part of a tree,
   * this should never return null.
   */
  virtual const CNSTreeNode *getParent() const;

  /**
   * Returns a pointer to the parent node.
   *
   * Must return null for the root node of a tree;
   * for all other nodes which are part of a tree,
   * this should never return null.
   *
   * Do not delete the returned pointer.
   */
  virtual CNSTreeNode *getParent();

  /**
   * Returns the root node of the tree this node belongs to.
   *
   * In a working CNS tree, this should always be an instance
   * of the derived class CNSTree.
   */
  const CNSTreeNode &getRoot() const;

  /**
   * Returns the root node of the tree this node belongs to.
   *
   * In a working CNS tree, this should always be an instance
   * of the derived class CNSTree.
   */
  CNSTreeNode &getRoot();

  /**
   * Returns true if the current node is the root node of its tree.
   */
  bool isRoot() const { return ! (parent && parent->isA(CNS_TREE)); }

  /**
   * Returns the number of children of this node.
   */
  unsigned int getNumberOfChildren() const { return children.getNumberOfItems(); }

  /**
   * Returns the child node at the specified index, or null if the index does not exist.
   * Do not delete the returned pointer.
   */
  CNSTreeNode *getChildAt(unsigned int index) { return children.getAt(index); }

  /**
   * Returns the child node at the specified index, or null if the index does not exist.
   */
  const CNSTreeNode *getChildAt(unsigned int index) const { return children.getAt(index); }

  /**
   * Returns the child node with the specified name, or null if no such node was found.
   * Do not delete the returned pointer.
   */
  CNSTreeNode *getChild(const char *childName);

  /**
   * Returns the child node with the specified name,
   * or null if no such node was found.
   */
  const CNSTreeNode *getChild(const char *childName) const;

  /**
   * Adds an existing node to the children of this node.
   * If the child node is successfully added, the node takes ownership of it.
   *
   * Empty pointers or nodes with existing names will not be added.
   *
   * @return True if the node was successfully added, otherwise false.
   */
  bool addChildNode(CNSTreeNode *node);

  /**
   * Removes and deletes the specified child node.
   * The given pointer cannot be used after a successful call,
   * since its memory has been deleted.
   *
   * @return False if the node was not found, otherwise true
   */
  bool removeChildNode(const CNSTreeNode *childNode);

  /**
   * Removes the specified child node, but does not delete it.
   *
   * @return False if the node was not found, otherwise true
   */
  bool cutChildNode(const CNSTreeNode *childNode);

  /**
   * Deletes all child nodes.
   */
  void clearChildNodes() { children.clear(); }

  /**
   * Invokes the specified visitor for this node and all descendents.
   *
   * @return PVSS_TRUE if every invocation of the functor returned PVSS_TRUE,
   *         otherwise PVSS_FALSE
   */
  PVSSboolean visitEveryCNSNode(CNSTreeVisitor &visitor) const;

  /** The clone function is used to create an exact copy of the current object.
      The whole tree with all its nodes is cloned.
      This copy should be deleted after use.
      @return CNSTree* pointer to a newly cloned CNSTree (deep copy).
  */
  CNSTree *clone() const;

  const char *getNamePtr() const;

  const char *getDisplayNamePtr(LanguageIdType lang) const;

protected:
  void setNames(CNSNodeNames *newNames);

  /// Stores either an owned instance of CNSNodeNames,
  /// or a non-owned pointer to an item in CNSNodeDataHeap.
  union
  {
    CNSNodeNames *ptr;
    CNSNodeDataHeap::StringNodePair *idx;
  }
  names;

  CNSDataIdentifier data;

  const CNSView *view; // don't delete
  CNSObject *parent; // don't delete
  SimplePtrArray<CNSTreeNode> children;

  /**
   * Changes the link to the parent node of this node.
   * Note that this does not change the ownership of a node,
   * it is still owned by the parent node where it is stored.
   */
  void setParent(CNSObject &newParent) { parent = &newParent; }

private:
  // avoid generated default methods
  CNSTree &operator=(const CNSTree &);
  CNSTree(const CNSTree &);

  /// collect the pointers of the strings that make up the path of this string
  void fetchPathPtrs(std::vector<StrWithLen> &ptrs, bool withSystem) const;

  /// collect the pointers of the strings that make up the path of this string
  void fetchDisplayPathPtrs(std::vector<CNSTree::StrWithLen> &ptrs,
                            const CharString &separator,
                            LanguageIdType lang, bool withSystem) const;

  /// builds a string out of the char pointers collected by fetchPathPtrs()
  char *buildStrFromPtrs(const std::vector<StrWithLen> &ptrs, size_t &len) const;

  ///
  void setViewAtAllNodes(CNSView &newView);

};

//------------------------------------------------------------------------------
//--
//------------------------------------------------------------------------------
inline const char *CNSTree::getNamePtr() const
{
  if (view == 0 || !CNSContainer::isValid())
  {
    return(((names.ptr == 0) ? "" : names.ptr->getNamePtr()));
  }

  return(CNSContainer::getHeap().getNamePtr(names.idx));
}

//------------------------------------------------------------------------------
//--
//------------------------------------------------------------------------------
inline const char *CNSTree::getDisplayNamePtr(LanguageIdType lang) const
{
  if (view == 0 || !CNSContainer::isValid())
  {
    return(((names.ptr == 0) ? "" : names.ptr->getDisplayNamePtr(lang)));
  }

  return(CNSContainer::getHeap().getDisplayNamePtr(names.idx, lang));
}

//------------------------------------------------------------------------------
//--
//------------------------------------------------------------------------------
inline const CNSDataIdentifier &CNSTree::getDataIdentifier() const
{
  return(data);
}



//==============================================================================
//== CNSTreeNode
//==============================================================================


/**
 * Internal implementation of a single node of a CNS tree, holding the names,
 * the data and the linking information of the tree.
 *
 * Every node has a (technical) name, which is used for addressing, a collection
 * of display names and a container for various data (which might be empty).
 *
 * A node contains and thus owns its child nodes, which means a node cannot
 * be relocated just by changing its parent pointer. It has to be removed
 * from the old parent and reattached to the new.
 *
 * Please make sure to set the parent pointer on every node that you create
 * and attach to a tree, otherwise the node will not be able to find out
 * its path and containing view and system.
 *
 * For the root node of a tree, use the base class CNSTree, which can hold
 * a pointer to its parent view.
 *
 * @internal
 */
class DLLEXP_DATAPOINT CNSTreeNode : public CNSTree
{
public:
  /// BCM stream input operator (streams the whole tree)
  friend DLLEXP_DATAPOINT itcNdrUbReceive &operator>>(itcNdrUbReceive &from, CNSTree &tree);
  /// BCM stream output operator (streams the whole tree)
  friend DLLEXP_DATAPOINT itcNdrUbSend &operator<<(itcNdrUbSend &to, const CNSTree &tree);
  /// BCM stream input operator (streams a single node)
  friend DLLEXP_DATAPOINT itcNdrUbReceive &operator>>(itcNdrUbReceive &from, CNSTreeNode &node);
  /// BCM stream output operator (streams a single node)
  friend DLLEXP_DATAPOINT itcNdrUbSend &operator<<(itcNdrUbSend &to, const CNSTreeNode &node);
  // for streaming operators
  friend class CNSTree;

public:
  /**
   * Default constructor. Creates an empty node without names,
   * data and parent link.
   * Use only for BCM streaming.
   */
  CNSTreeNode() : CNSTree() { }

  /**
   * Creates a new node of a CNS tree.
   *
   * For the root node of the tree, use the derived class CNSTree instead.
   *
   * @param nodeNames The technical name and display names of this node
   * @param nodeData The data to be saved inside this node
   * @param parentNode A pointer to the parent node this node belongs to.
   */
  CNSTreeNode(const CNSNodeNames &nodeNames, const CNSDataIdentifier &nodeData);

  CNSTreeNode(const CNSNodeNames &nodeNames, const CNSDataIdentifier &nodeData, CNSObject &parentNode);

  /// Destructor
  virtual ~CNSTreeNode();

  /** Equality operator (virtual).
      @return int 1 if the values are equal, otherwise 0.
  */
  int operator==(const CNSTreeNode &rVal) const;

public:

  /** Equality operator (virtual).
      @return int 1 if the values are equal, otherwise 0.
  */
  virtual int operator==(const CNSObject &rVal) const;

  /** Check if own type matches or is derived from a given type.
      @param type CNSObjectType to check.
      @return true if the type does match, false if the type does not match.
   */
  virtual bool isA(CNSObjectType type) const { return((type == CNS_TREE) || (type == CNS_TREE_NODE)); }

  /// @return the CNSObjectType of the object.
  virtual CNSObjectType isA() const { return(CNS_TREE_NODE); }

  /**
   * BCM stream output method.
   * Sends the entire sub-tree starting at this node.
   */
  virtual void outNdrUb(itcNdrUbSend &ndrStream) const;

  /**
   * BCM stream input method.
   * Reads the entire sub-tree starting at this node.
   */
  virtual void inNdrUb(itcNdrUbReceive &ndrStream);

  /// The debug function. Print out the contents according to format level (1 - 3)
  void debug(std::ostream &to, int level, unsigned int indent = 0) const;

  /** The clone function is used to create an exact copy of the current object.
      This copy should be deleted after use.
      @return CNSTreeNode* pointer to a newly cloned CNSTreeNode.
  */
  CNSTreeNode *clone() const;

protected:

private:
  // avoid generated default methods
  CNSTreeNode &operator=(const CNSTreeNode &);
  CNSTreeNode(const CNSTreeNode &);

};

#endif // _CNSTREE_H_
