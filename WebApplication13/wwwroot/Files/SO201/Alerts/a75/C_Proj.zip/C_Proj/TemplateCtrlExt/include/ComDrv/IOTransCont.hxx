#ifndef _IOTRANSCONT_H_
#define _IOTRANSCONT_H_

#include <DynPtrArray.hxx>
#include <TimeVar.hxx>
#include <IOTransItem.hxx>

class DpMsgDrvAnswer;
class ErrClass;

/** This class contains a list of ongoing IO transactions.
  * It is used for the managment of I/O peripheral addresses.
  * @classification ETM internal
  */
class IOTransCont
{

  friend class UNIT_TEST_FRIEND_CLASS;    

  public:
    /** Constructor
    */
    IOTransCont();

    /// destructor
    virtual ~IOTransCont();

    /** Adds a transaction. It sets the ..original_value.._transaction attribute
      * and stores the pointer to the HWMapDpPa.
      * @param dpId data point identifier, which is concerned by the transaction.
      * @param varPtr pointer to variable containing the value to be set.
      */
    void outputTrans (const DpIdentifier & dpId, VariablePtr varPtr);

    /** Adds a transaction. It stores the answer pointer for the write transaction.
      * @param dpId data point identifier, which is concerned by the transaction.
      * @param ansPtr pointer to answer which sould be sent on confirmation.
      */
    void outputTrans (const DpIdentifier & dpId, DpMsgDrvAnswer *ansPtr);

    /** Checks if a timeout appears for any ongoing transaction.
      * It removes the transaction from the list and resets the old value.
      */
    void checkTimeout ();

    /** Processes the input part of a transaction. It marks the transaction as not
      * running and it sets the old value.
      * @param dpId data point identifier, which is concerned by the transaction.
      * @param varPtr pointer to variable containing the value received from the
               peripheral device.        
      * @param flags the flags to store with the variable
      */
    void inputTrans (const DpIdentifier & dpId, VariablePtr varPtr, const BitVec &flags);

    /** Process the write confirmation of a transaction.
      * @param dpId DPE identifier
      * @param answerId the answer id concerned
      * @param errorPtr an optional error object to insert into the answer message -
               the error object is captured by the answer message and deleted by the answer after sending
      */
    void commitTrans (const DpIdentifier &dpId, int answerId, ErrClass *errorPtr = 0);

    /** Finds dp Id in the list and removes it. 
      * @param dpId data point identifier
      */
    void removeItem (const DpIdentifier & dpId);

  private:
    /** Compares two IO transaction items
    * @param g1 the first item for comparison
    * @param g2 the second item for comparison
    * @return result of comparison
    */
    static int compare2 (const OutTransItem * g1, const OutTransItem * g2);

    // Copy constructor
    IOTransCont(const IOTransCont&);
    // Assignment operator
    IOTransCont& operator=(const IOTransCont&);

    TimeVar lastTime_;
    TimeVar currentTime_;
    unsigned tickCounter_;
    // array for active transactions 
    DynPtrArray<InTransItem> transList_;
    DynPtrArray<OutTransItem> writeTransList_;
    // map of all existing last values
    void *transMap_;
};
#endif
