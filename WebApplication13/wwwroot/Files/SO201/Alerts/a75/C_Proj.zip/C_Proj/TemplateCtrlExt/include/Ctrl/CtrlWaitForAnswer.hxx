#ifndef _CTRLWAITFORANSWER_H_
#define _CTRLWAITFORANSWER_H_

#include <WaitForAnswer.hxx>
#include <HotLinkWaitForAnswer.hxx>
#if PVSS_VERS >= 300000
#include <AlertHotLinkWaitForAnswer.hxx>
#endif
#include <Types.hxx>

class WaitDpGet;


/*  author VERANTWORTUNG: Martin Koller */
/** continues execution when waiting for the dpGetPeriod request answer */
class DLLEXP_CTRL CtrlWaitForAnswer : public WaitForAnswer
{
  public:
    CtrlWaitForAnswer(WaitDpGet *cond);
    virtual ~CtrlWaitForAnswer();

    virtual void callBack(DpMsgAnswer &answer);

    void setWaitCond(WaitDpGet *wait) { waitCond = wait; }

    PVSSboolean needRefresh(DpMsg *msg);

  protected:

  private:
    WaitDpGet *waitCond;
};

//------------------------------------------------------------------------------

/*  author VERANTWORTUNG: Andreas Pfluegl */
/** Wait Objekt: Wartet auf eintreffen eines HotLinks
  *   Vorgehensweise:
  *      Anmeldung f�r einen HotLink.
  *        1.) Objekt anlegen und ueber WaitDpGet mit einem ConnTblEntry verbinden.
  *        2.) mit dpConnect Manager Klasse CallbackObjekt schicken.
  *      Anmedlungsbest�tigung mit Letztwert trifft ein.
  *        1.) hotLinkCallback wird aufgerufen.
  *      HotLink trifft ein.
  *        1.) hotLinkCallback wird aufgerufen.
  */
class DLLEXP_CTRL CtrlHotLinkWaitForAnswer : public HotLinkWaitForAnswer
{
  public:
    /// WaitDpGet muss einen valid ConnTblEntry haben
    CtrlHotLinkWaitForAnswer(WaitDpGet *cond);

    /// WaitDpGet muss einen valid ConnTblEntry haben.
    CtrlHotLinkWaitForAnswer(WaitDpGet *cond, PVSSboolean deliverConnectAnswer);

    /// Destruktor
    virtual ~CtrlHotLinkWaitForAnswer();

    /// HotLink Callback startet Thread und fuehrt work Function aus
    virtual void hotLinkCallBack(DpMsgAnswer &answer);

    /// HotLink Callback startet Thread und fuehrt work Function aus
    virtual void hotLinkCallBack(DpHLGroup &group);

    /// WaitDpGet muss einen valid ConnTblEntry haben.
    void setWaitCond(WaitDpGet *wait) { waitCond = wait; }

  protected:
    WaitDpGet *waitCond;

  private:
    PVSSboolean mdeliverConnectAnswer;
};


class DLLEXP_CTRL CtrlQueryHotLinkWaitForAnswer : public CtrlHotLinkWaitForAnswer
{
  public:
    CtrlQueryHotLinkWaitForAnswer(WaitDpGet *cond);
    virtual ~CtrlQueryHotLinkWaitForAnswer();

    virtual void hotLinkCallBack(DpMsgAnswer &answer);
    virtual void hotLinkCallBack(DpHLGroup &hlGroup);
};


//------------------------------------------------------------------------------
/** Callback object for alertConnect
  */

class DLLEXP_CTRL CtrlAlertHotLinkWaitForAnswer : public AlertHotLinkWaitForAnswer
{
  public:
    CtrlAlertHotLinkWaitForAnswer(WaitDpGet *cond, PVSSboolean deliverConnectAnswer);
    virtual ~CtrlAlertHotLinkWaitForAnswer();

    virtual void alertHotLinkCallBack(DpMsgAnswer &answer);
    virtual void alertHotLinkCallBack(AlertAttrList &group);

    // Set wait condition (to NULL)
    void setWaitCond(WaitDpGet *wait) { waitCond = wait; }

  private:
    WaitDpGet *waitCond;
    PVSSboolean mdeliverConnectAnswer;
};

#endif /* _CTRLWAITFORANSWER_H_ */
