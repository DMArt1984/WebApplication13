// DATEIBESCHREIBUNG ==============================================================
// DATEINAME:     PtrList.hxx
// VERANTWORTUNG:	Thomas Koroschetz
// BESCHREIBUNG:	Die Klasse PtrList dient als Schnittstelle zu von PtrListItem
// 		abgeleiteten Objekten = einfach verkettete Liste von Objekten.
//
// ======================================Ende======================================
#ifndef _PTRLIST_H_
#define _PTRLIST_H_

// Vorwaerts-Deklaration der Eigenen Klasse
class PtrList;

#include <PtrListItem.hxx>

/** A simple pointer list. This list stores PtrListItem objects.
    @classification ETM internal
*/
class DLLEXP_BASICS PtrList 
{
public:
  /// Constructor.
  PtrList();
  /// Destructor.
  virtual ~PtrList();

  /** Subscript operator.
      This operator allows the direct access to the list items.
	  Works independently from getFirst / getNext.
      Keep in mind that the list has to be traversed, however.
	  */
  PtrListItem* operator[](unsigned int index) const;

  /** Append a new item at the end of the list.
      @param itemPtr Item pointer to be added.
	  */
  void append(PtrListItem* itemPtr);
  /** Insert new item as first in the list.
      @param itemPtr Item pointer to be added.
	  */
  void insertAsFirst(PtrListItem* itemPtr);
  /** Insert itemPtr after thisItemPtr.
      ATTENTION: For proper usage only call this function with thisItemPtr being part
                 of the PtrList. It will not be checked whether thisItemPtr is part
                 of the PtrList for performance reasons!
      @param thisItemPtr Item pointer after which the item pointer will be added.
	  @param itemPtr Item pointer to be added.
	  */
  void insertAfter(PtrListItem* thisItemPtr, PtrListItem* itemPtr);

  /** Get the first element from the list.
      This function uses an internal state to iterate over the list.
      @return The first item in the list or NULL if the list is empty.
	  */
  PtrListItem* getFirst() const { return ((PtrListItem* &)lastAccessedPtr) = headPtr; }
 
  /** Get the next element from the list.
      This functions uses an internal state to iterate over the list.
      @return the next item in the list or NULL if the last object was accessed.
	  */
  PtrListItem* getNext() const 
  { return ((PtrListItem* &) lastAccessedPtr) = ( (lastAccessedPtr) ? lastAccessedPtr->nextPtr : 0 ); }

  /** Get the first element from the list without changing the internal lastAccessed pointer. 
      Calling this function whis will not change the sequence of getFirst / getNext.
      @param itemPtr A dummy argument. ItemPtr is not updated.
      @return The first item in the list or NULL if the list is empty.
   */
  PtrListItem *getFirst(PtrListItem * itemPtr) const {return headPtr;}

  /** Get the element behind itemPtr without changing the internal lastAccessed pointer. 
      Calling this function whis will not change the sequence of getFirst / getNext.
      @param itemPtr The list item.
      @return The item after itemPtr or NULL if the itemPtr is the last item in the list.
   */ 
  PtrListItem *getNext(PtrListItem *itemPtr) const { return (itemPtr ? itemPtr->nextPtr : 0); }

  /** Get the last element from the list. 
      Calling this function whis will not change the sequence of getFirst / getNext.
	  */
  PtrListItem*  getLast() const { return tailPtr; }

  /// Get the last accessed element once again.
  PtrListItem*  getLastAccessed() const { return lastAccessedPtr; }

  /** Remove the itemPtr from the list and delete it.
      If itemPtr is the last accessed pointer of getFirst() / getNext(), the last accessed pointer will be updated to point to the item following itemPtr.
   */   
  void remove(PtrListItem* itemPtr);
  
  /// Get number of items in the list.
  unsigned int getNumberOfItems() const { return numberOfItems; }
  
  /** Cut out the first element.
      The developer is responsible for deleting the object.
	  */
  PtrListItem* cutFirst();

  /** Cut out the requested element.
      The developer is responsible for deleting the object.
      If itemPtr is the last accessed pointer of getFirst() / getNext(), the last accessed pointer will be updated to point to the item following itemPtr.
   */   
  PtrListItem* cut(PtrListItem* itemPtr);
  
  /** Cut out the last element.
      The developer is responsible for deleting the object.
	  */
  PtrListItem*  cutLast();
  
  /// Clear the list, remove all objects.
  virtual void clear();

private:

  // Zaehler fuer die momentan in der Liste befindlichen Objekte
  unsigned int numberOfItems;
  PtrListItem* headPtr;
  PtrListItem* tailPtr;
  PtrListItem* lastAccessedPtr;

  // damit sie niemand verwenden kann
  inline PtrList(const PtrList &) {}  //COVINFO LINE: defensive (AP: disallow copy ctor)
  inline PtrList &operator=(const PtrList &) {return *this;} //COVINFO LINE: defensive (AP: disallow operator=)
};

#ifdef LINUX2                  // weils unter Linux2 Probleme macht!
#  define NO_PTRLIST_INLINE
#endif

#ifdef WIN32                   // Weils auch unter optimierten NT Probleme macht!
#  define NO_PTRLIST_INLINE
#endif

#ifndef NO_PTRLIST_INLINE
#  include <PtrList_Inl.hxx>
#endif

#endif /* _PTRLIST_H_ */
