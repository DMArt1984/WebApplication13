#ifndef _CONFIGTYPES_H_
#define _CONFIGTYPES_H_

// VERANTWORTUNG: Martin Koller
// BESCHREIBUNG: Enthaelt enums etc. von div. Configs

// ========== AckKindType ============================================================
enum AckKindType {
    ACKKIND_NOT = 0,
    ACKKIND_MULTIPLE,
    ACKKIND_SINGLE
};

// ========== AcknowledgementType ============================================================
// enum zur Abbildung der Quittierungsarten (siehe Meldungskonzept
// Kapitel: Quittierungsarten - Meldungszustaende von Bereichen)
enum AcknowledgementType {
    // Quittieren loescht
    ACKNOWLEDGEMENT_DELETES = 0,
    // nicht quittierbar
    ACKNOWLEDGEMENT_NONE,
    ACKNOWLEDGEMENT_NON = ACKNOWLEDGEMENT_NONE,
    // kam ist quittierbar
    ACKNOWLEDGEMENT_CAME,
    // Meldungspaar ist quittierungspflichtig
    ACKNOWLEDGEMENT_PAIR,
    // kam und ging sind quittierungspflichtig
    ACKNOWLEDGEMENT_CAMEANDGONE,
    // Quittierungsart fuer Summenalarme, entspricht nicht quittierbar
    ACKNOWLEDGEMENT_SUMALERT
};

// ========== AlertStateType ============================================================
// Definition der Meldungszustaende (siehe Analysedokument: Meldungskonzept, Kapitel: 4.1
// Quittierungsarten - Meldungszustaende von Bereichen)
enum AlertStateType {
    // keine Meldung
    ALERTSTATE_NOALERT = 0,
    // kam bzw. kam/unquittiert (zu einem Wert zusammengefasst)
    ALERTSTATE_CAME_NOTACKNOWLEDGED,
    // kam/quittiert
    ALERTSTATE_CAME_ACKNOWLEDGED,
    // ging/unquittiert
    ALERTSTATE_GONE_NOTACKNOWLEDGED,
    // kam/ging/unquittiert
    ALERTSTATE_CAME_GONE_NOTACKNOWLEDGED
};

// ========== SumAlertOrderType ============================================================
// enum zur Abbildung der Reihung von Meldungen in einer Sammelmeldungsbehandlung
// (siehe Meldungskonzept Kapitel: Meldungszustand einer Sammelmeldungsbehandlung)
enum SumAlertOrderType {
    // Prioritaet vor Meldezustand
    ORDER_PRIO_STATE = 0,
    // Kurzzeichen vor Meldezustand
    ORDER_SIGN_STATE,
    // Meldezustand vor Prioritaet
    ORDER_STATE_PRIO,
    // Meldezustand vor Kurzzeichen
    ORDER_STATE_SIGN
};

// ========== HysteresisType ============================================================
// enum zur Abbildung der verschiedenen Hysterese-Arten
enum HysteresisType {
    // keine Hysterese
    HYSTERESIS_NON = 0,
    // wertbezogene Hysterese
    HYSTERESIS_VALUE,
    // Meldeverzoegerung (zeitliche Hysterese)
    HYSTERESIS_TIME
};

// ========== CounterConvType ============================================================
// Was ist zu zaehlen.
enum CounterConvType {
    CountPositiveEdges,
    CountNegativeEdges,
    CountAllEdges,
    CountPositivePulses,
    CountNegativePulses
};

// ========== DpConversionType ============================================================
// Typ der Konvertierung oder Glaettung.
enum DpConversionType {
    DpConvNoConversion,
    DpConvLog,
    DpConvPoly,
    DpConvLinInt,
    DpConvNullSupp,
    DpConvInvert,
    DpConvDateTime,
    DpConvTrigger,
    DpConvPrec,
    DpConvCounter,
    DpConvSimpleSmooth,
    DpConvDerivSmooth,
    DpConvFlutterSmooth
};

// ========== DpSimpleSmoothType ============================================================
// Typ der Glaettung.
enum DpSimpleSmoothType {
    DpValueSmooth,
    DpTimeSmooth,
    DpTimeAndValSmooth,
    DpTimeOrValSmooth,
    DpOldNewComparison,
    DpOldNewAndTimeSmooth,
    DpOldNewOrTimeSmooth,
    DpValRelSmooth,
    DpTimeAndValRelSmooth,
    DpTimeOrValRelSmooth
};

// ========== RangeType ============================================================
enum RangeType {
    RANGETYPE_NORANGE,
    RANGETYPE_RANGECHECK,
    RANGETYPE_RANGE_ALL,
    RANGETYPE_SET,
    RANGETYPE_MINMAX,
    RANGETYPE_MATCH,
    RANGETYPE_MIN,
    RANGETYPE_MAX
};

// ========== DbArchiveProcedure ============================================================
// Typ der zyklischen Bearbeitung. (Siehe Analysedokument, Datenverwaltung)
enum ArchiveProcedureType {
    ArchProcNothing = 0,
    ArchProcDelete,
    ArchProcMove,
    ArchProcSimpleSmooth ,
    ArchProcSimpleSmoothAndMove ,
    ArchProcDerivSmooth ,
    ArchProcDerivSmoothAndMove ,
    ArchProcDecimation,
    ArchProcDecimationAndMove,
    ArchProcAverageValue ,
    ArchProcAverageValueAndMove ,
    ArchAverageTime0,
    ArchAverageTime0AndMove,
    ArchAverageTime1,
    ArchAverageTime1AndMove,
    ArchProcValueArchive      // esperrer 18.1.2000 HDB-Erweiterung
};

// ========== DbArchiveTimes ============================================================
// Haufigkeit der zyklischen Bearbeitung. (Siehe Analysedokument, Datenverwaltung)
enum ArchiveFrequencyType {
    ArchiveDoNotDoIt = 0,
    ArchiveDoWhenSaving,
    ArchiveDoEveryDay,
    ArchiveDoEveryWeek,
    ArchiveDoEveryMonth,
    ArchiveDoEveryYear
};

// ========== DbArchiveTimes ============================================================
// Typ des Absatndes und Intervallen der zyklischen Bearbeitung. (Siehe Analysedokument, Datenverwaltung)
enum ArchiveTimeDiffType {
    ArchTimeDiffNone = 0,
    ArchTimeDiffSecond,
    ArchTimeDiffMinute,
    ArchTimeDiffHour,
    ArchTimeDiffDay,
    ArchTimeDiffWeek,
    ArchTimeDiffMonth,
    ArchTimeDiffYear
};

// ////////////////////////////////////////////////////////////////////////////////////////////////
// Diese Reihenfolge darf nicht geaendert werden
// ========== TransformationType ============================================================
/** Default transformation type constants are provided below. The specific driver implementation has to define it's own transformation constants
  User defined transformations start at a specific index at the end of this enum (TransUserType).
  @see Transformation
  @classification ETM internal
*/
typedef unsigned int TransformationType;

/// (0). empty transformation type
static const TransformationType TransUndefinedType = 0;

///Legacy driver transformation types
///Will be merged to the specific driver in near future
///Don't use them in own drivers
enum : TransformationType
{
    /** (1). profibus boolean type */
    PbusTransBooleanType = 1,
    /** (2). profibus int8 type */
    PbusTransInt8Type,
    /** (3). profibus int16 type */
    PbusTransInt16Type,
    /** (4). profibus int32 type */
    PbusTransInt32Type,
    /** (5). profibus uint8 type */
    PbusTransUInt8Type,
    /** (6). profibus uint16 type */
    PbusTransUInt16Type,
    /** (7). profibus uint32 type */
    PbusTransUInt32Type,
    /** (8). profibus float type */
    PbusTransFloatType,
    /** (9). profibus string type */
    PbusTransVisibleType,
    /** (10). profibus octet stream type */
    PbusTransOctetType,
    /** (11). profibus date type */
    PbusTransDateType,
    /** (12). profibus time type */
    PbusTransTimeType,
    /** (13). profibus time difference type */
    PbusTransTimeDifferType,
    /** (14). profibus bit string type (0=MSB, 7=LSB) */
    PbusTransBitStringType,
    /** (15). internal bit string trafo in reversed order for DP (7=MSB, 0=LSB) */
    PbusTransBitStringReverseType,
    // Bis hier sind die Profibus Standard-Typen definiert! Alle weiteren enums
    // betreffen Anwender-definierte Typen und muessen in der, hier angegebenen Reihenfolge
    // im Objektverzeichnis angelegt sein!
    /** (16). special profibus type for siemens kt format */
    PbusTransSiemKTType,
    /** (17). special profibus type for BCD16 type */
    PbusTransBCD16Type,
    /** (18). internal transformation for handling profibus records */
    PbusTransRecordType,        // a special transformation designed for handling PBUS records
    /** (37). profibus bit string type (0=MSB, 7=LSB) */
    PbusTransDPBitStringType = 37,
    /** (38). internal bit string trafo in reversed order for DP (7=MSB, 0=LSB) */
    PbusTransDPBitStringReverseType = 38,
    /** (39). undefined profibus transformation */
    PbusTransUndefinedType = 39,

    SsiTransUndefinedType = 40,
    SsiTransUnsignedInt32Type,    // SSI transformations
    SsiTransSignedInt32Type,
    SsiTransTrafoType,
    SsiTransFloatType,
    SsiTransCombValType,
    SsiTransStrTranspType,
    SsiTransSingleAlarmsType,
    SsiTrans8DoubleIndType,
    SsiTrans4DoubleIndType,
    SsiTrans1DoubleIndType,
    SsiTransBinaryCommandType,
    SsiTransStringType,

    SebaTransUndefinedType = 80,
    SebaTransFloatType,

    AgroTransUndefinedType = 120,
    AgroTransFloatType,

    /** (200). tcp sample driver undefined transformation */
    TcpTransUndefinedType = 200,
    /** (201). tcp sample driver boolean transformation */
    TcpTransBooleanType,
    /** (202). tcp sample driver int32 transformation */
    TcpTransInt32Type,
    /** (203). tcp sample driver float transformation */
    TcpTransFloatType,
    /** (204). tcp sample driver ASCII string transformation */
    TcpTransVisibleType,

    RK512TransUndefinedType = 240,  // 3964R / RK512 Trafos
    RK512TransByteType,
    RK512TransUByteType,
    RK512TransWordType,
    RK512TransUWordType,
    RK512TransDWordType,
    RK512TransUDWordType,
    RK512TransFloatType,
    RK512TransBCDType,              // 2-Byte BCD
    RK512TransBCD4Type,             // 4-Byte BCD
    RK512TransKCType,               // Counterformat
    RK512TransKTType,               // Zaehlerformat
    RK512TransBitType,
    RK512TransStringType,
    RK512TransLByteType,            // lower Byte eines Wortes
    RK512TransRByteType,            // upper Byte eines Wortes

    AbbTransUndefinedType = 280,    // Abb-Treiber
    AbbTransBitType = 281,          // Abb-Treiber: Meldung
    AbbTransIntType = 282,          //    - " -   : Zaehlwert
    AbbTransFloatType = 283,        //    - " -   : Messwert
    AbbTransIntegerType = 284,      //
    AbbTransDoubleType = 285,
    AbbTransBlobType = 286,         //    - " -   : Blob

    AdsTransUndefinedType = 320,    // ADS-Treiber: undefined
    AdsTransBoolType,               // Bit
    AdsTransCharType,               // signed char
    AdsTransByteType,               // unsigned char
    AdsTransIntType,                // signed short
    AdsTransWordType,               // unsigned short
    AdsTransLongType,               // signed long
    AdsTransDWordType,              // unsigned long
    AdsTransStringType,             // char *
    AdsTransTransferType,           // TransferInfo
    AdsTransDeviceListType,         // Geraeteliste (2 Byte in einem int)
    AdsTransFlashTabType,           // Kennungstabelle (DynFloat)
    AdsTransAstroCalType,           // Astronomischer Kalender (DynInt)
    AdsTransCoordType,              // Geographische Koordinaten (DynInt)
    AdsTransTelephoneListType,      // Telefonliste (DynString)
    AdsTransRadioListType,          // Funknachbarliste
    AdsTransLuxTabType,             // Tabelle der Umrechnung V - Lux (DynFloat)

    FwmTransUndefinedType = 360,    // FWM-Treiber
    FwmTransBitType,
    FwmTransIntType,
    FwmTransFloatType,
    FwmTransTimeType,

    UbusTransUndefinedType = 400,   // uBus-Treiber
    UbusTransBitType,
    UbusTransIntType,

    HwdzTransUndefinedType = 440,   // HWDZ-Treiber
    HwdzTransBitType,
    HwdzTransIntType,

    // TLS Driver
    TlsTransUndefinedType = 610,
    TlsTrans0x1fType = 611,
    TlsTransByteType = 612,
    TlsTransWordType = 613,
    TlsTransStringType = 614,
    TlsTransDynVarType = 615,
    TlsTransTimeSyncType = 616,
    TlsTransTimeStampType = 617,
    TlsTransStatusType = 618,
    TlsTransStatType = 619,
    TlsTransInitType = 620,
    TlsTransInterType = 621,
    TlsTransXXXType = 622,
    TlsTransTimeStamp20xType = 623,
    TlsTransTimeStamp21Type = 624,
    TlsTransTimeStamp21xType = 625,
    TlsTransTimeStamp31Type = 626,
    TlsTransTimeStamp31xType = 627,
    TlsTransTimeStamp64Type = 628,
    TlsTransTimeStamp64xType = 629,
    TlsTransTimeStamp48Type = 630,
    TlsTransF4T55Type = 631,
    TlsTransSignedWordType = 632,

    // Applicom Driver
    ApcTransUndefinedType = 640,
    ApcTransBitType = 641,
    ApcTransByteType = 642,
    ApcTransWordType = 643,
    ApcTransDWordType = 644,
    ApcTransFWordType = 645,
    ApcTransUWordType = 646,
    ApcTransUDWordType = 647,

    // TR-SNMP
    SNMPTransUndefinedType = 660,
    SNMPTransInt32Type,           // INTEGER, Integer32
    SNMPTransUInt32Type,          // Unsigned32, Gauge, Gauge32, Counter, Counter32, Timeticks, Timestamp
    SNMPTransUInt64Type,          // Counter64, high/low part
    SNMPTransObjectIdentifierType,// object identifier-> int-array or string
    SNMPTransOctetType,
    SNMPTransDisplayStringType,   // special octet string, c-style string 0..255, string representation, non printable characters ignored
    SNMPTransDateTimeType,        // special octet string, 8 or 11
    SNMPTransMACAddressType,      // special octet string, length 6
    SNMPTransIPAddressType,       // special octet string, length 4
    SNMPTransBitsType,            // snmp v2 bitstring - left for version 2
    SNMPTransSanorsInt32Type,     // SANORS extension int32 transformation
    SNMPTransSanorsStringType,    // SANORS extension displaystring transformation
    SNMPTransDisplayHexStringType,// special octet string, c-style string 0..255, hex representation

    ASXTransUndefinedType = 680,
    ASXTransKMType,
    ASXTransKFType,
    ASXTransKYType,
    ASXTransKHType,
    ASXTransDHType,
    ASXTransKGType,
    ASXTransKMUIntType,
    ASXTransDHQType,
    ASXTransKGQType,

    // Teleperm-Treiber
    TlpTransBoolType = 690,
    TlpTransInt32Type,
    TlpTransFloatType,
    TlpTransStrType,

    // Nis-Treiber
    NisTransBitType = 710,

    // Sinaut-Treiber
    SinautTransDefaultType = 720,
    SinautTransBitType,
    SinautTransBit32Type,
    SinautTransFloat32Type,
    SinautTransInt16Type,
    SinautTransInt32Type,
    SinautTransUInt28Type,
};

static const TransformationType TransformationBaseType = 999; // this is the last internal transformation number
///(1000). the start number for user defined transformations.
static const TransformationType TransUserType = 1000;          // defined for user written drivers

// ========== StatFunctionType ============================================================
// moegliche statistische Funktionen
// wird vom Config: StatFunction und von der Ctrl-Funktion statFunc() verwendet
enum StatFunctionType
{
    STAT_FUNC_MIN = 0,
    STAT_FUNC_MAX,
    STAT_FUNC_MIN_TIME,
    STAT_FUNC_MAX_TIME,
    STAT_FUNC_NUMBER,
    STAT_FUNC_SUM,
    STAT_FUNC_INTEGRAL0,
    STAT_FUNC_INTEGRAL1,
    STAT_FUNC_AVG,
    STAT_FUNC_AVG_WT0,
    STAT_FUNC_AVG_WT1,
    STAT_FUNC_TIME0,
    STAT_FUNC_TIME1,
    STAT_FUNC_CHANGES,
    STAT_FUNC_CHANGES01,
    STAT_FUNC_CHANGES10,
    STAT_FUNC_SAMPLE,
    STAT_FUNC_ENDVALUE,
    STAT_FUNC_DIFF,

    STAT_FUNC_FLOATING_INCR = 0x40// bei Aenderungen StatFunction::isConsistent() anpassen
};

// ================ PeriphAddr ========================================================
// moegliche Address - Modes

/** the driver address mode enum. this enum contains the possible states for
  the address config.
 */
enum AddressMode
{
    /// No address mode specified
    AM_undefined,
    /// (1). DP as output. All DP with same address are sent together.
    AM_Output,      // Gruppenanmeldung im Falle von Arrays
    /// (2). DP as input. Spontaneous data are expected
    AM_InputSpont,
    /// (3). DP as input. Single query data expected
    AM_InputSQuery,
    /// (4). DP as input. Data will be polled.
    AM_InputPoll,
    /// (5). DP as output. Only this DP will be sent
    AM_OutputSingle,    // Einzelanmeldung im Falle von Arrays
    /// (6). DP as output and input spontaneous
    AM_IOGroupSpont,
    /// (7). DP as output and input polling
    AM_IOGroupPoll,
    /// (8). DP as output and single query
    AM_IOGroupSQuery,
    /// (9). alert address
    AM_Alert,
    /// (10) Input on demand
    AM_InputOnDemand,
    /// (11) Input polling on use
    AM_InputCyclicOnUse,
    /// (12) Input/output on demand  - single subscription
    AM_IOOnDemand,
    /// (13) Input/output polling on use - single subscription
    AM_IOCyclicOnUse,
    /// (14) Input spontaneous on use
    AM_InputSpontaneousOnUse,
    /// (15) Input/Output spontaneous on use - single subscription
    AM_IOSpontaneousOnUse,
    /// (16). DP as output and input polling
    AM_IOSinglePoll,

    // ---- modifier ---
    // (32). DP is special address for internal data handling.
    AM_Internal = 0x20,
    /// (64). Flag to switch on low level comparision. Binary or with any AM_Input mode.
    AM_LowLevelFlag = 0x40,

    // internal
    AM_active = 0x80,

    // internal flags, not visible outside config

    // internal check for alert config consistency
    AM_AlertConfigAvailable = 0x100,
    AM_AlertConfigActive = 0x200,

    // internal flag for tracing a specific DPE
    AM_TraceSingle = 0x400,

    // internal flag for current xxxOnUse state
    AM_OnUsePollActive = 0x800,
};

// low-level-filter = alt/neu vergleich auf hardware-objekt-basis. Dieses bit wird
// im response_mode gesetzt (- nur um config nicht aendern zu muessen und weil es
// fuer dieses attribut sowieso schon egal ist (siehe single-mode)!
// Ist dieses Bit gesetzt wird VOR JEDER ANDEREN Behandlung verglichen, ob eine
// Aenderung zum vorigen Objekt existiert. Wurde keine Aenderung festgestellt wird
// das Objekt (von spontaner Benachrichtigung) verworfen.
#define    RESPMODEMASK      0x007F
#define    PERIPHACTIVE      0x0080
#define    LOWLEVELFILTER    0x0040
#define    DRIVERINTERNAL    0x0020
#define    AM_MASK           0x001F

#endif /* _CONFIGTYPES_H_ */
