//----------------------------------------------------------------------------
//  Copyright (C) Siemens AG 2018. All Rights Reserved.
//----------------------------------------------------------------------------
#pragma once

#ifdef _WIN32 // needed for PSID
#  define WIN32_LEAN_AND_MEAN
#  include <windows.h>
#  include <new.h>
#  include <WinSock2.h>
#endif

#include <Types.hxx>
#include <NetUtil.hxx>
#include <CharString.hxx>

#include <fstream>
#include <vector>

#if defined(OS_LINUX) || defined(__APPLE__) || defined(__EMSCRIPTEN__)
#include <sys/time.h>
#include <sys/select.h>
#include <sys/socket.h>
#include <string.h>
#include <sys/stat.h>
#endif

#ifdef OS_FREEBSD
#include <sys/types.h>
#include <sys/time.h>
#include <unistd.h>
#include <sys/socket.h>
// arpa/inet.h definiert inet_ntoa als __inet_ntoa.
// Das betrifft leider auch die Klassendefinition
#include <arpa/inet.h>
#endif

// squirt, 6.4.2004, IM61550: Aenderungen fuer Solaris
#ifdef OS_SOLARIS
#include <sys/time.h>
#include <sys/socket.h>
#ifndef INADDR_NONE
#define INADDR_NONE        ((in_addr_t) 0xffffffffU)
#endif
#endif


/** the non-POSIX wrapper. this class covers all the non-posix system calls used by PVSS-II.
    whenever using system calls try to use these functions to maintain platform compatibility.
*/
namespace NoPosix
{
  // network-related functions moved to NetUtil namespace
  using namespace NetUtil;

  /// delay program execution for seconds:mycroseconds
  DLLEXP_BASICS void delay(unsigned int sec, unsigned int mic);

  /// lock a file by the given file descriptor
  IL_DEPRECATED("deprecated, use OaNoPosix::lockFile() instead")
  DLLEXP_BASICS int lockFile(int fildes);

  /// unlock a file by the given file descriptor
  IL_DEPRECATED("deprecated, use OaNoPosix::unlockFile() instead")
  DLLEXP_BASICS int unlockFile(int fildes);

  /// ask for the password fir a given user
  DLLEXP_BASICS PVSSboolean getPassword(const CharString &userName, CharString &password);

  /// mask the input by stars (WIN32) or simply hide it (UNIX)
  DLLEXP_BASICS CharString getWithoutEcho(const char *prompt);

  /** play a simple beep with the given frequency [Hz] and the duration [milli seconds]
      No soundcard is needed. The beep is played with the internal speaker
  */
  IL_DEPRECATED("deprecated, use OaNoPosix::beep() instead")
  DLLEXP_BASICS void beep(long frequency, long duration);

  /** play a sound file
      @param fileName ... filename including absolute path to the .wav file
      @param loop ... set this to true, if the soundfile shall be played in an endless loop
      @return 0 if everything worked, -1 on error
  */
  IL_DEPRECATED("deprecated, use OaNoPosix::startSound() instead")
  DLLEXP_BASICS int startSound(const char *fileName, bool loop = false);
  /** Set the socket to ignore SIGPIPE system signal. This can be important on non windows platforms.
  */
  DLLEXP_BASICS void ignoreSIGPIPE();

  /** stop the sound currently being played
      @return 0 if everything worked, -1 on error
  */
  IL_DEPRECATED("deprecated, use OaNoPosix::stopSound() instead")
  DLLEXP_BASICS int stopSound();

  /// enum HomeOrig for HOME, HOMEDRIVE, HOMEPATH, HOMEPROFILE
  enum HomeOrig
  {
    /// no user specific Home directory found
    HOME_NOT_FOUND = 0,
    /// env HOME was set
    HOME_FROM_ENV_HOME = 1,
    /// env HOMEDRIVE, HOMEPATH was set
    HOME_FROM_ENV_HD_HP = 2,
    /// got from Profile
    HOME_FROM_PROFILE = 3
  };

  /** get HOME directory
        @param homePath
        @return enum HomeOrig
  */
  DLLEXP_BASICS HomeOrig getHome(CharString & homePath);

  /** set the priority level
        @param  priorityClass OS sepecific priority class
        @return PVSSBoolean result of OS specific SetPriorityClass
  */
  DLLEXP_BASICS PVSSboolean setPriorityClass(int priorityClass);

  /// return the name of the user currently logged onto the system.
  DLLEXP_BASICS CharString getUserName();


  /** get runtime system error number.
        @return errno on UNIX, GetLastError() on Windows
  */
  DLLEXP_BASICS int getLastError();

  /** creates error message for errno / GetLastError() - value
    @see getLastErrorText()
    @param errNo value representing errno on UNIX or GetLastError() on Windows
    @param fun additional preceding text if not NULL
    @return CharString
  */
  DLLEXP_BASICS CharString getErrorText(int errNo, const char *fun = nullptr);

  /** creates error message for errno / GetLastError() ( calls getLastError() ).
        @see getLastError()
        @see getErrorText()
        @param fun additional preceding text if not NULL
        @param errNum return errno/GetLastError() if not NULL
        @return CharString
  */
  DLLEXP_BASICS CharString getLastErrorText(const char *fun = 0, int * errNum = nullptr);

  /** set an environment variable.
      adds the variable name to the environment with the value value,
      if name does not already exist. If name does exist in the environment,
      then its value is changed to value.
      Note: Windows can not set an environment variable without a value (e.g. an empty string
      is not possible)
      @param name the name of the variable
      @param value the value of the variable
      @return zero on success, or -1 if there was insufficient space in the environment.
  */
  DLLEXP_BASICS int setenv(const char *name, const char *value);

  /** deletes the variable name from the environment.
      @param name the name of the variable
      @return zero on success, or -1 on error, with errno set to indicate the cause of the error.
      @see getLastErrorText()
  */
  DLLEXP_BASICS int unsetenv(const char *name);

  /** get an environment variable.
      searches the environment list for a string that matches the string pointed to by name.
      The strings are of the form name = value.
      @param name the name of the variable
      @return returns a pointer to the value in the environment, or 0 if there is no match.
  */
  DLLEXP_BASICS char *getenv(const char *name);

  /** get an environment variable.
      searches the environment list for a string that matches the string pointed to by name.
      The strings are of the form name = value.
      In case the environment variable is not defined an empty string is returned.
      @param name the name of the variable
      @return returns the value as CharString type.
  */
  IL_DEPRECATED("deprecated, use getenv(const char*, CharString &) instead")
  DLLEXP_BASICS CharString getenvPL(const char *name);

  /** get an environment variable.
  searches the environment list for a string that matches the string pointed to by name.
  @param name the name of the variable
  @param buffer [out] receives the value of the environment variable
  @return returns a pointer to the buffer output parameter, or nullptr if there is no match.
  */
  DLLEXP_BASICS char *getenv(const char *name, CharString &buffer);
  
  /** replace fopen standard function with method that treats encoding 
      @param fname filename in project encoding
      @param openMode as used for std::fopen
      @return NULL on error, file pointer on success
  */
  IL_DEPRECATED("deprecated, use OaNoPosix::fopen() instead")
  DLLEXP_BASICS FILE* fopen(const char *fname, const char *openMode); 

  /** replace std::ifstream::open standard function with method that treats encoding of filename
      @param ifstream stream object reference
      @param fname filename in project encoding
      @param openMode as used for std::open
  */
  IL_DEPRECATED("deprecated, use OaNoPosix::open() instead")
  DLLEXP_BASICS void open(std::ifstream &stream, const char *filename, std::ios_base::openmode mode = std::ios_base::in);

  /** replace std::ofstream::open standard function with method that treats encoding of filename
      @param ofstream stream object
      @param fname filename in project encoding
      @param openMode as used for std::open
  */
  IL_DEPRECATED("deprecated, use OaNoPosix::open() instead")
  DLLEXP_BASICS void open(std::ofstream &stream, const char *filename, std::ios_base::openmode mode = std::ios_base::out);

  /** replace std::ofstream::open standard function with method that treats encoding of filename
      @param ofstream stream object
      @param fname filename in project encoding
      @param openMode as used for std::open
  */
  IL_DEPRECATED("deprecated, use OaNoPosix::stat() or better some method of FileSysSlim instead")
  DLLEXP_BASICS int stat(const char *filename, struct ::stat* statBuf);
}

