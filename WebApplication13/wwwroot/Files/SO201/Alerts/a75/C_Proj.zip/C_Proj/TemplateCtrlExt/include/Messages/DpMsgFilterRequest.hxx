#ifndef _DPMSGFILTERREQUEST_H_
#define _DPMSGFILTERREQUEST_H_

/*
VERANTWORTUNG: Robert Trausmuth      
BESCHREIBUNG:
 */

#include <CharString.hxx>
#include <DpMsg.hxx>

/// DpMsgFilterRequest class is used for selecting datapoints or datapoint attributes.
class DLLEXP_MESSAGES DpMsgFilterRequest : public DpMsg
{
  public:
    /// Action type.
    enum DpFilterActionType
    {
      NO_FILTER,
      GET_SIMPLE_REQUEST,
      GET_DATABASE_REQUEST,
      CONNECT_ALL_REQUEST,
      CONNECT_SINGLE_REQUEST,
      DISCONNECT_REQUEST
    };

    /// Default constructor.
    DpMsgFilterRequest(MsgType t = DP_MSG_FILTER_REQUEST);
    /// Constructor.
    DpMsgFilterRequest(MsgType t, DpFilterActionType newType, const CharString &query, 
  PVSSboolean eval = PVSS_FALSE, PVSSboolean allowed = PVSS_FALSE);
    /// Copy constructor.
    DpMsgFilterRequest(const DpMsgFilterRequest &rVal);
    /// Destructor.
    ~DpMsgFilterRequest();    

    /// Write the instance into the itcNdrUbSend stream.
    friend DLLEXP_MESSAGES itcNdrUbSend &operator<<(itcNdrUbSend &ndrStream, const DpMsgFilterRequest &msg);
    /// Read the instance from the itcNdrUbReceive stream.
    friend DLLEXP_MESSAGES itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream, DpMsgFilterRequest &msg);
    /// Comparison operator.
    int operator==(const DpMsgFilterRequest &rVal) const;
    /// Comparison operator.
    int operator==(const Msg &rVal) const;
    /// Assignment operator.
    DpMsgFilterRequest &operator=(const DpMsgFilterRequest &rVal);
    /// Assignment operator.
    Msg &operator=(const Msg &rVal);

    /// Get own type.
    MsgType isA() const; 
    /// Check if own type matches other type.
    MsgType isA(MsgType dpMsgType) const   { return (type == dpMsgType || dpMsgType == DP_MSG_FILTER_REQUEST ? type : DpMsg::isA(dpMsgType)); }
    /// Get flag indicating whether answer is required.
    PVSSboolean needsAnswer() const { return PVSS_TRUE; }
    /// Create new instance.
    virtual Msg *allocate() const { return new DpMsgFilterRequest(type); }
    /** Get number of groups.
        This always returns 1.
        */
    virtual PVSSulong getNrOfGroups() const {return 1;};
    /** Print the contents of the list to an output stream.   
      Level controls the amount of debug information printed and shall be > 0.
    */
    virtual void debug(std::ostream &to, int level) const;

    /// Get action type.
    DpFilterActionType getActType() const { return actType; }
    /// Set action type.
    void setActType(DpFilterActionType newActType) { actType = newActType; }

    /// Get query string.
    const CharString &getQuery() const { return queryText; }
    /// Set query string.
    void setQuery(const CharString &newQuery) {queryText = newQuery;} 

    /// Get the connection ID.
    PVSSulong getIdentifier() const           { return identifier;  }
    /// Set the connection ID.
    void setIdentifier(const PVSSulong newId) { identifier = newId; }

    /// Get wantEvaluate attribute.
    PVSSboolean wantsEvaluate() const {return evaluateAtOnce;}
    /// Set wantEvaluate attribute.
    void setEvaluate(PVSSboolean yn = PVSS_TRUE) {evaluateAtOnce = yn;}

    /// Get the flag indicating whether the values in the answer message are required.
    PVSSboolean getWantAnswer() const { return evaluateAtOnce; }
    /// Set the flag indicating whether the values in the answer message are required.
    void setWantAnswer(PVSSboolean b) { evaluateAtOnce = b; }

    // Get the indication whether multiple answers are allowed
    PVSSboolean getMultipleAnswersAllowed() const { return multipleAnswersAllowed; }

  protected:
    /// Write the instance into the itcNdrUbSend stream.
    virtual void outNdrUb(itcNdrUbSend &ndrStream) const;
    /// Read the instance from the itcNdrUbReceive stream.
    virtual void inNdrUb(itcNdrUbReceive &ndrStream);

  private:
    static PVSSulong     nextIdentifier;

    MsgType              type;
    DpFilterActionType   actType;
    PVSSboolean          evaluateAtOnce;
    CharString           queryText;
    PVSSulong            identifier;
    
    // Flag whether multiple answers are allowed. Initialized in constructor.
    PVSSboolean multipleAnswersAllowed;


    friend class UNIT_TEST_FRIEND_CLASS;
};


#endif /* _DPMSGFILTERREQUEST_H_ */
