#ifndef _TLSCONTEXTHANDLER_H
#define _TLSCONTEXTHANDLER_H
//---------------------------------------------------------------------------- 
// Copyright (C) Siemens AG 2011. All Rights Reserved. Confidential. 
//---------------------------------------------------------------------------- 
// Descr.: Class definition of CertFileTLSContextHandler
//---------------------------------------------------------------------------- 

//#include "ItcPrelude.h"
#include <ITLSContextHandler.h>

#include <openssl/ssl.h>
#include <openssl/err.h>
#include <string>

class TLSContextIntern;
      
/**  
    @n This class is responsible for the secure data handling using SSL. It is derived from ITLSContextHandler, the virtual function descriptions can be read there.
    @classification public use
  */

class DLLEXP_BCM TLSContextHandler : public ITLSContextHandler
{

public:
    /// Simple constructor
    TLSContextHandler();

    /// Destructor
    virtual ~TLSContextHandler();

    virtual int close(int td) ;

    virtual int connect(int td, const sockaddr* sockAddr, size_t sizeOfSockAddr, int *errorNumber);
    virtual int accept(int td, int *new_td, sockaddr* sockAddr, int *addrLen, bool *blocking);
    virtual int accept2(int td, bool *blocking);

    virtual int read(int td, void *buff, int mlen, bool *tryAgain);
    virtual int send(int td, const void *buff, int len, bool *tryAgain);
    virtual int getPending(int td);
    virtual int setConnOptions ( int td, itcConnection::ConnOptions opt);
    virtual const char *getCipherSuite(int td);

    virtual void doBeforeSslHandshake() = 0;

    virtual void acquire();
    virtual bool release();
    
    /// General info about openSSL internal states
    static void apps_ssl_info_callback ( const SSL *s, int where, int ret );
 
protected:
    /// Receive debug message from openSSL library and forward it to the default debug routines.
    virtual void bioDebugPrint();

    /// Set dh params for the SSL_CTX from the given PEM file or certificate file,
    /// or use default params if the filename is empty or null.
    bool setDhParam( const char *paramFile, const char *certFile );

    /// Set the ECDH curve with the given name for the SSL_CTX,
    /// or use a default curve if the name is empty or null.
    bool setEcdhCurve( const char *curveName );

    /// Get the human readable error string from the last ssl error. Never return null pointer.
    static std::string GetLastSSLErrorStr();

    int verifyTime;
    SSL_CTX *ctx;
private:
  /// The private internal members are hidden behind this inherited class
  TLSContextIntern *pIntern;

  friend class UNIT_TEST_FRIEND_CLASS;

};

#endif
