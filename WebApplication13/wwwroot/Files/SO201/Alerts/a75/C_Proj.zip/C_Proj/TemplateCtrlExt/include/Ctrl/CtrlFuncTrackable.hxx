#ifndef _CtrlFuncTrackable_H_
#define _CtrlFuncTrackable_H_

// Qt trackable object (for QPointer<CtrlFuncTrackable>)
// which is not needed by customer API
// @classification ETM internal

#include <QObject>
class CtrlFunc;

class CtrlFuncTrackable : public QObject
{
  public:
    CtrlFuncTrackable(CtrlFunc *f) : func(f) { }
    CtrlFunc *func;
};

#endif
