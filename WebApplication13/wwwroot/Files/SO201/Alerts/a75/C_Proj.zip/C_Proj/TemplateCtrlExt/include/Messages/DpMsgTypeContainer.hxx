// DATEIBESCHREIBUNG ==============================================================
// DATEINAME:     DpMsgTypeContainer.hxx
// VERANTWORTUNG:  WOLFGANG SCHUH + PETER PENTEK
// 
// BESCHREIBUNG:  DpMsgTypeContainer verschickt den gesamten DpTypeContainer.
//     Besonders ist, dass die Daten direkt an der Message haengen
//     und keine MsgItems vorhanden sind.
//     
//     Diese Message wird nur zur Initialisierung eines Managers
//     benoetigt. Es gibt daher keine Antwortmessage.
//     
//     Diese Message hat keine Items.
//
// AENDERUNGS-HISTORIE
// Ver.  | Datum      | Aenderungen                            | ModNr.| Autor
// ------+------------+-----------------Anfang-----------------+-------+-----------
//   1.0 |            | 1.Erstellung mit Westmount-OMT         |     0 |
// ======================================Ende======================================
#ifndef _DPMSGTYPECONTAINER_H_
#define _DPMSGTYPECONTAINER_H_

// Vorwaerts-Deklaration der Eigenen Klasse
class DpMsgTypeContainer;

// System-Include-Files
#include <DpMsg.hxx>

// Vorwaerts-Deklarationen :
class DpMsgTypeContainer;
class DpTypeContainer;
class ManagerIdentifier;
class Msg;

class Blob;

/** DpMsgTypeContainer verschickt den gesamten DpTypeContainer.
//     Besonders ist, dass die Daten direkt an der Message haengen
//     und keine MsgItems vorhanden sind.
//     
//     Diese Message wird nur zur Initialisierung eines Managers
//     benoetigt. Es gibt daher keine Antwortmessage.
//     
//     Diese Message hat keine Items.
*/
class DLLEXP_MESSAGES DpMsgTypeContainer : public DpMsg 
{
  /// Friend class definition used in unit-tests.
  friend class UNIT_TEST_FRIEND_CLASS;
  friend class UNIT_TEST_FRIEND_CLASS2;

  /// Write the instance into the itcNdrUbSend stream.
  friend DLLEXP_MESSAGES itcNdrUbSend &operator<<(itcNdrUbSend &ndrStream, const DpMsgTypeContainer &dpMsg);
  /// Read the instance from the itcNdrUbReceive stream.
  friend DLLEXP_MESSAGES itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream, DpMsgTypeContainer &dpMsg);

  public:
    /// Internal flags.
    enum { 
      FLAG_TYPECONTAINER  = 0x01
    };

  private:
    enum
    {
      none = 0,
      zlib = 1,
      bzip = 2,
      last
    };
    
  public:
    /// Default constructor.
    DpMsgTypeContainer();
    /// Constructor.
    DpMsgTypeContainer(const DpMsgTypeContainer &newMsg);
    /// Constructor.
    DpMsgTypeContainer(const ManagerIdentifier &newDest);
    /// Destructor.
    ~DpMsgTypeContainer();

    // Operatoren :

    /// Comparison operator.
    int operator==(const DpMsgTypeContainer &rVal) const;
    /// Comparison operator.
    virtual int operator==(const Msg &rVal) const;
    /// Assignment operator.
    DpMsgTypeContainer &operator=(const DpMsgTypeContainer &rVal);
    /// Assignment operator.
    virtual Msg &operator=(const Msg &rVal);

    /** Assign the DpTypeContainer.
        Do not delete the pointer.
    */
    void setTypeContainer(DpTypeContainer *dpTypeContainerPtr);
    /// Assign the DpTypeContainer.
    void setTypeContainer(const DpTypeContainer &dpTypeContainer);
    /// Create new instance.
    virtual Msg *allocate() const;
    /// Check if own type matches other type.
    virtual MsgType isA(MsgType dpMsgType) const;
    /// Get own type.
    MsgType isA() const;
    /** Get number of groups.
        This always returns 1.
        */
    virtual PVSSulong getNrOfGroups() const {return 1;};

    /** Print the contents of the list to an output stream.   
      Level controls the amount of debug information printed and shall be > 0.
    */
    virtual void debug(std::ostream &to, int level) const;

    /// Get the assigned DpTypeContainer.
    const DpTypeContainer *getTypeContainer() const;
    /// Get the assigned DpTypeContainer.
    DpTypeContainer *getTypeContainer();
    
    /** Set message compression.
        @param type Name of the compression. Currently "zlib", "bzip2" and "zlib-bzip2" are supported.        
    */
    void setCompressionType(const char *type);

  protected:
    /// Write the instance into the itcNdrUbSend stream.
    virtual void outNdrUb(itcNdrUbSend &ndrStream) const;
    /// Read the instance from the itcNdrUbReceive stream.
    virtual void inNdrUb(itcNdrUbReceive &ndrStream);

  private:
    PVSSuchar        flags;
    DpTypeContainer *typeContainerPtr;

  private:
    // Caching of compressed data
    mutable Blob *compCache_;
    mutable int compType_;
    mutable size_t rawLen_;

};

// ================================================================================
// Inline-Funktionen :
inline const DpTypeContainer *DpMsgTypeContainer::getTypeContainer() const
{
  return typeContainerPtr;
}

inline DpTypeContainer *DpMsgTypeContainer::getTypeContainer()
{
  return typeContainerPtr;
}


#endif /* _DPMSGTYPECONTAINER_H_ */
