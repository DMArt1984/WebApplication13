#ifndef _PENDINPARAMS_H_
#define _PENDINPARAMS_H_


#include <PtrListItem.hxx>
class Variable;

#include <Allocator.hxx>

/*  author VERANTWORTUNG: Milos Marusiak */
/** class holds a Variable for later use as input to a CtrlThread.
*/
class DLLEXP_CTRL PendingParams : public PtrListItem
{
  public:
    /// create a Param holder
    PendingParams(const Variable *params);
    /// 
    ~PendingParams();

    AllocatorDecl;
    ///
    Variable *getArgs() const { return args; }

  protected:

  private:
    Variable *args;
};

#endif /* _PENDINPARAMS */
