/*
  Created by Zoltan Racz
*/

#ifndef _BCMDEBUG_H
#define _BCMDEBUG_H

#include <JCFPortConf.h>
#include <sstream>

//#define DO_NFR_DEBUG    // compile code for periodic NFR reports that is enabled with -dbg nfr is set 

namespace BcmError
{
  enum BcmErrorCode
  {
    // beware! the code values must be passed to the errClass
    
    /// 
    BCM_UNEXPECTEDSTATE = 54,
    
    /// (199) SSL wrapper init failed.
    BCM_INIT_SSL_WRAPPER_ERROR = 199,
    
    /// (200) Cert file error, the given values are failed at the initialization: ($1)
    BCM_INIT_CERT_FILES_ERROR = 200,
    
    /// (201) SSL library error. Problem with creating objects or calling functions. ($1)
    BCM_SSL_LIBRARY_ERROR = 201,			
    
    /// (202) Unknown error when creating SSL context.
    BCM_SSL_UNKNOWN_ERROR = 202,

      /// (206) Required SSL version : ($1)
    BCM_SSL_VERSION_MISMATCH = 206,

    /// (207) Cannot load SSL ($1) library.
    BCM_INIT_SSL_LOAD_LIBRARY_ERROR = 207,

    /// (208) Cannot load SSL function ($1).
    BCM_LOAD_SSL_FUNCTION_ERROR = 208,

    /// Could not find any certificat matching $1.
    BCM_ERR_WINCERT_NOMATCHING = 211,
    
    /// No valid certificate matching subject string ($1) found.
    BCM_ERR_WINCERT_NOVALIDBYSUBJECT = 212,
    
    /// Could not open certificate store <store>. + getLastError() fehlermeldung
    BCM_ERR_OPENSTORE = 213,
    
    /// Certificate with X509_ASN_ENCODING is required.
    BCM_ERR_REQ_X509 = 214,
    
    /// Private key for Certificate $1 is required
    BCM_ERR_CRYPT_ACQ = 215,
    
    /// Certificates $1 private key has to be exportable.
    BCM_ERR_CRYPT_EXPKEY = 216,
    
    /// Cipher $1 cannot be set.
    BCM_ERR_WRAP_CIPHER = 217,    

    /// Certificate $1 is expired.
    BCM_ERR_CERT_EXPIRED = 218,
    
    /// (219) Certificate $1 verification failed, due to: $2. 
    BCM_ERR_CERT_VERIFICATION_FAILED = 219
  };
  
  // taken from ErrClass ...
    
  /// error classification
  enum ErrType
  {
    /// implementation error
    ERR_IMPL,
    /// parametrisation error
    ERR_PARAM,
    /// system error
    ERR_SYSTEM,
    /// control runtime error
    ERR_CONTROL,
    /// redundancy error
    ERR_REDUNDANCY,
    // just a short name for "redundancy"
    ERR_REDU = ERR_REDUNDANCY
  };

  /// error priority
  enum ErrPrio
  {
    /// fatal error. kill the program instance!
    PRIO_FATAL,
    /// now obsolete
    PRIO_FATAL_NO_RESTART = PRIO_FATAL,
    /// severe error, but we can continue
    PRIO_SEVERE,
    /// warning message, something is not as it should be
    PRIO_WARNING,
    /// info message - hello, here I am!
    PRIO_INFO
  };

  /** flags for dbgLevel
  @n These flags can be set by number on cmdline. Numbers can
  be separated by , to get more flags, like -dbg 2,8,15.
  For API purposes there are constants DBG_API_USR1 to DBG_API_USR3,
  for ComDrv there are DBG_DRV_USR1 to DBG_DRV_USR3.
  */
  // this is a copy of the enum of Resources.hxx (libBasics)
  enum DbgFlags
  {
    // changes should be protocolled in dispatch as well
    /// (1). no time info will be printed on streams
    DBG_TIMEOFF = 1,
    /// (2). the general purpose debug flag; used for run info on current manager
    DBG_WORK = 2,
    /// (3). give warning when send buffer is extended
    DBG_EXTBUFFER = 3,
    /// (4). check sockets if input is ready
    DBG_INPUTREADY = 4,
    /// (5). check sockets if output is ready
    DBG_OUTPUTREADY = 5,
    /// (6). SND stamp;
    DBG_SNDSTAMP = 6,
    /// (7). BCV stamp
    DBG_RCVSTAMP = 7,
    /// (8). debug query actions
    DBG_QUERY = 8,
    /// (9). show manager heartbeat
    DBG_DISPATCH = 9,
    /// (10). first available API debug flag - use at your will
    DBG_API_USR1 = 10,
    /// (11). second available API debug flag - use at your will
    DBG_API_USR2 = 11,
    /// (12). third available API debug flag - use at your will
    DBG_API_USR3 = 12,
    /// (13). time
    DBG_DM_TIME = 13,
    /// (13). status function
    DBG_EV_STATFUNC = 13,
    /// (14). set temp. slot
    DBG_DM_SETEMPTYSLOT = 14,
    /// (15). service mode
    DBG_DM_SERVICEMODE = 15,
    /// (16). event work
    DBG_EV_WORK = 16,
    /// (17). event time 100
    DBG_EV_TIME100 = 17,
    /// (18). source time
    DBG_EV_SOURCETIME = 18, // XXX remove, wenn Systemzeitbeigabe geklaert ist!!!
    /// (19). event file
    DBG_EV_EVENTFILE = 19,
    /// (20). alert file
    DBG_EV_ALERTFILE = 20,
    /// (21). event main
    DBG_EV_EVMAIN = 21,
    /// (22). panel time
    DBG_UI_PANELTIME = 22,
    /// (23). show report manager actions (obsolete)
    DBG_UI_RENT = 23,
    /// (24). common DRV heartbeat - use
    DBG_DRV_WORK = 24,
    /// (25). first available DRV debug flag - use at your will
    DBG_DRV_USR1 = 25,
    /// (26). second available API debug flag - use at your will
    DBG_DRV_USR2 = 26,
    /// (27). third available API debug flag - use at your will
    DBG_DRV_USR3 = 27,
    /// (28). show redundancy messages
    DBG_REDUNDANCY = 28,      // redundancy messages
    /// (28). for people who can't write redundancy
    DBG_REDU = DBG_REDUNDANCY,
    /// (29). show ctrl trace
    DBG_CTRL_TRACE = 29,
    /// (30), show every n sec a snd/rcv statistic
    DBG_MSG_STATISTIC = 30,
    /// (31), extended Warnings   
    DBG_EXT_WARNING = 31,           // don't modify number BCM relies on it
    /// (32), use of old status
    DBG_STATUS32 = 32,
    /// (33), HTTP traffic
    DBG_HTTP = 33,
    /// (34), BCM                 
    DBG_BCM = 34,                 // don't modify number BCM relies on it
    /// (35), NFR outputs         
    DBG_NFR = 35,                 // don't modify number BCM relies on it
    // Must be last
    DBG_LAST
  };

}

typedef void ( *FuncBcmErrorPrint ) ( BcmError::ErrPrio errPrio, 
                                      BcmError::ErrType errType, 
                                      BcmError::BcmErrorCode bcmErrorCode, 
                                      const char *note1, 
                                      const char *note2);
                                      
typedef void ( *FuncBcmDebugPrint ) (int, const char *);


#define BCM_ERROR_PRINT(__errPrio__, __errType__, __bcmErrorCode__, __note1__, __note2__) \
{                                                                 \
  BcmDebug::AutoMutex lock;                                       \
  if (BcmDebug::pBcmErrorPrint) {                                 \
    std::stringstream localBuffer1;                               \
    localBuffer1 << __note1__;     \
    std::stringstream localBuffer2;                               \
    localBuffer2 << __note2__;     \
    if (strlen(localBuffer2.str().c_str()) != 0) { BcmDebug::pBcmErrorPrint( __errPrio__, __errType__, __bcmErrorCode__, localBuffer1.str().c_str(), localBuffer2.str().c_str() ); }\
    else { BcmDebug::pBcmErrorPrint( __errPrio__, __errType__, __bcmErrorCode__, localBuffer1.str().c_str(), 0 );  }\
  }                                                                                   \
}


#define BCM_DEBUG_PRINT(__msg__)                                  \
{                                                                 \
  BcmDebug::AutoMutex lock;                                       \
  if (BcmDebug::pBcmDebugPrint) {                                 \
    std::stringstream localBuffer;                                \
    localBuffer << __msg__;                                       \
    BcmDebug::pBcmDebugPrint(BcmError::DBG_BCM, localBuffer.str().c_str());          \
  }                                                               \
}


#define NFR_DEBUG_PRINT(__msg__)                                  \
{                                                                 \
  BcmDebug::AutoMutex lock;                                       \
  if (BcmDebug::pBcmDebugPrint) {                                 \
    std::stringstream localBuffer;                                \
    localBuffer << __msg__;                                       \
    BcmDebug::pBcmDebugPrint(BcmError::DBG_NFR, localBuffer.str().c_str());          \
  }                                                               \
}

/*
 * General wrapper for diagnose protocol of BCM library
 */

class DLLEXP_BCM BcmDebug
{
  public:
    class AutoMutex
    {
      public:
        AutoMutex();
        ~AutoMutex();
    };
    
  public:
    // pointer to a void function, that has to run as a error print function
    static FuncBcmErrorPrint pBcmErrorPrint;

    // pointer to a void function, that has to run as a debug print function
    static FuncBcmDebugPrint pBcmDebugPrint;
  
    // ERROR HANDLING
    static void initBcmErrorPrint ( const FuncBcmErrorPrint pFunc );

    // DEBUG HANDLING  
    // Set a function pointer for debug prints, if any function is given BCM won't protokoll diagnose issues.
    static void initBcmDebugPrint ( const FuncBcmDebugPrint pFunc );
};

#endif // _BCMDEBUG_H
