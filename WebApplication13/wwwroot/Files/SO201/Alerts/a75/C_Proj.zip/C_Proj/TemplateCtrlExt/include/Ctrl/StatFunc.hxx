#ifndef _STATFUNC_H_
#define _STATFUNC_H_

#include <CtrlModule.hxx>
#include <DpIdentifier.hxx>
#include <DpIdentList.hxx>
#include <DpIdValueList.hxx>
#include <TimeVar.hxx>
#include <DynVar.hxx>
#include <TextVar.hxx>
#include <Bit32Var.hxx>
#include <IntegerVar.hxx>
#include <UIntegerVar.hxx>
#include <CharString.hxx>

#include <BaseAccu.hxx>
#include <PeriodAccu.hxx>
#include <PeriodGenerator.hxx>
#include <TimeBitStateAccu.hxx>
#include <ExternData.hxx>

#include <AnswerGroup.hxx>
#include <QLinkedList>

class AnswerItem;
class SFKWaitForAnswer;
class TimeBitFloatAccu;

// Zaehler, der die Anzahl der Stat-Funcs, die auf dieselben Pointer zugreifen,
// im Griff behaelt
class StatFuncCounter
{
  public:
    StatFuncCounter() : counter_( 1 )  { }
    virtual ~StatFuncCounter() {};

    virtual PVSSushort operator++() { return( ++counter_ ); }
    virtual PVSSushort operator--() { return( --counter_ ); }

  private:
    // so that the compiler does not define them itself !!
    // assignment operator
    StatFuncCounter &operator=(const StatFuncCounter &) { return *this; }

    // copy constructor - is used for 2nd object (historical period)
    StatFuncCounter( StatFuncCounter & ) {};

    // Member
    PVSSushort counter_;
};

/*  author VERANTWORTUNG: Heinz MEISSL                                 */
/** cumulate statistic information on specific datapoints */
class DLLEXP_CTRL StatFunc : public CtrlModule
{
  public:

    /** Erstelle eine Statistische Funktion.
      * @param fromScript IN:
      * @param aWorkFunk IN:
      * @param aInterval IN:
      * @param aDayTime  IN:
      * @param aWeekDay  IN:
      * @param aMonthDay IN:
      * @param aMonth    IN:
      * @param aDelay    IN:
      * @param aDpNameArray        IN:
      * @param aStatFuncTypeArray  IN:
      * @param readArchive         IN:
      */
    StatFunc( CtrlScript *fromScript,
              const CharString &aWorkFunc,
              const UIntegerVar &aInterval,
              const IntegerVar &aDayTime,
              const IntegerVar &aWeekDay,
              const IntegerVar &aMonthDay,
              const IntegerVar &aMonth,
              const UIntegerVar &aDelay,
              const DynVar &aDpNameArray,
              const DynVar &aStatFuncTypeArray,
              PVSSboolean readArchive = PVSS_TRUE );

    /** Erstelle eine Statistische Funktion.
      * @param fromScript IN:
      * @param extData    IN:
      * @param dpResult   IN:
      * @param intermRes  IN:
      * @param intermInterval IN:
      * @param aWorkFunk IN:
      * @param aInterval IN:
      * @param aDayTime  IN:
      * @param aWeekDay  IN:
      * @param aMonthDay IN:
      * @param aMonth    IN:
      * @param aDelay    IN:
      * @param readArchive         IN:
      * @param func      IN: f�r jedes Bit der statFuncModus
      * @param limit     IN: f�r jedes Bit die Schwelle 0..100
                             (Prozent des Intervalles die das Bit gesetzt sein muss)
                             ab der func an das Ergebnis weitergegeben wird
                             -1 func wird nie weitergegeben
      * @param aDpNameArray        IN:
      * @param aStatFuncTypeArray  IN:
      */
    StatFunc( CtrlScript  *fromScript,
              const ExternData *extData,
              const TextVar     &dpResult,
              const PVSSboolean intermRes,
              const UIntegerVar &intermInterval,
              const CharString  &aWorkFunc,
              const UIntegerVar &aInterval,
              const IntegerVar  &aDayTime,
              const IntegerVar  &aWeekDay,
              const IntegerVar  &aMonthDay,
              const IntegerVar  &aMonth,
              const UIntegerVar &aDelay,
              PVSSboolean       readArchive,
              const int         func[],
              const int         limit[],
              const DynVar      &aDpNameArray,
              const DynVar      &aStatFuncTypeArray);

    /** Erstelle eine Statistische Funktion.
      * @param fromScript IN:
      * @param extData    IN:
      * @param dpResult   IN:
      * @param intermRes  IN:
      * @param intermInterval IN:
      * @param aWorkFunk IN:
      * @param aInterval IN:
      * @param aDayTime  IN:
      * @param aWeekDay  IN:
      * @param aMonthDay IN:
      * @param aMonth    IN:
      * @param aDelay    IN:
      * @param readArchive         IN:
      * @param func      IN: f�r jedes Bit der statFuncModus
      * @param limit     IN: f�r jedes Bit die Schwelle 0..100
                             (Prozent des Intervalles die das Bit gesetzt sein muss)
                             ab der func an das Ergebnis weitergegeben wird
                             -1 func wird nie weitergegeben
      * @param aDpNameArray        IN:
      * @param aStatFuncTypeArray  IN:
      */
    StatFunc( CtrlScript  *fromScript,
              const ExternData *extData,
              const TextVar     &dpResult,
              const PVSSboolean intermRes,
              const UIntegerVar &intermInterval,
              const CharString  &aWorkFunc,
              const UIntegerVar &aInterval,
              const IntegerVar  &aDayTime,
              const IntegerVar  &aWeekDay,
              const IntegerVar  &aMonthDay,
              const IntegerVar  &aMonth,
              const UIntegerVar &aDelay,
              PVSSboolean       readArchive,
              const int         func[],
              const int         limit[],
              const DynVar      &aDpNameArray,
              const DynVar      &aStatFuncTypeArray,
              PVSSboolean       delExternData);
    ///

    ~StatFunc();

    enum statFuncModus
    {
      IGNORE_BITS,           // Status-Bits werden nicht beruecksichtigt
      IGNORE_VALUE,          // Wenn eines der relevanten Status-Bits gesetzt ist
                             //   wird der Wert ignoriert
      IGNORE_VALUE_TIME,     // Wenn eines der relevanten Status-Bits gesetzt ist
                             //   wird der Wert ignoriert und der Zeitraum fuer die
                             //   Berechnung gekuerzt.
      TRANSFER_BITS          // Ab der eingestellten Schwelle wird das ensprechende Bit
                             //   uebertragen, der Wert wird nicht beruehrt
      // Ende-Kriterium: TRANSFER_BITS (siehe Implementierung)
    };


    enum statFuncConfig
    {
      DEFAULT = 0,
      USER1,
      USER2,
      USER3,
      USER4,
      USER5,
      USER6,
      USER7,
      USER8,
      INVALID             // muss das letzte Element des enum bleiben!!!
    };

    enum statFuncCorrStatus     // sagt, ob waehrend der laufenden Periode
    {                           // ein Korrekturwert gekommen ist
      DEFAULT_KORR = 0,
      INVALID_KORR
    };

    virtual ExecReturn start();
    /// Wann soll der thread das naechste mal gettstartet werden
    virtual const TimeVar &nextWork() const;

    /** Statistische Funktion ausfuehren
      * @return EXEC_OK, EXEC_DONE, EXEC_ERROR
      */
    virtual ExecReturn work(PVSSlong micro);

    /** ein Hotlink ist eingetroffen */
    virtual void dpValueChanged(const DpHLGroup &dpGroup);
    /** ein Hotlink mit Korrekturwert ist eingetroffen */
    virtual void dpCorrValueChanged(const DpHLGroup &dpGroup);

    /** antwort auf eine Anmeldung ist eingetroffen.*/
    virtual void handleAnswer(DpMsgAnswer &answer, int clientData);

    // IM 66276 - Redu Erweiterung
    static void setSwitchedActive() { switchedActive_ = true; };
    static void resetSwitchedActive() { switchedActive_ = false; };

  protected:

  private:
    // so that the compiler does not define them itself !!

    // assignment operator
    StatFunc &operator=(const StatFunc &) { return *this; }

    // copy constructor - is used for 2nd object (historical period)
    StatFunc( StatFunc &tf);
    // append DpName-String to DpList for calling DpConnect()
    PVSSboolean appendDP(const CharString &name);
    // check parameters  received with constructor for validity
    PVSSboolean checkInput();
    BaseAccu *newStatAccu(const IntegerVar &aAccuType, const VariableType aVarType, const TimeVar at);
    SimpleAccu *newSimpleAccu(const IntegerVar &aAccuType, const VariableType aVarType, PeriodAccu::AccuMode &aMode );
    const TimeVar getPeriodStart();
    const TimeVar getPeriodStop();

    TimeVar delayedStartTime;

    // don't store a pointer to CtrlScript, because if we re-read the script,
    // the pointer is invalid
    CharString myWorkFunc;

    // delay the time to activate the CtrlScript
    PVSSulong delay;

    // the DPs to observe as given to constructor
    DynVar dpNameArray;
    // the kind of observation, related to dpNameArray
    DynVar statTypeArray;
    // the dpIds according to dpNameArray
    DpIdentList dpIdList;
    // statistic Accumulators for the Dps to observe, according to dpNameArray
    BaseAccu **statAccuTbl;

    // list of the DP-attributes to connect (difference to dpIdList: unique list!)
    DpIdentList dpUniqueIdList;
    // Pointers to WaitForAnswer-Objects, related to dpUniqueIdList
    CMWaitForAnswer *waitObj_;

    DpIdentList **ConnTbl;

    PVSSushort dpCount,
             accuCount;

    PeriodGenerator *myPeriodGenerator;

    PeriodGenerator *NewPeriodGenerator(
       const TimeVar now,
       const IntegerVar aMonth,
       const IntegerVar aMonthDay,
       const IntegerVar aWeekDay,
       const IntegerVar aDayTime,
       const UIntegerVar aInterval );

    void StatFuncConstr(const int *func,
                        const int *limit,
                        const TextVar &dpResult);

    // extStatFunc
    void StatFuncInit( CtrlScript *fromScript,
              const CharString &aWorkFunc,
              const UIntegerVar &aInterval,
              const IntegerVar &aDayTime,
              const IntegerVar &aWeekDay,
              const IntegerVar &aMonthDay,
              const IntegerVar &aMonth,
              const UIntegerVar &aDelay,
              const DynVar &aDpNameArray,
              const DynVar &aStatFuncTypeArray,
              PVSSboolean readArchive );

    void StatFuncCorrInit( const StatFunc &orig, const TimeVar &at );

    // Ueberpruefung, welcher der Werte oder ob beide Werte (online und korrektur) geschickt werden
    void checkResAndDoDpSetTimed(TimeVar &, DpIdValueList &);

    // gibt es im aktuellen Intervall eine g�ltige History?
    // sonst muss ich das Intervall r�ckstellen und ein neues dpGetPeriod aufrufen
    // (und den Code hier �berspringen)
    PVSSboolean isValidHistInActInterval( DpMsgAnswer &answer );

    //------------------------------------------------------------------------------
    inline bool isExtStatFunc() { return(myLimit != 0); }
    statFuncModus myStatusBitCheck(const Bit32Var &status, const TimeVar &tim);
    statFuncModus myStatusBitReset(const Bit32Var &status, const TimeVar &tim);
    statFuncModus myStatusBitAccumulate(const Bit32Var &status, const TimeVar &tim);
    void setResult(TimeVar &periodStart, time_t periode, DpIdentifier &dp, Variable &result);
    void setIntermResult(const TimeVar &now);

    //------------------------------------------------------------------------------
    ExecReturn execCtrlWorkFunc(
      TimeVar &periodStart,
      TimeVar &periodStop,
      DpIdentifier &dp,
      time_t periode);

    PVSSboolean myIntermRes;            // Zwischenwerte?
    UIntegerVar myIntermInterval;       // wenn ja: das Intervall

    Bit32Var *myLastStatus;
    Bit32Var myLastStatusResult;
    // TimeBitStateAccu *myBitOnTime[INVALID+1];
    TimeBitFloatAccu *myBitOnTime;
    DpAttributeNrType myAttr[INVALID+1];
    int myFunc[INVALID+1];
    int *myLimit;

    VariableType myDpResultVarType;
    DpIdentifier myDpResult_wert;
    DpIdentifier myDpResult_status;
    DpIdentifier myDpResult_zwischen;
    DpIdentifier myDpResult_aut_inv;

    PVSSboolean delClientData;
    const ExternData *clientData;

    // Eintraege fuer die Erweiterung auf Korrekturwerte
    PVSSboolean amCorrObject_;
    PVSSboolean haveCorrValues_;
    statFuncCorrStatus corrStatus;        // Korrekturwert in der laufenden Periode?
    UIntegerVar interval_;
    IntegerVar dayTime_;
    IntegerVar weekDay_;
    IntegerVar monthDay_;
    IntegerVar month_;
    StatFuncCounter *corrCntr_;             // laeuft gerade ein dpGetPeriod?

    DpIdValueList saveDpIdList_;
    TimeVar saveTime_;                    // im 2nd obj merken, bis Ergebnis da ist
    TimeVar corrEventTimeMin_;               // wann kam der Hotlink?
    TimeVar corrEventTimeMax_;

    PVSSboolean delayedCalc_;             // verzoegerte Berechnung aufgrund der Hotlinks, nicht der Intervalle
    PVSSboolean floatingCalc_;            // TI 17326 gleitende Berechnung

    // IM 66276: Erweiterung fuer Redu in 3.5
    // IM 66276: Redu-Erweiterung fuer Acknowledge
    static PVSSboolean switchedActive_;

    virtual void ackReduResult( const TimeVar& time );  // Hotlink sent for acknowledge
    virtual PVSSboolean storeReduResult();              // do a dpSet with the last result whatever
    // wie Manager::dpSetTimed(), stellt gleichzeitig die Daten ein (saveReduDpIdList,saveReduTime)
    virtual void dpSetTimedReduSave( const TimeVar &periodStart, const DpIdValueList &valueList );

    DpIdValueList saveReduDpIdList_;   // Werte bis zum Acknowledge merken; Liste ist leer, wenn der HL zuerst gekommen ist
    TimeVar saveReduTime_;             // Zeit des letzten HL oder Wertes
    PVSSboolean readArchive_;          // Ende der Initialisierung

    QLinkedList<AnswerGroup> discValueBuffer;
    TimeVar firstHLTime_;              // IM 114248 needed for delayedCalc resume loop
};

// Klasse zur Kapselung der TimeBitAccus, die im gleitenden Betrieb doppelt indiziert werden muessen
class TimeBitFloatAccu
{
public:
  TimeBitFloatAccu( int count );

  virtual ~TimeBitFloatAccu();

  void reset( int lim );
  void accumulate( int, const BitVar &var, const TimeVar &tim );

  TimeBitStateAccu *getActAccu( int lim );
  void addAccu( int lim );
  PVSSboolean isNotNull( int lim );

private:

  // so that the compiler does not define them itself !!
  TimeBitFloatAccu( ) {};
  // assignment operator
  // virtual TimeBitFloatAccu &operator=(const TimeBitFloatAccu &) = 0;

  TimeBitStateAccu *(*accuPtr_)[StatFunc::INVALID + 1];
  int count_;     // Anzahl paralleler gleitender StateAccus
  int actAccu_;
};


// --------------------------------------------------------------------------------

// ****************************************************************************
inline void TimeBitFloatAccu::reset( int lim )
{
  accuPtr_[actAccu_][lim]->reset();
  actAccu_ = (actAccu_ + 1) % count_;

  return;
}

inline void TimeBitFloatAccu::accumulate  ( int lim, const BitVar &bit, const TimeVar &tim )
{
  for (int i = 0; i < count_; i++)
    accuPtr_[i][lim]->accumulate( bit, tim );
  return;
}

inline TimeBitStateAccu *TimeBitFloatAccu::getActAccu  ( int lim )
{
  return (accuPtr_[actAccu_][lim] );
}

inline void TimeBitFloatAccu::addAccu ( int lim )
{
  for (int i = 0; i < count_; i++)
    accuPtr_[i][lim] = new TimeBitStateAccu(PVSS_TRUE);

  return;
}

inline PVSSboolean TimeBitFloatAccu::isNotNull ( int lim )
{
  // da sind alle gleich
  return (accuPtr_[0][lim] != 0);
}

#endif /* _STATFUNC_H_ */
