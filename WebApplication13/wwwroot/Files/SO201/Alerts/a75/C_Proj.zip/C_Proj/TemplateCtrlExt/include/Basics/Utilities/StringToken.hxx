#ifndef _STRINGTOKEN_H_
#define _STRINGTOKEN_H_

/*
VERANTWORTUNG: Andreas Pfluegl
BESCHREIBUNG: 
*/

#ifndef _CHARSTRING_H_
#include <CharString.hxx>
#endif

#ifndef _CODEPOINT_ITERATOR_H_
#include <CodepointIterator.hxx>
#endif

/** The StringToken class breaks a string in a token separated by the given separator.
  * You can Iterate over the string with the methods getFirst() and getNext().
  * The string is not copied into the Iterator, so you must not modify the string while 
  * you iterate on it.
  * 
  * @classification public use, derive
  */
class DLLEXP_BASICS StringToken
{
  public:
    
    /* Empty constructor.
     */
    StringToken() : string_(0), len_(0), separator_(0UL), lastRead_(0UL), currentPos_("") {}
    
    /** Create an object that splits a string into a token.
      * The input string will not be modified.
      * @param str  IN       : string that will be splitted.
      *             @n str == 0 : getFirst or getNext returns a string containing only the separator.
      *             @n str == "": getFirst or getNext returning a string containing only the separator. 
      * @param separator Separator character.
      */
    StringToken(const char *str, Codepoint separator);

    /** Create a object that splits a string into a token. The input string will not be modified.
      * @param str       IN, string that will be splitted.
      * @param separator IN, separator character. 
      */
    StringToken(const CharString &str, Codepoint separator);

    /** Initializes the instance with the new values.
      * @param str        IN, string that will be split.
      * @param sep        IN, separator character.       
      */
    void init(const char *str, Codepoint sep);

    /** Get the first token of the string.
      * @return - The first token (the subset of the string before the first separator).
      *          @n - A string only containing the separator 
      *               to identify we have reached the end of the string.
      *          @n - A whole string, if the string does not contain the separator.
      *          @n - Empty string, if the first character is the separator.
      */
    CharString getFirst();

    /** Get the next token of the string.
      * @return -  The next token.
      *           @n - A string only containing the separator 
      *             to identify we have reached the end of the string.
      *           @n - A CharString("") if the last char is the separator
      *             and you have reached this token.
      */
    CharString getNext();

    /** get the next to be scanned character.
      * @return -  The next character in the string to be checked, which can be 0
      */
    char getNextChar() const;

    /** get the next to be scanned code point.
      * @return -  The next character in the string to be checked, which can be 0
      */
    Codepoint getNextCodepoint() const;

    /** Get the current position of the tokenizer in the given string.
        This is the position of the next to be checked character (at next getNext() call)
      * @return -  The current position in the string
      */
    size_t getCurrentPos() const { return currentPos_.byteIndex(); }

    /** Advance the next to be checked position to the given character.
      * @param pos  is checked against valid range
      */
    void setCurrentPos(size_t pos);

  private:
    const char *string_;
    size_t len_;
    Codepoint separator_;
    Codepoint lastRead_;
    CodepointIterator currentPos_;
};

#endif /* _STRINGTOKEN_H_ */
