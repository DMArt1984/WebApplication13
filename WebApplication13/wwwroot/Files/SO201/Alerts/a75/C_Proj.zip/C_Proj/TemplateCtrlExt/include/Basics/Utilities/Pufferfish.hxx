#ifndef  _PUFFERFISH_H_
#define  _PUFFERFISH_H_

//COVINFO FILE: debug (AP: class used only for testing)

#define THANKS_FOR_ALL_THE_FISH //if not defined the fish will not inflate
#define FISH_SIZE_LEN   1048572 // = 1024*1024 - 4 = 1MB - 4 //4Bytes needed for dataLen in every blob

#include <stdlib.h>
#include <NewHandler.hxx>
#include <OaNoPosix.hxx>
#include <SimplePtrArray.hxx>
#include <Blob.hxx>

/** The pufferfish class is used to make an process really fat.
 *  It is mainly used for testing, and hopefully nothing else.
 *  Happy fishing!
 */

class Pufferfish
{
  public:
    /**
     * constructor for creating a new pufferfish
     */
    Pufferfish() {}

    /**
     * constructor for creating a new pufferfish
     * that reads from an environmentvar how much it should inflate
     * if the var does not exist, the pufferfish will not inflate
     * do not infalte to much - if the process eats to much, it may get sick *g*
     * we defined a infaltion maximum of 4000MBs
     * @param envvar the name of the environmentvar
     */
    Pufferfish(const char* envvar);

    /**
     * constructor for creating a new pufferfish
     * that automatically will inflate the fish to the given amount
     * @param size the inflation amount in MBs
     * do not infalte to much - if the process eats to much, it may get sick *g*
     * we defined a infaltion maximum of 4000MBs
     */
    Pufferfish(unsigned int size) {inflate(size);}

    /**
     * if the pufferfish is deleted, it deflates automatically
     */
    ~Pufferfish() {deflate();}

    /**
     * function to inflate the fish
     * @param size the inflation amount in MBs     
     */
    void inflate(unsigned int size);

    /**
     * function to deflate the fish
     */
    void deflate();

  private:

    /// storage of the content
    SimplePtrArray<Blob> blub;
};

Pufferfish::Pufferfish(const char* envvar)
{
#ifdef THANKS_FOR_ALL_THE_FISH
  CharString buffer;
  char *var = OaNoPosix::getenv(envvar, buffer);

  if (var) //if no var do not inflate
     inflate(atoi(var));
#endif
}

void Pufferfish::inflate(unsigned int size)
{
#ifdef THANKS_FOR_ALL_THE_FISH
  int i = 0;
  bool currentState;

  if (size <= 0)
    return;

  if (size > 4000) //max. 4000 MBs
    size = 4000;

  std::cout << "Pufferfish tries to inflate up to " << size << " mega bites!" << std::endl;

  PVSSuchar *pOneElem = new PVSSuchar[FISH_SIZE_LEN];

  for (i = 0; i < FISH_SIZE_LEN; ++i)
    pOneElem[i] = 'x';

  // disable PVSS allocator
  Allocator::enableAllocator(false);

  // do not exit if no mem!
  currentState = NewHandler::_exitOnNoMem;
  NewHandler::_exitOnNoMem = false;

  blub.clear();

  for (i = 0; i < static_cast<int>(size); ++i)
  {
    try
    {
      blub.append(new Blob(pOneElem, FISH_SIZE_LEN, PVSS_TRUE));
    }
    catch(std::bad_alloc)
    {
      std::cout << "Pufferfish cannot inflate more than " << (i-1) << " mega bites!" << std::endl;
      size = (i-1);

      break;
    }
  }

  std::cout << "Pufferfish has inflated to " << size << " mega bites!" << std::endl;

  // enable PVSS allocator
  Allocator::enableAllocator(true);

  // now you are allowed to exit again ;-)
  NewHandler::_exitOnNoMem = currentState;

  delete [] pOneElem;
#endif
}

void Pufferfish::deflate()
{
#ifdef THANKS_FOR_ALL_THE_FISH
  // disable PVSS allocator

  if (blub.getNumberOfItems() <= 0) //nothing to deflate
    return;

  Allocator::enableAllocator(false);

  blub.clear();

  std::cout << "Pufferfish has successfully deflated!" << std::endl;

  // enable PVSS allocator
  Allocator::enableAllocator(true);
#endif
}

#endif
