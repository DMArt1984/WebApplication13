// DATEIBESCHREIBUNG ==============================================================
// DATEINAME:     DpMsg.hxx
// VERANTWORTUNG:	Gerhard Fellrieser
// 
// BESCHREIBUNG:	Diese Nachricht wird zum Datenaustausch bezueglich Datenpunkte
// 		verwendet und dient als Basisklasse fuer alle speziellen
// 		Datenpunk-Messages. Es koennen aber nur die speziellen
// 		Dp-Messages verschickt werden.
// 		
// 		Die Aufteilung in verschiedene DpMessages (DpMsgHotLink, 
// 		DpMsgRequest, ...) hat folgenden Grundgedanken:
// 		
// 			Es sollen Meldungen mit einheitlichen Inhalten
// 			verschickt werden, um deren Verarbeitung zu 
// 			vereinfachen oder zu ermoeglichen. In eine 
// 			DpMsgConnection-Message koennen auch nur dessen 
// 			zugehoerige Meldungen eingehaengt werden und 
// 			z. B. keine Request-Meldung.	
//
// AENDERUNGS-HISTORIE
// Ver.  | Datum      | Aenderungen                            | ModNr.| Autor
// ------+------------+-----------------Anfang-----------------+-------+-----------
//   1.0 |            | 1.Erstellung mit Westmount-OMT         |     0 |
// ======================================Ende======================================
#ifndef _DPMSG_H_
#define _DPMSG_H_

// Vorwaerts-Deklaration der Eigenen Klasse
class DpMsg;

// System-Include-Files
#include <Msg.hxx>
#include <DpIdentifier.hxx>

// Vorwaerts-Deklarationen :
class DpMsg;
class ManagerIdentifier;

// ========== DpMsg ============================================================
/** The base class for all datapoint messages. This message is used to exchange 
  information regarding datapoints between managers.
 */
class DLLEXP_MESSAGES DpMsg : public Msg 
{
    // Operatoren :

    /// overloaded operator << with itcNdrUbSend-stream, derived from class Msg 
    friend DLLEXP_MESSAGES itcNdrUbSend &operator<<(itcNdrUbSend &ndrStream, const DpMsg &dpMsg);

    /// overloaded operator >> with itcNdrUbReceive-stream, derived from class Msg 
    friend DLLEXP_MESSAGES itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream, DpMsg &dpMsg);

  public:
    /// Default constructor
    DpMsg();
    /// Copy constructor
    DpMsg(const DpMsg &newMsg);
    /// Destructor
    virtual ~DpMsg();

    /// compare operator == with Msg
    /// subclass must call this method when overriding it
    virtual int operator==(const Msg &rVal) const;

    /// compare operator == with DpMsg
    int operator==(const DpMsg &rVal) const;

    /// assignment operator = with Msg
    /// subclass must call this method when overriding it
    virtual Msg &operator=(const Msg &rVal);

    /// assignment operator = with DpMsg
    DpMsg &operator=(const DpMsg &rVal);

    /// The debug functions.
    /// subclass must call this method when overriding it
    /// @return the name of the DpMsg as a string
    virtual const char *getMsgName() const;

    // Spezielle Methoden :
    /// allocate for messages DP_MSG, DP_MSG_CONNECTION, DP_MSG_ALERT and DP_MSG_VALUECHANGE not allowed
    /// all other DP-messages are allowed
    /// @return a message given by the message type
    static DpMsg *allocate(MsgType dpMsgType);

    /** Check if the message is of a given type or is a derived type. 
        @return dpMsgType if the type matches, else NO_MSG
     */
    virtual MsgType isA(MsgType dpMsgType) const;

    /// @return message type.
    virtual MsgType isA() const;

    /** Return the number of groups in this message.
        Most DpMsg have their data organized in groups. All groups are independent from each other
        and are put in one message only to minimize the transport overhead.
     */
    PVSSulong getNumberOfGroups() const {return getNrOfGroups();}

    /** Return the number of groups in this message.
        Most DpMsg have their data organized in groups. All groups are independent from each other
        and are put in one message only to minimize the transport overhead.
     */
    virtual PVSSulong getNrOfGroups() const = 0;

    /// will be needed for AnswerHandler::sendMsgWaitingForAnswer()
    /// and returns the first DpIdentifier in the group
    /// @return DpIdentifier of DpMsg
    virtual DpIdentifier getGroupId(PVSSulong) const {return DpIdentifier();};

  protected:
    /// constructor DpMsg via ManagerIdentifier
    /// @param newDestination will be passed through Msg constructor
    DpMsg(const ManagerIdentifier &newDestination);

    /// outNdrUb sends message to stream
    /// subclass must call this method when overriding it
    virtual void outNdrUb(itcNdrUbSend &ndrStream) const;

    /// inNdrUb gets message from stream
    /// subclass must call this method when overriding it
    virtual void inNdrUb(itcNdrUbReceive &ndrStream);

    friend class UNIT_TEST_FRIEND_CLASS;
    friend class UNIT_TEST_FRIEND_CLASS2;
};

#endif /* _DPMSG_H_ */
