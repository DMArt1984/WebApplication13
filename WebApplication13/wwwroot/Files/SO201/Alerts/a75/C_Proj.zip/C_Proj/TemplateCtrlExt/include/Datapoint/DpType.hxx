// DATEIBESCHREIBUNG ==============================================================
// DATEINAME:     DpType.hxx
// VERANTWORTUNG: Stanislav Meduna
//
// BESCHREIBUNG:  Typ eines Datenpunkts.
//
//                Diese Klasse speichert die Baumstruktur des Datenpunkt-Typs.
//          Der Typ wird intern als ein AVL-Baum von DpTypeNodes
//          realisiert. Die Klasse bietet folgende Methoden an:
//
//          - Parametrierung
//            - Freies DpElementId allokieren (allocateNewElId)
//                  - Nodeeinfuegung (addNode)
//            - Setzen des Names und Root-Ids (setName, setRootElement)
//
//          - Konsistenzpruefung (isConsistent)
//
//          - Finden des Root-Elements und beliebiges Elements
//            nach seinem Nummer - ein Zeiger zum DpTypeNode
//            wird zurueckgeliefert (getRootTypeNodePtr,
//      getTypeNodePtr)
//
//          - Finden der Id-s der Root-, Vater- und Sohn-Elementen
//            (getRootElement, getFather, getSon)
//
//          - Finden des Sohnanzahls (getSonNumber)
//
//
//          Der Typ macht immer eine Kopie des Knotens.
//
//          Es ist nicht moeglich ein Knoten zu loeschen. Der
//                einzige Weg ist ganzen Typ zu loeschen und neu
//                parametrieren. Anders ist die Konsistenz der Daten
//                schwer zu sichern.
//
// BEMERKUNG:     Zwei private Attributen sind definiert, die nur
//                von friends (Datenbank) gesetzt werden koennen.
//
//          versionNr wird beim Aendern des Types ueberprueft -
//                    wenn zwei Managers den Typ gleichzeitig
//        aendern, wird die spaetere Aenderung
//        nicht bearbeitet
//
//     firstFreeElId
//              speichert das erste DpElementId, die in
//        diesem Typ nie verwendet war. Neue
//        Knoten muessen die Funktion allocateNewElId
//        verwenden um eine gueltige Identifizierung
//        zu kriegen. addNode ueberprueft das
//        nicht (um die Reihenfolge der Aenderung
//        beliebig zu lassen)
//
//
// AENDERUNGS-HISTORIE
// Ver.  | Datum      | Aenderungen                            | ModNr.| Autor
// ------+------------+-----------------Anfang-----------------+-------+-----------
//   1.0 |            | 1.Erstellung mit Westmount-OMT         |     0 |
// ======================================Ende======================================
#ifndef _DPTYPE_H_
#define _DPTYPE_H_

// Vorwaerts-Deklaration der Eigenen Klasse
class DpType;

#ifndef  _DPTYPES_H_
#include <DpTypes.hxx>
#endif

#ifndef  _DPTYPENODE_H_
#include <DpTypeNode.hxx>
#endif

#ifndef  _DYNPTRARRAY_H_
#include <DynPtrArray.hxx>
#endif

#include <ostream>

class itcNdrUbSend;
class itcNdrUbReceive;

// Vorwaerts-Deklarationen :
class DpType;

typedef  DynPtrArray<DpTypeNode>  DpTypeNodeList;

/// Containers for forward and backward type references
class DLLEXP_DATAPOINT TypeRefStr
{
public:
  /// Element type.
  DpTypeId    typeNr;
  /// Element ID.
  DpElementId elNr;

  /// Compare references.
  static int cmp(const TypeRefStr *item1Ptr, const TypeRefStr *item2Ptr);
};

#ifdef WIN32
#pragma warning ( disable: 4231 )
#endif

#if defined(LIBS_AS_DLL)
EXTERN_DATAPOINT template class DLLEXP_DATAPOINT DynPtrArray<DpTypeNode>;
EXTERN_DATAPOINT template class DLLEXP_DATAPOINT DynPtrArray<TypeRefStr>;
EXTERN_DATAPOINT template class DLLEXP_DATAPOINT DynPtrArray<DpElementId>;
#endif

#ifdef WIN32
#pragma warning ( default: 4231 )
#endif

/** DpType class represents complex type.
    Complex type consist of simple value types (e.g. DPELEMENT_ARRAY, DPELEMENT_BIT, DPELEMENT_FLOAT, ...) and also can contain the reference to other complex type.
    This class saves the tree structure of datapoints types. The type is internally implemented as an AVL-Tree of DpTypeNodes.
    */
class DLLEXP_DATAPOINT DpType
{
public:
  /// Default constructor.
  DpType();
  /// Constructor.
  DpType(const DpType &aType);
  /// Destructor.
  ~DpType()
  {
    Resources::getDiag().removeDpType(sizeof(DpType));
  }


  /// Comparison operator.
  int operator==(const DpType &rVal) const {return(name == rVal.name);}
  /// Comparison operator.
  int operator!=(const DpType &rVal) const {return(name != rVal.name);}
  /// Comparison operator.
  int operator<(const DpType &type) const;
  /// Assignment operator.
  const DpType &operator=(const DpType &aType);


  /// Write the instance into the itcNdrUbSend stream.
  friend DLLEXP_DATAPOINT itcNdrUbSend &operator<<(itcNdrUbSend &ndrStream, const DpType &type);
  /// Read the instance from the itcNdrUbReceive stream.
  friend DLLEXP_DATAPOINT itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream, DpType &type);    

  /// Allocate new element ID.
  DpElementId allocateNewElId();

  /// Add type node.
  PVSSboolean addNode(const DpTypeNode &newNode);

  /// Set root element.
  PVSSboolean setRootElement(DpElementId newRoot);
  /// Set name.
  PVSSboolean setName(DpTypeId newName);

  /** Get the type node of the root element.
  @return Returns NULL if the root element node was not found (Consistency is not valid).
  */
  const DpTypeNode *getRootTypeNodePtr() const;

  /// Get the type node for the specified element.
  DpTypeNode *getTypeNodePtr(DpElementId el);
  /// Get the type node for the specified element.
  const DpTypeNode *getTypeNodePtr(DpElementId el) const;
  /// Get number of type nodes
  DynPtrArrayIndex length() const { return dpTypeNodeList.getNumberOfItems(); }
  /// Get type node by index
  const DpTypeNode * getTypeNodePtrByIndex(DynPtrArrayIndex idx) const { return dpTypeNodeList.getAt(idx); }

  /// Get number of sons.
  DynPtrArrayIndex getSonNumber(DpElementId elementNum) const;
  /// Get element ID of the specified son node.
  DpElementId getSon(DpElementId elementNum, DynPtrArrayIndex sonIndex) const;
  /// Get element ID of the father node.
  DpElementId getFather(DpElementId elementNum) const;
  /// Check if the instance is correctly set-up. 
  PVSSboolean isConsistent() const;

  /// Get the difference between two types.
  static PVSSboolean diff(const DpType &oldType, const DpType &newType,
    DpElementId *&addedPtr,   PVSSulong &added,
    DpElementId *&removedPtr, PVSSulong &removed,
    DpElementId *&changedPtr, PVSSulong &changed);

public:    
  /// Get name.
  const DpTypeId &getName() const { return name; }
  /// Get name.
  DpTypeId &getName() { return name; }
  /// Get element ID of the root element.
  DpElementId getRootElement() const { return rootElement; }
  /// Get element ID of the root element.
  DpElementId &getRootElement() { return rootElement; }
  /// Get version number.
  const PVSSuchar &getVersionNr() const { return versionNr; }
  /// Get version number.
  PVSSuchar &getVersionNr() { return versionNr; }
  /// Set version number.
  void setVersionNr(const PVSSuchar &newVersionNr) { versionNr = newVersionNr; }

  /** Get first free Element Id.
  Should be handled with care!!!
  */
  DpElementId getFirstFreeElId() const { return firstFreeElId; }
  /** Set first free Element Id.
  Should be handled with care!!!
  @retval PVSS_FALSE if newFirstFreeElId was not set
  */
  PVSSboolean setFirstFreeElId(DpElementId newFirstFreeElId); 

  /// Write the content of the object into the debug stream.
  void debug(std::ostream &to, int level) const;


  /** Get first reference from the forward container.
  Forward container contains a list of references from our type together with source element id. 
  Only direct references are stored.
  @retval The whole structure is returmed.
  */
  const TypeRefStr *getFirstFwdRef() const;
  /** Get next reference from the forward container.
  For more information regarding forward container see getFirstFwdRef().
  @retval The whole structure is returmed.
  */
  const TypeRefStr *getNextFwdRef() const;
  /** Get first reference from the forward container.
  For more information regarding forward container see getFirstFwdRef().
  @retval Only type is returmed.
  */
  const DpTypeId   *getFirstTypeFwdRef() const;
  /** Get next reference from the forward container.
  For more information regarding forward container see getFirstFwdRef().
  @retval Only type is returmed.
  */
  const DpTypeId   *getNextTypeFwdRef() const;
  /** Clear forward container.
  For more information regarding forward container see getFirstFwdRef().
  */
  void clearFwdCont();
  /** Add element into the forward container.
  For more information regarding forward container see getFirstFwdRef().      
  @param typeId Type ID.
  @param elId Element ID.
  */
  void addToFwdCont(DpTypeId typeId, DpElementId elId);
  /** Remove element from the forward container.
  For more information regarding forward container see getFirstFwdRef().      
  @param typeId Type ID.
  @param elId Element ID.
  */
  void removeFromFwdCont(DpTypeId typeId, DpElementId elId);
  /** Rebuild the content of the forward container.
  For more information regarding forward container see getFirstFwdRef(). 
  */
  void rebuildFwdCont();

  /** Get first reference from the backward container.
  Backward container contains a list of references to our type together with source element id. 
  Only direct references are stored.
  Naturally, the type itself cannot determine this and the container must be filled from outside.
  @retval The whole structure is returmed.
  */
  const TypeRefStr *getFirstBwdRef() const;
  /** Get next reference from the backward container.
  For more information regarding backward container see getFirstBwdRef().
  @retval The whole structure is returmed.
  */
  const TypeRefStr *getNextBwdRef() const;
  /** Get first reference from the backward container.
  For more information regarding backward container see getFirstBwdRef().
  @retval Only type is returmed.
  */
  const DpTypeId   *getFirstTypeBwdRef() const;
  /** Get next reference from the backward container.
  For more information regarding backward container see getFirstBwdRef().
  @retval Only type is returmed.
  */
  const DpTypeId   *getNextTypeBwdRef() const;
  /** Clear backward container.
  For more information regarding backward container see getFirstBwdRef().
  */
  void clearBwdCont();
  /** Add element into the backward container.
  For more information regarding backward container see getFirstBwdRef().
  @param typeId Type ID.
  @param elId Element ID.
  */
  void addToBwdCont(DpTypeId typeId, DpElementId elId);
  /** Remove element from the backward container.
  For more information regarding backward container see getFirstBwdRef().
  @param typeId Type ID.
  @param elId Element ID.
  */
  void removeFromBwdCont(DpTypeId typeId, DpElementId elId);

  /** Compare the objects.
  isEqual compares not only ID, but also teh types into the datails.
  */
  PVSSboolean  isEqual(const DpType &type) const;

protected:
private:
  static int compareDpTypeNode(const DpTypeNode *a, const DpTypeNode *b);
  static int compareDpElementId(const DpElementId *id1, const DpElementId *id2);

  PVSSboolean diffFunction(const DpTypeNode *nodePtr,
    DpElementId *addedArrRef,   PVSSulong &addedHowManyRef,
    DpElementId *removedArrRef, PVSSulong &removedHowManyRef,
    DpElementId *changedArrRef, PVSSulong &changedHowManyRef,
    int  pass) const;

  PVSSboolean checkFunction(const DpTypeNode *nodePtr, DpTypeId dptId) const;

  void debug(std::ostream &to, int level, DpElementId elId, int indent) const;
  void rebuildFwdContSubtree(DpElementId elId);
  void appendNode(DpTypeNode *newNodePtr);

  DpTypeId name;
  DpElementId rootElement;
  DpElementId firstFreeElId;
  PVSSuchar versionNr;
  DpTypeNodeList  dpTypeNodeList;

  // Temporaer fuer interne Funktionen
private:
  static DynPtrArray<DpElementId>  checkListSons;
  static PVSSboolean    hasNoValueElType;
  static PVSSboolean    hasOtherElType;

  // Fwd and bwd containers
  DynPtrArray<TypeRefStr> fwdRefs;    // mutable ...
  DynPtrArray<TypeRefStr> bwdRefs;    // mutable ...

  friend class UNIT_TEST_FRIEND_CLASS; 
};


// inlines
// -------------------------------------------------------------------
inline const DpTypeNode *DpType::getRootTypeNodePtr() const
{
  return getTypeNodePtr(getRootElement());
}


//--------------------------------------------------------------------
inline DynPtrArrayIndex DpType::getSonNumber(DpElementId elementNum) const
{
  const DpTypeNode *nodePtr = getTypeNodePtr(elementNum);

  return nodePtr ? nodePtr->getSonNumber() : 0;
}


//--------------------------------------------------------------------
inline DpElementId DpType::getSon(DpElementId elementNum, DynPtrArrayIndex sonIndex) const
{
  const DpTypeNode *nodePtr = getTypeNodePtr(elementNum);

  return (nodePtr && sonIndex < nodePtr->getSonNumber()) ? nodePtr->getSon(sonIndex) : 0;
}


//--------------------------------------------------------------------
inline DpElementId DpType::getFather(DpElementId elementNum) const
{
  if (elementNum == rootElement)
    return 0;  // Vater des Roots ist nicht definiert

  const DpTypeNode *nodePtr = getTypeNodePtr(elementNum);

  return nodePtr ? nodePtr->getFather() : 0;
}


//--------------------------------------------------------------------
inline  const TypeRefStr * DpType::getFirstFwdRef() const
{
    // Unfortunately no 'mutable' keyword yet ...
    return fwdRefs.getFirst();
}


//--------------------------------------------------------------------
inline  const TypeRefStr * DpType::getNextFwdRef() const
{
    // Unfortunately no 'mutable' keyword yet ...
    return fwdRefs.getNext();
}

//--------------------------------------------------------------------
inline  const TypeRefStr *DpType::getFirstBwdRef() const
{
    // Unfortunately no 'mutable' keyword yet ...
    return bwdRefs.getFirst();
}


//--------------------------------------------------------------------
inline  const TypeRefStr *DpType::getNextBwdRef() const
{
    // Unfortunately no 'mutable' keyword yet ...
    return bwdRefs.getNext();
}

//--------------------------------------------------------------------



#ifdef WIN32
#pragma warning ( disable: 4231 )
#endif

#if defined(LIBS_AS_DLL)
    EXTERN_DATAPOINT template class DLLEXP_DATAPOINT DynPtrArray<DpType>;
#endif

#ifdef WIN32
#pragma warning ( default: 4231 )
#endif

#endif /* _DPTYPE_H_ */
