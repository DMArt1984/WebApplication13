// DATEIBESCHREIBUNG ==============================================================
// DATEINAME:     ElIdListItem.hxx
// VERANTWORTUNG: Johannes Ertl
// BESCHREIBUNG:  Das ist fuer eine Liste von Elementnummern
//
// AENDERUNGS-HISTORIE
// Ver.  | Datum      | Aenderungen                            | ModNr.| Autor
// ------+------------+-----------------Anfang-----------------+-------+-----------
//   1.0 |            | 1.Erstellung mit Westmount-OMT         |     0 |
// ======================================Ende======================================
#ifndef _ELIDLISTITEM_H_
#define _ELIDLISTITEM_H_

// Vorwaerts-Deklaration der Eigenen Klasse
class ElIdListItem;

// System-Include-Files
#include <DpTypes.hxx>
#include <PtrListItem.hxx>

// Vorwaerts-Deklarationen :

/// ========== ElIdListItem ============================================================
class DLLEXP_MESSAGES ElIdListItem : public PtrListItem 
{

  // Klassen-Enums:

// ..........................Anfang User-Klasseninterne-Definitionen..................
// ...........................Ende User-Klasseninterne-Definitionen...................
public:
  /// Constructor.
  ElIdListItem(DpElementId theElId);
  /// Destructor.
  ~ElIdListItem();

  // Operatoren :

  // Spezielle Methoden :

  /// Get DpElement ID.
  const DpElementId &getElId();

  // Generierte Methoden :

protected:
private:
  DpElementId elId;

// ............................Anfang User-Attribut-Definitionen...................
// .............................Ende User-Attribut-Definitionen....................
};

// ================================================================================
// Inline-Funktionen :

// ............................Anfang User-Inlines.................................
// .............................Ende User-Inlines..................................

inline const DpElementId &ElIdListItem::getElId()
{
  return elId;
}

// ................................OMT-Regeneration................................

#endif /* _ELIDLISTITEM_H_ */
