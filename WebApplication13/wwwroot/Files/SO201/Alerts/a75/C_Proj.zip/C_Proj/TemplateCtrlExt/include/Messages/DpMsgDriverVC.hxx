#ifndef _DPMSGDRIVERVC_H_
#define _DPMSGDRIVERVC_H_

// DATEIBESCHREIBUNG ==============================================================
// DATEINAME:     DpMsgDriverVC.hxx
// VERANTWORTUNG: Johannes Ertl
// BESCHREIBUNG:  Das ist die DpMsgValueChange fuer den Treiber. Ihre "Lese"-
//                Schnittstelle (->fuer den Empfaenger) ist gleich wie bei jeder
//                anderen DpMsgValueChange, nur das Erzeugen einer solchen Message
//                ist etwas anders.
//
//                Die DpMsgDriverVC enthaelt folgende Attribute von der
//                Konfiguration DpValue:
//                   - Quellzeit (in der Gruppe vorhanden)
//                   - Systemzeit (enthaelt jede DpMsg)
//                   - Originalwert
//                   - OutOfRange Statusbit (default auf FALSE)
//                   - Automatic Invalid Statusbit (default auf FALSE)
//                   - Generalabfrage Statusbit (default auf FALSE)
//                   - Einzelabfrage Statusbit (default auf FALSE)
//
//
//  03.03.2002    Memory/Msg-Length optimized, Martin Koller

// System-Include-Files
#include <BitVar.hxx>
#include <DpMsgValueChange.hxx>
#include <DpVCGroup.hxx>
#include <DpVCItem.hxx>

#include <Allocator.hxx>

// Vorwaerts-Deklarationen :
class DpIdentifier;
class ManagerIdentifier;
class Msg;
class TimeVar;
class Variable;

// ========== DpMsgDriverVC ============================================================

/// The DpMsgValueChange for a driver.
/// @n The interface (for a receiver) is the same as any other DpMsgValueChange,
/// only the creation of such a message is different.
///
/// The DpMsgDriverVC contains the following attributes of the configuration DpValue:
/// - source time (in the existing group)
/// - system time (already included in every DpMsg)
/// - original value
/// - out of range status bit (default is FALSE)
/// - automatic invalid status bit (default is FALSE)
/// - general query status bit (default is FALSE)
/// - single query status bit (default is FALSE)

class DLLEXP_MESSAGES DpMsgDriverVC : public DpMsgValueChange
{
  friend class UNIT_TEST_FRIEND_CLASS;    // ein Unit-Test braucht erweiterten zugriff auf diese Klasse
  friend class UNIT_TEST_FRIEND_CLASS_2;    // ein Unit-Test braucht erweiterten zugriff auf diese Klasse

  public:
    AllocatorDecl;

    /// constructor, initialisation with zero values
    DpMsgDriverVC();

    /// copy constructor.
    DpMsgDriverVC(const DpMsgDriverVC &rVal);

    /// param constructor
    /// @param newDestination the ManagerIdentifier of new destination
    /// @param answer the answer flag
    /// @param originManager the ManagerIdentifier of the origin manager
    /// @param originTime the time the origin
    /// @param dpIdentifier the changed DpIdentifier
    /// @param value the changed value
    DpMsgDriverVC(const ManagerIdentifier &newDestination, PVSSboolean answer,
                  const ManagerIdentifier &originManager, const TimeVar &originTime,
                  const DpIdentifier &dpIdentifier, const Variable &value);

    /// param constructor
    /// @param newDestination the ManagerIdentifier of new destination
    /// @param answer the answer flag
    /// @param originManager the ManagerIdentifier of the origin manager
    /// @param originTime the time the origin
    /// @param dpIdentifier the changed DpIdentifier
    /// @param varPtr the changed value
    /// @n The call takes ownership of this pointer.
    DpMsgDriverVC(const ManagerIdentifier &newDestination, PVSSboolean answer,
                  const ManagerIdentifier &originManager, const TimeVar &originTime,
                  const DpIdentifier &dpIdentifier, VariablePtr varPtr);

    /// destructor
    ~DpMsgDriverVC();


    // Operatoren :

    /// operator << for itcNdrUbSend stream
    /// @param ndrStream the stream, which to send to
    /// @param msg the DpMsgDriverVC message
    friend DLLEXP_MESSAGES itcNdrUbSend &operator<<(itcNdrUbSend &ndrStream, const DpMsgDriverVC &msg);

    /// operator >> for itcNdrUbReceive stream
    /// @param ndrStream the stream, which to receive from
    /// @param msg the DpMsgDriverVC message
    friend DLLEXP_MESSAGES itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream, DpMsgDriverVC &msg);

    /// comparison operator ==
    /// @param rVal the DpMsgDriverVC to compare with
    /// @return 0 if not equal else 1
    int operator==(const DpMsgDriverVC &rVal) const;

    /// comparison operator ==
    /// @param rVal the message to compare with
    /// @return 0 if not equal else 1
    virtual int operator==(const Msg &rVal) const;

    /// assignment operator for DpMsgDriverVC
    /// @param rVal the DpMsgDriverVC to assign
    /// @return the resulting DpMsgDriverVC
    DpMsgDriverVC &operator=(const DpMsgDriverVC &rVal);

    /// assignment operator used for type conversion
    /// @param rVal the message to convert
    /// @return the resulting message
    virtual Msg &operator=(const Msg &rVal);

    /// send debug info to output stream
    /// @param to the output stream
    /// @param level the debug level
    virtual void debug(std::ostream &to, int level) const;

    // Spezielle Methoden :
  
    /// set OutOfRange flag
    /// @param value the value to set
    void setOutOfRange(PVSSboolean value);

    /// set AutoInv flag
    /// @param value the value to set
    void setAutoInv(PVSSboolean value);

    /// set GeneralInter flag
    /// @param value the value to set
    void setGeneralInter(PVSSboolean value);

    /// set SingleInter flag
    /// @param value the value to set
    void setSingleInter(PVSSboolean value);

    /// set TimeOfPeriph flag
    /// @param value the value to set
    void setTimeOfPeriph(PVSSboolean value);

    /// set UserBit
    /// @param pos the position to set
    /// @param value the value to set
    void setUserBit(PVSSushort pos, PVSSboolean value);


    /// get number of VCGroups in this message, always returns 1
    virtual PVSSulong getNrOfGroups() const {return 1;};

    // wird im AnswerHandler::sendMsgWaitingForAnswer() benoetigt und liefert aus einer
    // Group den ersten DpIdentifier

    /// get the DpIdentifier from a group
    /// @param groupIndex the index of the group
    virtual DpIdentifier getGroupId(PVSSulong groupIndex) const;

    /// set iterator on the first group
    /// @return the first group
    DpVCGroup *getFirstGroup() const;

    /// set iterator to the next group
    /// @return the next group
    DpVCGroup *getNextGroup() const;

    /// remove a group
    /// @param g the group to remove
    /// @return if g == lastAccessed then g.getNext() else lastAccessed
    DpVCGroup *removeGroup(DpVCGroup *g);

  	/// check if own DP message type matches other DP message type
    /// @param dpMsgType the MsgType to check
    /// @return DpMsgDriverVC type if argument is DpMsgDriverVC else a DP message type
    MsgType isA(MsgType dpMsgType) const;

    /// get own DP message type, always DP_MSG_DRIVER_VC
    MsgType isA() const;

    /// allocate a new message
    Msg *allocate() const;

  protected:

  private:
    void outNdrUb(itcNdrUbSend &ndrStream) const;
    void inNdrUb(itcNdrUbReceive &ndrStream);

    DpVCGroup group;
    DpVCItem valueItem;

    BitVar outOfRange;
    DpVCItemProt outOfRangeItem;

    BitVar autoInv;
    DpVCItemProt autoInvItem;

    BitVar generalInter;
    DpVCItemProt generalInterItem;

    BitVar singleInter;
    DpVCItemProt singleInterItem;

    BitVar timeOfPeriph;
    DpVCItemProt timeOfPeriphItem;

    BitVar userbit1;
    DpVCItemProt userbit1Item;

    BitVar userbit2;
    DpVCItemProt userbit2Item;

    BitVar userbit3;
    DpVCItemProt userbit3Item;

    BitVar userbit4;
    DpVCItemProt userbit4Item;

    BitVar userbit5;
    DpVCItemProt userbit5Item;

    BitVar userbit6;
    DpVCItemProt userbit6Item;

    BitVar userbit7;
    DpVCItemProt userbit7Item;

    BitVar userbit8;
    DpVCItemProt userbit8Item;

    PVSSuchar userbitFlags;  // every bit is one flag for the corresponding UserBit

  private:
    void init();
    void setupAdresses();
};

// ================================================================================

inline void DpMsgDriverVC::setOutOfRange(PVSSboolean value)
{
  outOfRange.setValue(value);
}

inline void DpMsgDriverVC::setAutoInv(PVSSboolean value)
{
  autoInv.setValue(value);
}

inline void DpMsgDriverVC::setGeneralInter(PVSSboolean value)
{
  generalInter.setValue(value);
}

inline void DpMsgDriverVC::setSingleInter(PVSSboolean value)
{
  singleInter.setValue(value);
}

inline void DpMsgDriverVC::setTimeOfPeriph(PVSSboolean value)
{
  timeOfPeriph.setValue(value);
}

inline DpVCGroup *DpMsgDriverVC::getFirstGroup() const
{
  return (DpVCGroup *)(&group);
}

inline DpVCGroup *DpMsgDriverVC::getNextGroup() const
{
  return 0;
}


inline DpVCGroup *DpMsgDriverVC::removeGroup(DpVCGroup *)
{
  return(0);
}

#endif /* _DPMSGDRIVERVC_H_ */
