#ifndef _SFKWAITFORANSWER_H_
#define _SFKWAITFORANSWER_H_

#include <HotLinkWaitForAnswer.hxx>

/*  author VERANTWORTUNG: Wolfram Klebel */
/** handles the returning values on managing corr_value-callbacks */

class StatFunc;

class DLLEXP_CTRL SFKWaitForAnswer : public HotLinkWaitForAnswer
{
  public:
    ///
    SFKWaitForAnswer(StatFunc *mod, int cData = 0) 
    : module(mod), 
      clientData(cData),
      hotLinkAnswered(false)  {}

    ///
    ~SFKWaitForAnswer();

    /// Implement callBack 
    virtual void callBack(DpMsgAnswer &answer);

    ///
    /// HotLink Callback startet Thread und fuehrt work Function aus
    virtual void hotLinkCallBack(DpMsgAnswer &answer);

    /// HotLink Callback startet Thread und fuehrt work Function aus
    virtual void hotLinkCallBack(DpHLGroup &group);

    /// entferne ref 
    void clearModule() { module = 0; }

    /// Ist die Antwort auf das dpConnect eingetroffen? true -> Hotlink ist aktiv.
    bool gotHotLinkAnswer() { return(hotLinkAnswered); }

  protected:

  private:
    StatFunc *module;
    int clientData;
    bool hotLinkAnswered;
};

#endif /* _SFKWAITFORANSWER_H_ */
