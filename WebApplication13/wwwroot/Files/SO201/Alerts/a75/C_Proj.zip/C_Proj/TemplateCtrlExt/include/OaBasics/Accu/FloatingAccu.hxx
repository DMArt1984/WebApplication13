#ifndef _FLOATINGACCU_H_
#define _FLOATINGACCU_H_

// Author: Wolfram Klebel
// Date:   22.10.2002
// Purpose: Zwischenschicht zwischen StatFunc und PeriodAccu fuer die Generierung
//          von statistischen Funktionen, die gleitend (dh. laufend mit 
//          verschachtelten Perioden) berechnet werden
//          siehe auch TI 17623

// ****************************************************************************
// Function:
//
// die Schnittstelle soll der StatFunc eine Variante des PeriodAccu vorgeben:
// es gibt die gleichen Methoden, aber deren Funktion beschr�nkt sich darauf, 
// sie an den richtigen (jeweils aktiven) PeriodAccu weiterzugeben
// - isValid(), startWorking(), alle add...()-Funktionen werden direkt an ALLE angehaengten PeriodAccus weitergeschliffen
// - getResult( stop ) wird nur an den jeweils aktiven PeriodAccu weitergegeben,
// - workNextPeriod( stopTime ) schiebt die Zeiten und den aktuellen PeriodAccu um eins weiter
//
// Der FloatingAccu haellt mehrere PeriodAccu (je Unterteilung einen)
//
// ******************************************************************************

#ifndef _SIMPLEACCU_H_
#include <SimpleAccu.hxx>
#endif

#ifndef _VARIABLE_H_
#include <Variable.hxx>
#endif

#ifndef _TIMEVAR_H_
#include <TimeVar.hxx>
#endif

#ifndef _DYNVAR_H_
#include <DynVar.hxx>
#endif

#ifndef _PERIODACCU_H_
#include <PeriodAccu.hxx>
#endif

#ifndef _BASEACCU_H_
#include <BaseAccu.hxx>
#endif

#include <DebugOutput.hxx>

/** This class provides a buffer for time related cumulating functions, working on Variables.
    FloatingAccu accumulates the values over predefined period of time. Using multiple PeriodAccu classes, it can provide intermediate results.
    FloatingAccu adresses the period accu using time slices for the calculation of subsequent periods within the same interval.

    @classification ETM internal
*/
class DLLEXP_OABASICS FloatingAccu : public BaseAccu
{
  public:
    /** Constructor.
        @param  periodAccuArray Pointer to array of PeriodAccu onbjects.
        @param  count The number of accumulators in the array.
        */
    FloatingAccu( PeriodAccu **periodAccuArray, PVSSulong count );

    // Destructor
    virtual ~FloatingAccu();
    
    /// Add new value to the accumulator.
    virtual void addValue( const Variable &theValue, const TimeVar &atTime );
    /// Add new invalid value to the accumulator.
    virtual void addInvalidValue( const Variable &theValue, const TimeVar &atTime );

    /// Add new value to history.
    virtual void addHistory( const Variable &theValue, const TimeVar &atTime );
    /// Add new invalid value to history.
    virtual void addInvalidHistory(const Variable &theValue, const TimeVar &atTime);

    /// Advance to the subsequent period and process buffered values (if any). 
    virtual void workNextPeriod( const TimeVar & nextStop );

    /** Process the buffered values. 
        When there is no history, this is a first function after the constructor which is called from StatFunc.
    */
    virtual void startWorking();

    /// Return the result kept in the accumulator.
    virtual const Variable &getResult(TimeVar* periodStop = 0, PVSSboolean isIntermediate = false );

    /// Check if the accumulator is in the valid state. 
    virtual PVSSboolean isValid() const;
    
    /// Returns the start and stop time.
    virtual void getStartStop( TimeVar *start, TimeVar *stop) const;
    /// Set the start and stop time.
    virtual void setStartStop( const TimeVar &start, const TimeVar &stop);
    /// Reset the start and stop time.
    virtual void reset( const TimeVar &theStart, const TimeVar &theStop );

  protected:
    
  private:
    FloatingAccu();
    FloatingAccu(const PeriodAccu &);
    FloatingAccu &operator=(const FloatingAccu &);

    PeriodAccu **myPeriodAccus_;
    PVSSulong actPeriodAccu_;
    PVSSulong myAccuCount_;
};

// ****************************************************************************

inline PVSSboolean FloatingAccu::isValid() const
{
  return (myPeriodAccus_[actPeriodAccu_])->isValid();
}

inline void FloatingAccu::getStartStop( TimeVar *sa, TimeVar *sp ) const
{
  myPeriodAccus_[actPeriodAccu_]->getStartStop( sa, sp);

  return;
}

inline void FloatingAccu::setStartStop( const TimeVar &sa, const TimeVar &sp )
{
  myPeriodAccus_[actPeriodAccu_]->setStartStop( sa, sp);

  return;
}

inline void FloatingAccu::reset( const TimeVar &sa, const TimeVar &sp )
{
  myPeriodAccus_[actPeriodAccu_]->reset( sa, sp);

  return;
}

inline const Variable &FloatingAccu::getResult(TimeVar* periodStop, PVSSboolean isIntermediate )
{
  return (myPeriodAccus_[actPeriodAccu_])->getResult( periodStop, false);
}

inline void FloatingAccu::startWorking()
{
  for (PVSSulong i = 0; i < myAccuCount_; i++)
    myPeriodAccus_[i]->startWorking( );
}

inline void FloatingAccu::workNextPeriod( const TimeVar & nextStop )
{
  myPeriodAccus_[actPeriodAccu_]->workNextPeriod( nextStop );
  if (DebugOutput::isDbgFlag(DebugOutput::DBG_EV_STATFUNC))
  // COVINFO BLOCK: debug (mhorvath: isDbgFlag - no safety relevance)
  {
    std::cerr << "FloatingAccu::workNextPeriod( " << actPeriodAccu_ << ", ";
    nextStop.outToFile(std::cerr); std::cerr << ");" << std::endl;
  }
  // COVINFO BLOCKEND
  actPeriodAccu_ = (actPeriodAccu_ + 1) % myAccuCount_;
}

inline void FloatingAccu::addValue( const Variable &theValue, const TimeVar &atTime )
{
  for (PVSSulong i = 0; i < myAccuCount_; i++)
    myPeriodAccus_[i]->addValue( theValue, atTime );
}

inline void FloatingAccu::addInvalidValue( const Variable &theValue, const TimeVar &atTime )
{
  for (PVSSulong i = 0; i < myAccuCount_; i++)
    myPeriodAccus_[i]->addInvalidValue( theValue, atTime );
}

inline void FloatingAccu::addHistory( const Variable &theValue, const TimeVar &atTime )
{
  for (PVSSulong i = 0; i < myAccuCount_; i++)
    myPeriodAccus_[i]->addHistory( theValue, atTime );
}

inline void FloatingAccu::addInvalidHistory(const Variable &theValue, const TimeVar &atTime)
{
  for (PVSSulong i = 0; i < myAccuCount_; i++)
    myPeriodAccus_[i]->addInvalidHistory( theValue, atTime );
}


#endif
