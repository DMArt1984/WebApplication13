#ifndef _RUNNINGSTATE_H_
#define _RUNNINGSTATE_H_

/*
VERANTWORTUNG: Johann Klugsberger    
BESCHREIBUNG:  class RunningState, to signalize state of 
  the manager to other programs (like the PVSSConsole) via 
  Win32-Event
*/

/* never used ...
#define RS_UNCREATED  0x00
#define RS_CREATED    0x01
#define RS_RUNNING    0x03
#define RS_STOPPED    0x05
*/
#include <PmonTable.hxx>

class CharString;

/** The running state of a manager. This class is used to signal the running state of a manager
    to other programs. This class originally implemented for the old Windows-only PVSS console.

    This class is deprecated and will be removed in future releases.
    @osdiff Only for OS Windows
    @classification ETM internal
*/
class DLLEXP_BASICS RunningState
{
friend class UNIT_TEST_FRIEND_CLASS; 

  public:
    /// Constructor.
    RunningState()
      //: myState(RS_UNCREATED)
#ifdef _WIN32
      : runningEvent(NULL)
#else
#endif // _WIN32
    { myIdx_ = -1; }

    /// Destructor.
    ~RunningState()
    {
      setStateStopped();
#ifdef _WIN32
      if (runningEvent)
          CloseHandle(runningEvent);
#endif // _WIN32
    }

    /// Calls CreateEvent/OpenEvent Windows API method and initializes the process
    /// monitor table (pmon member).
    int create();
    
    /// Calls the SetEvent Windows API method.
    void setStateRunning();

    /// Calls the ResetEvent Windows API method. 
    void setStateStopped();
      
    /// Create unique object name combined from computer name, program name and pid. This
    /// string will then be used in the Windows Event-related methods.
    /// @param buffer Output buffer for the object name string.
    /// @param bufferLen length of the buffer.
    /// @param progName Program name string.
    /// @param pid Project Id.
    /// @return Pointer to buffer variable containing the object name string.
    static char* createObjectName(char * buffer, size_t bufferLen,
        char * progName, unsigned long pid);
    /*
    int getState()
    {
      return myState;
    }
    */
 
    /// Gets the Process monitor table.
    /// @return Pointer to the internaly stored Process monitor table (pmon variable).
    const PmonTable * getPmonTable() const { return &pmon; }

    /// Increase the Alive counter in the pmon table.
    void incAlive();

    /// Sets Manager number into PmonTable.
    /// @param num Manager number.
    void setManNum(unsigned num);

    /// Sets reduPeerAlive flag in the PmonTable.
    /// @param b ReduPeerAlive flag.
    void setReduPeerAlive(bool b) { pmon.setReduPeerAlive(b); }

  protected:
    //int myState;

#ifdef _WIN32
    /// Event handle
    HANDLE runningEvent;
#endif    // _WIN32

  private:
    /// process monitor table
    PmonTable pmon;

    /// the index for my Manager into the pmon-table
    int myIdx_;
 
    // so that the compiler does not define them itself !!
    /// copy constructor
    RunningState(const RunningState &);
    /// assignment operator
    RunningState &operator=(const RunningState &);
};

#endif /* _RUNNINGSTATE_H_ */

