#ifndef _EXPRLIST_H_
#define _EXPRLIST_H_

#include <PTreeNode.hxx>
#include <CtrlExpr.hxx>


/* author VERANTWORTUNG: Martin Koller                    */
/* BESCHREIBUNG: Liste von Argumenten (fuer Function-Call) */

/** the function call expression list. this list holds the parameters used for a control function call
*/
class DLLEXP_CTRL ExprList : public PTreeNode
{
  public:
    /// leere Liste
    ExprList(int line = -1, int file = -1)
      : PTreeNode(line, file), first(0), last(0), act(0), count(0) {}

    /// delete all private Member
    virtual ~ExprList();

    /// append a CtrlExpr to the list
    void append(CtrlExpr *exp);
    void insert(CtrlExpr *exp);
    void cut(CtrlExpr *exp);

    void clear();

    /// return NULL  |  first CtrlExpr
    CtrlExpr *getFirst() const { return (act = first); }

    /// return NULL  |  next CtrlExpr
    CtrlExpr *getNext() const { return (act = (CtrlExpr *) (act ? (act->getNext()) : 0)); }

    /// return NULL | last CtrlExpr
    CtrlExpr *getLast() const { return (act = last); }

    /** returns the expression pointed to by start and sets the "last accessed-pointer".
        from now a call to getNext() returns the next item from the given on
      */
    CtrlExpr *getFirst(CtrlExpr *start) { return (act = start); }

    /// return number of items in list
    unsigned int getNumberOfItems() const { return count; }

    /// return index of given expression in this list or -1 if not found
    int indexOf(CtrlExpr *expr) const;

    virtual void dumpCoverageTree(std::ostream &to, CoverageAction action = DUMP) const;

    virtual bool checkIntegrity(const CharString &location, CtrlThread *thread) const;

  protected:
    // Do not change, FCall relies on this!
    ExprList(const ExprList &list) : PTreeNode(list) {};

    CtrlExpr *first;
    CtrlExpr *last;
    mutable CtrlExpr *act;
    unsigned int count;
};

#endif /* _EXPRLIST_H_ */
