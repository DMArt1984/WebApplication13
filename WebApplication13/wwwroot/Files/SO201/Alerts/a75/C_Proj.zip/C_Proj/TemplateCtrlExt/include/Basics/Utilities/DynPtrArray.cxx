// DATEIBESCHREIBUNG ==============================================================
// DATEINAME:     DynPtrArray.cxx
// VERANTWORTUNG: Laszlo Szakony
// BESCHREIBUNG:  Dynamisches Pointer Array
//
// ======================================Ende======================================
#if !defined(_DYNPTRARRAY_CXX)
#define _DYNPTRARRAY_CXX

#include <stdlib.h>
#include <limits.h>
#include <string.h>
#include <assert.h>
#include "DynPtrArray.hxx"

// #define  USE_QSORT

// template <class Item>
// int (*DynPtrArray<Item>::wcompFunction)(const void *, const void *) = 0;

#define SINGLEALLOCATEBOUND 4
#define ALLOCATEFACTOR 1.5 // increase with factor p of current size -> y_new = y_cur*p
#define ALLOCHYSTFACTOR 0.5 // the factor for hystcalc h where h <= 1/p (if equal no hysteresis)

// Destruktor
  template<class Item>
DynPtrArray<Item>::~DynPtrArray()
{
  // ................................Anfang Destruktor...............................
  if (!arrayPtr)
    return;

  // If there is no copy of this object, than destry the pointed objects as well!
  if (this == firstArrayPtr && !nextArrayPtr)
  {
    for (int i = nofItemsInArray; i--; )
      delete arrayPtr[i];
  }
  else
  {
    DynPtrArray *p;
    // if we are the first in the list, set all first pointer to the next!
    if (firstArrayPtr == this)
    {
      for ( p = firstArrayPtr->nextArrayPtr; p; p = p->nextArrayPtr)
      {
        p->firstArrayPtr = nextArrayPtr;
      }
    }
    else
    {
      // we are not the first, so remove us from the list!
      for ( p = firstArrayPtr; p && p->nextArrayPtr != this; p = p->nextArrayPtr)
        ;
      assert (p && p->nextArrayPtr == this);
      p->nextArrayPtr = this->nextArrayPtr;
    }
  }

  nofItemsInArray = 0;
  resizeArray(0);
}

// Konstruktor
  template<class Item>
DynPtrArray<Item>::DynPtrArray()
  : firstArrayPtr(this),
  nextArrayPtr(0),
  arrayPtr(0),
  sizeOfTheArray(0),
  nofItemsInArray(0),
  compareFunction(0),
  isSorted(0)
{
  lastAccessedIndex = DYNPTRARRAY_INVALID;
  lastFoundIndex = DYNPTRARRAY_INVALID;
}

  template<class Item>
DynPtrArray<Item>::DynPtrArray(DynPtrArray &pa) // copy ctor
  : firstArrayPtr(this),
  nextArrayPtr(0),
  arrayPtr(0),
  sizeOfTheArray(0),
  nofItemsInArray(0),
  compareFunction(0),
  isSorted(0)
{
  lastAccessedIndex = DYNPTRARRAY_INVALID;
  lastFoundIndex = DYNPTRARRAY_INVALID,
  *this = pa;
}

  template<class Item>
DynPtrArray<Item>& DynPtrArray<Item>::operator =(DynPtrArray<Item>& x)
{
  assert (sizeOfTheArray == 0 && firstArrayPtr == this && !nextArrayPtr);

  if (resizeArray (x.sizeOfTheArray) != DYNPTRARRAY_INVALID)
  {
    memcpy (arrayPtr, x.arrayPtr, sizeOfTheArray * sizeof(Item **));

    firstArrayPtr       = x.firstArrayPtr;
    nextArrayPtr        = x.nextArrayPtr;
    x.nextArrayPtr      = this;

    nofItemsInArray     = x.nofItemsInArray;
    lastAccessedIndex   = x.lastAccessedIndex;
    lastFoundIndex      = x.lastFoundIndex;
    isSorted            = x.isSorted;
    compareFunction     = x.compareFunction;
  }

  return *this;
}

//-------------------------------------------------------------------------
// grabTheArrayOfMyFriend
  template<class Item>
DynPtrArrayIndex DynPtrArray<Item>::grab(DynPtrArray<Item> &myFriend)
{
  // I am the target. hooo!!

  if (sizeOfTheArray != 0 )
    return DYNPTRARRAY_INVALID;   //COVINFO LINE: defensive (AP: never expected)

  if (myFriend.sizeOfTheArray == 0)
    return 0; // Nothing to do, we are ready

  if (firstArrayPtr != this || myFriend.firstArrayPtr != &myFriend)
    return DYNPTRARRAY_INVALID;   //COVINFO LINE: defensive (AP: never expected)

  if (nextArrayPtr || myFriend.nextArrayPtr)
    return DYNPTRARRAY_INVALID;   //COVINFO LINE: defensive (AP: never expected)

  arrayPtr                   = myFriend.arrayPtr;
  myFriend.arrayPtr          = 0;
  sizeOfTheArray             = myFriend.sizeOfTheArray;
  myFriend.sizeOfTheArray    = 0;
  nofItemsInArray            = myFriend.nofItemsInArray;
  myFriend.nofItemsInArray   = 0;
  lastFoundIndex             = myFriend.lastFoundIndex;
  myFriend.lastFoundIndex    = DYNPTRARRAY_INVALID;
  lastAccessedIndex          = myFriend.lastAccessedIndex;
  myFriend.lastAccessedIndex = DYNPTRARRAY_INVALID;
  isSorted                   = myFriend.isSorted;
  compareFunction            = myFriend.compareFunction;

  return   sizeOfTheArray;
}

//-------------------------------------------------------------------------
  template<class Item>
DynPtrArrayIndex DynPtrArray<Item>::deepCopy(const DynPtrArray<Item> &src)
{
  DynPtrArrayIndex i, count = src.nofItems();

  // Vorher alles loeschen
  reinit(count);

  // Do it backward. avoid realloc()
  for (i=count; i--; )
  {
    Item *newItem = 0, *srcItem;
    if ((srcItem = src.getAt(i)) != 0)
    {
      newItem = new Item(*srcItem);
      if (!newItem)
      { //COVINFO BLOCK: defensive (AP: out of memory)  //nothing has been copied - no memory
        clear();
        count = 0;
        break;
      } //COVINFO BLOCKEND
    }
    else
      newItem = 0;

    setPtr(i, newItem);
  }

  return count;
}
//-------------------------------------------------------------------------
  template<class Item>
DynPtrArrayIndex DynPtrArray<Item>::deepCopySorted(const DynPtrArray<Item> &src)
{
  DynPtrArrayIndex res = deepCopy(src);

  if (nofItems() == src.nofItems())
    isSorted = src.isSorted;

  compareFunction = src.compareFunction;

  return res;
}

//-------------------------------------------------------------------------
template<class Item>
DynPtrArrayIndex DynPtrArray<Item>::findPtr(const Item* itemPtr) const
{
  // local vars are faster, than those of member vars!!!
  Item **p = arrayPtr;

  if (lastFoundIndex < nofItemsInArray && p[lastFoundIndex] == (Item*) itemPtr)
    return lastFoundIndex;

  if (lastAccessedIndex < nofItemsInArray && p[lastAccessedIndex] == (Item *) itemPtr)
    return ( ((DynPtrArray<Item> *) this)->lastFoundIndex = lastAccessedIndex);

  // wenn die Ptr nur durch vergleich der Adressen gesucht werden k�nnen auch Ptr die
  // nicht mehr g�ltig sind gesucht werden ohne das es einen crash gibt.
  // zumindest der Event nutzt im QueryContaner diese feature -> nicht �ndern!!!

# if 0
  // Better not, comparefunction could be very slow
  // if sorted look via findItemIfSorted
  DynPtrArrayIndex idx = DYNPTRARRAY_INVALID;
  if (compareFunction && isSorted)
  {
    idx = findItemIfSorted(itemPtr);
    if (idx != DYNPTRARRAY_INVALID)
    {
      // Jetzt unter lauter gleichen den richtigen Ptr suchen
      while ( idx < nofItemsInArray )
      {
        if (p[idx] == (Item *) itemPtr)
          return ( ((DynPtrArray<Item> *) this)->lastFoundIndex = idx);

        // Ab hier stehen andere Werte, Pech
        if ( (*compareFunction)(itemPtr, p[idx]) )
          break;

        idx++;
      }
    }

    // Der Pointer wurde nicht gefunden, also Tschuess
    return DYNPTRARRAY_INVALID;
  }
# endif

  // Falls es wie oben nicht gefunden werden konnte
  Item **ptr;
  DynPtrArrayIndex i;

  for (i = nofItemsInArray, ptr = (Item **) (p + i); ptr--, i--;)
  {
    if (*ptr == (Item *) itemPtr)
      return ( ((DynPtrArray<Item> *) this)->lastFoundIndex = i);    // mutable
  }

  return DYNPTRARRAY_INVALID;
}


// ######################################################################################
// # Functions, which contain critical sections
// # No return allowed, until the critical section!
// ######################################################################################

template<class Item>
DynPtrArrayIndex DynPtrArray<Item>::setPtr(DynPtrArrayIndex i, const Item* itemPtr)
{
  if ( i == DYNPTRARRAY_INVALID)
    return i;

  // If there is no copy of this object, simple process only the object!!
  // This is actually the template, of 'what to do'.
  if (this == firstArrayPtr && !nextArrayPtr)
  {
    if (i >= nofItemsInArray)
    {
      if ( resizeArray(i+1) == DYNPTRARRAY_INVALID)
      {
        return DYNPTRARRAY_INVALID;  //COVINFO LINE: defensive (AP: out of memory) 
      }
      else
        nofItemsInArray = i + 1;
    }

    arrayPtr[i] = (Item *)itemPtr;
    isSorted = 0;
    return i;
  }


  // There are some copies, so update all of the attached objects!
  // first of all save the state of THIS object!
  int cleanupNeeded = 0;
  DynPtrArrayIndex foundIndex = 0;
  DynPtrArrayIndex savedNofItemsInArray  = nofItemsInArray;
  Item *searchItemPtr = getAt(i);
  DynPtrArray *p;


  //*********************************************************
  //* Critical Section Start
  //* No return is allowed!!!!!
  //*********************************************************
  // Process all of the objects, which are hanging in the list
  for ( p = firstArrayPtr; p; p = p->nextArrayPtr)
  {
    // staticUserDataPtr = p->getUserDataPtr();

    assert (p->nofItemsInArray == savedNofItemsInArray);

    if ( i >= p->nofItemsInArray)  // the index is greater then the # of items in the array
    {
      if ( p->resizeArray(i+1) == DYNPTRARRAY_INVALID)  // try to make room for the newcoming
      { //COVINFO BLOCK: defensive (AP: out of memory) 
        cleanupNeeded = 1;  // hmmm, no success
        break;
      } //COVINFO BLOCKEND
      else
        p->nofItemsInArray = i + 1; // array expanded, and we have some more items (1 or may be more!!!)

      p->arrayPtr[i] = (Item *)itemPtr; // set pointer at the requested place!
      p->isSorted = 0; // I guess, it is unsorted
    }
    else  // If the index points into the array just try to update it!
    {
      if (p->arrayPtr[i] == searchItemPtr)  // found ourself ??!!, maybe, but not sure!!
      {
        foundIndex = i;
      }
      else  // the index is not the right one. search the right index!
      {
        foundIndex = p->findPtr(searchItemPtr);
        assert (foundIndex != DYNPTRARRAY_INVALID); // Inconistent ????
      }

      // Update sort-Flag
      if ( p->compareFunction &&
          ( !p->arrayPtr[foundIndex] || (*p->compareFunction)(itemPtr, p->arrayPtr[foundIndex]) )
         )
      {
        p->isSorted = 0;          // In any case: not sorted
      }

      p->arrayPtr[foundIndex] = (Item *)itemPtr; // update the pointer at the found place

      // Otherwise sort state is not changed
      // p->isSorted = 0; // I guess it should be unsorted!
    }
  }

  if (cleanupNeeded)
  { //COVINFO BLOCK: defensive (AP: never expected)
    DynPtrArray * recoveryPtr = p;

    // Process all ofthe objects, which were processed so far in the list
    for ( p = firstArrayPtr; p != recoveryPtr; p = p->nextArrayPtr)
    {
      foundIndex = p->findPtr(itemPtr);
      assert (foundIndex != DYNPTRARRAY_INVALID); // Inconistent ????
      if (p->nofItemsInArray == savedNofItemsInArray)
        p->arrayPtr[foundIndex] = searchItemPtr;
      else
        p->arrayPtr[foundIndex] = 0;

      p->nofItemsInArray = savedNofItemsInArray;
    }
  } //COVINFO BLOCKEND

  //*********************************************************
  //* Critical Section End
  //*********************************************************

  // set / clear the error only for this object!
  if (cleanupNeeded)
  {
    i = DYNPTRARRAY_INVALID; //COVINFO LINE: defensive (AP: never expected)
  }

  return i;
}

  template<class Item>
DynPtrArrayIndex DynPtrArray<Item>::insertPtr(DynPtrArrayIndex i, const Item* itemPtr)
{
  if ( i >= nofItemsInArray)
    return setPtr(i, itemPtr);

  // If there is no copy of this object, simple process only the object!!
  // This is actually the template, of 'what to do'.
  if (this == firstArrayPtr && !nextArrayPtr)
  {
    if ( resizeArray(nofItemsInArray + 1) == DYNPTRARRAY_INVALID)
    {
      return DYNPTRARRAY_INVALID; //COVINFO LINE: defensive (AP: out of memory)
    }

    size_t sz = (nofItemsInArray - i) * sizeof(Item *);

    if (sz)
      memmove( arrayPtr + i + 1, arrayPtr + i, sz);

    arrayPtr[i] = (Item *)itemPtr;
    nofItemsInArray += 1;
    isSorted = 0;
    return i;
  }

  // There are some copies, so update all of the attached objects!
  // first of all save the state of THIS object!
  int cleanupNeeded = 0;
  DynPtrArrayIndex foundIndex = 0;
  DynPtrArrayIndex savedNofItemsInArray = nofItemsInArray;
  Item *searchItemPtr = getAt(i);
  DynPtrArray * p;


  //*********************************************************
  //* Critical Section Start
  //* No return is allowed!!!!!
  //*********************************************************

  // Process all of the objects, which are hanging in the list
  for ( p = firstArrayPtr; p; p = p->nextArrayPtr)
  {
    assert (p->nofItemsInArray == savedNofItemsInArray);

    if (p->resizeArray(p->nofItemsInArray + 1) == DYNPTRARRAY_INVALID)
    { //COVINFO BLOCK: defensive (AP: out of memory)
      cleanupNeeded = 1;
      break;
    } //COVINFO BLOCKEND

    if (p->arrayPtr[i] == searchItemPtr)  // found ourself ??!!, maybe, but not sure !!
    {
      foundIndex = i;
    }
    else  // the index is not the right one. search the right index!
    { //COVINFO BLOCK: defensive (AP: OBJ Inconistent)
      foundIndex = p->findPtr(searchItemPtr);
      assert (foundIndex != DYNPTRARRAY_INVALID); // Inconistent ????
    } //COVINFO BLOCKEND

    size_t sz = (p->nofItemsInArray-foundIndex) * sizeof(Item *);
    if (sz)
      memmove (p->arrayPtr + foundIndex + 1, p->arrayPtr + foundIndex, sz);

    p->arrayPtr[foundIndex]= (Item *)itemPtr;
    p->nofItemsInArray += 1;
    p->isSorted = 0;
  }

  if (cleanupNeeded)
  { //COVINFO BLOCK: defensive (AP: OBJ Inconistent)
    DynPtrArray * recoveryPtr = p;

    // Process all ofthe objects, which were processed so far in the list
    for ( p = firstArrayPtr; p != recoveryPtr; p = p->nextArrayPtr)
    {
      foundIndex = p->findPtr(itemPtr);
      assert (foundIndex != DYNPTRARRAY_INVALID); // Inconistent ????

      size_t sz = (p->nofItemsInArray-1 - foundIndex) * sizeof(Item *);
      // copy back pointers, which were moved one time right
      if (sz)
        memmove (p->arrayPtr + foundIndex, p->arrayPtr + foundIndex + 1, sz);

      p->arrayPtr[p->nofItemsInArray] = 0;
      p->nofItemsInArray = savedNofItemsInArray;
    }
  } //COVINFO BLOCKEND

  //*********************************************************
  //* Critical Section End
  //*********************************************************

  // set / clear the error only for this object!
  if (cleanupNeeded)
  {
    i = DYNPTRARRAY_INVALID; //COVINFO LINE: defensive (AP: Inconistent)
  }

  return i;
}

  template<class Item>
DynPtrArrayIndex DynPtrArray<Item>::insertSortPtrUnique(const Item* itemPtr)
{
  // There are some copies, so update all of the attached objects!
  // first of all save the state of THIS object!
  int cleanupNeeded = 0;
  DynPtrArrayIndex returnIndex = DYNPTRARRAY_INVALID;
  DynPtrArrayIndex foundIndex = 0, indexBefore, indexAfter;
  Item *saveItemPtr = 0;
  PVSSboolean  selfFound = PVSS_FALSE;
  DynPtrArray * p;

  //*********************************************************
  //* Critical Section Start
  //* No return is allowed!!!!!
  //*********************************************************

  // Erst den eigenen Ptr rauswerfen. Das findItem dient, sicherzustellen, dass eine
  // binaere Suche erfolgt und keine lineare.
  if ( findItem(itemPtr) != DYNPTRARRAY_INVALID && cut(findPtr(itemPtr)) )
    selfFound = PVSS_TRUE;

  // Process all of the objects, which are hanging in the list
  for ( p = firstArrayPtr; p; p = p->nextArrayPtr)
  {
    // if Item has been changed, it should be found here and we have to sort the array due to the changes
    // otherwise its really new
    foundIndex = p->findItem(itemPtr,indexBefore,indexAfter);

    if (foundIndex == DYNPTRARRAY_INVALID)    // item does not exist, insert on right place
    {
      if (p->resizeArray(p->nofItemsInArray + 1) == DYNPTRARRAY_INVALID)
      { //COVINFO BLOCK: defensive (AP: out of memory)
        cleanupNeeded = 1;
        break;
      } //COVINFO BLOCKEND

      foundIndex = (indexAfter == DYNPTRARRAY_INVALID) ? p->nofItemsInArray : indexAfter;

      size_t sz = (p->nofItemsInArray-foundIndex) * sizeof(Item *);
      if (sz)
        memmove (p->arrayPtr + foundIndex + 1, p->arrayPtr + foundIndex, sz);

      p->arrayPtr[foundIndex]= (Item *)itemPtr;
      p->nofItemsInArray += 1;

      // Sortierung aendert sich nicht
      // p->isSorted = 1;
    }
    else    // item exists, do not resize array, change ptr only
    {
      // We shall find one item only once
      if (saveItemPtr)
      { //COVINFO BLOCK: defensive (AP: OBJ inconsistent)
        cleanupNeeded = 1;
        break;
      } //COVINFO BLOCKEND

      saveItemPtr = p->cutPtr(foundIndex);

      foundIndex = p->findItem(itemPtr,indexBefore,indexAfter);

      if (foundIndex != DYNPTRARRAY_INVALID)
      { //COVINFO BLOCK: defensive (AP: OBJ inconsistent)
        // More than one item found
        cleanupNeeded = 1;
        break;
      } //COVINFO BLOCKEND

      foundIndex = (indexAfter == DYNPTRARRAY_INVALID) ? p->nofItemsInArray : indexAfter;
      p->resizeArray(p->nofItemsInArray + 1);

      size_t sz = (p->nofItemsInArray-foundIndex) * sizeof(Item *);
      if (sz)
        memmove (p->arrayPtr + foundIndex + 1, p->arrayPtr + foundIndex, sz);

      p->arrayPtr[foundIndex]= (Item *)itemPtr;
      p->nofItemsInArray += 1;

      // Sortierung aendert sich nicht
      // p->isSorted = 1;
    }   // Item exists

    if (p == this)
      returnIndex = foundIndex;
  } // for (p)

  if (cleanupNeeded)
  { //COVINFO BLOCK: defensive (AP: OBJ inconsistent)
    DynPtrArray * recoveryPtr = p;

    // Process all ofthe objects, which were processed so far in the list
    for ( p = firstArrayPtr; p != recoveryPtr; p = p->nextArrayPtr)
    {
      foundIndex = p->findPtr(itemPtr);
      assert (foundIndex != DYNPTRARRAY_INVALID); // Inconistent ????

      size_t sz = (p->nofItemsInArray-1 - foundIndex) * sizeof(Item *);
      // copy back pointers, which were moved one time right
      if (sz)
        memmove ( p->arrayPtr + foundIndex, p->arrayPtr + foundIndex + 1, sz);

      p->arrayPtr[p->nofItemsInArray] = 0;
      p->nofItemsInArray--;
    }

    if (saveItemPtr || selfFound)
    {
      if (saveItemPtr)
        insertPtr(0, saveItemPtr);
      if (selfFound)
        insertPtr(0, itemPtr);
      sort();
    }
  }
  else  //COVINFO BLOCKEND
    delete saveItemPtr;    // only set if really added new item!

  //*********************************************************
  //* Critical Section End
  //*********************************************************

  // set / clear the error only for this object!
  if (cleanupNeeded)
  {
    returnIndex = DYNPTRARRAY_INVALID; //COVINFO LINE: defensive (AP: inconsistent)
  }

  return returnIndex;
}

  template<class Item>
DynPtrArrayIndex DynPtrArray<Item>::insertSortPtr(const Item* itemPtr, DynPtrArrayIndex check)
{
  // no unique key is checked!
  // There are some copies, so update all of the attached objects!
  // first of all save the state of THIS object!
  int cleanupNeeded = 0;
  DynPtrArrayIndex returnIndex = DYNPTRARRAY_INVALID;
  DynPtrArray * p;

  //*********************************************************
  //* Critical Section Start
  //* No return is allowed!!!!!
  //*********************************************************

  // Process all of the objects, which are hanging in the list
  for ( p = firstArrayPtr; p; p = p->nextArrayPtr)
  {
    DynPtrArrayIndex foundIndex;
    DynPtrArrayIndex indexBefore = DYNPTRARRAY_INVALID, indexAfter = DYNPTRARRAY_INVALID;

    // Array muss auf jedem Fall sortiert sein
    p->sort();

    // Try to insert at given position first
    if (check != DYNPTRARRAY_INVALID && check <= p->nofItemsInArray &&
        p->compareFunction && p->isSorted)
    {
      Item *before = (check > 0 ? p->arrayPtr[check-1] : 0);
      Item *after  = (check < p->nofItemsInArray ? p->arrayPtr[check] : 0);

      if ( (after  && ((*p->compareFunction)(itemPtr, after)  > 0)) ||
           (before && ((*p->compareFunction)(itemPtr, before) < 0))  )
      {
        // That was a bad guess, try to find the right position
        // Found index is the first equal item in the list. Insert at least one after this
        if ( (foundIndex = p->findItem(itemPtr, indexBefore, indexAfter)) != DYNPTRARRAY_INVALID )
          foundIndex++;
        else if (indexAfter != DYNPTRARRAY_INVALID)
          foundIndex = indexAfter;
        else
          foundIndex = p->nofItemsInArray;
      }
      else
      {
        foundIndex = check;
      }
    }
    else
    {
      // Found index is the first equal item in the list. Insert at least one after this
      if ( (foundIndex = p->findItem(itemPtr, indexBefore, indexAfter)) != DYNPTRARRAY_INVALID )
        foundIndex++;
      else if (indexAfter != DYNPTRARRAY_INVALID)
        foundIndex = indexAfter;
      else
        foundIndex = p->nofItemsInArray;
    }

    // check if array supports sort, if not, simply append item
    // How can we find an item without compareFunction ?
    if (! p->compareFunction)
    {
      if (p->resizeArray(p->nofItemsInArray + 1) == DYNPTRARRAY_INVALID)
      { //COVINFO BLOCK: defensive (AP: OBJ inconsistent)
        cleanupNeeded = 1;
        break;
      } //COVINFO BLOCKEND

      p->arrayPtr[p->nofItemsInArray] = (Item *) itemPtr;
      p->nofItemsInArray += 1;
    }
    else    // linear search
    {
      // Append at the end of equal items
      while ( (foundIndex < p->nofItemsInArray) &&
          ((*p->compareFunction)(itemPtr, p->getAt(foundIndex)) == 0)
          )
        foundIndex++;

      // OK, insert here
      if (p->resizeArray(p->nofItemsInArray + 1) == DYNPTRARRAY_INVALID)
      { //COVINFO BLOCK: defensive (AP: OBJ inconsistent)
        cleanupNeeded = 1;
        break;
      } //COVINFO BLOCKEND

      size_t sz = (p->nofItemsInArray-foundIndex) * sizeof(Item *);
      if (sz)
        memmove (p->arrayPtr + foundIndex + 1, p->arrayPtr + foundIndex, sz);

      p->arrayPtr[foundIndex]= (Item *)itemPtr;
      p->nofItemsInArray += 1;
    } // linear search

    if (p == this)
      returnIndex = foundIndex;
  }

  if (cleanupNeeded)
  { //COVINFO BLOCK: defensive (AP: OBJ inconsistent)
    DynPtrArray * recoveryPtr = p;

    // Process all ofthe objects, which were processed so far in the list
    for ( p = firstArrayPtr; p != recoveryPtr; p = p->nextArrayPtr)
    {
      DynPtrArrayIndex foundIndex = p->findPtr(itemPtr);
      assert (foundIndex != DYNPTRARRAY_INVALID); // Inconistent ????

      size_t sz = (p->nofItemsInArray-1 - foundIndex) * sizeof(Item *);
      // copy back pointers, which were moved one time right
      if (sz)
        memmove (p->arrayPtr + foundIndex, p->arrayPtr + foundIndex + 1, sz);

      p->arrayPtr[p->nofItemsInArray] = 0;
      p->nofItemsInArray--;
    }

    returnIndex = DYNPTRARRAY_INVALID;
  } //COVINFO BLOCKEND

  //*********************************************************
  //* Critical Section End
  //*********************************************************

  return returnIndex;
}


  template<class Item>
Item* DynPtrArray<Item>::cutPtr(DynPtrArrayIndex i)
{
  if (i == DYNPTRARRAY_INVALID || i >= nofItemsInArray)
    return 0;

  Item *searchItemPtr = getAt(i);

  // If there is no copy of this object, simple process only the object!!
  // This is actually the template, of 'what to do'.
  if (this == firstArrayPtr && !nextArrayPtr)
  {
    size_t sz = (nofItemsInArray-1 - i) * sizeof(Item *);

    if (sz)
      memmove(arrayPtr + i, arrayPtr + i + 1, sz);

    nofItemsInArray -= 1;
    resizeArray( nofItemsInArray ); // set back the size of the array, if neccassarx

    // hopefully the array stayed sorted, if it was!
    return searchItemPtr;
  }

  // There are some copies, so update all of the attached objects!
  // first of all save the state of THIS object!
  DynPtrArrayIndex foundIndex = 0;
  // DynPtrArrayIndex savedNofItemsInArray = nofItemsInArray;
  DynPtrArray * p;

  //*********************************************************
  //* Critical Section Start
  //* No return is allowed!!!!!
  //*********************************************************

  // Process all of the objects, which are hanging in the list
  for ( p = firstArrayPtr; p; p = p->nextArrayPtr)
  {
    // assert (p->nofItemsInArray == savedNofItemsInArray);

    // this should prevent runtime faults due to array inconsistencies
    // -- preventive hack that never should be needed
    if (! p->nofItemsInArray)
      continue;  //COVINFO LINE: defensive (AP: inconsistent)

    if (p->arrayPtr[i] == searchItemPtr)  // found ourself ??!!, maybe, but not sure!!
    {
      foundIndex = i;
    }
    else  // the index is not the right one. search the right index!
    {
      foundIndex = p->findPtr(searchItemPtr);
      assert (foundIndex != DYNPTRARRAY_INVALID); // Inconistent ????
    }

    size_t sz = (p->nofItemsInArray-1 - foundIndex) * sizeof(Item *);

    if (sz)
      memmove (p->arrayPtr + foundIndex, p->arrayPtr + foundIndex + 1, sz);

    p->nofItemsInArray -= 1;
    p->resizeArray( p->nofItemsInArray ); // set back the size of the array, if neccassary
    // hopefully the array stayed sorted, if it was!
  }

  //*********************************************************
  //* Critical Section End
  //*********************************************************

  return searchItemPtr;
}


  template<class Item>
Item * DynPtrArray<Item>::replaceAt(DynPtrArrayIndex idx, Item *itemPtr)
{
  if (idx == DYNPTRARRAY_INVALID || idx >= nofItemsInArray)
    return 0;

  Item *searchItemPtr = getAt(idx);

  // If there is no copy of this object, simple process only the object!!
  // This is actually the template, of 'what to do'.
  if (this == firstArrayPtr && !nextArrayPtr)
  {
    arrayPtr[idx] = itemPtr;
    isSorted = 0;

    return searchItemPtr;
  }
  //COVINFO BLOCK: defensive (AP: OBJ inconsistent)
  // There are some copies, so update all of the attached objects!
  // first of all save the state of THIS object!
  DynPtrArrayIndex foundIndex = 0;
  // DynPtrArrayIndex savedNofItemsInArray = nofItemsInArray;
  DynPtrArray * p;

  //*********************************************************
  //* Critical Section Start
  //* No return is allowed!!!!!
  //*********************************************************

  // Process all of the objects, which are hanging in the list
  for ( p = firstArrayPtr; p; p = p->nextArrayPtr)
  {
    // assert (p->nofItemsInArray == savedNofItemsInArray);

    // this should prevent runtime faults due to array inconsistencies
    // -- preventive hack that never should be needed
    if (! p->nofItemsInArray)
      continue;

    if (p->arrayPtr[idx] == searchItemPtr)  // found ourself ??!!, maybe, but not sure!!
    {
      foundIndex = idx;
    }
    else  // the index is not the right one. search the right index!
    {
      foundIndex = p->findPtr(searchItemPtr);
      assert (foundIndex != DYNPTRARRAY_INVALID); // Inconistent ????
    }

    p->arrayPtr[foundIndex] = itemPtr;
    p->isSorted = 0;
  }

  //*********************************************************
  //* Critical Section End
  //*********************************************************
  
  return searchItemPtr;
} //COVINFO BLOCKEND

// ######################################################################################
// # End of Functions, which contain critical sections
// ######################################################################################

template<class Item>
Item * DynPtrArray<Item>::replaceOrSetAt(DynPtrArrayIndex idx, Item *itemPtr)
{
  if (idx >= nofItemsInArray) //do we have to call setPtr?
  {
    setPtr(idx, itemPtr);
    return 0;
  }

  // index already exists -> replace
  return replaceAt(idx, itemPtr);
}


  template<class Item>
void  DynPtrArray<Item>::removeRange(DynPtrArrayIndex start, DynPtrArrayIndex end)
{
  if ( (start == DYNPTRARRAY_INVALID) || (end == DYNPTRARRAY_INVALID) )
    return;

  if (start > nofItemsInArray)
    return;

  if (end >= nofItemsInArray)
    end = nofItemsInArray - 1;

  if (this == firstArrayPtr && !nextArrayPtr)
  {
    for (DynPtrArrayIndex idx = start; idx <= end; idx++)
      delete arrayPtr[idx];

    size_t sz = (nofItemsInArray - (end + 1)) * sizeof(Item *);
    if (sz)
      memmove(arrayPtr + start, arrayPtr + end + 1, sz);

    nofItemsInArray -= (end - start + 1);

    resizeArray( nofItemsInArray ); // set back the size of the array, if neccassary
  }
  else
  {
    for (DynPtrArrayIndex idx = end; idx >= start; idx--)
      remove(idx);
  }
}


  template<class Item>
DynPtrArrayIndex DynPtrArray<Item>::insertItemOnlyIfNotFound(const Item *itemPtr)
{
  DynPtrArrayIndex indexBefore, indexAfter, returnIndex;

  returnIndex = DYNPTRARRAY_INVALID;

  if ( findItem(itemPtr, indexBefore, indexAfter)== DYNPTRARRAY_INVALID)
  {
    // Store the temporary after find, because find may sort the array!!!
    int tmpIsSorted = isSorted;

    // If this Item would be the last or there are No Items in the array
    // than set itemPtr at the last place in the array
    if (indexAfter == DYNPTRARRAY_INVALID)
    {
      returnIndex = setPtr(nofItemsInArray, itemPtr);
    }
    // We know, where to insert!
    else
    {
      returnIndex = insertPtr(indexAfter, itemPtr);
    }
    // If the array originally sorted was, restore the state.
    // next time you do NOT have to sort again, if you want to search!
    isSorted = tmpIsSorted;
  }

  return returnIndex;
}

  template<class Item>
DynPtrArrayIndex DynPtrArray<Item>::updateItemOrInsertIfNotFound(const Item *itemPtr)
{
  DynPtrArrayIndex indexBefore, indexAfter, foundIndex, returnIndex;

  returnIndex = DYNPTRARRAY_INVALID;
  foundIndex = findItem(itemPtr, indexBefore, indexAfter);

  // Store the temporary after find, because find may sort the array!!!
  int tmpIsSorted = isSorted;

  // Not found, so insert it!
  if (foundIndex == DYNPTRARRAY_INVALID)
  {
    // If this Item would be the last or there are No Items in the array
    // than set itemPtr at the last place in the array
    if (indexAfter == DYNPTRARRAY_INVALID) {
      returnIndex = setPtr(nofItemsInArray, itemPtr);
    }
    // We know, where to insert!
    else
    {
      returnIndex = insertPtr(indexAfter, itemPtr);
    }
  }
  else
  {
    // We have found the Item! They key is the same after the update,
    // so the array must stay sorted, if it was !!!!
    Item *tmpItemPtr = getAt(foundIndex);
    returnIndex = setPtr(foundIndex, itemPtr);
    if (returnIndex != DYNPTRARRAY_INVALID)
      delete tmpItemPtr;
  }

  // If the array originally sorted was, restore the state.
  // next time you do NOT have to sort again, if you want to search!
  isSorted = tmpIsSorted;

  return returnIndex;
}

  template<class Item>
void DynPtrArray<Item>::clear()
{
  reinit(0);
}

  template<class Item>
void DynPtrArray<Item>::reinit(DynPtrArrayIndex newLen)
{
  while (nofItemsInArray--)
    delete arrayPtr[nofItemsInArray];

  // Process all of the objects, which are hanging in the list
  for (DynPtrArray *p = firstArrayPtr; p; p = p->nextArrayPtr)
  {
    p->nofItemsInArray = 0;
    p->resizeArray(newLen);
  }
}

//--------------------------------------------------------------------------------

  template<class Item>
DynPtrArrayIndex DynPtrArray<Item>::resizeArray(DynPtrArrayIndex newSize)
{
  Item ** tmpPtr = 0;
  DynPtrArrayIndex targetSize;

  if (newSize > sizeOfTheArray)
  {
    if (newSize <= SINGLEALLOCATEBOUND)
      targetSize = newSize;
    else
    {
      DynPtrArrayIndex nextSize;
      targetSize = sizeOfTheArray;
      if (targetSize <= SINGLEALLOCATEBOUND)
        targetSize = SINGLEALLOCATEBOUND;
      while (targetSize < newSize)
      {
        nextSize = static_cast<DynPtrArrayIndex>(targetSize*ALLOCATEFACTOR + 0.5); //always ceil to avoid endless loop
        if (nextSize < targetSize || //overflow
            nextSize > UINT_MAX / sizeof(Item **))
          return DYNPTRARRAY_INVALID;
        targetSize = nextSize;
      }
    }

    tmpPtr = (Item **)realloc(arrayPtr, (targetSize) * sizeof(Item **));

    if (!tmpPtr) //we do not get the mem we want - so try to get the memory the caller wants
    { //COVINFO BLOCK: defensive (AP: out of memory)
      targetSize = newSize;
      tmpPtr = (Item **)realloc(arrayPtr, (targetSize) * sizeof(Item **));
    } //COVINFO BLOCKEND

    if (tmpPtr)
    {
      memset(tmpPtr + sizeOfTheArray, 0, (targetSize - sizeOfTheArray) * sizeof(Item **));
      arrayPtr = tmpPtr;
      sizeOfTheArray = targetSize;
      return  sizeOfTheArray;
    }
    else
      return DYNPTRARRAY_INVALID; //COVINFO LINE: defensive (AP: out of memory)
  }
  else if (newSize < sizeOfTheArray)
  {
    if (newSize < nofItemsInArray) //if we free used elements, this can cause an leak - so do not allow it
      newSize = nofItemsInArray;

    if (newSize <= SINGLEALLOCATEBOUND)
      targetSize = newSize;
    else
    {
      targetSize = sizeOfTheArray;
      while (static_cast<DynPtrArrayIndex>(targetSize*ALLOCHYSTFACTOR) > newSize) //while still under hist bound
      {
        targetSize = static_cast<DynPtrArrayIndex>(targetSize/ALLOCATEFACTOR); //always floor to avoid endless loop
      }
    }

    if (targetSize == sizeOfTheArray) //we do not have to realloc - already there
      return sizeOfTheArray;

    // extra code because win32 is not posix ...
    if (targetSize == 0)
    {
      free (arrayPtr);
      tmpPtr = 0;
      isSorted = 0;
    }
    else
    {
      // this was the original behaviour
      tmpPtr= (Item **)realloc(arrayPtr, (targetSize) * sizeof(Item **));
    }

    if (!tmpPtr && targetSize > 0)
      return DYNPTRARRAY_INVALID;
    else
    {
      arrayPtr = tmpPtr;
      sizeOfTheArray = targetSize;

      if ( lastAccessedIndex >= sizeOfTheArray )
        lastAccessedIndex = DYNPTRARRAY_INVALID;

      if ( lastFoundIndex >= sizeOfTheArray )
        lastFoundIndex = DYNPTRARRAY_INVALID;

      return  sizeOfTheArray;
    }
  }

  return sizeOfTheArray;
}

//--------------------------------------------------------------------------------

template<class Item>
DynPtrArrayIndex DynPtrArray<Item>::findItemByLinearSearch(const Item *itemPtr) const
{
  DynPtrArrayIndex i;
  int (*compare)(const Item *, const Item *);

  if (compareFunction && nofItemsInArray)
  {
    Item **p = arrayPtr;
    compare = compareFunction;

    if (lastFoundIndex < nofItemsInArray && (*compare)(itemPtr, p[lastFoundIndex]) == 0)
      return lastFoundIndex;

    for (i = nofItemsInArray; i--;)
      if ((*compare)(itemPtr, p[i]) == 0)
        return ( ((DynPtrArray<Item> *) this)->lastFoundIndex = i);    // mutable
  }

  return DYNPTRARRAY_INVALID;
}

  template<class Item>
DynPtrArrayIndex DynPtrArray<Item>::findItem(const Item *itemPtr, DynPtrArrayIndex & indexBefore, DynPtrArrayIndex &indexAfter)
{
  indexBefore = DYNPTRARRAY_INVALID;
  indexAfter = DYNPTRARRAY_INVALID;

  if (compareFunction && nofItemsInArray)
  {
    if (!isSorted)
      sort();

    DynPtrArrayIndex  found;
    found = findItemIfSorted(itemPtr, indexBefore, indexAfter);

    return found;
  }

  return DYNPTRARRAY_INVALID;
}


template<class Item>
DynPtrArrayIndex DynPtrArray<Item>::findItemIfSorted(const Item *itemPtr,
    DynPtrArrayIndex &indexBefore, DynPtrArrayIndex &indexAfter) const
{
  indexBefore = DYNPTRARRAY_INVALID;
  indexAfter = DYNPTRARRAY_INVALID;

  // Don't panic if there is only one item in Array
  if (!nofItemsInArray || !compareFunction ||
      (!isSorted && (nofItemsInArray > 1)) )
    return DYNPTRARRAY_INVALID;

  int (*compare)(const Item *, const Item *);

  compare   = compareFunction;
  Item **p  = arrayPtr;

  int cond = 0;
  DynPtrArrayIndex mid    = 0;
  DynPtrArrayIndex low = 0;
  DynPtrArrayIndex high = nofItemsInArray - 1;

  if (lastFoundIndex < nofItemsInArray)
  {
    if ( (cond = (*compare)(itemPtr, p[lastFoundIndex])) == 0 )
    {
      Item **ptr = (Item **) (p + lastFoundIndex - 1);

      while (lastFoundIndex && !(*compare)(itemPtr, *ptr))
      {
        ptr--;
        (((DynPtrArray<Item> *) this)->lastFoundIndex)--;
      }

      indexBefore = lastFoundIndex ? lastFoundIndex -1 : DYNPTRARRAY_INVALID;
      indexAfter = lastFoundIndex < (nofItemsInArray - 1) ? lastFoundIndex +1 : DYNPTRARRAY_INVALID;
      return lastFoundIndex;
    }
    else if (cond < 0)
    {
      if (lastFoundIndex)
        high = lastFoundIndex - 1;
      else
      {
        indexBefore = DYNPTRARRAY_INVALID;
        indexAfter = lastFoundIndex;
        return ( ((DynPtrArray<Item> *) this)->lastFoundIndex = DYNPTRARRAY_INVALID);
      }
    }
    else
    {
      if (lastFoundIndex < (nofItemsInArray-1))
        low = lastFoundIndex + 1;
      else
      {
        indexBefore = lastFoundIndex;
        indexAfter = DYNPTRARRAY_INVALID;
        return ( ((DynPtrArray<Item> *) this)->lastFoundIndex = DYNPTRARRAY_INVALID);
      }
    }
  }


  while (low <= high)
  {
    mid = low + (high - low) / 2;
    if ((cond = (*compare)( itemPtr, p[mid] )) < 0)
    {
      // if (mid == 0)
      //   break;

      if (mid == low)
        break;
      high = mid - 1;
    }
    else if (cond > 0)
    {
      if (mid == high)
        break;
      low = mid + 1;

      // if (low == 0)
      //   break;
    }
    else
    {
      // Goto first Item
      Item **ptr = (Item **) (p + mid - 1);

      while ( mid && !(*compare) (itemPtr, *ptr) )
      {
        ptr--;
        mid--;
      }

      indexBefore = mid ? mid -1 : DYNPTRARRAY_INVALID;
      indexAfter = mid < (nofItemsInArray - 1) ? mid +1 : DYNPTRARRAY_INVALID;
      return ( ((DynPtrArray<Item> *) this)->lastFoundIndex = mid); /* match ptr */
    }
  }

  if (cond < 0)
  {
    indexBefore = mid ? mid -1 : DYNPTRARRAY_INVALID;
    indexAfter = mid;
  }
  else  // cond > 0!
  {
    indexBefore = mid;
    indexAfter  = mid < (nofItemsInArray - 1) ? mid +1 : DYNPTRARRAY_INVALID;
  }

  return ( ((DynPtrArray<Item> *) this)->lastFoundIndex = DYNPTRARRAY_INVALID);
}



  template <class Item>
void DynPtrArray<Item>::insertionSort(DynPtrArrayIndex first, DynPtrArrayIndex last)
{
  Item *prevVal = arrayPtr[first];
  Item *curVal;

  for (DynPtrArrayIndex indx = first + 1; indx <= last; ++indx)
  {
    curVal = arrayPtr[indx];

    if ( (*compareFunction)(prevVal, curVal) > 0 )
    {
      // Out of order: arrayPtr[indx-1] > arrayPtr[indx]
      DynPtrArrayIndex  indx2;
      arrayPtr[indx] = prevVal;  // Move up larger item first

      for (indx2 = indx - 1; indx2 > first; indx2--)
      {
        Item *tempVal = arrayPtr[indx2-1];

        if ( (*compareFunction)(tempVal, curVal) > 0 )
        {
          // Still out of order, move 1 up
          arrayPtr[indx2] = tempVal;
        }
        else
          break;
      } // for (indx2)

      arrayPtr[indx2] = curVal;
    }
    else
    {
      // In order, advance to next element
      prevVal = curVal;
    }
  }
}



  template <class Item>
void DynPtrArray<Item>::quickSort(DynPtrArrayIndex first, DynPtrArrayIndex last)
{
  if (last - first <= 16)
  {
    insertionSort(first, last);
    return;
  }

#define  swap(x, y) {Item *tmp = arrayPtr[x]; arrayPtr[x] = arrayPtr[y]; arrayPtr[y] = tmp;}

  DynPtrArrayIndex  up = last, down = first;
  DynPtrArrayIndex  med = (first + last) >> 1;

  // Choose pivot from first, last and median position
  if ( (*compareFunction)(arrayPtr[first], arrayPtr[last]) > 0)
    swap(first, last);

  if ( (*compareFunction)(arrayPtr[first], arrayPtr[med]) > 0 )
    swap(first, med);

  if ( (*compareFunction)(arrayPtr[med], arrayPtr[last]) > 0)
    swap(med, last);

  Item *pivot = arrayPtr[med];

  for (;;)
  {
    while ( (*compareFunction)(pivot, arrayPtr[++down]) > 0 );
    while ( (*compareFunction)(arrayPtr[--up], pivot) > 0 );

    if (up > down)
      swap(down, up)
    else
      break;
  }

  // Sort smaller partition first, then the larger
  if ( (up - first + 1) >= (last - up) )
  {
    quickSort(up+1, last);
    quickSort(first, up);
  }
  else
  {
    quickSort(first, up);
    quickSort(up+1, last);
  }

# undef  swap
}

  template<class Item>
void DynPtrArray<Item>::mergeSort(DynPtrArrayIndex first, DynPtrArrayIndex last)
{
  const DynPtrArrayIndex INSERTION_SORT_BOUND = 8; // boundary point to use insertion sort

  DynPtrArrayIndex span;   // step width
  DynPtrArrayIndex lb;     // lower bound
  DynPtrArrayIndex ub;     // upper bound
  DynPtrArrayIndex indx;
  DynPtrArrayIndex indx2;
  DynPtrArrayIndex len = last - first + 1;

  if (len <= 1)
    return;

  span = INSERTION_SORT_BOUND;

  // insertion sort the first pass
  {
    Item *prevItem;
    Item *curItem;
    Item *tempItem;

    for (lb = first; lb <= last; lb += span)
    {
      if ((ub = lb + span) > last)
        ub = last;

      prevItem = arrayPtr[lb];

      for (indx = lb + 1; indx <= ub; ++indx)
      {
        curItem = arrayPtr[indx];

        if ((*compareFunction)(prevItem, curItem) > 0)
        {
          // out of order: array[indx-1] > array[indx]
          arrayPtr[indx] = prevItem; // move up the larger item first

          // find the insertion point for the smaller item
          for (indx2 = indx - 1; indx2 > lb;)
          {
            tempItem = arrayPtr[indx2 - 1];
            if ((*compareFunction)(tempItem, curItem) > 0)
            {
              arrayPtr[indx2--] = tempItem;
              // still out of order, move up 1 slot to make room
            }
            else
              break;
          }
          arrayPtr[indx2] = curItem; // insert the smaller item right here
        }
        else
        {
          // in order, advance to next element
          prevItem= curItem;
        }
      }
    }
  }

  // second pass merge sort
  {
    DynPtrArrayIndex median;
    Item** aux;

    aux = (Item**) malloc(sizeof(Item *) * len / 2);

    while (span < len)
    {
      // median is the start of second file
      for (median = first + span; median <= last;)
      {
        indx2 = median - 1;
        if ((*compareFunction)(arrayPtr[indx2], arrayPtr[median]) > 0)
        {
          // the two files are not yet sorted
          if ((ub = median + span) > last)
          {
            ub = last;
          }

          // skip over the already sorted largest elements
          while ((*compareFunction)(arrayPtr[--ub], arrayPtr[indx2]) >= 0)
          {
          }

          // copy second file into buffer
          for (indx = first; indx2 < ub; ++indx)
          {
            aux[indx - first] = arrayPtr[++indx2];
          }
          --indx;
          indx2 = median - 1;
          lb = median - span;
          // merge two files into one
          for (;;)
          {
            if ((*compareFunction)(aux[indx - first], arrayPtr[indx2]) >= 0)
            {
              arrayPtr[ub--] = aux[indx - first];
              if (indx > first)
                --indx;
              else
              {
                // second file exhausted
                for (;;)
                {
                  arrayPtr[ub--] = arrayPtr[indx2];
                  if (indx2 > lb)
                    --indx2;
                  else
                    goto mydone; // done
                }
              }
            }
            else
            {
              arrayPtr[ub--] = arrayPtr[indx2];
              if (indx2 > lb)
                --indx2;
              else
              {
                // first file exhausted
                for (;;)
                {
                  arrayPtr[ub--] = aux[indx - first];
                  if (indx > first)
                    --indx;
                  else
                    goto mydone; // done
                }
              }
            }
          } // for (;;) merge two files into one
        }
mydone:
        median += span + span;
      }
      span += span;
    }

    free(aux);
  }
}


  template<class Item>
void DynPtrArray<Item>::sort()
{
  if (isSorted)
    return;

  if (!compareFunction)
    return;

  // That's easy :)
  if (nofItemsInArray <= 1)
  {
    isSorted = 1;
    return;
  }

  // -------------------------------------

  quickSort(0, nofItemsInArray-1);

  // -------------------------------------
  isSorted = 1;
}


  template<class Item>
void DynPtrArray<Item>::sort(DynPtrArrayIndex start, DynPtrArrayIndex end)
{
  if (isSorted)
    return;

  if (!compareFunction)
    return;

  if (end - start <= 1)
    return;

  if (start >= nofItemsInArray || end >= nofItemsInArray)
    return;

  quickSort(start, end);
}


  template<class Item>
void DynPtrArray<Item>::stableSort()
{
  if (isSorted)
    return;

  if (!compareFunction)
    return;

  // That's easy :)
  if (nofItemsInArray <= 1)
  {
    isSorted = 1;
    return;
  }

  mergeSort(0, nofItemsInArray-1);

  isSorted = 1;
}

  template<class Item>
void DynPtrArray<Item>::stableSort(DynPtrArrayIndex start, DynPtrArrayIndex end)
{
  if (isSorted)
    return;

  if (!compareFunction)
    return;

  if (end - start <= 1)
    return;

  if (start >= nofItemsInArray || end >= nofItemsInArray)
    return;

  mergeSort(start, end);
}

//-------------------------------------------------------------------------
//--
//-------------------------------------------------------------------------
  template<class Item>
PVSSboolean DynPtrArray<Item>::unique()
{
  if (!compareFunction)
    return(PVSS_FALSE);


  if (nofItemsInArray < 2 )
    return(PVSS_TRUE);

  DynPtrArrayIndex oneBeforeLast = nofItemsInArray - 1;
  for (DynPtrArrayIndex i = 0; i < oneBeforeLast; i++ )
  {
    if (arrayPtr[i] == 0)
      continue;

    DynPtrArrayIndex j = 0;
    for (j = i+1; j <= oneBeforeLast; j++ )
    {
      if ( (*compareFunction)(arrayPtr[i], arrayPtr[j]) == 0 )
      {
         remove(j);
         j--;
         oneBeforeLast--;
      }
      else if (isSorted)
      {
        break;
      }
    }
  }

  return(PVSS_TRUE);
}

#endif

