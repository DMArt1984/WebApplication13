#ifndef _MAXTIMEACCU_H_
#define _MAXTIMEACCU_H_

// Author: Heinz MEISSL
// Date:   14.4.1997
// Purpose: implement a statistic Accumulator to determine the time of maximum within a period

#ifndef _SIMPLEACCU_H_
#include <SimpleAccu.hxx>
#endif

#ifndef _VARIABLE_H_
#include <Variable.hxx>
#endif

#ifndef _TIMEVAR_H_
#include <TimeVar.hxx>
#endif

/** A value accumulator class. 
    This class is used to get the maximum time value.
    An internal time value is checked every time the accumulate function is called.

    @classification ETM internal
*/
class DLLEXP_OABASICS MaxTimeAccu: public SimpleAccu
{
  public:
    /** Constructor.
        @param  aVarType The type identifier, for which the accumulatior is created.
    */
    MaxTimeAccu(const VariableType aVarType);
    /// Destructor
    virtual ~MaxTimeAccu();
    
    /** Accumulate value/time pair.
        Call this function to add the value/time pair to accumulated value.
        @param  theValue The value to be added.
        @param  atTime Timestamp of the value.
    */
    virtual void accumulate(const Variable &theValue, const TimeVar &atTime );
    /// Get the accumulated value.
    virtual const Variable &getResult();
    /** Get the intermediate accumulated value.
        @param  theValue Not used.
        @param  start Timestamp of the value.
    */
    virtual const Variable &getIntermResult(  const Variable &theValue, const TimeVar &start, 
                                                     const TimeVar &/*stop*/, bool /*valid*/ );
    /// Reset the accumulated value.
    virtual void reset();
    
  protected:
  
  private:
    MaxTimeAccu(const MaxTimeAccu &);
    MaxTimeAccu &operator=(const MaxTimeAccu &);
  
    Variable *theMax;
    TimeVar theMaxTime;
};

#endif
