#ifndef _TRYSMENT_H_
#define _TRYSMENT_H_

#include <CtrlSment.hxx>

#include <iostream>

class CtrlExpr;

class DLLEXP_CTRL TrySment : public CtrlSment
{
  public:
    class DLLEXP_CTRL TryBlock : public CtrlSment
    {
      public:
        TryBlock(TrySment *t, CtrlSment *s) : CtrlSment(s->getCurrentLine(), s->getFileNumber()), trySment(t), smentList(s) {}
        ~TryBlock() {delete smentList;}

        virtual void writeTrace(CtrlThread *t, bool wv = true) const
        {
          std::cerr << "try";
        }

        virtual bool checkIntegrity(const CharString &location, CtrlThread *thread) const;
        virtual void dumpCoverageTree(std::ostream &to, CoverageAction action = DUMP) const;

        virtual const CtrlSment *execute(CtrlThread *thread) const;
        virtual const CtrlSment *getNext(CtrlThread *) const;

      private:
        TrySment  *trySment;
        CtrlSment *smentList;

        friend class EditorWidget;
    };


    class DLLEXP_CTRL CatchBlock : public CtrlSment
    {
      public:
        CatchBlock(CtrlSment *s) : CtrlSment(s->getCurrentLine(), s->getFileNumber()), smentList(s) {}
        ~CatchBlock() {delete smentList;}

        virtual void writeTrace(CtrlThread *t, bool wv = true) const
        {
          std::cerr << "catch";
        }

        virtual bool checkIntegrity(const CharString &location, CtrlThread *thread) const;
        virtual void dumpCoverageTree(std::ostream &to, CoverageAction action = DUMP) const;

        virtual const CtrlSment *execute(CtrlThread *thread) const;

      private:
        CtrlSment *smentList;

        friend class EditorWidget;
    };


    class DLLEXP_CTRL FinallyBlock : public CtrlSment
    {
      public:
        FinallyBlock(CtrlSment *s) : CtrlSment(s->getCurrentLine(), s->getFileNumber()), smentList(s) {}
        ~FinallyBlock() {delete smentList;}

        virtual void writeTrace(CtrlThread *t, bool wv = true) const
        {
          std::cerr << "finally";
        }

        virtual bool checkIntegrity(const CharString &location, CtrlThread *thread) const;
        virtual void dumpCoverageTree(std::ostream &to, CoverageAction action = DUMP) const;

        virtual const CtrlSment *execute(CtrlThread *thread) const;

      private:
        CtrlSment *smentList;

        friend class EditorWidget;
    };

  public:
    TrySment(CtrlSment *e1, CtrlSment *e2, CtrlSment *e3, int line, int filenum);
    ~TrySment();

    /// CtrlSment nach dem TrySment
    virtual void setNext(CtrlSment *n);

    /** Wertet if(cond) aus und returns abhaengig davon das naechste CtrlSment.
      * (then zweig, else zweig oder das Statement nach dem IF)
      */
    virtual const CtrlSment *execute(CtrlThread *thread) const;

    /// Gewichtung des CtrlSment
    virtual SmentWeight getWeight() const { return SM_WT_Low; }

    virtual bool checkIntegrity(const CharString &location, CtrlThread *thread) const;

    /** Is the sment of the specified type ?
      * @param type given type
      * @return TRUE  Sment is of type "type"
      * @return FALSE Sment is not of type "type"
      */
    virtual int isA(SmentType type) const { return (type == SMENT_TRY); }

    const TryBlock *getTryBlock() const { return tryBlock; }
    const CatchBlock *getCatchBlock() const { return catchBlock; }
    const FinallyBlock *getFinallyBlock() const { return finallyBlock; }

    /** dump the whole tree for code coverage analysis
        @param to output stream
      */
    virtual void dumpCoverageTree(std::ostream &to, CoverageAction action = DUMP) const;

  private:
    TryBlock *tryBlock;
    CatchBlock *catchBlock;
    FinallyBlock *finallyBlock;
};

//--------------------------------------------------------------------------------

inline TrySment::~TrySment()
{
  delete tryBlock;
  delete catchBlock;
  delete finallyBlock;
}

#endif

