#ifndef _NewExpr_H_
#define _NewExpr_H_

#include <CtrlExpr.hxx>
#include <TypeSpec.hxx>
class FCall;
class ExprList;

class DLLEXP_CTRL NewExpr : public CtrlExpr
{
  public:
    NewExpr(const TypeSpec &spec, int line, int filenum);

    virtual ~NewExpr();

    void setArgList(ExprList *args);  // for user-defd class
    void setArgument(CtrlExpr *arg);  // for basic datatype

    virtual ExprType isA() const { return NEW_EXPR; }

    virtual const CtrlSment *execute(CtrlThread *thread) const;

    virtual const Variable *evaluate(CtrlThread *thread) const;

    virtual const CtrlExpr *getFirstExpr(CtrlThread *thread) const;

    virtual SmentWeight getWeight() const { return SM_WT_Medium; }

    virtual void writeTrace(CtrlThread *thread, bool writeValue = true) const;

    virtual void dumpCoverageTree(std::ostream &to, CoverageAction action = DUMP) const;

  private:
    TypeSpec typeSpec;
    CtrlExpr *argument = nullptr;  // init value of non-class datatype
    FCall *ctor = nullptr;
};

#endif
