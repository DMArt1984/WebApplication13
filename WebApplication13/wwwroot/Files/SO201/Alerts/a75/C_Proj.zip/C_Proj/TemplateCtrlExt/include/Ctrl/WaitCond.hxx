#ifndef _WAITCOND_H_
#define _WAITCOND_H_

#include <Types.hxx>

class TimeVar;

/*  author Martin Koller */
/** This is an abstract base class.
  * This class handles a wait-condition in a CtrlThread; that means
  * if the thread must wait for some event to occur, e.g. a timer expires or
  * a DP response, then this event checking can be implemented in a derived class.
*/

class DLLEXP_CTRL WaitCond
{
  public:
    /// Destructor
    virtual ~WaitCond();

    /** when shall we call checkDone at the latest. Default is immediately.
        This is a hint and tells the Control engine that it is not needed
        to call checkDone() before this given timestamp, but the Control
        engine will call checkDone whenever it sees fit to do so, even before
        this timestamp.
        We also need "non const" nextCheck == nextCheckAt().
        you only need to implement one of these two.
    */
    virtual const TimeVar &nextCheckAt();

    /** when shall we call checkDone at the latest. Default is immediately.
        You only need to implement one of these two.
    */
    virtual const TimeVar &nextCheck() const;

    /** checks if the wait condition has finished
        @return 1 (true) if the condition we wait for has been reached
                0 (false) otherwise. The CtrlThread will not be continued
                until this method returns true.
    */
    virtual int checkDone() = 0;

    /// checks if a HotLink connect is finished
    virtual int hotLinkDone() { return 0; }
};

#endif /* _WAITCOND_H_ */
