// -----------------------------------------------------------------------------
// creator: Andras Horvath - 01.09.2017
// purpose: Interface for creating an SSL Key
// -----------------------------------------------------------------------------
#ifndef _KEYSSL_HXX_
#define _KEYSSL_HXX_

#include <Key.hxx>
#include <memory>
#include <string>

/**
  @class KeySsl
  @brief The KeySsl class
         implements a private and public Key stored in PEM files.
         This class implements the singing, verifying and checking of
         keys and signatures, as well as loading private keys, certificate and
         PEM files and the serialization of an KeySsl object
*/
class DLLEXP_OABASICS KeySsl : public Key
{
public:
  /// destructor
  ~KeySsl() override;

  /**
    @brief   Create a digital signature with a KeySsl.
    @details This function signs the given data with the private key.
             Can be used only with private keys.
    @param   data       Blob data to sign
    @param   signature  returning Signature object containing the signated data
    @return             0 if successful
  */
  int sign(const Blob& data, Signature& signature) const override;

  /**
    @brief   Verifies the validity of a KeySsl.
             Can be used only with public keys (certificates).
    @details This function verifies the public key against the crlFile and the
             caFile lists.
             The KeySsl must be a valid X.509 certificate signed by caFile Root
             or intermediate certificate and must not be revoked in crlFile.
    @param   crlFiles     Certificate Revocation Lists.
    @param   caFiles      CA lists
    @param   chainPrefix  this parameter is not used for KeySsl
    @param   verifyTime   this parameter is not used for KeySsl
    @return               0 if certificate is valid and not revoked,
                          else error code
  */
  int verify(const Key::CrlList& crlFiles,
             const Key::CaList& caFiles,
             const std::string& chainPrefix,
             bool verifyTime = true) const override;

  /**
    @brief  Checks a digital signature with the KeySsl.
            Can be used only with public keys (certificates).
    @param  data       Blob data that was signed
    @param  signature  the Signature object containing the digital signature
    @return            0 if signature is valid, else error code
  */
  int checkSignature(const Blob& data,
                     const Signature& signature) const override;

  /**
    @brief  Seals an envelope
            Can be used only with public keys.
    @param  inputData  Blob data that has to be encrypted
    @param  sealedData the output encrypted data
    @return            0 if successful, else error code
  */
  virtual int sealEnvelope(const Blob& inputData,
                           Blob& sealedData) const override;

  /**
    @brief  Opens an envelope
            Can be used only with private keys.
    @param  sealedData the input encrypted data
    @param  outputData  the decrypted output Blob data
    @return            0 if successful, else error code
  */
  virtual int openEnvelope(const Blob& sealedData,
                           Blob& outputData) const override;

  /**
    @brief  Gets the common name field (CN) of a certificate.
    @param  componentName  component name, if empty, returns the whole common
                           name string
    @return                common name of the certificate
  */
  std::string getCommonName(const std::string& componentName) const override;

  /**
    @brief   Construct a new instance of the KeySsl class.
    @details This function implements how to create a key based on a Key::Type
             and a file path.
    @param   keyType      type of the Key
    @param   filePath     path to the file holding the key in PEM format
    @param   verifyTime   this parameter is not used for KeySsl
    @return               created Key object based on parameters
  */
  static SmartKey create(Key::Type keyType,
                         const std::string& filePath,
                         bool verifyTime = true);

  /**
    @brief   Construct a new instance of the KeySsl class.
    @details This function implements how to create a key based on a previously
             JSON serialized Key object.
             Only public keys can be created with this function.
    @param   jsonData    JSON serialized representation of Key subclass object
    @param   verifyTime  this parameter is not used for KeySsl
    @return              created Key object based on parameters
  */
  static SmartKey create(Key::Type keyType,
                         const QJsonObject& jsonData,
                         bool verifyTime = true);

  static SmartKey createFromPEM(Key::Type keyType, const std::string& PEMdata);

  static int generateRSAKeyPair(std::string& publicPEM,
                                std::string& privatePEM,
                                int bits = 2048);

private:
  /// constructor from config entry
  KeySsl(Key::Type keyType,
         const std::string& filePath,
         bool verifyTime = true);

  /// constructor from json object
  KeySsl(Key::Type keyType,
         const QJsonObject& jsonData,
         bool verifyTime = true);

  /// constructor from external data
  KeySsl(Key::Type keyType,
         const std::string& format,
         const std::string& data);

  class KeySslImpl;

#ifdef _WIN32
#  pragma warning(push)
#  pragma warning(disable : 4251)
#endif
  std::unique_ptr<KeySslImpl> m_impl;
#ifdef _WIN32
#  pragma warning(pop)
#endif
};

#endif  // _KEYSSL_HXX_
