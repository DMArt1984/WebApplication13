#ifndef _LANGTEXTVAR_H_
#define _LANGTEXTVAR_H_

#ifndef _VARIABLE_H_
#include <Variable.hxx>
#endif

#ifndef _LANGTEXT_H_
#include <LangText.hxx>
#endif

#ifndef _CHARSTRING_H_
#include <CharString.hxx>
#endif
 
// ========== LangTextVar ============================================================

/** Variable class representing a multilanguage string
    @see LangText
  */
//author Stano Meduna
class DLLEXP_BASICS LangTextVar : public Variable
{
  /** operator << for itcNdrUbSend stream
      @param ndrStream the stream, which to send to
      @param tVar the LangTextVar
    */
  friend DLLEXP_BASICS itcNdrUbSend &operator<<(itcNdrUbSend &ndrStream, const LangTextVar &tVar);

  /** operator >> for itcNdrUbReceive stream
      @param ndrStream the stream, which to receive from
      @param tVar the LangTextVar
    */
  friend DLLEXP_BASICS itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream, LangTextVar &tVar);

  /** operator << for std stream
      @param ofStream the stream, which to send to
    */
  friend DLLEXP_BASICS std::ostream &operator<<(std::ostream &ofStream, const LangTextVar &);

  /** operator >> for std stream
      @param ifStream the stream, which to receive from
    */
  friend DLLEXP_BASICS std::istream &operator>>(std::istream &ifStream, LangTextVar &);

  public:
  
    /** constructor, initialisation with zero values
      */
    LangTextVar() { cachedIsA = LANGTEXT_VAR; }

    /** copy constructor
        @param rVal the LangTextVar, which shall be copied from
      */
    LangTextVar(const LangTextVar &rVal) : Variable(rVal),value(rVal.value) { cachedIsA = LANGTEXT_VAR; }

    /** constructor, initialisation with LangText
        @param rVal the LangText, which shall be initialised with
      */
    LangTextVar(const LangText &rVal) : value(rVal) { cachedIsA = LANGTEXT_VAR; }
    
    /** allocator deallocator class
      */
    AllocatorDecl;

    /** comparison operator ==
        @param rVal the Variable to cmpare witho
            @n Important: this operator checks the VariableType, so two objects are only equal, if
               they also have the same class (no conversion is done; see other operators)
        @return 0 if not equal else 1
      */
    virtual int operator==(const Variable &rVal) const;

    /** comparison operator <
        @param rVal the Variable to compare with
            @n Important: this operator also converts the given rVal to its own class-type if needed
        @return 0 if the Variable to compare with is smaller else 1
	  */
    virtual int operator<(const Variable &rVal) const;
    
    /** comparison operator >
        @param rVal the Variable to compare with
            @n Important: this operator also converts the given rVal to its own class-type if needed
        @return 0 if the Variable to compare with is bigger else 1
	  */
    virtual int operator>(const Variable &rVal) const;
    
    /** non virtual comparison operator <
        @param rVal the LangTextVar to compare with
        @return 0 if the LangTextVar to compare with is smaller else 1
	*/
    int operator<(const LangTextVar &rVal) const;

    /** assignment operator used for type conversion
        @param rVal the Variable to convert
        @return the resulting Variable
      */
    virtual Variable &operator=(const Variable &rVal);

# if 0 
    /** return own variable type
        @return LANGTEXT_VAR
      */
    VariableType  isA() const;

	/** check if own variable type matches other variable type
        @param varType the VariableType to check
        @return LANGTEXT_VAR, if argument is LangTextVar, else NOTYPE_VAR.
      */
    VariableType  isA(VariableType varType) const;
# endif

    /** return type of variable
        @return LANGTEXT_VAR
      */
    virtual VariableType isAUncached() const { return LANGTEXT_VAR; }
    
	/** return type of variable
        @param varType the VariableType to check
	    @return LANGTEXT_VAR if TextVar else return other VariableType
      */
    virtual VariableType isAUncached(VariableType varType) const;

	/** send to output stream
        @param ofStream the stream, which to send to
      */
    virtual void outToFile(std::ostream &ofStream) const;


	/** get from input stream
        @param ifStream the stream, which to get from
      */
    virtual void inFromFile(std::istream &ifStream);
 
    /** format the value (the text for the active language) according to the format string
        @return the string representation of the value
        @param  format the format string
             @n If the string is not empty it is used as an argument to the sprintf function.
                Else the text for the active language is returned.
    */
    virtual CharString formatValue(const CharString &format) const;

    /** format the value according to a format string
        @n This method is more performant than the one which returns a CharString, because no alloc is done.
        @param format the format string
            @n If the string is not empty it is used as an argument to the sprintf function (if useful).
               Else a default is used.
        @param target the buffer, which is directly written to
        @param len the length of the target
        @return the number of bytes written into target without 0-byte,
                or a negative value on error (like buffer too small)
    */
    virtual int formatValue(const CharString &format, char *target, size_t len) const;

    /** clone the current LangTextVar object
        @return the Variable as clone of this object
      */
    virtual Variable *clone() const { return new LangTextVar(*this); }

    /** allocate new LangTextVar
        @return the new LangTextVar
      */
    virtual Variable *allocate() const { return new LangTextVar; }

    /** set a value given by LangTextVar
        @param rVal the LangTextVar to set
      */
    void setValue(const LangTextVar &rVal) { value = rVal.value; }

	/** get the stored string as a const LangText
        @return the LangText as the stored string
    */
    const LangText &getValue() const { return value; }

	/** get the stored string as a LangText
        @return the LangText as the stored string
    */
    LangText &getValue() { return value; }

  private:
    void outNdrUb(itcNdrUbSend &ndrStream) const;
    void inNdrUb(itcNdrUbReceive &ndrStream);

    LangText value;
};

#endif /* _LANGTEXTVAR_H_ */
