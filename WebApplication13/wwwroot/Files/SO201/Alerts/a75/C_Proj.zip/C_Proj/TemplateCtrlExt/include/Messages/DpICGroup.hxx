// DATEIBESCHREIBUNG ==============================================================
// DATEINAME:     DpICGroup.hxx
// VERANTWORTUNG: Guenter Szolderits
// BESCHREIBUNG:  

#ifndef _DPICGROUP_H_
#define _DPICGROUP_H_

// System-Include-Files
#include <PtrList.hxx>
#include <PtrListItem.hxx>
#include <DpICItem.hxx>
#include <DpTypes.hxx>
#include <Allocator.hxx>


// Vorwaerts-Deklarationen :
class DpICGroup;

// ========== DpIdValueList ============================================================
/** Init-config group
*/
class DLLEXP_MESSAGES DpICGroup : public PtrListItem
{
public:
  // Konstruktor
  /// Default constructor
  DpICGroup();

  /** Constructor
   * @param systemNr system number
   * @param dpId  datapoint id
   * @param dpType datapoint type
   * @param elem element id
   */
  DpICGroup(const SystemNumType &systemNr, const DpIdType &dpId, const DpTypeId &dpType, const DpElementId &elem);

  /// Copy constructor
  DpICGroup(const DpICGroup &rVal);

  /// Destructor
  virtual ~DpICGroup();

  /// Allocator class
  AllocatorDecl;

  // Operatoren :
  /** BCM output streaming operator
   * @param[in,out] ndrStream the BCM stream to write to
   * @param item the DpICGroup instance to be written
   */
  friend DLLEXP_MESSAGES itcNdrUbSend &operator<<(itcNdrUbSend &ndrStream, const DpICGroup &item);

  /** BCM input streaming operator
   * @param[in,out] ndrStream the BCM stream to read from
   * @param[out] item the DpICGroup instance to be read
   */
  friend DLLEXP_MESSAGES itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream, DpICGroup &item);

  /** Equality operator
   * @param rVal the DpICGroup to compare with
   */
  int operator==(const DpICGroup &rVal) const;

  /** Inequality operator
   * @param rVal the DpICGroup to compare with
   */
  int operator!=(const DpICGroup &rVal) const;

  /** Copy operator
   * @param rVal the DpICGroup to copy from
   */
  DpICGroup &operator=(const DpICGroup &rVal);

  // Spezielle Methoden :
  /** Writes this group to the BCM stream
   * @param[out] ndrStream
   */
  void outNdrUb(itcNdrUbSend &ndrStream) const;

  /** Reads this group from the BCM stream
   * @param[in,out] ndrStream
   */
  void inNdrUb(itcNdrUbReceive &ndrStream);

  /** Debug output method
   * @param[out] to the stream to write to
   * @param level controlls the amount of debug information, the higher the more
   */
  void debug(std::ostream &to, int level) const;

  /// Returns the system number in this group
  SystemNumType getSystem() const          { return system; }

  /** Sets the system number in this group
   * @param newSystem the new value
   */
  void setSystem(SystemNumType newSystem)  { system = newSystem; }
  
  /// Returns the datapoint id in this group
  DpIdType getDp() const                   { return dp; }

  /** Sets the datapoint id in this group
   * @param newDp the new value
   */
  void setDp(DpIdType newDp)               { dp = newDp; } 

  /// Returns the datapoint type in this group
  DpTypeId getDpType() const               { return type; } 

  /// Returns the datapoint type in this group
  DpTypeId getType() const                 { return getDpType(); }
  
  /** Sets the datapoint type in this group
   * @param newType the new value
   */
  void setType(DpTypeId newType)           { type = newType; }

  /// Returns the element id
  DpElementId getEl() const                { return el; }

  /** Sets the element id
   * @param newEl DpElementId element id
   */
  void setEl(DpElementId newEl)            { el = newEl; }

  /** Insert a new DpConfig. This method creates a deep copy
   *  of the given DpConfig, so insertConfig(DpConfig*) is faster.
   * @param newConfig the new config
   */
  void insertConfig(const DpConfig &newConfig);

  /** Insert a new DpConfig.
   * @param newConfig the new config, this method takes responsibility
   */
  void insertConfig(DpConfig *newConfig);

  /// Returns the first DpIcItem from the group
  DpICItem *getFirstItem() const { return (DpICItem *)itemList.getFirst(); }

  /// Returns the next DpIcItem from the group
  DpICItem *getNextItem() const { return (DpICItem *)itemList.getNext(); }

  /// Returns the count of items in this group
  unsigned int getNumberOfItems() const { return itemList.getNumberOfItems(); }

  /// Removes all items from this group
  void clearItems() { itemList.clear(); }

protected:
  ///system number
  SystemNumType system;
  ///dp id
  DpIdType dp;
  ///dp type
  DpTypeId type;
  ///element id
  DpElementId el;
  ///DpIcItem list
  PtrList itemList;

  friend class UNIT_TEST_FRIEND_CLASS;
};

#endif /* _DPICGROUP_H_ */
