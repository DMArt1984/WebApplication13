// -----------------------------------------------------------------------------
// creator: Andras Horvath - 01.09.2017
// purpose: Base class for Keys
// -----------------------------------------------------------------------------
#ifndef _KEY_HXX_
#define _KEY_HXX_

#include <Signature.hxx>
#include <Blob.hxx>
#include <memory>
#include <string>
#include <vector>

class QJsonObject;
class Key;

/// Reference counted Key
typedef std::unique_ptr<Key> SmartKey;

/**
  @class Key
  @brief The Key class
         is the abstract base class for other Key classes.
         This class represents a private key or a public key of a certain kind
         (determined by the concrete class).
         The member variable m_keyType determines if the Key is a private or
         public key.
*/
class DLLEXP_OABASICS Key
{
public:
  /// Key::Type enum, defines the type of a key
  enum class Type
  {
    UNDEFINED_KEY = -1,  ///< Default value
    PRIVATE_KEY,         ///< Key is a private key
    PUBLIC_KEY,          ///< Key is a public key (certificate)
    NUM_TYPES            ///< Number of possible key types
  };

  /**
    @class Key::CaList
    @brief Helper class of Key.
           This class stores the path to one or more CA files
  */
  class CaList
  {
  public:
    /// Constructs a new empty CaList
    CaList() = default;

    /**
      Constructs a new CaList form a string.
      The string can contain multiple CA file paths,
      separated by a semicolon (;)
    */
    explicit CaList(const std::string& CaFile)
      : m_values(Key::tokenizeStr(CaFile, ';'))
    {
    }

    /// Constructs a new CaList form a list of strings.
    explicit CaList(const std::vector<std::string>& CaFiles)
      : m_values(CaFiles)
    {
    }

    /// Appends one value to the CaList
    void append(const std::string& CaFile) { m_values.push_back(CaFile); }

    /// Reads the contents of the CaList
    std::vector<std::string> getValues() const { return m_values; }

    /// Checks if the CaList is empty
    bool isEmpty() const { return m_values.empty(); }

  private:
    std::vector<std::string> m_values;  ///< the stored values
  };

  /**
    @class Key::CrlList
    @brief Helper class of Key.
           This class stores the path to one or more CRL files
  */
  class CrlList
  {
  public:
    /// Constructs a new empty CrlList
    CrlList() = default;

    /**
      Constructs a new CrlaList form a string.
      The string can contain multiple CRL file paths,
      separated by a semicolon (;)
    */
    explicit CrlList(const std::string& CrlFile)
      : m_values(Key::tokenizeStr(CrlFile, ';'))
    {
    }

    /// Constructs a new CrlList form a list of strings.
    explicit CrlList(const std::vector<std::string>& CrlFiles)
      : m_values(CrlFiles)
    {
    }

    /// Appends one value to the CrlList
    void append(const std::string& CrlFile) { m_values.push_back(CrlFile); }

    /// Reads the contents of the CrlList
    std::vector<std::string> getValues() const { return m_values; }

  private:
    std::vector<std::string> m_values;  ///< the stored values
  };

  /**
    @brief Constructor for a new empty Key
    @param keyType  type of the Key
  */
  explicit Key(Key::Type keyType);

  /**
    @brief Constructor for a new Key
    @param jsonPem  JSON object containing Key data
    @param keyType  type of the Key
  */
  Key(Key::Type keyType, const QJsonObject& jsonPem);

  /// destructor
  virtual ~Key() = default;

  /**
    @brief   Create a digital signature with a key.
             Can be used only with private keys.
    @details This function signs the given data with the private key.
    @param   data       Blob data to sign
    @param   signature  returning Signature object containing the signated data
    @return             0 if successful
  */
  virtual int sign(const Blob& data, Signature& signature) const = 0;

  /**
    @brief  Verifies the validity of a Key.
            Can be used only with public keys (certificates).
    @param  crlFiles     Certificate Revocation Lists.
    @param  caFiles      CA lists
    @param  chainPrefix  check if the certificate chain starts with this prefix
    @param  verifyTime   check if the certificate is expired ( default = true )
    @return              0 if certificate is valid and not revoked,
                         else error code
  */
  virtual int verify(const Key::CrlList& crlFiles,
                     const Key::CaList& caFiles,
                     const std::string& chainPrefix,
                     bool verifyTime = true) const = 0;

  /**
    @brief  Checks a digital signature with the Key.
            Can be used only with public keys (certificates).
    @param  data       Blob data that was signed
    @param  signature  the Signature object containing the digital signature
    @return            0 if signature is valid, else error code
  */
  virtual int checkSignature(const Blob& data,
                             const Signature& signature) const = 0;

  /**
    @brief  Seals an envelope
            Can be used only with public keys.
    @param  inputData  Blob data that has to be encrypted
    @param  sealedData the output encrypted data
    @return            0 if successful, else error code
  */
  virtual int sealEnvelope(const Blob& inputData,
                           Blob& sealedData) const = 0;

  /**
    @brief  Opens an envelope
            Can be used only with private keys.
    @param  sealedData the input encrypted data
    @param  outputData  the decrypted output Blob data
    @return            0 if successful, else error code
  */
  virtual int openEnvelope(const Blob& sealedData,
                           Blob& outputData) const = 0;

  /**
    @brief  Gets the common name field (CN) of a certificate.
    @param  componentName  component name, if empty, returns the whole common
                           name string
    @return                common name of the certificate
  */
  virtual std::string getCommonName(const std::string& componentName) const = 0;

  /**
    @brief   Returns the Type function of the Key.
    @details Use this function to determine what functinality is available.
    @return  the type of the Key
  */
  Key::Type getKeyType() const;

  /**
    @brief   Creates a JSON object from a key.
    @details Only public keys can be exported with this function.
    @param   json  the returning JSON object
    @return        0 on success, else error code
  */
  virtual int serialize(QJsonObject& json) const;

  /**
    @brief   Construct a new instance of the Key class.
    @details This function implements how to create a key based on a Key::Type
             and a Key resource (config entry). This function is used by the
             CertificateChallengeHandler to create its public and private keys.
    @param   keyType      type of the Key
    @param   keyResource  value of config entry ssaPrivateKey or ssaCertificate
    @param   verifyTime   the key should verify if it is expired
    @return               created Key object based on parameters
  */

  static SmartKey create(Key::Type keyType,
                         const std::string& keyResource,
                         bool verifyTime = true);
  /**
    @brief   Construct a new instance of the Key class.
    @details This function implements how to create a key based on a previously
             JSON serialized Key object. This function is used by the
             CertificateChallengeHandler to recreate the clients public key on
             the server.  Only public keys can be created with this function.
    @param   jsonObj     JSON serialized representation of Key subclass object
    @param   verifyTime  the key should verify if it is expired
    @return              created Key object based on parameters
  */
  static SmartKey create(const QJsonObject& jsonObj,
                         bool hasChainFile,
                         bool verifyTime = true);

protected:

  /// Returns the PEM data of a Key
  std::string getPem() const;

  /// Sets the PEM data of a Key
  void setPem(const std::string& pem);

  /// Internal helper function for tokenizing strings
  static std::vector<std::string> tokenizeStr(const std::string& str,
                                              char delimiter);

private:
  Key::Type m_keyType;  ///< the Key type

#ifdef _WIN32
#  pragma warning(push)
#  pragma warning(disable : 4251)
#endif
  std::string m_keyPem;  ///< the stored PEM data
#ifdef _WIN32
#  pragma warning(pop)
#endif

  /// Internal: initializes the OpenSSL Wrapper to load the OpenSSL Library
  static void initWrapper();
  static int sslInitialized;  ///< Internal: SSL wrapper is initialized
};

#endif  // _KEY_HXX_
