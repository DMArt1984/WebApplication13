#ifndef _ALERTATTRLIST_H_
#define _ALERTATTRLIST_H_

// Vorwaerts-Deklaration der Eigenen Klasse
class AlertAttrList;

// System-Include-Files
#ifndef _ALERTTIME_H_
#include <AlertTime.hxx>
#endif

#ifndef _DPTYPES_H_
#include <DpTypes.hxx>
#endif

#ifndef _PTRLIST_H_
#include <PtrList.hxx>
#endif

#ifndef _PTRLISTITEM_H_
#include <PtrListItem.hxx>
#endif

#ifndef _ALERTIDENTIFIER_H_
#include <AlertIdentifier.hxx>
#endif

#ifndef _DPVCITEM_H_
#include <DpVCItem.hxx>
#endif

// Vorwaerts-Deklarationen :
class AlertAttrList;
class Variable;

class itcNdrUbSend;
class itcNdrUbReceive;

/**
 * A container for alert attributes of a single alert config and a single alert time.
 * Instances of this class are used as items in AlertList, which is used in alert messages.
 *
 * The alert config can be specified in the constructor call and is otherwise
 * taken from the first inserted element. Subsequent inserts will only succeed if
 * the specified AlertIdentifier matches the AlertIdentifier of the list,
 * except for the attribute number.
 *
 * The alert time can be specified in the constructor call and is otherwise
 * taken from the first inserted element.
 *
 * @remarks If the flag @p allAttributes is set, the instance will act as if it contains
 * every attribute which is searched for. When an attribute is not in the list, it
 * will be created without a value.
 */
class DLLEXP_BASICS AlertAttrList : public PtrListItem
{
  friend class AlertList;
  friend class UNIT_TEST_FRIEND_CLASS;

  public:
    /**
     * Default constructor. Creates an empty list.
     */
    AlertAttrList();

    /**
     * Copy constructor. Creates a deep copy of the specified instance.
     *
     * @param chAttr The list that is copied
     */
    AlertAttrList(const AlertAttrList &chAttr);

    /**
     * Creates a new instance with the flag @p allAttributes set, which only
     * accepts inserts for the specified AlertIdentifier.
     * 
     * The resulting list is always sorted.
     *
     * @param id The AlertIdentifier for which inserts are allowed.
     */
    AlertAttrList(const AlertIdentifier &id);

    /**
     * Creates a new instance with the specified AlertTime set.
     *
     * @param t The AlertTime of this list.
     */
    AlertAttrList(const AlertTime &t);

    /// Destructor
    ~AlertAttrList();

    /**
     * The message stream send operator. This operator is used to send an
     * alert item through the BCM message connection.
     *
     * The allAttributes flag is not copied.
     *
     * @internal
     */
    friend DLLEXP_BASICS itcNdrUbSend &operator<<(itcNdrUbSend &ndrStream, const AlertAttrList &list);

    /**
     * The message stream receive operator. This operator is used to receive
     * AlertAttrList objects from the message stream.
     *
     * It must be the exact mirror function to the send operator.
     * 
     * @internal
     */
    friend DLLEXP_BASICS itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream, AlertAttrList &list);

    /**
     * Dumps the specified list to the specified output stream. Used for debug purposes.
     */
    friend DLLEXP_BASICS std::ostream &operator<<(std::ostream &_out, const AlertAttrList &list);

    /**
     * Equality operator. Compares AlertTime, @p allAttributes
     * and content and order of the items.
     */
    int operator==(const AlertAttrList &rVal) const;

    /**
     * Assignment operator. Copies everything (flags, AlertTime and items)
     * from @p chAttr to this instance.
     *
     * @param chAttr The instance to be copied into the current instance.
     */
    AlertAttrList &operator=(const AlertAttrList &chAttr);

    /**
     * Insert a new attribute into the list.
     *
     * If the attribute is already a member of the list, only the value is
     * updated.
     *
     * The list holds attributes for one SYS:DP.El:CF.DT combination.
     * You cannot insert an attribute for another combination in the list when
     * at least one item is already there.
     *
     * @param identifier The attribute to insert
     * @param valuePtr A pointer to a Variable object which holds the value.
     * The call takes ownership of this pointer.
     * @param search If false, the specified attribute will be appended,
     * even if the same attribute is already in the list.
     *
     * @return PVSS_TRUE on success, otherwise PVSS_FALSE
     */
    PVSSboolean insertAttribute(const AlertIdentifier &identifier, Variable * valuePtr = 0, 
	PVSSboolean search = PVSS_TRUE);

    /**
     * Update the value of an attribute that is already in the list.
     *
     * @param identifier The attribute to search for
     * @param valuePtr A pointer to the Variable object which holds the new value.
     * The call takes ownership of this pointer.
     *
     * @return PVSS_TRUE on success, otherwise PVSS_FALSE
     */
    PVSSboolean setValuePtr(const AlertIdentifier &identifier, Variable * valuePtr);

    /**
     * Resets the internal pointer of the list to the first item and
     * returns that item.
     *
     * @return A pointer to the first item of the list or 0 if the list is empty.
     */
    DpVCItem *getFirstItem() const { return (DpVCItem *) list.getFirst(); }

    /**
     * Sets the internal pointer of the list to the next item and
     * returns that item.
     *
     * @return A pointer to the next item of the list or 0 if there are
     * no more items.
     */
    DpVCItem *getNextItem() const { return (DpVCItem *) list.getNext(); }

    /**
     * Returns the number of items in the list.
     *
     * @return The number of items in the list.
     */
    PVSSulong getNumberOfItems() const {return list.getNumberOfItems(); }

    /**
     * Alias for getNumberOfItems()
     */
    PVSSulong getNrOfItems() const { return list.getNumberOfItems(); }

    /**
     * Returns the AlertIdentifier of the first item of the list.
     *
     * @param id A reference to the object that receives the DpIdentifier
     *
     * @return PVSS_TRUE on success, PVSS_FALSE if the list is empty
     */
    PVSSboolean getFirstAlertId(AlertIdentifier &id) const;

    /**
     * Deletes all items of the list. Leaves the AlertTime and the flags intact.
     */
    void clear() { list.clear(); }

    /**
     * Returns the AlertTime for the items in the list.
     *
     * @return the AlertTime, i.e. the time when the alert was initiated
     */
    const AlertTime &getATime() const { return aTime; }

    /**
     * Searches for the specified attribute number in this list
     * and returns the corresponding DPVCItem.
     *
     * @param attrNr The attribute number to search for.
     *
     * @return A pointer to the found DPVCItem, or 0 if it was not found.
     */
    DpVCItem *findAttribute(DpAttributeNrType attrNr);

    /**
     * Dumps the list to an output stream.
     *
     * @param to The target stream
     * @param level The detail level of information, should be > 0
     */
    virtual void debug(std::ostream &to, int level) const;

    /**
     * Returns the @p allAttributes flag.
     *
     * Only used for EvConnection::alertAttrChanged
     */
    PVSSboolean getAllAttributes() { return allAttributes; }

    /**
     * Check if values are from an answer (use in ctrl only)
     */
    PVSSboolean isAnswer() const {return answer;}

    /**
     * Sets the answer flag
     */
    void  setAnswer() {answer = PVSS_TRUE;}

    /**
     * Check if values are from a refresh
     */
    PVSSboolean isRefresh() const {return refresh;}

    /**
     * Set the refresh flag
     */
    void  setRefresh() {refresh = PVSS_TRUE;}

  private:
    /**
     * Checks whether the specified AlertIdentifier belongs to the same
     * alert message as the list.
     * Returns PVSS_FALSE for empty lists.
     */
    PVSSboolean checkIdentifier(const AlertIdentifier &identifier) const;

    // Vergleichsfunktion fuer sortierte Liste, es wird nur die Attribut-Nr verglichen
    /**
     * Compares the attribute number of the specified value change items.
     *
     * Returns -1 if @p item1 < @p item2, 1 if @p item1 > item2, otherwise 0
     */
    static int compare(const DpVCItem *item1, const DpVCItem *item2);

  private:
    PtrList  list;
    AlertTime aTime;

    /**
     * Marks a new message that should contain all possible attributes.
     * To avoid having to insert all attributes, this flag simulates
     * having all attributes.
     *
     * @internal
     *
     * @remarks Only for interal use inside the event manager
     */
    PVSSboolean allAttributes;

    /// Flag if values are from an answer (used in the ctrl)
    PVSSboolean answer;

    /// Flag if values are from a refresh
    PVSSboolean refresh;
};

// Destruktor
inline AlertAttrList::~AlertAttrList()
{
}

// Konstruktor
inline AlertAttrList::AlertAttrList() 
  : aTime(),
allAttributes(PVSS_FALSE), answer(PVSS_FALSE), refresh(PVSS_FALSE)
{
}

// Konstruktor
inline AlertAttrList::AlertAttrList(const AlertIdentifier &id)
  : aTime(),
allAttributes(PVSS_TRUE), answer(PVSS_FALSE), refresh(PVSS_FALSE)
{
  insertAttribute(id);
}

// Konstruktor
inline AlertAttrList::AlertAttrList(const AlertAttrList &chAttr)
{
  *this = chAttr;
}

// Konstruktor
inline AlertAttrList::AlertAttrList(const AlertTime &t)
  : aTime(t),
allAttributes(PVSS_FALSE), answer(PVSS_FALSE), refresh(PVSS_FALSE)
{
}

// prueft ob der uebergebene Identifier zur selben Meldung gehoert, wie die in
// der Liste enthaltenen Attribute, bei leerer Liste wird false geliefert
inline PVSSboolean AlertAttrList::checkIdentifier(const AlertIdentifier &identifier) const
{
  if (list.getFirst())
  {
    // Test ob Identifier bis auf Attribut-Nr gleich sind
    AlertIdentifier id( ((DpVCItem *) list.getFirst())->getDpIdentifier(), aTime );

    if (id.isEqual(identifier, (PVSSushort) ~(DpIdentifier::compAttr | DpIdentifier::compType))) 
      return PVSS_TRUE;
  }

  return PVSS_FALSE;
}

inline PVSSboolean AlertAttrList::getFirstAlertId(AlertIdentifier &id) const
{
  DpVCItem *item = (DpVCItem *) list.getFirst();
  if (item)
  {
    (DpIdentifier &) id = item->getDpIdentifier();
    id.setAlertTime(aTime);

    return PVSS_TRUE;
  }

  return PVSS_FALSE;
}


#endif /* _ALERTATTRLIST_H_ */
