#ifndef _WAITDPTYPE_H_
#define _WAITDPTYPE_H_

#include <WaitCond.hxx>
#include <CharString.hxx>
#include <DynVar.hxx>

#include <DpElementType.hxx>
#include <DpTypes.hxx>
#include <WaitForAnswer.hxx>

#include <LangText.hxx>

class CtrlThread;
class DpTypeNode;
class DpIdentification;
class DpTypeContainer;
class DpType;
class DpMsgManipDpType;

/*  author VERANTWORTUNG: Milos Marusiak        */
/** Ctrl-Funktionen f�r Erstelln/�ndern von DPTs und
  */

class DpTypeWaitForAnswer;
class WaitDpType;

class DLLEXP_CTRL WaitDpType : public WaitCond
{
  public:
    /// Disconnect an existing Hotlink 
    ~WaitDpType();
    WaitDpType(CtrlThread *thread):m_thread(thread), m_dpTypeArray(0), waitForAnswer(0)
    {
      m_done = PVSS_FALSE;
      doInit();
    }
    /** Waitobjetct: Warte bis DPT erstellt/ge�ndert ist.
      * @param theThread   IN: thread der warten muss. wird nicht frei gegeben!
      * @param dpTypeName  IN: DPT-Name
      * @param names       IN: DPE-Namen
      * @param types       IN: DPE-Typen
      */
    WaitDpType( CtrlThread *theThread,
                const DynVar &names,
                const DynVar &types, PVSSboolean createNew);

    /** Waitobjetct: Warte bis DPT erstellt/ge�ndert ist.
      * @param theThread   IN: thread der warten muss. wird nicht frei gegeben!
      * @param dpTypeName  IN: DPT-Name
      * @param names       IN: DPE-Namen
      * @param types       IN: DPE-Typen
      * @param elementName IN: ElementName to change
      */
    WaitDpType( CtrlThread *theThread,
                const DynVar &names,
                const DynVar &types, PVSSboolean createNew, const DynVar &oldElementNames);

    /** Waitobjetct: Warte bis DPT gel�scht ist.
      * @param theThread   IN: thread der warten muss. wird nicht frei gegeben!
      * @param dpTypeName  IN: DPT-Name
      */
    WaitDpType( CtrlThread *theThread,
                CharString dpTypeName);

    /** Waitobjetct: Warte bis "Skript-Struktur" von DPT erstellt ist.
      * @param theThread   IN: thread der warten muss. wird nicht frei gegeben!
      * @param dpTypeName  IN: DPT-Name
      * @param names      OUT: DPE-Namen
      * @param types      OUT: DPE-Typen
      * @param includeSubTypes IN: should sub-Types also be included in the result
      */
    WaitDpType(CtrlThread *theThread,
               const CharString &typeName,
               DynVar *names,
               DynVar *types, bool includeSubTypes);

    /* Liefert alle Referenzen die in einem DPT vorkommen
    */
    PVSSboolean dpGetDpTypeRefs(const CharString &dpTypeName, DynVar &array);
    /*Liefert alle DPTs und DPEs zur�ck, die 'reference' als Referenz ebthalten.
    */
    PVSSboolean dpGetRefsToDpType(const CharString &reference, DynVar &array);

    /// wann soll thread das naechste mal ausgefuehrt werden.
    virtual const TimeVar &nextCheck() const;

    virtual int checkDone();

    void handleAnswer(DpMsgAnswer &answer);

    void setWaitForAnswer(DpTypeWaitForAnswer *wait4Answer)
    {
      waitForAnswer = wait4Answer;
    }

    PVSSboolean m_done;

  private:
    typedef struct
    {
      unsigned long row;
      unsigned long column;
      CharString elementName;
      DpElementType elementType;
      DpTypeId referencedType;
      DpElementId id;
    }
    DpTypeItem; 

    PVSSboolean doInit();
    void Initialize(const DynVar &names, const DynVar &types, PVSSboolean createNew);
    PVSSboolean findAllTypeReferences(const DpType *dpTypePtr, const DpTypeNode *node, DynVar &array, DynVar &path, const char *cmpRef = 0);
    void buildOutputArray(DynVar &array, DynVar &pathArray);
    PVSSboolean InitDpTypeArray(const DynVar &names, const DynVar &types);
    void UpdateElementsId(const DpType *dpTypePtr, WaitDpType::DpTypeItem *item, const CharString &newElemPath);
    DpTypeItem *GetRoot();
    DpTypeItem *GetChild(DpTypeItem *item);
    DpTypeItem *GetNextSibling(DpTypeItem *item);
    PVSSboolean buildDpType(DpTypeItem *dpTypeItem, DpType &dpType, DpTypeNode *dpTypeNode,
                             DpElementId &elemId, DpMsgManipDpType &msg);
    PVSSboolean checkSiblings(DynVar &siblings, const char *name);
    void ChangeElementName(DpMsgManipDpType &msg, DpType *dpTypePtr, const DpTypeNode *node, const DynVar &elementNames, const DpType *oldDpTypePtr);
    void ChangeElementName(const DynVar &name, const DynVar &elementNames);

    void parseDpType(const DpTypeNode *node, int &row, int &column, bool includeSubTypes);
    void insertElement(const CharString &elementName, DpElementType elementType, int row, int column,  const CharString &referencedElementName);

    CtrlThread *m_thread;
    DpIdentification *m_dpIdentPtr;
    DpTypeContainer *m_dpTypeContainerPtr;
    DpTypeItem **m_dpTypeArray;
    DynPtrArrayIndex m_rows, m_columns;

    DpTypeWaitForAnswer *waitForAnswer;
    DynVar *m_ptypes, *m_pnames;
    DpType *m_dpTypePtr;
};

class DLLEXP_CTRL DpTypeWaitForAnswer : public WaitForAnswer
{
  public:
    DpTypeWaitForAnswer(WaitDpType *cond):waitCond(cond){}

    virtual ~DpTypeWaitForAnswer()
    {
      if ( waitCond ) waitCond->setWaitForAnswer(0);
    }

    virtual void callBack(DpMsgAnswer &answer);

    void setWaitCond(WaitDpType *wait) { waitCond = wait; }

  protected:

  private:
    WaitDpType *waitCond;
};

#endif /* _WAITFORDPVALUE_H_ */
