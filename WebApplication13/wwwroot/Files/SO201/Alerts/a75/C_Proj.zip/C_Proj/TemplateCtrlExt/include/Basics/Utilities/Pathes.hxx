#ifndef _PATHES_H_
#define _PATHES_H_

/*
VERANTWORTUNG: Andreas Pfluegl
BESCHREIBUNG: This class holds the pathes to the pvss-Project
              This is the Base-Class to PathesV1 and PathesV2
              and represents the FilesStructure Version 1
*/

#ifndef _CHARSTRING_H_
#include <CharString.hxx>
#endif

#ifndef _PROJDIRS_H_
#include <ProjDirs.hxx>
#endif

#ifndef _FILESYS_H_
#include <FileSys.hxx>
#endif


class DynVar;


/// This class holds the information about the Project and PVSS
/// directory structure. Methods are provided for obtaining a specific directory.
/// @classification CoreTest, public use, derive
class DLLEXP_BASICS Pathes
{
  public:

    /// Type of path filter
    enum FilterPathes
    {
      /// Full - all files will be considered
      FILT_FULL = 1,

      /// NODB - Database files will be filtered out
      FILT_NODB = 2,

      /// MIN - Only files marked as "MIN" will be considered
      FILT_MIN = 3
    };

    /// Constructor.
    Pathes();

    /// Destructor.
    ~Pathes();

    /// Reset projDirs members and the pvss root directory.
    void  reset();

    /// Reset the projDirs members.
    void  resetProjDirs();

    /// Set the root PVSS directory.
    /// @param dir New PVSS root directory.
    void  setPvssDir(const CharString &dir)    {pvssDir_ = dir;}

    /// Add new directory to the project directories list.
    /// @param dir Directory to add.
    void  appendProjDir(const CharString &dir) {projDir_.append(new CharString(dir));}

    /// Insert new directory to the beginning of the project directories list.
    /// @param dir Directory to add.
    void  insertProjDir(const CharString &dir) {projDir_.insertPtr(0, new CharString(dir));}

    /// Initialize Project-files list. 
    /// Do this by reading the (PVSSInstallation)\config\proj_dirs file
    /// @param languages defines for which languages the lang-specific dirs
    ///        shall create subdirs, e.g. msg/
    ///        (The argument is only optional to keep the code compatible with old console)
    /// @return true if initialization was successfull, false otherwise.
    bool initProjDirs(const DynVar *languages = 0);

    /// Initialize Project-files list, filter can be specified.
    /// @param languages Defines for which languages the lang-specific dirs
    ///       shall create subdirs, e.g. msg/
    /// @param filter Filter for paths.
    /// @return true if initialization was successfull, false otherwise.
    bool initProjDirs(const DynVar *languages, FilterPathes filter );

     /** Returns a list of Objects.
       * Each Object describes one necessary file or directory for a PVSS-Project
       * - for the actual Structure of the project
       * - for a Project with old Structure
       * - for a Project with the new Structure
       * @return DynArrayPtr with the ProjDirs.
       */
    const DynPtrArray<ProjDirs> &getProjDirs()   { return(*projDirs_);  }

    /// Returns an array of 13 hard-coded project directories.
    /// @return DynPtrArray of the ProjDirs.
    const DynPtrArray<ProjDirs> &getProjDirsV1() { return(projDirsV1_); }

    /// Returns the proj dirs v.2.
    /// @return DynPtrArray of the ProjDirs.
    const DynPtrArray<ProjDirs> &getProjDirsV2() { return(projDirsV2_); }


    /// Gets the pvss2 directory including a trailing "/".
    /// @return CharString with the directory.
    CharString  getPvssDir();

    /// Get the pvss2 project directory including a trailing "/".
    /// @param level Level of the subdirectory.
    /// @return CharString with the directory.
    CharString  getProjDir(int level = 1);

    // TI 1621
    /// Get the pvss2 project directory including a trailing "/".
    /// @param level Level of the subdirectory.
    /// @return CharString with the directory.
    CharString getProjDirC(int level);

    /// Get the pvss2 bin directory including a trailing "/".
    /// @return Charstring with the directory.
    CharString getBinDir();

    /// get the project bin dir. returns the path including a trailing "/"
    /// @param level Level of the subdirectory.
    /// @return CharString with the directory.
    CharString getProjBinDir(int level = 1);

    /// get the project source dir. returns the path including a trailing "/"
    /// @param level Level of the subdirectory.
    /// @return CharString with the directory.
    CharString getSourceDir(int level = 1);

    /// get the project help dir. returns the path including a trailing "/"
    /// @param level Level of the subdirectory.
    /// @return CharString with the directory.
    CharString getHelpDir(int level = 1);

    /// get the project msg dir. returns the path including a trailing "/"
    /// @param level Level of the subdirectory.
    /// @return CharString with the directory.
    CharString getMsgDir(int level = 1);

    /// get the project config dir. returns the path including a trailing "/"
    /// @param level Level of the subdirectory.
    /// @return CharString with the directory.
    CharString getConfigDir(int level = 1);

    /// get the project pictures dir. returns the path including a trailing "/"
    /// @param level Level of the subdirectory.
    /// @return CharString with the directory.
    CharString getPicturesDir(int level = 1);

    /// get the project printers dir. returns the path including a trailing "/"
    /// @param level Level of the subdirectory.
    /// @return CharString with the directory.
    CharString getPrintersDir(int level = 1);

    /// get the project colorDB dir. returns the path including a trailing "/"
    /// @param level Level of the subdirectory.
    /// @return CharString with the directory.
    CharString getColorDbDir(int level = 1);

    /// get the project panels dir. returns the path including a trailing "/"
    /// @param level Level of the subdirectory.
    /// @return CharString with the directory.
    CharString getPanelsDir(int level = 1);

    /// get the project images dir. returns the path including a trailing "/"
    /// @param level Level of the subdirectory.
    /// @return CharString with the directory.
    CharString getImagesDir(int level = 1);

    /// get the project scripts dir. returns the path including a trailing "/"
    /// @param level Level of the subdirectory.
    /// @return CharString with the directory.
    CharString getScriptsDir(int level = 1);

    /// get the project ctrl lib dir. returns the path including a trailing "/"
    /// @param level Level of the subdirectory.
    /// @return CharString with the directory.
    CharString getLibsDir(int level = 1);

    /// get the project data dir. returns the path including a trailing "/"
    /// @param level Level of the subdirectory.
    /// @return CharString with the directory.
    CharString getDataDir(int level = 1);

    /// get the project db\pvss dir. returns the path including a trailing "/"
    /// @param level Level of the subdirectory.
    /// @return CharString with the directory.
    CharString getDbDir(int level = 1);

    /// get the project db\lta dir. returns the path including a trailing "/"
    /// @param level Level of the subdirectory.
    /// @return CharString with the directory.
    CharString getLtaDir(int level = 1);

    /// get the project log dir. returns the path including a trailing "/"
    /// @param level Level of the subdirectory.
    /// @return CharString with the directory.
    CharString getLogDir(int level = 1);

    /// get the project dplist dir. returns the path including a trailing "/"
    /// @param level Level of the subdirectory.
    /// @return CharString with the directory.
    CharString getDplistDir(int level = 1);

    /// get the pvss2 nls dir. returns the path including a trailing "/"
    /// @return CharString with the directory.
    CharString getNlsDir();

    /// get the proj nls dir. returns the path including a trailing "/"
    /// @param level Level of the subdirectory.
    /// @return CharString with the directory.
    CharString getProjNlsDir(int level = 1);

    /// get the pvss2 text dir. returns the path including a trailing "/"
    /// @return CharString with the directory.
    CharString getTextsDir();

    /// get the project reports dir. returns the path including a trailing "/"
    /// @param level Level of the subdirectory.
    /// @return CharString with the directory.
    CharString getReportDir(int level = 1);

    /// get the project pixmaps dir. returns the path including a trailing "/"
    /// @param level Level of the subdirectory.
    /// @return CharString with the directory.
    CharString getPixmapsDir(int level = 1);

    /// get the pvss icons dir. returns the path including a trailing "/"
    /// @param level Level of the subdirectory.
    /// @return CharString with the directory.
    CharString getIconsDir(int level = 1) {return getPicturesDir(level);}

    /// get the project gif dir. returns the path including a trailing "/"
    /// @param level Level of the subdirectory.
    /// @return CharString with the directory.
    CharString getGifDir(int level = 1);

    /// get the pvss printerfonts dir. returns the path including a trailing "/"
    /// @return CharString with the directory.
    CharString getPrinterFontDir();

    /// get the pvss dbtools dir. returns the path including a trailing "/"
    /// @return CharString with the directory.
    CharString getDbtoolsDir();

    /// get the pvss dbdfiles dir. returns the path including a trailing "/"
    /// @return CharString with the directory.
    CharString getDbdfilesDir();

    /// get the project log file. returns the path including a trailing "/"
    /// @param level Level of the subdirectory.
    /// @return CharString with the directory.
    CharString getLogFile(int level = 1);

    /// get the project dbg file. returns the path including a trailing "/"
    /// @param level Level of the subdirectory.
    /// @return CharString with the directory.
    CharString getDbgFile(int level = 1);

    /// get the path to the error description file. returns the path including a trailing "/"
    /// @param level Level of the subdirectory.
    /// @return CharString with the directory.
    CharString getErrTextDir(int level = 1);

    /// get the text file name without path
    /// @return CharString with the directory.
    CharString getErrTextFileName();

    /// get the Err text file path and name
    /// @param localeStr Locale string.
    /// @return CharString with the directory.
    CharString getErrTextFile(CharString localeStr);

    /// get the Xml dir. returns the path includinga trailing "/"
    /// @param level Level of the subdirectory.
    /// @return CharString with the directory.
    CharString getXmlDir(int level = 1);

    /// Gets the number of items in the projDir list.
    /// @return int with the number of items.
    int  getSearchPathLen();

  protected:

    /// Initialize all files of the current project.
    /// @return true if successfull, false otherwise.
    bool initProjDirsV1();

    /// Initialize all files of an old Project (<  V2.10).
    /// @param languages Languages.
    /// @return true if successfull, false otherwise.
    bool initProjDirsV2(const DynVar *languages);

    /// Initialize all files of a new Project (>=  V2.10).
    /// @param languages Languages.
    /// @param filter Path filters.
    /// @return true if successfull, false otherwise.
    bool initProjDirsV2(const DynVar *languages, FilterPathes filter);

    /// list of all necassary files of the current Project.
    DynPtrArray<ProjDirs> *projDirs_;

    /// list of all necessary files of a old Project (<  V2.10).
    DynPtrArray<ProjDirs> projDirsV1_;     

    /// list of all necessary files of a new Project (>= V2.10).
    DynPtrArray<ProjDirs> projDirsV2_;

  private:

    /// PVSS root directory.
    CharString                  pvssDir_;

    /// Array of the project directories and files.
    SimplePtrArray<CharString>  projDir_;
};


// ---------------------------------------------------------------------------
inline void  Pathes::resetProjDirs()
{
  projDirs_ = 0;
  projDirsV1_.clear();
  projDirsV2_.clear();
}

// ---------------------------------------------------------------------------
inline void  Pathes::reset()
{
  pvssDir_ = "";
  projDir_.clear();
  resetProjDirs();
}


// ----------------------------------------------------------------------------
inline int Pathes::getSearchPathLen() 
{ 
  return(projDir_.getNumberOfItems() + 1); 
}


// ----------------------------------------------------------------------------
inline CharString Pathes::getPvssDir()
{ 
  return pvssDir_; 
}

// ----------------------------------------------------------------------------
inline CharString Pathes::getProjDir(int level)
{ 
  if (level <= 0)
    return "";
  else if (level <= (int) projDir_.getNumberOfItems())
    return *projDir_[projDir_.getNumberOfItems() - level];
  else if (level == (int) projDir_.getNumberOfItems() + 1)
    return pvssDir_;
  else
    return "";
}

// ----------------------------------------------------------------------------
inline CharString Pathes::getProjDirC(int level)
{
  return getProjDir(level); 
}

// ----------------------------------------------------------------------------
inline  CharString Pathes::getBinDir()
{
  return getPvssDir() + "bin" + FileSys::PATH_CHAR; 
}


// ----------------------------------------------------------------------------
inline  CharString Pathes::getProjBinDir(int level)
{
  return getProjDir(level) + "bin" + FileSys::PATH_CHAR; 
}


// ----------------------------------------------------------------------------
inline  CharString Pathes::getSourceDir(int level)
{
  return getProjDir(level) + "source" + FileSys::PATH_CHAR; 
}


// ----------------------------------------------------------------------------
inline  CharString Pathes::getHelpDir(int level)
{
  return getProjDir(level) + "help" + FileSys::PATH_CHAR; 
}


// ----------------------------------------------------------------------------
inline  CharString Pathes::getMsgDir(int level)
{
  return getProjDir(level) + "msg" + FileSys::PATH_CHAR; 
}


// ----------------------------------------------------------------------------
inline  CharString Pathes::getConfigDir(int level)
{
  return getProjDir(level) + "config" + FileSys::PATH_CHAR; 
}


// ----------------------------------------------------------------------------
inline  CharString Pathes::getPicturesDir(int level)
{
  return getProjDir(level) + "pictures" + FileSys::PATH_CHAR; 
}


// ----------------------------------------------------------------------------
inline CharString Pathes::getPrintersDir(int level)
{
  return getProjDir(level) + "printers" + FileSys::PATH_CHAR; 
}


// ----------------------------------------------------------------------------
inline CharString Pathes::getColorDbDir(int level)
{
  return getProjDir(level) + "colorDB" + FileSys::PATH_CHAR; 
}


// ----------------------------------------------------------------------------
inline CharString Pathes::getPanelsDir(int level)
{
  return getProjDir(level) + "panels" + FileSys::PATH_CHAR; 
}


// ----------------------------------------------------------------------------
inline CharString Pathes::getImagesDir(int level)
{
  return getProjDir(level) + "images" + FileSys::PATH_CHAR; 
}


// ----------------------------------------------------------------------------
inline CharString Pathes::getScriptsDir(int level)
{
  return getProjDir(level) + "scripts" + FileSys::PATH_CHAR; 
}


// ----------------------------------------------------------------------------
inline CharString Pathes::getLibsDir(int level)
{
  return getScriptsDir(level) + "libs" + FileSys::PATH_CHAR; 
}


// ----------------------------------------------------------------------------
inline CharString Pathes::getDataDir(int level)
{
  return getProjDir(level) + "data" + FileSys::PATH_CHAR; 
}


// ----------------------------------------------------------------------------
inline CharString Pathes::getDbDir(int level)
{
  return getProjDir(level) + "db" + FileSys::PATH_CHAR + "wincc_oa" + FileSys::PATH_CHAR; 
}


// ----------------------------------------------------------------------------
inline CharString Pathes::getLtaDir(int level)
{
  return getProjDir(level) + "db" + FileSys::PATH_CHAR + "lta" + FileSys::PATH_CHAR; 
}


// ----------------------------------------------------------------------------
inline CharString Pathes::getLogDir(int level)
{
  return getProjDir(level) + "log" + FileSys::PATH_CHAR; 
}


// ----------------------------------------------------------------------------
inline CharString Pathes::getDplistDir(int level)
{
  return getProjDir(level) + "dplist" + FileSys::PATH_CHAR; 
}


// ----------------------------------------------------------------------------
inline CharString Pathes::getNlsDir()
{
  return getPvssDir() + "nls" + FileSys::PATH_CHAR; 
}


// ----------------------------------------------------------------------------
inline CharString Pathes::getProjNlsDir(int level)
{
  return getProjDir(level) + "nls" + FileSys::PATH_CHAR; 
}


// ----------------------------------------------------------------------------
inline CharString Pathes::getTextsDir()
{
  return ""; 
}


// ----------------------------------------------------------------------------
// -- UI                                                                     --
// ----------------------------------------------------------------------------
inline CharString Pathes::getReportDir(int level)
{
  return getProjDir(level) + "reports" + FileSys::PATH_CHAR; 
}


// ----------------------------------------------------------------------------
inline CharString Pathes::getPixmapsDir(int level)
{
  return getProjDir(level) + "pictures" + FileSys::PATH_CHAR; 
}


// ----------------------------------------------------------------------------
inline CharString Pathes::getGifDir(int level)
{
  return getProjDir(level) + "pictures" + FileSys::PATH_CHAR; 
}


// ----------------------------------------------------------------------------
inline CharString Pathes::getPrinterFontDir()
{
  return getPrintersDir() + "printerFontDir" + FileSys::PATH_CHAR; 
}


// ----------------------------------------------------------------------------
// -- dbtools                                                                --
// ----------------------------------------------------------------------------
inline CharString Pathes::getDbtoolsDir()
{
  return getPvssDir() + "bin" + FileSys::PATH_CHAR; 
}

// ----------------------------------------------------------------------------
inline CharString Pathes::getDbdfilesDir()
{
  return getPvssDir() + "dbdfiles" + FileSys::PATH_CHAR; 
}



// ----------------------------------------------------------------------------
// ----------------------------------------------------------------------------
// ----------------------------------------------------------------------------
inline CharString Pathes::getLogFile(int level)
{
  return getLogDir(level) + FileSys::PATH_CHAR + CharString("PVSS_II.log"); 
}


// ----------------------------------------------------------------------------
inline CharString Pathes::getDbgFile(int level)
{
  // return getProjDir(level) + "db" + FileSys::PATH_CHAR + "dbg"; 
  return getLogDir(level) + FileSys::PATH_CHAR + "dbg";  
}



// ----------------------------------------------------------------------------
/// get the text file name without path
// ----------------------------------------------------------------------------
inline CharString Pathes::getErrTextFileName()
{
  return(CharString("_errors.cat"));
}

// ----------------------------------------------------------------------------
// get the path to the File error description <SearchPath>\msg\    _
// ----------------------------------------------------------------------------
inline CharString Pathes::getErrTextDir(int level)
{
  return getMsgDir(level);
}

// ----------------------------------------------------------------------------
/// get the Err text file path and name
// ----------------------------------------------------------------------------
inline CharString Pathes::getErrTextFile(CharString localeStr)
{
  CharString errsTxt;

  if (pvssDir_ != CharString(""))
  {
    errsTxt = getErrTextDir(getSearchPathLen()) + localeStr + CharString(FileSys::PATH_CHAR) + getErrTextFileName();  
  }

  return(errsTxt);
}


// -------------------------------------------------------------------------------
// Get the path to the xml dir
// -------------------------------------------------------------------------------
inline CharString Pathes::getXmlDir(int level)
{
  return getProjDir(level) + "xml" + FileSys::PATH_CHAR;
}

#endif /* _PATHES_H_ */
