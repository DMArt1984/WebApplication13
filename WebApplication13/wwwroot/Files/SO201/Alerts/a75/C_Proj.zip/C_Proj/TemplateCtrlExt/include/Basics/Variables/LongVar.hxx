#ifndef _LONGVAR_H_
#define _LONGVAR_H_

#ifndef _VARIABLE_H_
#include <Variable.hxx>
#endif

#ifndef _CHARSTRING_H_
#include <CharString.hxx>
#endif

/** A Variable class representing 64-bit integers.
*/
//author	Christoph Theis 
class DLLEXP_BASICS LongVar : public Variable
{
  public:
    /** Constructor
        @param init PVSSlonglong initial value.
    */
    LongVar(PVSSlonglong init = 0) : value(init) { cachedIsA = LONG_VAR; }
 
    /** Copy constructor
        @param rVal Source LongVar value to be copied.
    */
    LongVar(const LongVar &rVal) : Variable(rVal),value(rVal.value)  { cachedIsA = LONG_VAR; }

    /** Declares new and delete operator.
    */
    AllocatorDecl;

    /** Outputs LongVar value to the itcNdrUbSend stream.
        @param ndrStream Output stream.
        @param iVar Streamed LongVar variable.
        @return itcNdrUbSend stream.
    */
    friend DLLEXP_BASICS itcNdrUbSend &operator<<(itcNdrUbSend &ndrStream, const LongVar &iVar);

    /** Receives the LongVar value from the itcNdrUbReceive stream.
        @param ndrStream input stream.
        @param iVar LongVar variable receiving the value from the stream.
        @return itcNdrUbReceive stream.
    */
    friend DLLEXP_BASICS itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream, LongVar &iVar);
    
     /** Outputs LongVar value to the std::ostream.
        @param ofStream Output stream.
        @param iVar Streamed LongVar variable.
        @return std::ostream stream.
    */   
    friend DLLEXP_BASICS std::ostream &operator<<(std::ostream &ofStream, const LongVar &iVar);

    /** Receives the LongVar value from the std::istream stream.
        @param ifStream input stream.
        @param iVar LongVar variable receiving the value from the stream.
        @return std::istream stream.
    */
    friend DLLEXP_BASICS std::istream &operator>>(std::istream &ifStream, LongVar &iVar);

    /** Comparison operator ==
        @param rVal Compared value.
        @return int 1 if the values are equal, otherwise 0.
        @n Important: this operator checks the VariableType, so two objects are equal only if
        they also have the same type (no conversion is done; see other operators).
    */
    virtual int operator==(const Variable &rVal) const;

    /** Comparison operator <
        @param rVal Compared value.
        @return int 1 if true, otherwise 0.
        @n Important: this operator also converts the given rVal to its own class-type if needed.
    */
    virtual int operator<(const Variable &rVal) const;

    /** Comparison operator >
        @param rVal Compared value.
        @return int 1 if true, otherwise 0.
        @n Important: this operator also converts the given rVal to its own class-type if needed.
    */
    virtual int operator>(const Variable &rVal) const;

    /** Overloaded assignment operator used for type conversions.
        @param rVal Assigned value.
        @return Variable with assigned value.
    */
    virtual Variable &operator=(const Variable &rVal);

    /** Assignment operator.
        @param rVal PVSSlonglong assigned value.
        @return LongVar with the assigned value.
    */
    LongVar &operator=(PVSSlonglong rVal);

    /** Check if variable is logically true (if value != 0)
        @return PVSS_TRUE or PVSS_FALSE.
    */
    virtual PVSSboolean isTrue() const {if (value) return PVSS_TRUE; return PVSS_FALSE;}

    /** Clone the current variable object
        @return Variable* pointer to a newly created LongVar with the same value,
        created by the copy constructor.
    */
    virtual Variable *clone() const {return new LongVar(value);}

    /** Cast to PVSSlonglong
    */
    operator PVSSlonglong () const { return value; }

    /** Creates a new LongVar variable
        @return Variable* pointer to a newly allocated LongVar created with the
        default contructor (value is 0).
    */
    virtual Variable *allocate() const { return new LongVar; }

    /** Overloaded function returning LONG_VAR
        @return VariableType
    */
    virtual VariableType isAUncached() const { return LONG_VAR; }

    /** Returns the VariableType for the specified type
        @param varType VariableType.
        @return VariableType for this type.
    */
    virtual VariableType isAUncached(VariableType varType) const;

# if 0
    // DOC++-Kommentare
    /// Get own variable type. Always returns LONG_VAR.
    VariableType  isA() const;
    /** Check if own variable type matches varType.
        Returns LONG_VAR if argument is LONG_VAR, and NOTYPE_VAR else.
    */
    VariableType  isA(VariableType varType) const;
# endif

    /** Write value to output stream
        @param ofStream std::ostream to write to.
    */
    virtual void outToFile(std::ostream &ofStream) const;

    /** Read value from the input stream
        @param ifStream std::istream to read the value from.
    */
    virtual void inFromFile(std::istream &ifStream);

    /** Format the value acording to the format string
        @param  format  The format string. If the string is not empty it is
                used as an argument to the sprintf function.
                Else a default is used.
        @return The string representation of the value.
    */
    virtual CharString formatValue(const CharString &format) const;

    /** Format the value according to a format string.
        @param format The format string. If the string is not empty is is
               used as an argument to the sprintf function.
               Else a default is used.
        @param target This is a buffer with length len, which is directly written to.
               This method is more performant than the one which returns a CharString,
               because no alloc is done.
        @param len Size of the output buffer.
        @return Number of bytes written into target without 0-byte,
                or a negative value on error (like buffer too small).
    */
    virtual int formatValue(const CharString &format, char *target, size_t len) const;

    /** Get the value of the variable
        @return Internally stored PVSSlonglong (64-bit integer) value.
    */
    PVSSlonglong getValue() const { return value; }

    /** Set the value of the variable
        @param newValue New 64-bit integer value.
    */
    void setValue(const PVSSlonglong newValue) { value = newValue; }

    // versucht sich selbst in eine Variable "out" vom Typ "to" zu konvertieren
    // Returnwert:    OK: Konvertierung erfolgreich, "out" wurde neu allokiert
    //                OUT_OF_RANGE: Konvertierung grundsaetzlich moeglich, aber der
    //                Wert von "in" liegt ausserhalb des Wertebereichs des Typs "to",
    //                "out" wird trotzdem allokiert !!!! und enthaelt Min bzw. Max des
    //                moeglichen Wertebereichs
    //                CONV_NOT_DEFINED: Typumwandlung nicht moeglich, "out" wird auf 0
    //                gesetzt
    /** Converts the value to a Variable of another type
        @param to VariableType of the variable converting to.
        @param out VariablePtr to a newly created Variable of the desired type.
        @return OK if correctly converted, OUT_OF_RANGE or CONV_NOT_DEFINED otherwise.
    */
    virtual ConvertResult convert(VariableType to, VariablePtr &out) const;


    // mit encode und decode koennen Werte in bestimmten Bit (von - bis)
    // abgespeichert werden. Die von-bis Indizien gehen von 0 bis 31.
    // Mit dieser Funktionen kann der LongVar mehrere Werte speichern!
    /** Get the value from the bits interval.
        @param bitFrom Lowest bit number of the interval.
        @param bitTo Highest bit number of the interval.
        @return PVSSlonglong number at the bits <bitFrom, bitTo>
    */
    PVSSlonglong decodeBits(int bitFrom, int bitTo)  const 
    {
      PVSSlonglong bitMask = (((PVSSlonglong) 1) << (bitTo - bitFrom + 1)) - 1;
      return ((value >> bitFrom) & bitMask); 
    }

    /** Set only certain bits in the LongVar variable.
        @param bitFrom Lowest bit number of the interval.
        @param bitTo Highest bit number of the interval.
        @param code Value to be set into the bits in the interval <Lowest, Highest>.
    */
    void encodeBits(int bitFrom, int bitTo, PVSSlonglong code)
    {
      PVSSlonglong bitMask = (((PVSSlonglong) 1) << (bitTo - bitFrom + 1)) - 1;
      value &= (~(bitMask << bitFrom));
      value |= ((code & bitMask) << bitFrom);
    }

  private:
    void outNdrUb(itcNdrUbSend &ndrStream) const;
    void inNdrUb(itcNdrUbReceive &ndrStream);

    PVSSlonglong value;
};

#endif /* _LONGVAR_H_ */
