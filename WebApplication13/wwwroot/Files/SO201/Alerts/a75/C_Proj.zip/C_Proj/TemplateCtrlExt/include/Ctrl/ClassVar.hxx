#ifndef _ClassVar_H_
#define _ClassVar_H_

// author: 10.11.2015 Martin Koller
/**
  An instance of a user defined class type

  @classification ETM internal
*/

#include <CtrlVariable.hxx>
#include <Allocator.hxx>
#include <SimplePtrArray.hxx>
#include <CtrlVar.hxx>

class UserType;
class CtrlThread;
class CtrlScript;
class ConnTblEntry;

class DLLEXP_CTRL ClassVar : public CtrlVariable
{
  public:
    ClassVar(const UserType *type, bool doRefCount = true);
    virtual ~ClassVar();

    AllocatorDecl;

    virtual Variable *clone() const;
    virtual Variable *allocate() const { return clone(); }
    virtual VariableType isAUncached() const { return CLASS_VAR; }
    virtual VariableType isAUncached(VariableType varType) const;

    const UserType *getUserType() const { return userType; }
    const CharString &getUserTypeName() const;

    // return true if this is an instance of given type (or a baseclass of type if it's a CtrlClass)
    bool isInstanceOf(const UserType *type) const;

    virtual PVSSboolean isTrue() const;

    /** Overloaded assignment operator used for type conversions.
        @param rVal Assigned value.
        @return Variable with assigned value.
    */
    virtual Variable &operator=(const Variable &rVal);

    virtual bool assign(const Variable &rVal, CtrlThread *thread = 0);

    /** Comparison operator ==
        @param rVal Compared value.
        @return int 1 if the values are equal, otherwise 0.
        @n Important: this operator checks the VariableType, so two objects are only equal, if
        they also have the same Variable class (no conversion is done; see other operators).
        Also the userType must be the same
    */
    virtual int operator==(const Variable &rVal) const;

    virtual void outToFile(std::ostream &ofStream) const;

    virtual CharString formatValue(const CharString &format) const;

    void setMemberCount(unsigned int num);
    void setMemberCtrlVar(unsigned int idx, CtrlVar *value);

    unsigned int getMemberCount() const;

    // while parsing and using a userType class as declaration/parameter in a function inside the
    // class itself, the class is not yet completely known with all members. Therefore this method ensures
    // that the ClassVar matches the definition of the class
    void ensureMembers();

    // get class member by index (result can be a pointer to the single static member in class definition)
    Variable *getMemberValue(unsigned int idx = 0) const;

    // get class member by name (result can be a pointer to the single static member in class definition)
    CtrlVar *getMemberCtrlVar(const CharString &name, CtrlThread *thread = nullptr) const;

    const CharString &getMemberName(unsigned int idx) const;

    CtrlVar *getMemberCtrlVar(unsigned int idx) const;

    // registered threads will be set to invalid when this object is deleted
    void registerThread(CtrlThread *thread);
    void unregisterThread(CtrlThread *thread);

    // registered connections will be disconnected when this object is deleted
    void registerConnection(CtrlScript *script, ConnTblEntry *entry);
    void unregisterConnection(CtrlScript *script, ConnTblEntry *entry);

    class DLLEXP_CTRL Callback
    {
      public:
        virtual ~Callback() { }
        virtual void aboutToDie(ClassVar *var) = 0;
    };

    void registerCallback(Callback *cb);
    void unregisterCallback(Callback *cb);

    void setCtorFinished();
    bool wasCtorFinished() const;

  private:
    class ClassVarPrivate *d;
    const UserType *userType;
    SimplePtrArray<CtrlVar> memberVars;
    bool refCounting;
};

#endif
