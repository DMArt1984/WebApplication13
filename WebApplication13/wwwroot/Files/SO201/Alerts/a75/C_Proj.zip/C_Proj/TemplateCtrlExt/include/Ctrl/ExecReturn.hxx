#ifndef _EXECRETURN_H_
#define _EXECRETURN_H_

/*  author Martin Koller*/
/** defines the return-values for the script, thread and module execution */
enum ExecReturn
{
  EXEC_OK,
  EXEC_ERROR,
  EXEC_DONE
};

#endif /* _EXECRETURN_H_ */
