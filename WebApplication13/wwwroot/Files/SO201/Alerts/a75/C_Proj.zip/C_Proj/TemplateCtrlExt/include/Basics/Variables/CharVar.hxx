#ifndef _CHARVAR_H_
#define _CHARVAR_H_

// VERANTWORTUNG: Johannes Ertl
// BESCHREIBUNG:  Character-Variable im PVSS-2.

#ifndef _VARIABLE_H_
#include <Variable.hxx>
#endif

#ifndef _CHARSTRING_H_
#include <CharString.hxx>
#endif

/**
	A Variable class representing unsigned chars.
*/
class DLLEXP_BASICS CharVar : public Variable
{
  public:
    /** Constructor
        @param init PVSSuchar initial value.
    */
    CharVar(PVSSuchar init = 0) : value(init) { cachedIsA = CHAR_VAR; }

    /** Copy constructor
        @param rVal Source CharVar value to be copied.
    */
    CharVar(const CharVar &rVal) : Variable(rVal),value(rVal.value) { cachedIsA = CHAR_VAR; }

    /** Declares new and delete operator.
    */
    AllocatorDecl;

   /** Writes CharVar value to the itcNdrUbSend stream.
        @param ndrStream Output stream.
        @param cVar Streamed CharVar variable.
        @return itcNdrUbSend stream.
    */
    friend DLLEXP_BASICS itcNdrUbSend &operator<<(itcNdrUbSend &ndrStream, const CharVar &cVar);
    
    /** Reads the CharVar value from the itcNdrUbReceive stream.
        @param ndrStream input stream.
        @param cVar CharVar variable receiving the value from the stream.
        @return itcNdrUbReceive stream.
    */  
    friend DLLEXP_BASICS itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream, CharVar &cVar);
    
    /** Writes CharVar value to the std::ostream.
        @param ofStream Output stream.
        @param cVar Streamed CharVar variable.
        @return std::ostream stream.
    */
    friend DLLEXP_BASICS std::ostream &operator<<(std::ostream &ofStream, const CharVar &cVar);
    
    /** Reads the CharVar value from the std::istream stream.
        @param ifStream input stream.
        @param cVar CharVar variable receiving the value from the stream.
        @return std::istream stream.
    */
    friend DLLEXP_BASICS std::istream &operator>>(std::istream &ifStream, CharVar &cVar);

    /** Comparison operator ==
        @param rVal Compared value.
        @return int 1 if the values are equal, otherwise 0.
        @n Important: this operator checks the VariableType, so two objects are only equal, if
        they also have the same class (no conversion is done; see other operators)
    */
    virtual int operator==(const Variable &rVal) const;

    /** Comparison operator <
        @param rVal Compared value.
        @return int 1 if true, otherwise 0.
        @n Important: this operator also converts the given rVal to its own class-type if needed
    */
    virtual int operator<(const Variable &rVal) const;

    /** Comparison operator >
        @param rVal Compared value.
        @return int 1 if true, otherwise 0.
        @n Important: this operator also converts the given rVal to its own class-type if needed
    */
    virtual int operator>(const Variable &rVal) const;

    /** Overloaded assignment operator used for type conversions.
        @param rVal Assigned value.
        @return Variable with assigned value.
    */
    virtual Variable &operator=(const Variable &rVal);

    /** Single assignment operator.
        @param rVal PVSSlong assigned value.
        @return CharVar with the assigned value.
    */
    CharVar &operator=(PVSSuchar rVal);

    /** Checks if variable is logically true (if value != 0)
        @return PVSS_TRUE or PVSS_FALSE.
    */
    virtual PVSSboolean isTrue() const {return (value != 0);}

    /** Clone the current variable object
        @return Variable* pointer to a newly created CharVar with the same value,
        created by the copy constructor.
    */
    virtual Variable *clone() const {return new CharVar(value);}

    /** PVSSchar Cast operator
		@return PVSSchar casted variable
    */
    operator PVSSchar () const { return (PVSSchar) value; }

    /** PVSSuchar Cast operator
		@return PVSSuchar casted variable
    */
    operator PVSSuchar () const { return (PVSSuchar) value; }

    /** Creates a new dynamicaly allocated CharVar variable
	    @return Variable pointer to a newly allocated CharVar created by the
        default constructor (value is 0).
    */
    virtual Variable *allocate() const { return new CharVar; }

    /** Overloaded function returning CHAR_VAR
        @return VariableType (CHAR_VAR)
    */
    virtual VariableType isAUncached() const { return CHAR_VAR; }
    
    /** Returns the VariableType for the specified type
        @param varType VariableType.
        @return VariableType for this type.
    */
    virtual VariableType isAUncached(VariableType varType) const;
    
    /** Writes the value to the output stream
        @param ofStream std::ostream to write the value to.
    */
    virtual void outToFile(std::ostream &ofStream) const;
    
    /** Reads the value from the input stream
        @param ifStream std::istream to read the value from.
    */
    virtual void inFromFile(std::istream &ifStream);

    /** Formats the value acording to the format string.
        @param  format  The format string. If the string is not empty it is
                used as an argument to the sprintf function.
                Else a default is used.
		@return The string representation of the value.
    */
    virtual CharString formatValue(const CharString &format) const;

    /** Format the value according to a format string.
        @param format The format string. If the string is not empty is is
               used as an argument to the sprintf function.
               Else default value.
        @param target This is a buffer with length len, which is directly written to.
               This method is more performant than the one which returns a CharString,
               because no alloc is done.
        @param len A buffer length.
        @return Number of bytes written into target without 0-byte (1-byte),
                or a negative value on error (like buffer too small)
    */
    virtual int formatValue(const CharString &format, char *target, size_t len) const;

    /** Print the contents to an output stream. level controls the amount of debug information 
        printed. Nothing is printed if level == 0.
    */
    virtual void debug(std::ostream &to, int level) const;

    /** Gets the value of the variable
        @return Internally stored PVSSlong (32-bit integer) value.
    */
    PVSSuchar getValue() const { return value; }

    /** Sets the value of the variable
        @param newValue New 32-bit integer value.
    */
    void setValue(PVSSuchar newValue) { value = newValue; }

    // versucht sich selbst in eine Variable "out" vom Typ "to" zu konvertieren
    // Returnwert:    OK: Konvertierung erfolgreich, "out" wurde neu allokiert
    //                OUT_OF_RANGE: Konvertierung grundsaetzlich moeglich, aber der
    //                Wert von "in" liegt ausserhalb des Wertebereichs des Typs "to",
    //                "out" wird trotzdem allokiert !!!! und enthaelt Min bzw. Max des
    //                moeglichen Wertebereichs
    //                CONV_NOT_DEFINED: Typumwandlung nicht moeglich, "out" wird auf 0
    //                gesetzt

    /** Converts the value to a Variable of another type
        @param to VariableType of the variable converting to.
        @param out VariablePtr to a newly created Variable of the desired type.
        @return OK if correctly converted, OUT_OF_RANGE or CONV_NOT_DEFINED otherwise.
    */
    virtual ConvertResult convert(VariableType to, VariablePtr &out) const;

  private:
    void outNdrUb(itcNdrUbSend &ndrStream) const;
    void inNdrUb(itcNdrUbReceive &ndrStream);
    PVSSuchar value;
};

#endif /* _CHARVAR_H_ */
