#ifndef _DRVCONFIGMANAGER_H_
#define _DRVCONFIGMANAGER_H_

// Vorwaerts-Deklaration der Eigenen Klasse
class DrvConfigManager;

// System-Include-Files

#ifndef _DPCONFIGMANAGER_H_
#include <DpConfigManager.hxx>
#endif

#ifndef _DPCONFIG_H_
#include <DpConfig.hxx>
#endif

#ifndef _DPFLUTTERHDL_H_
#include <DpFlutterHdl.hxx>
#endif

#ifndef _DYNPTRARRAY_H_
#include <DynPtrArray.hxx>
#endif

/** This class manages driver configs.
  * @classification ETM internal
  */
class DrvConfigManager : public DpConfigManager 
{

public:

  /** Constructor
    */
  DrvConfigManager();

  /** Destructor
    */
  ~DrvConfigManager();

  // Spezielle Methoden :
  /** Allocate DP configuration on type of configuration
    * @param type type of DP configuration
    * @return pointer to DP configuration
    */ 
  virtual DpConfigPtr allocate(DpConfigType type);
  
  /** Check config against manager and element.
    * @param type configuration type
    * @param elType element type
    * @return PVSS_TRUE if both types are correct
    */ 
  virtual PVSSboolean checkConfigType(DpConfigType type, DpElementType elType);
  
  /** Check for changing of valid DP configuration types
    * @param t1 configuration type
    * @param t2 configuration type
    * @return PVSS_TRUE if change of types is possible
    */ 
  virtual PVSSboolean validTypeChange(DpConfigType t1, DpConfigType t2);

private:
  //STANO
  /** Get pointer to DP configuration 
    * @param sysNum
    * @param dpId DP identifier
    * @param dpEl  DP elemnet
    * @param dpConfigNr DP config number
    * @return pointer to DP configuration
    */
  static DpConfig *getConfigPtr(SystemNumType sysNum, DpIdType dpId, DpElementId dpEl, DpConfigNrType dpConfigNr);

  /** Allocate DP flutter handler
    * @param sysNum
    * @param dpId DP identifier
    * @param dpEl  DP element
    * @param idx dynamic pointer array index
    * @param due time variable
    * @return itcIOHandler
    */
  static itcIOHandler *allocFlutterHdl(SystemNumType sysNum, DpIdType dpId, DpElementId dpEl, DynPtrArrayIndex idx, const TimeVar &due);

};

// ================================================================================
// Inline-Funktionen :

inline itcIOHandler *DrvConfigManager::allocFlutterHdl(SystemNumType sysNum, DpIdType dpId, DpElementId dpEl, DynPtrArrayIndex idx, const TimeVar &due)
{
  return DpFlutterHdl::allocate(sysNum, dpId, dpEl, idx, due);
}

#endif /* _DRVCONFIGMANAGER_H_ */
