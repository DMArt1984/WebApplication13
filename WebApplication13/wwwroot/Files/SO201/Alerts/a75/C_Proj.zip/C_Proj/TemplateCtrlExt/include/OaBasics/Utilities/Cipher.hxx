#ifndef CIPHER_H
#define CIPHER_H

#include <Blob.hxx>
#include <CharString.hxx>

class DLLEXP_OABASICS Cipher
{
public:
  /*
  * possible SSLWrapper init statusses
  */
  enum SSLWrapperInitStatus
  {
    VERSION_NOT_SUFFICIENT = -3,
    FUNCTION_NOT_FOUND = -2,
    LIBRARY_NOT_FOUND = -1,
    NOT_INITIALIZED = 0,
    INIT_SUCCEEDED = 1
  };

  /**
  possible algorithms
  */
  enum Algorithm
  {
    AES256  // en/decrypt using Aes256
  };

  /**
  possible modes
  */
  enum Mode
  {
    AES256_CBC           // en/decryption mode is CBC
  };

  /**
  Constructor: initalize the sslWraper and try to load the openssl library.
  */
  Cipher(Algorithm algo, Mode m);

  ~Cipher();
  
  /**
  encrypt data with the specified algorithm
  @param data the data to encrypt
  @param key  the key for encryption
  @return the encrypted data. If encryption failed, the lenght of the blob is null, please call getLastOpenSSLError.
  */
  const Blob &encrypt(const Blob &data, const CharString &key);

  /**
  encrypt data with the specified algorithm
  @param data the data to decrypt
  @param key  the key for decryption
  @return the decrypted data. If decryption failed, the lenght of the blob is null, please call getLastOpenSSLError.
  */
  const Blob &decrypt(const Blob &data, const CharString &key);

  /** Get the human readable error string from the last ssl error.
      For details and openssl error codes please see openssl documentation for ERR_get_error.
      @param errorText the openssl error code as text.
      @param openSSLErrorCode last openssl errorcode
      @return initalization's status of the SSLWrapper. If it not INIT_SUCCEEDED, then the openSSLErrorCode and errorText will be empty.
  */
  Cipher::SSLWrapperInitStatus getLastOpenSSLError(std::string& errorText, unsigned long openSSLErrorCode);

  /**
      Check the success of initialization. If the openssl doesn't exist, retuns false.
      @return the value of sslinitialized, false if there any proplem of initalization of sslWrapper or cannot load the openssl library. 
  */
  bool isSslinitialized(){ return (sslInitStatus == INIT_SUCCEEDED); }

private:
  /**
  encrypt data using Aes256
  */
  void encryptAes256(const Blob &in, const CharString &key, Blob &out);

  /**
  decrypt data using Aes256
  */
  void decryptAes256(const Blob &in, const CharString &key, Blob &out);

private:
  Algorithm algorithm_;
  Mode mode_;
  Blob data_;
  SSLWrapperInitStatus sslInitStatus;
};

#endif // !CIPHER_H
