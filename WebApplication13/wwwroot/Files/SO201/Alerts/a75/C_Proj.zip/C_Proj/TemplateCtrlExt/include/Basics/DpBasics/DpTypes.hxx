#ifndef _DPTYPES_H_
#define _DPTYPES_H_

// DATEIBESCHREIBUNG ==============================================================
// DATEINAME:     DpTypes.hxxx
// VERANTWORTUNG: Thomas Exner
// BESCHREIBUNG: Verschiedene Typdefinitionen zu Datenpunkten, Dp-Elementen,
//               Configs usw.
//
// AENDERUNGS-HISTORIE
// Ver.  | Datum      | Aenderungen                            | ModNr.| Autor
// ------+------------+-----------------Anfang-----------------+-------+-----------
//   1.0 |            | 1.Erstellung mit Westmount-OMT         |     0 |
// ======================================Ende======================================
// System-Include-Files
#ifndef _TYPES_HXX_
#include <Types.hxx>
#endif

// ========== DpAttributeNrType ============================================================
// Typ zur adressierung eines Attributes. Die ersten beiden Bytes entsprechen dem
// Attributtyp, die gleich dem Variablentyp ist. Sollte der Typ des Attributes vom Element,
// an dem das Konfig haengt abhaengen, so ist die Attributnummer VARIABLE+....
/** The attribute number type. If the attribute type depends on the element (_original.._value),
    the high word holds the element type and the low word the attribute number.
*/
typedef PVSSlong DpAttributeNrType;

// ========== DpDetailNrType ============================================================
// Typ zur adressierung der Detailnummer im DpConfig.
/** The detail number type. */
typedef PVSSshort DpDetailNrType;

// ========== DpElementId ============================================================
// Ein Elementbezeichner innerhalbs eines Typs.
/** The element number type. The element number is assigned through the datapoint type and
    therefore describes the element number for all datapoints of this type. Always a  
    higher number than those  used is assigned to an new element.
    element is assigned the next higher number than that last used.
*/
typedef PVSSshort DpElementId;

// ========== DpIdType ============================================================
// Typ des Datenpunkt-Identifiers.
/** The datapoint number type. This is a systemwide unique number assigned by the 
    data manager when the datapoint is created. Always a higher number than those
    already used is assigned to an new datapoint.
*/
typedef PVSSulong DpIdType;

// ========== DpTypeId ============================================================
// Typ-Bezeichner des DpTypNamens.
/** The datapoint type number type. This is a systemwide unique number assigned by 
    the data manager when the new datapoint type is created.
*/
typedef PVSSshort DpTypeId;       // die sollte auch auf PVSSulong aufgebort werden (siehe DpIdType)

// ========== SystemNumType ============================================================
#ifndef _SYSTEMNUMTYPE_HXX_
#include <SystemNumType.hxx>
#endif


#endif /* _DPTYPES_H_ */

