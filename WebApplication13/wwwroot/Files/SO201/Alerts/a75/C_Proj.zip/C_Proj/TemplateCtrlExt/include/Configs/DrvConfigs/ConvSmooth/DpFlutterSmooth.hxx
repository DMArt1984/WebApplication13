// DATEIBESCHREIBUNG ==============================================================
// DATEINAME:     DpFlutterSmooth.hxx
// VERANTWORTUNG:	Stanislav Meduna
// 
// BESCHREIBUNG:	Flatterunterdrueckung.
//
// AENDERUNGS-HISTORIE
// Ver.  | Datum      | Aenderungen                            | ModNr.| Autor
// ------+------------+-----------------Anfang-----------------+-------+-----------
//   1.0 |            | 1.Erstellung mit Westmount-OMT         |     0 |
// ======================================Ende======================================
#ifndef _DPFLUTTERSMOOTH_H_
#define _DPFLUTTERSMOOTH_H_

// Vorwaerts-Deklaration der Eigenen Klasse
class DpFlutterSmooth;

// System-Include-Files
#include <BitVar.hxx>
#include <DpSmoothing.hxx>
#include <TimeVar.hxx>

// Vorwaerts-Deklarationen :
class DpConvSmooth;
class DpFlutterSmooth;
class Variable;
class itcIOHandler;

// ========== DpFlutterSmooth ============================================================

/** This is a flutter smoothing class used to smooth bit variables. It supports natively BIT_VAR only.
    The class can be configured using following attributes:
        - smoothing interval

    Smoothing interval defines the time within any value changes are ignored. The flutter smoothing uses
    internally DpFlutterHdl class that provides full timer support. Additionally the flutter smoothing class
    calls into the smoothing container  to obtain that flutter handler and to start/stop the timer.

    @classification public use
*/
class DLLEXP_CONFIGS DpFlutterSmooth : public DpSmoothing 
{
    friend class UNIT_TEST_FRIEND_CLASS;   
  // Klassen-Enums:

// ..........................Anfang User-Klasseninterne-Definitionen..................
// ...........................Ende User-Klasseninterne-Definitionen...................
public:
  /** Default constructor.
   */
  DpFlutterSmooth();
  
  /** Default destructor.
   */
  ~DpFlutterSmooth();


  // Operatoren :

  /** Writes content of the smoothing class to the output stream.
        @param ndrStream Output stream.
        @param aConv Reference to DpFlutterSmooth instance.
        @return itcNdrUbSend stream.
   */
  friend DLLEXP_CONFIGS itcNdrUbSend &operator<<(itcNdrUbSend &ndrStream, const DpFlutterSmooth &aConv);
  
  /** Reads contents of the smoothing from the input stream.
        @param ndrStream Input stream.
        @param aConv Reference to DpFlutterSmooth instance.
        @return itcNdrUbSend stream.
   */
  friend DLLEXP_CONFIGS itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream, DpFlutterSmooth &aConv);
  
  /** Assignment operator used for type conversions (*x)=(*y).
      @param aConv Reference to DpFlutterSmooth instance.  
      @return DpConvSmooth reference.
    */  
  virtual DpConvSmooth &operator=(const DpConvSmooth &aConv);

  // Spezielle Methoden :

  /** Returns the class smoothing type.
      @return always DpConvFlutterSmooth type
   */
  virtual DpConversionType convType() const;

 /** Performs flutter smoothing for a given input variable. This is a easy-to-use version of 'convert' method that does not provide the sysNum, dpId, elNo
   *  and myIndex parameters. (see other 'convert' method)   
      @param inpVar value of the variable.  
      @param outVarPtr smoothed output value.  
      @param timeVar timestamp of the variable.  
      @param ubits user defined bytes.  
      @return DpConversionOK on success and DpSmoothed if value was smoothed. In the case of an error a DpConversionError value is returned.
   */
  virtual DpConversionResultType convert(const Variable &inpVar, Variable * & outVarPtr, const TimeVar &timeVar, const BitVec &ubits);
  
  /** Performs flutter smoothing for a given input variable.    
      @param inpVar value of the variable.  
      @param outVarPtr smoothed output value.  
      @param timeVar timestamp of the variable.  
      @param ubits user defined bytes.  
      @param sysNum system number.  
      @param dpId datapoint type id.  
      @param elNo datapoint element id.  
      @param myIndex index of XXX.  
      @return DpConversionOK on success and DpSmoothed if value was smoothed. In the case of an error a DpConversionError value is returned.
   */
  virtual DpConversionResultType convert(const Variable &inpVar, Variable * & outVarPtr, const TimeVar &timeVar, const BitVec &ubits, 
              SystemNumType sysNum, DpIdType dpId, DpElementId elNo, DynPtrArrayIndex myIndex);
  
  /** Allocates a new DpFlutterSmooth object.
      @return A pointer to a newly created object, or NULL.
   */
  virtual DpConvSmooth *allocate() const;
  
  /** Sets a new value of specified smoothing attribute.
      @param attrNr specified attribute number.  Following attributes are supported by this class : FLUTTER_SMOOTH_TIME_ATTR and FLUTTER_SMOOTH_OLDNEW_ATTR.
      @param var a Variable object that holds specified attribute.
      @return PVSS_TRUE if the attribute's value was succesfully updated or PVSS_FALSE otherwise.
   */
  virtual PVSSboolean setAttribut(DpAttributeNrType attrNr, const Variable &var);

  /** Returns specified smoothing attribute value.
      @param attrNr specified attribute number.  Following attributes are supported by this class : TYPE_ATTR, FLUTTER_SMOOTH_TIME_ATTR and FLUTTER_SMOOTH_OLDNEW_ATTR.
      @return A pointer to a Variable objects that holds specified attribute.
   */
  virtual Variable *getAttribut(DpAttributeNrType attrNr) const;
  
  /** Indicates if the instance is properly configured.
      @return always PVSS_TRUE 
   */
  virtual PVSSboolean isConsistent() const;

  // Generierte Methoden :

  /** Returns actual smoothing flutter interval attribute. (const version)
      @return A reference to a TimeVar value that holds smoothing interval.
   */
  const TimeVar &getAttrInterval() const;
  
  /** Returns actual smoothing flutter interval attribute. 
      @return A reference to a TimeVar value that holds smoothing interval.
   */
  TimeVar &getAttrInterval();
  
  /** Sets a new smoothing flutter interval attribute. 
      @param newAttrInterval A reference to a TimeVar value that holds smoothing interval.
   */
  void setAttrInterval(const TimeVar &newAttrInterval);
 
  /** Returns last sent bit value. (const version)
      @return A reference to a BitVar value that holds last sent value.
   */
  const BitVar &getLastValueSent() const;
  
  /** Returns last sent bit value. 
      @return A reference to a BitVar value that holds last sent value.
   */
  BitVar &getLastValueSent();

  /** Sets a last sent bit value. 
      @param newLastValueSent A reference to a BitVar value that holds last sent bit value.
   */
  void setLastValueSent(const BitVar &newLastValueSent);
  
  /** Returns last received bit value. (const version)
      @return A reference to a BitVar value that holds last sent value.
   */
  const BitVar &getLastValueReceived() const;
  
  /** Returns last received bit value. 
      @return A reference to a BitVar value that holds last sent value.
   */  
  BitVar &getLastValueReceived();

  /** Sets a last received bit value. 
      @param newLastValueReceived A reference to a BitVar value that holds last sent bit value.
   */  
  void setLastValueReceived(const BitVar &newLastValueReceived);
  
  /** Returns status of the internal flutter timer. (const version)
      @return PVSS_TRUE if the timer is running, otherwise PVSS_FALSE.
   */
  const PVSSboolean &getTimerRunning() const;

  /** Returns status of the internal flutter timer.
      @return PVSS_TRUE if the timer is running, otherwise PVSS_FALSE.
   */
  PVSSboolean &getTimerRunning();

  /** Sets the status of the internal flutter timer. 
      @param newTimerRunning A boolean value.
   */  
  void setTimerRunning(const PVSSboolean &newTimerRunning);
  
  /** Removes the pending handler. NO DEFINITION !!!!
   */
  void removePendingHdl();

  /** Checks the internal pending handler pointer.
      @return PVSS_TRUE if the pointer is not NULL, otherwise PVSS_FALSE.
   */
  int isValidPendingHdl() const;

protected:
private:
  const TimeVar &getLastTime() const;
  TimeVar &getLastTime();
  void setLastTime(const TimeVar &newLastTime);

  TimeVar attrInterval;
  PVSSboolean attrOldNew;

  BitVar lastValueSent;
  BitVar lastValueReceived;
  TimeVar lastTime;
  PVSSboolean timerRunning;
  itcIOHandler *pendingHdlPtr;

// ............................Anfang User-Attribut-Definitionen...................
// .............................Ende User-Attribut-Definitionen....................
};

// ================================================================================
// Inline-Funktionen :
inline const TimeVar &DpFlutterSmooth::getAttrInterval() const
{
  return attrInterval;
}

inline TimeVar &DpFlutterSmooth::getAttrInterval()
{
  return attrInterval;
}
inline void DpFlutterSmooth::setAttrInterval(const TimeVar &newAttrInterval)
{
  attrInterval = (TimeVar &) newAttrInterval;
}
inline const BitVar &DpFlutterSmooth::getLastValueSent() const
{
  return lastValueSent;
}

inline BitVar &DpFlutterSmooth::getLastValueSent()
{
  return lastValueSent;
}
inline void DpFlutterSmooth::setLastValueSent(const BitVar &newLastValueSent)
{
  lastValueSent = (BitVar &) newLastValueSent;
}
inline const BitVar &DpFlutterSmooth::getLastValueReceived() const
{
  return lastValueReceived;
}

inline BitVar &DpFlutterSmooth::getLastValueReceived()
{
  return lastValueReceived;
}
inline void DpFlutterSmooth::setLastValueReceived(const BitVar &newLastValueReceived)
{
  lastValueReceived = (BitVar &) newLastValueReceived;
}
inline const TimeVar &DpFlutterSmooth::getLastTime() const
{
  return lastTime;
}

inline TimeVar &DpFlutterSmooth::getLastTime()
{
  return lastTime;
}
inline void DpFlutterSmooth::setLastTime(const TimeVar &newLastTime)
{
  lastTime = (TimeVar &) newLastTime;
}
inline const PVSSboolean &DpFlutterSmooth::getTimerRunning() const
{
  return timerRunning;
}

inline PVSSboolean &DpFlutterSmooth::getTimerRunning()
{
  return timerRunning;
}
inline void DpFlutterSmooth::setTimerRunning(const PVSSboolean &newTimerRunning)
{
  timerRunning = (PVSSboolean &) newTimerRunning;
}

inline int DpFlutterSmooth::isValidPendingHdl() const
{
  return pendingHdlPtr != 0;
}


// ............................Anfang User-Inlines.................................
// .............................Ende User-Inlines..................................

// ................................OMT-Regeneration................................

#endif /* _DPFLUTTERSMOOTH_H_ */
