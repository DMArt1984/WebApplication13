#ifndef _FILESYSSLIM_H_
#define _FILESYSSLIM_H_

/*
VERANTWORTUNG: Guenter Szolderits
BESCHREIBUNG: wrapper class for file system related functions
WOKL 4.3.03: aus FileSys die Superklasse abgeleitet wg. Variablen fuer RemoteInstall
  In dieses File d�rfen KEINE Variablenklassen aus PVSS eingebracht werden!
*/

#ifndef _TYPES_HXX_
#include <Types.hxx>
#endif

#ifndef _CHARSTRING_H_
#include <CharString.hxx>
#endif

#ifndef _FILEUTIL_H_
#include <FileUtil.hxx>
#endif

#if defined (_WIN32_WCE)
#include <io.h>
#include <dirent.h>
#elif defined (_WIN32)
#include <io.h>
#include <direct.h>
#else
#include <dirent.h>
#include <unistd.h>
#include <utime.h>
#endif
#include <stdio.h>
#include <sys/stat.h>

#ifdef MAXPATHLEN                // PVSS_MAX_PATH = MAXPATHLEN  - Linux, HP
  #define PVSS_MAX_PATH MAXPATHLEN
#else
  #ifdef _MAX_PATH               // PVSS_MAX_PATH = _MAX_PATH   - NT
    #define PVSS_MAX_PATH _MAX_PATH
  #else
    #define PVSS_MAX_PATH 1024   // PVSS_MAX_PATH  = 1024       - if still not defined.
  #endif
#endif

#if defined (_WIN32) // [

#if !defined(ACE_USES_OLD_IOSTREAMS) // [  ACE defines better Constants
// these are dummies for WINDOWS
  #define S_IRWXU 00700     /* read, write, execute permission (owner) */
  #define S_IRUSR 00400     /* read permission (owner) */
  #define S_IWUSR 00200     /* write permission (owner) */
  #define S_IXUSR 00100     /* execute permission (owner) */

  #define S_IRWXG 00070     /* read, write, execute permission (group) */
  #define S_IRGRP 00040     /* read permission (group) */
  #define S_IWGRP 00020     /* write permission (group) */
  #define S_IXGRP 00010     /* execute permission (group) */

  #define S_IRWXO 00007     /* read, write, execute permission (other) */
  #define S_IROTH 00004     /* read permission (other) */
  #define S_IWOTH 00002     /* write permission (other) */
  #define S_IXOTH 00001     /* execute permission (other) */

#endif // ]

#ifndef _MODE_T_DEFINED_
typedef int mode_t;
#define _MODE_T_DEFINED_
#endif

#endif // ]

#if defined (_WIN32)
# include <BaseTsd.h>
# define DIR_MODE755 0
#else
# define DIR_MODE755 ( S_IRWXU | S_IRGRP | S_IXGRP | S_IROTH | S_IXOTH )
#endif

# define DIR_MODE777 ( S_IRWXU | S_IRWXG | S_IRWXO )
# define DIR_MODE770 ( S_IRWXU | S_IRWXG )

/** The file system wrapper. Since PVSS-II is a multi platform application, we need to
 *  abstract the different file system operations. This class mainly consists of
 *  static functions.
 */
class DLLEXP_BASICS FileSysSlim
{
public:
  /// platform dependent type for a filedescriptor.
#if defined (_WIN32)
  typedef UINT_PTR FileDescriptor;
#else
  typedef int FileDescriptor;
#endif
  /// platform dependent value of the invalid file descriptor.
  static const FileDescriptor invalidFileDescriptor;

  /// platform-dependent path separator ('/', '\\', ...)
  static const char PATH_CHAR;
  /// string of length 1 holding PATH_CHAR
  static const char *PATH_STR;

  /// Holds the status of a file system @see FilsSysSlim::statfs()
  /// int64 version
    struct FileSystemStatus64
  {
    /// total kilobytes
    PVSSlonglong    totalKBytes;
    /// kilobytes available
    PVSSlonglong    freeKBytes;
    /// kilobytes available for non-superuser
    PVSSlonglong    availKBytes;
  };

  /// Holds the status of a file system @see FilsSysSlim::statfs()
  /// deprecated! please use FileSystemStatus64 
  struct FileSystemStatus
  {
    /// total kilobytes
    long    totalKBytes;
    /// kilobytes available
    long    freeKBytes;
    /// kilobytes available for non-superuser
    long    availKBytes;
  };

  /// constructor
  FileSysSlim();
  /// destructor
  ~FileSysSlim();

  /** Open a specific directory for reading directory entries via nextFile().
   *
   *  @param directory full path of the directory to open.
   *  @return PVSS_TRUE on success, PVSS_FALSE on error
   *  @osdiff On windows, @e directory may contain a wildcards,
   *          e.g. "C:/work/PVSS*.exe". This implies that
   *          the last path component need not exist (e.g. the nonexistent
   *          "C:/work/nodir" will result in PVSS_TRUE when "C:/work" is an
   *          existing directory, the dirname will be set to C:/work and 
   *          subsequent nextFile() calls will work in that directory.
   *          If no path seperators can be found and the string is not 
   *          a valid directory PVSS_FALSE will be returned and the 
   *          dirname will be an empty CharString.")
   *  @see nextFile()
   */
  PVSSboolean openDir(const char *directory);

  /** Get next file from open directory
   *
   *  @return a valid file name when there is a next file, or 0 when no more files
   *          are found or when there was no previous call to openDir()
   */
  const char *nextFile();

  /** Get next file from open directory - internal version
   *
   *  @param traceTxt used only for debugging purposes, must not be 0
   *  @return a valid file name when there is a next file, or 0 when no more files
   *          are found or when there was no previous call to openDir()
   *
   *  @classification internal
   */
  const char *nextFile(const char *traceTxt);

  /// rewind the current directory
  void rewind();
  /// close the current directory
  void closeDir();

  /** Converts path strings with any valid separator to the valid path names for
   *  the current platform.
   *
   *  @param [in,out] path a path
   */
  static void setPathCharInString(CharString & path);

  /** Converts path strings with any valid separator to the valid path names for
   *  the current platform, C-string version.
   *
   *  @param [in,out] pathName a path, must not be 0
   */
  static void setPathCharInString(char *pathName);

  /** Converts path strings with any valid separator to a platform-independent path
   *  with the separator '/', C-string version.
   *
   *  @param [in,out] path a path, must not be 0
   */
  static void setStdPathCharInString(char *path);

  /** Converts path strings with any valid separator to a platform-independent path
   *  with the separator '/'.
   *
   *  @param [in,out] path a path
   */
  static void setStdPathCharInString(CharString & path);

  /** Removes trailing path separators of any kind, C-string version
   *
   *  @param [in,out] path a path, must not be 0
   */
  static void removeLastPathCharInString(char *path);

  /** Removes trailing path separators of any kind.
   *
   *  @param [in,out] path a path, must not be 0
   */
  static void removeLastPathCharInString(CharString & path);

  /** Converts path strings with any valid separator to the valid path names for
   *  the current platform and removes any duplicate path separators 
   *  ( // -> 1 PATH_CHAR and \\\\ -> 1 PATH_CHAR). C-string version
   *
   *  @param [in,out] path a path, must not be 0
   */
  static void cleanPath(char *path);

  /** Converts path strings with any valid separator to the valid path names for
   *  the current platform and removes any duplicate path 
   *  ( // -> 1 PATH_CHAR and \\\\ -> 1 PATH_CHAR).
   *
   *  @param [in,out] path a path, must not be 0
   */
  static void cleanPath(CharString & path);

  /** Checks if path string is absolute (= starting from / or x:/)
   *
   *  @param pathName a path, must not be 0
   *  @return PVSS_TRUE if the path is absolute, PVSS_FALSE otherwise
   */
  static PVSSboolean isAbsolutePath(const char *pathName);

  /** Checks if path string is relative (= not starting from / or x:/)
   *
   *  @param pathName a path, must not be 0
   *  @return PVSS_TRUE if the path is absolute, PVSS_FALSE otherwise
   */
  static PVSSboolean isRelativePath(const char *pathName);

  /** Checks if the path points to a directory
   *
   *  @param pathName a path, must not be 0
   *  @return PVSS_TRUE if the path points to a directory, PVSS_FALSE otherwise
   */
  static PVSSboolean isDirectory(const char *pathName);

  /** Checks if the path points to a regular file.
   *
   *  @param pathName a path, must not be 0
   *  @return PVSS_TRUE if the path points to a regular file, PVSS_FALSE otherwise
   */
  static PVSSboolean isRegularFile(const char *pathName);

  /** Checks if the path points to a sticky file.
   *
   *  @param pathName a path, must not be 0
   *  @return PVSS_TRUE if the path points to a sticky file, PVSS_FALSE otherwise
   */
  static PVSSboolean isSticky(const char *pathName);

  /** Checks if the path points to an existing file.
   *
   *  @param pathName a path, must not be 0
   *  @return PVSS_TRUE if the path exists, PVSS_FALSE otherwise
   */
  static PVSSboolean fileExists(const char *pathName);

  /** Creates a new directory
   *
   *  @param directory full path of the directory to create
   *  @param flags the access flags for the directory
   *  @return PVSS_TRUE on success, PVSS_FALSE on error
   *  @osdiff On windows, only DIR_MODE777 or DIR_MODE755 (default) are possible
   *          for @e flags
   *  @see makePath()
   */
  static PVSSboolean makeDir(const char *directory, mode_t flags= DIR_MODE755 );

  /** Removes an existing directory
   *
   *  @param directory full path of the directory to remove
   *  @return PVSS_TRUE on success, PVSS_FALSE on error
   */
  static PVSSboolean removeDir(const char *directory);

  /** Removes an existing non-empty directoy
   *
   *  @param dirname full path of the directory to remove
   *  @param recursive when PVSS_TRUE, also the subdirectories are removed,
   *                   when PVSS_FALSE, only the files are removed and
   *                   removal of the directory fails when subdirectories
   *                   exist
   *  @return PVSS_TRUE on success, PVSS_FALSE on error
   */
  static PVSSboolean removeDir(const char *dirname, PVSSboolean recursive);

  /** Create a new directory recursively (with all parent dirs if needed)
   *
   *  @param directory full path of the directory to create
   *  @param flags the access flags for the directory
   *  @return PVSS_TRUE on success, PVSS_FALSE on error
   *  @osdiff On windows, only DIR_MODE777 or DIR_MODE755 (default) are possible
   *          for @e flags
   *  @see makeDir()
   */
  static PVSSboolean makePath(const char *directory, mode_t flags= DIR_MODE755 );

  /** Get information about the file system on which @e path resides
   *
   *  @param path a path to a file or directory
   *  @param [out] statRef information about the file system on which @e path resides.Holds the information in 64Bit members.
   *  @return PVSS_TRUE on success, PVSS_FALSE on error
   */
  static PVSSboolean statfs(const char *path, FileSystemStatus64 &statRef);

  /** Get information about the file system on which @e path resides
   *
   *  @param path a path to a file or directory
   *  @param [out] statRef information about the file system on which @e path resides
   *  @return PVSS_TRUE on success, PVSS_FALSE on error
   */
  static PVSSboolean statfs(const char *path, FileSystemStatus &statRef);

  /** Get file access and modification times. The result depends on the file system where
   *  the file resides, not all file systems store both, modification and access time.
   *
   *  @param [in] path a valid file name, must not be 0
   *  @param [out] accessTime on success, this variable receives the access time
   *  @param [out] modifTime on success, this variable receives the modification time
   *  @return PVSS_TRUE on success, PVSS_FALSE on error
   */
  static PVSSboolean getFileTimes(const char *path, time_t &accessTime, time_t &modifTime);

  /** Get file modification time.
   *
   *  @param path a valid file name, must not be 0
   *  @return on success, the file modification time. on error, the return value is 0
   */
  static time_t getFileMTime(const char *path);

  /** Get file access and modification times. Since not all file systems store both,
   *  access and modification time, the values set here may not be retrieved exactly.
   *
   *  @param path a valid file name, must not be 0
   *  @param accessTime the new access time for the file
   *  @param modifTime the new modification time for the file
   *  @return PVSS_TRUE on success, PVSS_FALSE on error
   */
  static PVSSboolean setFileTimes(const char *path, const time_t accessTime, const time_t modifTime);

  /** Set file modification time, access time is not changed
   *
   *  @param path a valid file name, must not be 0
   *  @param modifTime the new modification time for the file
   *  @return PVSS_TRUE on success, PVSS_FALSE on error
   */
  static PVSSboolean setFileMTime(const char *path, const time_t modifTime);

  /** Set access time and modification time to now. Create emmpty file if not existent.
   *
   *  @param path a valid file name, must not be 0
   *  @return PVSS_TRUE on success, PVSS_FALSE on error
   */
  static PVSSboolean touchFile(const char *path);

  /** Set access time and modification time to the access and modification times of
   *  the file @e refPath.
   *
   *  @param path the file, whose times shall be set
   *  @param refPath a valid file name, must not be 0
   *  @return PVSS_TRUE on success, PVSS_FALSE on error
   */
  static PVSSboolean touchFileRef(const char *path, const char *refPath);

  /** Get file access mode information
   *
   *  @param path a valid file name, must not be 0
   *  @param pmode a pointer to a variable receiving the access mode
   *  @return 0 on success, any other value on error
   */
  static int getmod( const char *path, int *pmode );

  /** Set file access mode information
   *
   *  @param path a valid file name, must not be 0
   *  @param pMode a pointer to a variable receiving the access mode
   *  @return 0 on success, any other value on error
   *  @osdiff the access mode is highly platform-dependent, on windows, the
   *          execution flags depend on the file extension and cannot be changed
   */
  static int chmod( const char *path, int pMode );

  /** Converts path strings with any valid separator to a UNIX path with
   *  the separator '/'.
   *
   *  @param path a path
   *  @return the converted path as a pointer to an internal varaible, you
   *          <strong>must not</strong> cast the const away and modify it.
   *  @deprecated use setStdPathCharInString(char*) or
   *              setStdPathCharInString(CharString&) instead
   */
  static const char *makeUnixPath(const char *path);

  /** Create a temp filename (does not create the file itself). On success, the
   *  filename is guaranteed to be creatable and writable.
   *
   *  @param [out] str the variable to receive the temporary filename, on error,
   *               this variable is set to an empty string
   *  @return the temporary filename, always a reference to @e str
   */
  static CharString& tmpnam(CharString & str);

  /** Create a temp filename (does not create the file itself) in a specific
   *  directory with a specific prefix. On success, the filename is guaranteed
   *  to be creatable and writable.
   *
   *  @param inDirectory the directory where the temporary filename shall be created
   *  @param prefix if non-0, this value is used as a prefix of the temporary filename
   *  @return the temporary filename or an empty string on error
   */
  static CharString tempnam(const CharString &inDirectory, const CharString *prefix = 0);

  /** Creates a temporary directory. On success, the directory is guaranteed
   *  to be writable.
   *
   *  @param existingTmpDirName path name of the created directory
   *  @return <tt>true</tt> on success, <tt>false</tt> on error
   */
  static bool tmpDir(CharString & existingTmpDirName);

  /** Get file size
   *
   *  @param path a valid file name, must not be 0
   *  @return when 0 or positive, the file size, negative on error.
   */
  static long getFileSize(const char *path);

  /** Renames or moves a file (even accross file systems) or
   *  renames or move a directory (on the same file system).
   *
   *  @param fromFile the source file
   *  @param toFileOrDir name of the new file or existing destination directory
   *  @return 0 on success, -1 when one of the parameters is 0, any other value
   *          indicates a platform-dependent error code
   *  @osdiff On UNIX, a return value <-1 indicates the error that source and
   *          destination are on different file systems, and a return value >0 is equal
   *          to @e errno. On Windows, a return value >0 is equal to the return value of
   *          GetLastError(). On Windows, the call returns after flushing
   *          the move, on UNIX this is not guaranteed.
   */
  static int moveFile( const char *fromFile, const char * toFileOrDir );

  /** Removes a file
   *
   *  @param file the filename
   *  @return 0 on success, -1 when @e file is 0 or the file could not be removed
   */
  static int removeFile( const char *file );

  /** Copies a file
   *
   *  @param source source file
   *  @param destination destination file name or existing directory
   *  @param preserve the access and modification times are preserved on copying
   *  @param makeDir When <tt>true</tt>, makePath() is called on @e destination
   *
   *  @retval  0 on success
   *  @retval -1 one of the parameters is NULL
   *  @retval -2 (UNIX): source file could not be opened
   *  @retval -3 (UNIX): error in writing destination file (no space?)
   *  @retval -4 (UNIX): destination file could not be opened
   *  @retval -5 (UNIX): error reading source file
   *  @retval -6 (UNIX): could not preserve time; (Windows): could not <em>un</em>preserve time
   *  @retval >0 (Windows): system error number from GetLastError()
   *
   *  @osdiff On Windows, the access and modification times are preserved by default
   */
  static int copyFile(const char *source, const char *destination, bool preserve, bool makeDir);

  /** Platform-dependent wrapper for copyFile(const char*,const char*,bool,bool), with
   *  @e makeDir set to <tt>false</tt>
   *
   *  @param source source file
   *  @param destination destination file name or existing directory
   *  @osdiff @e preserve is <tt>true</tt> on Windows and <tt>false</tt> on UNIX
   *  @see copyFile(const char*,const char*,bool,bool)
   */
  static int copyFile(const char *source, const char *destination);

  /** Compare path or file names
   *  unix: symbolic links are NOT resolved.
   *  @param pathName1 one path
   *  @param pathName2 the other path
   *  @param ignPathChar if set, backslashes (\) and slashes (/) as treated as equal
   *  @return like strcmp(), 0 .. equal, -1 .. pathName1 < pathName2, 1 .. pathName1 > pathName 2
   *
   *  @osdiff On Windows, the comparision is case-insensitive, on UNIX, symbolic links
   *          are not resolved
   */
  static int cmpPathNames(const char *pathName1, const char *pathName2, bool ignPathChar = true);

  /** Compare path or file names up to @e count characters
   *  unix: symbolic links are NOT resolved.
   *  Duplicate path separators are not removed. Use cleanPath() to remove any duplicate
   *  path separators.
   *  @param pathName1 one path
   *  @param pathName2 the other path
   *  @param count the number of characters from the beginning to be compared
   *  @param ignPathChar if set, backslashes (\) and slashes (/) as treated as equal
   *  @return like strcmp(), 0 .. equal, -1 .. pathName1 < pathName2, 1 .. pathName1 > pathName 2
   *
   *  @osdiff On Windows, the comparision is case-insensitive, on UNIX, symbolic links
   *          are not resolved
   */
  static int ncmpPathNames(const char *pathName1, const char *pathName2, size_t count, bool ignPathChar = true);

  /** Creates a lock file
   *
   *  @param fileName the name for the lock file
   *  @return When <tt>true</tt> file could be created, lock is available.
   *          When <tt>false</tt> file already exists or couldn't be created, lock is
   *          not available
   */
  static bool lockFileCreated( const char *fileName );

  /** Redirects stdout to a file
   *
   *  @param fileName name of an existing or new file
   *  @param truncate truncate or append (default) to existing file
   *  @return PVSS_TRUE on success, PVSS_FALSE on error
   *  @see redirectFile()
   */
  static PVSSboolean redirectStdOut(const char *fileName, bool truncate = false);

  /** Redirects stderr to a file
   *
   *  @param fileName name of an existing or new file
   *  @param truncate truncate or append (default) to existing file
   *  @return PVSS_TRUE on success, PVSS_FALSE on error
   *  @see redirectFile()
   */
  static PVSSboolean redirectStdErr(const char *fileName, bool truncate = false);

  /** Redirects a file descriptor to a file
   *
   *  @param fd valid file descriptor
   *  @param fileName name of an existing or new file
   *  @param mode mode for fopen(), e.g. "w", "a" etc.
   *  @return PVSS_TRUE on success, PVSS_FALSE on error
   */
  static PVSSboolean redirectFile(int fd, const char *fileName, const char *mode);

  /** Set the inheritable flag for the file descriptor.
   * @param fd valid file descriptor
   * @param inheritable set to true if the fd shall be inherited by a spawned child process,
   *        false otherwise
   *  @return PVSS_TRUE on success, PVSS_FALSE on error (e.g. invalid file descriptor)
   */
  static PVSSboolean setInheritable(FileDescriptor fd, bool inheritable);

  /** Get the inheritable flag for the file descriptor.
   * @param fd valid file descriptor
   * @param inheritable will be set to true if the fd shall be inherited by a spawned child process,
   *        false otherwise
   *  @return PVSS_TRUE on success, PVSS_FALSE on error (e.g. invalid file descriptor)
   */
  static PVSSboolean getInheritable(FileDescriptor fd, bool &inheritable);

private:
  /** Recursive worker for makePath()
   *
   *  @param directory full path of the directory to create
   *  @param flags the access flags for the directory
   *  @return PVSS_TRUE on success, PVSS_FALSE on error
   *  @osdiff On windows, only DIR_MODE777 or DIR_MODE755 (default) are possible
   *          for @e flags
   *  @see makeDir()
   */
  static PVSSboolean internalMakePath(const char *directory, mode_t flags=0);

#if defined (_WIN32) && !defined (_WIN32_WCE)
  /// handle for openDir() -> nextDir() operation
  FileDescriptor findHandle;
  /// information for nextDir() operation
  struct _finddata_t fileInfo;
  /// pattern given to openDir()
  CharString dirName;
  /// indicates if findHandle, fileInfo and dirName are initialized
  PVSSboolean initialized;
  struct _wfinddata_t wFileInfo;  // IM 115346
  CharString fileName;
#else
  /// handle for openDir() -> nextDir() operation
  DIR *dirPtr;
  /// information for nextDir() operation
  struct dirent *entry;
#endif
};

inline PVSSboolean FileSysSlim::isRelativePath(const char *pathName)
{
  return (pathName && *pathName && !isAbsolutePath(pathName));
}

#endif /* _FILESYSSLIM_H_ */

