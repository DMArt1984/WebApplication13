#ifndef _USERTABLE_H_
#define _USERTABLE_H_

/*
VERANTWORTUNG: Martin Koller         
BESCHREIBUNG: holds all defined users on the system and handles the conversion
  between user-id and user-name, password checking, etc.
  The user table is really in a datapoint, but this class holds a copy
  so that the access is faster
*/

#include <Types.hxx>
#include <DpIdentList.hxx>
#include <WaitForAnswer.hxx>
#include <Bit32Var.hxx>
#include <DynVar.hxx>
#include <NameServerSysMsg.hxx>

class DpIdValueList;

class DLLEXP_MANAGER UserTable
{
  /// <summary>
  /// Declare test class as a friended class, having access to private/protected methods
  /// </summary>    
  friend class UNIT_TEST_FRIEND_CLASS;
  
  enum { MAX_USER_DPIDS = 7 };
  public:
    UserTable();
    ~UserTable();
    
    // wait for user data to arrive
    void waitForData();

    // update the internal copy of the user-table
    int dpValueChanged(const DpIdValueList &values);

    // returns the user-id which corresponds to the given name, or
    // DEFAULT_USER if there is no
    // user with this name
    PVSSuserIdType getUserId(const char* name);

    // returns the user-name for this id or 0 if this id does not exist
    const char* getUserName(PVSSuserIdType id);

    // Check if the User is enabled
    PVSSboolean isUserEnabled(const char *name);
    PVSSboolean isUserEnabled(PVSSuserIdType id);

    // Get the group IDs in a DynVar for a specific user
    // returns 0 for nonexisting user
    const DynVar *getGroupIds(PVSSuserIdType id);

    // returns the user-permissions for this id or 0 if this id does not exist
    const Bit32Var *getUserPermissionSet(PVSSuserIdType id);
    const Bit32Var *getUserForceSet(PVSSuserIdType id);
    
    // returns PVSS_TRUE if the given password is correct for user id, PVSS_FALSE otherwise
    PVSSboolean checkPassword(PVSSuserIdType id, const char* passwd);
    
    // send connect messages on reconnect
    void reConnect();
    
    // handle NameServerSysMsg
    PVSSboolean handleNameServerSysMsg(const NameServerSysMsg &msg);

    // Check if the table is initialized
    bool isInitialized() const {return names != 0;}
    
    // Compare stored password hash with the calculated one
    PVSSboolean authPassword(const char *passwd, const CharString &storedPwdHash);

  private:
    // konvertiert einen string vom aktuellen Encoding in einem wchar_t string
    // caller ist f�r den Speicher verantwortlich
    static wchar_t * getAsWChar(const char *value);
  
  // so that the compiler does not define them itself !!

    // copy constructor
    UserTable(const UserTable &) {}  //COVINFO LINE: defensive (AP: no copy allowed)
    // assignment operator
    UserTable &operator=(const UserTable &) { return *this; }  //COVINFO LINE: defensive (AP: no operator= allowed)

    
    // Authenticate user through security service of operating system
    PVSSboolean authOsUserCreditals(const char *passwd, const char *userPrincipalName);

    // convert text group IDs from data point to dyn_dyn_uint for easier access
    void setGroupIds(const DynVar &var);

    
    DynVar *ids;
    DynVar *names;
    DynVar *passwords;
    DynVar *permSet;
    DynVar *forceSet;
    DynVar *enabled;
    DynVar *groupIds;

    DynPtrArrayIndex cacheIndex;
    PVSSuserIdType cacheId;

    DpIdentList dpList;

    class DLLEXP_MANAGER WaitFor : public WaitForAnswer
    {
      friend class UserTable;

      public:
        WaitFor(UserTable *ut) : table(ut) {}
        ~WaitFor();

        virtual void callBack(DpMsgAnswer &answer);

      private:
        UserTable *table;
    };
    
    friend class WaitFor;

    WaitFor *wait;
    PVSSboolean answerArrived;
    
    class DLLEXP_MANAGER NameIdMap
    {
    public:
      void setName(const CharString &newDpName) { dpName = newDpName; }
      void setId(const DpIdentifier &newDpId);
      
      const CharString &getName() const { return dpName; }
      const DpIdentifier &getId() const { return dpId; }
    
    private:
      CharString dpName;
      DpIdentifier dpId;
    };
    
    NameIdMap internalIds[MAX_USER_DPIDS];
    int nameServerSysMsgsPending;
};

#endif /* _USERTABLE_H_ */
