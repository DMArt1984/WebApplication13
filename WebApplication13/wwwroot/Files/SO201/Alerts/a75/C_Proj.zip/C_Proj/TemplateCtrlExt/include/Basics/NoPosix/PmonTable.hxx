#ifndef _PMONTABLE_H_
#define _PMONTABLE_H_

#include <Variable.hxx>
#include <PVSSTime.hxx>
#include <ComponentNames.hxx>

#ifdef _WIN32
#  include <windows.h>
#else
#include <unistd.h>
#endif

class ErrClass;

//--------------------------------------------------------------------------------
// helper classes to hold the progs-file entries


/** 
  This class PmonEntry holds all settings for one manager (like arguments, startTime, ...)
  IM 117497 It must have a fixed size, because it is kept in a shared-memory segment
  .... and it must have a fixed size regardless of platform x64/x86 (if you mix managers in console)
  assert for sizeof(PmonEntry) is called in PmonTable::ctor
*/
class DLLEXP_BASICS PmonEntry
{
  public:
    ///ctor
    PmonEntry();

    /** 
    set manager name
      @param name 
    */
    void setManName(const char *name);
    /** 
    set cmdline options
      @param options 
    */
    void setManOptions(const char *options);

    /// name of manager 
    char manName_[MAX_COMPONENT_NAME_LENGTH + 1];      
    /// Manager-Number
    PVSSulong manNum_;       
    /// commandline options
    char manOptions_[200];
    /// IM117253: Following dummy members are necessary
    ///           to keep the size of PmonEntry and the internal offsets
    ///           identical to older versions.
    // IM 117497 WOKL
    char dummy[24];
    /// when was this manager started
    PVSSdouble startTimeD_;
    /// process id
    PVSSlong pid_;               
    /// START_MANUAL, START_ONCE, START_ALWAYS
    PVSSlong startMode_;         
    PVSSlong secKill_;
    PVSSlong restartCount_;
    PVSSlong resetMin_;

    /// manager type << 16 + manager subtype
    PVSSulong manType_;
    /// alive counter (increased by Manager during main loop)
    PVSSulong alive_;        
    /// commands to Pmon
    PVSSlong      command_;      
};

/**
  PmonEntryList item struct
*/
struct DLLEXP_BASICS PmonEntryListItem
{
  ///iterates to next item
  PmonEntryListItem() : next(0) {}

  //// pointer to the next entry, or 0 if last
  PmonEntryListItem *next;    
  PmonEntry entry;
};

/**
  list of PmonEntries
*/
struct DLLEXP_BASICS PmonEntryList
{
  PmonEntryList() : count(0), oldVersion(false), first(0) {}
  ~PmonEntryList();

  /// user for authentication
  CharString user;         
  /// encrypted password for authentication
  CharString passwd;        
  /// number of entries in this list
  unsigned count;   
  /// true if the loaded progs-file was not the current version
  bool oldVersion;          

  /// pointer to the first entry, or 0 if empty
  PmonEntryListItem *first; 
};

//--------------------------------------------------------------------------------

/**
Class for accessing the process-monitor-table which holds
  the information which manager is in what state, when it was started, ...
  @classification public use
*/
class DLLEXP_BASICS PmonTable
{
  public:
    //PmonState enum
    enum PmonState
    {
      MAN_NOT_RUNNING = 0,
      MAN_INIT        = 1,
      MAN_RUNNING     = 2,
      MAN_BLOCKED     = 3  // state only detected by pmon, never returned by getState(idx)
    };

    //StartMode enum
    enum StartMode
    {
      START_MANUAL,     // only manually
      START_ONCE,       // only once
      START_ALWAYS      // start it and restart it after stop
    };

    //PmonCommand enum
    enum PmonCommand
    {
      CMD_NONE            = 0,
      CMD_RESTART_PROJECT = 1
    };

    ///ctor
    PmonTable();
    ///destructor
    ~PmonTable();

    ///this
    static PmonTable *thisPtr;

    /** 
    Get access to the PmonTable (shm), and probably load initial information from the progs-file
        when the caller is the creator of the Table (shm).
        @return true, when there were no errors
    */
    bool init();

    /// set the emergency-mode (true = ON, false = OFF)
    void setEmergencyMode(bool mode);

    /// check if emergency mode is active (true) or not (false)
    bool getEmergencyMode() const;

    /// set the demo-mode (true = ON, false = OFF)
    void setDemoMode(bool mode);

    /// check if demo mode is active (true) or not (false)
    bool getDemoMode() const;

    /// set the redu peer alive flag (true = redu system is alive, false = peer is stopped)
    void setReduPeerAlive(bool alive);

    /// check if the redundant peer system is alive (true) or not (false)
    bool getReduPeerAlive() const;

    /** Define the username + (clear text) password for authentication.
        user is limited with 10 characters.
        The password will be encrypted and stored encrypted in SHM.
        To remove user, pass an empty string (NOT 0-pointer).
        To remove password, pass empty string (NOT 0-pointer).
        @param user user name
        @param passwd
        @return 0 if values could be set, else -1 (e.g. username too long)
    */
    int setAuthInfo(const char* user, const char* passwd);

    /** get the username + crypted password for authentication.
        @param user user name
        @param passwd
    */
    void getAuthInfo(const char* &user, const char* &passwd) const;

    /** set the PID of the PVSStoolLogViewer
      @param pid
    */
    void setLogViewerPID(int pid);

    /// set the PID of the PVSStoolLogViewer
    int getLogViewerPID() const;

    /** Check authentication.
        If no password is set in PmonTable, only the user must match.
        Do never pass a 0-pointer for one of these arguments !
        @param user user name
        @param passwd
        @return true if given user and (clear text) password matches
    */
    bool checkAuth(const char* user, const char* passwd) const;

    /// get maximum number of allowed entries
    unsigned getMaxCount() const { return semCount_; }

    /// get Number of Managers defined
    int getManCount() const;

    /** get the index of an entry
        @param manName manager name 
        @param manNum manager number  
        @param checkNum = false, when only the manager-name shall be checked and the number is a "don't care"
        @return the managers index into the pmon-table (0 .. manCount-1), -1 on error
    */
    int getEntryIdx(const char *manName, unsigned manNum, bool checkNum = true) const;

    /** checks if the given index to an entry is allowed
        @param idx
        @return true if OK, else false
    */
    bool checkIdx(int idx) const;

    /** get the running-state of a manager
        @param  idx ... manager index
        @return the running-state of the given manager (PmonState), or -1 if not found
    */
    int getState(int idx) const;

    /** increase the state of the given manager
        @param idx index
        @return -1 on error, else 0
    */
    int incState(int idx);

    /** increases the alive-counter of the given manager
        @param idx
    */
    void incAlive(int idx);

    /** set command
        @param idx
        @param cmd
    */
    void setCommand(int idx, PmonCommand cmd);

    // access to the settings for a given entry (index)

    /** getManName
        @param idx
        @return manager name
    */
    const char*     getManName      (int idx) const;
    /** getManNum
        @param idx
        @return manager num
    */
    unsigned        getManNum       (int idx) const;
    /** getManOptions
        @param idx
        @return cmdline options
    */
    const char*     getManOptions   (int idx) const;
    /** getStartMode
        @param idx
        @return start mode
    */
    int             getStartMode    (int idx) const;
    /** getSecondsToKill
        @param idx
        @return seconds to kill
    */
    int             getSecondsToKill(int idx) const;
    /** getRestartCount
        @param idx
        @return restart cnt
    */
    int             getRestartCount (int idx) const;
    /** getResetMinutes
        @param idx
        @return reset minutes
    */
    int             getResetMinutes (int idx) const;
    /** getStartTime
        @param idx
        @return start time
    */
    const PVSSTime &getStartTime    (int idx) const;
    /** getPID
        @param idx
        @return pid
    */
    int             getPID          (int idx) const;

    /** getManType
        @param idx
        @return manager type
    */
    unsigned        getManType      (int idx) const;
    /** setManType
        @param idx
        @param type manager type
    */
    void            setManType      (int idx, unsigned type);

    /** setManNum
        @param idx
        @param type manager number
    */
    void            setManNum       (int idx, unsigned num);

    /** return current value of alive-counter
        @param idx
        @return alive cnt
    */
    unsigned        getAlive        (int idx) const;

    /** return command
        @param idx
        @return cmd
    */
    PmonCommand     getCommand      (int idx) const;

    /** set startTime to 0
        @param idx
        @return 0 ok,  -1 error
    */
    int resetStartTime(int idx); 
    /** set PID to -1
        @param idx
        @return 0 ok,  -1 error
    */
    int resetPID(int idx);        
    /** set PID to given pid
        @param pid
        @param idx
        @return 0 ok,  -1 error
    */
    int setPID(int idx, int pid); 

    /** saves the PmonTable to the progs-file
        @return 0 ok,  -1 error      
    */
    int writeProgsFile() const;  

    /** Removes completely this entry and moves all below it one position up.
        The progs file will be written to reflect the same content
        @param idx
        @return -1 on error, 0 on success
    */
    int deleteEntry(int idx);

    /** Inserts new entry as given index and moves all starting with idx one position down.
        Possible only if there is enough space left (semCount_ not reached).
        The progs file will be written to reflect the same content
        @param idx
        @param entry
        @return -1 on error, 0 on success
    */
    int insertEntry(int idx, const PmonEntry &entry);

    /** Replace entry at index idx with given new entry.
        Only modifies the following fields: manOptions_, manNum_, startMode_, secKill_, restartCount_, resetMin_.
        The progs file will be written to reflect the same content.
        @param idx
        @param entry
        @return -1 on error, 0 on success
    */
    int changeEntry(int idx, const PmonEntry &entry);

    /** convert progs file if needed and write back to disc
        @param configDir  path to the config dir in which the progs file to be converted resides
               Must end with the path-delimiter char (e.g. "/")
        @return 0 on success, else a pointer to a ErrClass object describing the error.
                It must be deleted by the caller.
    */
    static ErrClass *convertProgsFile(const CharString &configDir);

    /** convert given StartMode to an ascii representation
      @param startMode
    */

    static const char *startModeToStr(int startMode);

    /** convert ascii representation of StartMode to internal representation
      @param str strart mode string
    */
    static int strToStartMode(const char *str);

    /** activate switch to use allocated memory instead of shared memory
      * for stand-alone mode
      */
    static void disable()       { usePrivateMemory_ = true; }

  private:
    /** Loads progs-file and returns a pointer to the list of loaded entries
        @param list The returned list must be deleted by the caller. It is 0 on error.
        @param configDir if given, the progs file found in the given config path is loaded,
               otherwise the progs file from the current project is loaded.
               The given path must include the path-delimiter ("/") char at the end.
               This is useful for converting an old file.
        @return 0 on success, else a pointer to a ErrClass object describing the error.
                It must be deleted by the caller.
    */
    static ErrClass *loadProgsFile(PmonEntryList *&list, const char* configDir = 0);

    /** copied from Crypto to fulfill #37415
    @brief  Generate PKCS#5 password hash (PBKDF2)
    @detail The number of iterations is randomized between 2000 and 2999
    @param passwd     the password to encrypt
    @return           the generated format: #algorithm#salt#iterations#passhash
    */
    static bool cryptHashPBKDF2(const char* passwd, int iterations, CharString &hash);
    
    // copied from UserTable, compares stored password hash with the calculated one
    bool authPassword(const char *passwd, const CharString &storedPwdHash) const;

  private:
    /// number of semaphores really created (== max number of entries allowed)
    unsigned semCount_;  
    int semId_;
    int shmId_;

#ifdef _WIN32
    HANDLE shmHdl_;
    HANDLE semHdl_;

    /// used for converting old progs-files
    static void readRegistry(PmonEntryList &list, const char* configDir);  
#endif

    /// pointer to shm segment (contains GeneralData + PmonEntry list)
    void *shm_;           

  public:  // Windoze needs this enum to be public to access it in GeneralData; also used in Pmon
    enum
    {
      /// username length + 0-byte
      USER_LEN = 20 + 1,

      /// password length (we now use new crypt() which has "_" + 11bytes) + 0-byte
      PASSWD_LEN = 66 + 1,

      /// max ProjectName length stored in SHM + 0-byte
      PROJECT_LEN = 100 + 1
    };

  private:
    /// general data in shared memory
    // IM 117497 care for fixed size in 32 and 64bit!
    // assert for sizeof(PmonTable::GeneralData) is called in PmonTable::ctor
    struct GeneralData    
    {
      /// number of managers
      PVSSlong manCount_;                 
      /// emergency-mode flag
      bool emergencyMode_;          
      /// license demo-mode flag
      bool demoMode_;                
      /// flag which tells Pmon if the other redu system is running
      bool reduPeerAlive_;           
      /// username (for write protection) + 0-byte
      char user_[USER_LEN];          
      /// crypted password (for write protection) + 0-byte
      char passwd_[PASSWD_LEN];      
      /// projectName + 0-byte
      char project_[PROJECT_LEN];    
      /// PID of first logViewer instance (to be able to kill it)
      PVSSlong logViewerPID_;             
    } *data_;             // pointer to this data (in shared memory)

    PmonEntry *table_;    // pointer to the list of pmonEntries (in shared memory)

    static bool usePrivateMemory_;    // IM 118965
    static const int SEMCOUNT;
	
   friend class UNIT_TEST_FRIEND_CLASS;
};

#endif
