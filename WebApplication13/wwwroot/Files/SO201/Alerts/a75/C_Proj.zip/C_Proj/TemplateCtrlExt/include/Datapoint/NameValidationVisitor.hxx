#ifndef _NAMEVALIDATIONVISITOR_H_
#define _NAMEVALIDATIONVISITOR_H_

#include <CNSTreeVisitor.hxx>
#include <LangText.hxx>
#include <CharString.hxx>
#include <DpIdentifierVar.hxx>
#include <ErrClass.hxx>


/**
 * A visitor which checks the name and display names of every visited node.
 * It will abort its traversal at the first invalid node. The result of the
 * validation can be checked with isValid().
 *
 * Please note that visit() ignores the previous state of the valid-flag.
 * This means that if the visitor aborts because of an invalid node, and visit()
 * is called again with a valid node, the visitor will not retain its "invalid"
 * state.
 */
class DLLEXP_DATAPOINT NameValidationVisitor : public CNSTreeVisitor
{
public:
  /**
   * Creates a new visitor.
   *
   * @param viewSeparators The display name separators to use for checking the
   *                       validity of display names.
   * @param initiallyValid Sets the initial state of the visitor. Useful if you
   *                       are not sure that any node at all will be visited,
   *                       which might otherwise leave the visitor in an
   *                       undefined state.
   */
  NameValidationVisitor(const LangText &viewSeparators, bool initiallyValid = true)
    : separators(viewSeparators), valid(initiallyValid), lastFailedNode(0), lastError(0)
  {
  }

  /// Destructor
  virtual ~NameValidationVisitor() { delete lastError; }

  /**
   * Checks the name and display names of the given node for validity.
   *
   * @retval CONTINUE if the node is valid.
   * @retval ABORT if the node is invalid.
   */
  virtual CNSVisitor::NavigationHints visit(const CNSTreeNode &node);

  /**
   * Returns the validity of the last visited node. Because the visitor
   * aborts tree traversal at the first invalid node, this can be regarded
   * as validity for the whole view / tree / subtree visited.
   *
   * Please note that visit() ignores the previous state of the valid-flag.
   * This means that if the visitor aborts because of an invalid node, and visit()
   * is called again with a valid node, the visitor will not retain its "invalid"
   * state.
   */
  bool isValid() const { return valid; }

  /**
   * Returns true if the given DpIdentifier is either empty
   * or can be resolved to a DP name.
   */
  bool isResolvable(const DpIdentifier &dpId);

  /**
   * Resets the state of the visitor to the specified value
   * (true if not explicitely specified).
   * Also resets the pointer to the last failed node.
   */
  void reset(bool initiallyValid = true);

  /**
   * Returns a pointer to the last visited node for which the validation failed,
   * or null if no such node was visited since the last (re-)initialization.
   */
  const CNSTreeNode *getLastFailedNode() const { return lastFailedNode; };

  /**
   * Returns an appropriate error message if the validation failed at some node,
   * otherwise a null pointer.
   */
  const ErrClass *getErrorPtr() const { return lastError; }

private:
  LangText separators;
  bool valid;
  const CNSTreeNode *lastFailedNode;
  ErrClass *lastError;

};

//------------------------------------------------------------------------------
// inline-methods:

inline bool NameValidationVisitor::isResolvable(const DpIdentifier &dpId)
{
  if (dpId.isNull())
  {
    return true;
  }

  CharString dummy;
  if (dpId.convertToString(dummy))
  {
    return true;
  }

  return false;
}

//------------------------------------------------------------------------------

inline void NameValidationVisitor::reset(bool initiallyValid)
{
  valid = initiallyValid;
  lastFailedNode = 0;
  delete lastError;
  lastError = 0;
}

#endif // _NAMEVALIDATIONVISITOR_H_
