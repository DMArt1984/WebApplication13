// Handle FileTransfer messages
#ifndef  FILETRANSFERITEM_H
#define  FILETRANSFERITEM_H

#include  <PtrListItem.hxx>
#include  <CharString.hxx>
#include  <ManagerIdentifier.hxx>
#include  <RecVar.hxx>
#include  <FileTransferSysMsg.hxx>
#include  <CryptoHash.hxx>

#include  <stdio.h>

class  ManagerIdentifier;
class  UIntegerVar;
class  DynVar;

// Base class for file transfer
class  DLLEXP_MANAGER  FileTransferItem : public PtrListItem
{
  /// <summary>
  /// Declare test class as a friended class, having access to private/protected methods
  /// </summary>    
  friend class UNIT_TEST_FRIEND_CLASS;

  public:
    FileTransferItem(const ManagerIdentifier &manId, const CharString &fileName);
    virtual ~FileTransferItem();
   
  public:
    const ManagerIdentifier & getManager() const {return manId;}
    const CharString & getFileName() const {return fileName;}
    
    // Handle data from FiletransferMsg
    virtual PVSSboolean  handleValue(FileTransferSubType type, RecVar &data) = 0;
    
    // Get data for FiletransferMsg
    virtual PVSSboolean  getValue(FileTransferSubType &type, RecVar &data) = 0;
    
    // Check done. Return PVSS_TRUE, if job is finished, else PVSS_FALSE
    virtual PVSSboolean  checkDone() = 0;
    
    // Check if error occured
    PVSSboolean  checkError();
    
  protected:
    ManagerIdentifier manId;
    CharString   fileName;
    unsigned     counter;   
    PVSSboolean  errorState;
};


// Derived class: Send file
class  DLLEXP_MANAGER  SendFileTransferItem : public FileTransferItem
{
  /// <summary>
  /// Declare test class as a friended class, having access to private/protected methods
  /// </summary>    
  friend class UNIT_TEST_FRIEND_CLASS;

  public :
    SendFileTransferItem(const ManagerIdentifier &target, const CharString &fileName);
   ~SendFileTransferItem();
    
  public:
    // Handle data from FiletransferMsg
    virtual PVSSboolean  handleValue(FileTransferSubType type, RecVar &data);
    
    // Get data for FiletransferMsg
    virtual PVSSboolean  getValue(FileTransferSubType &type, RecVar &data);
    
    // Check done. Return PVSS_TRUE, if job is finished, else PVSS_FALSE
    virtual PVSSboolean  checkDone();

  private:
    // no copying allowed, CryptoHash cannot be copied
    SendFileTransferItem(const SendFileTransferItem &);
    SendFileTransferItem &operator=(const SendFileTransferItem &);

    enum
    {
      SendStateNone = 0,     // Nothing done yet
      SendStateData = 1,     // Next message is data
      SendStateEnd = 2,      // Next message is end / fail
      SendStateDone = 3      // All done
    } sendState;
    
    RecVar    options;
    FILE *    file;
    char *    buffer;

    CryptoHash finalChecksum;
    size_t       totalTransmitted;
};


// Dereived class: Receive file
class  DLLEXP_MANAGER  RecvFileTransferItem : public FileTransferItem
{
  /// <summary>
  /// Declare test class as a friended class, having access to private/protected methods
  /// </summary>    
  friend class UNIT_TEST_FRIEND_CLASS;

  public :
    RecvFileTransferItem(const ManagerIdentifier &manId, const CharString &fileName);
   ~RecvFileTransferItem();
    
  public:
    // Handle data from FiletransferMsg
    virtual PVSSboolean  handleValue(FileTransferSubType type, RecVar &data);
    
    // Get data for FiletransferMsg
    virtual PVSSboolean  getValue(FileTransferSubType &type, RecVar &data);

    // Check done. Return PVSS_TRUE, if job is finished, else PVSS_FALSE
    virtual PVSSboolean  checkDone();
    
  protected:
    // Handle data or file stats msg
    PVSSboolean  handleValueData(Variable *varPtr);
    PVSSboolean  handleValueEnd(RecVar &statVar);
    
    // Rollback in case of error
    PVSSboolean  rollback();

  private:
    // no copying allowed, CryptoHash cannot be copied
    RecvFileTransferItem(const RecvFileTransferItem &);
    RecvFileTransferItem &operator=(const RecvFileTransferItem &);

    enum
    {
      RecvStateNone = 0,   // Nothing requested
      RecvStateData = 1,   // Waiting for data
      RecvStateDone = 2    // End message received
    } recvState;
    
    FILE *    file; 
    RecVar    fileStat;
    
    CryptoHash finalChecksum;
    size_t       totalReceived;
};


class  DLLEXP_MANAGER  ListFileTransferItem : public FileTransferItem
{
  /// <summary>
  /// Declare test class as a friended class, having access to private/protected methods
  /// </summary>    
  friend class UNIT_TEST_FRIEND_CLASS;

  public:
    ListFileTransferItem(const ManagerIdentifier &manId, const DynVar &fileList);

    // Handle data from FiletransferMsg
    virtual PVSSboolean  handleValue(FileTransferSubType type, RecVar &data);
    
    // Get data for FiletransferMsg
    virtual PVSSboolean  getValue(FileTransferSubType &type, RecVar &data);
    
    // Check done. Return PVSS_TRUE, if job is finished, else PVSS_FALSE
    virtual PVSSboolean  checkDone();
    
  private:
    DynVar fileList;
    DynVar statList;    
    DynPtrArrayIndex idx;
};

#endif
