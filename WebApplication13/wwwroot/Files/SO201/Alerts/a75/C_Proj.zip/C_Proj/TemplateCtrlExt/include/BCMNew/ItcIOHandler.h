//
//  $RCSfile$
//  $Date$
//  $Revision$
//  $Author$
//  $Locker$
//  $State$
//  $Source$
//
// %Z%JESSI-COMMON-FRAMEWORK 2.0
// %Z%Copyright (C) by Siemens Nixdorf Informationssysteme AG 1992
// %Z%Copyright (C) by Universitaet GH Paderborn 1992
// %Z%Development of this software was partially funded by ESPRIT project 7364.
// %Z%BCM %M% %I% %E%

#ifndef ItcIOHandler_H
#define ItcIOHandler_H

//#ifdef __GNUG__
//#pragma interface
//#endif

#include "JCFPortOS.h"

class itcConnection;

/** Derived classes read input on a file number, write output on a file
    number, handle an exception raised on a file number, or handle a
    timer's expiration.
*/
class DLLEXP_BCM itcIOHandler {
public:
    virtual ~itcIOHandler();

  /// Check if it is possible to read from the connection
  /// @param conn Pointer to itcConnection
  /// @param data Pointer to the data
  /// @return This implementation returns -1
  virtual int inputReady(itcConnection *conn, char *data);
  
  /// Check if it is possible to write to the connection
  /// @param conn Pointer to itcConnection
  /// @param data Pointer to the data
  /// @return This implementation returns -1
  virtual int outputReady(itcConnection *conn, char *data);

  /// Check if an exception event happened on the connection
  /// @param conn Pointer to itcConnection
  /// @param data Pointer to the data
  /// @return This implementation returns -1
  virtual int exceptionRaised(itcConnection *conn, char *data);

  /// The timer has expired
  /// @param sec Seconds
  /// @param usec Milliseconds
  virtual void timerExpired(long sec, long usec);

protected:
    /// default constructor
    itcIOHandler();
};

#endif /* ItcIOHandler_H */
