#ifndef _DIAGMSGITCIOHANDLER_H_
#define _DIAGMSGITCIOHANDLER_H_

#include <DiagItcIOHandler.hxx>

/*
VERANTWORTUNG: Andreas Pfluegl
BESCHREIBUNG: 
*/


/** the DiagItcIOHandler class is a Timer-Object that writes some PVSS-Resource Counter
  * to a DP of the type _Statistics.
  * once the Timer is started by the Manager-Class it restarts itself periodically
  * 
  * @classification internal use
  */
class DLLEXP_MANAGER DiagMsgItcIOHandler : public DiagItcIOHandler 
{
  public:
    DiagMsgItcIOHandler() {}

    virtual ~DiagMsgItcIOHandler() {}

    virtual void timerExpired(long sec, long usec) override;

	private:

};


#endif /* _RESOURCEDIAG_H_ */
