#pragma once

#include <Resources.hxx>
#include <ErrHdl.hxx>
#include <CharString.hxx>
#include <DpIdentifier.hxx>
#include <Variable.hxx>
#include <BitVec.hxx>
#include <set>
#include <map>
#include <HWMapDpPa.hxx>

using namespace std;

class DrvIntDp;
class DrvPluginHdl;

class HmiConnection;

/** This is an internal state.
  * It shows the purpose of the stored dpId - dpName duple.
  * This is for identifying what to do with incoming hotlinks or value changes.
  */
enum InternalDpIdType
  {
    /** (0). this is not an internal dpId - send to hardware */
    NOT_INTERNAL_DPID,
    /** (1). this is the internal general query dpId */
    INTERNAL_GQ_DPID,
    /** (2). this is the internal single query dpId */
    INTERNAL_SQ_DPID,
    /** (3). this is the internal smooth mode dpId */
    INTERNAL_SMOOTHMODE_DPID,
    /** (4). this is the internal eror mode dpId */
    INTERNAL_ERRMSGMODE_DPID,
    /** (5). this is the internal poll mode dpId */
    INTERNAL_POLLMODE_DPID,
    /** (6). this is the internal poll epsilon dpId */
    INTERNAL_POLLEPSILON_DPID,
    /** (7). this is the manual state control dpID */
    INTERNAL_MANUALSTATE_DPID,
    /** (8). this is the internal disable commands dpId */
    INTERNAL_COMMANDS_DPID,
    /** (9). this is the periphaddr diagnosis dpId - show DPs for periphaddr */
    INTERNAL_ADHW_DPID,
    /** (10). this is the HWaddr diagnosis dpId - show HWObjects for periphaddr */
    INTERNAL_HWHW_DPID,
    /** (11). this is the periphaddr diagnosis answer dpId */
    INTERNAL_ADDP_DPID,
    /** (12). this is the HWaddr diagnosis answer dpId */
    INTERNAL_HWDP_DPID,
    /** (13). this is the internal PVSS general query dpId */
    INTERNAL_PVSSGQ_DPID,
    /** (14). this is the internal driver type dpId */
    INTERNAL_DRVTYPE_DPID,
    /** (15). this is an internal poll group dpId */
    INTERNAL_POLLGROUP_DPID,
    /** (16). this is the overflow dpId */
    INTERNAL_OVERFLOW_DPID,
    /** (17). this is an internal dpId for the derived driver */
    INTERNAL_DPID,
    /** (18). this is an internal dpId for the derived driver */
    INTERNAL_DPID_NEW,
    /** (19). this is a dpId for a loaded driver plugin */
    INTERNAL_DRVPLUGIN_DPID,
    /** Anzahl der Typen */
    MAX_INTERNALDPS = INTERNAL_DRVPLUGIN_DPID

    // when adding new internal dp elements please check with SimResource::begin() for default values in simulator
  };

/** internal cache for internal dp lookup
  *
  * @classification ETM internal
  */
struct DpElEntry
{
    /// constructor for the struct items
    DpElEntry(DpIdType d, DpElementId e, InternalDpIdType t = NOT_INTERNAL_DPID) : dp(d), el(e), it(t) {}

    /// the dp number
    DpIdType dp;
    /// the element number
    DpElementId el;
    /// the type of dpid
    InternalDpIdType it;
};

inline bool operator ==(const DpElEntry &de1, const DpElEntry &de2) {return (de1.dp == de2.dp && de1.el == de2.el);}
inline bool operator < (const DpElEntry &de1, const DpElEntry &de2) {return (de1.dp < de2.dp || (de1.dp == de2.dp && de1.el < de2.el));}

typedef set<DpElEntry> DpElSet;

typedef HmiConnection * HCP;
typedef map<unsigned, HCP> HmiConnectionSet;
typedef pair<unsigned, HCP> HmiConnectionItem;
typedef HmiConnectionSet::iterator HCP_Iterator;

/** An identification item. This class contains the dpName and dpId for a requested datapoint.
  * Since the ComDrv has no DpIdentification we must store this information in another way.
  * We also distiguish between the different purposes of the locally known dpIds.
  *
  * @classification ETM internal
  */
class InternalDpAttrId
{
  public:
    /// the purpose of this item
    InternalDpIdType    attrType;
    /// the DpIdentifier
    DpIdentifier        dpId;
    /// the name of the DpIdentifier
    CharString          attrName;

};

/** This class holds all "global" variables of a driver. It also is responsible
  * for providing the names and dpIds for the datapoints to connect additionally to the
  * parametrized IO dps.
  *
  * @classification public use, overload
  */
class DrvResources : public Resources
{
public:

    /// bit flags for AlertService error suppression
    enum AlertServiceErrorLevels {
        ALERT_ALL                  = 0x00,
        ALERT_DELAY_INFO           = 0x01,
        ALERT_ACK_FOR_INVALID_ID   = 0x02,
        ALERT_UPD_FOR_INVALID_ID   = 0x04,

        ALERT_SUPPRESS_ALL         = 0xFF,
    };

  /** Constructor
    */
  DrvResources();

  /** Destruktor
    */
  virtual ~DrvResources();

  /** This is a function to get a pointer to the one existing instance of
    * this class. Each program has exactly one resource instance which holds all the "global"
    * stuff. Therefore it is legal to use this static function for retrieving a valid pointer.
    *
    *  @return pointer to DrvResources instance
    *  @classification public use, call
    */
  static DrvResources*         getSelfPtr() { return selfPtr; }

  /** The driver waits the specified number of seconds or until
    * the function isReadyToConnect returns PVSS_TRUE. If the driver is still not
    * ready to connect it will stop.
    *
    * @return number of seconds to wait until driver is ready to connect
    * @classification pubblic use, call
    */
  static PVSSushort  getWaitSecondsForIdps() {return waitSecs4Idp;}

  /** This function is called before the internal DpIdentifier objects are set up.
    * Use this function to setup the names of the internal dps.
    *
    * @classification public use, overload
    */
  virtual void     initializeIdps() {};

  /** If your derived driver needs additional internal dps you must
    * overload this function and return the number of your dpnames which must be converted
    * to dpIdentifier objects.
    * @return number of dpnames to convert
    * @classification public use, overload
    */
  virtual int              getNumberOfDpNames();

  /** According to the given number of dp names to convert
    * the derived driver is now asked for each dp name.
    * @param index goes from 0 to getNumberOfDpNames()-1
    * @return the name which has to be converted to a dpId
    * @classification public use, overload
    */
  virtual const CharString& getDpName4Query(int index);

  /** As long as there are some unresolved dp names, the driver does nothing except
    * for reading the incoming nameserver messages. You should overload this function to state
    * that you have got all your DpIdentifier objects.
    * @return PVSS_TRUE when you have got all your dpIds
    * @classification public use, overload
    */
  virtual PVSSboolean      allIdsGot();

  /** This function is called to provide the answer from the nameserver to the derived driver.
    * You should overload this function if your driver has internal datapoints.
    * @param name the dpName sent to the nameserver
    * @param dpId the corresponding dpIdentifier got from the nameserver
    * @return PVSS_FALSE in the case that this dpId is not for you
    *         otherwise you should return PVSS_TRUE.
    * @classification public use, overload
    */
  virtual PVSSboolean      setDpIdentifier(CharString& name, DpIdentifier& dpId);

  /** If your derived driver has internal datapoints you can connect the
    * driver for these DpIdentifier objects to get any value changes.
    * @return the number of dps to connect
    */
  virtual int              getNumberOfIds2Connect();

  /** The derived driver is asked to submit the dpIdentifier for which it wants to be connected.
    * @param index runs from 0 to getNumberOfIds2Connect()-1
    * @return a dpId previously got from the nameserver (via setDpIdentifier() )
    * @classification public use, overload
    */
  virtual const DpIdentifier&    getId2Connect(int index);

  /** Callback function. When the driver is being connected for a specific dpId, it gets
    * the current value as answer. If an internal dpId of the derived driver is being
    * connected, this function is called with the result.
    * You are responsible for deleting the varPtr if you don't need it.
    * @param dpId the dpId which has been connected
    * @param varPtr the Variable cut out of the answer message
    * @classification public use, overload
    */
  virtual void             answer4DpId(const DpIdentifier& dpId, Variable* varPtr);

    /** Function to append an internal DP to the list
      * @param idp internal DpIdentifier
    */
  void appendDrvIntDp(DrvIntDp * idp);

    /** Function to cut an internal DP obejct out of the list
      * @param idp internal DpIdentifier
    */
  void cutDrvIntDp(DrvIntDp * idp);

    /** Function for cyclic processing for internal DP's
      */
  void workProcDrvIntDp();

  /** function for cyclic processing of HmiConnection
  */
  void workProcConnection();

  /** function for final shutdown of all HmiConnections
  */
  void shutdownConnections();

  /** Function to cut a HmiConnection object out of the list
      * @param id the datapoint number
    */
  void cutConnection(DpIdType id);

  /** function to find a HmiConnection object for a given id
    * @param id the datapoint number
    * @return the object or NULL if not found
  */
  HmiConnection *findConnection(DpIdType id);

  /** Function to add a new HmiConnection DP to the list
    * this function uses the getNewHmiConnection call to create a new HmiConnection instance
    * @param id the datapoint number
    */
  HmiConnection *addConnectionById(DpIdType id);

  /** function to create new HmiConnection instance for a given id
    * a new HmiConnection instance should be returned here
    * @param id the datapoint number
    */
  virtual HmiConnection *getNewHmiConnection(DpIdType id) const;

  const HmiConnectionSet &getHmiConnectionSet() const { return connectionList_; }

// ----------------------------------------------------------------------
// internal ones
  /** Handles intern or plug-in dp configuration by keyword.
    * @return PVSS_TRUE if proccess was successful
    */
  static PVSSboolean       commonKeyWord();

  /** the pre-config init function
      @n The function sets progName and manNum and opens the configfile.
      If you have any params in your command line, you should overload this function to read your config section.
      Don't forget to call the base function!
      @param argc number of arguments
      @param argv values of arguments
  */
  static void begin(int &argc, char *argv[]);

  /** post-config init functin
      @n The function closes the configfile and interprets the commandline-paramter.
      If you have any params in your command line, you should overload this function to read your config section.
      Don't forget to call the base function!
      @param argc number of arguments
      @param argv values of arguments
  */
  static void end(int &argc, char *argv[]);

  // liefert zurueck fuer wieviele namen dpIdentifier abgefragt werden sollen
  /** Gets number of requested DpIdentifier names.
    * @return number of requested dp identifcator names
    */
  int                      getNumberOfNames2Ask();

  // liefert indexten namen fuer DpIdentifier-Abfrage zurueck
  /** Gets name of intern dp or dp name for query by index.
    * @param index index for selection
  * @return name of intern dp or dp name for query by index
    */
  const CharString&        getDpName(int index);

  // liefert zurueck ob alle Identifier geliefert wurden
  /** Gets the result that all identifiers are resolved.
    * @return PVSS_TRUE if all identifiers are resolved
    */
  PVSSboolean              allAnswered();

  /** Inserts element in internal cache,
    * sets DpIdentifier, config, attribute for identifier name.
    * @param name name of identifier
    * @param dpId DpIdentifier according to name of identifier
    */
  void                     identifier4Name(CharString& name, DpIdentifier& dpId);

  /** sets Dp name for DpIdentifier.
    * @param dpId DpIdentifier
    * @param name name of identifier according to dpId
    */
  void                     name4Identifier(DpIdentifier& dpId, CharString& name);

  // liefert anzahl der DpIdentifier zurueck, fuer die beim Eventmanager angemeldet werden soll
  /** Gets the number of connected identifiers together with number
    * of the identifiers to be connected.
    * @return the number of connected identifiers together
  * with number of the identifiers to be connected
    */
  int                      getConnectCnt();

  // liefert indexten DpIdentifier fuer anmeldung EV zurueck
  /** Gets DpIdentifier for input index
    * @param index input index for dp
    * @return DpIdentifier
    */
  const DpIdentifier&      getConnectId(int index);

  /** Check in internal cache whether dp is INTERNAL_DRVPLUGIN_DPID
    * or NOT_INTERNAL_DPID
    * @param dpId DpIdentifier
  * @return result of dpId checking in internal cache
  */
  InternalDpIdType         isInternal(DpIdentifier& dpId);

  /** Check whether PollActive is set to true
    * @return doPoll
  */
  PVSSboolean              isPollActive() {return doPoll;}

  /** Sets PollActive
    * @param mode mode to be set
  */
  void                     setPollActive(PVSSboolean mode) {doPoll = mode;}

  /** Returns PVSS_TRUE if type of internal dp is INTERNAL_POLLMODE_DPID
    * @param [out] dpId DpIdentifier is set if returned value is PVSS_TRUE
    * @return PVSS_TRUE if type of internal dp is INTERNAL_POLLMODE_DPID
  */
  PVSSboolean              getPollVarId(DpIdentifier &dpId);

  /** Returns PVSS_TRUE if attribute type of internal dp is INTERNAL_DRVTYPE_DPID
    * @param [out] dpId DpIdentifier is set if returned value is PVSS_TRUE
    * @return PVSS_TRUE if type of internal dp is INTERNAL_DRVTYPE_DPID
    */
  PVSSboolean              getDrvTypeId(DpIdentifier &dpId);

  /** Returns PVSS_TRUE if attribute type of internal dp is INTERNAL_OVERFLOW_DPID
    * @param [out] dpId DpIdentifier is set if returned value is PVSS_TRUE
    * @return PVSS_TRUE if type of internal dp is INTERNAL_OVERFLOW_DPID
    */
  PVSSboolean              getOverflowId(DpIdentifier &dpId);

  /** Gets the epsilonPoll
    * @return the epsilonPoll
    */
  static PVSSfloat         getPollEpsilon() { return (PVSSfloat)(epsilonPoll / 100.0) ; }

  /** Sets the value of the epsilonPoll
    * @param val value for epsilonPoll to be set
    */
  static void              setPollEpsilon(PVSSfloat val) { if (val >= 0.) epsilonPoll = val; }

  /** Gets the pollTime
    * @return the pollTime
    */
  static PVSSfloat         getPollTime()    {return pollTime;}

  /** Gets the PollCount
    * @return the PollCount
    */
  static PVSSulong         getPollCount()   {return pollCount;}

  /** Sets the pollTime
    * @param t value of the pollTime to be set
    */
  static void              setPollTime(PVSSfloat t)   {pollTime = t;}

  /** Sets the pollCount to 1
    * @param l value ( is one) of the pollCount to be set
    */
  static void              setPollCount(PVSSulong l)  {pollCount = l;}

  /** Returns PVSS_TRUE if attribute type of internal dp is INTERNAL_POLLEPSILON_DPID
    * @param [out] dpId DpIdentifier is set if returned value is PVSS_TRUE
    * @return PVSS_TRUE if type of internal dp is INTERNAL_POLLEPSILON_DPID
    */
  PVSSboolean              getPollEpsilonId(DpIdentifier &dpId);

  /** Returns PVSS_TRUE if attribute type of internal dp is INTERNAL_ADDP_DPID
    * @param [out] dpId DpIdentifier is set if returned value is PVSS_TRUE
    * @return PVSS_TRUE if type of internal dp is INTERNAL_ADDP_DPID
    */
  PVSSboolean              getDiagAnswerId(DpIdentifier &dpId);

  /** Returns PVSS_TRUE if attribute type of internal dp is INTERNAL_HWDP_DPID
    * @param [out] dpId DpIdentifier is set if returned value is PVSS_TRUE
    * @return PVSS_TRUE if type of internal dp is INTERNAL_HWDP_DPID
    */
  PVSSboolean              getHWDiagAnswerId(DpIdentifier &dpId);

  /** Gets IO transformation timeout
    * @return IO transformation timeout
  */
  static unsigned          getIOTransTimeout () {return ioTransTimeout;}

  /** Sets IO transformation timeout
    * @param iot IO transformation timeout to be set
  */
  static void              setIOTransTimeout (unsigned iot) {ioTransTimeout = iot;}

  /** Gets srcTimeCheckMode
    * @return srcTimeCheckMode
  */
  static unsigned          getSrcTimeCheckMode() {return srcTimeCheckMode;}

  /** Gets srcTimeMaxBefore
    * @return srcTimeMaxBefore
  */
  static int               getSrcTimeMaxBefore() {return srcTimeMaxBefore;}

  /** Gets srcTimeMaxBehind
    * @return srcTimeMaxBehind
  */
  static int               getSrcTimeMaxBehind() {return srcTimeMaxBehind;}

  /** Gets maxConnectMachineSend
    * @return maxConnectMachineSend
  */
 static unsigned          getmaxConnectMachineSend() {return maxConnectMachineSend;}

  /** Gets maxConnectMachinePending
    * @return maxConnectMachinePending
  */
 static unsigned          getmaxConnectMachinePending() {return maxConnectPending;}

 /** Gets maxVcMessageSize
    * @return maxVcMessageSize
  */
  static unsigned          getMaxVcMessageSize() {return maxVcMessageSize;}

  /** Gets the number of internal dp's which should be connected with answer
    * return the number of iDps which should be connected with answer
  */
  virtual int              getInternCntWA() const {return internCnt;}

  /** Gets the name of the plugin
    * @return the name of the plugin ( or an empty string )
  */
  static const CharString  &getDrvPluginName() { return drvPluginName; };

  /** Use this function if you need the last values of some internal
    * datapoints to connect to the hardware. After connecting to the event manager
    * the driver will not call HWService::start() nor process hotlinks from non-internal
    * datapoints until this function returns PVSS_TRUE.
    * <p> Per default this function returns always PVSS_TRUE. Overload this function
    * when your driver needs more information to connect to the hardware.
    * The driver will not wait for more than 1000 seconds and abort, if this function
    * still returns PVSS_FALSE.
    * @return PVSS_TRUE if the driver is ready to call HWService::start() and can process
    * hotlinks from non-internal datapoint, PVSS_FALSE otherwise.
    */
  virtual PVSSboolean      isReadyToConnect();

  /** Use this function to toggle the behaviour of datapoint of
    * type DynVar. For messages sent to the SPS those datapoints are treated
    * as other datapoints, the subindex in the address config differentiates
    * between datapoints. For messages comming from the SPS the behaviour of
    * those datapoints depends on the return value of this function:
    * If it returns PVSS_FALSE those datapoints are treated also like other
    * datapoints. If the function returns PVSS_TRUE one datapoint is treated
    * like an array, the subindex (always running from 0) gives the element
    * position in the DynVar-array
    *
    * @param  dpId datapoint for which this shall be evaluated
    * @return PVSS_FALSE if datapoints of type DynVar are treated as other
    * datapoints, PVSS_TRUE if they are treated as an array.
    * Per default this function returns PVSS_TRUE.
    *
    * @classification public use, overload
    */
  virtual  PVSSboolean     dynVarIsArray(const DpIdentifier & dpId);

  /** Gets selected timeout
    * @return timeout
    */
  static PVSSulong   getSelectTimeout() { return selectTimeout; }

  /** Control, if the active state is set manually or via a SysMsg from the event manager.
    * @param flag is 1 if an active state are set manually
    * @classification public use, call
    */
  static void        setManualRedState(PVSSboolean flag);

  /** Return if the active state is controlled manually or via a SysMsg from the event manager
    * @return 1 if an active state are set manually
  */
  static PVSSboolean getManualRedState() {return manualRedState;}

  /** Use this function to disable / enable sending commands to the hardware.
    * @param state use PVSS_TRUE to disable sending commands and PVSS_FALSE to
    * enable it again.
    * @classification public use, call
    */
  static void        setDisableCommands(PVSSboolean state) {disableCommands = state;}

  /** Return wether commands are discarded or sent to the hardware.
    * @return PVSS_TRUE if commands are disregarded or PVSS_FALSE if all commands are
    * sent to the hardware.
    * @classification public use, call
    */
  static PVSSboolean getDisableCommands();

  /** Return the user and status bits that are considered for the smoothing
    * @return A BitVec which contains the bits
    * @classification internal use, call
    */
  static BitVec  getSmoothBits() {return smoothBits;}

  /** Return the user bits that are set for hitorical data.
    * Historical data are sent as correction values and not as original values to the event.
    * @return A BitVec which contains the bits
    *
    * @classification internal use, call
    */
  static BitVec getHistDataBits()  {return histDataBits;}

  /** Gets flag of sendCorrValWithStatus
  * @return sendCorrValWithStatus
  */
  static PVSSboolean getSendCorrValWithStatus() { return sendCorrValWithStatus; }

  /** Gets flag of reconnection
    * @return reconnecting flag
    */
  static PVSSboolean getReconnect() {return reconnectFlag;}

  /** Gets max number of outstanding answers
    * @return Max number of outstanding answers
  */
  static unsigned    getCommitCount() {return commitCount;}

  /** Gets max output queue size
    * @return max output queue size
    */
  static unsigned    getMaxOutputQueueSize();


  /** Sets max output queue size
    * @param newVal new value of max output queue size
    */
  static void        setMaxOutputQueueSize(unsigned newVal) {maxOutputQueueSize = newVal;}

  /** Gets max alert queue size
   * @return max alert queue size
   */
  static unsigned    getMaxAlertQueueSize() {return maxAlertQueueSize;}

  /** Gets max poll time before SQ is done for new "xx on use" items
   * @return max time in secs
   */
  static unsigned    getMaxTimeBeforeSQ() {return maxSecsBeforeSQ;}

  /** Sets new max alert queue size
    * @param newVal new value of an alerft queue size
    */
  static void        setMaxAlertQueueSize(unsigned newVal) {maxAlertQueueSize = newVal;}

  /** Gets max number of pending alert messages
    * @return max number of pending alert messages
  */
  static unsigned    getMaxPendingAlerts() {return maxOpenAlertMsg;}

  /** Sets max number of pending alerts
    * @param newVal max number of pending alert messages that to be set
  */
  static void        setMaxPendingAlerts(unsigned newVal) {maxOpenAlertMsg = newVal;}

 /** Sets the driver identification string
   * @param driverType driver identification string
   */
 static void setDriverType (const char * driverType) {driverType_ = driverType;}

 /** Gets the driver indentification string
   * @return driver type indentification string
   */
  static const CharString & getDriverType () { return driverType_;}

  /** If set to PVSS_TRUE, normal behaviour, the drv manager sets the driver state to running, when PVSS_FALSE it does not
    * be sure to call Manager::setRunningEvent() manually later on.
  * @param flag value for setting of autoSwitchToRunning
  */
  static void        setAutoSwitchToRunning(PVSSboolean flag) {autoSwitchToRunning = flag;}

  /** If PVSS_TRUE, normal behaviour, the drv manager sets the driver state to running, when PVSS_FALSE it does not
    * @return logical value of AutoSwitchToRunning, e.g.
  *  PVSS_TRUE in case of normal behaviour, the drvmanager sets the driver state to running, otherwise PVSS_FALSE
  */
  static PVSSboolean getAutoSwitchToRunning() { return autoSwitchToRunning; }

  // IM 102687
  /** check if user wants to see this error
      @param flag value for the requested error message
      @return PVSS_TRUE if we should issue the error
  */
  static PVSSboolean shouldPrintAlertError(unsigned flag);

  // IM 102687
  /** user sets mask to not see this error
      @param value value for the error message level to suppress
  */
  static void setSuppressAlertServiceErrors(unsigned value) {suppressAlertServiceErrors = value;}


  /** Prints out the general available command-line parameters. When you derive your
    * own resource class, you should overload this function to print out your own new features.
    * Don't forget to call the base function before you start writing ...
    * @classification public use, call / overload
    */
  static void printHelp();

  // TI 2342
  /** Prints out the used debug flags and their meaning.
      @classification public use, call / overload
  */
  static void printHelpDbg();

  /** Gets name of dp driver
    * @return name of dp driver
  * @classification public use, call / overload
    */
  static const CharString & getDrvDpName() {return drvDpName;}

  /** Sets the connectForAlerts after parameter connect
    * @param connect value for connectForAlerts that will be set
    */
  static void setConnectForAlert(const PVSSboolean doConnect);

  /** Gets connection for alert
    * @return connection for alert
    */
  static const PVSSboolean getConnectForAlert() {return connectForAlerts;}

  /** Gets suppressCyclicContinuous value
    * @return suppressCyclicContinuous flag
    */
  static const PVSSboolean getSuppressCyclicContinuous() {return suppressCyclicContinuous;}


  /** Gets a set of all DPEs which should be traced when flag DRV_TEST_DATAACCESS_SINGLE is set
    * @return list of DPEs where flag is set
    */
  static const set<DpIdShort> & getTraceSingleDPEs() {return DrvResources::traceSingleDPEs;}

  static unsigned getMaxToDpBeforeSend() { return maxToDpBeforeSend; }

  /// debug logging level
  static PVSSshort DBG_DRV_IOCOUNT;
  /// debug logging level
  static PVSSshort DBG_DRV_ALERT;
  /// debug logging level
  static PVSSshort DBG_DRV_ALERTOBJECT;
  /// debug logging level
  static PVSSshort DBG_DRV_CONNECTION;
  /// debug logging level
  static PVSSshort DBG_DRV_SUBSCRIPTION;
  /// debug low level filter actions
  static PVSSshort DBG_DRV_LLF;
  /// debug logging level
  static PVSSshort DBG_DRV_DIRECTWRITE;
  /// debug logging level
  static PVSSshort DBG_DRV_DRVINTDP;

  /// test tracing level
  static PVSSshort DBG_TEST_CONNECTION;
  /// test tracing level
  static PVSSshort DBG_TEST_POLLGROUP;
  /// test tracing level
  static PVSSshort DBG_TEST_DATAACCESS_INPUT;
  /// test tracing level
  static PVSSshort DBG_TEST_DATAACCESS_OUTPUT;
  /// test tracing level
  static PVSSshort DBG_TEST_DATAACCESS_SINGLE;
  /// test tracing level
  static PVSSshort DBG_TEST_DATAACCESS_ONUSE;

 protected:
  /// Simulator uses this to connect to _Simulatorx dps
  static CharString       drvDpName;          // DP-Name fuer internen DP

private:

  /** Function to insert connection DP into list
    * since all HmiConnection objects are of type DrvIntDp we do not capture the object
    * @param ptr HmiConnection object
  */
  void insertConnection(HCP ptr);

  static int  getInternalIndex(InternalDpIdType type);  // Sucht entsprechenden Eintrag, um
                                              // Doppeleintraege zu verhindern

  // allocate new extern handler
  static bool newDrvPluginHdl(const CharString &libName, DrvPluginHdl* &hdl);

  // simulator uses these fields to connect to _Simulatorx dps
  static InternalDpAttrId internDp[MAX_INTERNALDPS];
  // counter for actually defined dps
  static int              internCnt;

  static PVSSboolean      autoSwitchToRunning;   // true, normal behaviour, the drvmanager sets the driver state to running, when false it does not

  static PVSSboolean      doPoll;
  static PVSSfloat        epsilonPoll;           // defines epsilon in percent of poll interval
                                                 // default = 100.0 -> poll anyway
  static PVSSfloat        pollTime;              // Max. time spent in polling
  static PVSSulong        pollCount;             // Max items polled
  static PVSSboolean      pollGroupMode_;        // indicates if we are polling in poll group mode

  static PVSSulong        selectTimeout;         // used for configurable timeout in dispatch()
                                                 // value is read as milliSeconds
  static DrvResources*        selfPtr;
  static int              idSetCnt;
  static PVSSboolean      manualRedState;        // PVSS_TRUE, if _DriverCommon.DC controls the state
  static PVSSboolean      disableCommands;       // PVSS_TRUE, wenn *keine* Befehle an die Peripheri
                                                 // geschickt werden sollen
  static PVSSushort       waitSecs4Idp;          // Anzahl Sekunden, die auf int. DP gewartet wird
  static BitVec           smoothBits;            // Bits used for smoothing
  static BitVec           histDataBits;          // Those bits are set for historical values
  static PVSSboolean      sendCorrValWithStatus; // Send correction value with status
  static PVSSboolean      reconnectFlag;         // Reconnect after connection lost to EM
  static unsigned         commitCount;           // Max number of outstanding answers
  static unsigned         maxOutputQueueSize;    // Max output queue size
  static unsigned         ioTransTimeout;        // timeout for a transaction on an I/O address in s
  static unsigned         srcTimeCheckMode;      // mode for checking the source time 0=no check 1=only error message 2=error msg and discard
  static int              srcTimeMaxBefore;      // maximum allowed time difference, if source time is before PVSS time (in s)
  static int              srcTimeMaxBehind;      // maximum allowed time difference, if source time is behind PVSS time (in s)
  static unsigned         maxVcMessageSize;      // maximum number of value changes in one ComplexVC message sent by the driver
  static unsigned         maxConnectMachineSend; // maximum number of (dis)connect messages sent per round
  static unsigned         maxConnectPending;     // maximum number of unconfirmed connect messages from ConnectMachine

  static unsigned         maxSecsBeforeSQ;       // maximum poll time to suppress single queries for new items "xx on use"

  static unsigned         maxToDpBeforeSend;     // maximumm number of toDp calls before a sendData2Dp is called unconditionally, switched off if 0

  static CharString driverType_;

  SimplePtrArray<DrvIntDp> drvIntDpList_;         // list of internal DPs
  HmiConnectionSet        connectionList_;        // list of HmiConnections - objects are also members of drvIntDpList_

  static CharString       drvPluginName;          // Contains the name of DLL to be loaded

  static PVSSboolean      connectForAlerts;            // can be set with config entry "connectForAlerts = [y|n]"
  static unsigned         suppressAlertServiceErrors;  // suppress warnings from AlertService - default 0: show all
                                                       //     value 1: suppress ACK error for unknown AlertID
  static unsigned         maxAlertQueueSize;           // maximum of alert messages before driver signals overload
  static unsigned         maxOpenAlertMsg;             // maximum of unconfirmed alert messages to EV

  static PVSSboolean      suppressCyclicContinuous;    // suppress polling of cyclic continuous elements

  static set<DpIdShort>   traceSingleDPEs;             // if this is set for a DPE, this DPE will be traced review: kommentar?????

friend class UNIT_TEST_FRIEND_CLASS;
};


// -----------------------------------------------------------------------------------------
// Disable commands wird aus redActive und disableCommands berechnet
inline  PVSSboolean  DrvResources::getDisableCommands()
{
  if (manualRedState)
    return disableCommands;
  return (Resources::isRedActive() ? PVSS_FALSE : PVSS_TRUE);
}


