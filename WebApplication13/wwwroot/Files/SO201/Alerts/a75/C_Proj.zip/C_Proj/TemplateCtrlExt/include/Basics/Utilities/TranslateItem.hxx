#ifndef _TRANSLATEITEM_H_
#define _TRANSLATEITEM_H_
 
/*
VERANTWORTUNG: Christoph Theis       
BESCHREIBUNG:  Eintrag in der Liste der Tokens fuer die Uebersetzung
  03/97 (ChT)
*/


#ifndef _CHARSTRING_H_
#include <CharString.hxx>
#endif

#ifndef _DYNVAR_H_
#include <DynVar.hxx>
#endif

#ifndef _TEXTVAR_H_
#include <TextVar.hxx>
#endif

/** This class builds the objects for the translation list.
    The TranslationList class is used to translate between different languages.
    @classification CoreTest
*/
class DLLEXP_BASICS TranslateItem
{
  public:     

    /**
    Only one allowed constructor, receives as the input a string 'str' token and the translation delimiter 'del'.
    
    @param  str The constant string to be translated and tokenized. 
    @param  del The delimiter. 
    */
    TranslateItem(const CharString &str, char del);    

    /**
    Returns the token (already sorted)
    
    @return The token string. 
    */
    const CharString &getToken() const { return token; }

    /**
    Sets the translation index as a token
    
    @param  idx Zero-based index of the token. 
    */
    void  setToken(int idx);

    /**
    Sets the token explicitly
    
    @param  tok The token string. 
    */
    void  setToken(const CharString &tok);

    /**
    Translates according to a given language index 'lang'. The resulting string is returned then 
         
    @param [in,out] out The output string. 
    @param  lang        The language id. 
    
    @return If the translation was succesfully executed, returns true. Otherwise false. 
    */
    PVSSboolean getTranslation(CharString &out, unsigned int lang) const;

    /**
    Changes the translation
    
    @param  str The string to be translated. 
    @param  idx Zero-based index of the translation. 
    */
    void  setTranslation(const CharString &str, int idx);

    /**
    Returns the array of translated strings for every language
    
    @return The DynVar of type TextVar with translated strings. 
    */
    const DynVar & getLang() const {return lang;}

  private:
    CharString token;    // Der Token fure die Sortierung
    DynVar  lang;        // Die Eintraege in den verschiedenen Sprachen
    
    // Hilfsfuns
    void setupItem(const CharString &str, char del);    // Bricht str in Tokens
    char *getNextToken(char *str, char del);            // Liefert den naechsten Token im String
    char *strip(char *str);                             // Whitespace aus str entfernen
    
    // so that the compiler does not define them itself !!
    // default Konstruktor (es gibt sonst keine Moeglichkeit, ein Item zu init.
    TranslateItem() {}; //COVINFO LINE: defensive (AP: disallow ctor)
    // copy constructor
    TranslateItem(const TranslateItem &) {} //COVINFO LINE: defensive (AP: disallow copy ctor)
    // assignment operator
    TranslateItem &operator=(const TranslateItem &) { return *this; } //COVINFO LINE: defensive (AP: disallow operator=)
};


#endif /* _TRANSLATEITEM_H_ */
