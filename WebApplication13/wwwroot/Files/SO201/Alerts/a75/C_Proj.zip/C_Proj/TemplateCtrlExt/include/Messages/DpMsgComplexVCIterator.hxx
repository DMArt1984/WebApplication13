#ifndef _DPMSGCOMPLEXVCITERATOR_H_
#define _DPMSGCOMPLEXVCITERATOR_H_

#include <MsgGroupIterator.hxx>

// forward declarations
class DpMsgComplexVC;
class DpVCGroup;
class DpVCItem;


/**
 * A MsgGroupIterator-implementation for DpMsgComplexVC.
 *
 * Some implementation properties:
 * - The message cannot be changed, only read.
 * - All items of a group in the iterator belong to the same DPE,
 *   so going through the message with getFirstGroup()/getNextGroup() and
 *   calling getFirst() for each group should be sufficient to see all DPEs.
 * - The iterator will not skip empty groups, but such groups shouldn't exist anyway.
 * - Calling getFirstGroup() / getNextGroup() changes the internal cursor of the message.
 *
 * @internal
 */
class DLLEXP_MESSAGES DpMsgComplexVCIterator : public MsgGroupIterator
{
public:
  DpMsgComplexVCIterator(const DpMsgComplexVC &msg);

  virtual bool getFirstGroup() const;

  virtual bool getNextGroup() const;

  virtual const DpIdentifier *getFirst() const;

  virtual const DpIdentifier *getNext() const;

  virtual const DpIdentifier *getCurrent() const;

  /**
   * DpMsgComplexVC cannot be changed, so this method does not remove anything.
   * It actually should never be called, since this class should always be given
   * to the SecurityPlugin as const type.
   * For completeness, we try to make it act like other iterators anyway,
   * by jumping to the next group.
   */
  virtual bool removeCurrentGroup(ErrClass *errorPtr = 0) { delete errorPtr; return getNextGroup(); }

  virtual const Variable *getCurrentValue() const;

  /// DpMsgComplexVC cannot be changed, so this method will always return null
  virtual Variable *getCurrentValue() { return 0; }

  /// DpMsgComplexVC cannot be changed, so this method will always return false
  virtual bool replaceCurrentValue(Variable *newValue) { delete newValue; return false; }

  /**
   * In a DpMsgComplexVC, all items of a group in the message belong to the
   * same DPE.
   */
  virtual bool hasSameDpePerGroup() const { return true; }

private:
  // avoid copy construction and copy assignment
  DpMsgComplexVCIterator(const DpMsgComplexVCIterator &);
  DpMsgComplexVCIterator &operator=(const DpMsgComplexVCIterator &);

  const DpMsgComplexVC &msg_;
  mutable const DpVCGroup *currentGroup_;
  mutable const DpVCItem *currentItem_;

};

#endif // _DPMSGCOMPLEXVCITERATOR_H_
