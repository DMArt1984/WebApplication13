#ifndef _MESSAGEDIAG_H_
#define _MESSAGEDIAG_H_

#include <DynPtrArray.hxx>
#include <UIntegerVar.hxx>
#include <PtrListItem.hxx>
#include <DpIdentifier.hxx>
#include <DpIdValueList.hxx>
#include <ManagerIdentifier.hxx>

/*
VERANTWORTUNG: Andreas Pfluegl
BESCHREIBUNG: 
*/


/** the MessageDiag class for internal use only
  * @classification internal use
  */

 /* Dieser Kommentar ist absichtlich kein DOC++ Kommentar!
  *
  * Zaehlt die anzahl der MSGs einer Richtung (snd / rcv) fuer eine TCP-Connection
  * Hat 2 Auswertungen 
  *   getDirtyList: Liefert alle Counter die ich seit dem letzen Aufruf dieser Methode
  *                 geaendert haben als Datenpunktliste.
  *   getTotalList: Liefert alle Counter als DynPtrArray<InfoItem> zurueck.
  * 
  */

/**
 * The MessageDiag class.
 * This class is used to count the messages sent and received for a specific TCP-Connection.
 */
class DLLEXP_BASICS MessageDiag: public PtrListItem
{
  public:

    /// Directions of messages, send or received
    enum Direction                        
    {
      snd,
      rcv
    };

  enum MsgType                  // Jede MSG wird in einer der folgenden Kategorien zugeordnet
  {                             // Msg::isAStat() macht diese Zuordnung
    sysMsgCnt_,
    sysMsgNameserverCnt_,
    dpMsgConnectCnt_,
    dpMsgHotlinkCnt_,
    dpMsgVcCnt_,
    dpMsgRequestCnt_,
    dpMsgAnswerCnt_,
    dpMsgIdentificationCnt_,
    dpMsgTypecontainerCnt_,
    dpMsgManipDpCnt_,
    dpMsgLockCnt_,
    dpMsgUnlockCnt_,
    dpMsgCmdNewdelDpCnt_,
    dpMsgSimpleRequestCnt_,
    dpMsgAsynchRequestCnt_,
    dpMsgSynchRequestCnt_,
    dpMsgPeriodRequestCnt_,
    dpMsgAlertVcCnt_,
    dpMsgAlertConnectCnt_,
    dpMsgAlertHlCnt_,
    dpMsgAlertDisconnCnt_,
    dpMsgAlertTimeRequCnt_,
    dpMsgAlertPeriodRequCnt_,
    dpMsgFilterReqCnt_,
    dpMsgFilterConnectCnt_,
    dpMsgFilterDisconnectCnt_,
    dpMsgAbortRequestCnt_,
    dpMsgMaxAgeRequestCnt_,
    dpMsgManipCnsCnt_,
    MAX_MSG_CNT// dont remove this
  };

    /**
     * The InfoItem struct is used to store the number of messages of a certain
     * messageType sent or received by a certain manager.
     */
    struct InfoItem
    {
      /// direction, send or receive
      CharString dir;             // Counter fuer die Richtung (snd / rcv)
      /// the name of the manager to which this manager is connected
      CharString managerName;     // das ist eine Connection zum Manager managerName (z.B. "ui")
      /// the name of the message type
      CharString messageName;     // Counter fuer die Kategorie messageName
      /// the counter how many messages were sent for this connection
      const UIntegerVar *value;   // value ist der Counter fuer die Connection
      /// whether a _Statistics datapoint was used
      bool summed;
    };

    /// DynPtrArray for InfoItems
    typedef DynPtrArray<InfoItem> DynInfoItem;

    // Counter fuer eine Richtung einer Connection
    // uebergabe von Manager::getId
    // das ist eine Connection zum Manager man
    // snd oder rcv
    // me wird aus Resources geholt
    // Wenn ein Datenpunkt mit dem Namen _Stat_<me>_<meNr>_to_<man>_<manNr> vom 
    // Type _Statistics_Connection existiert, so lifert getDirtyList()
    // eine DpIdValueList fuer alle geaenderten werte.
    // gibt es diesen Datenpunkt nicht ist die DpIdentList leer.
    // z.B. im Event-Manager ist me = event und der Datenpunkt
    //      der Verwendet wird ist _Stat_event_0_to_ui_1

    /**
     * Constructor.
     * Initializes the MessageDiag for a given manager and direction.
     * The counter is initialized with 0.
     * @param man managerIdentifier of this MessageDiag
     * @param dir the direction, send or receive
     */
    MessageDiag(const ManagerIdentifier &man, Direction dir);

    /// Destruktor
    ~MessageDiag() {}

    // bei jedem Send oder Receive diese Methode aufrufen
    /**
     * This function increases the count for a specific messageType.
     * @param msg the type of the message for which the count should be increased.
     * @return the new count.
     */
    long incMsgCnt(MsgType msg); 

    // wenn ein DP mit dem Namen _Statistics_<manager> existiert
    // liefert getDirtyList eine DpIdValueList aller DP Elemente die sich seit dem 
    // letzen aufruf geaendert haben.
    // Die Manager-Klasse verwendet diese DpIdValueList in einem dpSet
    /**
     * This function will deliver a list of all sent or received messages since 
     * the last call. A _Statistics_<manager> datapoint is necessary for this 
     * feature to work.
     * @param dpIdList [OUT] list of all changed messagetype datapoints for this manager and their count.
     * @param summen   [OUT] entry with the DpIdentifer for this managers messagediag and the sum of all changes.
     * @return false if no changes occured, else true.
     */
    bool getDirtyList(DpIdValueList &dpIdList, DpIdValueList &summen);

    // Komplette Statistik des Counters
    /**
     * This function will deliver a list of all sent or received messages in total.
     * @param resList [OUT] list of all InfoItems.
     * @return always returns true.
     */
    bool getTotalList(DynInfoItem &resList);

    /**
     * This function returns the number of the observed manager.
     * @return manager number.
     */
    PVSSuchar getManNum() { return(man_.getManNum()); }

  protected:
    /**
     * This function returns the number of the given manager as a CharString.
     * @param manId the manager number.
     * @return manager number as a CharString.
     */
    CharString  manIdToString(const ManagerIdentifier &manId) const;
    
    /**
     * This function is used to retrieve the datapoint used to store
     * the information for a certain message type.
     * @param dpIdx the messageType number.
     * @param dpid [OUT] DpIdentifier in which the result is stored.
     * @return true if DpIdentifier was found, else false.
     */
    bool myGetId(int dpIdx, DpIdentifier &dpid);

    /// Performance Counter
    PVSSlonglong *counter_;

    /// Manager
    ManagerIdentifier      man_;

    /// Direction, send or receive
    Direction              dir_;

    /// DpIdentifier array of the counter dp elements for each messageType.
    DpIdentifier           msgDpId_[MessageDiag::MAX_MSG_CNT+1];  // DP-Ids aller Counter-Element

    /// UIntegerVar array of the counters for each messageType
    UIntegerVar            msgCnt_[MessageDiag::MAX_MSG_CNT+1];   // die counter selbst

    /// char array of dirty flags indicating whether changes occurred for a certain messagetype.
    char                   dirty_[MessageDiag::MAX_MSG_CNT+1];    // wurde der Counter veraendert?
};


inline  CharString  MessageDiag::manIdToString(const ManagerIdentifier &manId) const
{
  return CharString(manId.getManName()) + "_" + (int) manId.getManNum();
}

#ifdef WIN32
#pragma warning ( disable: 4231 )
#endif

//! @cond Doxygen_Suppress
#if defined(LIBS_AS_DLL)
  EXTERN_BASICS template class DLLEXP_BASICS DynPtrArray<MessageDiag::InfoItem>;
#endif
//! @endcond

#ifdef WIN32
#pragma warning ( default: 4231 )
#endif


#endif /* _MESSAGEDIAG_H_ */
