#ifndef _STACKITEM_H_
#define _STACKITEM_H_

#include <CtrlVarList.hxx>

class CtrlSment;
class CtrlFunc;
class ErrorVar;
class CtrlClass;
class ClassVar;

/*  author VERANTWORTUNG: Martin Koller */
/** class used for storing local-Variables on function call
    @classification internal use
 */
class StackItem
{
  public:
    // no ctor. Increase performance by not initing all members since all of them are set with set()

    ~StackItem()
    {
      delete locals;
      delete argValues;
      // Don't delete basePtr or sment
    }

    void set(CtrlVarList *_locals, const CtrlVar *_basePtr,
             CtrlVarList *_argValues, const CtrlSment *_sment,
             bool _deferred, bool _wantEval, const CtrlClass *newClassScope, ClassVar *instance,
             const CtrlFunc *newFunc)
    {
      locals    = _locals;
      basePtr   = _basePtr;
      argValues = _argValues;
      sment     = _sment;
      func      = newFunc;
      deferred  = _deferred;
      wantEval  = _wantEval;
      perfCount = inCatch = inFinally = false;
      exceptionPtr = nullptr;
      classScope = newClassScope;
      classScopeInstance = instance;
    }

    void setPerfCount() { perfCount = true; }
    bool getPerfCount() const { return perfCount; }

    /// get the top locals
    CtrlVarList *getLocals()  const { return locals; }

    // get the result of a evaluation
    CtrlVarList *getArgValues() const { return argValues; }

    /// get the top of the former locals
    const CtrlVar *getBasePtr() const { return basePtr; }

    /// get the top CtrlSment
    const CtrlSment *getSment() const { return sment; }

    bool isDeferred() const { return deferred; }

    /// cut the locals from the stack
    CtrlVarList *cutLocals() { CtrlVarList *loc = locals; locals = 0; return loc; }

    CtrlVarList *cutArgValues() { CtrlVarList *list = argValues; argValues = 0; return list; }

  public:
    CtrlVarList     *locals;
    const CtrlVar   *basePtr;
    CtrlVarList     *argValues;
    const CtrlSment *sment;
    const CtrlFunc  *func;
    bool deferred;
    bool wantEval;
    bool perfCount;
    bool inCatch;
    bool inFinally;
    ErrorVar *exceptionPtr;
    const CtrlClass *classScope;
    ClassVar *classScopeInstance;

  public:
    StackItem *next;
};

#endif /* _STACKITEM_H_ */
