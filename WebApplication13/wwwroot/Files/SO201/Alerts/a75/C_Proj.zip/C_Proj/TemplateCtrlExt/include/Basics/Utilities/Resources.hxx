#ifndef _RESOURCES_H_
#define _RESOURCES_H_

#include <DebugOutput.hxx>
#include <Bit32Var.hxx>
#include <TimeVar.hxx>
#include <CharString.hxx>
#include <DynPtrArray.hxx>
#include <OaFileSys.hxx>
#include <Pathes.hxx>
#include <Types.hxx>
#include <ResourceDiag.hxx>
#include <ManagerIdentifier.hxx>
#include <ComponentNames.hxx>
#include <IpAcl.hxx>
#include <BitVec.hxx>

#include <fstream>
#include <stdio.h>
#include <locale.h>
#include <map>
#include <set>

#include <OaLocale.hxx>
#include <LanguageDefRec.hxx>

#ifdef OS_SOLARIS
  #define OS_PMON_DEFAULT_PORT      4779
#else
  #define OS_PMON_DEFAULT_PORT      4999
#endif

class StdSignalHandler;
class TranslateList;
class StringToken;
class DynVar;

void setAddVersionInfo();

//#define SHIFT_ARGS(i) { memmove(&argv[i], &argv[i+1], (argc - i) * sizeof(char*)); argc--; }
//this macro has been defined for the Resources::end() function

#define SHIFT_ARGS_N(i,n)  \
          if ( i >= 0 && i < argc && n > 0 && n <= ( argc -i +1) )\
          { if ( n < ( argc - i +1) ) memmove(&argv[i], &argv[i+n], (argc - (n + i) +1 ) *sizeof(char*));\
              argc -= n;}

#define SHIFT_ARGS(i)  SHIFT_ARGS_N(i, 1)

// ========== mxProxy ============================================================
typedef enum
{
  stNone = 0,
  stSSLFILE = 1,
  stSSLWINCERT = 2,
  stPLAIN      = 3
} SEC_TYPE_t;


typedef struct
{
  CharString proxyHost;
  unsigned short proxyPort;
  SEC_TYPE_t secType;
} ProxyDescription_t;

typedef std::map<CharString, ProxyDescription_t>  CharStringProxyDescriptionMap;


// ========== LanguageIdType ============================================================

typedef PVSSuchar LanguageIdType;        // Index
typedef PVSSushort GlobalLanguageIdType;  // PVSS unique

// ========== SocketInitializer ============================================================

/** This class ensures correct initialization of a socket
    @n Under Windows, the socket interface must be initialised properly,
    before any network related function can be used. So a dummy object is
    created, which performs the necessary tasks. An object of this class is
    instantiated immediatly before the first call of OaNoPosix::gethostname() in Resources.cxx.
    @classification ETM internal
  */
class DLLEXP_BASICS SocketInitializer
{
public:
  /// constructor
  SocketInitializer();

  /// destructor
  ~SocketInitializer();

private:
  static PVSSboolean init;
};

#ifdef WIN32
  #pragma warning ( push )
  #pragma warning ( disable: 4231 )
#endif

#if defined(LIBS_AS_DLL)
  EXTERN_BASICS template class DLLEXP_BASICS DynPtrArray<LanguageDefRec>;
  EXTERN_BASICS template class DLLEXP_BASICS DynPtrArray<CharString>;
  EXTERN_BASICS template class DLLEXP_BASICS DynPtrArray<ManagerIdentifier>;
#endif

#ifdef WIN32
  #pragma warning ( pop )
#endif

// ========== DejaVuType ============================================================

enum DejaVuType
{
  ManWithDejaVu,
  ManWithoutDejaVu
};

// ========== Resources ============================================================

/** This class and its derivatives should hold all data considered "global" to the running manager
    @n The class is responsible for reading the config file and handling
    command line parameters. Several common utility functions like debug flags are covered
    here.
    @classification public use, derive
  */
class DLLEXP_BASICS Resources
{
  friend class UNIT_TEST_FRIEND_CLASS;    // ein Unit-Test braucht erweiterten zugriff auf diese Klasse
  friend class StdSignalHandler; // IM 112314: directly calls signalHandler

  public:
    // Server port defaults
    static const unsigned short PROXY_DEFAULT_PORT = 5678;
    static const unsigned short DATA_DEFAULT_PORT  = 4897;
    static const unsigned short EVENT_DEFAULT_PORT = 4998;

    static const unsigned short REDU_DEFAULT_PORT  = 4776;
    static const unsigned short DIST_DEFAULT_PORT  = 4777;
    static const unsigned short SPLIT_DEFAULT_PORT = 4778;

     // SNMP, LiveAgent, Pmon port defaults
    static const unsigned short SNMP_DEFAULT_PORT = 4700;
    static const unsigned short LIVE_AGENT_DEFAULT_PORT = 4701;
    static const unsigned short PMON_DEFAULT_PORT = OS_PMON_DEFAULT_PORT; // solaris: 4779 else 4999;

  protected:
    /// active language
    // must be first, because it is used as default parameter in some methods

    static IL_DEPRECATED("deprecated, work with GlobalLanguageIdType and use OaManager::getActiveLangId() instead") LanguageIdType& activeLang;

    // generate mxProxy config entry defaults vom data and event configuration
    static void addMxProxyDefaults();

    // generate mxProxy config entry defaults
    // @param hostList like <host1>[:<port1>][,<host2>[:<port2>]] e.g. secondaryDMConnectString
    // @param proxyPort the server port of the WCCILproxy
    static void addMxProxyDefaults(StringToken &hostList, unsigned short proxyPort);

    // generate mxProxy config entry defaults
    // @param hostName like <host>[:<port>]
    // @parem proxyPort the server port of the WCCILproxy
    static void addMxProxyDefaults(const CharString &hostName, unsigned short proxyPort);

  public:

    // MIB enumeration value for UTF-8 encoding
    enum
    {
      UTF8_MIB_ENUM = 106,
      LATIN1_MIB_ENUM = 4
    };

    /** flags for logging.
        @n These constants are used when -log command is given.
        Since logging is handled internally, this is for information only.
    */
    enum IL_DEPRECATED("deprecated, use DebugOutput") LogFlags
    {
      /// -log +dp
      LOG_DATAPOINT = DebugOutput::LOG_DATAPOINT,
      /// -log +file
      LOG_FILE = DebugOutput::LOG_FILE,
      /// -log +stderr
      LOG_STDERR = DebugOutput::LOG_STDERR
    };

    /** flags for autoReg - kind
    */
    enum AutoRegKind
    {
      NO_AUTO_REG=0,
      AUTO_REG_NORMAL=1,
      AUTO_REG_FORCE=2,
      AUTO_REG_VG=3,     // special for version generation
      PROJ_REG_SUB=4,    // reg notRunnable sub project
      PROJ_REG_SUBF=5,   // reg notRunnable sub project (force)
      PROJ_UNREG=6,
      PROJ_UNREG_DEL=7,
      PVSS_REG=8,
      PVSS_REG_FORCE=9
    };

    /** flags for dbgLevel
        @n These flags can be set by number on cmdline. Numbers can
        be separated by , to get more flags, like -dbg 2,8,15.
        For API purposes there are constants DBG_API_USR1 to DBG_API_USR3,
        for ComDrv there are DBG_DRV_USR1 to DBG_DRV_USR3.
        @classification public use, test
    */
    // If you add a flag here, don't forget to update the List in DebugSettings, too!
    // only add flags never change existing flag numbers, because BCM has a copy of this enum
    enum IL_DEPRECATED("deprecated, use DebugOutput") DbgFlags
    {
      // changes should be protocolled in dispatch as well
      /// (1). no time info will be printed on streams
      DBG_TIMEOFF = DebugOutput::DBG_TIMEOFF,
      /// (2). the general purpose debug flag; used for run info on current manager
      DBG_WORK = DebugOutput::DBG_WORK,
      /// (3). give warning when send buffer is extended
      DBG_EXTBUFFER = DebugOutput::DBG_EXTBUFFER,
      /// (4). check sockets if input is ready
      DBG_INPUTREADY = DebugOutput::DBG_INPUTREADY,
      /// (5). check sockets if output is ready
      DBG_OUTPUTREADY = DebugOutput::DBG_OUTPUTREADY,
      /// (6). SND stamp;
      DBG_SNDSTAMP = DebugOutput::DBG_SNDSTAMP,
      /// (7). BCV stamp
      DBG_RCVSTAMP = DebugOutput::DBG_RCVSTAMP,
      /// (8). debug query actions
      DBG_QUERY = DebugOutput::DBG_QUERY,
      /// (9). show manager heartbeat
      DBG_DISPATCH = DebugOutput::DBG_DISPATCH,
      /// (10). first available API debug flag - use at your will
      DBG_API_USR1 = DebugOutput::DBG_API_USR1,
      /// (11). second available API debug flag - use at your will
      DBG_API_USR2 = DebugOutput::DBG_API_USR2,
      /// (12). third available API debug flag - use at your will
      DBG_API_USR3 = DebugOutput::DBG_API_USR3,
      /// (13). time
      DBG_DM_TIME = DebugOutput::DBG_DM_TIME,
      /// (13). status function
      DBG_EV_STATFUNC = DebugOutput::DBG_EV_STATFUNC,
      /// (14). set temp. slot
      DBG_DM_SETEMPTYSLOT = DebugOutput::DBG_DM_SETEMPTYSLOT,
      /// (15). service mode
      DBG_DM_SERVICEMODE = DebugOutput::DBG_DM_SERVICEMODE,
      /// (16). event work
      DBG_EV_WORK = DebugOutput::DBG_EV_WORK,
      /// (17). event time 100
      DBG_EV_TIME100 = DebugOutput::DBG_EV_TIME100,
      /// (18). source time
      DBG_EV_SOURCETIME = DebugOutput::DBG_EV_SOURCETIME, // XXX remove, wenn Systemzeitbeigabe geklaert ist!!!
      /// (19). event file
      DBG_EV_EVENTFILE = DebugOutput::DBG_EV_EVENTFILE,
      /// (20). alert file
      DBG_EV_ALERTFILE = DebugOutput::DBG_EV_ALERTFILE,
      /// (21). event main
      DBG_EV_EVMAIN = DebugOutput::DBG_EV_EVMAIN,
      /// (22). panel time
      DBG_UI_PANELTIME = DebugOutput::DBG_UI_PANELTIME,
      /// (23). show report manager actions (obsolete)
      DBG_UI_RENT = DebugOutput::DBG_UI_RENT,
      /// (24). common DRV heartbeat - use
      DBG_DRV_WORK = DebugOutput::DBG_DRV_WORK,
      /// (25). first available DRV debug flag - use at your will
      DBG_DRV_USR1 = DebugOutput::DBG_DRV_USR1,
      /// (26). second available API debug flag - use at your will
      DBG_DRV_USR2 = DebugOutput::DBG_DRV_USR2,
      /// (27). third available API debug flag - use at your will
      DBG_DRV_USR3 = DebugOutput::DBG_DRV_USR3,
      /// (28). show redundancy messages
      DBG_REDUNDANCY = DebugOutput::DBG_REDUNDANCY,      // redundancy messages
      /// (28). for people who can't write redundancy
      DBG_REDU = DebugOutput::DBG_REDU,
      /// (29). show ctrl trace
      DBG_CTRL_TRACE = DebugOutput::DBG_CTRL_TRACE,
      /// (30), show every n sec a snd/rcv statistic
      DBG_MSG_STATISTIC = DebugOutput::DBG_MSG_STATISTIC,
      /// (31), extended Warnings
      DBG_EXT_WARNING = DebugOutput::DBG_EXT_WARNING,           // don't modify number BCM relies on it
      /// (32), use of old status
      DBG_STATUS32 = DebugOutput::DBG_STATUS32,
      /// (33), HTTP traffic
      DBG_HTTP = DebugOutput::DBG_HTTP,
      /// (34), BCM
      DBG_BCM = DebugOutput::DBG_BCM,                 // don't modify number BCM relies on it
      /// (35), NFR outputs
      DBG_NFR = DebugOutput::DBG_NFR,                 // don't modify number BCM relies on it
      /// (36), Statistics counter, simple version
      DBG_STAT_SIMPLE = DebugOutput::DBG_STAT_SIMPLE,
      /// (37), Statistics counter, long version
      DBG_STAT_HISTO  = DebugOutput::DBG_STAT_HISTO,
      // Must be last
      DBG_LAST = DebugOutput::DBG_LAST
    };

    /// flags for reportLevel
    /// @n They are set by -report cmdline arg.
    /// 0-11: gelten fuer alle Manager
    /// 12-15: Data-Manager
    /// 16-21: Event-Manager
    /// 22-23: Ui
    /// 24-27: Treiber
    /// 28-31: Ascii-Manager
    enum IL_DEPRECATED("deprecated, use DebugOutput") ReportFlags
    {
      /// (0). report CPU usage
      REP_CPU = DebugOutput::REP_CPU,
      /// (1). report HEAP usage
      REP_HEAP = DebugOutput::REP_HEAP,
      /// (2). report dispatcher state & message queue len
      REP_DISPATCH = DebugOutput::REP_DISPATCH,
      /// (3). report pending query state
      REP_QUERY = DebugOutput::REP_QUERY,    // this flag is used by data & event
      /// (4). call backs
      REP_CALLBACKS = DebugOutput::REP_CALLBACKS,
      /// (5). db type
      REP_DPTYPE = DebugOutput::REP_DPTYPE,
      /// (6). DP identification
      REP_DPIDENTIFICATION = DebugOutput::REP_DPIDENTIFICATION,
      /// (7). config manager
      REP_CONFIGMANAGER = DebugOutput::REP_CONFIGMANAGER,
      /// (8) give overview of scripts, etc. in Controller
      REP_CTRL = DebugOutput::REP_CTRL,
      /// (9). DM action
      REP_DM_ACTION = DebugOutput::REP_DM_ACTION,
      /// (10). DM status
      REP_DM_STATUS = DebugOutput::REP_DM_STATUS,
      /// (11). DM time list
      REP_DM_TIMELIST = DebugOutput::REP_DM_TIMELIST, // 09.05.00 esperrer HDB timelist
      // Must be last
      REP_LAST  = DebugOutput::REP_LAST
    };

    /// attribute flags
    enum AttrFlags
    {
      ATTR_FLAG_TEXT  = 1,
      ATTR_FLAG_VALUE = 2
    };

    /// constructor
    Resources();

    /// idle call function after exception handling
    static void dispatch(void);

    /** the resource init function
        @n The function reads only section [general] from the configfile
        and does every necessary initialization.
        If creating your own Resource class you should overload this function.
        If reading more than the [general] section from the configfile,
        the following code is neccesary:
        @n
        @n Resources::begin(argc, argv);
        @n while (YourResourceClass::readSection() || Resources::generalSection());
        @n Resources::end(argc, argv);
        @n
        @n @warning on Windows: If you debug an api manager, which calls Ressources::init and uses getchar(), then you have to start the manager with -log +stderr.
        Otherwise the manager will crash. This is a bug in Microsoft Kernel and we can't solve this.
        @n
        @param argc number of arguments
        @param argv values of arguments
    */
    static void init(int &argc, char **argv);

    /** the pre-config init function
        @n The function sets progName and manNum and opens the configfile.
        If you have any params in your command line, you should overload this function to read your config section.
        Don't forget to call the base function!
        @param argc number of arguments
        @param argv values of arguments
    */
    static void begin(int &argc, char *argv[]);

    /** checks if we are at given section
        @n The manNum is automatically added.
        @param section the section
    */
    static PVSSboolean isSection(const CharString &section);

    /** reads the [general] section or skips all other sections
        @return true if cfgState != CFG_EOF else false
    */
    static PVSSboolean generalSection();

    /** post-config init functin
        @n The function closes the configfile and interprets the commandline-paramter.
        If you have any params in your command line, you should overload this function to read your config section.
        Don't forget to call the base function!
        @param argc number of arguments
        @param argv values of arguments
    */
    static void end(int &argc, char *argv[]);

    /** reads key words
        @param isGeneral specifies, whether to read in general section or not
        @return PVSS_TRUE if OK, else PVSS_FALSE
      */
    static PVSSboolean readGeneralKeyWords(PVSSboolean isGeneral = PVSS_FALSE);

    /** reads dummy key words
        @n The function ignores (w/o any warning) key words, which are not used in a manager.
        @return PVSS_TRUE if OK, else PVSS_FALSE
      */
    // WOKL 6.6.03 IM 52282
    static PVSSboolean readDummyKeyWords();

#ifdef _WIN32

    /** install standard signal handlers
      */
    static void installStdSignalHandlers();
#endif

    /// opens configfile
    static void openCfg(const char * = 0);

    /// closes configfile
    static void closeCfg();

    /// set all project-bin paths as searchpath for Qt-plugins
    static void setQtPluginPaths();

    /** defines behaviour in case of error
        @n This function specifies whether function exit()
        shell be called in case of error or not.
        @param doExit whether to do call exit() or not
    */
    static void setExitOnError(bool doExit);

    /// get the exitOnError flag
    static bool isExitOnError() { return exitOnError; }

    /// get the program name (i.e. argv[0])
    static const CharString &getProgName();

    /// get the program name and the current time (i.e. myManName ; 1999.02.01 11:11:11.001)
    static CharString getProgNameAndTime();

    /// get the program name formated with the given time (i.e. myManName ; 1999.02.01 11:11:11.001)
    /// @param timeToPrint the time to print
    static CharString getProgNameAndTime(const TimeVar &timeToPrint);

    /// get the program name and the actual config file name
    static const CharString &getProgNameAndConfigFile();

    /// get the ManagerIdentifier
    static const ManagerIdentifier & getManId() {return ownManId;}

    /// get the manager type
    static PVSSuchar  getManType() {return ownManId.getManType();}

    /// set the manager type
    /// @param newType the type to set
    static void setManType(PVSSuchar newType) {ownManId.setManType(newType);}

    /// get the manager number
    static PVSSuchar getManNum() { return ownManId.getManNum(); }

    /// set the manager number
    /// @param newNum the number to set
    static void setManNum(PVSSuchar newNum)  {ownManId.setManNum(newNum);}  //  //

    /// get the manager subtype
    static PVSSuchar getManSubType() {return ownManId.getManSubType();}

    /// set the manager subtype
    /// @param newSubType the SubType to set
    static void setManSubType(PVSSuchar newSubType) {ownManId.setManSubType(newSubType);}

    /// get the extended manager flag
    static  PVSSboolean getExtendedMan() { return ownManId.getExtendedFlag(); }

    /// set the extended manager flag
    static  void  setExtendedMan() { ownManId.setExtendedFlag(); }

    /// get the redundant manager flag
    static  PVSSboolean getRedundantMan() {return ownManId.getRedundantFlag();}

    /// set the redundant manager flag
    static  void setRedundantMan() {ownManId.setRedundantFlag();}

    /// get the system number in the own manager
    static  SystemNumType getSystem() { return ownManId.getSystem(); }

    /// set the system number in the own manager
    /// @param newSys the new system number
    static  void setSystem(SystemNumType newSys) { ownManId.setSystem(newSys); }

    /// get the current system name
    static  const CharString &getSystemName() { return systemName; }

    // TFS 24334 begin
    /// set the flag that tells whether the remote system uses UTF8 encoding or not
    /// this accessor function is necessary, because this flag must be also settable from outside the DistResources class
    /// If we are in dist-client role, this information is configured locally, and set by the DistResources class.
    /// If we are in dist-master role, this information is taken from the incoming SYS_MSG_INIT msg. of the client.
    /// @param sysNum the number of the remote system
    /// @param sysUsesUtf8 whether the remote system uses UTF8 encoding
    static void setRemoteSysUsesUTF8Enc(SystemNumType sysNum, PVSSboolean sysUsesUtf8) { if (sysUsesUtf8) remoteSysUsesUTF8Enc.set(sysNum); else remoteSysUsesUTF8Enc.clear(sysNum); }
    /// get function for the above data
    static PVSSboolean getRemoteSysUsesUTF8Enc(SystemNumType sysNum) { return remoteSysUsesUTF8Enc.get(sysNum); }
    // TFS 24334 end

    /// set the current system name
    /// @param theSystemName the system name
    static  void setSystemName(const CharString &theSystemName) { systemName = theSystemName; }

    /// get the project name set by -proj cmdline arg
    static const CharString &getProjectName() { return projectName_; }

    /// get the config file name set by -config cmdline arg or env PVSS_II
    static const CharString &getConfigFileName() { return configFileName_; }

    /** get the project-key
        @n The project-key is a unique identifier for each project on a host.
        It is used in PmonTable for the creation of a unique SHM key.
        If not defined in the config file, on Linux it returns a pseudo-unique
        key using ftok(), on Windows it returns the pmonPort.
    */
    static int getProjectKey();

    /// get the TCP port, the pmon is listening for commands
    static unsigned short getPmonPort();

    /// get the index into the pmon-table (progs-file)
    /// @n The flag was set by pmon on startup of this manager.
    /// Internal use only!
    static int getPmonIndex() { return pmonIndex; }

    /// get the alive port
    static unsigned short getAlivePort() {return alivePort;}

    /// set the alive port (e.g. if the socket could not be bound to this port)
    /// @param port the port to set
    static void setAlivePort(unsigned short port) {alivePort = port;}

    /// get the alive timeout
    static short getAliveTimeout() {return aliveTimeout;}

    /// set the alive timeout
    /// @param tmo the timeout to set
    static void setAliveTimeout(short tmo) {aliveTimeout = tmo;}

    /// get the priority of the alive thread
    static int  getAliveThreadPriority() {return aliveThreadPriority;}

    /** get a list of objectsv for the actual Structure of the project
        @n Each object describes one necessary file or directory for a PVSS-Project.
      */
    static const DynPtrArray<ProjDirs> &getProjDirs()   { return(pathes_.getProjDirs()); }

    /** get a list of objects for a Project with old Structure
        @n Each object describes one necessary file or directory for a PVSS-Project.
      */
    static const DynPtrArray<ProjDirs> &getProjDirsV1() { return(pathes_.getProjDirsV1()); }

    /** get a list of objects for a Project with the new Structure
        @n Each object describes one necessary file or directory for a PVSS-Project.
      */
    static const DynPtrArray<ProjDirs> &getProjDirsV2() { return(pathes_.getProjDirsV2()); }

    // --------------------- Pathes of PVSS2 ------------------------------------

    /** @name Directory Names
        @n Return the name of the directories including a trailing "/".
        Some functions have an (optional) parameter level. This specifies at which project
        directory given in the config files to look at, ending with the PVSS install dir.
        level == 0: return only the relative subpath, e.g. "panels/"
        level == 1: project path
        level 1..n-1: subproject path
        level n: PVSS path
        Where n = getSearchPathLen()
    */
    //@{
    /// get the number of hierarchies defined with pvss_path and all proj_path in config
    static int getSearchPathLen()                { return pathes_.getSearchPathLen(); }

    /// get the pvss2 dir. returns the path including a trailing "/"
    static CharString getPvssDir(int)           { return pathes_.getPvssDir(); }

    /// get the pvss2 dir. returns the path including a trailing "/"
    static CharString getPvssDir()               { return pathes_.getPvssDir(); }

    /// get the specified part of the SearchPath returns the path including a trailing "/"
    /// @param level the level (see upper)
    static CharString getProjDir(int level)      { return pathes_.getProjDir(level); }

    /// get the pvss2 project dir. returns the path including a trailing "/"
    static CharString getProjDir()               { return pathes_.getProjDir(); }

    // TI 1621 14.04.99 Irena
    /// get the pvss2 project dir. returns the path including a trailing "/"
    /// @param level the level (see upper)
    static CharString getProjDirC(int level)     { return pathes_.getProjDir(level); }

    /// get the pvss2 bin dir. returns the path including a trailing "/"
    static CharString getBinDir()                { return pathes_.getBinDir(); }

    /// get the project bin dir. returns the path including a trailing "/"
    /// @param level the level (see upper)
    static CharString getProjBinDir(int level = 1) { return pathes_.getProjBinDir(level); }

    /// get the project source dir. returns the path including a trailing "/"
    /// @param level the level (see upper)
    static CharString getSourceDir(int level = 1)  { return pathes_.getSourceDir(level); }

    /// get the project help dir. returns the path including a trailing "/"
    /// @param level the level (see upper)
    static CharString getHelpDir(int level = 1)    { return pathes_.getHelpDir(level); }

    /// get the project msg dir. returns the path including a trailing "/"
    /// @param level the level (see upper)
    static CharString getMsgDir(int level = 1)     { return pathes_.getMsgDir(level); }

    /// get the project msg Catalog dir. (project)\msg\actLang\ returns the path including a trailing "/"
    /// @param level the level (see upper)
    static CharString getMsgCatDir(int level = 1);

    /// get the project config dir. returns the path including a trailing "/"
    /// @param level the level (see upper)
    static CharString getConfigDir(int level = 1)  { return pathes_.getConfigDir(level); }

    /// get the project pictures dir. returns the path including a trailing "/"
    /// @param level the level (see upper)
    static CharString getPicturesDir(int level=1)  { return pathes_.getPicturesDir(level); }

    /// get the project printers dir. returns the path including a trailing "/"
    /// @param level the level (see upper)
    static CharString getPrintersDir(int level=1)  { return pathes_.getPrintersDir(level); }

    /// get the project printer dir. returns the path including a trailing "/"
    /// @param level the level (see upper)
    static CharString getPrinterCFDir(int level=1) { return pathes_.getPrintersDir(level); }

    /// get the project colorDB dir. returns the path including a trailing "/"
    /// @param level the level (see upper)
    static CharString getColorDbDir(int level = 1) { return pathes_.getColorDbDir(level); }

    /// get the project panels dir. returns the path including a trailing "/"
    /// @param level the level (see upper)
    static CharString getPanelsDir(int level = 1)  { return pathes_.getPanelsDir(level); }

    /// get the project panel dir. returns the path including a trailing "/"
    /// @param level the level (see upper)
    static CharString getPanelDir(int level = 1)   { return pathes_.getPanelsDir(level); }

    /// get the project images dir. returns the path including a trailing "/"
    /// @param level the level (see upper)
    static CharString getImagesDir(int level = 1)  { return pathes_.getImagesDir(level); }

    /// get the project image dir. returns the path including a trailing "/"
    /// @param level the level (see upper)
    static CharString getImageDir(int level = 1)   { return pathes_.getImagesDir(level); }

    /// get the project scripts dir. returns the path including a trailing "/"
    /// @param level the level (see upper)
    static CharString getScriptsDir(int level = 1) { return pathes_.getScriptsDir(level); }

    /// get the project ctrl lib dir. returns the path including a trailing "/"
    /// @param level the level (see upper)
    static CharString getLibsDir(int level = 1)    { return pathes_.getLibsDir(level); }

    /// get the project data dir. returns the path including a trailing "/"
    /// @param level the level (see upper)
    static CharString getDataDir(int level = 1)    { return pathes_.getDataDir(level); }

    /// get the project db\pvss dir. returns the path including a trailing "/"
    /// @param level the level (see upper)
    static CharString getDbDir(int level = 1)      { return pathes_.getDbDir(level); }

    /// get the project db\lta dir. returns the path including a trailing "/"
    /// @param level the level (see upper)
    static CharString getLtaDir(int level = 1)     { return pathes_.getLtaDir(level); }

    /// get the project log dir. returns the path including a trailing "/"
    /// @param level the level (see upper)
    static CharString getLogDir(int level = 1)     { return pathes_.getLogDir(level); }

    /// get the Project dplist dir. returns the path including a trailing "/"
    /// @param level the level (see upper)
    static CharString getDplistDir(int level = 1)  { return pathes_.getDplistDir(level); }

    /// get the pvss2 nls dir. returns the path including a trailing "/"
    static CharString getNlsDir()                  { return pathes_.getNlsDir(); }

    /// get the project nls dir. returns the path including a trailing "/"<
    /// @param level the level (see upper)
    static CharString getProjNlsDir(int level = 1) { return pathes_.getProjNlsDir(level); }

    /// get the pvss2 text dir. returns the path including a trailing "/"
    static CharString getTextsDir()                { return pathes_.getTextsDir(); }

    /// get the pvss xml dir. returns the path including a trailing "/"
    /// @param level the level (see upper)
    static CharString getXmlDir(int level = 1)     { return pathes_.getXmlDir(level); }

    // --------------------- Pathes of PVSS2 UI ---------------------------------

    /// get the project reports dir. returns the path including a trailing "/"
    /// @param level the level (see upper)
    static CharString getReportDir(int level = 1)  { return pathes_.getReportDir(level); }

    /// get the project pixmaps dir. returns the path including a trailing "/"
    /// @param level the level (see upper)
    static CharString getPixmapsDir(int level = 1) { return pathes_.getPixmapsDir(level); }

    /// get the project icons dir. returns the path including a trailing "/"
    /// @param level the level (see upper)
    static CharString getIconsDir(int level = 1)   { return pathes_.getIconsDir(level); }

    /// get the project gif dir. returns the path including a trailing "/"
    /// @param level the level (see upper)
    static CharString getGifDir(int level = 1)     { return pathes_.getGifDir(level); }

    /// get the pvss printerfonts dir. returns the path including a trailing "/"
    static CharString getPrinterFontDir()       { return pathes_.getPrinterFontDir(); }

    /// get the pvss dbtools dir. returns the path including a trailing "/"
    static CharString getDbtoolsDir()           { return pathes_.getDbtoolsDir(); }

    /// get the pvss dbdfiles dir. returns the path including a trailing "/"
    static CharString getDbdfilesDir()          { return pathes_.getDbdfilesDir(); }

    /// get flag for Independent Acknowledgement. returns true if alarms can be acknowledged in any order
    static PVSSboolean getIndependentAlertAck() { return independentAlertAck_; }


    // --------------------- Files of PVSS2 -------------------------------------

    /// check if this directory has a language specific subdirectories
    static  bool isLanguageDir(CharString (*getPath)(int));

    /// get the pvss2 project log file.
    static  CharString getLogFile()             { return pathes_.getLogFile(); }

    /// get the pvss2 project dbg file.
    static  CharString getDbgFile()             { return pathes_.getDbgFile(); }

    /// get the pvss2 license file.
    static CharString getLicenseFile();

    /// get the mapping file to map license keys to pvss license options.
    static CharString getLicenseMappingFile();

    /// get the error text file name without path
    static CharString getErrTextFileName()      { return pathes_.getErrTextFileName(); }

    /// get the error text file name's path
    static CharString getErrTextDir(int level)  { return pathes_.getErrTextDir(level); }

    /// get the error text file path and name
    static CharString getErrTextFile()          { return OaFileSys::fileExists(getErrTextDir,
                                                  getErrTextFileName()); }
    /// get the manager log file
    static  CharString getManagerLogFile()      { return pathes_.getLogFile(); }
    //@}

    // --------------------- Pathes of PVSS2 ------------------------------------

    /// check if log flag is set
    /// @param logFlag the log flag
    IL_DEPRECATED("deprecated, use DebugOutput instead")
    static PVSSboolean isLogFlag(int logFlag) { return DebugOutput::isLogFlag((DebugOutput::LogFlags)logFlag) ? PVSS_TRUE : PVSS_FALSE; }

    /// check if any log flag is set which determines that log output should be written to stderr.
    IL_DEPRECATED("deprecated, use DebugOutput instead")
    static PVSSboolean isLogFlagCerr() { return DebugOutput::isLogFlagCerr() ? PVSS_TRUE : PVSS_FALSE; }

    /// set log flag
    /// @param logFlag the log flag
    IL_DEPRECATED("deprecated, use DebugOutput instead")
    static void setLogFlag(int logFlag) { DebugOutput::setLogFlag((DebugOutput::LogFlags)logFlag); }

    /// clear log flag
    /// @param logFlag the log flag
    IL_DEPRECATED("deprecated, use DebugOutput instead")
    static void clearLogFlag(int logFlag) { DebugOutput::clearLogFlag((DebugOutput::LogFlags)logFlag); }

    /// get max. log file size
    static PVSSushort getMaxLogFileSize()  {return maxLogFileSize;}

    /// get the project version
    static CharString getProjVersion()   {return projVersion_;   }

    /// get the project version in numerical form (MMmmPPP - Major Minor Patch)
    static PVSSulong getProjVersionNumeric() { return projVersionNumeric_; }

    /// get number of languages of the current project
    IL_DEPRECATED("deprecated, use OaManager::getNumOfProjectLanguages() instead")
    static LanguageIdType getNumOfLangs();

    /** get a string denoting the project language configuration,
        the string contains the pvssLocale names of the languages in ascending order with a delimiter
        @return the language configuration string
    */
    static CharString getLanguageConfiguration();

    typedef enum
    {
      LANG_CFG_STR_TO_UTF8,
      LANG_CFG_STR_TO_ISO,
      LANG_CFG_STR_TO_INVARIANT           // to remove encoding substrings from lang. config string
    } LANG_CFG_STR_TRANSFORM_t;

    /// modifies the codepage names in the lang config string
    /// @param langCfgStr the original language config string, eg.: "de_AT.utf8,en_US.utf8,ru_RU.utf8"
    /// @param todo what do we want to do with the langCfgStr
    /// @param enc while we are at it, we extract the original encoding from langCfgStr, and return it in *enc, if enc is not 0
    ///            The *enc's value matches numerically the itcNDR::NDR_character enum.
    /// @return a modified copy of langCfgStr, either with modified encoding, or without the encoding substrings, eg.: "de_AT,en_US,ru_RU"
    static CharString transformLangCfgStrEncoding(const CharString &langCfgStr, Resources::LANG_CFG_STR_TRANSFORM_t todo, PVSSuchar *enc = 0);

    /** get the index of the active lang (_not_ PVSS language id ! ) in current project
        @n For use in getLangDefRec(), langIdxToId().
        @return index to internal table of project languages
        @see getLangDefRec(LanguageIdType idx)
        @see langIdxToId(LanguageIdType idx, GlobalLanguageIdType &idRef)
      */
    IL_DEPRECATED("deprecated, prefer working with GlobalLanguageIdType, rework code to use OaManager::getActiveLangId() instead")
    static LanguageIdType getActiveLang();

    /** returns the index of the param lang (_not_ PVSS language id ! ) in current project
        @return index to internal table of project languages
        @see getActiveLang()
        */
    IL_DEPRECATED("obsolete, param language shall not be used anymore")
    static LanguageIdType getParamLang() { return paramLang; }

    /** returns the index of the meta lang (_not_ PVSS language id ! ) in current project
        @return index to internal table of project languages
        @see getActiveLang()
      */
    IL_DEPRECATED("obsolete, meta language shall not be used anymore")
    static LanguageIdType getMetaLang() { return metaLang; }


    /** returns list of ids of configured offline languages in current project.
        Offline languages can be used to replace project languages in case of no connection to system
        @return list of offline languages
    */
    IL_DEPRECATED("deprecated, use OaManager::getAllProjectLanguageIds() instead")
    static std::vector<GlobalLanguageIdType> getProjectLangIds();

    /// set the number of languages from the database
    /// @param n the number of languages
    // Temporary  - remove when this will be read from the config file
    // (and update other references too - MapTableItem.hxx is the primary place).
    IL_DEPRECATED("obsolete, do not use anymore")
    static void setNumOfLangs(LanguageIdType n) { numOfLangs = n; }

    /// Try to find a locale that matches the user's system locale
    static CharString findUserLocale();

    /// convert from language index to id
    IL_DEPRECATED("deprecated, prefer working with GlobalLanguageIdType, rework code to use functions of OaLocale and OaManager instead")
    static PVSSboolean langIdToIdx(GlobalLanguageIdType id, LanguageIdType &idxRef);

    /// convert language index to language ID
    /// @param idx the language index
    /// @param idRef the language ID
    /// @return true if success
    IL_DEPRECATED("deprecated, prefer working with GlobalLanguageIdType, rework code to use functions of OaLocale and OaManager instead")
    static PVSSboolean langIdxToId(LanguageIdType idx, GlobalLanguageIdType &idRef);

    /// convert language index to PvssLocale
    /// @param idx the language index
    /// @param pvssLocale the pvssLocale
    /// @return true if success
    IL_DEPRECATED("deprecated, prefer working with GlobalLanguageIdType, rework code to use OaLocale::getLangName() instead")
    static PVSSboolean languageIdTypeToPvssLocale(LanguageIdType idx, CharString &pvssLocale);

    /// convert global language id to PvssLocale
    /// @param id the global language index
    /// @param pvssLocale the pvssLocale
    /// @return true if success
    IL_DEPRECATED("deprecated, use OaLocale::getLangName() instead")
    static PVSSboolean languageIdTypeToPvssLocale(GlobalLanguageIdType id, CharString &pvssLocale);

    /// convert language index to platformLocale
    /// @param idx the language index
    /// @param platformLocale the platformLocale
    /// @return true if success
    IL_DEPRECATED("deprecated, prefer working with GlobalLanguageIdType, rework code to use OaLocale::getOsLocale() instead")
    static PVSSboolean languageIdTypeToPlatformLocale(LanguageIdType idx, CharString &platformLocale);

    /// convert global language id to platformLocale
    /// @param id the global language index
    /// @param platformLocale the platformLocale
    /// @return true if success
    IL_DEPRECATED("deprecated, use OaLocale::getOsLocale() instead")
    static PVSSboolean languageIdTypeToPlatformLocale(GlobalLanguageIdType id, CharString &platformLocale);

    /// get the record of language table
    /// @param idx the language index
    IL_DEPRECATED("deprecated, prefer working with GlobalLanguageIdType, rework code to use functions of OaLocale instead")
    static const LanguageDefRec *getLangDefRec(LanguageIdType idx);

    /// get the matching record of language table entry, with alternate encoding
    /// eg. if the locale of languageDefTable[0] is "de_AT.utf8", then the locale of remoteLangDefTable[0] is "de_AT.iso88591" and vice versa
    /// @param idx the language index
    static const LanguageDefRec *getAltLangDefRec(LanguageIdType idx);

    /// get number of all available languages for current PVSS2 version
    IL_DEPRECATED("obsolete, use size of OaLocale::getAllLanguageIds() instead")
    static LanguageIdType getNumOfGlobLangs()
	{
      return static_cast<LanguageIdType>(OaLocale::getAllLanguageIds().size());
    }

    /// get the record of global language table by global language ID
    /// @param langId the global language ID
    IL_DEPRECATED("deprecated, prefer working with GlobalLanguageIdType, rework code to use functions of class OaLocale instead")
    static const LanguageDefRec *getGlobLangDefRec(GlobalLanguageIdType langId);

    /// get the record of global language table by global language string
    /// @param langString the global language string, e.g. de_AT.utf8
    IL_DEPRECATED("deprecated, prefer working with GlobalLanguageIdType, rework code to use function OaLocale::getIdByHmiLocale() instead")
    static const LanguageDefRec *getGlobLangDefRec(const CharString &langString);

    /// get the record of global language table by the starting part of global language string and
    /// whether the locale uses UTF8 encoding or not
    /// @param partialLangString the starting substring of the global language string, e.g. de_AT
    /// @param isUTF8 if the locale uses UTF8 encoding or not
    IL_DEPRECATED("deprecated, prefer working with GlobalLanguageIdType, rework code to use function OaLocale::getIdByHmiLocale() instead")
    static const LanguageDefRec * getGlobLangDefRec(const CharString &partialLangString, PVSSboolean isUTF8); // TFS 24334

    /** get the record of global language table by index
        @n The function can be used as iterator function starting from idx=0, until function returns null pointer.
        @param idx the relative position in the internal table of available PVSS2 languages
        @return null, if invalid idx
      */
    IL_DEPRECATED("deprecated, prefer working with GlobalLanguageIdType, rework code to use functions of class OaLocale instead")
    static const LanguageDefRec *getGlobalLangDefRecByIdx(int idx);

    /// get the array of language records
    IL_DEPRECATED("deprecated, prefer working with GlobalLanguageIdType, rework code to use OaManager::getActiveLangId() and functions of class OaLocale instead")
    static DynPtrArray<LanguageDefRec> &getLanguageSearchPath();

    /// set locale according to language table
    /// @param idx the language index
    IL_DEPRECATED("deprecated, prefer working with GlobalLanguageIdType, rework code to use OaLocale::setAppLocale() instead")
    static PVSSboolean setLocale(LanguageIdType idx);

    /// set locale according to language table
    /// @param cat the language
    /// @param idx the language index
    IL_DEPRECATED("deprecated, prefer working with GlobalLanguageIdType, rework code to use OaLocale::setAppLocale() instead")
    static PVSSboolean setLocale(int cat, LanguageIdType idx);

    /// set locale according to language table
    /// @param name the language name
    IL_DEPRECATED("deprecated, use OaLocale::setAppLocale() instead")
    static PVSSboolean setLocale(const CharString &name);

    /// save current locale to internal memory
    IL_DEPRECATED("deprecated, use OaLocale::saveAppLocale() instead")
    static void saveLocale() { OaLocale::saveAppLocale(); }

    /// save current locale to supplied string
    /// @n The locale saved into string by saveLocale()is nonportable - use for subsequent restoreLocale() only!
    /// @param cat the cat
    /// @param csRef the supplied string
    IL_DEPRECATED("deprecated, use OaLocale::saveAppLocale() instead")
    static void saveLocale(int cat, CharString &csRef);

    /// restore current locale from internal memory
    IL_DEPRECATED("deprecated, use OaLocale::restoreAppLocale() instead")
    static void restoreLocale() { OaLocale::restoreAppLocale(); }

    /// restore current locale from supplied string
    /// @param cat the cat
    /// @param cs the supplied string
    IL_DEPRECATED("deprecated, use OaLocale::restoreAppLocale() instead")
    static void restoreLocale(int cat, const CharString &cs);

    /// get event manager host name
    static const CharString &getEventHost() { return eventHost; }

    /// get event manager port number
    static unsigned short getEventPort()    { return eventPort; }

    /// get data manager host name
    static const CharString &getDataHost() { return dataHost; }

    /// get data manager port number
    static unsigned short getDataPort()    { return dataPort; }

#ifndef NO_NGA
    // should the next gen archiver be used for archiving or stick to RDB and ValArch
    static PVSSboolean useNGA() { return useNga; }
    static PVSSboolean useNGADirectRead() { return useNGA() && useNgaDirectRead;}
    static void setUseNGADirectRead(PVSSboolean newState) { useNgaDirectRead = newState; }
#endif

    /// get the local IP address for servers (the IP address listen on)
    static const CharString & getLocalAddress() {return localAddress;}

    /// get the IP address of localhost.
    /// This is configured in the hosts file and has to be 127.0.0.1 (IPv4) or ::1 (IPv6)
    static const CharString & getLocalhostIPAddr() {return localhostIPAddr;}

    /// check if atomic DP set is used
    static PVSSboolean useAtomicDpSet() { return atomicDpSet; }

    /// check if parallel ctrl ADO is used
    static PVSSboolean useParallelCtrlADO() { return parallelCtrlADO; }

    /// check if ctrl ADO bool format is used
    static PVSSboolean hasCtrlAdoMSBoolFormat() { return ctrlAdoMSBoolFormat; }

    /// get ctrl ADO numerical precision
    static const CharString &getCtrlAdoNumericalPrecision() { return ctrlAdoNumericalPrecision; }

    // HistoryDB esperrer 10.12.1999
    /// check if value archive is used.
    static PVSSboolean useValueArchive() { return valArch; }

    /// check if value archive is compressed
    static PVSSboolean compressValueArchive() { return compressArch; }

    // RDB Archive thbw 30.8.2003
    /// check if RDB archive is used.
    static PVSSboolean useRDBArchive() { return rdbArch; }

    //default-archive, when HDB and RDB in parallel use
    static int getDefaultArchive() { return defaultArchive; }

    /// check if query RDB direct is used.
    static PVSSboolean useQueryRDBDirect() { return queryRDBdirect && rdbArch; }

    // IM 58856, 27.07.2005 rputz: Added for APM
    /// get APM connection string
    static CharString getAPMConnString() { return APMConnString_; }

    // 09.08.04 esperrer RDB-Manager: Erkennung, ob BLE-RDB-Manager
    // 24.08.05 esperrer IM69115: wenn kein RDBArchive dann auch keine RDBGroups
    /// check if RDB groups are used.
    static PVSSboolean useRDBGroups() { return (useRDBArchive()) ? rdbGroups : PVSS_FALSE; }

    // 20.10.17 esperrer TFS 23329: use UTF8 with RAIMA DB in ISO
    static PVSSboolean useDBAsIso() { return dbAsIso; }

    /// get connection string
    static unsigned int getConnectRetries() { return connectRetries; }

    /// get connection delay
    static unsigned int getConnectDelay() { return connectDelay; }

    /// get exit delay
    static unsigned int getExitDelay() { return exitDelay; }

    /// get the msg receive debug level
    IL_DEPRECATED("deprecated, use DebugOutput instead")
    static int getRcvLevel() { return DebugOutput::getRcvLevel(); }

    /// get the msg send debug level
    IL_DEPRECATED("deprecated, use DebugOutput instead")
    static int getSndLevel() { return DebugOutput::getSndLevel(); }

    /// set the msg receive debug level
    /// @return the previous level
    IL_DEPRECATED("deprecated, use DebugOutput instead")
    static int setRcvLevel(int _level) { return DebugOutput::setRcvLevel(_level); }

    /// set the msg send debug level
    /// @return the previous level
    IL_DEPRECATED("deprecated, use DebugOutput instead")
    static int setSndLevel(int _level) { return DebugOutput::setSndLevel(_level); }

    /// register debug flag with optional description
    /// @param dbgName the debug name
    /// @param description the description
    /// @return the debug flag
    IL_DEPRECATED("deprecated, use DebugOutput instead")
    static PVSSshort registerDbgFlag(const CharString &dbgName, const char *description = 0)
    { return DebugOutput::registerDbgFlag(dbgName, description); }

    /// get debug level
    IL_DEPRECATED("obsolete, don't use")
    static unsigned long getDbgLevel();

    /// check if given debug flag is set
    /// @param dbgFlag the debug flag
    IL_DEPRECATED("deprecated, use DebugOutput instead")
    static PVSSboolean isDbgFlag(PVSSshort dbgFlag) { return DebugOutput::isDbgFlag(dbgFlag) ? PVSS_TRUE : PVSS_FALSE; }

    /// check if given debug flag is set and ouput should go to cerr
    /// @param dbgFlag the debug flag
    IL_DEPRECATED("deprecated, use DebugOutput instead")
    static PVSSboolean isDbgFlagCerr(PVSSshort dbgFlag) { return DebugOutput::isLogToStderr() && DebugOutput::isDbgFlag(dbgFlag); }

    /// check if given debug flag is set
    /// @param dbgName the debug name
    IL_DEPRECATED("deprecated, use DebugOutput instead")
    static PVSSboolean isDbgFlag(const CharString &dbgName) { return DebugOutput::isDbgFlag(DebugOutput::getDbgFlagId(dbgName)) ? PVSS_TRUE : PVSS_FALSE; }

    /// get name of the given debug flag
    /// @param dbgFlag the debug flag
    IL_DEPRECATED("deprecated, use DebugOutput instead")
    static CharString getDbgFlagName(PVSSshort dbgFlag) { return DebugOutput::getDbgFlagName(dbgFlag); }

    /// get name of the given debug flag
    /// @param dbgName the debug name
    IL_DEPRECATED("deprecated, use DebugOutput instead")
    static CharString getDbgFlagName(const CharString &dbgName) { return DebugOutput::getDbgFlagName(DebugOutput::registerDbgFlag(dbgName)); }

    /// set given debug flag
    /// @param dbgFlag the debug flag
    /// @param state the state to set
    /// @return old state of the flag
    IL_DEPRECATED("deprecated, use DebugOutput instead")
    static PVSSboolean setDbgFlag(PVSSshort dbgFlag, PVSSboolean state=PVSS_TRUE) { return DebugOutput::setDbgFlag(dbgFlag, state == PVSS_TRUE) ? PVSS_TRUE : PVSS_FALSE; }

    /// set given debug flag
    /// @param dbgName the debug name
    /// @param state the state to set
    /// @return old state of the flag
    IL_DEPRECATED("deprecated, use DebugOutput instead")
    static PVSSboolean setDbgFlag(const CharString &dbgName, PVSSboolean state=PVSS_TRUE) { return DebugOutput::setDbgFlag(dbgName, state == PVSS_TRUE) ? PVSS_TRUE : PVSS_FALSE; }

    /// set a list of debug flags as given on the commandline
    /// @param dbgList the list of flags, e.g. "1,2,3" which is the equivalent to the commandline "-dbg 1,2,3"
    IL_DEPRECATED("deprecated, use DebugOutput instead")
    static void setDbgFlagList(const CharString &dbgList) { DebugOutput::setDbgFlagList(dbgList); }

    /// get debug counter for performance tests
    /// @n Internal Use only!
    static PVSSushort getDbgCount() { return dbgCount; }

    /// get debug offset for performance tests
    /// @n Internal Use only!
    static PVSSushort getDbgOffset() { return dbgOffset; }

    /// get if manager started with -help
    static PVSSboolean getHelpFlag() { return helpFlag; }

    // TI 2342
    /// get help debug flag
    static PVSSboolean getHelpDbgFlag() { return helpDbgFlag; }

    /// get help report flag
    static PVSSboolean getHelpReportFlag() {return helpReportFlag;}

    /// get last value save on or off ( 1 - 8, 0 )
    /// @n 0 means you can not turn off last value.
    static int getSaveLastValueBit() { return saveLastValueBit_; }

    /// print basic help
    /// @n This function is called from printHelp.
    static void printBasicHelp();

    /// print out the general available command-line parameters
    /// @n When you derive your own resource class, you should overload this function to print out your own new features.
    /// Don't forget to call the base function!
    static void printHelp();

    // TI 2342
    /// print out the used debug flags and their meaning
    static void printHelpDbg();

    /// print out the used report flags
    static void printHelpReport();

    /// check if report is pending
    IL_DEPRECATED("deprecated, use DebugOutput instead")
    static PVSSboolean isReportPending() { return DebugOutput::isReportPending() ? PVSS_TRUE : PVSS_FALSE; }

    /// clear report pending flag
    IL_DEPRECATED("deprecated, use DebugOutput instead")
    static void clearReportPending() { DebugOutput::clearReportPending(); }

    /// register report flag with optional description
    /// @param repName the report name
    /// @param description the description
    /// @return report level
    IL_DEPRECATED("deprecated, use DebugOutput instead")
      static PVSSshort registerReportFlag(const CharString &repName, const char *description = 0) { return DebugOutput::registerReportFlag(repName, description); }

    /// check if report flag is set
    /// @param flag the report flag
    IL_DEPRECATED("deprecated, use DebugOutput instead")
    static PVSSboolean isReportFlag(PVSSshort flag) { return DebugOutput::isReportFlag(flag); }

    /// chcek if report flag is set
    /// @param repName the report name
    IL_DEPRECATED("deprecated, use DebugOutput instead")
    static PVSSboolean isReportFlag(const CharString &repName) { return DebugOutput::isReportFlag(DebugOutput::getReportFlagId(repName)); }

    /// set report flag
    /// @param repName the report name
    /// @param on the value to set
    IL_DEPRECATED("deprecated, use DebugOutput instead")
    static void setReportFlag(const CharString &repName, PVSSboolean on) { DebugOutput::setReportFlag(repName, on == PVSS_TRUE); }

    /// get report level
    IL_DEPRECATED("obsolete, don't use")
    static unsigned long  getReportLevel();

    /// get report stream
    static CharString getReportStream();

    /// set report stream
    /// @param fileName the file name
    static void setReportStream(const CharString &fileName) {reportStream = fileName;}

    /// get coverage report stream
    static CharString getCoverageReportStream();

    /// set coverage report stream
    /// @param fileName the file name
    static void setCoverageReportStream(const CharString &fileName) {coverageReportStream = fileName;}

    /// get dump coverage on exit
    static bool getDumpCoverageOnExit() {return dumpCoverageOnExit;}

    /// get allocate options
    static const CharString &getAllocOptions() { return allocOptions; }

    /// get redundancy level
    static int getRedundancyLevel() { return 0; }

    /// get redundancy replica
    static int getReplica() { return ownManId.getReplica(); }

    /// get replica number (deprecated for compatibility reasons (calls getReplica() ))
    /// please use getReplica!
    IL_DEPRECATED("obsolete, use getReplica()")
    static int   getReplicaNr()    {return getReplica();}

    /// set replica number (obsolete)
    IL_DEPRECATED("obsolete, don't use")
    static void  setReplicaNr(int) {}

    /// get user name
    static const CharString & getUserName() { return userName; }

    /// get password
    static const CharString & getPassword() { return password; }

    /// get ctrl max time
    static double getCtrlMaxTime() { return ctrlMaxTime; }

    /// get ctrl min time
    static double getCtrlMinTime() { return ctrlMinTime; }

    /// get ctrl max weight
    static PVSSlong getCtrlMaxWeight() { return ctrlMaxWeight; }

    /// get ctrl max pendings
    static PVSSlong getCtrlMaxPendings() { return ctrlMaxPendings; }

    /// get ctrl max blockedpendings
    static PVSSlong getCtrlMaxBlockedPendings() { return ctrlMaxBlockedPendings; }

    /// get query HL blocked time
    static PVSSshort getQueryHLBlockedTime() { return queryHLBlockedTime; }

    /// set query HL blocked time
    /// @param blockedTime the time to set
    static void setQueryHLBlockedTime(PVSSshort blockedTime) { queryHLBlockedTime = blockedTime; }

    /// get ctrl break function call
    static PVSSboolean getCtrlBreakFunctionCall() {return ctrlBreakFunctionCall;}

    /// get table util max weight
    static PVSSlong getTabUtilMaxWeight() { return tabUtilMaxWeight; }

    /// get max number of DP names
    static PVSSlong getMaxDpNames()    { return maxDpNames; }

    /// get as one row alert
    static PVSSlong get_asOneRowAlert() { return as_OneRowAlert; }

    /// get as show milliseconds
    static PVSSlong get_asShowMilliseconds() { return as_ShowMilliseconds; }

    /// get as special went text
    static PVSSlong get_asSpecialWentText() { return as_SpecialWentText; }

    /// get as went text delimiter
    static const CharString & get_asWentTextDelimiter() { return as_WentTextDelimiter; }

    // TI 637 17.03.99 Irena
    /// get ignore debug flag
    static  PVSSboolean getIgnoreDebug() { return ignoreDebug; }

    // TI 563 02.04.99 Irena
    /// get DP comment separator
    static  CharString getDpCommentSeparator() { return dpCommentSeparator; }

    /// get lowest auto manager number
    static  PVSSuchar getLowestAutoManNum() {return lowestAutoManNum;}

    /// get lowest auto manager number UI
    static  PVSSuchar getLowestAutoManNumUI() {return lowestAutoManNumUI;}

    /// get version
    static const CharString getVersion();

    /// get version for display
    static const CharString getVersionDisp();

    /// get version patch level
    static unsigned int getVersionPatch();

    /// check if translate
    IL_DEPRECATED("obsolete, please use translator tool instead")
    static PVSSboolean isTranslate();

    /// translate
    /// @param in the input text to translate
    /// @param out the output text to translate
    /// @param langIdx the language index
    /// @return true if OK
    IL_DEPRECATED("obsolete, please use translator tool instead")
    static PVSSboolean translate( const CharString &in, CharString &out, LanguageIdType langIdx );

    /// read from Dictionary-File
    /// @param dictFile the dictionary file name
    /// @return true if OK
    IL_DEPRECATED("obsolete, please use translator tool instead")
    static PVSSboolean readDictionary(const CharString &dictFile);

    /// write to Dictionary-File
    /// @param dictFile the dictionary file name
    /// @return true if OK
    IL_DEPRECATED("obsolete, please use translator tool instead")
    static PVSSboolean writeDictionary(const CharString &dictFile);

    /// get language dictionary
    /// @param langs the languages
    /// @param dict the dictionary
    /// @return true if OK
    IL_DEPRECATED("obsolete, please use translator tool instead()")
    static PVSSboolean getDictionary(const DynVar &langs, DynVar &dict);

    /// merge the languages from dictionary to the table
    /// @param langs the languages
    /// @param dict the dictionary
    /// @return true if OK
    IL_DEPRECATED("obsolete, please use translator tool instead()")
    static PVSSboolean mergeDictionary(const DynVar &langs, DynVar &dict);

    /// get translate delimiter
    IL_DEPRECATED("obsolete, please use translator tool instead()")
    static char  getTranslateDelimiter()    {return translateDelimiter;}

    /// get dictionary name
    IL_DEPRECATED("obsolete, please use translator tool instead()")
    static const CharString & getDictionaryName() {return translateDictionary;}

    /// get CTRL DLLs
    static const DynVar *getCtrlDLLs() { return(&ctrlDLLs_); }

    /// check if project path CTRL extensions are disallowed
    static bool noUserCtrlExt() { return noUserCtrlExt_; }

    /// check if a hotlink from this manager shall be ignored
    static PVSSboolean isIgnoredManager(const ManagerIdentifier &manId);

    /// check if a debug print of a message from this manager shall be printed
    static PVSSboolean checkPrintRecvMessage(const ManagerIdentifier &manId);

    /// check if a debug print of a message of this type shall be printed
    static PVSSboolean checkPrintRecvMessage(const char *);

    /// check if a debug print of a message to this manager shall be printed
    static PVSSboolean checkPrintSendMessage(const ManagerIdentifier &manId);

    /// check if a debug print of a message of this type shall be printed
    static PVSSboolean checkPrintSendMessage(const char *);

    /** get a list of all matching languages
        @n This list tells you in what order you have to search through the language subdirectories
        of msg and help. The list contains at least two entries (US English and Austrian German).
        @param res the result
        @param searchedLang the ID of the language you are looking for
        @return true if OK
    */
    IL_DEPRECATED("deprecated, use OaLocale::getAllFallbackLangs() instead")
    static PVSSboolean getAllMatchingLangs(DynPtrArray<CharString> &res,
                                           GlobalLanguageIdType searchedLang);

    /** get a list of all matching languages fo the current active language
        @n This list tells you in what order you have to search through the language subdirectories
        of msg and help. The list contains at least two entries (US English and Austrian German).
        @param res the result
        @return true if OK
    */
    IL_DEPRECATED("deprecated, rework code to use OaLocale::getAllFallbackLangs() instead")
    static PVSSboolean getAllMatchingLangs(DynPtrArray<CharString> &res);

    /** get a list of all matching languages for the given language
    @n This list tells you in what order you have to search through the language subdirectories
    of msg and help. The list contains at least two entries (US English and Austrian German).
    @param res the result
    @param searchedLang the index of the language you are looking for
    @return true if OK
    */
    IL_DEPRECATED("deprecated, prefer working with GlobalLanguageIdType, rework code to use OaLocale::getAllFallbackLangs() instead")
    static PVSSboolean getAllMatchingLangs(DynPtrArray<CharString> &res,
                                           LanguageIdType searchedLang);


    /** get a list of all matching languages
        @n This list tells you in what order you have to search through the language subdirectories
        of msg and help. The list contains at least two entries (US English and Austrian German).
        @param res the result
        @param searchedLang the PVSS locale string of the language you are looking for
        @return true if OK
      */
    IL_DEPRECATED("deprecated, rework code to use OaLocale::getAllFallbackLangs() instead")
    static PVSSboolean getAllMatchingLangs(DynPtrArray<CharString> &res,
                                           const CharString &searchedLang);

    /** get a list of all matching languages
        @n This list tells you in what order you have to search through the language subdirectories
        of msg and help. The list contains at least two entries (US English and Austrian German).
        @param res the result
        @param lang the ID of the global language you are looking for
        @return true if OK
      */
    IL_DEPRECATED("deprecated, rework code to use OaLocale::getAllFallbackLangs() instead")
    static PVSSboolean getAllMatchingLangs(const DynPtrArray<GlobalLanguageIdType> *&res,
                                           GlobalLanguageIdType lang);

    /// get encoding for the current active language
    /// @param idx the ID of the language
    /// @return encoding or empty string in error case
    IL_DEPRECATED("deprecated, use OaLocale::getEncoding() instead")
    static CharString getEncoding();

    /// get encoding for given language
    /// @param idx the ID of the language
    /// @return encoding or empty string in error case
    IL_DEPRECATED("deprecated, prefer working with GlobalLanguageIdType, rework code to use OaLocale::getEncoding() instead")
    static CharString getEncoding(LanguageIdType idx);

    /// get MIB enum for active language
    /// @param idx the ID of the language
    /// @return MIB enum or -1 in error case
    IL_DEPRECATED("deprecated, use OaLocale::getMibEnum() instead")
    static int getMibEnum();

    /// get MIB enum for given language
    /// @param idx the ID of the language
    /// @return MIB enum or -1 in error case
    IL_DEPRECATED("deprecated, prefer working with GlobalLanguageIdType, rework code to use OaLocale::getMibEnum() instead")
    static int getMibEnum(LanguageIdType idx);

    /// Defines whether the internal encoding is UTF-8
    /// default before initialization of language tables is UTF-8
    IL_DEPRECATED("deprecated, use OaLocale::isUtf8Encoding() instead")
    static PVSSboolean isUtf8Encoding();

    /// Defines whether the internal encoding is UTF-8
    /// default before initialization of language tables is UTF-8
    /// @param idx the ID of the language
    IL_DEPRECATED("deprecated, prefer working with GlobalLanguageIdType, rework code to use OaLocale::isUtf8Encoding() instead")
    static PVSSboolean isUtf8Encoding(LanguageIdType idx);

    /// get encoding for given global language
    /// @param id the ID of the global language
    /// @return encoding or empty string in error case
    IL_DEPRECATED("deprecated, use OaLocale::getEncoding() instead")
    static CharString getEncoding(GlobalLanguageIdType id);

    /// get MIB enum for given language
    /// @param id the ID of the global language
    /// @return MIB enum or -1 in error case
    IL_DEPRECATED("deprecated, use OaLocale::getMibEnum() instead")
    static int getMibEnum(GlobalLanguageIdType id);

    /// Defines whether the internal encoding is UTF-8
    /// @param id the ID of the global language
    IL_DEPRECATED("deprecated, use OaLocale::isUtf8Encoding() instead")
    static PVSSboolean isUtf8Encoding(GlobalLanguageIdType id);

    /// Determine whether the encoding of the active language makes it possible to traverse a string bytewise
    /// to determine ASCII characters (0-127). In case of a SBCS (single byte character set), the result is true.
    /// In case of a MBCS (multibyte character set), it depends on the kind of encoding. Some encodings guarantee
    /// that all bytes within a multibyte sequence differ from ASCII characters, in some encodings, one cannot
    /// know from a single byte whether it is meant as an ASCII character or it is part of a multibyte sequence.
    /// This function examines only encodings (identified by MIB-enums) currently used in WinCC OA.
    ///
    ///   @param mibEnum The language to examine, see Resources::getMibEnum().
    ///   @return PVSS_TRUE if the encoding allows bytewise traversion to detect ASCII characters.
    ///           PVSS_FALSE, otherwise (also in case of unknown encoding)
    ///
    IL_DEPRECATED("deprecated, use OaLocale::mibCanDetectAsciiBytewise() instead")
    static PVSSboolean mibCanDetectAsciiBytewise();

    /// Determine whether the encoding of the given language makes it possible to traverse a string bytewise
    /// to determine ASCII characters (0-127). In case of a SBCS (single byte character set), the result is true.
    /// In case of a MBCS (multibyte character set), it depends on the kind of encoding. Some encodings guarantee
    /// that all bytes within a multibyte sequence differ from ASCII characters, in some encodings, one cannot
    /// know from a single byte whether it is meant as an ASCII character or it is part of a multibyte sequence.
    /// This function examines only encodings (identified by MIB-enums) currently used in WinCC OA.
    ///
    ///   @param mibEnum The language to examine, see Resources::getMibEnum().
    ///   @return PVSS_TRUE if the encoding allows bytewise traversion to detect ASCII characters.
    ///           PVSS_FALSE, otherwise (also in case of unknown encoding)
    ///
    IL_DEPRECATED("deprecated, use OaLocale::mibCanDetectAsciiBytewise() instead")
    static PVSSboolean mibCanDetectAsciiBytewise(int mibEnum);

    /// append an independent language
    /// @n This is for the DataTools - don't use it unless you are sure
    /// what you are doing. This needs to be called before init.
    /// @param iLang the language
    IL_DEPRECATED("obsolete, do not use anymore")
    static void appendIndependentLanguage(const CharString &iLang) { indepLang = iLang; }

    /// get performance flag
    static PVSSboolean getPerfFlag() { return perfFlag; }

    /// get default data port
    static unsigned short getDefaultDataPort()  { return defaultDataPort; }

    /// get default event port
    static unsigned short getDefaultEventPort() { return defaultEventPort; }

    /// get data connect string
    static const CharString & getDataConnectString()  { return dataConnectString; }

    /// get event connect string
    static const CharString & getEventConnectString()  { return eventConnectString; }

    /// get primary DM connect string
    static const CharString & getPrimaryDMConnectString()   { return primaryDMConnectString; }

    /// get secondary DM connect string
    static const CharString & getSecondaryDMConnectString() { return secondaryDMConnectString; }

    /// get primary EM connect string
    static const CharString & getPrimaryEMConnectString()   { return primaryEMConnectString; }

    /// get secondary EM connect string
    static const CharString & getSecondaryEMConnectString() { return secondaryEMConnectString; }

    /// get primary DM host
    static const CharString &getPrimaryDMHost() { return primaryDMHost; }

    /// get secondary DM host
    static const CharString &getSecondaryDMHost() { return secondaryDMHost; }

    /// get primary EM host
    static const CharString &getPrimaryEMHost() { return primaryEMHost; }

    /// get secondary EM host
    static const CharString &getSecondaryEMHost() { return secondaryEMHost; }

    // 01.03.04 esperrer IM59466: return "real" hostname (without _1, _2)
    /// get any host name
    static const CharString getAnyHostName(const CharString &(*getFunc)());

    /// get primary DM host name
    static const CharString getPrimaryDMHostName() { return Resources::getAnyHostName(Resources::getPrimaryDMHost); }

    /// get secondary DM host name
    static const CharString getSecondaryDMHostName() { return Resources::getAnyHostName(Resources::getSecondaryDMHost); }

    /// get data host name
    static const CharString getDataHostName() { return Resources::getAnyHostName(Resources::getDataHost); }

    /// get primary EM host name
    static const CharString getPrimaryEMHostName() { return Resources::getAnyHostName(Resources::getPrimaryEMHost); }

    /// get secondary EM host name
    static const CharString getSecondaryEMHostName() { return Resources::getAnyHostName(Resources::getSecondaryEMHost); }

    /// get event host name
    static const CharString getEventHostName() { return Resources::getAnyHostName(Resources::getEventHost); }

    /// get primary DM port
    static unsigned short getPrimaryDMPort()      { return primaryDMPort; }

    /// get secondary DM port
    static unsigned short getSecondaryDMPort()    { return secondaryDMPort; }

    /// get primary EM port
    static unsigned short getPrimaryEMPort()      { return primaryEMPort; }

    /// get secondary EM port
    static unsigned short getSecondaryEMPort()    { return secondaryEMPort; }

    /// merge port into connect string, where no port is explicitly specified
    /// @param connStr the connect string
    /// @param port the port to merge
    /// @return the merge result
    static CharString mergePort(const CharString &connStr, unsigned short port);

    /// change or merge port in connect string
    /// @param connStr the connect string
    /// @param port the port to change
    /// @return the merge result
    static CharString changePort(const CharString &connStr, unsigned short port);

    /// get single source connect
    static PVSSboolean getSingleSourceConnect() { return singleSourceConnect; }

    /// get recovery requested flag
    static PVSSboolean recoveryRequested() { return recoveryRequest; }

    /// set recovery requested flag
    static void setRecoveryRequest()   { recoveryRequest = PVSS_TRUE; }

    /// clear recovery requested flag
    static void clearRecoveryRequest() { recoveryRequest = PVSS_FALSE; }

    /// set redundancy flag
    /// @n Use internally only!
    /// @param newRedu the value to set
    static void setRedundant(PVSSboolean newRedu) { redundancy = newRedu; }

    /// set light redundancy flag
    /// @param newRedu the value to set
    static void setLightRedundancy(PVSSboolean newRedu) { redundancy = newRedu; }

    /// check if manager is running in a redundant system
    static PVSSboolean isRedundant() { return redundancy; }

    /// check if manager is running in a redundant system (obsolete, use isRedundant())
    static PVSSboolean isLightRedundant() { return redundancy; }

    /// check if system is light red active
    static PVSSboolean isLightRedActive() { return redActive; }

    /// set light red active flag
    /// @param newAct the value to set
    static void setLightRedActive(PVSSboolean newAct) { redActive = newAct; }

    /// check if system is red active
    static PVSSboolean isRedActive() { return redActive; }

    /// set red active flag
    /// @param newAct the value to set
    static void setRedActive(PVSSboolean newAct);

    /// get redundant host number
    /// @n Return 1 or 2, depending on which EV I'm connected (e.g. eventHost = "host1$host2").
    /// In a non-redundant configuration it always returns 1
    static int getMyReduHostNum();

    /// get dejavy type
    /// @return  true if you got a valid DejaVuType or false if DejaVuType currently not available, try it later (after you have initialised your Manager Class)
    static bool getDejaVuType(DejaVuType &_type);

    /// get the hostname of the event manager, which is connected to
    /// (currently the same as getEventHost())
    static const CharString &getMyReduHost();

    /// get the name of the host the OTHER (not my) EV is running on
    /// @n In a non-redundant configuration it always returns the same as getEventHost().
    static const CharString &getOtherReduHost();

    /// set add version info
    /// @param info the info to set
    static void setAddVersionInfo(const char *info) { addVersionInfo = info; }

    /// get add version info
    static const CharString &getAddVersionInfo() { return addVersionInfo; }

    /// check if manager is running in a distributed system
    static PVSSboolean isDistributed() { return distributed; }

    /// tells whether sec. plugin usage is forced in a distributed system with heterogeneous versions (31406)
    static PVSSboolean getEnforceAccessControl() { return enforceAccessControl; }

    /// tells whether sec. plugin usage is forced in a distributed system with heterogeneous versions (31406)
    static void setEnforceAccessControl(PVSSboolean eac) { enforceAccessControl = eac; }

    // IM 94721: Identification should be parametizable per Manager in Dist-Systems
    /** hold DP identifications
      * @n It is now possible to restrict the number of DpIdentifications, hold by a manager.
      * @param _sys the system number
      * @return PVSS_TRUE if _sys is one of the DpIdentifications that the manager
      * may hold, but this does not mean the manager has already got the DpIdentification!
      */
    static PVSSboolean holdDpIdentification(SystemNumType _sys);

    /// check if "distributed" was read from config file
    static PVSSboolean isDistributedInitialized() { return distributedInitialized;}

    /// set distributed flag
    /// @param f the value to set
    static void setDistributed(PVSSboolean f);

    /** get list of Ctrl libraries which manager wants to use
      * @n This list is used in the managers with a CTRL interpreter, e.g. ctrl, ui, event.
      * It is modified by the config file keywords loadCtrlLibs, unloadCtrlLibs.
      */
    static DynPtrArray<CharString> &getCtrlLibraryList() { return ctrlLibraryList; }

    /// set load all Ctrl libs flag
    static void setLoadAllCtrlLibs() { loadAllCtrlLibs_ = PVSS_TRUE; }

    /// get load all Ctrl libs flag
    static PVSSboolean loadAllCtrlLibs() { return loadAllCtrlLibs_; }

    /// set load no Ctrl lib flag
    static void setLoadNoCtrlLib() { ctrlLibraryList.clear(); }

    /// get use local identification flag
    static PVSSboolean getUseLocalIdentification() {return useLocalIdentification;}

    /// get convert db flag
    static PVSSboolean convertDb() { return(convertDb_); }          // IM76860 TRUE means: manager was called by PVSStoolConvertDb to upgrade a database

    /// get stat FCT inherit corr values flag
    static PVSSboolean statFctInheritCorrValues() { return statFctInheritCorrValues_; }

    /// get status FCT activate
    static PVSSboolean statFctActivate() { return statFctActivate_; }

    /// get status FCT limit for mark as corrected
    static PVSSushort statFctLimitForMarkAsCorrected() { return statFctLimitForMarkAsCorrected_;  }

    /// get status FCT max intervals in past
    static PVSSushort statFctMaxIntervalsInPast() { return statFctMaxIntervalsInPast_;  }

    // 14.12.06 apfluegl IM75997 Alarmfarbe
    /// get keep ack color on multiple ack flag
    static PVSSboolean getKeepAckColorOnMultipleAck() { return keepAckColorOnMultipleAck;  }

    // IM79056 highlight the last active alert
    /// get highlight active alarm foreground color
    static const CharString &getHighlightActiveAlarmForeCol() { return highlightActiveAlarmForeCol;  }

    /// get highlight active alarm background color
    static const CharString &getHighlightActiveAlarmBackCol() { return highlightActiveAlarmBackCol;  }

    /// get highlight alarm foreground color
    static const CharString &getHighlightAlarmForeCol() { return highlightAlarmForeCol;  }

    /// get highlight alarm background color
    static const CharString &getHighlightAlarmBackCol() { return highlightAlarmBackCol;  }

    /// get description mode
    static const int &as_getDescriptionMode() { return as_descriptionMode;  }

    // IM 84037 WOKL 28.2.08 highlight the last active alert in current mode
    /// get highlight current active alarm foreground color
    static const CharString &getHighlightCurrActiveAlarmForeCol() { return highlightCurrActiveAlarmForeCol;  }

    /// get highlight current active alarm background color
    static const CharString &getHighlightCurrActiveAlarmBackCol() { return highlightCurrActiveAlarmBackCol;  }

    /// get ResourceDiag member
    static ResourceDiag &getDiag();

    /// get IP access control list
    static IpAcl &getIpAcl() { return ipAcl; }

    /// get BCM buffer limit
    static int getBCMBufferLimit() { return bcmBufferLimit; }

    /// get BCM buffer limit timeout
    static int getBCMBufferLimitTimeout() { return bcmBufferLimitTimeout; }

    /// get kerberos security
    static const CharString & getKerberosSecurity() {return kerberosSecurity;}

    /// get kerberos root group
    static const CharString & getKerberosRootGroup() {return kerberosRootGroup;}

    /// get message compression
    static CharString getMessageCompression() {return messageCompression;}

    /// is local message compression allowed?
    static PVSSboolean isLocalMsgCompressionAllowed() {return allowLocalMessageCompression;}

    /// get message compression treshold
    static unsigned getMessageCompressionThreshold() {return messageCompressionThreshold;}

    /// init heap management (is automatically done in begin(), init())
    static int initMemHeap();

    /// 'online' switch language
    /// @param lang the language
    IL_DEPRECATED("deprecated, use Manager::switchActiveLang() instead")
    static PVSSboolean switchLang(LanguageIdType lang);

    /// get auto reg
    static int getAutoReg() { return autoReg_; };

    /// get processed config file list
    static CharString getProcessedConfigFileList();

    /// start cript
    /// @param scriptName the script name
    /// @param arg the arguments
    /// @return true if OK
    static PVSSboolean startScript(const CharString &scriptName, const CharString &arg);

    /// redirect standard error
    static void redirectStdErr();

    /// check log size
    /// @param logFile the log file
    /// @param bTruncate the truncate flag
    /// @return true if OK
    static PVSSboolean checkLogSize(CharString logFile, PVSSboolean bTruncate);

    /// check log size
    static PVSSboolean checkLogSize();

    /// check if alert reduction is activated
    static PVSSboolean isAlertReductionActivated();   // IM 80248: _filter_threshold is not initialized in 3.5 and 3.6 projects

    /// get value change time diff
    static PVSSulong  getValueChangeTimeDiff();       // IM60408 filesets do not get the same name if pc-time is not the same

    /// get the smallest time interval, which can be processed
    static TimeVar getSystemTimePrecision();          // IM 061_7099 WI DB-SubSe Sub-seconds issues -- es gibt keine zeitgleichen werte mehr

    // IM90819 unit test for Event Class MsgQueueContainer
    // Damit UnitTest Executables kein config-file brauchen runningStateRequired_ auf false setzen
    /// get running state required
    /// @n see Exe/Event/Test/MsgQueueContainerTest.cxx
    static PVSSboolean runningStateRequired() { return(runningStateRequired_); }

    /// return true if this manager should not store CNS structures
    static bool refuseCNS();

    /// returns the comma-separated list of allowed CNS views (or empty)
    static const CharString &requestedCNSViews() { return requestedCNSViews_; }

    /// Returns the name of the configured security plugin, or an empty string (obsolete, see getAccessControlPluginName())
    static const CharString &getSecurityPluginName();    // TFS 16559 obsolete, for compatibility reasons

    /// Returns the name of the configured access control plugin, or an empty string
    static const CharString &getAccessControlPluginName();

    /// Returns Path and Configuration of Private key used for Manager authentication in serverside authentication, or an empty string
    static const CharString &getSsaPrivateKey();
    /// Returns Path and Configuration of Certificate used for Manager authentication in serverside authentication, or an empty string
    static const CharString &getSsaCertificate();
    /// Returns Path to Chainfile used for Manager authentication in serverside authentication, or an empty string
    static const CharString &getSsaChainFile();
    /// Returns Path to CRL file used for Manager authentication in serverside authentication, or an empty string
    static const CharString &getSsaCRL();
    /// Returns serverside authentication key verification parameters
    static const CharString &getSsaCertCheck();

    /// enable or disable server side authentication checks.
    static void setServerSideAuthentication(bool enabled);

    /// is server side authentication enabled?
    static bool isServerSideAuthenticationEnabled();

    /// returns true if the manager shall not send a disconnect all to systems it has no connects to
    static bool useOptimisedRefresh() { return optimisedRefresh; }

    /** returns true for Resources::ATTR_FLAG_TEXT if the _alert_hdl.._text attribute should be
        replaced by a definded _alert_hdl.._add_value_2.
        returns true for Resources::ATTR_FLAG_VALUE if the _alert_hdl.._value attribute should be
        replaced by a definded _alert_hdl.._add_value_1.
        @param attr: enum for alarm attribut that should be replaced { ATTR_FLAG_TEXT, ATTR_FLAG_VALUE }

    */
    static bool attributesFromAddValues(AttrFlags attr);

    /// allow periphaddr config on DPE of type DpId
    /// @return true if allowed
    static bool doAllowPeriphOnDpId() { return allowPeriphOnDpId; }

    /// get the maximum number of datapoints in a (dis)connect message
    static unsigned short getMaxConnectMessageSize() {return maxConnectMessageSize_;}

    /// get the "noReverseLookup" flag
    static bool getNoReverseLookup() {return noReverseLookup;}
    /// discrete impulse alert without WENT (like binary)
    static bool discreteImpulseAlertWithoutWent() { return discreteImpulseAlertWithoutWent_; }

    /// get the "useCRC" flag
    static bool getUseCRC() {return useCRC;}

    /// get the "osErrorMode" value
    static unsigned int getOSErrorMode() {return osErrorMode;}

    // Before 3.17 event checked alertSet against _auth._alert_hdl._write
    // Starting with 3.17 the default is to check it agains _auth._alert._write
    static bool alertPermissionsCompatibilityMode() { return alertPermissionsCompatibilityMode_; }

  public:
    static bool isMxProxyUsed(const CharString &hostname);
    static bool getMxProxy(CharString &hostname, unsigned short &portNr, SEC_TYPE_t &secMode);

    static SEC_TYPE_t getSecSecurityMode()  { return secSecurityMode; }
    static CharString getSecServerCert()    { return secServerCert; } // contains absolute path after config file processing is done, #62578
    static CharString getSecServerKey()     { return secServerKey; }  // contains absolute path after config file processing is done, #62578
    static CharString getSecRootCA()        { return secRootCA; }     // contains absolute path after config file processing is done, #62578
    static CharString getSecCrl()           { return secCrl; }
    static int getSecVerifyTime()           { return secVerifyTime; }
    /// PEM file containing DH params to use for ephemeral DH key exchange.
    /// If empty, either the DH params from the certificate or
    /// default params will be used.
    static CharString getSecTmpDhFile()     { return secTmpDhFile; }
    /// Name of the elliptic curve to use for ephemeral ECDH key exchange.
    /// If empty, a default curve will be used.
    /// Call "openssl ecparam -list_curves" to see possible values.
    static CharString getSecTmpEcdhCurve()  { return secTmpEcdhCurve; }

    static CharString getCertLoc()          { return certLoc; }
    static CharString getCertStore()        { return certStore; }
    static CharString getCertSubject()      { return certSubject; }
    static CharString getRootCALoc()        { return rootCALoc; }
    static CharString getRootCAStore()      { return rootCAStore; }
    static CharString getRootCASubject()    { return rootCASubject; }

    static int getWinCertFindType()         { return winCertFindType; }
    static CharString getCipherSuiteList()  { return cipherSuiteList; }
    static CharString getChainPrefix()      { return chainPrefix; }
    static bool hasCmdLineManagerNum()      { return hasManagerNum; }

    //functions to return CodeMeter licensing options
    static bool useCMLicense()               { return(useCMLicense_); }
    static unsigned short getCmContainerBoxMask()  { return cmContainerBoxMask_; }
    static unsigned int getCmContainerSerial()   { return cmContainerSerial_; }

    /// Debug flag for multiplexing proxy
    static short mxProxyDbgFlag;

    /// manager log file
    static CharString managerLogFile;

    /// @name General Datapoints
    //@{

    /// DP user ID
    static CharString DP_UserId;

    /// DP user mame
    static CharString DP_UserName;

    /// DP user password
    static CharString DP_UserPassword;

    /// DP user permission set
    static CharString DP_UserPermSet;

    /// DP user force set
    static CharString DP_UserForceSet;

    /// DP user enabled
    static CharString DP_UserEnabled;

    /// DP user enabled
    static CharString DP_UserGroupIds;

    /// DP manager table type
    static CharString DP_ManagerTableType;

    /// DP manager table number
    static CharString DP_ManagerTableNum;

    /// DP manager table permission
    static CharString DP_ManagerTablePerm;

    /// DP manager exit
    static CharString DP_ManagerExit;

    /// DP manager refresh
    static CharString DP_ManagerRefresh;

    /// DP connections
    static CharString DP_Connections;

    /// DP redundant manager
    static CharString DP_ReduManager;

    /// DP statistics message
    static CharString DP_StatisticsMsg;
    //@}

    /// counter
    static unsigned long aCounter;

    /// message diagnostic TMO
    static PVSSulong messageDiagTmo;

    /// @name PDM
    //@{

    /// DP product
    static CharString DP_Product;

    /// DP
    static CharString DP_Product_BitValues;

    /// DP product bit values
    static CharString DP_Product_AnalogValues;

    /// DP product text values
    static CharString DP_Product_TextValues;

    /// DP product bit variables
    static CharString DP_Product_BitVariables;

    /// DP product analog variables
    static CharString DP_Product_AnalogVariables;

    /// DP product text variables
    static CharString DP_Product_TextVariables;

    /// DP product reset
    static CharString DP_Product_Reset;
    //@}

    /// DP connect wild cards;
    static PVSSboolean dpConnectWildCards;

    /// mode for dpGetDescription
    static int dpGetCommentMode;

    /// DP function loop counter
    static PVSSulong dpFuncLoopCount;   // TI 17075 WOKL; wird in SimpleEvConfs/DpFunction.cxx verwendet

    // strictly for internal use only -> no DOC++ comment intended
    static int maxLoops;

  protected:
    /** init global settings like progName and parse commandline args which
        have nothing to do with config file/pa like -help, -helpdbg etc.
        @n It is called from begin() if it was not already called before.
        This is useful e.g. if you want to check only if the user passed the -help flag,
        or you want to deal with commandline arguments which do not need a config file yet.
        @return true if all went ok and the program shall continue, false otherwise
      */
    static bool initGlobals(int &argc, char *argv[]);

    /** get next config file entry
        @n Comments and entries for other hosts will be skipped.
        If after this call cfgState == CFG_OK, keyword will contain the current keyword
        and the cfgStream is positioned after the '=' character.
      */
    static void getNextEntry();

    /** get generateMXProxyEntries value
    @n generateMXProxyEntries will false if in config mxProxy = "none" is
    */
    static bool getGenerateMXProxyEntries()
    {
      return generateMXProxyEntries;
    }

    /** exit with message to std::cerr
        @param status the status
    */
    static void exit(int status);


    /// the states for reading the config file
    enum CfgState
    {
      /// (0). end of file reached
      CFG_EOF,
      /// (1). start of new section
      CFG_SECT_START,
      /// (2). continue reading a section
      CFG_OK
    };

    /// input stream
    IL_DEPRECATED("Please don't use 'cfgStream' directly anymore! Use 'getCfgStream()' instead!")
    static std::ifstream &cfgStream;

    /// stream file name
    static CharString cfgStreamFileName;

    /** error flag
        @n Set to PVSS_TRUE, if an error like an unknown keyword occured.
        The manager will exit if after reading the config file cfgError == PVSS_TRUE.
    */
    IL_DEPRECATED("Please don't use 'cfgError' directly anymore! Use 'isCfgError()' or 'setCfgError()' or 'unknownKeyWordError()' instead!")
    static PVSSboolean cfgError;

    /// current config state
    IL_DEPRECATED("Please don't use 'cfgState' directly anymore! Use 'getCfgState()' instead!")
    static CfgState cfgState;

    /// current keyword
    IL_DEPRECATED("Please don't use 'keyWord' directly anymore! Use 'getKeyWord()' instead!")
    static CharString keyWord;

    /// get input stream
    static std::istream& getCfgStream();

    /** error flag
    @n Set to PVSS_TRUE, if an error like an unknown keyword occured.
    The manager will exit if after reading the config file cfgError == PVSS_TRUE.
    */
    static PVSSboolean isCfgError();

    /** Set the cfgError flag to true
    Manager will exit if after reading of the config file the cfgError will be set to PVSS_TRUE.
    */
    static void setCfgError();

    /// raise an error (cfgError) because the current keyword is unknown.
    static void unknownKeyWordError();

    /// current config state
    static CfgState getCfgState();

    /// current keyword
    static const CharString& getKeyWord();


    /// set config filename
    /// @param configFileName the config filename
    static bool setConfigFileName(const char *configFileName = 0);

    // Need sigx protected for PVSSConsole (klugsber)
#if defined (_WIN32)
    /// Registered signal handler for Interrupt
    static StdSignalHandler * sigInt;
    /// Registered signal handler for Quit
    static StdSignalHandler * sigQuit;
    /// Registered signal handler for Kill
    static StdSignalHandler * sigKill;
    /// Registered signal handler for Terminate
    static StdSignalHandler * sigTerm;
# ifndef _WIN32_WCE
    /// Win32 control handler
    static int Win32CtrlHandler(int);
# endif
#endif

    /// programm name
    static CharString progName;

    /// reinit flag - NEW
    /// @n Set to 1 if call to init will be repeated.
    /// Certain calls (ie putenv) will not be performed if this flag is set to 1.
    // (klugsber)
    static PVSSuchar reInitFlag;

    /// help flag
    static PVSSboolean helpFlag;
    // TI 2342

    /// help debug flag
    static PVSSboolean helpDbgFlag;

    /// help report flag
    static PVSSboolean helpReportFlag;

    /// number of Userbits that turns last value save on or off (1 - 8)
    static int saveLastValueBit_;

    /// allocate options
    static CharString allocOptions;

    /// number of languages
    static LanguageIdType numOfLangs;

    /// parametric language
    static LanguageIdType paramLang;

    /// meta language
    static LanguageIdType metaLang;

    /// data connection string
    static CharString dataConnectString;

    /// event connection string
    static CharString eventConnectString;

    /// default data port
    static unsigned short defaultDataPort;

    /// default event port
    static unsigned short defaultEventPort;

    /// event host
    static CharString eventHost;

    /// event port
    static unsigned short eventPort;

    /// data host
    static CharString dataHost;

    /// data port
    static unsigned short dataPort;

    /// proxy port
    static unsigned short proxyPort;

    /// local address
    static CharString localAddress;

    static CharString localhostIPAddr;
    /// port which pmon listens for commands on
    static unsigned short pmonPort_;

    /// project key
    static int projectKey;

    /// pmon index
    static int pmonIndex;

    /// port for alive messages
    static unsigned short alivePort;

    /// timeout for messages
    static short aliveTimeout;

    /// alive thread priority
    static int aliveThreadPriority;

    /// atomic DP set flag
    static PVSSboolean atomicDpSet;

    /// parallel ctrl ADO
    static PVSSboolean parallelCtrlADO;

    /// ctrl ADO MS bool format
    static PVSSboolean ctrlAdoMSBoolFormat;

    /// ctrl ADO numerical precision
    static CharString  ctrlAdoNumericalPrecision;

    /// historyDB esperrer 10.12.1999
    static PVSSboolean valArch;

    /// compress archive flag
    static PVSSboolean compressArch;

    /// RDB archive thbw 30.8.2003
    static PVSSboolean rdbArch;

    // 20.10.17 esperrer TFS 23329: use UTF8 with RAIMA DB in ISO
    static PVSSboolean dbAsIso;

#ifndef NO_NGA
    /// should use the NextGenArchiver
    static PVSSboolean useNga;

    /// should calls to dpQuery(Split), dpGetPeriod(Split) and dpGetAsynch be redirected to the NextGenArchiver DirectRead Control Extension?
    static PVSSboolean useNgaDirectRead;
#endif

    //defaultrchive, when HDB and RDB in parallel use
    static int defaultArchive;

    // 09.08.04 esperrer RDB-Manager: Erkennung, ob BLE-RDB-Manager
    /// esperrer RDB-Manager: BLE-RDB-Manager
    static PVSSboolean rdbGroups;

    /// active locale
    static CharString activeLocale;

    /// param locale
    static CharString paramLocale;

    /// meta locale
    static CharString metaLocale;

    /// number of connection retries
    static unsigned int connectRetries;

    /// connection delay
    static unsigned int connectDelay;

    /// exity delay
    static unsigned int exitDelay;

    /// debug stream
    static std::ifstream &dbgStream;

    /// report stream
    static CharString reportStream;

    /// coverage report stream
    static CharString coverageReportStream;

    /// dump coverage on exit flag
    static bool dumpCoverageOnExit;

    /// user name
    static CharString userName;

    /// password
    static CharString password;

    /// have user name
    static PVSSboolean haveUserName;

    /// have password
    static PVSSboolean havePassword;

    /// ctrl max time
    static double ctrlMaxTime;

    /// ctrl max time
    static double ctrlMinTime;

    /// ctrl max weight
    static PVSSlong ctrlMaxWeight;

    /// ctrl max pendings
    static PVSSlong ctrlMaxPendings;

    /// ctrl max blocked pendings
    static PVSSlong ctrlMaxBlockedPendings;

    /// query HL blocked time
    static PVSSshort queryHLBlockedTime;

    /// ctrl Break function call
    static PVSSboolean ctrlBreakFunctionCall;

    /// table util max weight
    static PVSSlong tabUtilMaxWeight;

    /// max DP names
    static PVSSulong maxDpNames;

    // TI 18485, 18486
    /// one row alert
    static PVSSboolean as_OneRowAlert;

    /// show milli seconds
    static PVSSlong as_ShowMilliseconds;

    /// special went text
    static PVSSboolean as_SpecialWentText;

    /// went text delimiter
    static CharString as_WentTextDelimiter;

    // TI 637 17.03.99 Irena
    /// ignore debug
    static PVSSboolean ignoreDebug;

    // TI 563 02.04.99 Irena
    /// DP comment separator
    static CharString dpCommentSeparator;

    /// our manager identifier
    static ManagerIdentifier  ownManId;

    /// nur nystem name
    static CharString systemName;

    /// start of free assignable manager numbers
    static PVSSuchar  lowestAutoManNum;

    /// start of free assignable manager UI
    static PVSSuchar  lowestAutoManNumUI;

    /// saved locale
    static CharString savedLocale;

    /// strl DLLs
    static DynVar           ctrlDLLs_;

    /// no user ctrl ext
    static bool noUserCtrlExt_;

    /// IP ACL
    static IpAcl ipAcl;

    /// limit of BCM buffer [bytes]
    static int bcmBufferLimit;

    /// timeout [s], which defines how long the limit can be exceeded
    static int bcmBufferLimitTimeout;

    // IM 56754
    /// ctrl RDB archive DLL
    static CharString ctrlRDBArchiveDll;

    /// query RDB direct
    static PVSSboolean queryRDBdirect;

    // IM 58856, 27.07.2005 rputz:config entries added for APM
    /// APM connection string
    static CharString APMConnString_;

    // IM 73750
    /// append project directory
    /// @param dir the directory to append
    static void appendProjDir(const CharString &dir)
    {
      pathes_.appendProjDir(dir);
    }

    /// insert project directory
    /// @param dir the directory to insert
    static void insertProjDir(const CharString &dir)
    {
      pathes_.insertProjDir(dir);
    }

    // IM 061_7099 WI DB-SubSe Sub-seconds issues -- es gibt keine zeitgleichen werte mehr
    /// system time precision
    static TimeVar systemTimePrecision_;          // min. genauigkeit der zeiten

    static bool optimisedRefresh;

    /// independent alert ACK
    static bool independentAlertAck_;

    /// refuse CNS
    static bool refuseCNS_; // IM 99893: CNS on demand

    /// list of allowed CNS views (or empty)
    static CharString requestedCNSViews_;

    /// Security Plugin name or path (as supported by SharedLib::load())
    static CharString accessControlPluginName_; // IM 101399
    /// Path and Configuration of Private key used for Manager authentication in serverside authentication
    static CharString ssaPrivateKey_;
    /// Path and Configuration of Certificate used for Manager authentication in serverside authentication
    static CharString ssaCertificate_;
    /// Path to Chainfile used for Manager authentication in serverside authentication
    static CharString ssaChainFile_;
    /// Path to CRL file used for Manager authentication in serverside authentication
    static CharString ssaCRL_;
    /// Serverside authentication key verification parameters
    static CharString ssaCertCheck_;
    /// SecurityPlugin enforces server side authentication
    static bool serverSideAuthentication_;

    /// attributes from added values
    static int attributesFromAddValues_;

    /// the maximum number of datapoints in a (dis)connect message
    static unsigned short maxConnectMessageSize_;

    static void setMXProxyEntriesNeeded(bool Avalue) { generateMXProxyEntries = Avalue; }  // tells, that the manager has to generate the default mxproxy entries or not

    static PVSSboolean     useLocalIdentification;

    static bool discreteImpulseAlertWithoutWent_;
  private:
    // usable proxy forward routes
    static CharStringProxyDescriptionMap *destToProxy;

    // security variables
    // is security used
    static CharString secSecurityModeStr;
    static SEC_TYPE_t secSecurityMode;
    static CharString secServerCert;
    static CharString secServerKey;
    static CharString secRootCA;
    static CharString secKeyProt;
    static CharString secCrl;
    static int secVerifyTime;
    static CharString secTmpDhFile;
    static CharString secTmpEcdhCurve;

    static CharString certLoc;
    static CharString certStore;
    static CharString certSubject;
    static CharString rootCALoc;
    static CharString rootCAStore;
    static CharString rootCASubject;
    static int winCertFindType;

    // the selected cipher suite
    static CharString cipherSuiteList;

    // allowed root chain
    static CharString chainPrefix;

    static PVSSboolean checkIgnoredManager(const ManagerIdentifier &man);

    static int cfgLevel;  // used for reading all config-files of all levels
    static int cfgType;   // 1 = config.level, 2 = config.redu
    static CharString cfgStreamMainFileName; // IM 64275

    static bool exitOnError;

    static PVSSboolean readSection();
    static void signalHandler(int signo);
    static void setLevels();
    static PVSSboolean readDebugFile();

    static bool matchConfigProj(const char *config=0, const char *projName=0);
    static bool setProjectName(const char *projName=0);

    static void addToProcessedConfigFileList( const char *configFileName );
    static bool isInProcessedConfigFileList( const char *configFileName );

    // sets the default values of the certification path for the mxproxy
    static void setProxyDefaults();

    // finalizes the values of secServerCert, secServerKey, secRootCA members
    static void certPathsPostProcessing();

    // if 'path' is relative to the project dir, it will be expanded to absolute path
    static void resolvePathToAbsolute(CharString& path);

    static int exceptionHit;
    static SocketInitializer sockInit;

    //static DynPtrArray<LanguageDefRec>    languageDefTable;
    //static DynPtrArray<LanguageDefRec>    altLangDefTable;
    //static DynPtrArray<LanguageDefRec>    globLangDefTable;
    //static DynPtrArray<LanguageFallbackRec> globLangFallbackTable;

    static DynPtrArray<LanguageDefRec>    languageSearchPath_;

    static CharString licenseFile;

    static CharString indepLang;

    static TranslateList * translateList;
    static char            translateDelimiter;
    static CharString      translateDictionary;

    // Redundancy
    static CharString      primaryDMConnectString;
    static CharString      secondaryDMConnectString;

    static CharString      primaryEMConnectString;
    static CharString      secondaryEMConnectString;

    static CharString      primaryDMHost;
    static CharString      secondaryDMHost;
    static CharString      primaryEMHost;
    static CharString      secondaryEMHost;

    static unsigned short  primaryDMPort;
    static unsigned short  secondaryDMPort;
    static unsigned short  primaryEMPort;
    static unsigned short  secondaryEMPort;

    static PVSSboolean     singleSourceConnect;

    static PVSSboolean     recoveryRequest;

    static PVSSboolean     redundancy;
    static PVSSboolean     redActive;

    static PVSSboolean     perfFlag;

    static PVSSushort        dbgCount;
    static PVSSushort        dbgOffset;

    static CharString      addVersionInfo;

    static PVSSboolean     distributed;
    static PVSSboolean     distributedInitialized;

    static PVSSboolean     enforceAccessControl; // 31406

    static Pathes          pathes_;

    static PVSSushort        maxLogFileSize;

    static PVSSulong       projVersionNumeric_;
    static CharString      projVersion_;
    static CharString      configFileName_;  // double of env PVSS_II
    static CharString      projectName_;


    static bool            hardVersionCheck_;
    static bool            hardPaCheck_;

    static bool            allowPeriphOnDpId;

    static CharString      addConfigFile_;
    static CharString      processedConfigFiles_;

    static PVSSboolean     loadAllCtrlLibs_;
    static PVSSboolean     loadNoCtrlLib_;

    static int             autoReg_;

    static PVSSboolean     convertDb_;                          // IM76860 TRUE means: manager was called by PVSStoolConvertDb to upgrade a database
    static PVSSboolean     statFctActivate_;
    static PVSSboolean     statFctInheritCorrValues_;
    static PVSSushort        statFctLimitForMarkAsCorrected_;
    static PVSSushort        statFctMaxIntervalsInPast_;
    static PVSSboolean     keepAckColorOnMultipleAck;    // 14.12.06 apfluegl IM75997 Alarmfarbe
    static CharString      highlightActiveAlarmBackCol;        // IM79056 highlight the last active alert
    static CharString      highlightActiveAlarmForeCol;
    static CharString      highlightAlarmBackCol;
    static CharString      highlightAlarmForeCol;
    static int             as_descriptionMode;
    static CharString      highlightCurrActiveAlarmBackCol;        // IM 84037 highlight the last active alert in current mode
    static CharString      highlightCurrActiveAlarmForeCol;        // WOKL 28.2.08


    static DynPtrArray<CharString>  ctrlLibraryList;     // the list of Ctrl librarys the manager wants to use
    static DynPtrArray<ManagerIdentifier>  ignoredManagerList;  // Ignoriere HL von diesen Managern
    static DynPtrArray<ManagerIdentifier>  rcvManagerList;      // Print rcv messages from these Managers only
    static DynPtrArray<CharString>         rcvMsgTypeList;      // Print rcg messages of this types only
    static DynPtrArray<ManagerIdentifier>  sndManagerList;      // Print snd messages from these Managers only
    static DynPtrArray<CharString>         sndMsgTypeList;      // Print snd messages from these types only

    static ResourceDiag    diag_;
    static int             requestDejaVu_;

    static CharString      kerberosSecurity;
    static CharString      kerberosRootGroup;

    static CharString      messageCompression;
    static unsigned        messageCompressionThreshold;
    static PVSSboolean     allowLocalMessageCompression;  // IM 101676: allow local message compression when set,default false
    static PVSSboolean     activateAlertReduction_;       // IM 80248: _filter_threshold is not initialized in 3.5 and 3.6 projects

    static PVSSulong       valueChangeTimeDiff_;          // IM60408 filesets do not get the same name if pc-time is not the same
    static PVSSboolean     runningStateRequired_;
    static CharString      holdDpIdentifications_;        // IM 94721: Identification should be parametizable per Manager in Dist-Systems

    static bool            generateMXProxyEntries;        // IM112203: mxproxy default values

    static bool            isUsernameInConfig;            //IM 114328
    static bool            isPasswdInConfig;              //IM 114328
    static bool            hasManagerNum;                 //IM 117700: DpIdentification caching not supported on machines with more than one manager

    static bool            noReverseLookup;

    static bool            useCRC;
    static unsigned int    osErrorMode;

    static BitVec          remoteSysUsesUTF8Enc;          // TFS 24334

    // Before 3.17 event checked alertSet against _auth._alert_hdl._write
    // Starting with 3.17 the default is to check it agains _auth._alert._write
    static bool alertPermissionsCompatibilityMode_;

    /// defined displayName (e.g. for DesktopUI) to be shown instead of projectName
    static CharString      displayName;

    //config entries for CodeMeter Licensing
    static bool useCMLicense_;
    static unsigned int cmContainerSerial_;
    static unsigned short cmContainerBoxMask_;

#ifdef SWIG_TOOL
  public:
    // SWIG needs at least one virtual function in this class
    virtual void _SWIG_VirtualDummyFunction();
#endif
};

//--------------------------------------------------------------------------------

inline bool Resources::isLanguageDir(CharString (*getPath)(int))
{
  return(
          (getPath(1) == pathes_.getMsgDir(1) ) ||
          (getPath(1) == pathes_.getHelpDir(1)) ||
          (getPath(1) == pathes_.getErrTextDir(1))
        );
}

//--------------------------------------------------------------------------------

inline ResourceDiag &Resources::getDiag()
{
  return(diag_);
}

//--------------------------------------------------------------------------------


// Die erste Abfrage inline, damit sie schneller geht, die
// for-Schleife dann als explizite Fun
inline PVSSboolean Resources::isIgnoredManager(const ManagerIdentifier &manId)
{
  if (!ignoredManagerList.getNumberOfItems() ||
      (manId.getManType() == NO_MAN) )
    return PVSS_FALSE;
  return checkIgnoredManager(manId);
}


// -------------------------------------------------------------------------
inline const CharString &Resources::getProgName()
{
  return(progName);
}

// -------------------------------------------------------------------------
inline CharString Resources::getProgNameAndTime(const TimeVar &timeToPrint)
{
  CharString man;
  if (progName.len() < 13)
  {
    char temp[13 + 1];
    sprintf(temp, "%-13s", (const char *)progName);
    man = temp;
  }
  else
  {
    man = progName;
  }

  // 08.11.01 esperrer TI11702: Hack, um bei ValArchars die "-num"-ManNum zu bekommen
  unsigned manNum = Resources::getManNum();
  if (Resources::getManType() == DB_MAN && manNum > 1) // ValArch!
    manNum -= 2;

  return (man +
          "(" + CharString(manNum) + "), " +
          timeToPrint.formatValue("")
         );
}

// -------------------------------------------------------------------------
inline CharString Resources::getProgNameAndTime()
{
  TimeVar t;  // wird mit aktueller Zeit (now) initialisiert
  return(Resources::getProgNameAndTime(t));
}

// -------------------------------------------------------------------------

inline int Resources::getMyReduHostNum()  // return 1 or 2, depending on which EV I'm connected
{
  return
    Resources::isRedundant() ?
      (( Resources::getEventHost() == Resources::getPrimaryEMHost() ) ? 1 : 2) :
      1;
}

// -------------------------------------------------------------------------
// return the name of the host my EV is running on

inline const CharString &Resources::getMyReduHost()
{
  return Resources::getEventHost();
}

// -------------------------------------------------------------------------
// return the name of the host the OTHER EV is running on

inline const CharString &Resources::getOtherReduHost()
{
  return
    Resources::isRedundant() ?
      (( Resources::getEventHost() == Resources::getPrimaryEMHost() ) ?
          Resources::getSecondaryEMHost() :
          Resources::getPrimaryEMHost()) :
      Resources::getEventHost();
}

//------------------------------------------------------------------------------

inline bool Resources::refuseCNS()
{
  return refuseCNS_;
}

//------------------------------------------------------------------------------

inline const CharString &Resources::getSecurityPluginName()
{
  return accessControlPluginName_;
}

//------------------------------------------------------------------------------

inline const CharString &Resources::getAccessControlPluginName()
{
  return accessControlPluginName_;
}

//------------------------------------------------------------------------------

inline const CharString &Resources::getSsaPrivateKey()
{
  return ssaPrivateKey_;
}

//------------------------------------------------------------------------------

inline const CharString &Resources::getSsaCertificate()
{
  return ssaCertificate_;
}

//------------------------------------------------------------------------------

inline const CharString &Resources::getSsaChainFile()
{
  return ssaChainFile_;
}

//------------------------------------------------------------------------------

inline const CharString &Resources::getSsaCRL()
{
  return ssaCRL_;
}

//------------------------------------------------------------------------------

inline const CharString &Resources::getSsaCertCheck()
{
  return ssaCertCheck_;
}

//------------------------------------------------------------------------------

inline void Resources::setServerSideAuthentication(bool enabled)
{
  serverSideAuthentication_ = enabled;
}

//------------------------------------------------------------------------------

inline bool Resources::isServerSideAuthenticationEnabled()
{
  return(serverSideAuthentication_);
}

//------------------------------------------------------------------------------

inline bool Resources::attributesFromAddValues(AttrFlags attr)
{
  return (attributesFromAddValues_ & (int)attr) != 0;
}

/* ------------------------------------------------------------------------- */
#endif /* _RESOURCES_H_ */
