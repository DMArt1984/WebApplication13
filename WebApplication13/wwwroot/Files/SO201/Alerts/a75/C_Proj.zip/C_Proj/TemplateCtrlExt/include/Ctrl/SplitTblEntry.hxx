// VERANTWORTUNG: Andras Horvath

/* Item for the message splitting table  */

#ifndef _SPLITTBLENTRY_H_
#define _SPLITTBLENTRY_H_

#include <DpMsgAnswer.hxx>
#include <list>


class DynVar;
class WaitDpGetSplit;

//--------------------------------------------------------------------------------

class DLLEXP_CTRL SplitTblEntry
{
public:
  SplitTblEntry(PVSSulong reqId, MsgType msgType);

  /// Destructor
  virtual ~SplitTblEntry();


  DynVar* getDpQueryValue();
  void mergeDpQueryResult(DynVar* newvar);
  void clearDpQueryValue();

  void addDpGetPeriodAnswer(DpMsgAnswer& msg);
  DpMsgAnswer* getNextDpGetPeriodAnswer();
  void clearDpGetPeriodValue();

  PVSSulong getReqId() const;

  void setProgress(PVSSshort prog);
  PVSSshort getProgress() const;

  void setCond(WaitDpGetSplit *cond);
  WaitDpGetSplit * getCond() const;

  void setLastError(ErrClass *lastError);
  ErrClass* getLastError();

  void setReduSwitch(bool state = true);
  bool getReduSwitch();

  void waitQuery();
  void continueQuery();

private:

  PVSSulong _reqId;  
  MsgType _msgType;
  PVSSshort _progress;
  DynVar* _dpQueryAnswer;
  WaitDpGetSplit *_cond;
  ErrClass *_lastError;
  bool _reduSwitch;

  std::list<DpMsgAnswer*>* messageBuffer; // buffer for the dpGetPeriod answers
};

#endif /* _SPLITTBLENTRY_H_ */
