// DATEIBESCHREIBUNG ==============================================================
// VERANTWORTUNG: Thomas Koroschetz
// BESCHREIBUNG:  
// ======================================Ende======================================

#ifndef _IDPWAIT4ANSWER_H_
#define _IDPWAIT4ANSWER_H_

#ifndef _WAITFORANSWER_H_
#include <WaitForAnswer.hxx>
#endif

class DpMsgAnswer;

/** The internal datapoint answer handler.
    This class handles the ComDrv internal datapoint values like poll state
    and single/general query requests.
    @classification ETM internal
*/
class IDpWait4Answer : public WaitForAnswer
{
public:
  /** The callback function.
      This function will receive answer messages.

      @param answer The answer message received.
     */
  virtual void callBack(DpMsgAnswer &answer);
};

#endif /* _IDPWAIT4ANSWER_H_ */
