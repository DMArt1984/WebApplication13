#ifndef _PVSSTIMEVAR_H_
#define _PVSSTIMEVAR_H_

#include <BCTime.h>
#include <CharString.hxx>
#include <NanoSeconds.hxx>

#include <iostream>
#include <iomanip> 
#include <time.h>
#include <string.h>
#include <math.h>

class  itcNdrUbSend;
class  itcNdrUbReceive;


// ========== PVSSTime ============================================================

/** 
 * This class defines the time used in PVSS II
 * @n It counts seconds and milliseconds from 1.1.1970.
 * @n The counter is used in the derived class AlertTime. Here it is always set to 0.
 */
class DLLEXP_BASICS PVSSTime 
{
  friend DLLEXP_BASICS itcNdrUbSend & operator<<(itcNdrUbSend &ndrStream, const PVSSTime &val);
  friend DLLEXP_BASICS itcNdrUbReceive & operator>>(itcNdrUbReceive &ndrStream, PVSSTime &val);

  public:

    /// Default value and minimum valid value, "00:00:00 Jan 1, 1970 UTC" (UNIX epoch).
    static const PVSSTime ZERO_TIME;
    /// Sometime in the far far future, maximum valid value.
    static const PVSSTime MAX_TIME;

    /// Retrieve current system time (i.e. "now").
    static PVSSTime getSystemTime();

    /** Retrieve the time zone difference between local time and UTC,
     *  without accounting for daylight saving time.
     *
     *  The result is seconds east of UTC,
     *  e.g. UTC+0200 is (2 * 60 * 60) = 7200 seconds
     *  and UTC-0500 is (-5 * 60 * 60) = -18000 seconds.
     *
     *  @return Time zone difference in seconds
     */
    static int getTimeZoneDifference();

    /** constructor, initialize seconds and milliseconds with 0
      */
    PVSSTime() : time_(0), nano_(0), count_(0) {}
    
    /** constructor, initialize the time
        @param newTime the time to initialize with
      */
    IL_DEPRECATED("deprecated, use a other constructor")
    PVSSTime(const time_t newTime);

    /** constructor, initialize the time with milli seconds precision
        @param newTime the time to initialize with
        @param newMilli the milliseconds of the time
      */
    PVSSTime(const time_t newTime, const PVSSlong newMilli);
    
    /** constructor, initialize the time with milli seconds precision by passing a PVSSdouble.
        @param t the time
      */
    PVSSTime(const PVSSdouble t);
    
    // IM 86390: extend send and receive of TimeVar (64 bit, counter)
    /** constructor, initialize the time with nano seconds precision
        @param newTime the time to initialize with
        @param nanoSec the milli seconds of the time
      */
    PVSSTime(const time_t newTime, const NanoSeconds &nanoSec);
    
    /** copy constructor
        @param ti the PVSSTime, which shall be copied from
      */
    PVSSTime(const PVSSTime &ti) : time_(ti.time_), nano_(ti.nano_) , count_(0) {}

    /// assignment operator
    /// @param rVal the PVSSTime to assign
    PVSSTime& operator=(const PVSSTime &rVal); 

    /// add a time
    /// @param rVal the time to add
    /// @return result time
    PVSSTime  operator+(const PVSSTime &rVal) const;

    /// subtract a time
    /// @param rVal the time to subtract
    /// @return result time
    PVSSTime  operator-(const PVSSTime &rVal) const;
   
    /// compare for is equal
    /// @param rVal the PVSSTime to compare with
    int operator==(const PVSSTime &rVal) const;

    /// compare for is not equal
    /// @param rVal the PVSSTime to compare with
    int operator!=(const PVSSTime &rVal) const;

    /// compare for is greater
    /// @param rVal the PVSSTime to compare with
    int operator>(const PVSSTime &rVal) const;

    /// compare for is greater or equal
    /// @param rVal the PVSSTime to compare with
    int operator>=(const PVSSTime &rVal) const;

    /// compare for is less or equal
    /// @param rVal the PVSSTime to compare with
    int operator<=(const PVSSTime &rVal) const;

    /// compare for is less
    /// @param rVal the PVSSTime to compare with
    int operator<(const PVSSTime &rVal) const;

    /** operator << for std stream
        @n Print values on stream using the fixed format "YYYY.MM.DD;hh:mm:ss,ms".
      */
    friend DLLEXP_BASICS std::ostream & operator<<(std::ostream &, const PVSSTime &);

    /** operator >> for std stream
        @n Read value from stream using the fixed format "YYYY.MM.DD;hh:mm:ss,ms".
       */
    friend DLLEXP_BASICS std::istream & operator>>(std::istream &, PVSSTime &);

    /** get the seconds part of the time
        @return the time in seconds
      */
    time_t getSeconds() const;

    /** get the milliseconds part of the time
        @return the time in milliseconds
      */
    IL_DEPRECATED("deprecated, use getMilliseconds() instead")
    PVSSshort getMilli() const { return getMilliseconds(); }
    
    /** get the milliseconds part of the time
        @return the time in milliseconds
      */
    PVSSshort getMilliseconds() const { return (nano_.getValue() / 1000000); }

    // IM 86390: extend send and receive of TimeVar (64 bit, counter)
    /** get the microseconds part of the time
        @return the time in microseconds
      */
    IL_DEPRECATED("deprecated, use getMicroseconds() instead")
    PVSSulong getMicroSeconds() const { return getMicroseconds(); }

    // IM 86390: extend send and receive of TimeVar (64 bit, counter)
    /** get the microseconds part of the time
        @return the time in microseconds
      */
    PVSSulong getMicroseconds() const { return (nano_.getValue() / 1000   ); }
    
    /** get the nanoseconds part of the time
        @return the time in nanoseconds
      */
    IL_DEPRECATED("deprecated, use getNanoseconds() instead")
    PVSSulong  getNanoSeconds() const { return getNanoseconds(); }
    
    /** get the nanoseconds part of the time
        @return the time in nanoseconds
      */
    PVSSulong  getNanoseconds() const { return (nano_.getValue()          ); }

    /// get the time as double in secs.milli
    /// @return the time as double
    PVSSdouble getDouble() const;

    /// set the time
    /// @param newTime the time to set
    void setValue(const PVSSTime &newTime);

    /// set the time with milliseconds precision
    /// @param ti the time to set
    /// @param ms the milliseconds of the time
    void setValue(const time_t ti, PVSSlong ms);

    /// set the time with nanoseconds precision
    /// @param ti the time to set
    /// @param nano the nanoseconds of the time
    void setValue(const time_t ti, const NanoSeconds &nano);

    /// set the seconds part of the time and leave the milliseconds unchanged
    /// @param ti the time to set
    void setSeconds(const time_t ti) { time_ = ti; }

    /** set the fraction of a second of the time to mi milliseconds and adjust the seconds on over/underrun
        @n E.g. time_ = 23; nano_ = 123456789;
        setMilli(-1);
        result: time_ = 22; nano_ = 999000000;
        @param ni the milliseconds to set
      */
    IL_DEPRECATED("deprecated, use setMilliseconds() instead")
    void setMilli(const PVSSlong mi) { setMilliseconds(mi); }

    /** set the fraction of a second of the time to mi milliseconds and adjust the seconds on over/underrun
        @n E.g. time_ = 23; nano_ = 123456789;
        setMilli(-1);
        result: time_ = 22; nano_ = 999000000;
        @param ni the milliseconds to set
      */
    void setMilliseconds(const PVSSlong mi);             // PVSSlong, so we can set e.g. 60,000ms 

    // IM 86390: extend send and receive of TimeVar (64 bit, counter)
    /** set the fraction of a second of the time to nano nanoseconds and adjust the seconds on over/underrun
        @n E.g. time_ = 23; nano_ = 123456789;
        setNanoSeconds(-1);
        result: time_ = 22; nano_ = 999999999;
        @param nano the nanoseconds to set
      */
    IL_DEPRECATED("deprecated, use setNanoseconds() instead")
    void setNanoSeconds(const PVSSlong nano) { setNanoseconds(nano); }

    // IM 86390: extend send and receive of TimeVar (64 bit, counter)
    /** set the fraction of a second of the time to nano nanoseconds and adjust the seconds on over/underrun
        @n E.g. time_ = 23; nano_ = 123456789;
        setNanoSeconds(-1);
        result: time_ = 22; nano_ = 999999999;
        @param nano the nanoseconds to set
      */
    void setNanoseconds(const PVSSlong nano);

    /// increment the fraction of a second with nano nano seconds, adjust the seconds on over/underrun
    /// @param nano the nanoseconds to increment
    void incNanoSeconds(const PVSSlong nano);             

    /** set time given as double as secs.milli.
        @n WARNING: this method does not work with more than 3 fractional digits.
        @param t the time to set
      */
    void setDouble(const PVSSdouble t);

    /** take and set current time
      */
    IL_DEPRECATED("obsolete, use getSystemTime() instead")
    void setCurrentTime();

    /** return the time in standard PVSS format YYYY.MM.DD HH:MM:SS.mmm
        @param inUTC if given as false, represents the time in the local timezone
               otherwise represents the time in UTC timezone
        @return the CharString as result
    */
    CharString toString(bool inUTC = false) const;

    tm toTm(const bool inUTC /* = false */) const;

    /** Tell if date and time value falls between the boundaries provided.
    *  (Boundaries included.)
    *
    *  @param t1 [in] Left boundary of date and time interval
    *  @param t2 [in] Right boundary of date and time interval
    *
    *  @return True if the date and time value falls between the boundaries
    */
    PVSSboolean isBetween(const PVSSTime& t1, const PVSSTime& t2) const { return (t1 <= *this && t2 >= *this); }

  protected:
    /// set nanoseconds
    /// @param nano the nanoseconds to set
    void setNano(const NanoSeconds nano);

    /// set nanoseconds as PVSSlonglong
    /// @param nano the nanoseconds to set
    void setLLNano(const PVSSlonglong nano);             
    
  protected:
    /// seconds since 1.1.1970
    time_t time_;

    /// nanoseconds (0..999 999 999)
    NanoSeconds nano_;
  
    /// counter, used in AlertTime only
    PVSSushort  count_;
};


// -----------------------------------------------------------------------------------------
// inlines
// -----------------------------------------------------------------------------------------

inline  void PVSSTime::setMilliseconds(const PVSSlong newMilli) 
{
  setLLNano(PVSSlonglong(newMilli) * 1000000LL);
}

//--------------------------------------------------------------------------------

inline  void PVSSTime::setNanoseconds(const PVSSlong _nano) 
{
  setLLNano(PVSSlonglong(_nano));
}


//--------------------------------------------------------------------------------

inline  void PVSSTime::incNanoSeconds(const PVSSlong _nano) 
{
  setNano(nano_ + NanoSeconds(_nano));        // on overrun this increments time_
}

//--------------------------------------------------------------------------------

inline  void PVSSTime::setValue(const PVSSTime &newTime)  
{ 
  time_ = newTime.time_; 
  nano_ = newTime.nano_; 
}

//--------------------------------------------------------------------------------

inline  void  PVSSTime::setValue(const time_t t, const PVSSlong m)
{
  time_ = t;
  setMilliseconds(m);
}

//--------------------------------------------------------------------------------

inline  void  PVSSTime::setValue(const time_t t, const NanoSeconds &_nano)
{
  time_ = t;
  setNano(_nano);
}

//--------------------------------------------------------------------------------

inline  PVSSTime::PVSSTime(const time_t newTime)
  : time_(newTime), count_(0)
{
}

//--------------------------------------------------------------------------------

inline  PVSSTime::PVSSTime(const time_t newTime, const PVSSlong newMilli)
  : time_(newTime), count_(0)
{
  // Use the function setMilli to adjust for values out of range
  if (newMilli != 0)
    setMilliseconds(newMilli);
}

//--------------------------------------------------------------------------------

inline  PVSSTime::PVSSTime(const time_t _newTime, const NanoSeconds &_nano)
                : time_(_newTime), count_(0)
{
  // Use the function set to adjust for values out of range
  setNano(_nano);
}

//--------------------------------------------------------------------------------

inline PVSSTime::PVSSTime(const PVSSdouble t)
  : count_(0)
{
  setDouble(t);
}

//--------------------------------------------------------------------------------

inline  PVSSTime & PVSSTime::operator=(const PVSSTime &rVal)
{
  if (this == &rVal)
    return *this;

  time_ = rVal.time_;
  nano_ = rVal.nano_;

  return *this;
}

//--------------------------------------------------------------------------------

inline  int  PVSSTime::operator==(const PVSSTime &rVal) const
{
  return (time_ == rVal.time_) && (getMilliseconds() == rVal.getMilliseconds());
}

//--------------------------------------------------------------------------------

inline  int  PVSSTime::operator!=(const PVSSTime &rVal) const
{
  return !operator==(rVal);
}

//--------------------------------------------------------------------------------

inline  int  PVSSTime::operator>(const PVSSTime &rVal) const
{
  return ((time_ > rVal.time_) || ((time_ == rVal.time_) && (getMilliseconds() > rVal.getMilliseconds())));
}

//--------------------------------------------------------------------------------

inline  int  PVSSTime::operator<(const PVSSTime &rVal) const
{
  return ((time_ < rVal.time_) || ((time_ == rVal.time_) && (getMilliseconds() < rVal.getMilliseconds())));
} 

//--------------------------------------------------------------------------------

inline  int  PVSSTime::operator>=(const PVSSTime &rVal) const
{
  return !operator<(rVal);
}

//--------------------------------------------------------------------------------

inline  int  PVSSTime::operator<=(const PVSSTime &rVal) const
{
  return !operator>(rVal);
}

//--------------------------------------------------------------------------------

inline  PVSSTime  PVSSTime::operator+(const PVSSTime &rVal) const
{
  // Constructor normalizes
  PVSSTime ret(time_ + rVal.time_, nano_ + rVal.nano_);  
  if ( ret.time_ < 0 )  // overflow occured
  {
    ret = PVSSTime(MAX_TIME_VAR_SEC, MAX_TIME_VAR_MSEC);
  }
    
  return ret;
}

//--------------------------------------------------------------------------------

inline  PVSSTime  PVSSTime::operator-(const PVSSTime &rVal) const
{
  // No negative values
  if (*this < rVal)
    return PVSSTime(0, 0);
    
  PVSSTime res(time_ - rVal.time_, nano_ - rVal.nano_);
  
  return(res);
}

//--------------------------------------------------------------------------------

inline time_t PVSSTime::getSeconds() const      
{ 
  return (time_); 
}

//--------------------------------------------------------------------------------

inline  std::ostream & operator<<(std::ostream &os, const PVSSTime &rVal)
{
  BC_CTime  tmp(rVal.time_); 

  return os << std::setw(4) << std::setfill('0') << tmp.Year() << '.'
            << std::setw(2) << std::setfill('0') << tmp.Month() << '.'
            << std::setw(2) << std::setfill('0') << tmp.Day()   << ';'
            << std::setw(2) << std::setfill('0') << tmp.Hour()  << ':'
            << std::setw(2) << std::setfill('0') << tmp.Minute() << ':'
            << std::setw(2) << std::setfill('0') << tmp.Second() << ':'
            << std::setw(3) << std::setfill('0') << (rVal.getMilliseconds());
}

//--------------------------------------------------------------------------------

inline std::istream & operator>>(std::istream &is, PVSSTime &rVal)
{
  BC_CTime  tmp;
  struct tm t;
  PVSSlong ms;
  char    sep;

  memset(&t, 0, sizeof(struct tm));
 
  is >> t.tm_year >> sep >> t.tm_mon >> sep >> t.tm_mday >> sep
     >> t.tm_hour >> sep >> t.tm_min >> sep >> t.tm_sec  >> sep
     >> ms;

  // Adjust values in struct
  if (t.tm_year < 70)         // 2 digit Y2k
    t.tm_year += 100;         
  else if (t.tm_year < 100)   // 2-digit Y1.9k
    ;
  else                        // 4-digit year
    t.tm_year -= 1900;

  t.tm_mon -= 1;              // Counts 0..11
  t.tm_isdst = -1;            // Calculate DST

  rVal.setValue(mktime(&t), ms);

  return is;
}

//--------------------------------------------------------------------------------

inline PVSSdouble PVSSTime::getDouble() const
{
  return static_cast<PVSSdouble>(time_) + (getMilliseconds() / 1000.0);
}

//--------------------------------------------------------------------------------

inline void PVSSTime::setDouble(const PVSSdouble t)
{
#ifdef WIN32
  if (isnan(t))
  { 
    time_ = 0;
    nano_ = NanoSeconds();
  }
  else
  {
#endif
    time_ = (t > MAX_TIME_VAR_SEC) ? MAX_TIME_VAR_SEC : static_cast<time_t>(t);
    setMilliseconds(static_cast<PVSSlong>(((t - floor(t)) + 0.00005) * 1000));
#ifdef WIN32
  }
#endif
}

//--------------------------------------------------------------------------------

inline void PVSSTime::setNano(const NanoSeconds _nano)
{
  time_t sec;
  nano_ = NanoSeconds(PVSSlong(NanoSeconds::normalize(_nano.getValue(), sec)));
  time_ += sec;

#ifdef WIN32
  if (time_ < 0)
  {
    time_ = time_t(-1);
    nano_ = NanoSeconds(0);
  }
#endif
}

//--------------------------------------------------------------------------------

inline void PVSSTime::setLLNano(const PVSSlonglong _nano)
{
  time_t sec;
  nano_ = NanoSeconds(PVSSlong((NanoSeconds::normalize(_nano, sec))));
  time_ += sec;

#ifdef WIN32
  if (time_ < 0)
  {
    time_ = time_t(-1);
    nano_ = NanoSeconds(0);
  }
#endif
}

//--------------------------------------------------------------------------------

#endif
