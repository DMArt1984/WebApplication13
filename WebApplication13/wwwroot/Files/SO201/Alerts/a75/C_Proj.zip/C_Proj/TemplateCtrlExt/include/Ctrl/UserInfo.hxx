#ifndef _USER_INFO_H_
#define _USER_INFO_H_

#include <wchar.h>
#include <CharString.hxx>

//-----------------------------------------------------------------
/** @author Markus Schwarz */
/** Wrapperclass for wchar_t* */

class MyWChar_t
{
  public:
    //@param s String that will be copied and converted to a wchar_t* string and encapsulated in this class.
    MyWChar_t(const char *s);

    // Copy constructor
    MyWChar_t(const MyWChar_t &obj);

    //frees the data member ws.
    ~MyWChar_t();

    //@return Returns the data member ws.
    operator wchar_t* ();

    //@param ws String that will be copied and converted to a CharString object.
    //@return Returns a CharString object which is made out of a copy and convertion from the ws parameter.
    static CharString WChar_tToCharString(const wchar_t *ws);

  private:
    // The wchar_t* to be encapsulated in this class.
    wchar_t* ws;
};

//--------------------------------------------------------------------------------

class DynVar;

namespace UserInfo
{
  int VerifyUser(const DynVar &in, DynVar &out);
  int GetUsersList(const DynVar &in, DynVar &out);
  int QueryUserInformation(const DynVar &in, DynVar &out);
  int Connect(const DynVar &in, DynVar &out);
}

#endif
