// -----------------------------------------------------------------
// MsgVersion.hxx
// creator: Andreas Pfluegl at 06.02.06
// purpose: PVSS II Msg Version constants
// -----------------------------------------------------------------
// history:
// 20yy-mm-dd:  <Name> N            ( B O C X )
// -----------------------------------------------------------------
#ifndef _MSGVERSION_H_
#define _MSGVERSION_H_

#define PVSS_3_0_1              0x0301      // With start of PVSS II 3.0
#define PVSS_3_5_0              0x0350      // PVSS II 3.5
#define PVSS_3_8_0              0x0380      // PVSS II 3.8
#define PVSS_3_9_0              0x0390      // PVSS II 3.9
#define PVSS_3_10_0             0x03A0      // PVSS II 3.10
#define PVSS_3_11_0             0x03B0      // PVSS 3.11
#define PVSS_3_11_1             0x03B1      // PVSS 3.11.1
#define PVSS_3_12_0             0x03C0      // PVSS 3.12
#define PVSS_3_12_1             0x03C1      // PVSS 3.12.1 (dpRename)
#define PVSS_3_13_0             0x03D0      // PVSS 3.13
#define PVSS_3_13_1             0x03D1      // PVSS 3.13.1 (dpRename)
#define PVSS_3_14_0             0x03E0      // PVSS 3.14
#define PVSS_3_15_0             0x30F0      // PVSS 3.15 (change bit-encoding of format!)
#define PVSS_3_16_0             0x3100      // PVSS 3.16
#define PVSS_3_17_0             0x3110      // PVSS 3.17
#define PVSS_3_17_1             0x3111      // PVSS 3.17.1 (bug with language order in initMsg in 3.17.0)

#define PVSS_II_MSG_VERSION     PVSS_3_17_1
#endif

