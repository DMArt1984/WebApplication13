//
//  $RCSfile$
//  $Date$
//  $Revision$
//  $Author$
//  $Locker$
//  $State$
//  $Source$
//
// %Z%JESSI-COMMON-FRAMEWORK 2.0
// %Z%Copyright (C) by Siemens Nixdorf Informationssysteme AG 1992
// %Z%Copyright (C) by Universitaet GH Paderborn 1992
// %Z%Development of this software was partially funded by ESPRIT project 7364.
// %Z%BCM %M% %I% %E%

#ifndef ItcMsgHdr_H
#define ItcMsgHdr_H

//#ifdef __GNUG__
//#pragma interface
//#endif

#define USES_string

#include "ItcNDR.h"
#include "ItcMsgHeader.def"
#include "ItcPrelude.h"

const size_t 	NameBufSize = 32; // size of name buffer (sender & receiver)

// ========== itcMsgHdr ============================================================

/** This class ensures message header
    @classification ETM internal
  */
class DLLEXP_BCM itcMsgHdr : public itcXNDR {

public:
  
  /// message types
  enum itcMsgType { 
		MsgDefault      = 0,
		MsgNotification = 10,
		MsgRequest      = 11,
		MsgReply        = 12,
		RpcRequest      = 20,
		RpcReply        = 21,
		OpaqueData      = 30,
		VisibleData     = 31
	};

	/// read message type from itcNDRReceive stream
  /// @param ndr the input stream
  /// @param type the message type
  /// @return itcNDRReceive stream.
 	friend DLLEXP_BCM itcNDRReceive &operator>>(itcNDRReceive &ndr, itcMsgType &type);
	// Von ETM eingef�gt

	/// read message type from itcNdrUbReceive stream
  /// @param ndr the input stream
  /// @param type the message type
  /// @return itcNdrUbReceive stream.
  friend DLLEXP_BCM itcNdrUbReceive &operator>>(itcNdrUbReceive &ndr, itcMsgType &type);

  /// default constructor
  itcMsgHdr();

  /// param constructor
  /// @param nbr the message number
  /// @param tp the message type
  /// @param sdr the message sender
  /// @param rcvr the message receiver
  /// @param nop the number of params
  /// @param ol the opaque length
  /// @param rf the RPC function
  /// @param irt the in reply to
 	itcMsgHdr(int nbr, itcMsgType tp, char *sdr, char *rcvr, int nop, 
		  int ol, int rf, int irt);

  /// send to external
  /// @param ndr the output stream
  virtual void to_external(itcNDRSend &ndr) const;

  /// receive from internal
  /// @param ndr the input stream
	virtual void to_internal(itcNDRReceive &ndr);

  /// get message number
	int    	    getNumber() { return number; };

  /// get message type
	itcMsgType  getType() { return type; };

  /// get message sender
  char * 	    getSender() { return sender; };

  /// get message receiver
  char * 	    getReceiver() { return receiver; };

  /// get number of params
  int    	    getNumOfParam() { return nbr_of_param; };

  /// get opaque length
	int    	    getOpaqueLength() { return opaque_length; };

  /// get RPC function
	int    	    getRpcFunc() { return rpc_func; };

  /// get in reply to
	int    	    getInReplyTo() { return in_reply_to; };
	
  /// set message number
  /// @param nbr the value to set
	void   	setNumber(const int &nbr) { number = nbr; };

  /// set message type
  /// @param tp the value to set
	void   	setType(itcMsgType tp) { type = tp; };
	
  /// set message sender
  /// @param sdr the value to set
  void   	setSender(const char *sdr) { 
		    strncpy (sender, sdr, NameBufSize);
		    size_t l = strlen (sdr);
		    if (l >= NameBufSize) sender[NameBufSize - 1] = '\0';
		};

  /// set message receiver
  /// @param rcvr the value to set
  void   	setReceiver(const char *rcvr) { 
		    strncpy (receiver, rcvr, NameBufSize);
		    size_t l = strlen (rcvr);
		    if (l >= NameBufSize) receiver[NameBufSize - 1] = '\0';
		};
  
  /// set number of params
  /// @param nop the value to set
  void   	setNumOfParam(const int &nop) { nbr_of_param = nop; };

  /// set opaque length
  /// @param ol the value to set
  void   	setOpaqueLength(const int &ol) { opaque_length = ol; };

  /// set RPC function
  /// @param rf the value to set
  void   	setRpcFunc(const int &rf) { rpc_func = rf; };

  /// set in reply to
  /// @param irt the value to set
  void   	setInReplyTo(const int &irt) { in_reply_to = irt; };

	/// clear all
  void   	clearAll() {
        	number		= 0;
		type		= MsgDefault;
		sender[0]	= '\0';
		receiver[0]	= '\0';
		nbr_of_param	= 0;
		opaque_length	= 0;
		rpc_func	= 0;
		in_reply_to	= 0;
		};

private:
	// implementation
        int    		number;
	itcMsgType	type;
	char 		sender[NameBufSize];
	char  		receiver[NameBufSize];
	int		nbr_of_param;
	int		opaque_length;
	int		rpc_func;
	int		in_reply_to;
};

#endif /* ItcMsgHdr_H */
