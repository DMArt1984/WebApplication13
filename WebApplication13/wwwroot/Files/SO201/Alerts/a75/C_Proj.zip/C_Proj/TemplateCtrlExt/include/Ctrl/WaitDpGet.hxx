#ifndef _WAITDPGET_H_
#define _WAITDPGET_H_

#include <WaitDpVC.hxx>
#include <Types.hxx>

class CtrlScript;
class CtrlThread;
class ExprList;
class DpHLGroup;
class AlertAttrList;
class DpMsgAnswer;
class DpMsgHotLink;
class ConnTblEntry;
class WaitForAnswer;
class DynVar;
class TimeVar;


/*  author VERANTWORTUNG: Martin Koller                                  */
/** class handles the wait for a response of a dpGet(), etc.*/
class DLLEXP_CTRL WaitDpGet : public WaitDpVC
{
  public:
    /** constructor for dpGet - command.
      *
      * @param theThread IN: thread der wartet bis antwort eintrifft.
      *                      thread wird nicht frei gegeben.
      * @param argList   IN: (deep copy) parameterliste
      * @paran dyn       IN: (deep copy) if dyn == 0, it means every arg is a non-dyn-type
      *                      else, the dyn must hold for every arg the number of items
      * @param asynch    IN:
      */
    WaitDpGet(CtrlThread *theThread, ExprList *argList, DynVar *dyn = 0,
              PVSSboolean asynch = PVSS_FALSE);

    /** constructor for dpConnect
      * @param aScript   IN: CtrlScript das beim eintreffen des Hotlink
      *                      gestartet wird. Script wird nicht frei gegeben
      * @param theThread IN: thread der wartet bis antwort eintrifft.
      *                      thread wird nicht frei gegeben.
      * @param aEntry    IN: ConnTblEntry ist mit der work function verbunden
      *                      die beim eintreffen des HL gestartet wird.
      *                      wird nicht frei gegeben
      */
    WaitDpGet(CtrlScript *aScript, CtrlThread *aThread, ConnTblEntry *aEntry);

    /// destructor
    virtual ~WaitDpGet();

    /// wann soll thread das naechste mal ausgefuehrt werden.
    virtual const TimeVar &nextCheck() const;
    /** antwort fuer dpGet, Query ist eingetroffen.
      * WaitCond kann ab nun freigegeben werden.
      */
    virtual int checkDone();
    /// HotLink ist eingetroffen
    virtual int hotLinkDone();


    /** @name response ist eingetroffen.
      * all errors in the response message are given to the
      * assoziated thread
      */
    //@{
    ///
    void dpGetConnectResponse(DpMsgAnswer &answer);
    ///
    void dpGetResponse(DpMsgAnswer &answer);
    ///
    virtual void dpGetPeriodResponse(DpMsgAnswer &msg);
    ///
    virtual void alertGetPeriodResponse(DpMsgAnswer &msg);
    ///
    void alertConnectResponse(DpMsgAnswer &answer);
    ///
    void dpManipResponse(DpMsgAnswer &answer);
    ///
    void dpAliasResponse(DpMsgAnswer &answer);
    ///
    virtual void dpQueryResponse(DpMsgAnswer &answer);
    ///
    void dpQueryConnectResponse(DpMsgAnswer &answer);
    ///
    void dpQueryDisconnectResponse(DpMsgAnswer &answer);
    ///
    void dpSysMsgResponse(DpMsgAnswer &answer);
    //@}

    /** @name this is for a waiting dpSet */
    //@{
    ///
    void dpSetResponse(DpMsgAnswer &answer);
    ///
    void dpValueChangedResponse(DpHLGroup &hlGroup);
    ///
    void dpQueryValueChangedResponse(DpHLGroup &hlGroup);
    ///
    void alertValueChangedResponse(AlertAttrList &group);
    ///
    void setWaitForAnswer(WaitForAnswer *wait) { waitForAnswer = wait; }
    ///
    WaitForAnswer *getWaitForAnswer() const { return waitForAnswer; }
    //@}

    /** thread nach eintreffen der HL-antwort restarten.
      * HotLink Verwaltung in der Manager Klasse ->
      * die WaitCond darf nicht freigegeben werden.
      * um den thread der dpConnect aufrief wieder zu erwecken muss
      * das flag hotLinDone auf PVSS_TRUE gesetzt werden.
      */
    void awakeThread();

    /**
      */
    void setThread(CtrlThread *t) { thread = t; }

    // Overloaded from WaitDpVC, never called
    virtual void dpValueChanged(const DpHLGroup &group) {};

    // called on redu change
    virtual PVSSboolean needRefresh() { return PVSS_TRUE; }

  protected:
    CtrlScript *script;
    CtrlThread *thread;
    ExprList *args;       // pointer to arguments of FCall-sment
    DynVar *dynLen;       // for a dpGet with dyn_* types, this holds the ArrayLength() of the dyn_*
    ConnTblEntry *entry;  // pointer to dpConnect Entry
    int doneFlag;
    int hotLinkDoneFlag;
    WaitForAnswer *waitForAnswer;
    PVSSboolean isAsynch;

  private:
    bool collectParamsToList(DpIdValueList& vallist);
    void processCollectedParams(DpMsgAnswer &msg, const DpIdValueList& vallist, DynVar& dynTime, DynVar& dynInt);
};

#endif /* _WAITDPGET_H_ */
