#ifndef _CTRLMODULE_H_
#define _CTRLMODULE_H_

#include <Types.hxx>
#include <PtrListItem.hxx>
#include <ExecReturn.hxx>
#include <SmentWeight.hxx>

class CtrlScript;
class CharString;
class DpHLGroup;
class DpMsgAnswer;
class CMWaitForAnswer;
class DpIdentifier;
class TimeVar;

//--------------------------------------------------------------------------------

/*  author Martin Koller */
/** base class for modules in ctrl which do a specific work in compiled form.
  * They act like a compiled CTRL thread, which means
  * functionality implemented in C++
  * e.g. operatingHours, HTTP Server, timed function, etc.
  */
class DLLEXP_CTRL CtrlModule : public PtrListItem
{
  public:
    /// CtrlScript from where this module was started
    CtrlModule(CtrlScript *fromScript);
    /// Destructor
    virtual ~CtrlModule();

    /// tells, if this object could work properly; returns the okFlag
    PVSSboolean startAllowed() const { return okFlag; }

    /** starts the functionality.
        returns EXEC_OK if the module continues its work,
        EXEC_DONE if it has already completed and
        EXEC_ERROR if it failed to start
      */
    virtual ExecReturn start() = 0;

    /// tells, when we have to call work() at the latest again
    virtual const TimeVar &nextWork() const = 0;

    /// give the module time to work
    virtual ExecReturn work(PVSSlong micro) = 0;

    /// a Hotlink has arrived handle it
    virtual void dpValueChanged(const DpHLGroup &dpGroup);

    /// the answer for a dpGet has arrived
    virtual void handleAnswer(DpMsgAnswer &answer, int clientData);

    /// not implemented in this base class
    virtual void clearWaitForAnswer(CMWaitForAnswer *wait, int clientData);

    /// returns SM_WT_ExtraHigh by default
    virtual SmentWeight getWeight() const { return SM_WT_ExtraHigh; }

    /// return the className as RTTI information
    virtual const char* className() const { return "CtrlModule"; }

  protected:
    PVSSboolean checkDP(const CharString &name, DpIdentifier &dpId, const char* func);

    /// pointer back to the script from which this module was started and is handled from
    CtrlScript *script;

    /// flag which is returned by startAllowed(), defaults to PVSS_TRUE
    PVSSboolean okFlag;
};

#endif /* _CTRLMODULE_H_ */
