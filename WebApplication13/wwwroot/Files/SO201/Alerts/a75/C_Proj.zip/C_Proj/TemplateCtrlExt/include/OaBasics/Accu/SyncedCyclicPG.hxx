#ifndef _SYNCEDCYCLICPG_H_
#define _SYNCEDCYCLICPG_H_

#ifndef _PERIODGENERATOR_H_
#include <PeriodGenerator.hxx>
#endif

#ifndef _NEXTVALIDTIME_H_
#include <NextValidTime.hxx>
#endif

// ========== SyncedCyclicPG ============================================================

/** synced cyclic period generator
    @n This class generates cyclic periods of given time interval within
    certain validity period of given validity time interval.
    A sync time meeting conditions can be specified.

    Example:

    x____0____x____1____x__2__x____3_____x____4_____x___#____x

    ______F___^_______________^_________________________U___________

    symbols:
    @n x__n__x  period with number n = 0, 1, 2...   x marks start and end
    @n x__#__x  the last period, considered invalid
    @n ___F___  validity period from
    @n ___U___  validity period until
    @n ___^___  sync time meeting conditions aMonthList - aDayTimeList, conditions interpreted like in NextValidListTime
 
    @classification ETM internal
*/
class DLLEXP_OABASICS SyncedCyclicPG : public PeriodGenerator
{
  public:
    /// constructor, initialisation with zero values
    SyncedCyclicPG();
    
    /** set conditions of the intermittently active period generator
        @param aStartTime the starting time of generation
        @param aMonth the month to sync
        @param aMonthDay the day of month to sync
        @param aWeekDay the day of week to sync
        @param aDayTime the time to sync
        @param aInterval the time interval of cyclic periods
            @n 0 ... 3600 is used as interval.
        @param aValidFrom the starting time of validity period
            @n If NullTimeVar, then the first period ends at aStartTime.
        @param aValidUntil the ending time of validity period
            @n If NullTimeVar, then periods never get invalid (may work forever).
        @return PVSS_TRUE if everything is OK, else PVSS_FALSE 
      */
    PVSSboolean setConditions( const TimeVar &aStartTime,
                               PVSSshort aMonth,
                               PVSSshort aMonthDay,
                               PVSSshort aWeekDay,
                               PVSSulong aDayTime,
                               PVSSulong aInterval,
                               const TimeVar &aValidFrom = TimeVar::NullTimeVar,
                               const TimeVar &aValidUntil = TimeVar::NullTimeVar );
    
    /** go to the next period
        @return PVSS_TRUE if within given validity period, else PVSS_FALSE 
      */
    virtual PVSSboolean goNextPeriod();
    
  protected:

  private:
    // so that the compiler does not define them itself !!

    // copy constructor
    SyncedCyclicPG(const SyncedCyclicPG &) {} //COVINFO LINE: defensive (AP: disallow copy ctor)
    // assignment operator
    SyncedCyclicPG &operator=(const SyncedCyclicPG &) { return *this; } //COVINFO LINE: defensive (AP: disallow operator=)

    void initialize( const TimeVar &aStartTime );
    
    NextValidTime myNextTrigger;
    TimeVar validFrom;
    TimeVar validUntil;
    
    TimeVar nextSync;
    PVSSulong interval;
};

#endif /* _SyncedCyclicPG_H_ */
