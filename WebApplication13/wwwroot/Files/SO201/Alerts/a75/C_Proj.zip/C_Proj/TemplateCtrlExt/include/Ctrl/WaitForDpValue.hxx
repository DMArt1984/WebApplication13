#ifndef _WAITFORDPVALUE_H_
#define _WAITFORDPVALUE_H_

#include <WaitDpVC.hxx>
#include <DynVar.hxx>
#include <Variable.hxx>
#include <TimeoutTimer.hxx>
#include <DpIdentList.hxx>
#include <CharString.hxx>
#include <DpMsgAnswer.hxx>
#include <HotLinkWaitForAnswer.hxx>

class DpWaitForAnswer;
class WaitForDpValue;
class ConnTblEntry;
class CtrlThread;


/*  author VERANTWORTUNG: Milos Marusiak        */
/** Warte bis ein DP einen bestimmten wert erreicht hat.
  *               baue dazu eine HotLink-verbindung auf und beende
  *               das warten, wenn der gewuenschte wert eintrifft
  */
class DLLEXP_CTRL DpWaitForAnswer : public HotLinkWaitForAnswer
{
  public:
    /// WaitDpGet muss einen valid ConnTblEntry haben
    DpWaitForAnswer(WaitForDpValue *obj) :object(obj) {}
    /// Destruktor
    virtual ~DpWaitForAnswer(); 
    /// Bisheriger CallBack 
    // virtual void callBack(DpMsgAnswer &) {}
    /// HotLink Callback startet Thread und fuehrt work Function aus
    virtual void hotLinkCallBack(DpMsgAnswer &answer);
    /// HotLink Callback startet Thread und fuehrt work Function aus
    virtual void hotLinkCallBack(DpHLGroup &group);
    /// entferne ref auf WaitForDpValue
    void clearObject() { object = 0; }

  protected:

  private:
    WaitForDpValue *object;  // we do not delete this on destruction
};


/*  author VERANTWORTUNG: Milos Marusiak        */
class DLLEXP_CTRL WaitForDpValue : public WaitDpVC
{
  public:
    /// Disconnect an existing Hotlink 
    ~WaitForDpValue();
    /** Waitobjetct: Warte bis DP einen bestimmten wert hat.
      * @param theThread   IN: thread der warten muss. wird nicht frei gegeben!
      * @param dpNamesWait IN: datenpunkte auf die gewartet wird
      * @param cond        IN: werte die die datenpunkte dpNamesWait annehmen muessen
      * @param result      IN/OUT: resultliste wird nur veraendert wenn alle 
      *                            datenpunkte die geforderten werte angenommen haben.
      * @param time        IN: timeout. wielange soll gewartet werden?
      */
    WaitForDpValue( CtrlThread *theThread,
                    const DynVar &dpNamesWait,
                    const DynVar &cond,
                    const DynVar &dpNamesReturn,
                    DynVar *result,
                    const TimeVar &time, 
                    BitVar *timerExpired,
                    Variable *extReturnVar = 0
                  );

    /// Get the WaitForAnswer object
    virtual WaitForAnswer * getWaitForAnswer() const { return object_; }
    /// wann soll der thread das naechste mal geprueft werden ?
    virtual const TimeVar &nextCheck() const;
    /// thread darf WaitCond frei geben (antwort eingetroffen)
    virtual int checkDone();

    /// empfange letztwerte der DPs (antwort auf connect)
    virtual void handleAnswer(DpMsgAnswer &answer);
    /// empfange werteaenderungen (hotLinks)
    void dpValueChanged(const DpHLGroup &group);
    /** setze ConnTblEntry und fuehre ein dpConnect durch
      * @param theEntry IN: wird nicht frei gegeben
      */
    void connect(ConnTblEntry *theEntry);

//    void timerExpired();
    /// Information: auf welche datenpunte wartet das WaitObject
    const DpIdentList &getDpIdentList() {return dpList;}

    void clearObject() {object_ = 0;}
    /// PVSS_TRUE: WaitObject ist valid.
    PVSSboolean okFlag;
  protected:

  private:
    PVSSboolean checkDp(const CharString &dpName, VariableType vtype, DpIdentList &idList);
    void appendToDpList(DpIdentifier &dp);
    void setValue(const Variable *var, const DpIdentifier &dp, DynVar &dpValues, DpIdValueList *dpIdValueReturnList);
    void setReturnValues( DynVar *target, const DpIdValueList &dpIdList);

    DpIdentList dpList, dpNamesList, dpReturnList;
    PVSSboolean done;
    DynVar conditions, origValues;
    DynVar *returnValues;
    Variable *returnValue;
    TimeoutTimer timer;
    CtrlThread *thread;
    ConnTblEntry *entry;
    PVSSboolean ready;
    BitVar *pTimerExpired;

    DpWaitForAnswer *object_;

};

#endif /* _WAITFORDPVALUE_H_ */
