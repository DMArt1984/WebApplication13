#ifndef _CODEPOINT_H_
#define _CODEPOINT_H_

#include <iostream>

class CharString;
class itcNdrUbSend;
class itcNdrUbReceive;

/// Holds one Unicode code point
class DLLEXP_BASICS Codepoint
{
  public:
    /** Returns whether the given byte is the leading byte of a valid
     *  UTF-8 multi-byte-sequence
     */
    static bool isLeadingByte(unsigned char byte) {return ((byte & 0xC0) == 0xC0) && ((byte & 0xF8) != 0xF8);}

    /** Returns whether the given byte is the trailing byte of a valid
     *  UTF-8 multi-byte-sequence
     */
    static bool isTrailingByte(unsigned char byte) {return (byte & 0xC0) == 0x80;}

    /// Returns whether the given byte is a valid US-ASCII character
    static bool isAsciiByte(unsigned char byte) {return (byte & 0x80) == 0x00;}

    /** This value indicates the maximum code point value to fit into a
     *  single-byte UTF-8 sequence
     */
    static const unsigned long MAX_ONE_BYTE_UTF8 = 0x7F;

    /** This value indicates the maximum code point value to fit into a
     *  two-byte UTF-8 sequence
     */
    static const unsigned long MAX_TWO_BYTE_UTF8 = 0x7FF;

    /** This value indicates the maximum code point value to fit into a
     *  three-byte UTF-8 sequence
     */
    static const unsigned long MAX_THREE_BYTE_UTF8 = 0xFFFF;

    /** This value indicates the code point value for the Unicode standard
     *  replacement character for otherwise unrecognized code points
     */
    static const unsigned long REPLACEMENT_CHARACTER = 0xFFFD;

    /** The maximum number of corresponding code points for a single code point in a case conversion
     *  @see toUpper(Codepoint*), toLower(Codepoint*)
     */
    static const unsigned long CASE_CONVERSION_MAX_COUNT = 3;

  public:
    /// default constructor
    Codepoint() : value(0) {}

    /// constructor taking a code point value
    Codepoint(unsigned long val);

    /** Constructor that decodes a UTF-8 string into a code point. If the input
     *  string is not valid UTF-8, this code point is set to the Unicode
     *  Replacement Character and an error is raised via ErrHdl.
     * @param utf8_val the buffer to read from, must not be 0
     */
    Codepoint(const char* utf8_val) : value(0) {operator=(utf8_val);}

    /// copy constructor
    Codepoint(const Codepoint& val) : value(val.value) {}

    /// copy operator
    Codepoint& operator=(const Codepoint& val) {this->value = val.value; return *this;}

    /// Sets this code point to the given index in the Unicode table
    Codepoint& operator=(unsigned long val) {this->value = val; return *this;}

    /** Assignment operator that decodes a UTF-8 string into a code point.
     *  If the input string is not valid UTF-8, this code point is set to the
     *  Unicode Replacement Character and an error is raised via ErrHdl.
     * @param utf8_val the buffer to read from, must not be 0
     * @return a reference to this Codepoint object
     */
    Codepoint& operator=(const char* utf8_val) {fromUtf8(utf8_val); return *this;}

    /// Returns the index of this code point in the Unicode table
    operator unsigned long() const {return value;}

    /** Returns the length in bytes for UTF-8 encoding of this code point
     * @return length in bytes for UTF-8 encoding of this code point
     * @remark when this Codepoint was constructed with Codepoint(const char*),
     *         operator=(const char*) or fromUtf8(const char*), and the code point
     *         value is REPLACEMENT_CHARACTER, the return value of this method
     *         might not indicate the number of bytes read from due to possibly incorret
     *         encoding. Only fromUtf8(const char*) provides information about the
     *         actual number of bytes read.
     */
    size_t utf8ByteCount() const;

    /** Decodes a UTF-8 string into a code point. If the input string is not
     *  valid UTF-8, this code point is set to the Unicode Replacement
     *  Character and an error is raised via ErrHdl
     * @param src a buffer containing a UTF-8 encoded string, must not be 0
     * @return the number of bytes actually read (this number is correct
     *         even in case of failure)
     */
    size_t fromUtf8(const char* src);

    /** Encodes this code point as UTF-8 byte array. This method does not append
     *  an ASCII-NUL byte.
     * @param[out] dest a buffer of at least size utf8ByteCount(), must not be 0
     * @return the number of bytes written
     */
    size_t toUtf8(char* dest) const;

    /** Sets the given CharString to the UTF-8 encoding of this code point
     * @param[out] dest a CharString, whose content shall be replaced by
     *                  a UTF-8 encoding of this code point
     * @return the number of bytes written
     */
    size_t toUtf8(CharString& dest) const;

    /** Appends the UTF-8 encoding of this code point to the given CharString
     * @param[out] dest a CharString, where a UTF-8 encoding of this code point
     *                  shall be appended
     * @return the number of bytes appended
     */
    size_t appendUtf8(CharString& dest) const;

    /// Returns whether this code point is a lowercase code point
    bool isLower() const;

    /// Returns whether this code point is an uppercase code point
    bool isUpper() const;

    /** Returns a copy of this code point, for which isUpper() is guaranteed
     *  to return false. This method can only return a converted code point
     *  where a 1:1 conversion is possible. See toLower(Codepoint*) for other
     *  possible conversions.
     * @return when this code point is in uppercase, the corresponding
     *         lowercase code point, otherwise this code point
     */
    Codepoint toLower() const;

    /** Returns a copy of this code point, for which isLower() is guaranteed
     *  to return false. This method can only return a converted code point
     *  where a 1:1 conversion is possible. See toUpper(Codepoint*) for other
     *  possible conversions.
     * @return when this code point is in uppercase, the corresponding
     *         lowercase code point, otherwise this code point
     */
    Codepoint toUpper() const;

    /** Writes the lowercase representation of this code point to the given array.
     *  This method handles also the case where one code point is converted to
     *  multiple code points when performing a lowercase conversion.
     * @param[out] dest the array, to which the lowercase representation of
     *             this code point shall be written, must be at least of size
     *             CASE_CONVERSION_MAX_COUNT
     * @return the number of code points written to dest
     */
    size_t toLower(Codepoint* dest) const;

    /** Writes the uppercase representation of this code point to the given array.
     *  This method handles also the case where one code point is converted to
     *  multiple code points when performing an uppercase conversion.
     * @param[out] dest the array, to which the uppercase representation of
     *             this code point shall be written, must be at least of size
     *             CASE_CONVERSION_MAX_COUNT
     * @return the number of code points written to dest
     */
    size_t toUpper(Codepoint* dest) const;

    /** Writes a code point UTF-8 encoded to the given output stream
     * @param[in,out] to the output stream to write to
     * @param[in]     c  the Codepoint that shall be written
     */
    friend DLLEXP_BASICS std::ostream &operator<<(std::ostream &to, const Codepoint &c);

    /** Reads a UTF-8 encoded code point from the given input stream
     * @param[in,out] to the input stream to read from
     * @param[out]    c  the Codepoint that shall be read
     */
    friend DLLEXP_BASICS std::istream &operator>>(std::istream &from, Codepoint &c);

#ifndef NO_BCM

    /** BCM output streaming operator. Writes a code point UTF-8 encoded to the
     *  given output stream
     * @param[in,out] to the BCM output stream to write to
     * @param[in]     c  the Codepoint that shall be written
     */
    friend DLLEXP_BASICS itcNdrUbSend &operator<<(itcNdrUbSend &ndrStream, const Codepoint &c);

    /** BCM input streaming operator. Reads a UTF-8 encoded code point from the
     *  given input stream
     * @param[in,out] to the BCM input stream to read from
     * @param[out]    c  the Codepoint that shall be read
     */
    friend DLLEXP_BASICS itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream, Codepoint &c);

#endif

  private:
    unsigned long value;
};

#endif /* _CODEPOINT_H_ */
