//
//  $RCSfile$
//  $Locker$
//  $State$
//  $Source$
//
// %Z%JESSI-COMMON-FRAMEWORK 2.0
// %Z%Copyright (C) by Siemens Nixdorf Informationssysteme AG 1992
// %Z%Copyright (C) by Universitaet GH Paderborn 1992
// %Z%Development of this software was partially funded by ESPRIT project 7364.
// %Z%BCM %M% %I% %E%

// Wait on multiple file descriptors until a condition occurs.

#ifndef ItcDispatcher_H
#define ItcDispatcher_H

#define USES_timestuff

#include "ItcDispatch.def"
#include "ItcStatus.h"
#include "ItcPrelude.h"
#include "ItcTransport.h"

#ifdef QT_NAMESPACE
namespace QT_NAMESPACE { class QThread; }
using QT_NAMESPACE::QThread;
#else
class QThread;
#endif

// These must match with PerfTest.hxx !
typedef void (*IntReservedTextFP)(int, const char *);
typedef void (*StartTimerFP)(int);
typedef void (*IncDispatchSleepTimeFP)(long, long, long, long);

#define PERF_DISPATCHBEG  0
#define PERF_DISPATCHEND  1
#define PERF_INPRDYBEG    2
#define PERF_INPRDYEND    3
#define PERF_OUTRDYBEG    4
#define PERF_OUTRDYEND    5
#define PERF_EXCRAIBEG    6
#define PERF_EXCRAIEND    7


/** Mapping between the real sockets and a small numbers.
*/
class DLLEXP_BCM FdMask : public fd_set {
public:

  /** Get a real socket from fd.
      @param fd FD number.
      @return The real socket number.
  */
  static int  realFd(int fd);
  /** Allocate fd for the real socket.
      @param fd The real socket number.
      @return FD number.
  */
  static int  allocFd(int fd);
  /** Free fd associated with the real socket
      @param fd The real socket number.
  */
  static void freeFd(int fd);

  // Default constructor.
  FdMask();
  /// Set all bits to zero.
  void zero();
  /// Set bit.
  void setBit(int);
  /// Clear bit.
  void clrBit(int);
  /// Checks whether the bit is set.
  int isSet(int) const;
  /// Checks whether any bit is set.
  int anySet() const;
  /// Get number of bits set.
  int numSet() const;


private:
# ifdef IS_MSWIN_ // [
    // Under NT sockets are not numbers 0..n but arbitrary numbers
    // Use an mapping array to map to low numbers
    static unsigned  _unix_fd[FD_SETSIZE];
    static int  _count;    // Number of used descriptors
# endif // IS_MSWIN_ ] 
};

class itcConnection;
class itcIOHandler;
class TimerQueue;
struct timeval;

// forward declaration of nested type to force C++2.1 and C++3.0.1
// compatibility (concerning function names using nested type)
#if (defined(ATT_VERSION__) && (ATT_VERSION__ > 20))
enum itcDispatcherMask {};
#endif

/** Timer class.
*/
class DLLEXP_BCM ItcTimer {
public:
  /// Constructor.
  ItcTimer(timeval t, itcIOHandler* h, ItcTimer* n);
  /// Constructor.
  ItcTimer(timeval t, timeval lt, itcIOHandler* h, ItcTimer* n);

  /// Timer value.
  timeval timerValue;
  /// Timer value in local time.
  timeval localTimerValue;
  /// IO handler.
  itcIOHandler* handler;
  /// Pointer to the next timer.
  ItcTimer* next;
  /// Never used.
  unsigned int sn;
  /// Never used.
  int notifySent;
};


inline ItcTimer::ItcTimer(timeval t, itcIOHandler* h, ItcTimer* n) :
    timerValue(t),
    localTimerValue(t),
    handler(h),
    next(n),
    notifySent(0)
{
}

inline ItcTimer::ItcTimer(timeval t, timeval lt, itcIOHandler* h, ItcTimer* n) :
    timerValue(t),
    localTimerValue(lt),
    handler(h),
    next(n),
    notifySent(0)
{
}

/** Timer queue class.
*/
class DLLEXP_BCM TimerQueue {
public:
  /// Constructor.
  TimerQueue();
  /// Destructor.
  ~TimerQueue();

  /// Chcecks whether the timer queue is empty.
  int isEmpty() { return _first == nil; }
  /// Get the earliest time.
  timeval earliestTime() { return _first->timerValue; }

  /// Insert new timer into the queue.
  void insert(timeval, itcIOHandler*);
  /// Insert new timer into the queue.
  void insert(timeval, timeval, itcIOHandler*);
  /// Remove the timer from the queue.
  void remove(itcIOHandler*);
  /// Notify the queue about the time expired.
  void expire(timeval);

  /// Get the first timer.
  const ItcTimer *getFirstPtr() const { return _first; }
  /// Get the first timer.
  ItcTimer *getFirstPtr() { return _first; }
protected:
  /// The first timer
  ItcTimer* _first;
};


class DLLEXP_BCM itcAsyncFuncReady;
class DLLEXP_BCM ICBBcmReady;
class FdVector;


/** The main wrapper for I/O handling.
*/
class DLLEXP_BCM itcDispatcher : public itcStatus 
{
    /// Friend class definition used for unit-tests.
    friend class UNIT_TEST_FRIEND_CLASS;

public:
  /// Specifies, which events are we interested in.
  enum itcDispatcherMask { ItcNoneMask = 0, ItcReadMask = 1, ItcWriteMask = 2, ItcExceptMask = 4, ItcAllMask = 7 };

  /// Destructor.
  virtual ~itcDispatcher();

  /// Link a handler for an event on the connection. data will be passed to the handler.
  virtual bool link(itcConnection *conn, char *data, itcDispatcherMask, itcIOHandler*);
  /// Give the handler which handles specific events on the connection.
  virtual itcIOHandler* handler(itcConnection *conn, itcDispatcherMask);
  /// Unlink a handler from the connection.
  virtual bool unlink(itcConnection *conn, itcDispatcherMask mask = ItcAllMask);
  /// Unlink all handlers.
  virtual bool unlink_all(itcDispatcherMask mask = ItcAllMask);

  /// Set a timer.
  virtual void startTimer(long sec, long usec, itcIOHandler*);
  /// Clear the timer.
  virtual void stopTimer(itcIOHandler*);

  /// Main routine - call this periodically from the event loop.
  virtual void dispatch();
  /// Main routine with timeout - call this periodically from the event loop.
  virtual int dispatch(long &sec, long &usec);
  /// Main routine with const timeout.
  virtual int dispatch(double timeout);

  /// Get an access to a dispatcher singleton (create if nonexistent).
  static itcDispatcher& instance();
  /// Set the dispatcher instance.
  static void instance(itcDispatcher*);
  /// Destroy the dispatcher singleton.
  static void destroy()  { delete _instance; }
  /// Set the performance-gathering functions (see PerfTest.h for description).
  static void setPerfFunctions(IntReservedTextFP ptr1, StartTimerFP ptr2, IncDispatchSleepTimeFP ptr3);
  /// Set the number of bytes received to be shown in PERIODIC_PERFORMANCE_REPORT 
  static void incBytesRead(size_t count) { bytesRead += count; }
  /// Set the number of messages received to be shown in PERIODIC_PERFORMANCE_REPORT
  static void incMessagesRead(size_t count) { messagesRead += count; }

  /// Get number of dispatch calls.
  INT64 getDispatchCalls() const { return dispatchCalls; }
  /// Get total time slept in dispatch (if the arch supports it).
  INT64 getTotalSleepUsecs() const { return totalSleepUsecs; }

  virtual void addAsyncReadyNotify(int result, ICBBcmReady *par_pcbFunc, void *par_pcbParams, QThread *worker);
    
  virtual void registerICBBcmReady(ICBBcmReady *par_pcbFunc);
  
  virtual void deregisterICBBcmReady(ICBBcmReady *par_pcbFunc);
  
protected:
  // Both constructors are protected to enforce that the user 
  // will not create multiple itcDispatcher objects !!
  // The only way to create a single object is via instance().

  /** Default constructor.
      Constructors are protected to enforce that the user will not create multiple itcDispatcher objects.
      The only way to create a single object is via instance().
  */
  itcDispatcher();  
  /** Constructor.
      Constructors are protected to enforce that the user will not create multiple itcDispatcher objects.
      The only way to create a single object is via instance().
  */
  itcDispatcher(itcDispatcher &) {};

  /// attach.
  virtual void attach(int fd, itcConnection *conn, char *data, itcDispatcherMask, itcIOHandler*);
  /// detach.
  virtual void detach(int fd,itcDispatcherMask mask = ItcAllMask );
  /// detach_all.
  virtual void detach_all(itcDispatcherMask mask = ItcAllMask );

  /// dispatch.
  virtual int dispatch(timeval*);
  /// anyReady.
  virtual int anyReady();
  /// fillInReady.
  virtual int fillInReady(FdMask&, FdMask&, FdMask&);
  /// waitFor.
  virtual int waitFor(FdMask&, FdMask&, FdMask&, timeval*);
  /// notify.
  virtual void notify(int, FdMask&, FdMask&, FdMask&);
  /// calculateTimeout.
  virtual timeval* calculateTimeout(timeval*, timeval &);

  /// handleError.
  virtual int handleError();
  /// checkConnections.
  virtual void checkConnections();

  /// dispatchCalls.
  static size_t bytesRead;
  static size_t messagesRead;
  static bool checkCommunicationBuffer;

  /// startTimerFP.
  static StartTimerFP           startTimerFP;
  /// intReservedTextFP.
  static IntReservedTextFP      intReservedTextFP;
  /// incDispatchSleepTimeFP.
  static IncDispatchSleepTimeFP incDispatchSleepTimeFP;

private:
    void report(); 
    
    timeval currentTime() const;
    
    void processAsyncReadyNotify();

    timeval* calculateTimeout(timeval*, timeval &, FdVector &, bool &);

protected:
  /// size of the internal fd masks and tables.
  int _fdsetsize;
  /// highest-numbered file descriptor in any of the three masks, plus 1.
  int	_nfds;

  /// _rmask.
  FdMask* _rmask;
  /// _wmask.
  FdMask* _wmask;
  /// _emask.
  FdMask* _emask;

  /// _rmaskready.
  FdMask* _rmaskready;
  /// _wmaskready.
  FdMask* _wmaskready;
  /// _emaskready.
  FdMask* _emaskready;

  /// _rtable
  itcIOHandler** _rtable;
  /// _wtable
  itcIOHandler** _wtable;
  /// _etable
  itcIOHandler** _etable;

  /// _queue.
  TimerQueue* _queue;
  /// _conntable.
  itcConnection** _conntable; // relation between fds and connections

  /// User data for input callback.
  char**	   _rdatatable;
  /// User data for output callback.
  char**	   _wdatatable;
  /// User data for exception callback.
  char**	   _edatatable;

  /// dispatchCalls.
  INT64 dispatchCalls;
  /// totalSleepUsecs.
  INT64 totalSleepUsecs;

  struct Private;
  Private* d;

#ifdef IS_MSWIN__
    /*
     * File descriptors under windows are not 0..x as on unix, need
     * to map them to this in order to use above arrays
     */
    int* _unix_fd;
    struct wm_cache *_wmcache;
#endif

private:
    static itcDispatcher* _instance;

};

class DLLEXP_BCM itcAsyncFuncReady
{
  public:
    int retVal;
    ICBBcmReady *pcbFunc;
    void *pcbParams;
    QThread *workerThread;
    
    itcAsyncFuncReady(int result, ICBBcmReady *par_pcbFunc, void *par_pcbParams, QThread *par_worker) :
      retVal(result),
      pcbFunc(par_pcbFunc),
      pcbParams(par_pcbParams),
      workerThread(par_worker)
    {}
};


timeval operator+(timeval src1, timeval src2);
timeval operator-(timeval src1, timeval src2);
int operator>(timeval src1, timeval src2);
int operator<(timeval src1, timeval src2);
int operator==(timeval src1, timeval src2);
inline int operator>=(timeval src1, timeval src2) { return ! (src1 < src2); }
inline int operator<=(timeval src1, timeval src2) { return ! (src1 > src2); }

#endif /* ItcDispatcher_H */
