// DATEIBESCHREIBUNG ==============================================================
// DATEINAME:     DpMsgComplexVC.hxx
// VERANTWORTUNG: Johannes Ertl
// BESCHREIBUNG:  Diese Message ist eine DpMsgValueChange (Aenderungsmeldung), die
//                allgemein gehalten wurde, das heisst sie kann alle Aenderungen
//                verwalten. Dafuer ist sie nicht so effizient wie eine spezielle
//                ValueChange Message (siehe unten).
//                insertValueChange erzeugt automatisch die richtigen Gruppen!
// ACHTUNG:       Der Treiber sollte so oft wie moeglich die effizientere
//                DpMsgDriverVC verwenden!
//
// ======================================Ende======================================
#ifndef _DPMSGCOMPLEXVC_H_
#define _DPMSGCOMPLEXVC_H_

#include <ostream>
#include <DpMsgValueChange.hxx>
#include <PtrList.hxx>

// Vorwaerts-Deklarationen :
class DpIdentifier;
class DpVCGroup;
class ManagerIdentifier;
class Msg;
class TimeVar;
class Variable;

// ========== DpMsgComplexVC ============================================================

/** A general change message, derived from DpMsgvalueChange. It can handle all kinds of changes,
    but it is not as efficient as other DpMsgvalueChange subclasses.
    @remark Drivers should use the more efficient DpMsgDriverVC if possible.
  */
class DLLEXP_MESSAGES DpMsgComplexVC : public DpMsgValueChange 
{
  friend class UNIT_TEST_FRIEND_CLASS;    // ein Unit-Test braucht erweiterten zugriff auf diese Klasse

  /// operator << for itcNdrUbSend stream
  /// @param ndrStream the stream, which to send to
  /// @param msg the DpMsgComplexVC message
  friend DLLEXP_MESSAGES itcNdrUbSend &operator<<(itcNdrUbSend &ndrStream, const DpMsgComplexVC &msg);

  /// operator >> for itcNdrUbReceive stream
  /// @param ndrStream the stream, which to receive from
  /// @param msg the DpMsgComplexVC message
  friend DLLEXP_MESSAGES itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream, DpMsgComplexVC &msg);

public:

  /// constructor, initialisation with zero values
  DpMsgComplexVC();

  /// copy constructor
  /// @param newMsg the DpMsgComplexVC message to copy
  DpMsgComplexVC(const DpMsgComplexVC &newMsg);

  /// param constructor
  /// @param newDestination the ManagerIdentifier of new destination
  /// @param answer the answer flag
  DpMsgComplexVC(const ManagerIdentifier &newDestination, PVSSboolean answer);

  /// destructor
  virtual ~DpMsgComplexVC();

  // Operatoren :

  /// comparison operator ==
  /// @param rVal the DpMsgComplexVC to compare with
  /// @return 0 if not equal else 1
  int operator==(const DpMsgComplexVC &rVal) const;

  /// comparison operator !=
  /// @param rVal the DpMsgComplexVC to compare with
  /// @return 1 if not equal else 0
  int operator!=(const DpMsgComplexVC &rVal) const {return !operator==(rVal);}
 
  /// comparison operator ==
  /// @param rVal the message to compare with
  /// @return 0 if not equal else 1
  virtual int operator==(const Msg &rVal) const;

  /// assignment operator for DpMsgComplexVC
  /// @param rVal the DpMsgComplexVC to assign
  /// @return the resulting DpMsgComplexVC
  DpMsgComplexVC &operator=(const DpMsgComplexVC &rVal);

  /// assignment operator used for type conversion
  /// @param rVal the message to convert
  /// @return the resulting message
  virtual Msg &operator=(const Msg &rVal);

  /// send debug info to output stream
  /// @param to the output stream
  /// @param level the debug level
  virtual void debug(std::ostream &to, int level) const;

  // Spezielle Methoden :

  /// insert a VCGroup into the message
  /// @n There is no consistency check on the input parameter. The purpose of this method is to
  /// rearrange an existing DpMsgComplexVC object. E.g. pick up some groups from one DpMsgComplexVC msg
  /// and put it into a new DpMsgComplexVC msg. 
  /// @param group the group to insert
  /// @n A deep copy of the input parameter will be inserted.
  /// @return PVSS_TRUE if success else PVSS_FALSE
  PVSSboolean insertGroup(const DpVCGroup &group);

  /// insert a VCGroup into the message
  /// @param groupPtr the group to insert
  /// @n The class takes responsibility for the pointer.
  /// @return PVSS_TRUE if success else PVSS_FALSE
  PVSSboolean insertGroup(DpVCGroup *groupPtr);

  /// insert a VCGroup, created from the given parameters, into the message
  /// @param manager the ManagerIdentifier of the group
  /// @param user the PVSSuserIdType of the group
  /// @param time the time stamp of the group
  /// @param dpId the DpIdentifier of the group
  /// @param var the value of the group
  /// @return PVSS_TRUE if success else PVSS_FALSE
  PVSSboolean insertValueChange(const ManagerIdentifier &manager,
      PVSSuserIdType user, const TimeVar &time, const DpIdentifier &dpId, const Variable &var);

  /// insert a VCGroup, created from the given parameters, into the message
  /// @param manager the ManagerIdentifier of the group
  /// @param user the PVSSuserIdType of the group
  /// @param time the time stamp of the group
  /// @param dpId the DpIdentifier of the group
  /// @param varPtr the value of the group
  /// @n The call takes ownership of this pointer.
  /// @return PVSS_TRUE if success else PVSS_FALSE
  PVSSboolean insertValueChange(const ManagerIdentifier &manager,
      PVSSuserIdType user, const TimeVar &time, const DpIdentifier &dpId, VariablePtr varPtr);

  /// get number of VCGroups in this message
  virtual PVSSulong getNrOfGroups() const {return groupList.getNumberOfItems();};

  /// get the DpIdentifier from a group
  /// @param groupIndex the index of the group
  virtual DpIdentifier getGroupId(PVSSulong groupIndex) const;

  /// set iterator on the first group
  /// @return the first group
  DpVCGroup *getFirstGroup() const;

  /// set iterator to the next group
  /// @return the next group
  DpVCGroup *getNextGroup() const;

  /// set iterator to the last group
  /// @return the last group
  DpVCGroup *getLastGroup() const;

  /// cut out the pointer to the first group
  /// @n The caller is responsible to delete the pointer.
  DpVCGroup * cutFirstGroup();

  /// remove a group
  /// @param g the group to remove
  /// @return if g == lastAccessed then g.getNext() else lastAccessed
  DpVCGroup *removeGroup(DpVCGroup *g);

	/// check if own DP message type matches other DP message type
  /// @param dpMsgType the MsgType to check
  /// @return DpMsgComplexVC type if argument is DpMsgComplexVC else a DP message type
  virtual MsgType isA(MsgType dpMsgType) const;

  /// get own DP message type, always DP_MSG_COMPLEX_VC
  virtual MsgType isA() const;

  /// allocate a new message
  virtual Msg *allocate() const;

  /// set method for the useServerTime flag
  void setUseServerTimeFlag(PVSSboolean flag);

  /// get method for the useServerTime flag
  PVSSboolean getUseServerTimeFlag() { return useServerTime; }

  // Generierte Methoden :
  private:
  virtual void outNdrUb(itcNdrUbSend &ndrStream) const;
  virtual void inNdrUb(itcNdrUbReceive &ndrStream);
  PtrList groupList;
  PVSSboolean useServerTime;
};

// ================================================================================
// Inline-Funktionen :

inline DpVCGroup *DpMsgComplexVC::getFirstGroup() const
{
  return (DpVCGroup *)groupList.getFirst();
}

inline DpVCGroup *DpMsgComplexVC::getNextGroup() const
{
  return (DpVCGroup *)groupList.getNext();
}

inline DpVCGroup *DpMsgComplexVC::getLastGroup() const
{
  return (DpVCGroup *)groupList.getLast();
}

inline DpVCGroup *DpMsgComplexVC::removeGroup(DpVCGroup *g)
{
  groupList.remove(reinterpret_cast<PtrListItem *>(g));  // -> entfernen
  return(reinterpret_cast<DpVCGroup *>(groupList.getLastAccessed()));
}

inline void  DpMsgComplexVC::setUseServerTimeFlag(PVSSboolean flag)
{
  useServerTime = flag;
}


#endif /* _DPMSGCOMPLEXVC_H_ */
