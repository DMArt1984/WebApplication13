#ifndef _CTRLEXPR_H_
#define _CTRLEXPR_H_

#include <CtrlSment.hxx>
#include <Variable.hxx>

class CtrlThread;
class CharString;

/*  author VERANTWORTUNG: Martin Koller */
/** Baseclass for expressions */
class DLLEXP_CTRL CtrlExpr : public CtrlSment
{
  public:
    /// available subclassed types
    enum ExprType
    {
      /// assignment, e.g. a = b;
      ASS_EXPR,

      /// a constant, e.g. 19
      CONST_EXPR,

      /// a function call, e.g. foo(123)
      FCALL_EXPR,

      /// a variable name, e.g. abc
      ID_EXPR,

      /// index operator e.g  a[20]
      IDX_EXPR,

      /// operator, e.g. a+b
      OP_EXPR,

      /// unary expression, e.g. !a
      UNARY_EXPR,

      /// casting, e.g. (int)1.23
      CAST_EXPR,

      /// conditional expression, e.g. (a == 10) ? a : b
      COND_EXPR,

      /// selection, e.g motor.rotation(45)
      SEL_EXPR,

      // CtrlVar
      VAR_EXPR,

      /// new expression
      NEW_EXPR
    };

    /// Constructor
    CtrlExpr(int line, int filenum) : CtrlSment(line, filenum) {}

    /// Get the expression type of this CtrlExpr.
    virtual ExprType isA() const = 0;
   
    /// Get the statement type. Returns 1, if type is one of SMENT_EXPR, SMENT, else 0.
    virtual int isA(SmentType type) const;
    
    /// expression-statement: do nothing
    virtual const CtrlSment *execute(CtrlThread *) const;

    /** Evaluates the expression and returns a pointer to a static Variable.
      * The returned pointer will never be a 0-pointer!
      * WARNING: the static member will be overwritten on subsequent calls
      * so you have to eventually copy the value; Do NOT DELETE this pointer
      */
    virtual const Variable *evaluate(CtrlThread *thread) const = 0;

    /** returns a pointer to the Variable which can be a target for an assignment.
      * if not possible, it returns 0 and issues a Warning-Message
      */
    virtual Variable *getTarget(CtrlThread *thread) const;

    // Get the name of a unique, hidden variable to store this value in. 
    uintptr_t getArgId() const {  return (uintptr_t) this; }
 
    /* return a representation of this as a string, used in error output
      @internal
    */
    virtual CharString toString() const;

    /** dump the whole tree for code coverage analysis
        @param to output stream
      */
    virtual void dumpCoverageTree(std::ostream &to, CoverageAction action = DUMP) const;
};

#endif /* _CTRLEXPR_H_ */
