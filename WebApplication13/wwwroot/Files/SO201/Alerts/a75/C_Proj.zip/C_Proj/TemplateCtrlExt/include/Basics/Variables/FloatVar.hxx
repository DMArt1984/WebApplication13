#ifndef _FLOATVAR_H_
#define _FLOATVAR_H_

// VERANTWORTUNG: Johannes Ertl
// BESCHREIBUNG:  Float-Gleitkomma-Variable im PVSS-2.

#ifndef _VARIABLE_H_
#include <Variable.hxx>
#endif

#ifndef _CHARSTRING_H_
#include <CharString.hxx>
#endif


/**
	A variable class representing floating point value
*/
class DLLEXP_BASICS FloatVar : public Variable
{
  public:
    /** Constructor
        @param init PVSSdouble initial value.
    */
    FloatVar(PVSSdouble init = 0.0) : value(init) { cachedIsA = FLOAT_VAR; }

	/** Copy constructor
        @param rVal Source FloatVar value to be copied.
    */
    FloatVar(const FloatVar &rVal) : Variable(rVal),value(rVal.value) { cachedIsA = FLOAT_VAR; }

	/** Declares new and delete operator.
    */
    AllocatorDecl;

	/** Writes FloatVar value to the itcNdrUbSend stream.
        @param ndrStream Output stream.
        @param fVar Streamed FloatVar variable.
        @return itcNdrUbSend stream.
    */
    friend DLLEXP_BASICS itcNdrUbSend &operator<<(itcNdrUbSend &ndrStream, const FloatVar &fVar);

	/** Reads the FloatVar value from the itcNdrUbReceive stream.
        @param ndrStream input stream.
        @param fVar FloatVar variable receiving the value from the stream.
        @return itcNdrUbReceive stream.
    */
	friend DLLEXP_BASICS itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream, FloatVar &fVar);

	/** Writes FloatVar value to the std::ostream.
        @param ofStream Output stream.
        @param fVar Streamed FloatVar variable.
        @return std::ostream stream.
    */
	friend DLLEXP_BASICS std::ostream &operator<<(std::ostream &ofStream, const FloatVar &fVar);

	/** Reads the FloatVar value from the std::istream stream.
        @param ifStream input stream.
        @param fVar FloatVar variable receiving the value from the stream.
        @return std::istream stream.
    */
	friend DLLEXP_BASICS std::istream &operator>>(std::istream &ifStream, FloatVar &fVar);


	/** Comparison operator ==
        @param rVal Compared value.
        @return int 1 if the values are equal, otherwise 0.
        @n Important: this operator checks the VariableType, so two objects are only equal, if
        they also have the same class (no conversion is done; see other operators)
    */
    virtual int operator==(const Variable &rVal) const;

    /** Comparison operator <
        @param rVal Compared value.
        @return int 1 if true, otherwise 0.
        @n Important: this operator also converts the given rVal to its own class-type if needed
    */
    virtual int operator<(const Variable &rVal) const;

    /** Comparison operator >
        @param rVal Compared value.
        @return int 1 if true, otherwise 0.
        @n Important: this operator also converts the given rVal to its own class-type if needed
    */
    virtual int operator>(const Variable &rVal) const;

   /** Overloaded assignment operator used for type conversions.
        @param rVal Assigned value.
        @return Variable with assigned value.
   */
    virtual Variable &operator=(const Variable &rVal);

    /** Single assignment operator.
        @param rVal PVSSdouble assigned value.
        @return FloatVar with the assigned value.
    */
    FloatVar &operator=(PVSSdouble rVal);

    /** Checks if variable is logically true (if value != 0)
        @return PVSS_TRUE or PVSS_FALSE.
   */
    virtual PVSSboolean isTrue() const {return (value != 0.0);}

    /** Clone the current variable object
        @return Variable* pointer to a newly created FloatVar with the same value,
        created by the copy constructor.
    */
    virtual Variable *clone() const {return new FloatVar(value);}

    /** PVSSfloat Cast operator
		@return PVSSfloat casted variable
   */
    operator PVSSfloat () const { return (PVSSfloat) value; }

    /** PVSSdouble Cast operator
		@return PVSSdouble casted variable
   */
    operator PVSSdouble () const { return value; }

	/** Creates a new dynamicaly allocated FloatVar variable
        @return Variable* pointer to a newly allocated FloatVar created by the
        default constructor (value is 0).
   */
    virtual Variable *allocate() const { return new FloatVar; }

	/** Overloaded function returning FLOAT_VAR
        @return VariableType (FLOAT_VAR)
   */
    virtual VariableType isAUncached() const { return FLOAT_VAR; }

	/** Returns the VariableType for the specified type
        @param varType VariableType.
        @return VariableType for this type.
   */
	virtual VariableType isAUncached(VariableType varType) const;

# if 0
    // DOC++-Kommentare
    /// Get own variable type. Returns always FLOAT_VAR.
    VariableType  isA() const;
    /** Check if own variable type matches varType.
        Returns FLOAT_VAR, if argument is FLOAT_VAR, else NOTYPE_VAR.
    */
    VariableType  isA(VariableType varType) const;
# endif

    /** Writes the value to the output stream
        @param ofStream std::ostream to write the value to.
   */
	virtual void outToFile(std::ostream &ofStream) const;

	/** Reads the value from the input stream
        @param ifStream std::istream to read the value from.
    */
	virtual void inFromFile(std::istream &ifStream);

    /** Formats the value according to the format string.
        @param  format  The format string. If the string is not empty, it
                is used as an argument to the sprintf function.
                Else "%g" is used as a default.
        @return The string representation of the value.
   */
    virtual CharString formatValue(const CharString &format) const;

    /** Formats the value according to a format string.
        @param format The format string. If the string is not empty is is
               used as an argument to the sprintf function.
               Else a default is used.
        @param target This is a buffer with length len, which is directly written to.
               This method is more performant than the one which returns a CharString,
               because no alloc is done.
        @param len A buffer length.
        @return Number of bytes written into target without 0-byte,
                or a negative value on error (like buffer too small)
    */
    virtual int formatValue(const CharString &format, char *target, size_t len) const;

    /** Print the content of the Variable to the output stream.
        @param to Specifies the output stream.
        @param level Level controls the amount of debug information
        printed. Nothing is printed if level == 0.
    */
    virtual void debug(std::ostream &to, int level) const;

    /** Gets the value of the variable
        @return Internally stored PVSSdouble  value.
    */
    PVSSdouble getValue() const { return value; }

    /** Sets the value of the variable
        @param newValue New PVSSdouble value.
   */
    void setValue(const PVSSdouble newValue) { value = newValue; }

    // versucht sich selbst in eine Variable "out" vom Typ "to" zu konvertieren
    // bei Konvertierung in int-Typen erfolgt ein Runden !!!!
    // Returnwert:    OK: Konvertierung erfolgreich, "out" wurde neu allokiert
    //                OUT_OF_RANGE: Konvertierung grundsaetzlich moeglich, aber der
    //                Wert von "in" liegt ausserhalb des Wertebereichs des Typs "to",
    //                "out" wird trotzdem allokiert !!!! und enthaelt Min bzw. Max des
    //                moeglichen Wertebereichs
    //                CONV_NOT_DEFINED: Typumwandlung nicht moeglich, "out" wird auf 0
    //                gesetzt

	/** Converts the value to a Variable of another type
        @param to VariableType of the variable converting to.
        @param out VariablePtr to a newly created Variable of the desired type.
        @return OK if correctly converted, OUT_OF_RANGE or CONV_NOT_DEFINED otherwise.
   */
    virtual ConvertResult convert(VariableType to, VariablePtr &out) const;

  private:

#if defined (_WIN32) && !defined(WINCE)
    /** Formats the value according to a format string.
        This method is only used on Windows platform for UTF8 encoding.
        @param format The format string. If the string is not empty is is
               used as an argument to the sprintf function.
               Else a default is used.
        @param target the char* buffer, which is directly written to
        @param len the length of the buffer
        @return Number of bytes written into target without 0-byte,
                or a negative value on error (like buffer too small)
    */
    int formatValueUtf8(const CharString &format, char *target, size_t len) const;
#endif

    /** Formats the value according to a format string.
        This method is used on non-Windows platforms and on Windows platform for non-UTF8 encoding.
        @param format The format string. If the string is not empty is is
               used as an argument to the sprintf function.
               Else a default is used.
        @param target the char* buffer, which is directly written to
        @param len the length of the buffer
        @return Number of bytes written into target without 0-byte,
                or a negative value on error (like buffer too small)
    */
    int formatValuePosix(const CharString &format, char *target, size_t len) const;

    void outNdrUb(itcNdrUbSend &ndrStream) const;
    void inNdrUb(itcNdrUbReceive &ndrStream);
    PVSSdouble value;
};

#endif /* _FLOATVAR_H_ */
