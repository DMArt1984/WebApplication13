#ifndef _OAMANAGER_H_
#define _OAMANAGER_H_

#include <Manager.hxx>

class OaUserTable;

/** The (API) manager class. This class covers the API interface functionality.
  Each PVSS-II manager must contain anything up to the manager level to be able
  to participate in the PVSS-II data exchange.

  <p> Each manager has a manager type (this is hard coded) and a manager number
  which can be set when starting (-num xx option). This tuple of numbers identifies the
  manager and therefore there must not be two managers with the same combination
  in one running PVSS-II system.

  @classification public use, overload
*/
class DLLEXP_OAMANAGER OaManager : public Manager
{
  friend class UNIT_TEST_FRIEND_CLASS;    // ein Unit-Test braucht erweiterten zugriff auf diese Klasse

  public:

  /**
   * Constructor for a manager with the specified id.
   *
   * @param manId The manager id, a tuple of manager type and number
   */
  OaManager(const ManagerIdentifier &manId);

  /**
   * Constructor for a manager with the specified id and a (possibly derived)
   * instance of the CommonNameService-class.
   * If you just need a default instance of the CommonNameService,
   * please use the other constructor.
   *
   * @param manId The manager id, a tuple of manager type and number
   * @param customCns Pointer to an instance of CommonNameService.
   *                  Can be used to bring a custom derived instance of the
   *                  CommonNameService-class into the OaManager.
   *                  The OaManager takes ownership of the instance.
   */
  OaManager(const ManagerIdentifier &manId, CommonNameService *customCns);

  /// Destructor
  virtual ~OaManager();

  /** Get pointer to the single instance of the manager class.
    @return pointer to the manager
    @classification public use, call
   */
  static OaManager *getManPtr() { return static_cast<OaManager *>(Manager::getManPtr()); }

  /** Get all ids of languages defined in a certain system.
  @param [out] langIds The list with IDs
  @return DpIdentOK if the function was successful, DPIdentNoSuchSystem if system is not found, DpIdentInternalError in other error case
  @classification public use, call
  */
  static DpIdentificationResult getAllProjectLanguageIds(std::vector<GlobalLanguageIdType> &langIds);

  /** Return all ids of languages defined in a certain system.
  @return the project language ids if successful, otherwise an empty set.
  @classification public use, call
  */
  static std::vector<GlobalLanguageIdType> getAllProjectLanguageIds();

  /** Get the amount of languages defined in a certain system.
  @param [out] langCount The count of languages
  @return DpIdentOK if the function was successful, DPIdentNoSuchSystem if system is not found, DpIdentInternalError in other error case
  @classification public use, call
  */
  static DpIdentificationResult getNumOfProjectLanguages(uint32_t &langCount);

  /** Return the amount of languages defined in a certain system.
  @return the count project languages if successful, otherwise 0.
  @classification public use, call
  */
  static uint32_t getNumOfProjectLanguages();

  /** Checks if a specific lanaguage is defined in a certain system.
  @param langId The list with IDs
  @param hasLangId true if available in a system, otherwise false
  @return DpIdentOK if the function was successful, DPIdentNoSuchSystem if system is not found, DpIdentInternalError in other error case
  @classification public use, call
  */
  static DpIdentificationResult hasProjectLanguageId(const GlobalLanguageIdType langId, bool &hasLangId);

  /** Checks if a specific lanaguage is defined in a certain system.
  @param langId The list with IDs
  @param hasLangId PVSS_TRUE if available in a system, otherwise PVSS_FALSE
  @return true if system has language, false if not, false in case of errors
  @classification public use, call
  */
  static bool hasProjectLanguageId(const GlobalLanguageIdType langId);

  /// get the id of the active lang in current project
  /// @return id of active project language
  static GlobalLanguageIdType getActiveLangId();

  /// get the name of the active lang in current project in defineable format
  /// @param format The format of language
  /// @return name of active language
  static CharString getActiveLangLocale(LangNameFormat format = LangNameFormat::Hmi);

  /// 'online' switch language
  /// @param lang the language
  static bool switchActiveLang(GlobalLanguageIdType lang);

  /// 'online' switch language
  /// @param lang the language
  static bool switchActiveLang(CharString lang);

  /** get a string denoting the project language configuration,
  the string contains the pvssLocale names of the languages in ascending order with a delimiter
  @return the language configuration string
  */
  static CharString getLanguageConfiguration();

  /** API function. get the current user name
  @return returns 0 if conversion fails, userName otherwise
  */
  static const char* getUserName();

  /** API function. convert the userId to the userName. Uses the deleted users data.
  @param id the user id to search for
  @return 0 if userId does not exist
  */
  static const char* getUserName(PVSSuserIdType id);

  /** Connect to the event manager.
    @param dontExit by default the function will succeeed in establishing a connection to the
    event manger or the exit the manger.
    If this flag is set to PVSS_TRUE the manager will not
    exit and the function may return without an established connection.
    Note that the event manager may close the connection immedeately if there is no
    license for this manager. You are advised to check with Manager::isEvConnOpen if the
    connection is still open.
    @return PVSS_TRUE if the connect call to the event manager was successful
    @classification public use, call
   */
  static PVSSboolean connectToEvent(PVSSboolean dontExit = PVSS_FALSE);

  /** Connect to the event manager.
    @param dontExit by default the function will succeeed in establishing a connection to the
    event manger or the exit the manger.
    If this flag is set to PVSS_TRUE the manager will not
    exit and the function may return without an established connection.
    Note that the event manager may close the connection immedeately if there is no
    license for this manager. You are advised to check with Manager::isEvConnOpen if the
    connection is still open.
    @param bAutoSwitchToRunning by default Connecting to the event manager will set the Manager
    to state STATE_RUNNING. Otherwise this must be done manually lateron.
    @return PVSS_TRUE if the connect call to the event manager was successful
    @classification public use, call
   */
  static PVSSboolean connectToEvent(PVSSboolean dontExit, PVSSboolean bAutoSwitchToRunning);

  /** this method is called by the framework to handle newly received non-const DpMsg and handle them.
    This method calls doReceive(DpMsg &msg) for the actual message handling.
    @param msg a pointer to a message of type DpMsg. The messge is deleted in that function.
    @classification ETM internal
   */
  virtual void doReceive(DpMsg *msg);

  /** method to handle the different dp messages.
  It can be overloaded to implement special handling for messages.
  When overloading this function don't forget to call the original function for all messages
  you do not process.
  @param msg a message of type DpMsg
  @classification public use, overload, call basic
 */
  virtual void doReceive(DpMsg &msg)
  {
    Manager::doReceive(msg);
  }

  /** this method is called by the framework to handle newly received non-const SysMsg and handle them.
  This method calls doReceive(SysMsg &msg) for the actual message handling.
  @param msg a pointer to a message of type SysMsg
  @classification ETM internal
 */

  virtual void doReceive(SysMsg *msg)
  {
    Manager::doReceive(msg);
  }
  /** method to handle the different sys messages.
    It can be overloaded to implement special handling for messages.
    When overloading this function don't forget to call the original function for all messages
    you do not process. This is very important since we are handling system messages here!
    @param msg a message of type SysMsg. The message is deleted in that function.
    @classification public use, overload, call basic
   */
  virtual void doReceive(SysMsg &msg)
  {
    Manager::doReceive(msg);
  }

private:
  /// User Table to hold the deleted users data
  static OaUserTable* oaUserTable;

  /** Initialize the user table.
  */
  static void initOaUserTable();
};

#endif /* _OAMANAGER_H_ */
