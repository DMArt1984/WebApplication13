#ifndef _EVALDONECB_H_
#define _EVALDONECB_H_

#include <DoneCB.hxx>

/*  author: Martin Koller */
/** description: 
  This class is used to tell the WaitCondition-Object that the CTRL-script
  has been finished. If a target-pointer is given, then the result of the
  executed script (the return-value of the main() function) is stored in
  the target variable.
*/
class WaitEval;

class DLLEXP_CTRL EvalDoneCB : public DoneCB
{
  public:
    ///
    EvalDoneCB(Variable *target, WaitEval *wait) : target_(target), waitCond_(wait) {}
    virtual ~EvalDoneCB();

    /// return a copy of this
    virtual DoneCB *clone() const;

    /// this is the Callback-function
    virtual void execute(const Variable *var = 0);

  protected:

  private:
    Variable *target_;
    WaitEval *waitCond_;
};

#endif /* _EVALDONECB_H_ */
