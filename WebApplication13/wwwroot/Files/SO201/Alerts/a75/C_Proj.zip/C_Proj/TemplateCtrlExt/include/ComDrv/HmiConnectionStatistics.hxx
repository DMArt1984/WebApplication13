#ifndef _HMICONNECTIONSTATISTICS_H_
#define _HMICONNECTIONSTATISTICS_H_
//COVINFO FILE: obsolete (actually: not yet used in WinCC OA, dhoegerl)
#include <HmiConnection.hxx>
#include <StatisticTimer.hxx>

class HmiConnection;
class StatisticTimer;

class HmiConnectionStatistics : public DrvIntDp
{
  public:
    enum HmiInternalCommandElements
    {
      HmiICE_RefreshTime = 0,
      HmiICE_User,                  // important: ICE_User must always be the last entry
    };

    enum HmiInternalStateElements
    {
      HmiISE_First = 500,
      HmiISE_LastError = HmiISE_First,
      HmiISE_User,
    };

    HmiConnectionStatistics(HmiConnection * hmiConn, int additionalDPE, int additionalConnect);

    virtual ~HmiConnectionStatistics();

    virtual const CharString & getElementName(int index);

    virtual PVSSboolean setDpIdentifier(CharString& name, DpIdentifier& dpId);

    int getInternalIndex(int idx);

    void createTimer();

    void updateRefreshTime();

    CharString getMyDpName()        { return m_myDpName; }

    int getTotalConnect()           { return m_totalConnect; }

    int getTotalDpe()               { return m_totalDpe; }

    unsigned int getRefreshTime()   { return m_refreshTime; }

    StatisticTimer * getStatTimer() { return statTimer_; }

    bool isDpAvailable()            { return m_isDpAvailable; }  // true: if every dpe exists

  protected:
    #ifdef _UNIT_TEST
      HmiConnectionStatistics() : DrvIntDp() { };
    #endif // _UNIT_TEST

    // --------------------------------------------------
    // DrvIntDp interface

    // --------------------------------------------------------------
    // internal dp handling

    // retrievs the names of the internal DPEs. The function must be overloaded.
    // It should return the proper DPE string for the corresponding index
    const CharString& getDpName4Query(int index);

    // called if there is an answer to a certain index
    void answer4DpId(int index, Variable* varPtr);

    // called if there is a hotlink to a certain index
    void hotLink2Internal(int index, Variable* varPtr);

    // did we get all IDPs ?
    void dpReady();

    virtual void updateLastError(unsigned int lastError);

    virtual void doUpdateStatistics();

  private:
    void answerCallback(int index, Variable* varPtr);

    void hotlinkCallback(int index, Variable* varPtr);

    CharString m_myDpName;

    int m_totalDpe;
    int m_totalConnect;

    HmiConnection * m_hmiConn;

    StatisticTimer * statTimer_;
    unsigned int m_refreshTime;

    bool m_isDpAvailable;

};

#endif  // _HMICONNECTIONSTATISTICS_H_

