#ifndef _CRYPTO_HASH_H_
#define _CRYPTO_HASH_H_

#include <CharString.hxx>
class Blob;

/**
 * Calculates cryptographic hash values.
 */

class DLLEXP_OABASICS CryptoHash
{
  public:
    /// possible algorithms
    enum Algorithm
    {
      ///
      MD4,

      ///
      MD5,

      ///
      SHA1,

      ///
      SHA224,

      ///
      SHA256,

      ///
      SHA384,

      ///
      SHA512,

      ///
      SHA3_224,

      ///
      SHA3_256,

      ///
      SHA3_384,

      ///
      SHA3_512,
    };

    /** constructor
    @param algo  See Algorithm enum
    */
    CryptoHash(Algorithm algo);

    /** destructor
    */
    ~CryptoHash();

    /** add data to be calculated
    @param data Blob input
    @return nothing
    */
    void addData(const Blob &data);

    /** add data to be calculated
    @param data CharString input
    @return nothing
    */
    void addData(const CharString &data);

    /** add data to be calculated
    @param data char* input
    @return nothing
    */
    void addData(const char *data, size_t length);

    /** return hash result as a hex string
    @param
    @return hashed input
    */
    CharString hexResult() const;

    /** resets the object
    @param
    @return nothing
    */
    void reset();

    /** return the hash in hex calculated from given string
    @param algo See Algorithm enum
    @param data input data in Charstring form
    @return hashed value
    */
    static CharString hexResult(Algorithm algo, const CharString &data);

  private:
    class Private;
    Private *d;
};

#endif
