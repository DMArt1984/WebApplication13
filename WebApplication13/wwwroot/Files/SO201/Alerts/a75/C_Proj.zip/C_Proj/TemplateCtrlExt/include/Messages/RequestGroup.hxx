// DATEIBESCHREIBUNG ==============================================================
// DATEINAME:		RequestGroup.hxx
// VERANTWORTUNG:	Thomas Exner
// 
// BESCHREIBUNG:	Mit einer RequestGroup koennen mehrere DP-Attribute abgefragt
//					werden. Dazu enthalt die RequestGroup eine PtrList von
//					RequestItems. In einer Gruppe duerfen dabei nur Items enthalten
//					sein, bei denen die Config-Nr gleich ist (daher sind
//					unterschiedliche Datenpunkte moeglich).
//					Um welchen Typ der Abfrage es sich handelt bestimmt der
//					Konstruktor:
//					- RequestGroup() => SIMPLE_REQUEST (die Attribute time1 und
//					  time2 sind bedeutungslos)
//					- RequestGroup(TimeVar time, PVSSboolean synch)
//					  - wenn synch == 0 (default) => ASYNCH_REQUEST
//					  - wenn synch == 1 => SYNCH_REQUEST
//					  (in beiden Faellen ist time1 gleich dem Abfragezeitpunkt
//					  und time2 bedeutungslos)
//					- RequestGroup(TimeVar time, TimeVar time) => PERIOD_REQUEST
//					  (time1 = von, time2 = bis)
//					Zum Aufbau der Gruppe dient insertItem(). Die Parameter tolerance
//					und smoothTime haben nur fuer den PeriodRequest eine Bedeutung
//					und sind daher mit default-Werten versehen.
//					Zum Auslesen der Items gibt es daher auch Methoden, welche
//					entweder das ganze Item oder nur den Identifier aus dem Item
//					liefern.

#ifndef _REQUESTGROUP_H_
#define _REQUESTGROUP_H_

// Vorwaerts-Deklaration der Eigenen Klasse
class RequestGroup;

// ========== RequestGroupPtr ============================================================
typedef RequestGroup* RequestGroupPtr;

// System-Include-Files
#include <AlertTime.hxx>
#include <Msg.hxx>
#include <PtrList.hxx>
#include <RequestItem.hxx>

// Vorwaerts-Deklarationen :

// ========== RequestGroup ============================================================
/** Holds a list of RequestItem objects. All items in a group must have the same
 *  ConfigNr, but they can have different datapoints.
*/
class DLLEXP_MESSAGES RequestGroup : public PtrListItem
{
public:
  /// Default constructor, creates instance of type DP_MSG_SIMPLE_REQUEST
  RequestGroup();

  /** Constructor, creates a timed instance
   * @param time the time of the request
   * @param synch when PVSS_TRUE, the instance is a DP_MSG_SYNCH_REQUEST,
   *              otherwise, it is a DP_MSG_ASYNCH_REQUEST
   */
  RequestGroup(const TimeVar &time, PVSSboolean synch = PVSS_FALSE);

  /** Constructor, creates an interval instance
   * @param startTime start time of the interval
   * @param endTime end time of the interval
   * @param alert when PVSS_TRUE, the instance is a DP_MSG_ALERT_PERIOD_REQU,
   *              otherwise, it is a DP_MSG_PERIOD_REQUEST
   */
  RequestGroup(const TimeVar &startTime, const TimeVar &endTime, PVSSboolean alert = PVSS_FALSE);

  /** Constructor, creates an instance of type DP_MSG_ALERT_TIME_REQU
   * @param time the alert time
   */
  RequestGroup(const AlertTime &time);

  /** Constructor, creates an instance of type DP_MSG_MAXAGE_REQUEST
   * @param maxAge If the requested value is older than the maxage it has to be updated
   *               for the request.
   */
  RequestGroup(const PVSSulong &timespan);

  /// Copy constructor
  RequestGroup(const RequestGroup &group);

  /// Destructor
  ~RequestGroup();

  // Operatoren :
  /** BCM output streaming operator
   * @param[in,out] ndrStream the BCM stream to write to
   * @param group the RequestGroup instance to be written
   */
  friend DLLEXP_MESSAGES itcNdrUbSend &operator<<(itcNdrUbSend &ndrStream, const RequestGroup &group);

  /** BCM input streaming operator
   * @param[in,out] ndrStream the BCM stream to read from
   * @param[out] group the RequestGroup instance to be read
   */
  friend DLLEXP_MESSAGES itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream, RequestGroup &group);

  /// Comparison operator
  int operator==(const RequestGroup &rVal) const;

  /// Assignment operator
  RequestGroup &operator=(const RequestGroup &rVal);

  // Spezielle Methoden :
  /// Returns the MsgType
  MsgType getMsgType() const {return myType;};

  /// Returns the start time
  PVSSTime getTime1() const {return aTime.getTime();};

  /// Returns the end time
  PVSSTime getTime2() const {return time2;};  

  /// Returns alert time
  const AlertTime &getATime() const {return aTime;};

  /// Returns the maxAge PVSSulong
  PVSSulong getMaxAge() const {return maxAge;};

  // fuegt ein neues Item in die Gruppe ein, in einer Gruppe duerfen sich nur Items
  // befinden, in deren Identifier die Config-Nr gleich ist
  /** Insert an item into the group, the group can contain only items whose ids are
   *  the equal to the id of the ConfigNr
   * @param id to be checked against config nr. id may not be empty
   * @param number the number of the RequestItem
   * @param tolerance the smoothing tolerance value
   * @param smoothTime the smoothing time value
   * @see RequestItem
   */
  PVSSboolean insertItem(const DpIdentifier &id, PVSSushort number = 0, 
      const FloatVar &tolerance = FloatVar(0.0), const TimeVar &smoothTime = TimeVar(0, 0));

  /// Returns the first RequestItem
  RequestItem *getFirstItem() const {return (RequestItem *) list.getFirst();};

  /// Returns the next RequestItem
  RequestItem *getNextItem() const {return (RequestItem *) list.getNext();};

  /// Returns the id of the first RequestItem
  const DpIdentifier *getFirstId() const
	  {return (list.getFirst() ? &(((RequestItem *) list.getFirst())->getId()) : 0);};

  /// Returns the id of the next RequestItem
  const DpIdentifier *getNextId() const;

  /// Returns the count of items
  unsigned int getNrOfItems() const {return list.getNumberOfItems();};

  /** Debug output method
   * @param[out] to the stream to write to
   * @param level controlls the amount of debug information, the higher the more
   */
  void debug(std::ostream &to, int level) const;

protected:
private:
  PtrList list;
  MsgType myType;
  AlertTime aTime;
  TimeVar time2;
  PVSSulong maxAge;
};

// ========== inline-functions ============================================================
// Konstruktor, erzeugt Group fuer DP_MSG_SIMPLE_REQUEST
inline RequestGroup::RequestGroup()
	: PtrListItem(),
	  list(),
	  myType(DP_MSG_SIMPLE_REQUEST),
	  aTime(),
	  time2(0, 0),
    maxAge(0)
{
}

// Konstruktor, erzeugt je nach Parameter: synch Group fuer DP_MSG_SYNCH_REQUEST bzw. DP_MSG_ASYNCH_REQUEST
inline RequestGroup::RequestGroup(const TimeVar &time, PVSSboolean synch)
	: PtrListItem(),
	  list(),
	  myType(synch ? DP_MSG_SYNCH_REQUEST : DP_MSG_ASYNCH_REQUEST),
	  aTime(time, 0),
	  time2(0, 0),
    maxAge(0)
{
}

// Konstruktor, erzeugt je nach Parameter alert Group fuer DP_MSG_PERIOD_REQUEST bzw. DP_MSG_ALERT_PERIOD_REQU
inline RequestGroup::RequestGroup(const TimeVar &startTime, const TimeVar &endTime, PVSSboolean alert)
	: PtrListItem(),
	  list(),
	  myType(alert ? DP_MSG_ALERT_PERIOD_REQU : DP_MSG_PERIOD_REQUEST),
	  aTime(startTime, 0),
	  time2(endTime),
    maxAge(0)
{
}

// Konstruktor, erzeugt Group fuer DP_MSG_ALERT_TIME_REQU
inline RequestGroup::RequestGroup(const AlertTime &time)
	: PtrListItem(),
	  list(),
	  myType(DP_MSG_ALERT_TIME_REQU),
	  aTime(time),
	  time2(0, 0),
    maxAge(0)
{
}

// Copy-Konstruktor
inline RequestGroup::RequestGroup(const RequestGroup &group)
	: PtrListItem(),
	  list(), 
    aTime(),
    time2(0, 0),
    maxAge(0)
{
	operator=(group);
}

// Konstruktor, erzeugt Group fuer DP_MSG_MAXAGE_REQUEST
inline RequestGroup::RequestGroup(const PVSSulong &timespan)
	: PtrListItem(),
	  list(),
	  myType(DP_MSG_MAXAGE_REQUEST),
	  aTime(),
	  time2(0, 0),
    maxAge(timespan)
{
}

// Destruktor
inline RequestGroup::~RequestGroup()
{
}

#endif /* _REQUESTGROUP_H_ */

