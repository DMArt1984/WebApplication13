//----------------------------------------------------------------------------
// Copyright (C) Siemens AG 2018. All Rights Reserved.
//----------------------------------------------------------------------------
// Descr.: 
//----------------------------------------------------------------------------

#ifndef _LANGTEXTPARSER_HXX_
#define _LANGTEXTPARSER_HXX_

#include <iostream>
#include <string.h>

#include <CharString.hxx>
#include <OaResources.hxx>
#include <LangText.hxx>

//----------------------------------------------------------------------------

class DLLEXP_OABASICS LangTextParser
{
  friend class UNIT_TEST_FRIEND_CLASS;

public:

  LangTextParser();

  LangTextParser(const LangTextParser &other);

public:

  ///read LangText from std::istream by its version (version is panel-like)
  ///@param from (std::istream)
  ///@param version (PVSSshort)
  ///@param to (LangText) returns its value from stream
  bool read(std::istream &from, PVSSshort version, LangText &to) const;

  ///write LangText to std::ostream by its version (version is panel-like)
  ///@param from (LangText)
  ///@param version (PVSSshort)
  ///@param to (std::ostream)
  bool write(const LangText &from, PVSSshort version, std::ostream &to) const;

  ///write LangText to std::ostream by its version (version is panel-like)
  ///@param langText (LangText)
  ///@param version (PVSSshort)
  // @param nOfLang (LanguageIdType)
  // @param langList (LanguageIdType *)
  ///@param to (std::ostream)
  bool write(const LangText &from, PVSSshort version, LanguageIdType nOfLang, const LanguageIdType *langList, std::ostream &to) const;

  ///read from an input stream
  ///@n If version is less than 5, the string starts and ends with a double quote.
  ///If version equals 5 or higher, the string starts with the number of characters then a blank and then the
  ///characters. Multibyte characters must be read with version 5 or higher.
  ///@param from the input stream
  ///@param version the string representation version
  ///@param to is output variable for read data
  ///@return the state of the input stream, i.e. PVSS_TRUE if the read was successful,
  ///PVSS_FALSE after an error
  static bool read(std::istream &from, PVSSshort version, CharString &to);

  ///write to an output stream
  ///@n If version is less than 5, the string starts and ends with a double quote.
  ///If version equals 5 or higher, the string starts with the number of characters then a blank and then the
  ///characters. Multibyte characters must be read with version 5 or higher.
  ///@param from is input variable for written data
  ///@param version the string representation version
  ///@param to the output stream
  ///@return the state of the output stream, i.e. PVSS_TRUE if the read was successful,
  ///PVSS_FALSE after an error
  static bool write(const CharString &from, PVSSshort version, std::ostream &to);

  ///set if or not only project languages should be read and other languages are ignored or not
  ///@param value true if only forced languages should be read, false if all languages should be read
  void setReadOnlyProjectLanguages(bool value) { _readOnlyProjectLanguages = value; }

  ///get if or not only project languages should be read and other languages are ignored or not
  ///@n default is false
  ///@return true if only forced languages should be read, false if all languages should be read
  bool getReadOnlyProjectLanguages() const { return _readOnlyProjectLanguages; }

  ///set if or not fallback hierarchy should be used for project languages which are not already read
  ///@param value true if fallback hierarchy should be used, otherwise false
  void setUseFallbackHierarchyOnRead(bool value) { _useFallbackHierarchy = value; }

  ///get if or not fallback hierarchy should be used for project languages which are not already read
  ///@n default is false
  ///@param value true if fallback hierarchy should be used, otherwise false
  bool getUseFallbackHierarchyOnRead() const { return _useFallbackHierarchy; }

private:

  ///Sets the text for a specific project language,
  ///using the language fallback algorithm.
  ///The method should be only called if the text is not yet filled.
  ///The text remains empty if no text is found for any fallback language.
  ///Note that the fallback algorithm is implemented in Resources class.
  ///@param lang - project language for which the text should be filled.
  ///@param firstId - global language id used if no other language found.
  ///@param bFlagIdxArray - indicates for each project language whether the text is already set.
  void substituteLang(LangText &langText, LanguageIdType lang, GlobalLanguageIdType firstId, PVSSboolean *bFlagIdxArray) const;

  static bool getSafeLine(std::istream &from, CharString &safeLine, const size_t &safeLineCharCount);

private:

  static const PVSSshort THRESHOLD_VERSION;

  bool _readOnlyProjectLanguages;
  bool _useFallbackHierarchy;
};

#endif
//----------------------------------------------------------------------------
