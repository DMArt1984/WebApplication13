#ifndef _HTTP_H_
#define _HTTP_H_

#include <Socket.hxx>
#include <DynVar.hxx>
#include <RecVar.hxx>
#include <MsgBuffer.hxx>

/** The HTTP server class.
 * This class implements the core of an HTTP Server,
 * based on the HTTP/1.1 protocol defined in RFC2616
 * WARNING: This implementation only works with blocking sockets
 *
 * @classification public use 
 */
class DLLEXP_OABASICS HTTP //author Martin Koller
{
  public:
    /** Constructor; Reads the contentTypes.txt file
     * @param onlyHTTP indicates whether the socket provided to the methods of HTTP
     *                 is used by HTTP exclusively.
     *                 <ul>
     *                    <li><tt>true</tt>: HTTP is the only user
     *                    <li><tt>false</tt>: another line-oriented protocol shares the
     *                        socket with HTTP
     *                 </ul>
     */
    HTTP(bool onlyHTTP = true);

    /// Destructor
    virtual ~HTTP();

    /// Holds the content of a HTTP request
    struct DLLEXP_OABASICS RequestStruct
    {
      /// The state, in which the RequestStruct is left after readMessage()
      enum
      {
        /// Init, next: Read header
        STATE_INIT = 0,
        /// Reading header
        STATE_HEADER = 1,
        /// Reading body
        STATE_BODY = 2,
        /// All read without errors
        STATE_FINISHED = 3,
        /// Error reading request
        STATE_ERROR = 4,
        /// Unknown protocol
        STATE_UNKNOWN = 5
      } state;

      /// HTTP method, e.g. "GET", "HEAD", "POST", etc.
      CharString method;

      /** The requested URI without query parameters. It is UTF-8-decoded to the
       *  currently selected language.
       */
      CharString uri;

      /** query-parameters of the request (e.g. ?param1=xxx). Contains exactly
        * two DynVar(TEXT_VAR) elements, the first for the parameter names,
        * second for the parameter values. Unlike <tt>uri</tt>, the parameter names
        * and values are not UTF-8-decoded. If an application needs this, it has to
        * do that itself.
        */
      RecVar *params;

      /// HTTP protocol, e.g. "HTTP/1.1"
      CharString protocol;
      /// indicates if the connection shall be closed after response
      bool connClose;

      /// All header names found in the request, the corresponding values are stored in headerValues
      DynVar headerNames;
      /// All header values found in the request, the corresponding names are stored in headerNames
      DynVar headerValues;

      /// The content type, if the request contained one, else ""
      CharString contentType;

      /// The authorization user, if the request contained one, else ""
      CharString user;
      /// The authorization password, if the request contained one, else ""
      CharString passwd;
      /// The content length, e.g. the number of bytes which can be read from dataBufferPtr
      size_t contentLen;
      /// If not 0, a FileVar(), whose contents shall be transmitted to the client
      Variable *response;
      /// Content of WWW-Authenticate to be sent back to the client
      CharString respAuth;
      
      /// Pointer to allocated memory, do not alter
      char *recvBufferPtr;
      /** Pointer to the unprocessed request data. If state is STATE_FINISHED, it contains the
       *  request body (e.g. for POST-requests). Note that this is not 0-terminated C-string but
       *  a memory area
       */
      char *dataBufferPtr;
      /// Pointer to allocated memory, do not alter
      char *freeBufferPtr;
      
      /** Returns the size available in the data buffer.
       * @return if state is STATE_FINISHED, the return value is greater or equal to contentLen
       */
      size_t size() const {return freeBufferPtr - dataBufferPtr;}

      /// Constructor
      RequestStruct() : state(STATE_INIT), params(0), connClose(false),
                        headerNames(TEXT_VAR), headerValues(TEXT_VAR), 
                        contentLen(0), response(0), 
                        recvBufferPtr(0), dataBufferPtr(0), freeBufferPtr(0) {}

      /// Destructor
      ~RequestStruct() 
      { 
        delete params; 
        delete response;
        
        delete[] recvBufferPtr;
      }

      /** Lookup the header fields of the request for <tt>key</tt>
       *
       * @param [in] key the header name
       * @param [out] value the header value
       * @return <tt>true</tt> iff the header <tt>key</tt> was found
       */
      bool getHeader(const CharString &key, CharString &value) const;

      private:
        RequestStruct & operator=(const RequestStruct &) {return *this;}  //COVINFO LINE: defensive (AP: disallow operator=)
        RequestStruct(const RequestStruct &) {}  //COVINFO LINE: defensive (AP: disallow copy ctor)
    };  

    /// returnvalues for readMessage()
    enum ReadMessageReturnValue
    {
      /// a read error was detected. You should close the connection
      READ_ERROR   = 0,
      /** part of a message was read, readMessage() should be called again with the
       *  same parameters
       */
      READ_PENDING = 1,
      /// a valid HTTP Message was read
      READ_HTTP    = 2,
      /// a full line of an unknown protocol was successfully read into the buffer
      READ_UNKNOWN = 3
    };

    /** read one HTTP request and store content in given RequestStruct.
     *  The given RequestStruct MUST BE a newly created one, it will not be cleared
     *  before use. The only exception is a return value of <tt>READ_PENDING</tt>,
     *  which demands using the same RequestStruct again to complete it.
     *
     * @param [in]  http the Socket to read from
     * @param [out] req the RequestStructure, into which the request data shall
     *              be inserted
     *
     *  @return see ReadMessageReturnValue
     */
    int readMessage(Socket &http, RequestStruct &req);

    /** This method retrieves the next line from the internal buffer.
     *  This must be used for non-HTTP protocols after readMessage(), because readMessage()
     *  could have read already another line into the internal buffer.
     *
     * @param [in]  http the Socket to read from
     * @param [out] req the RequestStructure, into which the request data shall
     *              be inserted
     *
     *  @return a pointer into somewhere into the RequestStruct's recvBufferPtr,
     *          not a newly created one, so you must not delete it
     */
    char *getLine(Socket &http, RequestStruct &req);

    /** Converts the query-string <tt>data</tt> into one list for the parameter names
     *  and one for the parameter values.
     *  This function always returns a new RecVar object, so the caller of this method
     *  has to take care of it.
     * @param data a query-string without the leading '?'
     *
     * @return a RecVar containing two elements of type DynVar(TEXT_VAR), the first
     *         for the parameter names, the second for the parameter values
     */
    RecVar *getParams(const char *data) const;

    /** Sends a response with HTML content to the client. This method sets the Content-Type,
     *  Content-Length and Date header fields correctly and refuses from sending a HTTP body
     *  if the client's request was a HEAD request.
     *
     * @param http the Socket, to which the content shall be written
     * @param req  a RequestStruct containing the last request received from the client
     * @param header the HTTP header, starting with the response code line
     * @param body any HTML content
     */
    void sendMessage(Socket &http, const RequestStruct &req, const char *header, const char *body);

    /** Handles a GET request (send files) from Std-directories (pictures, data, help)
     *
     * @param http the Socket, to which the content shall be written
     * @param req  a RequestStruct containing the last request received from the client
     * @return <tt>true</tt> iff this was a request for one of these dirs, else false
     */
    bool handleStdDirs(Socket &http, RequestStruct &req);

    // is the given path really addressing a file below given dir ?
    // e.g. /data/../../file is not below, but /data/../data/file is
    static bool isBelowDir(const CharString &path, const CharString &dir);

    /** Sends "Not Implemented" HTTP response
     *
     * @param http the Socket, to which the content shall be written
     * @param req  a RequestStruct containing the last request received from the client
     */
    void errorNotImplemented(Socket &http, const RequestStruct &req);

    /** Sends "Not Found" HTTP response
     *
     * @param http the Socket, to which the content shall be written
     * @param req  a RequestStruct containing the last request received from the client
     */
    void errorNotFound(Socket &http, const RequestStruct &req);

    /** Sends "Not Authorized" HTTP response for given realm (e.g. "PVSS") containing
     *  an appropriate WWW-Authenticate-header
     *
     * @param http  the Socket, to which the content shall be written
     * @param req   a RequestStruct containing the last request received from the client
     * @param realm either a complete WWW-Authenticate-header line, with or without CRLF,
     *              or the realm name, for which a WWW-Authenticate-header shall be created
     */
    void errorNoAuth(Socket &http, const RequestStruct &req, const CharString &realm);

    /** Sends "Requested Range Not Satisfiable" HTTP response containing an appropriate
     *  Content-Range header field that indicates satisfiable ranges
     *
     * @param http the Socket, to which the content shall be written
     * @param req  a RequestStruct containing the last request received from the client
     * @param size the size in bytes for the Content-Range header field
     */
    void errorNotSatisfiable(Socket &http, const RequestStruct &req, size_t size);

    /** Sends a file's content to the client. This method can handle the If-Modified-Since,
     *  the If-Unmodified-Since and (partially) the Range-header correctly. It also allows
     *  Content-Encoding in gzip and pack200-gzip, although for pack200-gzip it doesn't create the compressed
     *  file content itself. For a pack200-gzip-request, a file
     *  <tt>fileName</tt>.pack.gz has to exist, which is newer than <tt>fileName</tt>.
     *
     *  This method always sends the HTTP header and may send (parts) of the file's content.
     *  If it did not succeed sending the whole file, RequestStruct::response is set a FileVar
     *  object and you have to continue sending the file's content to the client.
     *
     * @param http the Socket, to which the content shall be written
     * @param [in,out] req  a RequestStruct containing the last request received from the client
     * @param fileName the name of the file, whose content shall be sent to the client
     * @param contentType if the contentType is already known, pass it here, else it will be auto-determined
     */
    void sendFileContent(Socket &http, RequestStruct &req, const CharString &fileName, CharString contentType = CharString());

    /// defines if caching of auto-compressed files is allowed (stored in proj_path/cache)
    void setCompressionCacheEnabled(bool on);

    /// Returns the "Date:" header with current date+time in the format defined in RFC2616 (HTTP-Protocol)
    static CharString dateHeader();

    /** Returns general headers
      *  always returns dateHeader()
      *  and if socket.isSecured() == true, "Strict-Transport-Security:" header
      *  and if setXFrameOptions was called, "X-Frame-Options:" header
     */
    CharString generalHeaders(const Socket &socket) const;

    void clearGeneralHeaders();

    void addGeneralHeader(const CharString &header);

    /// Returns the the specified date+time in the format defined in RFC2616
    static CharString encodeDate(time_t t);

    /// Returns the time encoded in the RFC2616-conform string or -1 on error
    static time_t decodeDate(const char *date);

    /// Returns a Content-Type depending on the extension of the given fileName
    CharString getContentType(const CharString &fileName);

    /// Sets the maximum content length the server will accept on a POST or PUT request
    void setMaxContentLength(size_t l) { maxContentLength_ = l; }

    void setStrictTransportSecurityMaxAge(unsigned int maxAge) { strictTransportSecurityMaxAge_ = maxAge; }

    /** Manages Cache-Control and Expires headers in the next call of sendFileContent()
     *
     * @param maxAge if non-0, the Cache-Control and Expires headers are set according
     *               time in seconds given with this parameter, if 0, neither Cache-Control
     *               nor Expires is set automatically.
     */
    void setMaxAge(unsigned maxAge) { maxAge_ = maxAge; }

    /** allows setting of XFrameOptions for all outgoing messages 
     *  (see also https://developer.mozilla.org/en-US/docs/Web/HTTP/X-Frame-Options)
     *
     *  @param option option string
     */
    void setXFrameOptions(const CharString &option) { xFrameOptions_ = option; }

  private:
    bool onlyHTTP_;            // is the socket used only for HTTP
    bool compressionCacheEnabled;

    size_t maxContentLength_;  // max. Content-Length in POST requests

    unsigned maxAge_;          // "Cache-Control: max-age" for content handle by sendFileContent

    struct ContentType
    {
      CharString contentType;  // type-definition
      CharString extension;    // fileName extension

      ContentType *next;       // pointer to next in chained-list

      ContentType(ContentType *&first, const char* type, const char* ext);
    };

    ContentType *contentTypes_;  // pointer to first ContentType entry

    unsigned int strictTransportSecurityMaxAge_; // max-age of "Strict-Transport-Security" header

    CharString xFrameOptions_;    // IM 119210 values: DENY / SAMEORIGIN / ALLOW-FROM uri
    CharString generalHeaders_;

    void readHeader(Socket &socket, RequestStruct &reqStruct);
    void readBody(Socket &socket, RequestStruct &reqStruct);

    void handleAuth(char *line, CharString &user, CharString &passwd);
    void unescape(char *buf) const;
    void base64Decode(char *s) const;

    void initContentTypes();
    
    PVSSboolean readSocket(Socket &socket, char *buffer, int len, int &bytes);

    bool handleStdDir(Socket &http, RequestStruct &req,
                      const CharString &dir, CharString (*getPath)(int));

    bool handleLangDir(Socket &http, RequestStruct &req,
                       const CharString &dir, CharString (*getPath)(int));

    friend class UNIT_TEST_FRIEND_CLASS;
};

#endif /* _HTTP_H_ */
