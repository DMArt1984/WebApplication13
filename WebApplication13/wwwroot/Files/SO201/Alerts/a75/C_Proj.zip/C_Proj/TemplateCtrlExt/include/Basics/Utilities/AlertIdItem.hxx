#ifndef _ALERTIDITEM_H_
#define _ALERTIDITEM_H_

#ifndef _PTRLISTITEM_H_
#include <PtrListItem.hxx>
#endif

#ifndef _ALERTIDENTIFIER_H_
#include <AlertIdentifier.hxx>
#endif

/**
 * Wrapper class to insert an AlertIdentifier into a PtrList.
 */
class AlertIdItem : public PtrListItem
{
  public:
    /**
     * Creates a new instance for the specified AlertIdentifier.
     *
     * @param aId The AlertIdentifier to be wrapped
     */
    AlertIdItem(const AlertIdentifier &aId = AlertIdentifier()) : id(aId) {}

    /**
     * Checks whether the current object and the specified object are equal.
     */
    int operator==(const AlertIdItem &item) const { return (id == item.id); }

    /**
     * The message stream send operator. This operator is used to send an
     * instance through a BCM network stream.
     *
     * @internal
     */
    friend itcNdrUbSend &operator<<(itcNdrUbSend &ndrStream, const AlertIdItem &item)
        { return ndrStream << item.id; }

    /**
     * The message stream receive operator. This operator is used to receive
     * AlertIdItem objects from a BCM network stream.
     *
     * It must be the exact mirror function to the send operator.
     * 
     * @internal
     */
    friend itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream, AlertIdItem &item)
        { return ndrStream >> item.id; }

    /**
     * Returns the AlertIdentifier contained in this instance.
     *
     * @return The wrapped AlertIdentifier
     */
    const AlertIdentifier &getId() const { return id; }

  protected:

  private:
    AlertIdentifier id;
};

#endif /* _ALERTIDITEM_H_ */
