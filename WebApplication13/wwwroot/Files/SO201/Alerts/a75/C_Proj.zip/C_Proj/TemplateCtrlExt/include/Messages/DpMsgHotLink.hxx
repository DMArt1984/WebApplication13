// DATEIBESCHREIBUNG ==============================================================
// DATEINAME:     DpMsgHotLink.hxx
// VERANTWORTUNG: Johannes Ertl
// BESCHREIBUNG:	DpMsgHotLink ist die Aenderungsmeldung, welche fuer angemeldete
// 		Attribute geschickt wird.
// 		
// 		Ein Manager kann sich beim Event-Manager fuer bestimmte 
// 		Attribute anmelden und wird dann von jeder Aenderung dieser
// 		Attribute vom Event-Manager mit einer DpMsgHotLink-Message
// 		informiert. Jede angemeldete Gruppe kann mehrere Attribute
// 		enthalten, die entsprechende Aenderungsmeldung wird in einer
// 		DpHLGroup geschickt, eine DpMsgHotLink kann mehrere DpHLGroups
// 		enthalten.
// 		
// 		Eine DpMsgHotLink - Message hat nie eine Antwort-Message
// 
//
// AENDERUNGS-HISTORIE
// Ver.  | Datum      | Aenderungen                            | ModNr.| Autor
// ------+------------+-----------------Anfang-----------------+-------+-----------
//   1.0 |            | 1.Erstellung mit Westmount-OMT         |     0 |
// ======================================Ende======================================
#ifndef _DPMSGHOTLINK_H_
#define _DPMSGHOTLINK_H_

// Vorwaerts-Deklaration der Eigenen Klasse
class DpMsgHotLink;

// ========== DpMsgHotLinkPtr ============================================================

typedef DpMsgHotLink* DpMsgHotLinkPtr;

#include <ostream>
#include <DpHLGroup.hxx>
#include <DpMsg.hxx>
#include <PtrList.hxx>

// Vorwaerts-Deklarationen :
class DpMsgHotLink;
class ManagerIdentifier;
class Msg;

// ========== DpMsgHotLink ============================================================

/** A manager may connect to several attributes. Every time
  an attribute is changed a DpMsgHotLink message is sent to this manager.
  The data are organised in groups, each group contains all data in the order they
  were listed in the connect message and each group belongs to one transaction that
  caused an attribute change.
 */
class DLLEXP_MESSAGES DpMsgHotLink : public DpMsg 
{
  friend class UNIT_TEST_FRIEND_CLASS;    // ein Unit-Test braucht erweiterten zugriff auf diese Klasse

  /// operator << for itcNdrUbSend stream
  /// @param ndrStream the stream, which to send to
  /// @param msg the DpMsgHotLink
  friend DLLEXP_MESSAGES itcNdrUbSend &operator<<(itcNdrUbSend &ndrStream, const DpMsgHotLink &msg);

  /// operator >> for itcNdrUbReceive stream
  /// @param ndrStream the stream, which to receive from
  /// @param msg the DpMsgHotLink
  friend DLLEXP_MESSAGES itcNdrUbReceive &operator>>(itcNdrUbReceive &ndrStream, DpMsgHotLink &msg);
 
  public:

    /// constructor
    /// @param newDestination the manager ID
    DpMsgHotLink(const ManagerIdentifier &newDestination);

    /// default constructor, initialisation with zero values
    DpMsgHotLink();

    /// copy constructor
    /// @param msg the DpMsgFilterHL to copy
    DpMsgHotLink(const DpMsgHotLink &msg);

    /// destructor
    ~DpMsgHotLink();

    // Operatoren :
  
    /// comparison operator ==
    /// @param rVal the DpMsgHotLink to compare with
    /// @return 0 if not equal else 1
    int operator==(const DpMsgHotLink &rVal) const;

    /// comparison operator !=
    /// @param rVal the DpMsgHotLink to compare with
    /// @return 1 if not equal else 0
    int operator!=(const DpMsgHotLink &rVal) const {return !operator==(rVal);}

    /// comparison operator ==
    /// @param rVal the message to compare with
    /// @return 0 if not equal else 1
    virtual int operator==(const Msg &rVal) const;

    /// assignment operator for DpMsgHotLink
    /// @param rVal the DpMsgHotLink to assign
    /// @return the resulting DpMsgHotLink
    DpMsgHotLink &operator=(const DpMsgHotLink &rVal);

    /// assignment operator used for type conversion
    /// @param rVal the message to convert
    /// @return the resulting message
    virtual Msg &operator=(const Msg &rVal);

    /// send debug info to output stream
    /// @param to the output stream
    /// @param level the debug level
    virtual void debug(std::ostream &to, int level) const;

    // Spezielle Methoden :

    /// append a DpHLGroup
    /// @param groupPtr the pointer to DpHLGroup to append
    /// @n The class takes responsibility for the pointer.
    void appendGroup(DpHLGroup *groupPtr);

    /// get first hotlink group or 0, if the list is empty
    DpHLGroup *getFirstGroup() const;

    /// get next hotlink group or 0, if there are no groups left
    DpHLGroup *getNextGroup() const;

    /// get group following the group argument or 0, if this was the last one
    /// @param group the pointer to the DpHLGroup
    DpHLGroup *getNextGroup(DpHLGroup *group) const;

    /// get number of groups in this message
    virtual PVSSulong getNrOfGroups() const {return groupList.getNumberOfItems();};

    /// cut out the first group
    /// @n You are responsible to delete it.
    DpHLGroup *cutFirstGroup() {return (DpHLGroup *) groupList.cutFirst();}

    /// cut out the last group
    /// @n You are responsible to delete it.
    DpHLGroup *cutLastGroup() {return (DpHLGroup *) groupList.cutLast();}

    /// get group ID
    virtual DpIdentifier getGroupId(PVSSulong) const;

    /// allocate a new message
    Msg *allocate() const;
  
  	/// check if own DP message type matches other DP message type
    /// @param dpMsgType the MsgType to check
    /// @return DpMsgHotLink type if argument is DpMsgHotLink else a DP message type
    MsgType isA(MsgType dpMsgType) const;

    /// get message type, always returns DP_MSG_HOTLINK
    MsgType isA() const;

  private:
    void outNdrUb(itcNdrUbSend &ndrStream) const;
    void inNdrUb(itcNdrUbReceive &ndrStream);
    PtrList groupList;
};

// ================================================================================
// Inline-Funktionen :

inline void DpMsgHotLink::appendGroup(DpHLGroup *groupPtr)
{
  groupList.append(groupPtr);
}

inline DpHLGroup *DpMsgHotLink::getFirstGroup() const
{
  return (DpHLGroup *)groupList.getFirst();
}

inline DpHLGroup *DpMsgHotLink::getNextGroup() const
{
  return (DpHLGroup *)groupList.getNext();
}

inline DpHLGroup *DpMsgHotLink::getNextGroup(DpHLGroup *group) const
{
  return (DpHLGroup *)groupList.getNext(group);
}

inline Msg *DpMsgHotLink::allocate() const
{
  return new DpMsgHotLink;
}

// ................................OMT-Regeneration................................

#endif /* _DPMSGHOTLINK_H_ */
