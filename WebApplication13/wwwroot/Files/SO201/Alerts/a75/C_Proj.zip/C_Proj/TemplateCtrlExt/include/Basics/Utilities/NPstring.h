#ifndef _NPSTRING_H_
#define _NPSTRING_H_

/*
VERANTWORTUNG: Mark Probst
BESCHREIBUNG: string function which check for null pointers, report the
  error, but treat them as empty strings.
*/

#include <string.h>

#ifdef __cplusplus
extern "C" { 
#endif

/**string concatenation
*/
DLLEXP_BASICS char* NPstrcat (char *s1, const char *s2);
/**string concatenation
*/
DLLEXP_BASICS char* NPstrncat (char *s1, const char *s2, size_t n);

/**string concatenation
*/
DLLEXP_BASICS int NPstrcmp (const char *s1, const char *s2);
/**string comparation
*/
DLLEXP_BASICS int NPstrncmp (const char *s1, const char *s2, size_t n);
/**string comparation
*/
DLLEXP_BASICS int NPstrcasecmp (const char *s1, const char *s2);

/**string comparation using locale
*/
DLLEXP_BASICS int NPstrcoll(const char *s1, const char *s2);

/**string copy
*/
DLLEXP_BASICS char* NPstrcpy (char *s1, const char *s2);
/**string copy
*/
DLLEXP_BASICS char* NPstrncpy (char *s1, const char *s2, size_t n);

/**string duplcation
*/
DLLEXP_BASICS char* NPstrdup (const char *s);

/**find a pattern in the string 
*/
DLLEXP_BASICS char* NPstrpbrk (const char *s1, const char *s2);

/**find one of the characters in second param
*/
DLLEXP_BASICS size_t NPstrspn (const char *s1, const char *s2);

/**find pattern
*/
DLLEXP_BASICS char* NPstrstr (const char *s1, const char *s2);

/**divide string using delimiters
*/
DLLEXP_BASICS char* NPstrtok (char *s1, const char *s2);

/**string length
*/
DLLEXP_BASICS size_t NPstrlen (const char *s);

/**find character in the string 
*/
DLLEXP_BASICS char* NPstrchr (const char *s, int c);
/**find character in the string in reverse order
*/
DLLEXP_BASICS char* NPstrrchr (const char *s, int c);

#ifdef __cplusplus
}
#endif

#endif /* _NPSTRING_H_ */
