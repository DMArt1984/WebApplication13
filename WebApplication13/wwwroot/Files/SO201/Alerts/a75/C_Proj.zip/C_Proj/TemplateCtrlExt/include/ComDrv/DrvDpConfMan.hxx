#pragma once

#include <DrvConfigManager.hxx>

IL_DEPRECATED("deprecated, DrvDpConfMan renamed to DrvConfigManager")
typedef DrvConfigManager DrvDpConfMan;